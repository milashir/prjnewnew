SELECT  DISTINCT
												RES.Qid AS AssignedResoruceQid,
												RES.ManagerQid,
												R.ResourceTypeId
										FROM    dbo.Project P WITH ( NOLOCK )
												JOIN dbo.Request R WITH ( NOLOCK ) ON P.ProjectId = R.ProjectId
												JOIN dbo.ResourceRequestAssignment_XREF RRX WITH ( NOLOCK ) ON RRX.RequestId = R.RequestId
												JOIN dbo.Resource RES WITH ( NOLOCK ) ON RES.ResourceId = RRX.ResourceId
										WHERE   P.ProjectId = 7436
												AND R.ResourceTypeId IN ( 9109 )
												AND R.RequestStatusId IN ( 4, 9 )


												select * from ResourceType where ResourceTypeId=9109