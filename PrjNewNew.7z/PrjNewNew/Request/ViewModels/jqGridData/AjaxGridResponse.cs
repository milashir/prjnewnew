using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Quintiles.RM.Clinical.SharePoint.ViewModels
{
    [DataContract]
    public class AjaxGridResponse
    {
        [DataMember]
        public List<AjaxGridRowResponse> Rows { get; set; }

        public AjaxGridResponse()
        {
            Rows = new List<AjaxGridRowResponse>();
        }

    }
}
