using System;
using System.Runtime.Serialization;

namespace Quintiles.RM.Clinical.SharePoint.ViewModels
{
	[DataContract]
	public class SubmittedRequestRowResponse
	{
		[DataMember]
		public String RowId { get; set; }

		[DataMember]
		public String StartDateQ { get; set; }
		[DataMember]
		public String StopDateQ { get; set; }

		[DataMember]
		public int StartDateStatus { get; set; }
		[DataMember]
		public int StopDateStatus { get; set; }

		[DataMember]
		public string NeedByDateQ { get; set; }

		[DataMember]
		public String ErrorMessage { get; set; }
	}

	[DataContract]
	public class RequestDate_WS
	{
		[DataMember]
		public int Id { get; set; }

		[DataMember]
		public String StartDate { get; set; }

		[DataMember]
		public String StopDate { get; set; }
	}

	[DataContract]
	public class MonitoringRequestDate_WS : RequestDate_WS
	{
		[DataMember]
		public String IMDate { get; set; }
		[DataMember]
		public String CRADate { get; set; }
	}
}
