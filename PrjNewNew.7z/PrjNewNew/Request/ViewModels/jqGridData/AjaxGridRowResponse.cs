using System;
using System.Runtime.Serialization;

namespace Quintiles.RM.Clinical.SharePoint.ViewModels
{
    [DataContract]
    public class AjaxGridRowResponse
    {
        [DataMember]
        public int RowId { get; set; }

        [DataMember]
        public String Message { get; set; }

        [DataMember]
        public bool IsError { get; set; }

        private AjaxGridRowResponse() { } //no parameterless constructor
        public AjaxGridRowResponse(int rowId, bool isError, string message)
        {
            RowId = rowId;
            IsError = isError;
            Message = message;
        }

    }
}
