﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.SharePoint.ViewModels;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint
{
	[DataContract]
	public class ReqMonthlyHours_WS
	{
		[DataMember]
		public string Error;
		[DataMember]
		public decimal[] FTE;
		[DataMember]
		public decimal[] Hours;
		[DataMember]
		public int ReqID;
		[DataMember]
		public int StartMonthNumber { get; set; }
		[DataMember]
		public int StopMonthNumber { get; set; }
		[DataMember]
		public string CustomPointToolTipData { get; set; }
		[DataMember]
		public decimal[] AverageFTE;
		[DataMember]
		public decimal[] AverageHours;
		[DataMember]
		public string ProjectCode { get; set; }
	}

	[DataContract]
	public class ReqSched_WS
	{
		[DataMember]
		public int EndMonth; // Year*12 + Month
		[DataMember]
		public string Message;
		[DataMember]
		public ReqMonthlyHours_WS[] ReqMonthlyHours;
		[DataMember]
		public int StartMonth; // Year*12 + Month
		//[DataMember]
		//public ResourceTypeName ResourceType;
		/// <summary>
		///Holds the datatble from each reqtypescheduler. Used for debugging purposes
		/// </summary>
		[DataMember]
		public string DataTable;
		[DataMember]
		public string ExecutionPath;

	}

	[ServiceContract]
	public interface IRequest
	{
		[WebInvoke(Method = "POST",
			UriTemplate = "RequestQueue/Add",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		AjaxGridResponse AddRequestGroupToQueue(OpenRequestGridData[] idArray);

		[WebInvoke(Method = "POST",
			UriTemplate = "RequestQueue/Remove",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		bool RemoveGroupFromQueue(string listOfIds);

		[WebInvoke(Method = "POST",
			UriTemplate = "DeleteSubmittedRequests",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ServiceExecutionStatus_WS> DeleteSubmittedRequests(List<int> requestIds);

		[WebInvoke(Method = "POST",
			UriTemplate = "DeleteBackfillRequest",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus_WS DeleteBackfillRequest(int requestId, BackfillDeleteOption_E backfillDeleteOption);

		[WebInvoke(Method = "POST",
			UriTemplate = "TerminateRequests",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ServiceExecutionStatus_WS> TerminateRequests(List<int> requestIds, string comments);

		[WebInvoke(Method = "POST",
			UriTemplate = "Search",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<ResourceSearchRowData, ResourceResult, ResourceSearchCommonData, ResourceSearchGridCommonData> Search(SearchCriteria_WS searchCriteria);

		//[WebGet(UriTemplate = "Get?id={requestId}",
		//	BodyStyle = WebMessageBodyStyle.Bare,
		//	ResponseFormat = WebMessageFormat.Json)]
		//[OperationContract]
		//String GetRequest(int requestId);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetOpenResourceRequests",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<OpenResourceRequestRowData, OpenRequestQueue, GridRowCommonData> GetOpenResourceRequests(GridSearchResourceRequest_WS gridSearch);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetResourcingWorklistSummary",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<OpenResourceRequestRowData, OpenRequestQueue, GridRowCommonData> GetResourcingWorklistSummary(GridSearchResourceRequest_WS gridSearch);

		[WebInvoke(Method = "POST",
			UriTemplate = "UpdateRequestStartStopDates",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus<string, SubmittedRequestRowResponse> UpdateRequestStartStopDates(List<RequestDate_WS> requestDataList);

		[WebInvoke(Method = "POST",
			UriTemplate = "UpdateSingleRequestStartStopDates",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EntityExecutionStatus<SubmittedRequestRowResponse> UpdateSingleRequestStartStopDates(RequestDate_WS requestData);

		[WebInvoke(Method = "POST",
			UriTemplate = "SubmittedRequest/ReconnectDate",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		RequestSaveDateResponse ReconnectAndGetRequestDate(int requestId, string column, bool forceSave);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetOpenRequestsFromQueue",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<ResourcingWorklistRequestRowData, models.Request, RequestCommonData> GetOpenRequestsFromQueue(GridSearchByGroupId_WS gridSearch);

		[WebGet(UriTemplate = "GetCalculatorDetails?requestId={requestId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ReadonlyCalculator_WS GetCalculatorDetails(int requestId);

		[WebInvoke(Method = "POST",
			UriTemplate = "HardBookResource",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<BookingRequestResult_WS> HardBookResource(List<int> selectedRequestIds, int resourceId,
														 BidDefenseReason_WS bidDefenseResult, bool validateFirewalledProject);
		[WebInvoke(Method = "POST",
			UriTemplate = "RemoveSoftBookings",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ServiceExecutionStatus_WS> RemoveSoftBookings(List<int> selectedSoftBookingIds, string rejectedNotes);

		[WebInvoke(Method = "POST",
			UriTemplate = "SaveReturnRequest",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<BookingRequestResult_WS> SaveReturnRequest(List<int> requestIds, string description, int reasonId, string comment, int? sendQueryTo);

		[WebInvoke(Method = "POST",
			UriTemplate = "AcceptSoftBooking",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus_WS AcceptSoftBooking(int resourceRequestAssignmentId, BidDefenseReason_WS bidDefenseResult);

		[WebInvoke(Method = "POST",
			UriTemplate = "SoftBookResource",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<BookingRequestResult_WS> SoftBookResource(List<int> selectedRequestIds, List<int> selectedResources, bool validateFirewalledProject);


		[WebInvoke(Method = "POST",
			UriTemplate = "GetRequestSchedule",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ReqSched_WS GetRequestSchedule(List<int> reqID, bool isExecPathRequired, int graphContext);

		[WebInvoke(Method = "POST",
			UriTemplate = "Resubmit",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ServiceExecutionStatus_WS> Resubmit(ResubmitRequest_WS resubmitRequest);

		[WebInvoke(Method = "POST",
				UriTemplate = "CreateBackfillRequest",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ValidationAndExecutionStatus_WS CreateBackfillRequest(BackfillDetail_WS backfillDetail);

		[WebInvoke(Method = "POST",
				UriTemplate = "CreateBackfillRequestAndAssignResource",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ValidationAndExecutionStatus_WS CreateBackfillRequestAndAssignResource(BackfillAssignmentDetail_WS backfillDetail);

		[WebInvoke(Method = "GET",
			UriTemplate = "RenderInitiateCalculator?projectId={projectId}&resourceId={resourceId}&countryId={countryId}&requestId={requestId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS RenderInitiateCalculator(int projectId, int resourceId, int countryId, int requestId);

		[WebInvoke(Method = "GET",
			UriTemplate = "RenderRegionBasedInitiateCalculator?projectId={projectId}&resourceId={resourceId}&regionId={regionId}&requestId={requestId}&requestStartDate={requestStartDate}&requestStopDate={requestStopDate}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS RenderRegionBasedInitiateCalculator(int projectId, int resourceId, int regionId, int requestId, string requestStartDate, string requestStopDate);

		[WebInvoke(Method = "GET",
			UriTemplate = "RenderGlobalInitiateCalculator?projectId={projectId}&resourceTypeId={resourceTypeId}&organizationId={organizationId}&requestId={requestId}&requestStartDate={requestStartDate}&requestStopDate={requestStopDate}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS RenderGlobalInitiateCalculator(int projectId, int resourceTypeId, int organizationId, int requestId, string requestStartDate, string requestStopDate);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetInitiateCalculatorbyRequest?requestId={requestId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetInitiateCalculatorbyRequest(int requestId);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetCalculatorsByRequestId?requestId={requestId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetCalculatorsByRequestId(int requestId);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetRegionBasedInitiateCalculatorbyRequest?requestId={requestId}&regionId={regionId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetRegionBasedInitiateCalculatorbyRequest(int requestId, int regionId);

		[WebInvoke(Method = "GET",
				UriTemplate = "GetGenericInitiateCalculatorbyRequest?requestId={requestId}",
				BodyStyle = WebMessageBodyStyle.Bare,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetGenericInitiateCalculatorbyRequest(int requestId);

		[WebInvoke(Method = "GET",
				UriTemplate = "GetGlobalPhaseCalculatorsByResourceTypeId?resourceType={resourceType}",
				BodyStyle = WebMessageBodyStyle.Bare,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetGlobalPhaseCalculatorsByResourceTypeId(ResourceTypeName resourceType);

		[WebInvoke(Method = "GET",
				UriTemplate = "GetGlobalInitiateCalculatorbyRequest?requestId={requestId}&organizationId={organizationId}",
				BodyStyle = WebMessageBodyStyle.Bare,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetGlobalInitiateCalculatorbyRequest(int requestId, int organizationId);

		[WebInvoke(Method = "GET",
				UriTemplate = "GetDefaultGenericCalculatorsByResourceTypeId?resourceTypeId={resourceTypeId}&countryId={countryId}",
				BodyStyle = WebMessageBodyStyle.Bare,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetDefaultGenericCalculatorsByResourceTypeId(int resourceTypeId, int countryId);

		[WebInvoke(Method = "GET",
			UriTemplate = "CalculateWeeklyHourFTE?countryId={countryId}&resourceId={resourceId}&modifiedWeeklyHoursFTE={modifiedWeeklyHoursFTE}&type={type}&jobRoleId={jobRoleId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		decimal CalculateWeeklyHourFTE(int countryId, int resourceId, decimal modifiedWeeklyHoursFTE, string type, int jobRoleId);

		[WebInvoke(Method = "GET",
			UriTemplate = "CalculateRegionalFte?regionId={regionId}&resourceId={resourceId}&weeklyHours={weeklyHours}&resourceCountryId={resourceCountryId}&jobRoleId={jobRoleId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		decimal CalculateRegionalFte(int regionId, int resourceId, decimal weeklyHours, int resourceCountryId, int jobRoleId);

		[WebInvoke(Method = "GET",
			UriTemplate = "CalculateRegionalWeeklyHours?regionId={regionId}&resourceId={resourceId}&fte={fte}&resourceCountryId={resourceCountryId}&jobRoleId={jobRoleId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		decimal CalculateRegionalWeeklyHours(int regionId, int resourceId, decimal fte, int resourceCountryId, int jobRoleId);

		[WebInvoke(Method = "GET",
			UriTemplate = "CalculateGlobalFte?organizationId={organizationId}&resourceTypeId={resourceTypeId}&weeklyHours={weeklyHours}&resourceCountryId={resourceCountryId}&jobRoleId={jobRoleId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		decimal CalculateGlobalFte(int organizationId, int resourceTypeId, decimal weeklyHours, int resourceCountryId, int jobRoleId);

		[WebInvoke(Method = "GET",
			UriTemplate = "CalculateGlobalWeeklyHours?organizationId={organizationId}&resourceTypeId={resourceTypeId}&fte={fte}&resourceCountryId={resourceCountryId}&jobRoleId={jobRoleId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		decimal CalculateGlobalWeeklyHours(int organizationId, int resourceTypeId, decimal fte, int resourceCountryId, int jobRoleId);

		[WebInvoke(Method = "POST",
				UriTemplate = "GetSoftBookingList",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<SoftBookedRequestRowData, ResourceRequestAssignment, RequestCommonData> GetSoftBookingList(GridSearchRequestAssignment_WS gridSearch);

		[WebInvoke(Method = "POST",
				UriTemplate = "GetUnsubmittedSsvRequests",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<SsvRequestRowData, models.Request, RequestCommonData> GetUnsubmittedSsvRequests(GridSearchRequest_WS gridSearch);

		[WebInvoke(Method = "POST",
				 UriTemplate = "GetUnsubmittedPermanentRequests",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<MonitoringRequestRowData, models.Request, RequestCommonData> GetUnsubmittedPermanentRequests(GridSearchRequest_WS gridSearch);

		//[WebInvoke(Method = "POST",
		//		 UriTemplate = "GetProposalRequests",
		//		BodyStyle = WebMessageBodyStyle.WrappedRequest,
		//		RequestFormat = WebMessageFormat.Json,
		//		ResponseFormat = WebMessageFormat.Json)]
		//[OperationContract]
		//JqGridData<ProposalRequestRowData, models.Request, RequestCommonData> GetProposalRequests(GridSearchRequest_WS gridSearch);

		[WebInvoke(Method = "POST",
				 UriTemplate = "GetSubmittedRequests",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<SubmittedRequestRowData, models.Request, RequestCommonData> GetSubmittedRequests(GridSearchRequest_WS gridSearch);

		[WebInvoke(Method = "POST",
				 UriTemplate = "GetAllInitiateRequests",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<InitiateRequestRowData, models.Request, RequestCommonData> GetAllInitiateRequests(GridSearchRequest_WS gridSearch);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetCountryRegions?countryIds={countryIds}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<CountryRegions_WS> GetCountryRegions(string countryIds);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetCountryRegionCountryName?countryIds={countryIds}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<CountryRegions_WS> GetCountryRegionCountryName(string countryIds);

		[WebInvoke(Method = "GET",
		UriTemplate = "GetDistinctCountryIds",
		BodyStyle = WebMessageBodyStyle.Bare,
		ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<int> GetDistinctCountryIds();

		[WebInvoke(Method = "GET",
			UriTemplate = "GetResourceTypeNames?projectState={projectState}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<KeyValue_WS> GetResourceTypeNames(int projectState);

		[WebInvoke(Method = "POST",
			UriTemplate = "ValidateAndSaveInitiateRequest",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		AddUpdateInitiateRequestStatus_WS ValidateAndSaveInitiateRequest(InitiateRequests_WS initiateRequest);


		[WebInvoke(Method = "POST",
			UriTemplate = "SubmitInitiateRequestsMigration",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		AddUpdateInitiateRequestStatus_WS SubmitInitiateRequestsMigration(int requestId, string rowId);

		[WebInvoke(Method = "POST",
			UriTemplate = "ValidateRequestHasDeactivatedMilestones",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		MilestoneValidation_WS ValidateRequestHasDeactivatedMilestones(string requestIds, string milestoneIds, bool reloadPage, bool validateForAssignedRequest, StringArray DeletedMilestones);

		[WebInvoke(Method = "POST",
			UriTemplate = "ValidateAndUpdateInitiateRequest",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		AddUpdateInitiateRequestStatus_WS ValidateAndUpdateInitiateRequest(InitiateRequests_WS initiateRequest);

		[WebInvoke(Method = "POST",
	UriTemplate = "SubmitRequests",
	BodyStyle = WebMessageBodyStyle.WrappedRequest,
	RequestFormat = WebMessageFormat.Json,
	ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ServiceExecutionStatus_WS> SubmitRequests(List<int> requestIds);

		[WebInvoke(Method = "POST",
			UriTemplate = "AddToQueueRequests",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus_WS AddToQueueRequests(QueueRequest_WS Request);


		[WebInvoke(Method = "POST",
			UriTemplate = "UpdateRequests",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus_WS UpdateRequests(UpdateRequest_WS Request);

		[WebInvoke(Method = "POST",
			UriTemplate = "UpdateSsvRequestStartStopDates",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus<string, SubmittedRequestRowResponse> UpdateSsvRequestStartStopDates(List<RequestDate_WS> requestDataList);

		[WebInvoke(Method = "POST",
			UriTemplate = "UpdateMonitoringRequestStartStopDates",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus<string, MonitoringRequestDateResponse> UpdateMonitoringRequestStartStopDates(List<MonitoringRequestDate_WS> requestDataList);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetProjectDetailsForInitiateRequest?projectId={projectId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ProjectInfo_WS GetProjectDetailsForInitiateRequest(int projectId);

		[WebInvoke(Method = "POST",
			UriTemplate = "RequestCount",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		RequestCount RequestCount();

		[WebInvoke(Method = "POST",
			UriTemplate = "GetSiteDetails",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<SiteInfo_WS> GetSiteDetails(RequestDetails_WS RequestDetails);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetInitiateRequestInfo",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateRequest_WS GetInitiateRequestInfo(int projectId);

		[WebInvoke(Method = "POST",
			UriTemplate = "ReconnectToPpmDate",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		RequestSaveDateResponse ReconnectToPpmDate(int requestId, string column);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetAssignedRegions",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		string GetAssignedRegions(int projectId);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetRegionCountryByRequestId",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		string GetRegionCountryByRequestId(int requestId, int projectId);

		[WebInvoke(Method = "POST",
			UriTemplate = "saveEditRequest",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EditRequestStatus_WS saveEditRequest(EditRequest_WS modifiedRequest);

		[WebInvoke(Method = "POST",
			UriTemplate = "IsRequestValid",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<string> IsRequestValid(int requestId, bool getAlertForReadOnly, RmPageLink_E rmPageLink);

		//RMK : Added to get the page manager name
		[WebInvoke(Method = "POST", UriTemplate = "GetPageManagerTypeName",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		PageManager_WS GetPageManagerTypeName(int resourceTypeId, bool isProposalRequest);
		//KGS:12765
		[WebInvoke(Method = "GET",
		 UriTemplate = "GetAllOrganizationOrganizationalUnitRRTListForUser?projectId={projectId}&forMultiInit={forMultiInit}",
		 BodyStyle = WebMessageBodyStyle.Bare,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<OrganizationKVList_WS> GetAllOrganizationOrganizationalUnitRRTListForUser(int projectId, bool forMultiInit);

		//GS : Added to get OrganizationUnitSuffix List
		[WebInvoke(Method = "GET",
			 UriTemplate = "GetOrganizationalUnitSuffixList",
			 BodyStyle = WebMessageBodyStyle.Bare,
			 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<OrganizationSuffix_WS> GetOrganizationalUnitSuffixList();

		[WebInvoke(Method = "POST",
				UriTemplate = "SaveResourceType",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		Response_WS SaveResourceType(NewResourceType_WS newResourceType);

		[WebInvoke(Method = "GET",
	UriTemplate = "GetResourceRequestTypeDetails?resourceRequestTypeId={resourceRequestTypeId}",
	BodyStyle = WebMessageBodyStyle.Bare,
	ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<ResourceRequestType_WS> GetResourceRequestTypeDetails(int resourceRequestTypeId);

		//SS : Added to get Default start and stop milestone Id and name
		[WebInvoke(Method = "GET",
			 UriTemplate = "GetDefaultMilestoneData",
			 BodyStyle = WebMessageBodyStyle.Bare,
			 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<DefaultProjectMilestone_WS> GetDefaultMilestoneData();

		[WebInvoke(Method = "POST",
					UriTemplate = "GetGenericResourceTypes",
					BodyStyle = WebMessageBodyStyle.WrappedRequest,
					RequestFormat = WebMessageFormat.Json,
					ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<ResourceTypeRowData, GridSearchResourceTypes_WS, GridRowCommonData> GetGenericResourceTypes(GridSearchResourceTypes_WS gridSearch);

		//SS:To get all regions for Multiple utilization
		[WebInvoke(Method = "GET",
			UriTemplate = "GetAllRegions",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		string GetAllRegions();

		//SS:To get all subregions for Multiple utilization
		[WebInvoke(Method = "GET",
			UriTemplate = "GetAllSubRegionsByRegion?regionIds={regionIds}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		string GetAllSubRegionsByRegion(string regionIds);

		//SS:To get all countries for Multiple utilization
		[WebInvoke(Method = "GET",
			UriTemplate = "GetAllCountriesBySubRegion?subRegionIds={subRegionIds}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		string GetAllCountriesBySubRegion(string subRegionIds);

		[WebInvoke(Method = "POST",
						UriTemplate = "UpdateMultipleRequests",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EditMultipleRequestStatus_WS UpdateMultipleRequests(EditMultipleRequest_WS requestCommonData);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetPhaseCalculatorsByResourceTypeId?resourceType={resourceType}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetPhaseCalculatorsByResourceTypeId(ResourceTypeName resourceType);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetRegionalPhaseCalculatorsByResourceTypeId?resourceType={resourceType}&regionId={regionId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		InitiateCalculator_WS GetRegionalPhaseCalculatorsByResourceTypeId(ResourceTypeName resourceType, int regionId);

		[WebInvoke(Method = "POST",
						UriTemplate = "CheckGenericRequestStageCount",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ValidationAndExecutionStatus_WS CheckGenericRequestStageCount(List<int> requestIds);

		[WebInvoke(Method = "POST",
						UriTemplate = "CheckRequestValidity",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<string> CheckRequestValidity(List<int> requestIdList);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetSpecialOpenRequests",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<ResourcingWorklistRequestRowData, models.Request, RequestCommonData> GetSpecialOpenRequests(GridSearchByGroupId_WS gridSearch);

		[WebInvoke(Method = "POST",
			UriTemplate = "AssignToJapan",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<BookingRequestResult_WS> AssignToJapan(List<int> requestIds);

		[WebInvoke(Method = "POST",
				UriTemplate = "GetAutogeneratedFromProposalRequests",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<AwardedProposalRequestRowData, models.Request, RequestCommonData> GetAutogeneratedFromProposalRequests(GridSearchRequest_WS gridSearch);

		[WebInvoke(Method = "POST",
			UriTemplate = "SubmitAndAssignToProposalResource",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ServiceExecutionStatus_WS> SubmitAndAssignToProposalResource(List<int> requestIds);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetReadonlyNotes",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ReadonlyNotesResponse_WS> GetReadonlyNotes(List<ReadonlyNotes_WS> requestIds);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetAssignedRequestScheduleByResourceId",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ReqSched_WS GetAssignedRequestScheduleByResourceId(int resourceId);

		[WebInvoke(UriTemplate = "GetProjectBookingsByRequestIdListAndResorceId",
			Method = "POST",
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json,
			BodyStyle = WebMessageBodyStyle.WrappedRequest)]
		[OperationContract]
		BookingDetailcontainer_WS GetProjectBookingsByRequestIdListAndResorceId(int resourceId, List<int> requestIdList);

		[WebInvoke(UriTemplate = "GetProgramBookingsByRequestIdListAndResorceId",
			Method = "POST",
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json,
			BodyStyle = WebMessageBodyStyle.WrappedRequest)]
		[OperationContract]
		BookingDetailcontainer_WS GetProgramBookingsByRequestIdListAndResorceId(int resourceId, List<int> requestIdList);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<OptionItem_WS> GetCountriesFromSiteAddressByProjectId(int projectId);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetResourceTypeCustomFieldsByResourceType",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ResourceTypeCustomFields_WS> GetResourceTypeCustomFieldsByResourceType(int requestId, int resourceTypeId, int projectId);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetConnectedMilestoneDetailsFromDb",
		BodyStyle = WebMessageBodyStyle.WrappedRequest,
		ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		PpmConnectedDates_WS GetConnectedMilestoneDetailsFromDb(int resourceTypeId, int projectId, int? countryId);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetRegionConnectedMilestoneDetailsFromDb",
		BodyStyle = WebMessageBodyStyle.WrappedRequest,
		ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		PpmConnectedDates_WS GetRegionConnectedMilestoneDetailsFromDb(int resourceTypeId, int projectId, int? regionId);

		[WebInvoke(Method = "POST",
			UriTemplate = "HardDeleteResourceRequestType",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ResourceTypeDelete_Status HardDeleteResourceRequestType(List<int> resourceTypeIds);

		[WebInvoke(Method = "POST",
						UriTemplate = "SaveAndAssignSplitRequests",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus_WS SaveAndAssignSplitRequests(List<InitiateRequests_WS> requestList);

		[WebInvoke(Method = "POST",
						UriTemplate = "SaveAndAssignSplitRequestsAll",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus_WS SaveAndAssignSplitRequestsAll(List<InitiateRequests_WS> requestList);

		[WebInvoke(Method = "POST",
					UriTemplate = "SaveMultipleInitiateRequests",
					BodyStyle = WebMessageBodyStyle.WrappedRequest,
					RequestFormat = WebMessageFormat.Json,
					ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<AddUpdateInitiateRequestStatus_WS> SaveMultipleInitiateRequests(List<InitiateRequests_WS> requestList);

		[WebInvoke(Method = "POST",
						UriTemplate = "SplitSSVRequests",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EditMultipleRequestStatus_WS SplitSSVRequests(List<SplitSSVRequests_WS> requestList);

		[WebInvoke(Method = "POST",
			UriTemplate = "DeleteBackfill",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ServiceExecutionStatus_WS DeleteBackfill(int requestId, BackfillDeleteOption_E deleteOption);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetCustomFieldDefaultvalues?resourceTypeId={resourceTypeId}&projectId={projectId}&countryId={countryId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<CustomFields> GetCustomFieldDefaultValues(int resourceTypeId, int projectId, int countryId);

		[WebInvoke(Method = "GET",
			UriTemplate = "GetAllComputedReqestMilestoneDaysToAdd",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ComputedRequestMilestoneDays_WS> GetAllComputedReqestMilestoneDaysToAdd();

		[WebInvoke(Method = "GET",
			UriTemplate = "IsProposalReqeustWithQipData?requestId={requestId}",
			BodyStyle = WebMessageBodyStyle.Bare,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		bool IsProposalReqeustWithQipData(int requestId);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetBusinessDays",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		int GetBusinessDays(string stopDate, int countryId);

		[WebInvoke(Method = "POST",
		UriTemplate = "GetPastRequestsByProjectIdResourceTypeId",
		BodyStyle = WebMessageBodyStyle.WrappedRequest,
		RequestFormat = WebMessageFormat.Json,
		ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<PastRequestsListData, models.Request, RequestCommonData> GetPastRequestsByProjectIdResourceTypeId(PastRequestListGrid_WS gridSearch);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetSoftBookedResourceDetailsByRequestId",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<List<AssignedResourceDetails_WS>> GetSoftBookedResourceDetailsByRequestId(int requestId);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetRequestDetailsByRequestId",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<RequestInfo_WS> GetRequestDetailsByRequestId(int requestId);
	}
}