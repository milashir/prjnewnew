﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Activation;
using System.ServiceModel.Dispatcher;
using System.Text;
using Castle.ActiveRecord;
using Newtonsoft.Json;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.Domain.Models.ResourceMatching;
using Quintiles.RM.Clinical.Domain.Notification;
using Quintiles.RM.Clinical.Domain.Properties;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.SharePoint.ViewModels;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint
{
	//[BasicHttpBindingServiceMetadataExchangeEndpoint]
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
	public class Request : IRequest, IErrorHandler
	{
		#region Search
		public JqGridData<ResourceSearchRowData, ResourceResult, ResourceSearchCommonData, ResourceSearchGridCommonData> Search(SearchCriteria_WS searchCriteria)
		{
			JqGridData<ResourceSearchRowData, ResourceResult, ResourceSearchCommonData, ResourceSearchGridCommonData> result;
			try
			{
				SearchService searchService = new SearchService(searchCriteria, GraphContext.Search, false);
				int startMonthYear = searchService.ResultSet.StartSched;
				int endMonthYear = searchService.ResultSet.EndSched;

				GetMinMaxMonthYearNumbers(searchService.ResultSet, out startMonthYear, out endMonthYear);

				var pr = new PagedResponse<ResourceResult, ResourceSearchCommonData>
				{
					TotalPages = 1,
					Records = searchService.ResultSet.TopNAvailable().Select(kvp => kvp.Value).ToList(),
					AdditionalData = new ResourceSearchCommonData(searchService.ResultSet.TotalPossibleHits, searchService.CriteriaMap, startMonthYear, endMonthYear)
				};

				MapProjectProgramAssignmentIndicattors(pr, Resource.GetProjectAndProgramAssignmentStatusByRequestAndResourceIds(searchCriteria.requestsIds.ToList(), pr.Records.Select(r => r.ResourceId).ToList()));
				MapProjectFireWallIndicattors(pr, Resource.GetProjectFireWallStatusByProjectAndResourceIds(searchCriteria.projectIds.ToList(), pr.Records.Select(r => r.ResourceId).ToList()));
				MapProgramBlindedUnblindedIndicattors(pr, Resource.GetProgramBlindedUnblindedStatusByRequestAndResourceIds(searchCriteria.requestsIds.ToList(), pr.Records.Select(r => r.ResourceId).ToList()));

				pr.TotalRecords = pr.Records.Count();
				pr.PageNumber = pr.TotalRecords == 0 ? 0 : 1;

				var jsClientData = new ResourceSearchGridCommonData(searchService.ResultSet.AvailabilityError,
																														searchService.ResultSet.HardbookedError,
																														startMonthYear,
																														endMonthYear,
																														searchService.ResultSet.TotalMonthlyHours.Values.ToArray(),
																														searchService.ResultSet.TotalMonthlyFTE.Values.ToArray(),
																														new SearchPlan_WS(searchCriteria, searchService));
				result = new JqGridData<ResourceSearchRowData, ResourceResult, ResourceSearchCommonData, ResourceSearchGridCommonData>(pr, jsClientData, ResourceSearchRowData.Create);
				return result;
			}
			catch (TimeoutException)
			{
				throw new Exception(Resources.SearchTimeoutError);
			}
		}

		private void MapProjectProgramAssignmentIndicattors(PagedResponse<ResourceResult, ResourceSearchCommonData> pr, Dictionary<int, ProjectProgramAssignmentStatus> dictionary)
		{
			if (pr != null && pr.Records != null)
			{
				ProjectProgramAssignmentStatus ppa;
				foreach (var resource in pr.Records)
				{
					if (dictionary.TryGetValue(resource.ResourceId, out ppa))
					{
						resource.ProjectMatch = ppa.ProjectMatch;
						resource.ProgramMatch = ppa.ProgramMatch;
					}
				}
			}
		}

		private void MapProjectFireWallIndicattors(PagedResponse<ResourceResult, ResourceSearchCommonData> pr, Dictionary<int, List<ProjectFireWallStatus>> dictionary)
		{
			if (pr != null && pr.Records != null)
			{
				foreach (var resource in pr.Records)
				{
					List<ProjectFireWallStatus> projFireWallStatus = new List<ProjectFireWallStatus>();
					if (dictionary.TryGetValue(resource.ResourceId, out projFireWallStatus))
					{
						resource.ResourceFireWalled = true;
						resource.ResourceFireWalledDetailsHtml = "<div id=&#39tttextdiv&#39 class=&#39firewallHoverTextPosition&#39>" + "<div class=&#39tttextdivrow&#39 ><div class=&#39divcellhead&#39>Project Code </div> <div class=&#39divcellhead&#39>Protocol Number</div> <div class=&#39divcellhead&#39>Resource Request Type name</div> <div class=&#39divcellhead&#39>Job Role </div> <div class=&#39divcellhead&#39>Earliest request </div> <div class=&#39divcellhead&#39>Latest request  </div></div>";
						foreach (ProjectFireWallStatus pfs in projFireWallStatus)
						{
							resource.ResourceFireWalledDetailsHtml += "<div class=&#39tttextdivrow&#39 > <div class=&#39divcell&#39>" + pfs.ProjectCode + "</div><div class=&#39divcell&#39>" + pfs.ProtocolNumber + "</div><div class=&#39divcell&#39>" + pfs.ResourceTypeName + "</div><div class=&#39divcell&#39>" + pfs.JobRoleName + "</div><div class=&#39divcell&#39>" + pfs.StartDate + "</div><div class=&#39divcell&#39>" + pfs.StopDate + "</div> </div>";
						}
						resource.ResourceFireWalledDetailsHtml += "</div>";
					}
				}
			}
		}


		private void MapProgramBlindedUnblindedIndicattors(PagedResponse<ResourceResult, ResourceSearchCommonData> pr, Dictionary<int, ProgramStudyStatus> dictionary)
		{
			if (pr != null && pr.Records != null)
			{
				ProgramStudyStatus pss;
				foreach (var resource in pr.Records)
				{
					if (dictionary.TryGetValue(resource.ResourceId, out pss))
					{
						resource.ProgramUnblinded = pss.ProgramUnblinded;
					}
				}
			}
		}

		private void GetMinMaxMonthYearNumbers(ResourceResultSet resourceResultSet, out int minStartMonthYear, out int maxStopYearMonth)
		{
			minStartMonthYear = int.MaxValue;
			maxStopYearMonth = 0;

			#region Find out min max month year numbers with non zero hours
			foreach (var schedule in resourceResultSet.ReqToMatch.ReqMonthlyHours)
			{
				var minMy = schedule.Value.MonthYears.FirstOrDefault(my => my.Value.RequiredHours != 0);
				if (minMy.Value != null && minMy.Value.MonthNumber < minStartMonthYear)
				{
					minStartMonthYear = minMy.Value.MonthNumber;
				}

				var maxMy = schedule.Value.MonthYears.Reverse().FirstOrDefault(my => my.Value.RequiredHours != 0);
				if (maxMy.Value != null && maxMy.Value.MonthNumber > maxStopYearMonth)
				{
					maxStopYearMonth = maxMy.Value.MonthNumber;
				}
			}
			#endregion
		}

		#endregion

		#region GetResourceSearchQueueItems

		/// <summary>
		/// Build the resource worklist grid.
		/// </summary>
		/// <param name="gridSearch"> </param>
		/// <returns> </returns>
		public JqGridData<ResourcingWorklistRequestRowData, models.Request, RequestCommonData> GetOpenRequestsFromQueue(GridSearchByGroupId_WS gridSearch)
		{
			var pr = new PagedResponse<models.Request, RequestCommonData>();
			pr.TotalPages = 1;
			pr.PageNumber = 1;
			pr.Records = OpenRequestQueue.FindAllRequestsForGrid(gridSearch);
			pr.TotalRecords = pr.Records.Count();
			pr.PageNumber = pr.TotalRecords == 0 ? 0 : 1;

			return new JqGridData<ResourcingWorklistRequestRowData, models.Request, RequestCommonData>(pr, ResourcingWorklistRequestRowData.Create);
		}

		#endregion

		#region AddRequestGroupToQueue

		/// <summary>
		///   Takes a set of ID's in a group of requests and creates OpenRequest Queue rows pertaining to project, requesttype, resourcetype, protocol...
		/// </summary>
		/// <param ColumnName="listOfIds"> </param>
		/// <returns> </returns>
		public AjaxGridResponse AddRequestGroupToQueue(OpenRequestGridData[] idArray)
		{
			AjaxGridResponse myGridResponse = new AjaxGridResponse();
			foreach (OpenRequestGridData rowData in idArray)
			{
				var myResponse = new AjaxGridRowResponse(rowData.rowId, false, string.Empty);
				myGridResponse.Rows.Add(myResponse);

				OpenRequestQueue orq = new OpenRequestQueue
				{
					ProtocolNumber = rowData.protocolNumber,
					Project = new Project { Id = rowData.projectId },
					RequestTypeResourceTypeGroupId = rowData.requestTypeResourceTypeGroupId,
					QId = ExtensionMethods.GetCurrentUserQid(),
					CountryRegionId = rowData.countryRegionId,
					Country = (rowData.countryId == -1) ? null : new Country { Id = rowData.countryId },
					Region = (rowData.regionId == -1) ? null : new Region { Id = rowData.regionId }
				};
				orq.SaveAndFlush();
			}
			return myGridResponse;
		}

		#endregion

		#region RemoveGroupFromQueue

		/// <summary>
		///   Remove an open request grouping from the user's open request queue
		/// </summary>
		/// <param ColumnName="openRequestQueueId"> </param>
		public bool RemoveGroupFromQueue(string listOfIds)
		{
			OpenRequestQueue.DeleteAll(string.Format("OpenRequestQueueId in({0})", listOfIds.Replace("|", ",")));

			return true;
		}

		#endregion

		#region GetResourcingWorklistSummary
		/// <summary>
		/// Get all the requests in the queue for current user
		/// </summary>
		public JqGridData<OpenResourceRequestRowData, OpenRequestQueue, GridRowCommonData> GetResourcingWorklistSummary(GridSearchResourceRequest_WS gridSearch)
		{
			gridSearch.QId = ExtensionMethods.GetCurrentUserQid();
			var pr = new PagedResponse<OpenRequestQueue, GridRowCommonData>();
			pr.TotalPages = 1;
			pr.PageNumber = gridSearch.PageNumber;
			pr.Records = OpenRequestQueue.FindWorkListQueue(gridSearch);
			pr.TotalRecords = pr.Records.Count();
			pr.PageNumber = pr.TotalRecords == 0 ? 0 : 1;

			return new JqGridData<OpenResourceRequestRowData, OpenRequestQueue, GridRowCommonData>(pr, OpenResourceRequestRowData.Create);
		}
		#endregion

		#region GetOpenRequests

		/// <summary>
		///   Get all open requests
		/// </summary>
		public JqGridData<OpenResourceRequestRowData, OpenRequestQueue, GridRowCommonData> GetOpenResourceRequests(GridSearchResourceRequest_WS gridSearch)
		{
			gridSearch.QId = ExtensionMethods.GetCurrentUserQid();
			return new JqGridData<OpenResourceRequestRowData, OpenRequestQueue, GridRowCommonData>(OpenRequestQueue.FindOpenResourceRequestsForGrid(gridSearch), OpenResourceRequestRowData.Create);
		}

		#endregion

		public ServiceExecutionStatus<string, SubmittedRequestRowResponse> UpdateRequestStartStopDates(List<RequestDate_WS> requestDataList)
		{
			var result = new ServiceExecutionStatus<string, SubmittedRequestRowResponse>();

			foreach (var requestData in requestDataList)
			{
				result.EntityStatus.Add(UpdateSingleRequestStartStopDates(requestData));
			}

			return result;
		}

		public EntityExecutionStatus<SubmittedRequestRowResponse> UpdateSingleRequestStartStopDates(RequestDate_WS requestData)
		{
			var result = new EntityExecutionStatus<SubmittedRequestRowResponse> { Output = new SubmittedRequestRowResponse(), EntityId = requestData.Id };

			models.Request request = models.Request.Find(requestData.Id);
			var dates = new models.RequestDates
			{
				Dates = new Dictionary<RequestDateType, string>
				{
					{models.RequestDateType.Start, requestData.StartDate},
					{models.RequestDateType.Stop, requestData.StopDate}
				}
			};

			var validator = request.GetValidationRules(dates, RequestAction_E.UpdateSubmitted, null, null);
			validator.Validate();

			if (!validator.IsValid)
			{
				//Return an error response that the onSuccess callback will handle
				result.Output.RowId = request.Id.ToString();
				result.Output.StopDateQ = request.StopDate.ToQDateString();
				result.Output.StartDateQ = request.StartDate.ToQDateString();
				result.Output.StartDateStatus = (int)request.StartDateStatus;
				result.Output.StopDateStatus = (int)request.StopDateStatus;

				var errorMessages = validator.ErrorMessages;

				if (errorMessages != null)
				{
					foreach (KeyValuePair<ValidationType, string> error in errorMessages)
					{
						var elementName = string.Empty;

						if (error.Key == ValidationType.Start) { elementName = "StartDate"; }
						else if (error.Key == ValidationType.Stop) { elementName = "StopDate"; }

						if (!string.IsNullOrEmpty(elementName))
						{
							result.Errors.Add(
									new ValidationMessage_WS(Common.GetGridElementSelector(request.Id.ToString(), elementName), error.Value,
																					 MessageType_E.Error));
						}
						else
						{
							result.Errors.Add(new ValidationMessage_WS("", error.Value, MessageType_E.AlertMessage));
						}
					}
				}
			}
			else
			{
				request.SetStartAndNeedByDate(Common.GetDateTime(requestData.StartDate, true));
				request.StopDate = Common.GetDateTime(requestData.StopDate, true);

				//Change only start and stop dates. Leave other dates and status as it is
				RequestViewService.SetDateStatuses(request, true);

				if (request.ResourceTypeId == (int)ResourceTypeName.Co_monitoring || request.ResourceTypeId == (int)ResourceTypeName.Co_monitoring_NonSiteSpecific || request.ResourceTypeId == (int)ResourceTypeName.Non_Standard_Monitoring_NonSiteSpecific)
				{
					var assignedResource = ResourceRequestAssignment.GetAssignedResourceByRequestId(request.Id);
					var jobRoleIdForFteCalculation = assignedResource != null ? assignedResource.PrimaryJobRoleId.GetValueOrDefault() : request.ResourceType.JobRole.Id;
					var countryIdForFteCalculation = assignedResource != null ? assignedResource.CountryId.GetValueOrDefault() : request.CountryId.GetValueOrDefault();
					request.TotalHours = models.Request.calculateTotalHours(request.ResourceTypeId, countryIdForFteCalculation, request.StartDate.GetValueOrDefault(), request.StopDate.GetValueOrDefault(), request.FTE.GetValueOrDefault(), jobRoleIdForFteCalculation);
				}

				request.SaveAndFlush();

				result.Output.RowId = request.Id.ToString();
				result.Output.StopDateQ = request.StopDate.ToQDateString();
				result.Output.StartDateQ = request.StartDate.ToQDateString();
				result.Output.StartDateStatus = (int)request.StartDateStatus;
				result.Output.StopDateStatus = (int)request.StopDateStatus;
				result.Output.NeedByDateQ = request.NeedByDate.HasValue ? request.NeedByDate.ToQDateString() : string.Empty;

			}
			return result;
		}

		#region ReconnectAndGetRequestDate

		/// <summary>
		///   Don't actually reconnect if forceSave = false - just return a status that looks like we did so we can update the UI
		/// </summary>
		/// <param ColumnName="requestId"> </param>
		/// <param ColumnName="column"> </param>
		/// <param ColumnName="forceSave"> </param>
		/// <returns> </returns>
		public RequestSaveDateResponse ReconnectAndGetRequestDate(int requestId, string column, bool forceSave)
		{
			RequestSaveDateResponse response = new RequestSaveDateResponse { id = requestId };
			RequestViewService.ReconnectDate(response, models.Request.Find(requestId), column, true);
			return response;
		}

		#endregion

		#region GetCalculatorDetails

		public ReadonlyCalculator_WS GetCalculatorDetails(int requestId)
		{
			FTECalculatorViewService FteCalc = new FTECalculatorViewService();
			var fteCalculator = FteCalc.GetFTECalculatorValuesHover(requestId);
			return fteCalculator;
		}

		#endregion,

		#region HardBookResource

		/// <summary>
		///   This is to HardBook a resource from the ResourcingWorklist Page.
		/// </summary>
		/// <param name="selectedRequestIds"> </param>
		/// <param name="selectedResources"> </param>
		/// <param name="bidDefenseResult"> </param>
		/// <returns> </returns>
		public List<BookingRequestResult_WS> HardBookResource(List<int> selectedRequestIds, int resourceId, BidDefenseReason_WS bidDefenseResult, bool validateFirewalledProject)
		{
			var bookingResult = new List<BookingRequestResult_WS>();

			var allFirewallConflicts = new List<ProjectResourceFireWalledProjects_Ws>();
			if (validateFirewalledProject)
			{
				allFirewallConflicts = models.Request.ValidateFireWalledProject(selectedRequestIds, new List<int>(new int[] { resourceId }));
			}

			foreach (var requestId in selectedRequestIds)
			{
				try
				{
					if (models.Request.HasResourceRequestFireWalledProjectWarning(resourceId, requestId, false, allFirewallConflicts, Resources.ResourceTypeFireWalled, out string message))
					{
						bookingResult.Add(new BookingRequestResult_WS
						{
							RequestId = requestId,
							ResourceId = resourceId,
							Status = false,
							Message = message
						});
					}
					else
					{
						var status = ResourceRequestAssignment.HardBook(requestId, resourceId, true, bidDefenseResult, out message);
						bookingResult.Add(new BookingRequestResult_WS
						{
							RequestId = requestId,
							ResourceId = resourceId,
							Status = status,
							Message = message
						});
					}
				}
				catch (Exception ex)
				{
					bookingResult.Add(new BookingRequestResult_WS { RequestId = requestId, ResourceId = resourceId, Status = false, Message = ex.Message });
				}
			}

			return bookingResult;
		}
		#endregion

		#region SoftBookResource

		/// <summary>
		///   This Method is used to Softbook Requests against Resources.
		/// </summary>
		/// <param name="selectedRequestIds"> </param>
		/// <param name="selectedResources"> </param>
		/// <returns> </returns>
		public List<BookingRequestResult_WS> SoftBookResource(List<int> selectedRequestIds, List<int> selectedResources, bool validateFirewalledProject)
		{
			var bookingResult = new List<BookingRequestResult_WS>();
			var allFirewallConflicts = new List<ProjectResourceFireWalledProjects_Ws>();

			if (validateFirewalledProject)
			{
				allFirewallConflicts = models.Request.ValidateFireWalledProject(selectedRequestIds, selectedResources);
			}

			foreach (var resourceId in selectedResources)
			{
				foreach (var requestId in selectedRequestIds)
				{
					try
					{
						if (models.Request.HasResourceRequestFireWalledProjectWarning(resourceId, requestId, true, allFirewallConflicts, Resources.ResourceTypeFireWalled, out string message))
						{
							bookingResult.Add(new BookingRequestResult_WS
							{
								RequestId = requestId,
								ResourceId = resourceId,
								Status = false,
								Message = message
							});
						}
						else
						{
							var status = ResourceRequestAssignment.SoftBook(requestId, resourceId, true, out message);
							bookingResult.Add(new BookingRequestResult_WS
							{
								RequestId = requestId,
								ResourceId = resourceId,
								Status = status,
								Message = message
							});
						}
					}
					catch (Exception ex)
					{
						bookingResult.Add(new BookingRequestResult_WS { RequestId = requestId, ResourceId = resourceId, Status = false, Message = ex.Message });
					}
				}
			}

			return bookingResult;
		}

		#endregion

		#region SaveReturnRequest

		public List<BookingRequestResult_WS> SaveReturnRequest(List<int> requestIds, string description, int reasonId,
																														 string comment, int? sendQueryTo)
		{
			return models.Request.ReturnRequests(requestIds, description, reasonId, comment, sendQueryTo: sendQueryTo);
		}

		#endregion

		#region RemoveSoftBooking

		public List<ServiceExecutionStatus_WS> RemoveSoftBookings(List<int> selectedSoftBookingIds, string rejectedNotes)
		{
			List<ServiceExecutionStatus_WS> executionStatus = new List<ServiceExecutionStatus_WS>();
			List<int> updatedRequests = new List<int>();

			DetachedCriteria criteria = DetachedCriteria.For(typeof(ResourceRequestAssignment));
			criteria.Add(Restrictions.In("Id", selectedSoftBookingIds.ToArray()));
			var matchingSoftBookings = ResourceRequestAssignment.FindAll(criteria);

			foreach (var softBooking in matchingSoftBookings)
			{
				try
				{
					if (softBooking.Request.IsDeleted && softBooking.Request.ProjectProtocolSite.IsSiteDeleted)
					{
						executionStatus.Add(new ServiceExecutionStatus_WS(false, Resources.SiteNotActive, softBooking.Id));
					}
					else if (softBooking.Request.IsHardBooked)
					{
						executionStatus.Add(new ServiceExecutionStatus_WS(false, Resources.RequestAlreadyHardBooked, softBooking.Id));
					}
					else
					{
						selectedSoftBookingIds.Remove(softBooking.Id);
						if (!string.IsNullOrEmpty(rejectedNotes))
						{
							#region Add notes on resource and request

							softBooking.WasBookingRejected = true;
							StringBuilder sb = new StringBuilder("<div>");
							sb.AppendFormat("<b>Resource Name: </b>{0}", softBooking.Resource.Name);
							sb.AppendFormat("<br /><b>Notes: </b>{0}</div>", rejectedNotes);
							softBooking.SaveAndFlush();

							softBooking.Request.CreateComment(sb.ToString(), CommentTypeName.RejectedSoftBook).SaveAndFlush();
							softBooking.Resource.CreateComment(sb.ToString(), CommentTypeName.RejectedSoftBook).SaveAndFlush();

							#endregion
						}
						else
						{
							softBooking.DeleteAndFlush();
						}
						executionStatus.Add(new ServiceExecutionStatus_WS(true, "", softBooking.Id));
						if (!updatedRequests.Contains(softBooking.Request.Id))
						{
							updatedRequests.Add(softBooking.Request.Id);
						}
					}
				}
				catch (Exception ex)
				{
					executionStatus.Add(new ServiceExecutionStatus_WS(false, ex.StackTrace, softBooking.Id));
				}
			}

			foreach (var missingId in selectedSoftBookingIds)
			{
				executionStatus.Add(new ServiceExecutionStatus_WS(false, Resources.SoftBookingNoLongerAvailable, missingId));
			}

			if (updatedRequests.Count > 0)
			{
				List<int> changeToSubmittedIds = new List<int>();
				criteria = DetachedCriteria.For(typeof(ResourceRequestAssignment));
				criteria.Add(Restrictions.In("Request.Id", updatedRequests.ToArray()));

				var softBookings = ResourceRequestAssignment.FindAll(criteria);
				if (softBookings != null)
				{
					foreach (var requestId in updatedRequests)
					{
						models.ResourceRequestAssignment r = softBookings.FirstOrDefault(b => b.Request.Id == requestId);
						if (r == null)
						{
							changeToSubmittedIds.Add(requestId);
						}
					}

					if (changeToSubmittedIds.Count > 0)
					{
						criteria = DetachedCriteria.For(typeof(models.Request));
						criteria.Add(Restrictions.In("Id", changeToSubmittedIds.ToArray()));
						var requestList = models.Request.FindAll(criteria);
						foreach (var request in requestList)
						{
							request.RequestStatusId = (int)RequestStatusName.Submitted;
							request.SaveAndFlush(EventType_E.RequestRemovedLastSoftBooking, Process_E.UIEvent);
						}
					}
				}
			}

			return executionStatus;
		}

		#endregion

		#region AcceptSoftBooking

		public ServiceExecutionStatus_WS AcceptSoftBooking(int resourceRequestAssignmentId, BidDefenseReason_WS bidDefenseResult)
		{
			ServiceExecutionStatus_WS executionStatus = null;
			try
			{
				ResourceRequestAssignment resourceRequestAssignment = ResourceRequestAssignment.FindOneById(resourceRequestAssignmentId);
				if (resourceRequestAssignment != null)
				{
					string message = string.Empty;
					bool isSuccessful = false;
					try
					{
						isSuccessful = ResourceRequestAssignment.HardBook(resourceRequestAssignment.Request.Id,
																																resourceRequestAssignment.Resource.Id, false, bidDefenseResult,
																																out message);
						executionStatus = new ServiceExecutionStatus_WS(isSuccessful, message, resourceRequestAssignmentId);
					}
					catch (Exception ex)
					{
						executionStatus = new ServiceExecutionStatus_WS(false, ex.StackTrace, resourceRequestAssignmentId);
					}
				}
			}
			catch (Castle.ActiveRecord.NotFoundException)
			{
				executionStatus = new ServiceExecutionStatus_WS(false, Resources.SoftBookingNoLongerAvailable, resourceRequestAssignmentId);
			}
			return executionStatus;
		}

		#endregion

		#region GetRequestSchedule
		/// <summary>
		///   Create a Calendar for a list of Requests
		/// </summary>
		/// <param name="reqID"> </param>
		/// <param name="isExecPathRequired">Generates tracing information for the graph </param>
		/// <param name="graphContext">Client can control the graph context. WILL BE HONORED ONLY WHEN isExecPathRequired =true.  </param>
		/// <returns> Calendar by Request </returns>
		public ReqSched_WS GetRequestSchedule(List<int> reqID, bool isExecPathRequired, int graphContext)
		{
			return GetRequestScheduleInternal(reqID, isExecPathRequired, isExecPathRequired ? (GraphContext)graphContext : GraphContext.Request, true, true);
		}

		private ReqSched_WS GetRequestScheduleInternal(List<int> reqID, bool isExecPathRequired, GraphContext graphContext, bool removeZeroHourMonths, bool validateRequests)
		{
			Dictionary<int, string> requestValidationErrors = null;
			var validationErrorCount = 0;
			if (validateRequests)
			{
				requestValidationErrors = models.Request.ValidateRequests(reqID);
				validationErrorCount = requestValidationErrors == null ? 0 : requestValidationErrors.Count;

				foreach (var requestId in requestValidationErrors.Keys)
				{
					reqID.Remove(requestId);
				}
			}
			RequestScheduler reqSched = new RequestScheduler(new SchedulerService(graphContext), new RmCacheService(), true, null, null, true, graphContext);

			#region **********Log Execution Path**********
			reqSched.IsExecutionPathRequired = isExecPathRequired;
			StringBuilder sb = new StringBuilder(2000);
			Action<string> execPathDelegate = msg => sb.Append(msg);//define delegate as an inline lambda and we can use closure to capture the output
			if (isExecPathRequired) { reqSched.LogExecutionPathEvent += execPathDelegate; }
			#endregion

			reqSched.ProcessRequests(reqID);
			reqSched.LogExecutionPathEvent -= execPathDelegate;

			ReqMonthlyHours_WS[] arReqMonthlyHours;
			// Transform result for WS
			arReqMonthlyHours = new ReqMonthlyHours_WS[reqSched.ReqMonthlyHours.Count + reqSched.RequestErrors.Count + validationErrorCount];

			int iRow = 0;
			if (requestValidationErrors != null)
			{
				foreach (var keyVal in requestValidationErrors)
				{
					arReqMonthlyHours[iRow++] = new ReqMonthlyHours_WS { ReqID = keyVal.Key, Error = keyVal.Value };
				}
			}
			foreach (KeyValuePair<int, string> reqError in reqSched.RequestErrors)
			{
				arReqMonthlyHours[iRow++] = new ReqMonthlyHours_WS { ReqID = reqError.Key, Error = reqError.Value };
			}



			int overallMinStartMonthYear = Constants.MonthYearNumber_36000;
			int overallMaxStopYearMonth = Constants.MonthYearNumber_0;

			int newMinStartMonthYear;
			int newMaxStopYearMonth;
			GetMinMaxMonthYearNumbers(reqSched.ReqMonthlyHours, out newMinStartMonthYear, out newMaxStopYearMonth);
			foreach (KeyValuePair<int, RequestCalendar> reqMonthlyHour in reqSched.ReqMonthlyHours)
			{
				int countMonth = reqMonthlyHour.Value.MonthYears.Count;
				var arHours = new List<decimal>();
				var arFTE = new List<decimal>();
				var arAverageHours = new List<decimal>();
				var arAverageFTE = new List<decimal>();
				if (removeZeroHourMonths)
				{
					TrimZeroHourMonthsFromBothEnds(reqMonthlyHour, out newMinStartMonthYear, out newMaxStopYearMonth);
				}
				else
				{
					TrimHourByDateRange(reqMonthlyHour, newMinStartMonthYear, newMaxStopYearMonth);
				}
				overallMaxStopYearMonth = overallMaxStopYearMonth < newMaxStopYearMonth ? newMaxStopYearMonth : overallMaxStopYearMonth;
				overallMinStartMonthYear = overallMinStartMonthYear > newMinStartMonthYear ? newMinStartMonthYear : overallMinStartMonthYear;

				foreach (var requestMonthYears in reqMonthlyHour.Value.MonthYears)
				{
					arHours.Add(requestMonthYears.Value.RequiredHours);
					arFTE.Add(requestMonthYears.Value.Fte);
					arAverageHours.Add(requestMonthYears.Value.AverageHours);
					arAverageFTE.Add(requestMonthYears.Value.AverageFte);
				}

				arReqMonthlyHours[iRow++] = new ReqMonthlyHours_WS
				{
					ReqID = reqMonthlyHour.Key,
					Hours = arHours.ToArray(),
					FTE = arFTE.ToArray(),
					StartMonthNumber = newMinStartMonthYear,
					StopMonthNumber = newMaxStopYearMonth,
					AverageFTE = arAverageFTE.ToArray(),
					AverageHours = arAverageHours.ToArray()
				};
			}

			//If we get the default overallminmax dates, use current month to avoid long loop on the browser.
			//Default values indicate that all requests have errors associated and hence there is no schedule to display.
			if (overallMinStartMonthYear == Constants.MonthYearNumber_36000) { overallMinStartMonthYear = DateHelp.DateToMonthNumber(DateTime.Today); }
			if (overallMaxStopYearMonth == Constants.MonthYearNumber_0) { overallMaxStopYearMonth = DateHelp.DateToMonthNumber(DateTime.Today); ; }

			return new ReqSched_WS
			{
				ReqMonthlyHours = arReqMonthlyHours,
				StartMonth = overallMinStartMonthYear,
				EndMonth = overallMaxStopYearMonth,
				DataTable = reqSched.DataTableString,
				ExecutionPath = sb.ToString()
			};
		}

		private void GetMinMaxMonthYearNumbers(Dictionary<int, RequestCalendar> requestCalenderDictionary, out int minStartMonthYear, out int maxStopYearMonth)
		{
			minStartMonthYear = Constants.MonthYearNumber_36000;
			maxStopYearMonth = Constants.MonthYearNumber_0;
			foreach (var requestCalendar in requestCalenderDictionary)
			{
				var minMy = requestCalendar.Value.MonthYears.FirstOrDefault(my => my.Value.Fte != 0);
				if (minMy.Value != null && minMy.Value.MonthNumber < minStartMonthYear)
				{
					minStartMonthYear = minMy.Value.MonthNumber;
				}

				var maxMy = requestCalendar.Value.MonthYears.Reverse().FirstOrDefault(my => my.Value.RequiredHours != 0);
				if (maxMy.Value != null && maxMy.Value.MonthNumber > maxStopYearMonth)
				{
					maxStopYearMonth = maxMy.Value.MonthNumber;
				}
			}
		}

		private void TrimZeroHourMonthsFromBothEnds(KeyValuePair<int, RequestCalendar> requestCalendar, out int minStartMonthYear, out int maxStopYearMonth)
		{
			var minMy = requestCalendar.Value.MonthYears.FirstOrDefault(my => my.Value.RequiredHours > 0);
			minStartMonthYear = (minMy.Value == null) ? 0 : minMy.Value.MonthNumber;

			var maxMy = requestCalendar.Value.MonthYears.LastOrDefault(my => my.Value.RequiredHours > 0);
			maxStopYearMonth = (maxMy.Value == null) ? 0 : maxMy.Value.MonthNumber;

			var allMonthYearNumbers = requestCalendar.Value.MonthYears.Keys.ToArray();
			foreach (var monthYearNumber in allMonthYearNumbers)
			{
				if (monthYearNumber < minStartMonthYear || maxStopYearMonth < monthYearNumber)
				{
					requestCalendar.Value.MonthYears.Remove(monthYearNumber);
				}
			}
		}

		private void TrimHourByDateRange(KeyValuePair<int, RequestCalendar> requestCalendar, int minStartMonthYear, int maxStopYearMonth)
		{
			var allMonthYearNumbers = requestCalendar.Value.MonthYears.Keys.ToArray();
			foreach (var monthYearNumber in allMonthYearNumbers)
			{
				if (monthYearNumber < minStartMonthYear || maxStopYearMonth < monthYearNumber)
				{
					requestCalendar.Value.MonthYears.Remove(monthYearNumber);
				}
			}
			if (allMonthYearNumbers.Length > 0)
			{
				var minMyNumber = allMonthYearNumbers.First();
				var maxMyNumber = allMonthYearNumbers.Last();
				if (minStartMonthYear < minMyNumber)
				{
					for (int currentMyNumber = minStartMonthYear; currentMyNumber < minMyNumber; currentMyNumber++)
					{
						requestCalendar.Value.MonthYears.Add(currentMyNumber, new RequestMonthYear(currentMyNumber));
					}
				}
				if (maxStopYearMonth > maxMyNumber)
				{
					for (int currentMyNumber = maxMyNumber + 1; currentMyNumber <= maxStopYearMonth; currentMyNumber++)
					{
						requestCalendar.Value.MonthYears.Add(currentMyNumber, new RequestMonthYear(currentMyNumber));
					}
				}
			}
		}
		#endregion

		#region DeleteRequests
		public List<ServiceExecutionStatus_WS> DeleteSubmittedRequests(List<int> requestIds)
		{
			return models.Request.DeleteRequests(requestIds);
		}
		#endregion

		#region DeleteRequests
		public ServiceExecutionStatus_WS DeleteBackfillRequest(int requestId, BackfillDeleteOption_E backfillDeleteOption)
		{
			ServiceExecutionStatus_WS response;
			try
			{
				string message;
				var request = models.Request.FindOneById(requestId);
				response = new ServiceExecutionStatus_WS(request.DeleteBackfill(out message, backfillDeleteOption), message, requestId);
				response.ParentRequestId = request.ParentRequestId.GetValueOrDefault();
			}
			catch (Castle.ActiveRecord.NotFoundException)
			{
				response = new ServiceExecutionStatus_WS(false, string.Format("RequestId {0} not found in the system", requestId), requestId);
			}
			return response;
		}
		#endregion
		#region TerminateRequests

		public List<ServiceExecutionStatus_WS> TerminateRequests(List<int> requestIds, string comments)
		{
			return models.Request.CloseRequests(requestIds, comments, null);
		}


		#endregion

		#region ResubmitRequest

		public List<ServiceExecutionStatus_WS> Resubmit(ResubmitRequest_WS resubmitRequest)
		{
			return models.Request.ReSubmitRequests(resubmitRequest.RequestIds, resubmitRequest.Comment);
		}

		#endregion

		#region CreateBackfillRequest
		public ValidationAndExecutionStatus_WS CreateBackfillRequest(BackfillDetail_WS backfillDetail)
		{
			return models.Request.CreateBackfillRequest(backfillDetail, false);
		}
		#endregion

		#region CreateBackfillRequest
		public ValidationAndExecutionStatus_WS CreateBackfillRequestAndAssignResource(BackfillAssignmentDetail_WS backfillDetail)
		{
			return models.Request.CreateBackfillRequestAndAssignResource(backfillDetail);
		}
		#endregion


		#region RenderInitiateCalculator

		/// <summary>
		///   This RenderInitiateCalculator calculates data for Initiatecalulator based on QIP DATA.
		/// </summary>
		/// <param columnName="projectId"> </param>
		/// <param columnName="resourceId"> </param>
		/// <param columnName="id"> </param>
		/// <returns> </returns>
		public InitiateCalculator_WS RenderInitiateCalculator(int projectId, int resourceId, int countryId, int requestId)
		{
			var initiateCalculator = new InitiateCalculator_WS();

			var initiatecalculatorData = FTETypeFTEMileStoneType.FindbyResourceTypeProjectCountry(projectId, resourceId, countryId, requestId);

			var calcForJobGrade = initiatecalculatorData.FirstOrDefault(c => c.JobGrade.HasValue);
			if (calcForJobGrade != null)
			{
				initiateCalculator.JobGrade = calcForJobGrade.JobGrade;
				initiateCalculator.JobGradeInfoStr = calcForJobGrade.JobGradeInfoStr;
			}

			foreach (var calc in initiatecalculatorData)
			{
				initiateCalculator.staticInitiateCalculatorList.Add(new StaticInitiateCalculator_WS(calc));

				if (initiateCalculator.CountryId == -1 && initiateCalculator.RegionId == -1)
				{
					initiateCalculator.CountryId = calc.CountryId;
					initiateCalculator.RegionId = calc.RegionId;
				}

				long? timestamp = calc.QipTimestamp.HasValue ? calc.QipTimestamp.GetValueOrDefault().Ticks : (long?)null;
				var requestCalculatorTimestamp = calc.RequestCalculatorTimestamp.HasValue ? calc.RequestCalculatorTimestamp.GetValueOrDefault().Ticks : (long?)null;
				initiateCalculator.StaticInitiateCalcTimestamp.Add(new CalculatorTimestamp(timestamp, calc.QipId, requestCalculatorTimestamp, calc.RequestCalculatorId, calc.FTEType.Id));
			}

			return initiateCalculator;
		}

		#endregion
		public InitiateCalculator_WS RenderRegionBasedInitiateCalculator(int projectId, int resourceId, int regionId, int requestId, string requestStartDate, string requestStopDate)
		{
			var initiateCalculator = new InitiateCalculator_WS();

			var initiatecalculatorData = FteTypeFteMileStoneTypeRegion.FindbyResourceTypeProjectRegion(projectId, resourceId, regionId, requestId, requestStartDate.ToDateFromQDateString(), requestStopDate.ToDateFromQDateString());

			var calcForJobGrade = initiatecalculatorData.FirstOrDefault(c => c.JobGrade.HasValue);
			if (calcForJobGrade != null)
			{
				initiateCalculator.JobGrade = calcForJobGrade.JobGrade;
				initiateCalculator.JobGradeInfoStr = calcForJobGrade.JobGradeInfoStr;
			}

			foreach (var calc in initiatecalculatorData)
			{
				initiateCalculator.staticInitiateCalculatorList.Add(new StaticInitiateCalculator_WS(calc));

				if (initiateCalculator.CountryId == -1 && initiateCalculator.RegionId == -1)
				{
					initiateCalculator.CountryId = calc.CountryId;
					initiateCalculator.RegionId = calc.RegionId;
				}

				long? timestamp = calc.QipTimestamp.HasValue ? calc.QipTimestamp.GetValueOrDefault().Ticks : (long?)null;
				var requestCalculatorTimestamp = calc.RequestCalculatorTimestamp.HasValue ? calc.RequestCalculatorTimestamp.GetValueOrDefault().Ticks : (long?)null;
				initiateCalculator.StaticInitiateCalcTimestamp.Add(new CalculatorTimestamp(timestamp, calc.QipId, requestCalculatorTimestamp, calc.RequestCalculatorId, calc.FTEType.Id));
			}

			return initiateCalculator;
		}
		public InitiateCalculator_WS RenderGlobalInitiateCalculator(int projectId, int resourceTypeId, int organizationId, int requestId, string requestStartDate, string requestStopDate)
		{
			var initiateCalculator = new InitiateCalculator_WS();

			var initiatecalculatorData = FTETypeFTEMileStoneType.FindGlobalbyResourceTypeProjectOrganizationId(projectId, resourceTypeId, organizationId, requestId, requestStartDate.ToDateFromQDateString(), requestStopDate.ToDateFromQDateString());

			var calcForJobGrade = initiatecalculatorData.FirstOrDefault(c => c.JobGrade.HasValue);
			if (calcForJobGrade != null)
			{
				initiateCalculator.JobGrade = calcForJobGrade.JobGrade;
				initiateCalculator.JobGradeInfoStr = calcForJobGrade.JobGradeInfoStr;
			}

			foreach (var calc in initiatecalculatorData)
			{
				initiateCalculator.staticInitiateCalculatorList.Add(new StaticInitiateCalculator_WS(calc));

				long? timestamp = calc.QipTimestamp.HasValue ? calc.QipTimestamp.GetValueOrDefault().Ticks : (long?)null;
				var requestCalculatorTimestamp = calc.RequestCalculatorTimestamp.HasValue ? calc.RequestCalculatorTimestamp.GetValueOrDefault().Ticks : (long?)null;
				initiateCalculator.StaticInitiateCalcTimestamp.Add(new CalculatorTimestamp(timestamp, calc.QipId, requestCalculatorTimestamp, calc.RequestCalculatorId, calc.FTEType.Id));
			}

			return initiateCalculator;
		}
		#region GetInitiateCalculatorbyRequest

		/// <summary>
		///   This GetInitiateCalculatorbyRequest is to get the data from Initiatecalculator and AdhocInitiateCalculator based on the requestId.
		/// </summary>
		/// <param columnName="requestId"> </param>
		/// <returns> </returns>
		public InitiateCalculator_WS GetInitiateCalculatorbyRequest(int requestId)
		{
			return InitiateRequestsService.GetCalculatorByRequestId(requestId, false, null, null);
		}

		/// <summary>
		///   To get the Calculator values
		/// </summary>
		/// <param columnName="requestId"> </param>
		/// <returns> </returns>
		public InitiateCalculator_WS GetCalculatorsByRequestId(int requestId)
		{
			return InitiateRequestsService.GetCalculatorsByRequestId(requestId);
		}

		#endregion#endregion
		public InitiateCalculator_WS GetRegionBasedInitiateCalculatorbyRequest(int requestId, int regionId)
		{
			return InitiateRequestsService.GetCalculatorByRequestId(requestId, true, regionId, null);
		}

		public InitiateCalculator_WS GetGlobalInitiateCalculatorbyRequest(int requestId, int organizationId)
		{
			return InitiateRequestsService.GetCalculatorByRequestId(requestId, false, null, organizationId);
		}
		#region GetGenericInitiateCalculatorbyRequest

		/// <summary>
		///   This GetGenericInitiateCalculatorbyRequest is to get the data from GenericInitiatecalculator and AdhocInitiateCalculator based on the requestId and projectid.
		/// </summary>
		/// <param columnName="requestId"> </param>
		/// <returns> </returns>
		public InitiateCalculator_WS GetGenericInitiateCalculatorbyRequest(int requestId)
		{
			return InitiateRequestsService.GetGenericCalculatorbyRequest(requestId);
		}

		/// <summary>
		///   This GetDefaultGenericCalculatorsByResourceTypeId is to get the data from GenericInitiatecalculator and AdhocInitiateCalculator based on the resourceId.
		/// </summary>
		/// <param columnName="requestId"> </param>
		/// <returns> </returns>
		public InitiateCalculator_WS GetDefaultGenericCalculatorsByResourceTypeId(int resourceTypeId, int countryId)
		{
			return InitiateRequestsService.GetDefaultGenericCalculatorsByResourceTypeId(resourceTypeId, countryId);
		}

		#endregion#endregion

		#region CalculateWeeklyHourFTE

		public decimal CalculateWeeklyHourFTE(int countryId, int resourceId, decimal modifiedWeeklyHoursFTE, string type, int jobRoleId)
		{
			return type == "WH"
							? models.InitiateCalculator.WeeklyHoursToFTE(countryId, resourceId, modifiedWeeklyHoursFTE, jobRoleId)
							: models.InitiateCalculator.FteToWeeklyHours(countryId, resourceId, modifiedWeeklyHoursFTE, jobRoleId);
		}

		#endregion
		public decimal CalculateRegionalFte(int regioinId, int resourceId, decimal weeklyHours, int resourceCountryId, int jobRoleId)
		{
			return models.InitiateCalculator.RegionalWeeklyHoursToFte(regioinId, resourceId, weeklyHours, resourceCountryId, jobRoleId);
		}
		public decimal CalculateRegionalWeeklyHours(int regionId, int resourceId, decimal fte, int resourceCountryId, int jobRoleId)
		{
			return models.InitiateCalculator.RegionalFteToWeeklyHours(regionId, resourceId, fte, resourceCountryId, jobRoleId);
		}

		public decimal CalculateGlobalFte(int organizationId, int resourceTypeId, decimal weeklyHours, int resourceCountryId, int jobRoleId)
		{
			return models.InitiateCalculator.GlobalWeeklyHoursToFte(organizationId, resourceTypeId, weeklyHours, resourceCountryId, jobRoleId);
		}
		public decimal CalculateGlobalWeeklyHours(int organizationId, int resourceTypeId, decimal fte, int resourceCountryId, int jobRoleId)
		{
			return models.InitiateCalculator.GlobalFteToWeeklyHours(organizationId, resourceTypeId, fte, resourceCountryId, jobRoleId);
		}
		#region GetUnsubmittedSsvRequests
		public JqGridData<SsvRequestRowData, models.Request, RequestCommonData> GetUnsubmittedSsvRequests(GridSearchRequest_WS gridSearch)
		{
			return new JqGridData<SsvRequestRowData, models.Request, RequestCommonData>(models.Request.FindAllPagedRequests(gridSearch), SsvRequestRowData.Create);
		}
		#endregion

		#region GetUnsubmittedPermanentRequests
		public JqGridData<MonitoringRequestRowData, models.Request, RequestCommonData> GetUnsubmittedPermanentRequests(GridSearchRequest_WS gridSearch)
		{
			return new JqGridData<MonitoringRequestRowData, models.Request, RequestCommonData>(models.Request.FindAllPagedRequests(gridSearch), MonitoringRequestRowData.Create);
		}
		#endregion

		#region GetAllInitiateRequests
		public JqGridData<InitiateRequestRowData, models.Request, RequestCommonData> GetAllInitiateRequests(GridSearchRequest_WS gridSearch)
		{
			gridSearch.RmPageLink = RmPageLink_E.InitiateNewRequests;
			gridSearch.QId = ExtensionMethods.GetCurrentUserQid();
			return new JqGridData<InitiateRequestRowData, models.Request, RequestCommonData>(models.Request.FindAllPagedRequests(gridSearch), InitiateRequestRowData.Create);
		}
		public JqGridData<AwardedProposalRequestRowData, models.Request, RequestCommonData> GetAutogeneratedFromProposalRequests(GridSearchRequest_WS gridSearch)
		{
			gridSearch.RmPageLink = RmPageLink_E.AwardedProposalRequest;
			return new JqGridData<AwardedProposalRequestRowData, models.Request, RequestCommonData>(models.Request.FindAllPagedRequests(gridSearch), AwardedProposalRequestRowData.Create);
		}

		public List<CountryRegions_WS> GetCountryRegions(string countryIds)
		{
			return models.CountryRegion.getCountryRegions(countryIds);
		}

		public List<CountryRegions_WS> GetCountryRegionCountryName(string countryIds)
		{
			return models.CountryRegion.GetCountryRegionCountryName(countryIds);
		}

		public List<int> GetDistinctCountryIds()
		{
			return CountryRegion.GetDistinctCountryIds();
		}

		#endregion

		#region GetSubmittedRequests
		/// <summary>
		///   Only return requests that have an Open Request (i.ex. Submitted)
		/// </summary>
		public JqGridData<SubmittedRequestRowData, models.Request, RequestCommonData> GetSubmittedRequests(GridSearchRequest_WS gridSearch)
		{
			return new JqGridData<SubmittedRequestRowData, models.Request, RequestCommonData>(models.Request.FindAllPagedRequests(gridSearch), SubmittedRequestRowData.Create);
		}
		#endregion

		#region GetSoftBookingList
		public JqGridData<SoftBookedRequestRowData, ResourceRequestAssignment, RequestCommonData> GetSoftBookingList(GridSearchRequestAssignment_WS gridSearch)
		{
			gridSearch.Qid = ExtensionMethods.GetCurrentUserQid();
			return new JqGridData<SoftBookedRequestRowData, ResourceRequestAssignment, RequestCommonData>(ResourceRequestAssignment.FindPendingRequests(gridSearch), SoftBookedRequestRowData.Create);
		}

		#endregion

		#region IErrorHandler Members

		public bool HandleError(Exception error)
		{
			throw new NotImplementedException();
		}

		public void ProvideFault(Exception error, System.ServiceModel.Channels.MessageVersion version,
														 ref System.ServiceModel.Channels.Message fault)
		{
			throw new NotImplementedException();
		}

		#endregion

		#region IRequest Members

		public AddUpdateInitiateRequestStatus_WS ValidateAndSaveInitiateRequest(InitiateRequests_WS initiateRequest)
		{
			return InitiateRequestsService.ValidateAndSaveInitiateRequests(initiateRequest, InitiateRequestsService.AddErrorsToResultForSingleInitiate, false);
		}

		public AddUpdateInitiateRequestStatus_WS SubmitInitiateRequestsMigration(int requestId, string rowId)
		{
			return InitiateRequestsService.SubmitInitiateRequestsMigration(requestId, rowId);
		}
		public MilestoneValidation_WS ValidateRequestHasDeactivatedMilestones(string requestIds, string milestoneIds, bool reloadPage, bool validateForAssignedRequest, StringArray DeletedMilestones)
		{
			return InitiateRequestsService.ValidateDeactivatedMilestones(requestIds, milestoneIds, reloadPage, validateForAssignedRequest, DeletedMilestones);
		}
		public AddUpdateInitiateRequestStatus_WS ValidateAndUpdateInitiateRequest(InitiateRequests_WS initiateRequest)
		{
			return InitiateRequestsService.ValidateAndUpdateInitiateRequest(initiateRequest, InitiateRequestsService.AddErrorsToResultForSingleInitiate);
		}

		public List<KeyValue_WS> GetResourceTypeNames(int projectState)
		{
			return ResourceType.GetResourceTypeByProjectName(projectState);
		}

		public List<ServiceExecutionStatus_WS> SubmitRequests(List<int> requestIds)
		{
			return models.Request.SubmitRequests(requestIds, null, false);
		}

		public List<ServiceExecutionStatus_WS> SubmitAndAssignToProposalResource(List<int> requestIds)
		{
			return models.Request.SubmitAndAssignToProposalResource(requestIds);
		}

		public ServiceExecutionStatus_WS AddToQueueRequests(QueueRequest_WS Request)
		{
			return models.Request.AddToQueueRequests(Request);
		}

		public ServiceExecutionStatus_WS UpdateRequests(UpdateRequest_WS Request)
		{
			return models.Request.UpdateRequests(Request);
		}

		public ServiceExecutionStatus<string, SubmittedRequestRowResponse> UpdateSsvRequestStartStopDates(List<RequestDate_WS> requestDataList)
		{
			var result = new ServiceExecutionStatus<string, SubmittedRequestRowResponse>();

			foreach (var requestData in requestDataList)
			{
				result.EntityStatus.Add(UpdateSingleSsvRequestStartStopDates(requestData));
			}

			return result;
		}

		private EntityExecutionStatus<SubmittedRequestRowResponse> UpdateSingleSsvRequestStartStopDates(RequestDate_WS requestData)
		{
			var result = new EntityExecutionStatus<SubmittedRequestRowResponse> { Output = new SubmittedRequestRowResponse(), EntityId = requestData.Id };

			var ssvRequest = models.Request.Find(requestData.Id);
			var ssvAttribute = SSVAttribute.FindByProjectIdCountryId(ssvRequest.Project.Id, ssvRequest.CountryId);

			var dates = new RequestDates()
			{
				Dates = new Dictionary<RequestDateType, string>()
				{
					{RequestDateType.Start, requestData.StartDate},
					{RequestDateType.Stop, requestData.StopDate}
				}
			};
			var validator = ssvRequest.GetValidationRules(dates, RequestAction_E.UpdateNotSubmitted, null, null);
			validator.Validate();

			if (validator.IsValid)
			{
				RequestViewService.SaveStartDate(requestData.StartDate, ssvRequest, ssvAttribute);
				RequestViewService.SaveStopDate(requestData.StopDate, ssvRequest, ssvAttribute);
				ssvRequest.SaveAndFlush();
			}
			else
			{
				foreach (var error in validator.ErrorMessages)
				{
					switch (error.Key)
					{
						case ValidationType.Start:
							result.Errors.Add(new ValidationMessage_WS(Common.GetGridElementSelector(ssvRequest.Id.ToString(), "StartDate"), error.Value, MessageType_E.Error));
							break;
						case ValidationType.Stop:
							result.Errors.Add(new ValidationMessage_WS(Common.GetGridElementSelector(ssvRequest.Id.ToString(), "StopDate"), error.Value, MessageType_E.Error));
							break;
						case ValidationType.CRATraining:
							result.Errors.Add(new ValidationMessage_WS(Common.GetGridElementSelector(ssvRequest.Id.ToString(), "CRADate"), error.Value, MessageType_E.Error));
							break;
						case ValidationType.Country:
						case ValidationType.Project:
							result.Errors.Add(new ValidationMessage_WS(string.Empty, error.Value, MessageType_E.AlertMessage));
							break;
					}
				}
			}

			result.Output.RowId = ssvRequest.Id.ToString();
			result.Output.StopDateQ = ssvRequest.StopDate.ToQDateString();
			result.Output.StartDateQ = ssvRequest.StartDate.ToQDateString();
			result.Output.StartDateStatus = (int)ssvRequest.StartDateStatus;
			result.Output.StopDateStatus = (int)ssvRequest.StopDateStatus;
			result.Output.NeedByDateQ = ssvRequest.NeedByDate.HasValue ? ssvRequest.NeedByDate.ToQDateString() : string.Empty;

			return result;
		}

		public ServiceExecutionStatus<string, MonitoringRequestDateResponse> UpdateMonitoringRequestStartStopDates(List<MonitoringRequestDate_WS> requestDataList)
		{
			var result = new ServiceExecutionStatus<string, MonitoringRequestDateResponse>();

			foreach (var requestData in requestDataList)
			{
				result.EntityStatus.Add(UpdateSingleMonitoringRequestStartStopDates(requestData));
			}

			return result;
		}

		private EntityExecutionStatus<MonitoringRequestDateResponse> UpdateSingleMonitoringRequestStartStopDates(MonitoringRequestDate_WS requestData)
		{
			var result = new EntityExecutionStatus<MonitoringRequestDateResponse> { EntityId = requestData.Id };

			var request = models.Request.Find(requestData.Id);
			ICountryAttribute attribute = MonitoringAttribute.FindByProjectIdCountryId(request.Project.Id, request.CountryId);

			var dates = new RequestDates()
			{
				Dates = new Dictionary<RequestDateType, string>()
				{
		  {RequestDateType.IM, requestData.IMDate},
		  {RequestDateType.CRATraining, requestData.CRADate},
		  {RequestDateType.Start, requestData.StartDate},
		  {RequestDateType.Stop, requestData.StopDate},
		}
			};

			var validator = request.GetValidationRules(dates, RequestAction_E.UpdateNotSubmitted, null, null);
			validator.Validate();

			if (validator.IsValid)
			{
				RequestViewService.SaveCRATrainingDate(requestData.CRADate, request, attribute);
				RequestViewService.SaveIMDate(requestData.IMDate, request, attribute);
				RequestViewService.SaveStartDate(requestData.StartDate, request, attribute);
				RequestViewService.SaveStopDate(requestData.StopDate, request, attribute);

				request.SaveAndFlush();  //MR: no event
			}
			else
			{
				foreach (var error in validator.ErrorMessages)
				{
					switch (error.Key)
					{
						case ValidationType.Start:
							result.Errors.Add(new ValidationMessage_WS(Common.GetGridElementSelector(request.Id.ToString(), "StartDate"), error.Value, MessageType_E.Error));
							break;
						case ValidationType.Stop:
							result.Errors.Add(new ValidationMessage_WS(Common.GetGridElementSelector(request.Id.ToString(), "StopDate"), error.Value, MessageType_E.Error));
							break;
						case ValidationType.IM:
							result.Errors.Add(new ValidationMessage_WS(Common.GetGridElementSelector(request.Id.ToString(), "IMDate"), error.Value, MessageType_E.Error));
							break;
						case ValidationType.CRATraining:
							result.Errors.Add(new ValidationMessage_WS(Common.GetGridElementSelector(request.Id.ToString(), "CRADate"), error.Value, MessageType_E.Error));
							break;
						case ValidationType.Country:
							result.Errors.Add(new ValidationMessage_WS(string.Empty, error.Value, MessageType_E.AlertMessage));
							break;
						case ValidationType.Project:
							result.Errors.Add(new ValidationMessage_WS(string.Empty, error.Value, MessageType_E.AlertMessage));
							break;
					}
				}
			}

			result.Output = new MonitoringRequestDateResponse(request);

			return result;

		}

		public ProjectInfo_WS GetProjectDetailsForInitiateRequest(int projectId)
		{
			return Project.GetProjectDetailsForInitiateRequest(projectId);
		}

		public RequestCount RequestCount()
		{
			return models.Request.GetRequestCount();
		}

		public InitiateRequest_WS GetInitiateRequestInfo(int projectId)
		{
			return models.Request.GetRequestInfoForInitiateRequest(projectId);
		}
		public List<SiteInfo_WS> GetSiteDetails(RequestDetails_WS RequestDetails)
		{
			return ProjectProtocolSite.GetSiteDetailsforInitiateRequest(RequestDetails);
		}

		public RequestSaveDateResponse ReconnectToPpmDate(int requestId, string column)
		{
			return RequestViewService.ReconnectToPpmDate(requestId, column, true);
		}

		public string GetAssignedRegions(int projectId)
		{
			return JsonConvert.SerializeObject(CountryAndRegion_WS.getAssignedRegionsFromMonitoringAttributes(projectId));
		}

		public string GetRegionCountryByRequestId(int requestId, int projectId)
		{
			return JsonConvert.SerializeObject(CountryAndRegion_WS.getAssignedCountryRegionsbyRequestId(requestId, projectId));
		}

		public PageManager_WS GetPageManagerTypeName(int resourceTypeId, bool isProposalRequest)
		{
			return models.PageManagerType.GetPageManagerTypeName(resourceTypeId, isProposalRequest);
		}

		#endregion

		#region saveEditRequest
		public EditRequestStatus_WS saveEditRequest(EditRequest_WS modifiedRequest)
		{
			return models.Request.saveEditRequest(modifiedRequest);
		}
		#endregion

		#region IsRequestValid
		/// <summary>
		/// 
		/// </summary>
		/// <param name="requestId"></param>
		/// <returns></returns>
		public ExecutionAndValidationStatus_WS<string> IsRequestValid(int requestId, bool getAlertForReadOnly, RmPageLink_E rmPageLink)
		{
			var result = new ExecutionAndValidationStatus_WS<string>();

			models.Request request = models.Request.FindOneByProperty("Id", requestId);
			if (!request.Project.AllowRequestEdit(request.ResourceTypeId))
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, string.Format(Resources.RequestSubmissionNotAllowed, request.Project.StudyStatus), MessageType_E.AlertMessage));
			}
			else if ((RmPageLink_E.InitiateNewRequests.Equals(rmPageLink) ||
								RmPageLink_E.AwardedProposalRequest.Equals(rmPageLink) ||
								RmPageLink_E.ProposalRequests.Equals(rmPageLink)) &&
							 !(CacheService.ResourceTypes[request.ResourceTypeId].CanInitiateNewRequests))
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, Resources.CanInitiateNewRequestsEditRuleValidationMessage, MessageType_E.AlertMessage));
			}
			else if (request == null || request.RequestStatusId == (int)RequestStatusName.Deleted)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, Resources.RequestDeleted, MessageType_E.AlertMessage));
			}
			else if (!request.IsCountryActive())
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, Resources.InvalidCountry, MessageType_E.AlertMessage));
			}
			else if (!request.IsSiteActive())
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, Resources.SiteNotActive, MessageType_E.AlertMessage));
			}
			else if (!request.AllowRequestEdit)
			{
				if (getAlertForReadOnly)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, Resources.ExpiredRequest, MessageType_E.AlertMessage));
				}
				else
				{
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, Resources.AssignedRequestReadOnly_StopDateIsInPast, MessageType_E.AlertMessage));
				}
			}
			return result;
		}
		#endregion

		public List<OrganizationKVList_WS> GetAllOrganizationOrganizationalUnitRRTListForUser(int projectId, bool forMultiInit)
		{
			return models.OrganizationalUnit.GetAllOrganizationOrganizationalUnitRRTListForUser(projectId, forMultiInit);
		}

		public List<DefaultProjectMilestone_WS> GetDefaultMilestoneData()
		{
			return models.ProjectMilestone.GetMilestoneData();
		}
		public List<OrganizationSuffix_WS> GetOrganizationalUnitSuffixList()
		{
			return models.OrganizationalUnit.GetOrganizationalUnitSuffixList();
		}

		public Response_WS SaveResourceType(NewResourceType_WS newResourceType)
		{
			return ResourceType.AddEditResourceRequestType(newResourceType);
		}
		//Get Generic Resource types
		public JqGridData<ResourceTypeRowData, GridSearchResourceTypes_WS, GridRowCommonData> GetGenericResourceTypes(GridSearchResourceTypes_WS gridSearch)
		{
			return new JqGridData<ResourceTypeRowData, GridSearchResourceTypes_WS, GridRowCommonData>(ResourceType.FindAllPagedGenericResourceTypess(gridSearch), ResourceTypeRowData.Create);
		}

		public ExecutionAndValidationStatus_WS<ResourceRequestType_WS> GetResourceRequestTypeDetails(int resourceRequestTypeId)
		{
			ExecutionAndValidationStatus_WS<ResourceRequestType_WS> result = new ExecutionAndValidationStatus_WS<ResourceRequestType_WS>
			{
				RequestExecutionStatus = new List<ExecutionStatus_WS<ResourceRequestType_WS>>(),
				ValidationErrors = new List<ValidationMessage_WS>()
			};

			ResourceRequestType_WS resourceRequestDetails = ResourceType.GetResourceRequestTypeDetails(resourceRequestTypeId);

			if (resourceRequestDetails == null)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, Resources.ProjectProtocolNotFound, Domain.Utilities.MessageType_E.SharepointNotification));
			}
			else
			{
				result.RequestExecutionStatus.Add(new ExecutionStatus_WS<ResourceRequestType_WS> { AdditionalData = resourceRequestDetails });
			}

			return result;
		}

		public string GetAllRegions()
		{
			return JsonConvert.SerializeObject(CountryAndRegion_WS.GetAllRegions());
		}

		public string GetAllSubRegionsByRegion(string regionIds)
		{
			return JsonConvert.SerializeObject(CountryAndRegion_WS.GetAllSubRegionsByRegion(regionIds));
		}

		public string GetAllCountriesBySubRegion(string subRegionIds)
		{
			return JsonConvert.SerializeObject(CountryAndRegion_WS.GetAllCountriesBySubRegion(subRegionIds));
		}

		#region UpdateMultipleRequests
		public EditMultipleRequestStatus_WS UpdateMultipleRequests(EditMultipleRequest_WS requestCommonData)
		{
			return models.Request.UpdateMultipleRequests(requestCommonData);
		}
		#endregion

		#region GetPhaseCalculatorsByResourceTypeId

		/// <summary>
		///   Get phase calculator data by resource type
		/// </summary>
		/// <param columnName="requestId"> </param>
		/// <returns> </returns>
		public InitiateCalculator_WS GetPhaseCalculatorsByResourceTypeId(ResourceTypeName resourceType)
		{
			return InitiateRequestsService.GetPhaseCalculatorsByResourceTypeId(resourceType);
		}
		#endregion#endregion

		public InitiateCalculator_WS GetRegionalPhaseCalculatorsByResourceTypeId(ResourceTypeName resourceType, int regionId)
		{
			return InitiateRequestsService.GetRegionalPhaseCalculatorsByResourceTypeId(resourceType, regionId);
		}

		public InitiateCalculator_WS GetGlobalPhaseCalculatorsByResourceTypeId(ResourceTypeName resourceType)
		{
			return InitiateRequestsService.GetGlobalPhaseCalculatorsByResourceTypeId(resourceType);
		}

		public ValidationAndExecutionStatus_WS CheckGenericRequestStageCount(List<int> requestIds)
		{
			return GenericInitiateCalculator.CheckGenericRequestStageCount(requestIds);
		}
		#region IsRequestValid
		/// <summary>
		/// 
		/// </summary>
		/// <param name="requestId"></param>
		/// <returns></returns>
		public ExecutionAndValidationStatus_WS<string> CheckRequestValidity(List<int> requestIdList)
		{
			return models.Request.CheckRequestValidity(requestIdList);
		}
		#endregion

		public JqGridData<ResourcingWorklistRequestRowData, models.Request, RequestCommonData> GetSpecialOpenRequests(GridSearchByGroupId_WS gridSearch)
		{
			var pr = new PagedResponse<models.Request, RequestCommonData>();
			pr.TotalPages = 1;
			pr.PageNumber = 1;
			pr.Records = OpenRequestQueue.FindAllSpecialRequestsForSearch(gridSearch);
			pr.TotalRecords = pr.Records.Count();
			pr.PageNumber = pr.TotalRecords == 0 ? 0 : 1;

			return new JqGridData<ResourcingWorklistRequestRowData, models.Request, RequestCommonData>(pr, ResourcingWorklistRequestRowData.Create);
		}

		public List<BookingRequestResult_WS> AssignToJapan(List<int> requestIds)
		{
			List<BookingRequestResult_WS> resultRequestBookings = new List<BookingRequestResult_WS>();
			bool status;
			string message;

			foreach (var requestId in requestIds)
			{
				try
				{
					status = ResourceRequestAssignment.AssignToJapan(requestId, out message);
				}
				catch (Exception ex)
				{
					status = false;
					message = ex.Message;
				}

				resultRequestBookings.Add(new BookingRequestResult_WS { RequestId = requestId, Status = status, Message = message });
			}

			return resultRequestBookings;
		}

		public List<ReadonlyNotesResponse_WS> GetReadonlyNotes(List<ReadonlyNotes_WS> requestIds)
		{
			return EntityComment.GetReadonlyNotes(requestIds);
		}

		public ReqSched_WS GetAssignedRequestScheduleByResourceId(int resourceId)
		{
			ReqSched_WS requestSchedule;

			var requestIdList = ResourceRequestAssignment.GetAssignedRequestIdListByResourceId(resourceId);
			if (requestIdList != null && requestIdList.Count > 0)
			{
				requestSchedule = GetRequestScheduleInternal(requestIdList, false, GraphContext.Resource, false, false);
				AddProjectCodesToRequestSchedule(requestIdList, requestSchedule);
			}
			else
			{
				requestSchedule = new ReqSched_WS { ReqMonthlyHours = new ReqMonthlyHours_WS[0], StartMonth = DateHelp.DateToMonthNumber(DateTime.Today), EndMonth = DateHelp.DateToMonthNumber(DateTime.Today) };
			}

			return requestSchedule;
		}

		private void AddProjectCodesToRequestSchedule(List<int> requestIdList, ReqSched_WS requestScheduleList)
		{
			var projectCodesByRequestId = models.Request.GetProjectCodesByRequestIdList(requestIdList);

			foreach (var requestSchedule in requestScheduleList.ReqMonthlyHours)
			{
				if (requestSchedule.StartMonthNumber == 0) { requestSchedule.StartMonthNumber = requestScheduleList.StartMonth; }
				if (requestSchedule.StopMonthNumber == 0) { requestSchedule.StopMonthNumber = requestScheduleList.EndMonth; }
				if (requestSchedule.FTE == null) { requestSchedule.FTE = new decimal[requestSchedule.StopMonthNumber - requestSchedule.StartMonthNumber + 1]; }
				if (requestSchedule.Hours == null) { requestSchedule.Hours = new decimal[requestSchedule.StopMonthNumber - requestSchedule.StartMonthNumber + 1]; }

				string projectCode;
				if (projectCodesByRequestId.TryGetValue(requestSchedule.ReqID, out projectCode))
				{
					requestSchedule.CustomPointToolTipData = string.Format("Project Code: {0}<br>", projectCode);
					requestSchedule.ProjectCode = projectCode;
				}
			}
		}

		public BookingDetailcontainer_WS GetProjectBookingsByRequestIdListAndResorceId(int resourceId, List<int> requestIdList)
		{
			return ResourceRequestAssignment.GetProjectBookingsByRequestIdListAndResorceId(resourceId, requestIdList);
		}

		public BookingDetailcontainer_WS GetProgramBookingsByRequestIdListAndResorceId(int resourceId, List<int> requestIdList)
		{
			return ResourceRequestAssignment.GetProgramBookingsByRequestIdListAndResorceId(resourceId, requestIdList);
		}

		public List<OptionItem_WS> GetCountriesFromSiteAddressByProjectId(int projectId)
		{
			return ProjectProtocolSite.GetCountriesFromSiteAddressByProjectId(projectId);
		}

		public List<ResourceTypeCustomFields_WS> GetResourceTypeCustomFieldsByResourceType(int requestId, int resourceTypeId, int projectId)
		{
			return ResourceTypeCustomFields.FindByResourceTypeId(requestId, resourceTypeId, projectId);
		}

		public PpmConnectedDates_WS GetConnectedMilestoneDetailsFromDb(int resourceTypeId, int projectId, int? countryId)
		{
			return new PpmConnectedDates_WS(new models.Request { ResourceTypeId = resourceTypeId, Project = Project.FindById(projectId), CountryId = countryId }.PpmConnectedDates);
		}

		public PpmConnectedDates_WS GetRegionConnectedMilestoneDetailsFromDb(int resourceTypeId, int projectId, int? regionId)
		{
			return new PpmConnectedDates_WS(new models.Request { ResourceTypeId = resourceTypeId, Project = Project.FindById(projectId), RegionId = regionId }.PpmConnectedDates);
		}

		public ResourceTypeDelete_Status HardDeleteResourceRequestType(List<int> resourceTypeIds)
		{
			ResourceTypeDelete_Status resourceTypeDeleteStatus = new ResourceTypeDelete_Status();
			try
			{
				if (ResourceType.HardDeleteResourceRequestType(resourceTypeIds))
				{
					resourceTypeDeleteStatus.IsSuccessfull = true;
					resourceTypeDeleteStatus.Message = Resources.ResourceTypeDeleteSuccessful;
				}
				else
				{
					resourceTypeDeleteStatus.IsSuccessfull = false;
					resourceTypeDeleteStatus.Message = Resources.ResourceTypeDeleteFailed;
				}
			}
			catch
			{
				resourceTypeDeleteStatus.IsSuccessfull = false;
				resourceTypeDeleteStatus.Message = Resources.ResourceTypeDeleteFailed;
			}
			return resourceTypeDeleteStatus;
		}

		//Service for Addand Save Multiple Requests
		public EditMultipleRequestStatus_WS SplitSSVRequests(List<SplitSSVRequests_WS> requestList)
		{
			return models.Request.SplitSSVRequests(requestList);
		}

		public ServiceExecutionStatus_WS SaveAndAssignSplitRequests(List<InitiateRequests_WS> requestsToSplit)
		{
			if (requestsToSplit == null || requestsToSplit.Count == 0)
			{
				throw new ArgumentNullException("requestsToSplit");
			}
			else if (requestsToSplit[0].RequestId <= 0)
			{
				throw new Exception("RequestId required for first request.");
			}

			var executionStatus = new ServiceExecutionStatus_WS { ValidationErrors = new List<ValidationMessage_WS>() };

			var firewallConflictCheckList = requestsToSplit.Where(sr => sr.ResourceId.HasValue && sr.ValidateFirewalledProject
																	&& sr.RequestStatusId != (int)RequestStatusName.Assigned
																	&& sr.RequestStatusId != (int)RequestStatusName.Backfilled)
							.Select(sr => new FirewalledProjectConflictCheck_WS
							{
								ProjectId = sr.ProjectId,
								ResourceTypeId = sr.ResourceTypeId,
								ResourceId = sr.ResourceId.GetValueOrDefault(),
								RequestId = requestsToSplit[0].RequestId.GetValueOrDefault()
							}).ToList();

			if (firewallConflictCheckList != null && firewallConflictCheckList.Count > 0)
			{
				var firewalledProjectXml = SerializationHelper.SerializeWithDataContractSerializer(firewallConflictCheckList, typeof(List<FirewalledProjectConflictCheck_WS>));
				var allFirewallConflicts = models.Request.CheckForFireWallConflictByProjectId(firewalledProjectXml);

				if (allFirewallConflicts != null && allFirewallConflicts.Count > 0)
				{
					var hasFirewallConflict = false;
					var originalRequestId = requestsToSplit[0].RequestId.GetValueOrDefault();
					foreach (var request in requestsToSplit)
					{
						if (request.ResourceId.HasValue && models.Request.HasResourceRequestFireWalledProjectWarning(request.ResourceId.GetValueOrDefault(), originalRequestId, false, allFirewallConflicts, Resources.ResourceTypeFireWalledSplit, out string msg))
						{
							executionStatus.ValidationErrors.Add(new ValidationMessage_WS(originalRequestId.ToString(), msg, MessageType_E.ConsolidateAndShowInDialog));
							hasFirewallConflict = true;
						}
					}
					if (hasFirewallConflict)
					{
						executionStatus.ValidationErrors.Add(new ValidationMessage_WS("", Resources.ResourceTypeFireWalledSplitOkCancel, MessageType_E.ConsolidateAndShowInDialog));
					}
				}
			}

			if (!executionStatus.HasValidationErrors)
			{
				var tx = new TransactionScope();
				try
				{
					models.Request requestIncontext = null;
					models.Request originalRequest = null;
					InitiateCalculator originalRequestCalculator = null;
					for (int index = 0; index < requestsToSplit.Count; index++)
					{
						var currentRequestToSplit = requestsToSplit[index];

						if (index == 0 && currentRequestToSplit.RequestId <= 0)
						{
							throw new Exception("RequestId required for first request.");
						}
						else
						{
							if (currentRequestToSplit.StaticInitiateCalculator == null || currentRequestToSplit.StaticInitiateCalculator.Count == 0)
							{
								throw new Exception("Calculator value is missing.");
							}

							if (index == 0)
							{
								originalRequest = models.Request.Find(currentRequestToSplit.RequestId);
								originalRequest.TotalSites = currentRequestToSplit.TotalSites;
								originalRequest.SaveAndFlush();
								requestIncontext = originalRequest;

								var originalRequestCalculators = InitiateCalculator.GetCalculatorbyRequestId(originalRequest.Id);
								if (originalRequestCalculators != null && originalRequestCalculators.Count > 0)
								{
									originalRequestCalculator = originalRequestCalculators[0];
									originalRequestCalculator.FTE = currentRequestToSplit.StaticInitiateCalculator[0].FTE;
									originalRequestCalculator.WeeklyHours = currentRequestToSplit.StaticInitiateCalculator[0].WeeklyHours;
									originalRequestCalculator.SaveAndFlush();
								}
							}
							else
							{
								var splitRequest = models.Request.CloneRequest(originalRequest);
								splitRequest.RequestStatusId = (int)RequestStatusName.New;
								if (splitRequest.StartDate < DateTime.Today)
								{
									splitRequest.SetStartAndNeedByDate(DateTime.Today);
									splitRequest.StartDateStatus = RequestConnect_E.Disconnected;
								}
								splitRequest.CreatedOn = DateTime.Now;
								splitRequest.CreatedBy = ExtensionMethods.GetCurrentUserQid();
								splitRequest.TotalSites = currentRequestToSplit.TotalSites;
								splitRequest.DateSubmitted = null;
								splitRequest.SaveAndFlush();

								currentRequestToSplit.RequestId = splitRequest.Id;
								requestIncontext = splitRequest;

								var splitRequestCalculator = InitiateCalculator.CloneCalculator(originalRequestCalculator);
								splitRequestCalculator.RequestId = splitRequest.Id;
								splitRequestCalculator.FTE = currentRequestToSplit.StaticInitiateCalculator[0].FTE;
								splitRequestCalculator.WeeklyHours = currentRequestToSplit.StaticInitiateCalculator[0].WeeklyHours;
								splitRequestCalculator.SaveAndFlush();

								RequestCustomFieldData.CopyCustomfields(originalRequest.Id, splitRequest.Id);
							}
						}
					}
					tx.VoteCommit();
				}
				catch (Exception)
				{
					tx.VoteRollBack();
					throw;
				}
				finally { tx.Dispose(); }

				foreach (var requestToSplit in requestsToSplit)
				{
					var requestIncontext = models.Request.Find(requestToSplit.RequestId.GetValueOrDefault());
					if (requestIncontext.RequestStatusId == (int)RequestStatusName.New)
					{
						requestIncontext.SubmitWithoutValidation();
					}

					if (requestToSplit.ResourceId.HasValue && !requestIncontext.IsHardBooked)
					{
						try
						{
							string message;
							if (!ResourceRequestAssignment.HardBook(requestIncontext.Id, requestToSplit.ResourceId.GetValueOrDefault(), true, null, out message))
							{
								executionStatus.ValidationErrors.Add(new ValidationMessage_WS(requestIncontext.Id.ToString(), message, MessageType_E.ConsolidateAndShowInDialog));
							}
						}
						catch (Exception ex)
						{
							executionStatus.ValidationErrors.Add(new ValidationMessage_WS(requestIncontext.Id.ToString(), ex.Message, MessageType_E.ConsolidateAndShowInDialog));
						}
					}
				}
			}
			return executionStatus;
		}

		public ServiceExecutionStatus_WS SaveAndAssignSplitRequestsAll(List<InitiateRequests_WS> requestsToSplit)
		{
			if (requestsToSplit == null || requestsToSplit.Count == 0)
			{
				throw new ArgumentNullException("requestsToSplit");
			}
			else if (requestsToSplit[0].RequestId <= 0)
			{
				throw new Exception("RequestId required for first request.");
			}

			var executionStatus = new ServiceExecutionStatus_WS { ValidationErrors = new List<ValidationMessage_WS>() };

			var firewallConflictCheckList = requestsToSplit.Where(sr => sr.ResourceId.HasValue && sr.ValidateFirewalledProject
																	&& sr.RequestStatusId != (int)RequestStatusName.Assigned
																	&& sr.RequestStatusId != (int)RequestStatusName.Backfilled)
							.Select(sr => new FirewalledProjectConflictCheck_WS
							{
								ProjectId = sr.ProjectId,
								ResourceTypeId = sr.ResourceTypeId,
								ResourceId = sr.ResourceId.GetValueOrDefault(),
								RequestId = requestsToSplit[0].RequestId.GetValueOrDefault()
							}).ToList();

			if (firewallConflictCheckList != null && firewallConflictCheckList.Count > 0)
			{
				var firewalledProjectXml = SerializationHelper.SerializeWithDataContractSerializer(firewallConflictCheckList, typeof(List<FirewalledProjectConflictCheck_WS>));
				var allFirewallConflicts = models.Request.CheckForFireWallConflictByProjectId(firewalledProjectXml);

				if (allFirewallConflicts != null && allFirewallConflicts.Count > 0)
				{
					var hasFirewallConflict = false;
					var originalRequestId = requestsToSplit[0].RequestId.GetValueOrDefault();
					foreach (var request in requestsToSplit)
					{
						if (request.ResourceId.HasValue && models.Request.HasResourceRequestFireWalledProjectWarning(request.ResourceId.GetValueOrDefault(), originalRequestId, false, allFirewallConflicts, Resources.ResourceTypeFireWalledSplit, out string msg))
						{
							executionStatus.ValidationErrors.Add(new ValidationMessage_WS(originalRequestId.ToString(), msg, MessageType_E.ConsolidateAndShowInDialog));
							hasFirewallConflict = true;
						}
					}
					if (hasFirewallConflict)
					{
						executionStatus.ValidationErrors.Add(new ValidationMessage_WS("", Resources.ResourceTypeFireWalledSplitOkCancel, MessageType_E.ConsolidateAndShowInDialog));
					}
				}
			}

			if (!executionStatus.HasValidationErrors)
			{
				var tx = new TransactionScope();
				try
				{
					//models.Request requestIncontext = null;
					models.Request originalRequest = null;
					InitiateCalculator originalRequestCalculator = null;
					GenericInitiateCalculator originalGenericInitiateCalculator = null;
					for (int index = 0; index < requestsToSplit.Count; index++)
					{
						var currentRequestToSplit = requestsToSplit[index];

						if (index == 0 && currentRequestToSplit.RequestId <= 0)
						{
							throw new Exception("RequestId required for first request.");
						}
						else
						{
							var hasStaticCalculators = currentRequestToSplit.StaticInitiateCalculator != null && currentRequestToSplit.StaticInitiateCalculator.Count > 0;
							var hasGenericCalculators = currentRequestToSplit.GenericInitiateCalculatorPhaseDate != null && currentRequestToSplit.GenericInitiateCalculatorPhaseDate.Count > 0;
							if (!hasStaticCalculators && !hasGenericCalculators)
							{
								throw new Exception("Calculator value is missing.");
							}

							if (index == 0)
							{
								originalRequest = models.Request.Find(currentRequestToSplit.RequestId);
								var requestUpdated = false;
								if (hasGenericCalculators)
								{
									originalRequest.StartDate = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].FromMilestoneDate.ToDateFromQDateString();
									originalRequest.StartDateStatus = RequestConnect_E.Disconnected;
									originalRequest.StopDate = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].ToMilestoneDate.ToDateFromQDateString();
									originalRequest.StopDateStatus = RequestConnect_E.Disconnected;
									requestUpdated = true;
								}

								if (originalRequest.TotalSites != currentRequestToSplit.TotalSites)
								{
									originalRequest.TotalSites = currentRequestToSplit.TotalSites;
									requestUpdated = true;
								}

								if (requestUpdated) { originalRequest.SaveAndFlush(); }
								if (!string.IsNullOrEmpty(currentRequestToSplit.Notes))
								{
									originalRequest.CreateComment(currentRequestToSplit.Notes, CommentTypeName.None).SaveAndFlush();
								}
								//requestIncontext = originalRequest;
								IList<InitiateCalculator> originalRequestCalculators = null;
								IList<GenericInitiateCalculator> originalGenericCalculators = null;
								if (hasStaticCalculators)
								{
									originalRequestCalculators = InitiateCalculator.GetCalculatorbyRequestId(originalRequest.Id);
									if (originalRequestCalculators != null && originalRequestCalculators.Count > 0)
									{
										originalRequestCalculator = originalRequestCalculators[0];
										originalRequestCalculator.FTE = currentRequestToSplit.StaticInitiateCalculator[0].FTE;
										originalRequestCalculator.WeeklyHours = currentRequestToSplit.StaticInitiateCalculator[0].WeeklyHours;
										originalRequestCalculator.SaveAndFlush();
									}
								}
								else
								{
									originalGenericCalculators = GenericInitiateCalculator.GetGenericCalculatorbyRequestId(originalRequest.Id);

									if (originalGenericCalculators != null && originalGenericCalculators.Count > 0)
									{
										originalGenericInitiateCalculator = originalGenericCalculators[0];
										originalGenericInitiateCalculator.FTE = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].FTE;
										originalGenericInitiateCalculator.WeeklyHours = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].WeeklyHours;
										originalGenericInitiateCalculator.FromMilestoneDate = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].FromMilestoneDate.ToDateFromQDateString();
										originalGenericInitiateCalculator.ToMilestoneDate = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].ToMilestoneDate.ToDateFromQDateString();
										originalGenericInitiateCalculator.SaveAndFlush();
									}
								}
								requestsToSplit[index].Request = originalRequest;
								
							}
							else
							{
								var splitRequest = models.Request.CloneRequest(originalRequest);
								splitRequest.RequestStatusId = (int)RequestStatusName.New;

								if (hasGenericCalculators)
								{
									splitRequest.StartDate = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].FromMilestoneDate.ToDateFromQDateString();
									splitRequest.StartDateStatus = RequestConnect_E.Disconnected;
									splitRequest.StopDate = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].ToMilestoneDate.ToDateFromQDateString();
									splitRequest.StopDateStatus = RequestConnect_E.Disconnected;
								}
								else
								{
									if (splitRequest.StartDate < DateTime.Today)
									{
										splitRequest.SetStartAndNeedByDate(DateTime.Today);
										splitRequest.StartDateStatus = RequestConnect_E.Disconnected;
									}
								}

								//splitRequest.CreatedOn = DateTime.Now;
								//splitRequest.CreatedBy = ExtensionMethods.GetCurrentUserQid();
								//splitRequest.DateSubmitted = null;
								splitRequest.TotalSites = currentRequestToSplit.TotalSites;
								splitRequest.SaveAndFlush();

								if (!string.IsNullOrEmpty(currentRequestToSplit.Notes))
								{
									splitRequest.CreateComment(currentRequestToSplit.Notes, CommentTypeName.None).SaveAndFlush();
								}
								currentRequestToSplit.RequestId = splitRequest.Id;
								requestsToSplit[index].Request = splitRequest;

								if (hasStaticCalculators)
								{									
									var splitRequestCalculator = InitiateCalculator.CloneCalculator(originalRequestCalculator);
									splitRequestCalculator.Id = -1;
									splitRequestCalculator.RequestId = splitRequest.Id;
									splitRequestCalculator.FTE = currentRequestToSplit.StaticInitiateCalculator[0].FTE;
									splitRequestCalculator.WeeklyHours = currentRequestToSplit.StaticInitiateCalculator[0].WeeklyHours;
									splitRequestCalculator.CreatedOn = DateTime.Now;
									splitRequestCalculator.CreatedBy = ExtensionMethods.GetCurrentUserQid();
									splitRequestCalculator.SaveAndFlush();
								}
								else
								{
									var splitRequestGenericCalculator = GenericInitiateCalculator.CloneCalculator(originalGenericInitiateCalculator);
									splitRequestGenericCalculator.Id = -1;
									splitRequestGenericCalculator.RequestId = splitRequest.Id;
									splitRequestGenericCalculator.FTE = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].FTE;
									splitRequestGenericCalculator.WeeklyHours = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].WeeklyHours;
									splitRequestGenericCalculator.FromMilestoneDate = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].FromMilestoneDate.ToDateFromQDateString();
									splitRequestGenericCalculator.ToMilestoneDate = currentRequestToSplit.GenericInitiateCalculatorPhaseDate[0].ToMilestoneDate.ToDateFromQDateString();
									splitRequestGenericCalculator.CreatedOn = DateTime.Now;
									splitRequestGenericCalculator.CreatedBy = ExtensionMethods.GetCurrentUserQid();
									splitRequestGenericCalculator.SaveAndFlush();
								}
								RequestCustomFieldData.CopyCustomfields(originalRequest.Id, splitRequest.Id);
							}
						}
					}
					tx.VoteCommit();
				}
				catch (Exception)
				{
					tx.VoteRollBack();
					throw;
				}
				finally { tx.Dispose(); }

				foreach (var requestToSplit in requestsToSplit)
				{
					var requestIncontext = requestToSplit.Request;
					if (requestIncontext.RequestStatusId == (int)RequestStatusName.New)
					{
						requestIncontext.SubmitWithoutValidation();
					}

					if (requestToSplit.ResourceId.HasValue && !requestIncontext.IsHardBooked)
					{
						try
						{
							//if EmailSplitSummary of RT is true, suppress individual notification from inside HardBook & send a summary email with all the resources in the split operation separately.
							if (!ResourceRequestAssignment.HardBook(requestIncontext.Id, requestToSplit.ResourceId.GetValueOrDefault(), true, null, out string message, requestIncontext.ResourceType.EmailSplitSummary))
							{
								executionStatus.ValidationErrors.Add(new ValidationMessage_WS(requestIncontext.Id.ToString(), message, MessageType_E.ConsolidateAndShowInDialog));
							}
						}
						catch (Exception ex)
						{
							executionStatus.ValidationErrors.Add(new ValidationMessage_WS(requestIncontext.Id.ToString(), ex.Message, MessageType_E.ConsolidateAndShowInDialog));
						}
					}
				}
				if (!executionStatus.HasValidationErrors)
				{
					HardBookEmailService.SendNotificationForSplitResources(requestsToSplit.Where(res => res.ResourceId.HasValue).ToList(), UserCache.Usr);
				}
			}
			return executionStatus;
		}

		//Service for Addand Save Multiple Requests
		public List<AddUpdateInitiateRequestStatus_WS> SaveMultipleInitiateRequests(List<InitiateRequests_WS> requestList)
		{
			var executrionStatusList = new List<AddUpdateInitiateRequestStatus_WS>();

			foreach (var requestFromUi in requestList)
			{
				List<ProjectResourceFireWalledProjects_Ws> allFirewallConflicts = null;
				if (requestFromUi.ResourceId.HasValue && requestFromUi.ValidateFirewalledProject)
				{
					var firewallConflictCheck = new List<FirewalledProjectConflictCheck_WS> {
						new FirewalledProjectConflictCheck_WS
						{
							ProjectId = requestFromUi.ProjectId,
							ResourceTypeId = requestFromUi.ResourceTypeId,
							ResourceId = requestFromUi.ResourceId.GetValueOrDefault(),
							RequestId = requestFromUi.RowId.GetValueOrDefault()
						}
					};
					var firewalledProjectXml = SerializationHelper.SerializeWithDataContractSerializer(firewallConflictCheck, typeof(List<FirewalledProjectConflictCheck_WS>));
					allFirewallConflicts = models.Request.CheckForFireWallConflictByProjectId(firewalledProjectXml);
				}

				if (requestFromUi.ValidateFirewalledProject && requestFromUi.ResourceId.HasValue && models.Request.HasResourceRequestFireWalledProjectWarning(requestFromUi.ResourceId.Value, requestFromUi.RowId.GetValueOrDefault(), false, allFirewallConflicts, Resources.ResourceTypeFireWalled, out string msg))
				{
					var executionStatus = new AddUpdateInitiateRequestStatus_WS { ValidationErrors = new List<ValidationMessage_WS> { new ValidationMessage_WS(requestFromUi.RowId.ToString(), msg, MessageType_E.GridIcon) } };
					executionStatus.RowJson = new InitiateRequestRowData(new RequestCommonData { RmPageLinkId = (int)RmPageLink_E.InitiateNewRequests });
					executionStatus.RowJson.UiRowId = requestFromUi.RowId.GetValueOrDefault();
					executrionStatusList.Add(executionStatus);
				}
				else
				{
					var executionStatus = InitiateRequestsService.ValidateAndSaveInitiateRequests(requestFromUi, InitiateRequestsService.AddErrorsToResultForMultiInit, true);
					executrionStatusList.Add(executionStatus);

					if (!executionStatus.ContainsValidationErrors)
					{
						executionStatus.RowJson.UiRowId = requestFromUi.RowId.GetValueOrDefault();

						//Submit request if the there are no errors
						var submitResult = SubmitRequests(new List<int> { executionStatus.RowJson.id });
						if (submitResult != null && submitResult.Count > 0 && !submitResult[0].IsSuccessful)
						{
							executionStatus.ValidationErrors.Add(new ValidationMessage_WS("", submitResult[0].Message, MessageType_E.GridIcon));
						}

						else if (requestFromUi.ResourceId.HasValue)
						{
							//Hardbook request if the there are no submission errors
							try
							{
								string message;
								if (!ResourceRequestAssignment.HardBook(executionStatus.RowJson.id, requestFromUi.ResourceId.GetValueOrDefault(), true, null, out message))
								{
									executionStatus.ValidationErrors.Add(new ValidationMessage_WS("", message, MessageType_E.GridIcon));
								}
							}
							catch (Exception ex)
							{
								executionStatus.ValidationErrors.Add(new ValidationMessage_WS("", ex.Message, MessageType_E.GridIcon));
							}
						}
					}

					if (executionStatus.ContainsValidationErrors)
					{
						executionStatus.RowJson = new InitiateRequestRowData(new RequestCommonData { RmPageLinkId = (int)RmPageLink_E.InitiateNewRequests });
						executionStatus.RowJson.UiRowId = requestFromUi.RowId.GetValueOrDefault();
					}
				}
			}

			return executrionStatusList;
		}

		public ServiceExecutionStatus_WS DeleteBackfill(int requestId, BackfillDeleteOption_E deleteOption)
		{
			var result = new ServiceExecutionStatus_WS { EntityId = requestId };

			var request = models.Request.Find(requestId);
			if (request == null)
			{
				result.IsSuccessful = false;
				result.Message = string.Format("Request with Id {0} not found in the system", requestId);
			}
			else
			{
				string message;
				result.IsSuccessful = request.DeleteBackfill(out message, deleteOption);
				result.Message = message;
			}

			return result;
		}
		public List<CustomFields> GetCustomFieldDefaultValues(int resourceTypeId, int projectId, int countryId)
		{
			return ResourceType.GetCustomFieldDefaultValues(resourceTypeId, projectId, countryId);
		}
		public List<ComputedRequestMilestoneDays_WS> GetAllComputedReqestMilestoneDaysToAdd()
		{
			return FTETypeFTEMileStoneType.GetAllComputedReqestMilestoneDaysToAdd();
		}
		public bool IsProposalReqeustWithQipData(int requestId)
		{
			return models.Request.Find(requestId).IsProposalReqeustWithQipData;
		}

		public int GetBusinessDays(string stopDate, int countryId)
		{
			return CalculatorUtility.GetBusinessDays(DateTime.Now, Convert.ToDateTime(stopDate), countryId);
		}

		//GetPastRequestList
		public JqGridData<PastRequestsListData, models.Request, RequestCommonData> GetPastRequestsByProjectIdResourceTypeId(PastRequestListGrid_WS gridSearch)
		{
			return new JqGridData<PastRequestsListData, models.Request, RequestCommonData>(models.Request.FindAllPastSubmittedRequestsByProjectIdResourceTypeId(gridSearch), PastRequestsListData.Create);
		}

		public ExecutionStatus_WS<List<AssignedResourceDetails_WS>> GetSoftBookedResourceDetailsByRequestId(int requestId)
		{
			return ResourceRequestAssignment.GetSoftBookedResourceDetailsByRequestId(requestId);
		}

		public ExecutionStatus_WS<RequestInfo_WS> GetRequestDetailsByRequestId(int requestId)
		{
			return models.Request.GetRequestDetailsByRequestId(requestId);
		}
	}
}