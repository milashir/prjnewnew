       DECLARE @rbmSiteMonResourceTypeId AS INT = 27;
       DECLARE @rbmpharmaMonResourceTypeId AS INT = 28; 
	   DECLARE @stdMonResourceTypeId AS INT = 5;
        DECLARE @pharmaMonResourceTypeId AS INT = 7; 
        DECLARE @fsiLsiFteTypeId AS INT = 3;
        DECLARE @lsiLsoFteTypeId AS INT = 4;
        DECLARE @lsoDblFteTypeId AS INT = 5;
        --DECLARE @dblCovFteTypeId AS INT = 6;
        DECLARE @pharmacyFteTypeId AS INT = 8;
        DECLARE @projectId INT=4516

		DECLARE @VisitMaxAvgTable TABLE (    
	ProjectId INT NULL,
	CalculatorTypeId INT NULL,
    MinOnsiteError numeric(18, 3) NULL,
	MaxOnsiteError numeric(18, 3) NULL,
	AvgOnsiteError numeric(18, 3) NULL,
	MinRemoteError numeric(18, 3) NULL,
	MaxRemoteError numeric(18, 3) NULL,
	AvgRemoteError numeric(18, 3) NULL
);
INSERT INTO @VisitMaxAvgTable
 SELECT @projectId,CalculatorTypeId ,
        MIN(ABS(BeforeOnsiteVisitFrequency - AfterOnsiteVisitFrequency)) AS MinOnsiteError ,
        MAX(ABS(BeforeOnsiteVisitFrequency - AfterOnsiteVisitFrequency)) AS MaxOnsiteError ,
        AVG(ABS(BeforeOnsiteVisitFrequency - AfterOnsiteVisitFrequency)) AS AvgOnsiteError ,
        MIN(ABS(BeforeRemoteVisitFrequency - AfterRemoteVisitFrequency)) AS MinRemoteError ,
        MAX(ABS(BeforeRemoteVisitFrequency - AfterRemoteVisitFrequency)) AS MaxRemoteError ,
        AVG(ABS(BeforeRemoteVisitFrequency - AfterRemoteVisitFrequency)) AS AvgRemoteError
 FROM   ( SELECT    TC.ProjectId ,
                    PPS.SiteId ,
                    COALESCE(RC.CalculatorTypeId, TC.CalculatorTypeId) AS CalculatorTypeId ,
                    COALESCE(RC.TypeId, TC.TypeId) AS FteTypeId ,
                    STX.TierId ,
                    COALESCE(RC.VisitFrequency, TC.VisitFrequency) AS BeforeOnsiteVisitFrequency ,
                    COALESCE(RC.PhoneVisitFrequency, TC.PhoneVisitFrequency) AS BeforeRemoteVisitFrequency ,
                    CASE WHEN OnSiteVisitRatio != 0
                         THEN TierCycle / OnSiteVisitRatio
                         ELSE NULL
                    END AS AfterOnsiteVisitFrequency ,
                    CASE WHEN RemoteVisitRatio != 0
                         THEN TierCycle / RemoteVisitRatio
                         ELSE NULL
                    END AS AfterRemoteVisitFrequency
          FROM      TFTECalculator TC WITH ( NOLOCK )
                    JOIN ( SELECT   PPSI.ProjectId ,
                                    A.CountryId ,
                                    PPSI.SiteId
                           FROM     dbo.ProjectProtocolSite PPSI WITH ( NOLOCK )
                                    JOIN dbo.Address A WITH ( NOLOCK ) ON A.AddressId = PPSI.AddressId
                           WHERE    PPSI.ProjectId = @projectId
                         ) PPS ON PPS.ProjectId = TC.ProjectId
                                  AND PPS.CountryId = TC.CountryId
                    JOIN dbo.SiteTier_XREF STX ON STX.SiteId = PPS.SiteId
                                                  AND STX.CalculatorTypeId = TC.TypeId
                    LEFT JOIN dbo.VisitSchemaLevelTier_Xref VSLTX ON VSLTX.ProjectId = PPS.ProjectId
                                                              AND VSLTX.CalculatorTypeId = TC.CalculatorTypeId
                                                              AND VSLTX.TierId = STX.TierId
                    LEFT JOIN ( SELECT  R.ProjectId ,
                                        R.CountryId ,
                                        R.SiteId ,
                                        R.RequestId ,
                                        R.ResourceTypeId ,
                                        TC.CalculatorTypeId ,
                                        TC.TypeId ,
                                        TC.VisitFrequency ,
                                        TC.PhoneVisitFrequency ,
                                        ROW_NUMBER() OVER ( PARTITION BY R.SiteId,
                                                            TC.CalculatorTypeId,
                                                            TC.TypeId ORDER BY R.RequestId DESC ) AS RequestRank
                                FROM    dbo.Request R
                                        LEFT JOIN dbo.Request BFR ON BFR.ParentRequestId = R.RequestId
                                        JOIN dbo.TFTECalculator TC ON TC.RequestId = R.RequestId
                                WHERE   R.ResourceTypeId IN (
                                        @rbmSiteMonResourceTypeId,
                                        @rbmpharmaMonResourceTypeId )
                                        AND BFR.RequestId IS NULL
                                        AND R.ProjectId = @projectId
                              ) RC ON RC.ProjectId = TC.ProjectId
                                      AND RC.CountryId = TC.CountryId
                                      AND RC.CalculatorTypeId = TC.CalculatorTypeId
                                      AND RC.TypeId = TC.TypeId
                                      AND RC.SiteId = PPS.SiteId
                                      AND RC.RequestRank = 1
          WHERE     TC.TypeId IN ( @fsiLsiFteTypeId, @lsiLsoFteTypeId,
                                   @lsoDblFteTypeId, --@dblCovFteTypeId,
                                   @pharmacyFteTypeId )
                    AND TC.RequestId IS NULL
		--ORDER BY TC.ProjectId ,PPS.SiteId, CalculatorTypeId, FteTypeId
        ) d
 GROUP BY CalculatorTypeId;


 DECLARE @VisitCountTable TABLE (
    ProjectId INT NOT NULL,
    ActualRemoteCount INT NOT NULL,
	PlannedRemoteCount INT NOT NULL,
	ActualOnsiteCount INT NOT NULL,
	PlannedOnsiteCount INT NOT NULL
);


DECLARE @VisitProjectedTable TABLE (
ProjectId INT NOT NULL,
    ProjectedRemoteCount INT NOT NULL,
	ProjectedOnsiteCount INT NOT NULL
);

INSERT INTO @VisitCountTable
 SELECT @projectId, COUNT(CASE WHEN SVT.IsRemoteVisit = 1
                        AND CAST(COALESCE(SV.ActualDate, SV.ProjectedDate) AS DATE) < CAST(GETDATE() AS DATE)
                   THEN 1
                   ELSE NULL
              END) AS ActualRemoteCount,
			  COUNT(CASE WHEN SVT.IsRemoteVisit = 1
                        AND CAST(COALESCE(SV.ActualDate, SV.ProjectedDate) AS DATE) >= CAST(GETDATE() AS DATE)
                   THEN 1
                   ELSE NULL
              END) PlannedRemoteCount,
			  COUNT(CASE WHEN SVT.IsOnsiteVisit = 1
                        AND SVT.IsPharmacyVisit = 0
                        AND CAST(COALESCE(SV.ActualDate, SV.ProjectedDate) AS DATE) < CAST(GETDATE() AS DATE)
                   THEN 1
                   ELSE NULL
              END) ActualOnsiteCount,COUNT(CASE WHEN SVT.IsOnsiteVisit = 1
                        AND SVT.IsPharmacyVisit = 0
                        AND CAST(COALESCE(SV.ActualDate, SV.ProjectedDate) AS DATE) >= CAST(GETDATE() AS DATE)
                   THEN 1
                   ELSE NULL
              END) PlannedOnsiteCount
              FROM   dbo.ProjectProtocolSite PPS
        JOIN dbo.SiteVisit SV ON SV.SiteId = PPS.SiteId
        JOIN dbo.SiteVisitType SVT ON SVT.SiteVisitTypeId = SV.SiteVisitTypeId
        JOIN dbo.Project P WITH ( NOLOCK ) ON P.ProjectId = PPS.ProjectId
 WHERE  P.ProjectId=@projectId
        AND SVT.IsSivVisit = 0
         AND SVT.IsCovVisit = 0
        AND SVT.IsImvVisitForVisitCount = 1

		
 INSERT INTO @VisitProjectedTable

        SELECT @projectId,  COUNT(CASE WHEN SVT.IsRemoteVisit = 1 THEN 1
                   ELSE NULL
              END) AS ProjectedRemoteCount,
			  COUNT(CASE WHEN SVT.IsOnsiteVisit = 1
                        AND SVT.IsPharmacyVisit = 0
                        AND R.ResourceTypeId NOT IN ( 7, 28 ) THEN 1
                   ELSE NULL
              END) AS ProjectedOnsiteCount
 FROM   dbo.Request R
        JOIN dbo.ProjectProtocolSite PPS ON PPS.SiteId = R.SiteId
        JOIN dbo.Cache_RequestVisitDates CRVD ON CRVD.RequestId = R.RequestId
        JOIN dbo.SiteVisitType SVT ON SVT.SiteVisitTypeId = CRVD.SiteVisitTypeId
        JOIN dbo.Project P WITH ( NOLOCK ) ON P.ProjectId = PPS.ProjectId
 WHERE  P.ProjectId=@projectId
        AND SVT.IsSivVisit = 0
        AND SVT.IsCovVisit = 0
        AND SVT.IsRmProjectedVisit = 1

		SELECT P.ProjectCode,P.ProtocolNumber,C.TypeName,VCT.ActualRemoteCount+VCT.PlannedRemoteCount+VPT.ProjectedRemoteCount AS 'Remote Visit Count',
		VCT.ActualOnsiteCount+VCT.PlannedOnsiteCount+VPT.ProjectedOnsiteCount AS 'Onsite Visit Count',
		VMA.MinOnsiteError,
        VMA.MaxOnsiteError,
        VMA.AvgOnsiteError,
        VMA.AvgRemoteError
	    FROM  @VisitCountTable VCT JOIN @VisitProjectedTable VPT
		ON VCT.ProjectId=VPT.ProjectId
	    JOIN @VisitMaxAvgTable VMA
		ON VCT.ProjectId=VMA.ProjectId
		JOIN Project P ON P.ProjectId=VMA.ProjectId
		JOIN CalculatorType C ON C.CalculatorTypeId=VMA.CalculatorTypeId

		

		

		

		

		
		


		

 

   
        

 


       