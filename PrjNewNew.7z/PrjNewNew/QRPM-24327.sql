update R set R.FTE=IC.FTE
from Request R inner join InitiateCalculator IC ON R.RequestId=IC.RequestId
where R.ResourceTypeId=38 and R.RequestTypeId=5 and FTETypeFTEMileStoneTypeId=46


delete from InitiateCalculator where RequestId in(
select R.RequestId 
from Request R inner join InitiateCalculator IC ON R.RequestId=IC.RequestId
where R.ResourceTypeId=38 and R.RequestTypeId=5)
