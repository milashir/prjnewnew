﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Admin;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;
namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Admin
{
	public partial class Edit : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ResourceTypeAdministration; } }
		protected override void Page_Load(object sender, System.EventArgs e)
		{
			// Get All the categories

			List<Category_WS> categories = Category.GetSkillsetCategories();
			bool isDepartmentTab = false;
			string DepatmentSting = string.Empty;
			foreach (Category_WS category in categories)
			{
				string tabtext = category.CategoryName;
				Literal liStart = new Literal();
				liStart.Text = "<li id=\"" + category.Id + "\"><a href=\"#tabs-" + category.Id + "\">" + tabtext + "</a></li>";
				tabsList.Controls.Add(liStart);
				Literal tabDivStart = new Literal();
				string divid = "tabs-" + category.Id;
				tabDivStart.Text = "<div  id=" + divid + ">";
				staticData.Controls.Add(tabDivStart);
				IList<ExperienceType> projectData = ExperienceType.GetAdminControls(category.Id, null);
				Literal rootdivstart = new Literal();
				string rootdiv = "rootDiv" + category.Id;
				rootdivstart.Text = "<div id='" + rootdiv + "' style=\"overflow-x:hidden;overflow:auto;height:250px\">";
				staticData.Controls.Add(rootdivstart);
				Literal tableStart = new Literal();
				string tableId = "tbl" + category.Id;
				tableStart.Text = "<table id=" + tableId + " style=\"width: 400px\">";
				staticData.Controls.Add(tableStart);
				Literal trStart = new Literal();
				foreach (ExperienceType masterData in projectData)
				{
					string controlId = masterData.Name + "_" + masterData.Id;
					if (masterData.ControlType == "checkbox")
					{
						if (masterData.IsDeriveFromProject)
						{
							trStart.Text = trStart.Text + "<tr><td>" + masterData.Name + "</td><td>:</td><td> <input type=\"checkbox\" style=\"vertical-align: middle;\" id=\"chk_" + controlId + "\"><img style=\"vertical-align: middle;\" src=\"../../images/searchIcon.png\" alt='" + masterData.ToolTipText + "' class=\"classShowToolTip\"></td></tr>";
						}
					}
					else if (masterData.ControlType == "dropdownlist")
					{
						string dropDownData = ExperienceType.GetDropDownData(masterData.SourceTable, masterData.PrimaryKeyColumnName, masterData.DisplayColumnName);
						if (category.Id != 4)
						{
							trStart.Text = trStart.Text + "<tr><td>" + masterData.Name + "</td><td>:</td><td><label class=\"fieldSetControl\"><select class=\"fieldsetLabelWIdthBigger\"  id=\"ddl_" + controlId + "\">" + dropDownData + "</select></label></td></tr>";
						}
						else
						{
							if (masterData.DepartmentId == 0)
							{
								trStart.Text = trStart.Text + "<tr><td>" + masterData.Name + "</td><td>:</td><td><label class=\"fieldSetControl\"><select class=\"fieldsetLabelWIdthBigger classDepartment\"  id=\"ddlDepartment\">" + dropDownData + "</select></label></td></tr>";
								isDepartmentTab = true;
								DepatmentSting = Convert.ToString(GetDepartmentData(masterData));
							}
						}
					}
				}
				staticData.Controls.Add(trStart);
				Literal tableEnd = new Literal();
				tableEnd.Text = "</table>";
				staticData.Controls.Add(tableEnd);
				if (isDepartmentTab)
				{
					Literal deptringstart = new Literal();
					deptringstart.Text = DepatmentSting;
					staticData.Controls.Add(deptringstart);
				}
				Literal rootdivEnd = new Literal();
				rootdivEnd.Text = "</div>";
				staticData.Controls.Add(rootdivEnd);
				if (isDepartmentTab)
				{
					isDepartmentTab = false;
				}

				Literal tabDivEnd = new Literal();
				tabDivEnd.Text = "</div>";
				staticData.Controls.Add(tabDivEnd);
			}
			Literal tabHdnFld = new Literal();
			tabHdnFld.Text = "<input type=\"hidden\" id=\"hdnEdit\" >";
			staticData.Controls.Add(tabHdnFld);
			Literal hdnEditRowId = new Literal();
			hdnEditRowId.Text = "<input type=\"hidden\" id=\"hdnEditRowId\" >";
			staticData.Controls.Add(hdnEditRowId);
			Literal hdnUpdateTab = new Literal();
			hdnUpdateTab.Text = "<input type=\"hidden\" id=\"hdnUpdateTab\" >";
			staticData.Controls.Add(hdnUpdateTab);
			Literal hdnFilter = new Literal();
			hdnFilter.Text = "<input type=\"hidden\" id=\"hdnFilter\" >";
			staticData.Controls.Add(hdnFilter);

			UIUtility.BindDropDown(ddlJobRole, CacheService.ActiveJobRoles, true);
		}

		public StringBuilder GetDepartmentData(ExperienceType experienceData)
		{
			StringBuilder htmlAll = new StringBuilder();
			List<OptionItem_WS> dropDownData = ExperienceType.GetDataForDropdown(experienceData.SourceTable, experienceData.PrimaryKeyColumnName, experienceData.DisplayColumnName);
			if (experienceData.PrimaryKeyColumnName != string.Empty && experienceData.DisplayColumnName != string.Empty)
			{
				foreach (OptionItem_WS item in dropDownData)
				{
					var buttonId = "btnDepartment_" + item.Id + "_" + experienceData.CategoryId;
					var resetButtonId = "btnResetDepartment_" + item.Id + "_" + experienceData.CategoryId;
					var updateButtonId = "btnUpdateDepartment_" + item.Id + "_" + experienceData.CategoryId;

					DetachedCriteria criteria = DetachedCriteria.For(typeof(AdminPageSkillsHeader));
					criteria.Add(Expression.Eq("CategoryId", experienceData.CategoryId));
					criteria.Add(Expression.Eq("DepartmentId", item.Id));
					AdminPageSkillsHeader[] headerData = AdminPageSkillsHeader.FindAll(criteria);

					IList<ExperienceType> projectData = ExperienceType.GetAdminControls(experienceData.CategoryId, item.Id);
					headerData = headerData.OrderBy(h => h.DisplayOrder).ToArray();
					string className = "departmentClass" + item.Id;
					htmlAll.Append("<div class='" + className + "'>");
					foreach (AdminPageSkillsHeader header in headerData)
					{
						htmlAll.Append("<span><B>" + header.Name + "</B><span><br><br>");

						htmlAll.Append("<table  style=\"width: 800px\">");
						IList<ExperienceType> childControls = projectData.OrderBy(x => x.ControlDisplayOrder).Where(h => h.HeaderId == header.Id).ToList();
						foreach (ExperienceType masterData in childControls)
						{
							//RMK: Fix-identified an issue here if there exists special charecter "'"
							string label = masterData.Name;
							masterData.Name = masterData.Name.Replace("'", "");
							if (masterData.ControlType == "radiobutton")
							{
								string[] range = masterData.RangeValues.Split('|');
								htmlAll.Append("<tr><td style=\"width:250px;text-align:left\">" + label + "</td>");
								htmlAll.Append("<td>");
								foreach (string val in range)
								{
									string radioName = "rad_" + masterData.Name + "_" + masterData.Id;
									htmlAll.Append("<input type=\"radio\"  value=\"" + val.Trim() + "\"  class=\"radioButton_Department\" name=\"" + radioName.Trim() + "\">" + val.Trim() + "&nbsp;");
								}
								htmlAll.Append("</td>");
								htmlAll.Append("</tr>");
							}
							else if (masterData.ControlType == "checkbox")
							{
								string checkboxId = "chk_" + masterData.Name + "_" + masterData.Id;
								htmlAll.Append("<tr><td style=\"width:250px\">" + label + "</td><td><input type=\"checkbox\" id=\"" + checkboxId + "\"></td></tr>");
							}
							else if (masterData.ControlType == "textbox")
							{
								string controlId = "txt_" + masterData.Name + "_" + masterData.Id;
								htmlAll.Append("<td>" + label + "</td><td><input type=\"text\" id= '" + controlId + "' class=\"fieldsetLabelWIdthBigger\" /></td></tr>");
							}
							else if (masterData.ControlType == "dropdownlist")
							{
								string controlId = "ddl_" + masterData.Name + "_" + masterData.Id;
								string options = GetDropDownData(masterData.SourceTable, masterData.PrimaryKeyColumnName, masterData.DisplayColumnName);
								htmlAll.Append("<td>" + label + "</td><td><label class=\"fieldSetControl\"><select class=\"fieldsetLabelWIdthBigger\"  id='" + controlId + "'>" + options + "</select></label></td></tr>");
							}
						}

						htmlAll.Append("</table>");
					}
					htmlAll.Append("</div>");
				}
			}
			return htmlAll;
		}


		public string GetDropDownData(string tableName, string fieldId, string fieldName)
		{
			string html = "<option value=\"-1\" selected>" + "--Select--" + "</option>";
			if (fieldId != string.Empty && fieldName != string.Empty)
			{
				List<OptionItem_WS> dropDownData = ExperienceType.GetDataForDropdown(tableName, fieldId, fieldName);
				foreach (OptionItem_WS item in dropDownData)
				{
					html = html + "<option value=\"" + item.Id + "\" >" + item.Name + "</option>";
				}
			}
			return html;
		}

		public override TabDefinition GetTabDefinition()
		{
			var hasAccessToEditResourceType = RmFunction.HasPermissionToFunction(RmFunction_E.Edit_Resource_Types, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
			hdnHasAccessToEditResourceType.Value = hasAccessToEditResourceType.GetIntAsStringFromBool();

			AddResourceTypeRibbonButtons(hasAccessToEditResourceType);
			AddElvisSkillsRibbonButtons(hasAccessToEditResourceType);
			AddCustomFieldsRibbonButtons(hasAccessToEditResourceType);

			return new TabDefinition()
			{
				Id = "Permissions",
				Title = "Manage Resource Type",
				Groups = PageGroups.ToArray()
			};
		}

		private void AddCustomFieldsRibbonButtons(bool hasAccessToEditResourceType)
		{
			if (hasAccessToEditResourceType)
			{
				PageGroups.Add(new GroupDefinition()
					{
						Id = "CustomFieldActions",
						Title = "Custom Field Actions",
						Template = GroupTemplateLibrary.SimpleTemplate,
						Controls = new ControlDefinition[] 
						{
							new ButtonDefinition() {
									Id="AddCustomField",
									Title="Add",
									CommandJavaScript = "resourceTypeAdmin.customField.add()",
									CommandEnableJavaScript = "resourceTypeAdmin.customField.isCustomFieldAddEnabled()",
									Image=ImageLibrary.GetStandardImage(8, 5, revision)
							},
							new ButtonDefinition() {
									Id="UpdateCustomField",
									Title="Update",
									CommandJavaScript = "resourceTypeAdmin.customField.update()",
									CommandEnableJavaScript = "resourceTypeAdmin.customField.isCustomFieldEditEnabled()",
									Image=ImageLibrary.GetStandardImage(0, 1, revision)
							},
							new ButtonDefinition()
							{
									Id="ResetCustomField",
									Title="Reset",
									CommandJavaScript = "resourceTypeAdmin.customField.reset()",
									CommandEnableJavaScript = "resourceTypeAdmin.customField.isCustomFieldResetEnabled()",
									Image=MapImageLibrary.GetFormatMapImage(12,13, revision)
							}
					}
					});
			}
		}

		private void AddElvisSkillsRibbonButtons(bool hasAccessToEditResourceType)
		{
			if (hasAccessToEditResourceType)
			{
				PageGroups.Add(new GroupDefinition()
					{
						Id = "ElvisSkillsActions",
						Title = "ELVIS Skills Actions",
						Template = GroupTemplateLibrary.SimpleTemplate,
						Controls = new ControlDefinition[] 
										{
											new ButtonDefinition() {
													Id="AddElvisSkills",
													Title="Add",
													CommandJavaScript = "$.SkillSet.GetCategoryValue()",
													CommandEnableJavaScript = "$.RMAdmin._isAddButtonEnabled",
													Image=ImageLibrary.GetStandardImage(8, 5, revision)
											},
											new ButtonDefinition() {
													Id="UpdateElvisSkills",
													Title="Update",
													CommandJavaScript = "$.SkillSet.GetUpdatedCategoryValue()",
													CommandEnableJavaScript = "$.RMAdmin._isUpdateButtonEnabled",
													Image=ImageLibrary.GetStandardImage(0, 1, revision)
											},
											new ButtonDefinition()
											{
													Id="ResetElvisSkills",
													Title="Reset",
													CommandJavaScript = "$.SkillSet.Reset()",
													CommandEnableJavaScript = "$.RMAdmin._isResetElvisButtonEnabled",
													Image=MapImageLibrary.GetFormatMapImage(12,13, revision)
											}
									}
					});
			}
		}

		private void AddResourceTypeRibbonButtons(bool hasAccessToEditResourceType)
		{
			var controlList = new List<ControlDefinition> { 
													new ButtonDefinition()
													{
														Id="CloseGrid",
														Title="Close",
														CommandJavaScript = "$.RMAdmin.Close()",
														CommandEnableJavaScript = "true",
														Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
													}			
			};

			if (hasAccessToEditResourceType)
			{
				controlList.Insert(0, new ButtonDefinition()
				{
					Id = "SaveResourceType",
					Title = "Save",
					CommandJavaScript = "$.RMAdmin.SaveData()",
					CommandEnableJavaScript = "$.RMAdmin._isSaveButtonEnabled",
					Image = ImageLibrary.GetStandardImage(0, 10, revision)
				});

				controlList.Insert(0, new ButtonDefinition()
				{
					Id = "CancelResourcetype",
					Title = "Cancel",
					CommandJavaScript = "$.RMAdmin.Cancel()",
					CommandEnableJavaScript = "$.RMAdmin._isCancelButtonEnabled",
					Image = ImageLibrary.GetStandardImage(6, 12, revision)
				});
			}

			PageGroups.Add(new GroupDefinition()
			{
				Id = "PermissionsActions",
				Title = "Resource Type Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = controlList.ToArray()
			});
		}
	}
}
