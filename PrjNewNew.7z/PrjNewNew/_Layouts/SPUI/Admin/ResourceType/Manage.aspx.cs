﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Admin
{
	public partial class Manage : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ResourceTypeAdministration; } }

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
		}

		public override TabDefinition GetTabDefinition()
		{
			AddRibbonButtons();

			return new TabDefinition()
			{
				Id = "Permissions",
				Title = "Resource Type List",
				Groups = PageGroups.ToArray()
			};
		}

		private void AddRibbonButtons()
		{
			var hasAccessToEditResourceType = RmFunction.HasPermissionToFunction(RmFunction_E.Edit_Resource_Types, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
			hdnHasAccessToEditResourceType.Value = hasAccessToEditResourceType.GetIntAsStringFromBool();

			var ribbonButtonList = new List<ControlDefinition>{
				new ButtonDefinition()
				{
					Id="EditResourceRequest",
					Title= hasAccessToEditResourceType ? "Update Resource Type": "View Resource Type",
					CommandJavaScript = "resTypeListNs.EditResourceRequestType();",
					CommandEnableJavaScript = "resTypeListNs.IsEditResourceRequestTypeButtonEnabled()",
					Image=MapImageLibrary.GetRMImage(0, 15, revision)
				}
			};

			if (hasAccessToEditResourceType)
			{
				ribbonButtonList.Insert(0, new ButtonDefinition()
				{
					Id = "AddResourceRequest",
					Title = "Add new resource type",
					CommandJavaScript = "resTypeListNs.AddResourceRequestType();",
					CommandEnableJavaScript = "resTypeListNs.IsAddResourceRequestTypeButtonEnabled()",
					Image = MapImageLibrary.GetRMImage(1, 15, revision)
				});
				ribbonButtonList.Add(new ButtonDefinition()
				{
					Id = "DeleteResourceRequest",
					Title = "Delete resource type",
					CommandJavaScript = "resTypeListNs.DeleteResoureceType();",
					CommandEnableJavaScript = "resTypeListNs.IsDeleteResourceRequestTypeButtonEnabled()",
					Image = MapImageLibrary.GetRMImage(2, 15, revision)
				});
			}

			PageGroups.Add(new GroupDefinition()
			{
				Id = "ResourceRequestType",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = ribbonButtonList.ToArray()
			});
		}
	}
}