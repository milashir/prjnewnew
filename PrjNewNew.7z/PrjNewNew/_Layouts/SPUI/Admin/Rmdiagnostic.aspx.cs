﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Config;
using Quintiles.RM.Clinical.Domain.Models.Dashboard;
using Quintiles.RM.Clinical.Domain.Models.ServerProcessMap;
using Quintiles.RM.Clinical.Domain.Notification;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.Commands;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching;
using Quintiles.RM.Clinical.Domain.UserManagement;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.SharePoint.WCF;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;
using domain = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class RmDiagnostic : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.RmDiagnostic; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			//DateTime startDate = new DateTime(2020, 11, 1);
			//int daysToAdd = 122;
			//int countryId = 245;
			//Response.Write(countryId.ToString());
			//var cacheSvc = new RmCacheService();
			//var sw = System.Diagnostics.Stopwatch.StartNew();
			//for (int i = 0; i <= 365; i++)
			//{
			//	cacheSvc.IsBusinessDayV2(startDate.AddDays(i), countryId);
			//	//for (int j = 0; j <= daysToAdd; j++)
			//	//{
			//	//	CalculatorUtility.GetBusinessDaysV2(startDate.AddDays(i), startDate.AddDays(i + j), countryId);
			//	//}
			//}
			//sw.Stop();
			//Response.Write(string.Format("New function took {0}<br>", sw.ElapsedMilliseconds));

			//sw.Restart();
			//for (int i = 0; i <= 265; i++)
			//{
			//	cacheSvc.IsBusinessDay(startDate.AddDays(i), countryId);
			//	//for (int j = 0; j <= daysToAdd; j++)
			//	//{
			//	//	CalculatorUtility.GetBusinessDays(startDate.AddDays(i), startDate.AddDays(i + j), countryId);
			//	//}
			//}
			//Response.Write(string.Format("Old function took {0}<br><br><br>", sw.ElapsedMilliseconds));


			//Response.Write(string.Format("Veryfying old and new function output...<br><br><br>", sw.ElapsedMilliseconds));
			//for (int i = 0; i <= 31; i++)
			//{
			//	if (cacheSvc.IsBusinessDay(startDate.AddDays(i), countryId) != cacheSvc.IsBusinessDayV2(startDate.AddDays(i), countryId))
			//	{
			//		Response.Write(string.Format("Old value:{0}, new value:{1} for date: {2} <br>", startDate.AddDays(i).ToQDateString()));
			//	}
			//	//for (int j = 0; j <= daysToAdd; j++)
			//	//{
			//	//	var oldDays = CalculatorUtility.GetBusinessDays(startDate.AddDays(i), startDate.AddDays(i + j), countryId);
			//	//	var newDays = CalculatorUtility.GetBusinessDaysV2(startDate.AddDays(i), startDate.AddDays(i + j), countryId);
			//	//	if (oldDays != newDays)
			//	//	{
			//	//		Response.Write(string.Format("Old days:{0}, new days:{1} for startdate: {2} and stopdate:{3}<br>",
			//	//			oldDays, newDays, startDate.AddDays(i).ToQDateString(), startDate.AddDays(i + j).ToQDateString()));
			//	//	}
			//	//}
			//}
			//Response.Write(string.Format("Done veryfying old and new function output.<br><br><br>", sw.ElapsedMilliseconds));

			errorDiv.InnerHtml = string.Empty;
			errorDiv.Visible = false;
			outputDiv.InnerHtml = string.Empty;
			outputDiv.Visible = false;

			PopulateWindowsServiceProcessList();
		}

		private void PopulateWindowsServiceProcessList()
		{
			var enumVlaues = Enum.GetValues(typeof(WindowsServiceProcess_E));
			foreach (var enumVal in enumVlaues)
			{
				lstWinSrvProc.Items.Add(new ListItem(enumVal.ToString(), ((int)enumVal).ToString()));
			}
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "Rmdiag",
				Title = "RM Diagnostics",
				Groups = PageGroups.ToArray()
			};
		}
		protected void BtnTestEmail_Click(object sender, System.EventArgs e)
		{
			try
			{
				NotificationService.SendTestEmail();
				ShowMessage("Test email sent sucessfully");
			}
			catch (Exception ex) { ShowError(ex); }
		}

		protected void BtnTestNotificationById_Click(object sender, System.EventArgs e)
		{
			try
			{
				int? notificationId = NotificationId.Text.ToInt();
				if (notificationId.HasValue)
				{
					NotificationService.ProcessNotificationByNotificationId(notificationId.GetValueOrDefault());
					ShowMessage("Notification sent sucessfully");
				}
				else
				{
					ShowError("Only numberic notificationIds are supported");
				}
			}
			catch (Exception ex) { ShowError(ex); }
		}
		protected void BtnPurgeCache_Click(object sender, System.EventArgs e)
		{
			try
			{
				CacheService.ClearCache();
				ShowMessage("Cache cleared sucessfully");
			}
			catch (Exception ex) { ShowError(ex); }
		}

		protected void DebugCacheRequestService_Click(object sender, System.EventArgs e)
		{
			if (EnvironmentSpecificConfig.IsProductionServer)
			{
				ShowError("This function is disabled on production");
			}
			else
			{
				try
				{
					//var reqSched = new RequestScheduler(new SchedulerService(GraphContext.Cache), new RmCacheService(), true, null, null, true, GraphContext.Cache);

					//var reqIDList = new List<int>
					//{
					//	655686, 655685, 655684, 655683, 655682, 655678, 655677,
					//	655676, 655675, 655673, 655671, 655670, 655669, 655668,
					//	655667, 655666, 655663, 655652, 655651, 655650, 655649,
					//	655648, 655644, 655643, 655642, 655641, 655640, 655639,
					//	655638, 655637, 655636, 655635
					//};

					//reqSched.ProcessRequests(reqIDList);
				}
				catch (Exception ex) { ShowError(ex); }
			}
		}

		protected void DebugCacheResourceService_Click(object sender, System.EventArgs e)
		{
			if (EnvironmentSpecificConfig.IsProductionServer)
			{
				ShowError("This function is disabled on production");
			}
			else
			{
				try
				{
					////Get set of stale resources and convert into array of ids
					//var resourceList = new List<int> { 2479, 3128, 4, 44 }; // StaleResourceQueue.GetResourceIdsFromStaleResourceQueue(200).Values.ToList();

					//ISchedulerService schedulerService = new SchedulerService(Domain.GraphContext.Cache);

					//ResourceScheduler rc = new ResourceScheduler(schedulerService, new RmCacheService(), null, schedulerService.CutoffDateBasedOnContext, schedulerService.GetResourceCacheEndDate());
					//rc.ProcessResources(resourceList);
				}
				catch (Exception ex) { ShowError(ex); }
			}

		}

		protected void DebugPpmDateService_Click(object sender, System.EventArgs e)
		{
			if (EnvironmentSpecificConfig.IsProductionServer)
			{
				ShowError("This function is disabled on production");
			}
			else
			{
				//try
				//{
				//	var filePath = "C:\\Users\\Q773188\\Desktop\\Serialized PPM data\\PPMData.xml";
				//	filePath = "C:\\Users\\Q773188\\Desktop\\PPMProject.xml";
				//	using (var r = new System.IO.FileStream(filePath, System.IO.FileMode.Open))
				//	{
				//		var se = new Quintiles.RM.Clinical.SharePoint.WCF.PPMDataService();
				//		se.PublishPPMProject((PPMData)new System.Runtime.Serialization.DataContractSerializer(typeof(PPMData)).ReadObject(r));
				//	}
				//	ShowMessage("Project processed sucessfully");
				//}
				//catch (Exception ex) { ShowError(ex); }		
			}
		}

		protected void BtnSyncSingleUserFromAd_Click(object sender, System.EventArgs e)
		{
			try
			{
				int? notificationId = NotificationId.Text.ToInt();
				if (!string.IsNullOrEmpty(txtQid.Text))
				{
					DbHelp.ExecuteNonQueryText(string.Format(@"INSERT  INTO dbo.AdRefreshRmUserQueue
        ( RmUserId ,
          LastModifiedBy ,
          LastModifiedOn ,
          CreatedBy ,
          CreatedOn
        )
        SELECT  RU.RmUserId ,
                '{0}' ,
                GETDATE() ,
                '{0}' ,
                GETDATE()
        FROM    dbo.RmUser RU
                LEFT JOIN dbo.AdRefreshRmUserQueue ARRUQ ON ARRUQ.RmUserId = RU.RmUserId
        WHERE   QId = '{1}'
                AND ARRUQ.AdRefreshRmUserQueueId IS NULL;", DbSafe.EscapeQuote(ExtensionMethods.GetCurrentUserQid()), DbSafe.EscapeQuote(txtQid.Text)));
					ShowMessage(string.Format("User marked for active directory sync. Information will be sunced in approximately {0} minutes.", ConfigValue.SyncSingleUserFromActiveDirectoryProcessInterval));
				}
				else
				{
					ShowError("Qid is required");
				}
			}
			catch (Exception ex) { ShowError(ex); }
		}

		protected void BtnSyncUsersIsActiveAndGroupsFromAd_Click(object sender, System.EventArgs e)
		{
			try
			{
				int? notificationId = NotificationId.Text.ToInt();
				if (!string.IsNullOrEmpty(txtQid.Text))
				{
					using (var adServic = new ActiveDirectoryService(true))
					{
						var sw = new System.Diagnostics.Stopwatch();
						sw.Start();
						adServic.Process();
						sw.Stop();
						ShowMessage(string.Format("User information and groups have been synced from AD. Processed in {0} seconds.", sw.Elapsed.TotalSeconds));
					}
				}
				else
				{
					ShowError("Qid is required");
				}
			}
			catch (Exception ex) { ShowError(ex); }
		}

		protected void BtnReprocessCtmsMessageById_Click(object sender, System.EventArgs e)
		{
			try
			{
				int? siteMessageId = SiteMessageId.Text.ToInt();
				if (siteMessageId.HasValue)
				{
					var svs = new SiteVisitService().ProcessMessage(siteMessageId.GetValueOrDefault());
					ShowMessage(string.Format("Sitemessage id {0} processed successfully.", SiteMessageId.Text));
				}
				else
				{
					ShowError("Enter integer value for SiteMessageId.");
				}
			}
			catch (Exception ex) { ShowError(ex); }
		}
		protected void BtnResendNotifications_Click(object sender, System.EventArgs e)
		{
			try
			{
				int? startnotificationLogId = txtStartnotificationLogId.Text.ToInt();
				int? endnotificationLogId = txtEndnotificationLogId.Text.ToInt();
				if (!endnotificationLogId.HasValue) { endnotificationLogId = startnotificationLogId; }

				if (startnotificationLogId.HasValue && endnotificationLogId.HasValue)
				{
					ShowMessage(string.Format("Process started: {0}", DateTime.Now));

					var failedNotifications = NotificationLog.FindAll(DetachedCriteria.For<NotificationLog>().Add(Expression.Between("id", startnotificationLogId, endnotificationLogId)));


					if (failedNotifications != null)
					{
						ShowMessage(string.Format("Emails to process: {0}", failedNotifications.Length));

						foreach (var failedNotification in failedNotifications)
						{
							try
							{
								var templatedEmailMessage = new EmailMessage("noreply-QRPM@quintiles.com",
									failedNotification.ToAddress.Split(new char[] { ',' }).ToList(),
									failedNotification.MessageSubject,
									failedNotification.Body,
									(System.Net.Mail.MailPriority)failedNotification.Importance);

								if (!string.IsNullOrWhiteSpace(failedNotification.CcAddress))
								{
									templatedEmailMessage.CcAddressList = failedNotification.CcAddress.Split(new char[] { ',' }).ToList();
								}

								new EmailNotification(templatedEmailMessage).Send();
							}
							catch (Exception ex)
							{

								ShowError(string.Format("Error occured while sending notificationId: {0}", failedNotification.Id));
								ShowError(string.Format("Error occured: {0}", ex.Message));
							}
						}
					}

					ShowMessage(string.Format("Process completed: {0}", DateTime.Now));

					ShowMessage("Notification(s) processed successfully.");
				}
				else
				{
					ShowError("Only integer values are allowed in NotificationLogId.");
				}
			}
			catch (Exception ex) { ShowError(ex); }
		}
		private void ShowMessage(string message)
		{
			outputDiv.InnerHtml = message;
			outputDiv.Visible = true;
		}

		private void ShowError(Exception ex)
		{
			ShowError(string.Format("{0}<br/><br/>{1}", ex.Message, ex.StackTrace));
		}

		private void ShowError(string errorMessage)
		{
			errorDiv.InnerHtml = errorMessage;
			errorDiv.Visible = true;
		}

		protected void TriggerWindowsServiceProcess_Click(object sender, System.EventArgs e)
		{
			if (EnvironmentSpecificConfig.IsProductionServer)
			{
				ShowError("This function is disabled on production");
			}
			else
			{
				try
				{
					var message = "";
					int procId;
					if (int.TryParse(lstWinSrvProc.SelectedValue, out procId))
					{
						var process = (WindowsServiceProcess_E)procId;
						switch (process)
						{
							case WindowsServiceProcess_E.AutoGenerateCentralizedMonitoringLeadFromCl:
								domain.Request.AutoGenerateCentralizedMonitoringLeadFromCl();
								break;
							case WindowsServiceProcess_E.RecalculateWeeklyHoursFromResourceCountry:
								message = "Currently code does not suport triggering this service manually.";
								break;
							case WindowsServiceProcess_E.CreateAutoBackfillRequestsForAllInactiveResource:
								message = "Process completed successfully.";
								break;
							case WindowsServiceProcess_E.RunStatisticalTieringAlgorithm:
								new RunStatisticalTieringAlgorithmCommand().Run();
								message = "Process completed successfully.";
								break;
							case WindowsServiceProcess_E.PopulateFteChanges:
								AuditData.PopulateCalculatorChanges(ConfigValue.FteChangeDuration);
								break;
							case WindowsServiceProcess_E.MarkAllRequestAndResourcesForReCachingOnFirstOfEveryMonth:
								break;
							case WindowsServiceProcess_E.MarkAllMonitoringRequestForCachingEveryDay:
								domain.Request.MarkAllMonitoringRequestForCachingEveryDay();
								break;
							case WindowsServiceProcess_E.MarkReqeustsWithErrorsAsStale:
							case WindowsServiceProcess_E.ProcessStaleRequests:
							case WindowsServiceProcess_E.ProcessStaleResources:
							case WindowsServiceProcess_E.SendSiteTiertoCtms:
								message = "This service is configured to run frequently. There is no need to trigger this service manually.";
								break;
							case WindowsServiceProcess_E.SendNotifications:
							case WindowsServiceProcess_E.SyncFromActiveDirectory:
							case WindowsServiceProcess_E.SyncSingleUserFromActiveDirectory:
								message = "Use separate options listed on this page to trigger this service.";
								break;
							case WindowsServiceProcess_E.UpdateMetricValuesFromCtms:
								new UpdateMetricValuesFromCtmsCommand().Run();
								message = "Process completed successfully.";
								break;
							default:
								message = "Select a service to run.";
								break;
						}
					}
					else
					{
						message = "Select a service to run.";
					}

					if (!string.IsNullOrEmpty(message)) { ShowError(message); }
				}
				catch (Exception ex) { ShowError(ex); }
			}
		}

		protected void MigrateToRbm_Click(object sender, EventArgs e)
		{
			if (EnvironmentSpecificConfig.IsProductionServer)
			{
				ShowError("This function is disabled on production");
			}
			else
			{
				var projectId = txtProjectId.Text.ToInt();
				if (!projectId.HasValue)
				{ ShowError("Please enter numeric project id"); }
				else
				{
					try
					{
						var project = Project.Find(projectId);
						new RbmConverter(project, ExtensionMethods.GetCurrentUserQid(), ConfigValue.SiteTierPropotionAlgorithmForNonRbmToRbmConversion).ConvertToRbm();
						ShowMessage("Project RBM migration completed successfully.");
					}
					catch (Exception ex) { ShowError(ex.Message); }
				}
			}
		}
		protected void MigrateToNonRbm_Click(object sender, EventArgs e)
		{
			if (EnvironmentSpecificConfig.IsProductionServer)
			{
				ShowError("This function is disabled on production");
			}
			else
			{
				var projectId = txtProjectId.Text.ToInt();
				if (!projectId.HasValue)
				{ ShowError("Please enter numeric project id"); }
				else
				{
					try
					{
						var project = Project.Find(projectId);
						new RbmConverter(project, ExtensionMethods.GetCurrentUserQid()).ConvertToNonRbm();
						ShowMessage("Project Non-RBM migration completed successfully.");
					}
					catch (Exception ex) { ShowError(ex.Message); }
				}
			}
		}

		protected void Encrypt_Click(object sender, EventArgs e)
		{
			ShowMessage(RmAesEncryptor.Encrypt(txtInput.Text));
		}
	}
}
