﻿using System;
using System.Linq;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Permissions
{
	public partial class View : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ViewPagePermissions; } }
		public bool NewJobRoleAdded { get; private set; }

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			lblRoles.Text = string.Join(", ", UserCache.Usr.UserRoleList.Select(sr => sr.Name).OrderBy(i => i).ToArray());
			lblUserName.Text = UserCache.Usr.Name;
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Role Permissions",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
