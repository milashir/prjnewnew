﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.UI.UserControls;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class GraphExecPath : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.GraphExecPath; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			//RenderRibbon();
		}
		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "ManCache",
				Title = "Manual Caching",
				Groups = PageGroups.ToArray()
			};
		}
		//private void RenderRibbon()
		//{
		//	var ucRibbonCtrl = (RmRibbonControl)Master.FindControl("ucRibbon");
		//	if (ucRibbonCtrl != null)
		//	{
		//		ucRibbonCtrl.RibbonControlData = new RmRibbon { Tabs = new List<TabDefinition> { GetTabDefinition(), GetTabDefinitaion2() } };
		//	}
		//}

		//public TabDefinition GetTabDefinition()
		//{
		//	var PageGroups = new List<GroupDefinition>();
		//	PageGroups.Add(new GroupDefinition()
		//	{
		//		Id = "GridActions",
		//		Title = "Actions for Selected Requests",
		//		Controls = new ControlDefinition[] {
		//												new ButtonDefinition() {
		//														Id="SaveGrid",
		//														Title="Save",
		//														CommandJavaScript = "testNs.SaveGrid();",
		//														CommandEnableJavaScript = "testNs.IsSaveEnabled();",
		//														Image=ImageLibrary.GetStandardImage(8,13, revision)
		//												},
		//												new FlyoutAnchorDefinition() {
		//														Id="RecentProjectsFlyoutAnchor",
		//														Title="Recent Projects",
		//														Image=ImageLibrary.GetStandardImage(1,11,revision),
		//														Controls = GetRecentProjects(),
		//														ControlsSize = ControlSize.Size16x16
		//												},
		//												new ButtonDefinition() {
		//														Id="CancelGrid",
		//														Title="Cancel",
		//														CommandJavaScript = "testNs.CancelGrid();",
		//														CommandEnableJavaScript = "testNs.IsCancelEnabled();",
		//														Image=ImageLibrary.GetStandardImage(6,12, revision)
		//												},
		//												new ButtonDefinition() {
		//														Id="EditRow",
		//														Title="Modify Request",
		//														CommandJavaScript = "testNs.EditSelectedRow();",
		//														CommandEnableJavaScript = "testNs.EditSelectedRowEnabled();",
		//														Image=MapImageLibrary.GetPSImage(3,11, revision)
		//												},
		//												new FlyoutAnchorDefinition() {
		//														Id="RecentProjectsFlyoutAnchorAdditional",
		//														Title="Recent Projects2",
		//														Image=ImageLibrary.GetStandardImage(1,11,revision),
		//														Controls = GetRecentProjects(),
		//														ControlsSize = ControlSize.Size16x16
		//												},
		//												new ButtonDefinition() {
		//															Id="EditMultipleRow",
		//															Title="Modify Requests",
		//															CommandJavaScript = "testNs.ModifyMultipleRequests();",
		//															CommandEnableJavaScript = "testNs.ModifyMultipleRowsEnabled();",
		//															Image=MapImageLibrary.GetPSImage(3,11, revision)
		//												},
		//												new ButtonDefinition() {
		//														Id="RemoveRow",
		//														Title="Delete Request",
		//														CommandJavaScript = "testNs.DeleteSubmittedRequests();",
		//														CommandEnableJavaScript = "testNs.RemoveSelectedRowEnabled();",
		//														Image=MapImageLibrary.GetFormatMapImage(6,0, revision)
		//												},
		//												 new ButtonDefinition() {
		//														Id="TerminateRow",
		//														Title="Terminate Request",
		//														CommandJavaScript = "testNs.TerminateSelectedRow();",
		//														CommandEnableJavaScript = "testNs.TerminateSelectedRowEnabled();",
		//														Image=MapImageLibrary.GetFormatMapImage(12,13, revision)
		//												}
		//										}
		//	});

		//	PageGroups.Add(new GroupDefinition()
		//	{
		//		Id = "ReturnRequestAction",
		//		Title = "Return Queried Request Actions",
		//		Controls = new ControlDefinition[]
		//								{   
		//												new ButtonDefinition() {
		//														Id="ReturnRequest",
		//														Title="New Query Request form",
		//														CommandJavaScript = "testNs.ReturnRequest();",
		//														CommandEnableJavaScript = "testNs.ReturnRequestEnabled();",
		//														Image=MapImageLibrary.GetPSImage(5,1, revision)
		//												},
		//												new ButtonDefinition()
		//												{
		//														Id="SaveReturnRequest",
		//														Title="Return Queried Request",
		//														CommandEnableJavaScript = "testNs.SaveButtonEnabled()",
		//														CommandJavaScript = "testNs.Save()",
		//														Image=MapImageLibrary.GetFormatMapImage(5,1, revision)
		//												},
		//												new ButtonDefinition()
		//												{
		//														Id="CancelReturnRequest",
		//														Title="Cancel Query Form",
		//														CommandJavaScript = "testNs.Cancel()",
		//														CommandEnableJavaScript = "testNs.CancelButtonEnabled()",
		//														Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
		//												},
		//												new ButtonDefinition()
		//												{
		//														Id="CloseReturnRequest",
		//														Title="Close Query Form",
		//														CommandJavaScript = "testNs.Close()",
		//														CommandEnableJavaScript = "testNs.CloseButtonEnabled()",
		//														Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
		//												}
		//								}
		//	});

		//	PageGroups.Add(new GroupDefinition()
		//	{
		//		Id = "BackfillAction",
		//		Title = "Backfill Actions for Assigned Resources",
		//		Controls = new ControlDefinition[]
		//								{   
		//									new ButtonDefinition() {
		//											Id="PermanentBackfill",
		//											Title="Create Permanent Backfill Request",
		//											CommandJavaScript = "testNs.PermanentBackfill();",
		//											CommandEnableJavaScript = "testNs.PermanentBackfillEnabled();",
		//											Image=MapImageLibrary.GetFormatMapImage(2,5, revision)
		//									},
		//									new ButtonDefinition()
		//									{
		//											Id="SubmitBackfillRequest",
		//											Title="Save Backfill Request",
		//											CommandJavaScript = "testNs.CreateBackfillRequest();",
		//											CommandEnableJavaScript = "testNs.SubmitButtonEnabled();",
		//											Image=MapImageLibrary.GetFormatMapImage(15,0, revision)
		//									},
		//									new ButtonDefinition()
		//									{
		//											Id="CancelBackfillRequest",
		//											Title="Cancel Backfill Request",
		//											CommandJavaScript = "testNs.HideBackfillForm();",
		//											CommandEnableJavaScript = "testNs.CancelButtonEnabled();",
		//											Image=MapImageLibrary.GetFormatMapImage(15,1, revision)
		//									},
		//							}
		//	});

		//	return new TabDefinition()
		//	{
		//		Id = "RequestRibbon",
		//		Title = "Submitted Requests",
		//		Groups = PageGroups.ToArray()
		//	};
		//}

		//private ButtonDefinition[] GetRecentProjects()
		//{
		//	var rv = new List<ButtonDefinition>();
		//	for (int i = 0; i < 8; i++)
		//	{
		//		rv.Add(new ButtonDefinition()
		//			{
		//				Id = i.ToString(),
		//				Title = "Project - " + i.ToString(),
		//				CommandJavaScript = "ChangeProject('" + ("Project - " + i.ToString()).ToString().Replace(@"\", @"\\").Replace("'", @"\'") + @"');"
		//			});
		//	}

		//	return rv.ToArray();
		//}

		//public TabDefinition GetTabDefinitaion2()
		//{
		//	var PageGroups = new List<GroupDefinition>();
		//	PageGroups.Add(new GroupDefinition()
		//	{
		//		Id = "BookingActions",
		//		Title = "Action for Request",
		//		Controls = new ControlDefinition[]
		//		{
		//			new ButtonDefinition() 
		//			{
		//					Id="Assignments",
		//					Title="Modify Request",
		//					CommandJavaScript = "testNs.editSelectedRequest();",
		//					CommandEnableJavaScript = "testNs.editSelectedRequestEnabled();",
		//					Image=MapImageLibrary.GetPSImage(3,11, revision)
		//			}
		//		}
		//	});
		//	return new TabDefinition()
		//	{
		//		Id = "TestRibbon",
		//		Title = "New Requests",
		//		Groups = PageGroups.ToArray()
		//	};
		//}
	}
}
