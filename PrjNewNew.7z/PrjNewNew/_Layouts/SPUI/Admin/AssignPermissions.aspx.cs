﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Common = Quintiles.RPM.Common;
namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class AssignPermissions : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.Permissions; } }
		public string SelectedUser { get; set; }
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			if (!Page.IsPostBack)
			{
				var resourceTypeOrgOrgUnitList = ResourceType.GetResourceTypeOrganizationOrganizationalUnitList();
				List<Organization_WS> orgOrgUnitList = Organization.GetOrganizationOrganizationalUnitList();
				List<int> orgIds = orgOrgUnitList.Select(x => x.Id).Distinct().ToList();
				List<int> resourceTypeOrgIdsList = resourceTypeOrgOrgUnitList.Select(x => x.OrganizationId).Distinct().ToList();

				foreach (var orgId in resourceTypeOrgIdsList)
				{
					var orgName = resourceTypeOrgOrgUnitList.Where(x => x.OrganizationId == orgId).Select(item => item.OrganizationName).First();

					TreeNode root = new TreeNode();  // Creating new root node
					root.Text = orgName;
					root.Value = orgId.ToString();
					listBoxResourceRequestType.Nodes.Add(root); //Adding the root node
					root.Expanded = false;
					root.SelectAction = TreeNodeSelectAction.Expand;

					//var orgUnitListData = resourceTypeOrgOrgUnitList.Where(x => x.OrganizationId == orgId).ToList();
					var orgUnitIds = resourceTypeOrgOrgUnitList.Where(x => x.OrganizationId == orgId).OrderBy(x => x.OrganizationUnitName).Select(item => item.OrganizationUnitId).Distinct().ToList();
					foreach (var orgUnitId in orgUnitIds)
					{
						var orgUnitData = resourceTypeOrgOrgUnitList.Where(x => x.OrganizationUnitId == orgUnitId).Select(item => new { item.OrganizationUnitName, item.OrganizationUnitId }).First();
						TreeNode child = new TreeNode(); // creating child node
						child.Text = orgUnitData.OrganizationUnitName;
						child.Value = orgUnitData.OrganizationUnitId.ToString();
						root.ChildNodes.Add(child);

						var rrtListIds = resourceTypeOrgOrgUnitList.Where(x => x.OrganizationUnitId == orgUnitId).OrderBy(x => x.ResourceTypeName).Select(item => item.ResourceTypeId).ToList();

						foreach (var rrtIds in rrtListIds)
						{

							var rrtListData = resourceTypeOrgOrgUnitList.Where(x => x.ResourceTypeId == rrtIds).Select(item => item.ResourceTypeName).First();
							TreeNode rrtchild = new TreeNode(); // creating child node
							rrtchild.Text = rrtListData;
							rrtchild.Value = rrtIds.ToString();
							child.ChildNodes.Add(rrtchild);
						}
					}
				}


				// Organizations
				foreach (var items in orgIds)
				{
					var orgName = orgOrgUnitList.Where(x => x.Id == items).Select(item => item.Name).First();
					TreeNode root = new TreeNode();
					root.Text = orgName;
					root.Value = items.ToString();
					listOrganization.Nodes.Add(root);
					root.Expanded = false;
					root.SelectAction = TreeNodeSelectAction.Expand;

					var subList = orgOrgUnitList.Where(x => x.Id == items).ToList();
					foreach (var childItem in subList)
					{
						TreeNode child = new TreeNode()
						{
							Text = childItem.OrganizationalUnitName,
							Value = childItem.OrganizationalUnitId.ToString(),
							Expanded = false,
						};
						root.ChildNodes.Add(child);
					}
				}

				// Tree
				AddChildNodes(treeViewPermissions.Nodes, Region.FindAll().OrderBy(t => t.Name).Cast<ICodeTable>());
				InitUserData(); // Init with default User
			}
			else if (Request["__EVENTTARGET"] == updatePanel1.ClientID) // Grid Change Row
			{
				string evtArg = Request["__EVENTARGUMENT"];
				if (evtArg == "UserRowChange")
				{
					foreach (TreeNode cbResTypeOrg in listBoxResourceRequestType.Nodes) // RRT Organization
					{
						cbResTypeOrg.Checked = false;
						foreach (TreeNode cbResTypeOrgUnit in cbResTypeOrg.ChildNodes) // RRT
						{
							cbResTypeOrgUnit.Checked = false;
							foreach (TreeNode cbResTypes in cbResTypeOrgUnit.ChildNodes)
							{
								cbResTypes.Checked = false;
							}
						}
					}

					foreach (TreeNode cbOrg in listOrganization.Nodes)
					{
						cbOrg.Checked = false;
						foreach (TreeNode cbOrgUnit in cbOrg.ChildNodes)
						{
							cbOrgUnit.Checked = false;
						}
					}

					foreach (TreeNode tnRegion in treeViewPermissions.Nodes) // Region
					{
						tnRegion.Checked = false;
						foreach (TreeNode tnSubRegion in tnRegion.ChildNodes) // SubRegion
						{
							tnSubRegion.Checked = false;
							foreach (TreeNode tnCountry in tnSubRegion.ChildNodes) tnCountry.Checked = false;
						}
					}

					InitUserData(); // init with user selected in Grid

					// Set unshared resource types to gray color
					if (!string.IsNullOrEmpty(this.hdUnsharedResourceType.Value) || !string.IsNullOrEmpty(this.hdUnsharedOrganizationUnit.Value) || !string.IsNullOrEmpty(this.hdUnsharedCountries.Value))
					{
						System.Web.UI.ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "MyFun1", "SetResourceTypeColor();", true);
					}
					if (hdSelectedUserList.Value.Split(',').Length == 1)
					{
						ScriptManager.RegisterStartupScript(Page, this.GetType(), "MyFunforcss", "setSingleUserSelectedStyle();", true);
						System.Web.UI.ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "MyFunforcss", "setSingleUserSelectedStyle();", true);
					}
				}
				else if (evtArg == "SaveUser")
				{
					btnSave_Click();
				}
			}
		}

		private void InitUserData(string qid = null, string userName = null)
		{
			this.hdUnsharedCountries.Value = string.Empty;
			this.hdUnsharedOrganizationUnit.Value = string.Empty;
			this.hdUnsharedResourceType.Value = string.Empty;
			if (!string.IsNullOrEmpty(qid))
			{
				RmUser usr = GetUser(qid, userName);

				this.hdSelectedUserRMUserId.Value = usr.Id.ToString();
				this.hdSelectedUserQId.Value = usr.QId;
				this.hdSelectedUserList.Value = usr.Name;

				foreach (TreeNode cbResTypeOrg in listBoxResourceRequestType.Nodes) // RRT Organization
				{
					cbResTypeOrg.Checked = false;
					foreach (TreeNode cbResTypeOrgUnit in cbResTypeOrg.ChildNodes) // RRT
					{
						cbResTypeOrgUnit.Checked = false;
						foreach (TreeNode cbResTypes in cbResTypeOrgUnit.ChildNodes)
						{
							cbResTypes.Checked = false;
						}
					}
				}

				foreach (TreeNode cbOrg in listOrganization.Nodes)
				{
					cbOrg.Checked = false;
					foreach (TreeNode cbOrgUnit in cbOrg.ChildNodes)
					{
						cbOrgUnit.Checked = false;
					}
				}

				foreach (TreeNode tnRegion in treeViewPermissions.Nodes) // Region
				{
					tnRegion.Checked = false;
					foreach (TreeNode tnSubRegion in tnRegion.ChildNodes) // SubRegion
					{
						tnSubRegion.Checked = false;
						foreach (TreeNode tnCountry in tnSubRegion.ChildNodes) tnCountry.Checked = false;
					}
				}

			}
			else if (string.IsNullOrEmpty(hdSelectedUserRMUserId.Value))
			{
				// !Postback - default to current user
				this.hdSelectedUserRMUserId.Value = UserCache.Usr.Id.ToString();
				this.hdSelectedUserQId.Value = UserCache.Usr.QId;
				this.hdSelectedUserList.Value = UserCache.Usr.Name;

			}

			GetDataForUsers();//SS:Load data for users
			#region Load Grant All Values
			string evtArg = Request["__EVENTARGUMENT"];
			if (evtArg != "UserRowChange") LoadGrantAllRmUser(UserCache.Usr.Id.ToString(), true);
			else
				LoadGrantAllRmUser(hdSelectedUserRMUserId.Value, false);
			#endregion
		}

		private void LoadGrantAllRmUser(string GrantAllRmUserId, bool isCurrentUser)
		{
			string[] grantValue = RmUser.getGrantAllPermissions(GrantAllRmUserId, isCurrentUser);
			if (grantValue.Length > 0)
			{
				chkGrantAllOrg.Style.Add("background-color", "none");
				chkGrantAllCountry.Style.Add("background-color", "none");
				chkGrantAllRequestType.Style.Add("background-color", "none");
				chkGrantAllOrg.Checked = false;
				chkGrantAllCountry.Checked = false;
				chkGrantAllRequestType.Checked = false;
				hdGrantAllOrg.Value = "0";
				hdGrantAllCountry.Value = "0";
				hdGrantAllResourceType.Value = "0";
				if (Convert.ToBoolean(grantValue[0])) chkGrantAllOrg.Checked = true;
				if (Convert.ToBoolean(grantValue[1])) chkGrantAllCountry.Checked = true;
				if (Convert.ToBoolean(grantValue[2])) chkGrantAllRequestType.Checked = true;
				if (!isCurrentUser)
				{
					if (chkGrantAllOrg.Checked == true && Convert.ToBoolean(grantValue[3]))
					{
						chkGrantAllOrg.Style.Add("background-color", "#404040");
						hdGrantAllOrg.Value = "1";
					} // Assign Background Color for Unshared Common User
					if (chkGrantAllCountry.Checked == true && Convert.ToBoolean(grantValue[4]))
					{
						chkGrantAllCountry.Style.Add("background-color", "#404040");
						hdGrantAllCountry.Value = "1";
					}
					if (chkGrantAllRequestType.Checked == true && Convert.ToBoolean(grantValue[5]))
					{
						chkGrantAllRequestType.Style.Add("background-color", "#404040");
						hdGrantAllResourceType.Value = "1";
					}
				}
			}
			System.Web.UI.ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "MyFun2", "initializeGrantAll();", true);
		}

		private RmUser GetUser(string qid, string userName)
		{
			if (qid != null)
			{
				return new RmUser(qid, userName, true);
			}
			else
			{
				if (hdRmUser.Value.Length == 0)
				{
					return UserCache.Usr;
				}
				else
				{
					return new RmUser(int.Parse(hdRmUser.Value));
				}
			}

			//MR: Icky Vincent syntax, replaced by above
			//return (qid != null ? new RmUser(qid, userName, true) : (hdRmUser.Value.Length == 0 ? // no user selected => get loged in user
			//					UserCache.Usr : new RmUser(int.Parse(hdRmUser.Value))));
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "PermissionsActions",
				Title = "Permissions Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="SelectUser",
                                Title="Add User",
                                CommandJavaScript = "permissionsNs.selectUser();",
                                CommandEnableJavaScript = (UserCache.Usr.IsAdmin || UserCache.Usr.IsSupport)? "true" : "false",
                               Image=MapImageLibrary.GetFormatMapImage(13,12, revision)
                            },
                            new ButtonDefinition() {
                                Id="SavePermission",
                                Title="Save Permissions",
                                CommandJavaScript = "permissionsNs.savePermission();",
                                CommandEnableJavaScript = "permissionsNs.enableSavePermissionButton();",
                                Image=ImageLibrary.GetStandardImage(0,10, revision)
                            },
                            new ButtonDefinition() {
                                Id="Export",
                                Title="Export",
                                CommandJavaScript = RmPageLinkHelper.GenerateReportUrl(((int)QueryToRun.RMUsers)),
                                CommandEnableJavaScript = "true;",
                                Image=ImageLibrary.GetStandardImage(0,11, revision)
                            }
                        }
			});

			PageGroups.Add(new GroupDefinition()
			{
				Id = "ReportActions",
				Title = "Report Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="ActionReport",
                                Title="User Permission Changes",
                                CommandJavaScript = RmPageLinkHelper.GenerateReportUrl(9),
                                CommandEnableJavaScript = "true;",
																Image=MapImageLibrary.GetFormatMapImage(5,0, revision)
                            }
                        }
			});

			return new TabDefinition()
			{
				Id = "Permissions",
				Title = "Permissions",
				Groups = PageGroups.ToArray()
			};
		}

		/// <summary>
		/// onclick Save button
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="ex"></param>
		protected void btnSave_Click()
		{
			SelectedUser = this.hdSelectedUserRMUserId.Value;
			if (string.IsNullOrEmpty(this.hdSelectedUserRMUserId.Value))
			{
				string saveMsg = "rm.ui.messages.showSuccess('Select a user to save permissions!')";
				ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "foo", saveMsg, true);
				return;
			}
			SaveDataForUsers();
		}

		protected int InsertCheckList(string sqlStart, CheckBoxList cblistBox, string user)
		{
			int countResType = 0;
			StringBuilder sql = new StringBuilder(sqlStart);
			foreach (ListItem checkBox in cblistBox.Items)
				if (checkBox.Selected)
				{
					if (countResType > 0)
						sql.Append(',');
					sql.Append(user + int.Parse(checkBox.Value).ToString() + ')'); // int.Parse to be sure you don't have sql injection
					countResType++;
				}
			//	if (countResType > 0)
			//DbHelp.ExecuteNonQueryText(sql.ToString());
			return countResType;
		}

		/// <summary>
		/// onclick Event Handler on User Selection dialog
		/// Find UserId in Rm database, including Create User if not found
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="ex"></param>
		protected void btnOk_click(object sender, EventArgs e)
		{
			//TODO: Fix this
			//if (peopleeditorUser.ResolvedEntities.Count > 0)
			//{
			//    PickerEntity selectedEntity = (PickerEntity)peopleeditorUser.ResolvedEntities[0];

			//    string Qid = Common.ExtensionMethods.GetQidFromFullyQualifiedName(selectedEntity.Key);

			//    // Try to find a correct UserName
			//    object oSip = selectedEntity.EntityData["SIPAddress"];
			//    object accountName = selectedEntity.EntityData["AccountName"];
			//    object email = selectedEntity.EntityData["Email"];
			//    if ((oSip == null) && (accountName == null) && (email == null))
			//        throw new Exception("SIPAddress, AccountName and Email are all NULL for the User selected with Qid=" + Qid);

			//    object sip = oSip ?? email;
			//    string userName = (sip == null ?
			//        accountName.ToString().Substring(accountName.ToString().LastIndexOf('\\') + 1) :
			//        sip.ToString().Substring(0, sip.ToString().IndexOf("@")).Replace(".", " "));

			//    // Insert in RmUser table if Qid doesn't exist
			//    InitUserData(Qid, userName);
			//}
		}

		private void AddChildNodes(TreeNodeCollection nodes, IEnumerable<ICodeTable> entities)
		{
			foreach (ICodeTable e in entities)
			{
				TreeNode tn = new TreeNode()
				{
					Text = e.Name,
					Value = e.Id.ToString(),
					Expanded = false,
					SelectAction = TreeNodeSelectAction.Expand
				};
				nodes.Add(tn);
				int id = Int32.Parse(tn.Value);
				if (tn.Depth == 0) // Add SubRegion
					AddChildNodes(tn.ChildNodes, Subregion.FindAll(DetachedCriteria.For(typeof(Subregion)).Add(Expression.Eq("Region.Id", id))).OrderBy(t => t.Name).Cast<ICodeTable>());
				else if (tn.Depth == 1) // Add Countries
					AddChildNodes(tn.ChildNodes, CacheService.Countries.Values.Where(c => c.Subregion.Id == id).OrderBy(c => c.Name).Cast<ICodeTable>());
			}
		}

		protected bool EnableSavePermissionButton()
		{
			return false;
		}

		protected void btnCancel_click(object sender, EventArgs e)
		{

		}

		/// <summary>
		/// Gets Shared -  UnShared Resourcetypes,organizations,countries for users
		/// </summary>
		private void GetDataForUsers()//SS:Created common method to get data for all users or particular specified users
		{
			#region UserName
			if (!string.IsNullOrEmpty(hdSelectedUserRMUserId.Value))
			{
				if (hdSelectedUserList.Value.Split(',').Length == 1)
				{
					labelUserName.Text = "Current Permissions for the user: " + hdSelectedUserList.Value + " (" + hdSelectedUserQId.Value + ")";
				}
				else
				{
					int unselUsers;
					int totalUsers = int.TryParse(hdTotalRecordCount.Value, out totalUsers) ? totalUsers : 0;
					if (hdSelectAll.Value == "1")
					{
						unselUsers = totalUsers - hdManuallyUnselected.Value.Split(',')
						 .Select(x => x.Trim())
						 .Where(x => !string.IsNullOrEmpty(x)).ToArray().Length;
					}
					else
					{
						unselUsers = hdSelectedUserList.Value.Split(',').Length;
					}
					labelUserName.Text = string.Format("Current Permissions for the user: {0} selected Users of {1} searched users", unselUsers, totalUsers);
				}
			#endregion

				#region SharedResourceTypes
				// Get shared Resource Types
				ResourceType[] usrSharedResourcesType;
				if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && string.IsNullOrEmpty(hdManuallyUnselected.Value))
				{
					usrSharedResourcesType = RmUser.GetSharedResourceTypesForUsers(hdSelectedUserRMUserId.Value, "1");//SS:Passing "1" to indicate that all users
				}
				else if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && !string.IsNullOrEmpty(hdManuallyUnselected.Value))
				{
					usrSharedResourcesType = RmUser.GetSharedResourceTypesForUsers(hdSelectedUserRMUserId.Value, "1", FormattedUnselectedValue());
				}
				else
				{
					usrSharedResourcesType = RmUser.GetSharedResourceTypesForUsers(FilterRmUserList());
				}

				if (usrSharedResourcesType != null)
				{
					foreach (ResourceType resType in usrSharedResourcesType)
					{
						bool find = false;
						//	string resId = resType.Id.ToString();
						foreach (TreeNode cbResTypeOrg in listBoxResourceRequestType.Nodes) // RRT Organization
						{
							foreach (TreeNode cbResTypeOrgUnit in cbResTypeOrg.ChildNodes) // RRT
							{
								foreach (TreeNode cbResType in cbResTypeOrgUnit.ChildNodes)
								{
									if (cbResType.Value == resType.Id.ToString())
									{
										find = true;
										cbResType.Checked = true;
										cbResTypeOrg.Checked = true;
										cbResTypeOrgUnit.Checked = true;
										break;
									}
								}
								if (find)
								{
									break;
								}
							}

							if (find)
							{
								break;
							}

						}
					}
				}
				#endregion

				#region UnSharedResourceTypes
				// Get un-shared Resource Types
				ResourceType[] usrResourcesType;
				if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && string.IsNullOrEmpty(hdManuallyUnselected.Value))//SS:QRPM-4755:If for all users then pass "1" for below method , simply get data for all users
				{
					usrResourcesType = RmUser.GetUnsharedResourceTypesForUsers(hdSelectedUserRMUserId.Value, "1");//SS:Passing "1" to indicate that all users
				}
				else if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && !string.IsNullOrEmpty(hdManuallyUnselected.Value))
				{
					usrResourcesType = RmUser.GetUnsharedResourceTypesForUsers(hdSelectedUserRMUserId.Value, "1", FormattedUnselectedValue());
				}
				else
				{
					usrResourcesType = RmUser.GetUnsharedResourceTypesForUsers(FilterRmUserList());
				}

				if (usrResourcesType != null)
				{
					foreach (ResourceType resType in usrResourcesType)
					{
						bool find = false;
						string resId = resType.Id.ToString();
						foreach (TreeNode cbResTypeOrg in listBoxResourceRequestType.Nodes) // RRT Organization
						{
							foreach (TreeNode cbResTypeOrgUnit in cbResTypeOrg.ChildNodes) // RRT
							{
								foreach (TreeNode cbResType in cbResTypeOrgUnit.ChildNodes)
								{
									if (cbResType.Value == resType.Id.ToString())
									{
										find = true;
										cbResType.Checked = true;
										cbResTypeOrg.Checked = true;
										this.hdUnsharedResourceType.Value += "," + cbResType.Text;
										break;
									}

								}
								if (find)
								{
									break;
								}

							}
							if (find)
							{
								break;
							}

						}
					}
				}


				this.hdUnsharedResourceType.Value = string.IsNullOrEmpty(this.hdUnsharedResourceType.Value) ? string.Empty : this.hdUnsharedResourceType.Value.Substring(1);
				#endregion

				#region Organizations
				// Get shared organizations
				//		HashSet<int> usrOrgs;
				OrganizationalUnit[] usrOrgs;
				if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && string.IsNullOrEmpty(hdManuallyUnselected.Value))//SS:QRPM-4755:If for all users then pass "1" for below method , simply get data for all users
				{
					usrOrgs = RmUser.GetSharedOrganizationForUsers(hdSelectedUserRMUserId.Value, "1");//SS:Passing "1" to indicate that all users
				}
				else if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && !string.IsNullOrEmpty(hdManuallyUnselected.Value))
				{
					usrOrgs = RmUser.GetSharedOrganizationForUsers(hdSelectedUserRMUserId.Value, "1", FormattedUnselectedValue());
				}
				else
				{
					usrOrgs = RmUser.GetSharedOrganizationForUsers(FilterRmUserList());
				}

				if (usrOrgs != null)
				{
					foreach (var orgID in usrOrgs)
					{
						bool find = false;
						string orgUnitId = orgID.Id.ToString();
						foreach (TreeNode tnOrganizatione in listOrganization.Nodes) // Shared Resource types
						{
							foreach (TreeNode tnOrganization in tnOrganizatione.ChildNodes) // RRT
							{

								if (tnOrganization.Value == orgUnitId)
								{
									find = true;
									tnOrganization.Checked = true;
									tnOrganizatione.Checked = true;
									break;
								}
							}
							if (find)
							{
								break;
							}

						}
					}
				}
				#endregion

				#region UnSharedOrganizations
				// Get un-shared Organizations 
				OrganizationalUnit[] unsrOrgs;
				if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && string.IsNullOrEmpty(hdManuallyUnselected.Value))//SS:QRPM-4755:If for all users then pass "1" for below method , simply get data for all users
				{
					unsrOrgs = RmUser.GetUnsharedOrganizationForUsers(hdSelectedUserRMUserId.Value, "1");//SS:Passing "1" to indicate that all users
				}
				else if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && !string.IsNullOrEmpty(hdManuallyUnselected.Value))
				{
					unsrOrgs = RmUser.GetUnsharedOrganizationForUsers(hdSelectedUserRMUserId.Value, "1", FormattedUnselectedValue());
				}
				else
				{
					unsrOrgs = RmUser.GetUnsharedOrganizationForUsers(FilterRmUserList());
				}
				if (unsrOrgs != null)
				{
					foreach (var orgID in unsrOrgs)
					{
						string orgUnitId = orgID.Id.ToString();

						foreach (TreeNode tnOrganizatione in listOrganization.Nodes) // Shared Resource types
						{
							bool find = false;
							foreach (TreeNode tnOrganization in tnOrganizatione.ChildNodes)
							{
								if (tnOrganization.Value == orgUnitId)
								{
									find = true;
									tnOrganization.Checked = true;
									tnOrganizatione.Checked = true;
									this.hdUnsharedOrganizationUnit.Value += "," + tnOrganization.Text;
									break;
								}
							}
							if (find)
							{
								break;
							}
						}
					}
				}
				this.hdUnsharedOrganizationUnit.Value = string.IsNullOrEmpty(this.hdUnsharedOrganizationUnit.Value) ? string.Empty : this.hdUnsharedOrganizationUnit.Value.Substring(1);


				#endregion

				#region SharedCounrties
				// Get shared countries 
				int[] usrCountries;
				if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && string.IsNullOrEmpty(hdManuallyUnselected.Value))//SS:QRPM-4755:If for all users then pass "1" for below method , simply get data for all users
				{
					usrCountries = RmUser.GetSharedCountriesForUsers(hdSelectedUserRMUserId.Value, "1");//SS:Passing "1" to indicate that all users
				}
				else if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && !string.IsNullOrEmpty(hdManuallyUnselected.Value))
				{
					usrCountries = RmUser.GetSharedCountriesForUsers(hdSelectedUserRMUserId.Value, "1", FormattedUnselectedValue());
				}
				else
				{
					usrCountries = RmUser.GetSharedCountriesForUsers(FilterRmUserList());
				}

				if (usrCountries != null && usrCountries.Count() > 0)
				{
					foreach (var countryID in usrCountries)
					{
						string scountryID = countryID.ToString();
						bool find = false;
						foreach (TreeNode tnRegion in treeViewPermissions.Nodes) // Region
						{
							foreach (TreeNode tnSubRegion in tnRegion.ChildNodes) // SubRegion
							{
								foreach (TreeNode tnCountry in tnSubRegion.ChildNodes) // Country
								{
									if (tnCountry.Value == scountryID)
									{
										find = true;
										tnCountry.Checked = true;
										tnSubRegion.Checked = true;
										tnRegion.Checked = true;
										break;
									}
								}

								if (find)
								{
									break;
								}
							}

							if (find)
							{
								break;
							}
						}
					}
				}

				#endregion

				#region UnsharedCountries
				// Get unshared countries 
				int[] unsharedCountries;
				if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && string.IsNullOrEmpty(hdManuallyUnselected.Value))//SS:QRPM-4755:If for all users then pass "1" for below method , simply get data for all users
				{
					unsharedCountries = RmUser.GetUnsharedCountriesForUsers(hdSelectedUserRMUserId.Value, "1");//SS:Passing "1" to indicate that all users
				}
				else if (hdSelectAll.Value == "1" && hdJsonFilters.Value == "false" && !string.IsNullOrEmpty(hdManuallyUnselected.Value))
				{
					unsharedCountries = RmUser.GetUnsharedCountriesForUsers(hdSelectedUserRMUserId.Value, "1", FormattedUnselectedValue());
				}
				else
				{
					unsharedCountries = RmUser.GetUnsharedCountriesForUsers(FilterRmUserList());
				}
				if (unsharedCountries != null && unsharedCountries.Count() > 0)
				{
					foreach (var countryID in unsharedCountries)
					{
						string scountryID = countryID.ToString();
						bool find = false;
						foreach (TreeNode tnRegion in treeViewPermissions.Nodes) // Region
						{
							foreach (TreeNode tnSubRegion in tnRegion.ChildNodes) // SubRegion
							{
								foreach (TreeNode tnCountry in tnSubRegion.ChildNodes) // Country
								{
									if (tnCountry.Value == scountryID)
									{
										find = true;
										tnCountry.Checked = true;
										tnSubRegion.Checked = true;
										tnRegion.Checked = true;
										this.hdUnsharedCountries.Value += "," + tnCountry.Text;
										break;
									}
								}

								if (find)
								{
									break;
								}
							}

							if (find)
							{
								break;
							}
						}
					}
				}
				#endregion
			}
		}

		private string FilterRmUserList()
		{
			string[] rmUserList = this.hdSelectedUserRMUserId.Value.Split(',');
			string[] unSelectedUsers = this.hdManuallyUnselected.Value.Split(',');
			unSelectedUsers = unSelectedUsers.Select(x => "'" + x + "'").ToArray();
			// Remove the manually unselected users from main user list
			return string.Join(",", rmUserList.Except(unSelectedUsers).ToArray());
		}

		private string FormattedUnselectedValue()
		{
			string[] unSelectedUsers = this.hdManuallyUnselected.Value.Split(',')
				.Select(x => x.Trim())
				.Where(x => !string.IsNullOrEmpty(x)).ToArray();
			unSelectedUsers = unSelectedUsers.Select(x => "'" + x + "'").ToArray();
			return string.Join(",", unSelectedUsers);
		}

		private void SaveDataForUsers()
		{
			DateTime changeTime = DateTime.Now;
			ArrayList countResType = new ArrayList();
			ArrayList countOrg = new ArrayList(); ;
			ArrayList countCountries = new ArrayList();
			// Iterate through each user, and then delete permissions that are unchecked or shared
			string[] rmUserList = this.hdSelectedUserRMUserId.Value.Split(',');
			string[] unSharedResourceTypes = this.hdUnsharedResourceType.Value.Split(',');
			string[] unSharedOrganizations = this.hdUnsharedOrganizationUnit.Value.Split(',');
			string[] unSharedCountries = this.hdUnsharedCountries.Value.Split(',');

			if (!string.IsNullOrEmpty(this.hdManuallyUnselected.Value) && this.hdManuallyUnselected.Value.IndexOf(',') == 0 && this.hdManuallyUnselected.Value.Length > 1)
			{
				this.hdManuallyUnselected.Value = this.hdManuallyUnselected.Value.Substring(1);
			}

			if (this.hdSelectAll.Value == "1" && hdJsonFilters.Value == "false")
			{
				#region IfPart
				// Save Resource Type
				StringBuilder deleteResourceTypes = new StringBuilder();
				StringBuilder insertResourceTypes = new StringBuilder();
				StringBuilder exceptQuery = new StringBuilder();
				foreach (TreeNode rrtOrganization in this.listBoxResourceRequestType.Nodes)
				{
					foreach (TreeNode rrtOrgUnit in rrtOrganization.ChildNodes)
					{
						foreach (TreeNode resourceTypeNode in rrtOrgUnit.ChildNodes)
						{
							// Add to delete list, delete permissions that are unchecked or shared
							if (resourceTypeNode.Checked)
							{
								if (!countResType.Contains(resourceTypeNode.Text))
								{
									countResType.Add(resourceTypeNode.Text);
								}

								if (!unSharedResourceTypes.Contains(resourceTypeNode.Text))
								{
									insertResourceTypes.Append("," + resourceTypeNode.Value);
								}
							}
							else
							{
								deleteResourceTypes.Append("," + resourceTypeNode.Value);
							}
						}
					}
				}

				// Delete all unchecked and shared resourcetypes for rmuser
				if (!string.IsNullOrEmpty(deleteResourceTypes.ToString()))
				{
					string auditQuery = string.Empty;
					if (!string.IsNullOrEmpty(this.hdManuallyUnselected.Value))
					{
						auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_ResourceType (ChangeType,ChangeUserId,ChangeTime,RmUserId,ResourceTypeId) 
																					SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, ResourceTypeId
																					FROM RmUser_ResourceType_XREF WHERE ResourceTypeId IN({2}) AND RmUserId NOT IN ({3});

																					DELETE FROM RmUser_ResourceType_XREF WHERE ResourceTypeId IN ({2}) AND RmUserId NOT IN ({3});", UserCache.Usr.QId, changeTime, deleteResourceTypes.ToString().Substring(1), this.hdManuallyUnselected.Value);
					}
					else
					{
						auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_ResourceType (ChangeType,ChangeUserId,ChangeTime,RmUserId,ResourceTypeId) 
																					SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, ResourceTypeId
																					FROM RmUser_ResourceType_XREF WHERE ResourceTypeId IN({2});

																					DELETE FROM RmUser_ResourceType_XREF WHERE ResourceTypeId IN ({2});", UserCache.Usr.QId, changeTime, deleteResourceTypes.ToString().Substring(1));

						DbHelp.ExecuteNonQueryText("DELETE FROM RmUser_ResourceType_XREF WHERE ResourceTypeId IN(" + deleteResourceTypes.ToString().Substring(1) + ")");
					}
					DbHelp.ExecuteNonQueryText(auditQuery);
				}

				// Insert shared resourcetypes for rmuser
				if (!string.IsNullOrEmpty(insertResourceTypes.ToString()))
				{
					if (!string.IsNullOrEmpty(this.hdManuallyUnselected.Value))
					{
						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_ResourceType_XREF]([RmUserId],[ResourceTypeId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																												SELECT RU.RmUserId, RT.ResourceTypeId,'{0}','{1}','{0}','{1}'
																												FROM RmUser RU CROSS JOIN ResourceType RT 
																												WHERE RT.ResourceTypeId IN ({2})
																												AND RmUserId NOT IN ({3})
																												EXCEPT
																												SELECT RmUserId,ResourceTypeId,'{0}','{1}','{0}','{1}'
																												FROM RmUser_ResourceType_XREF
																												WHERE ResourceTypeId IN ({2})", UserCache.Usr.QId, changeTime, insertResourceTypes.ToString().Substring(1), this.hdManuallyUnselected.Value));
					}
					else
					{
						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_ResourceType_XREF]([RmUserId],[ResourceTypeId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																												SELECT RU.RmUserId, RT.ResourceTypeId,'{0}','{1}','{0}','{1}'
																												FROM RmUser RU CROSS JOIN ResourceType RT 
																												WHERE RT.ResourceTypeId IN ({2})
																												EXCEPT
																												SELECT RmUserId,ResourceTypeId,'{0}','{1}','{0}','{1}'
																												FROM RmUser_ResourceType_XREF
																												WHERE ResourceTypeId IN ({2})", UserCache.Usr.QId, changeTime, insertResourceTypes.ToString().Substring(1)));
					}
				}

				// Save Organizations
				StringBuilder deleteOrganizations = new StringBuilder();
				StringBuilder insertOrganizations = new StringBuilder();
				foreach (TreeNode organizationTreeNode in this.listOrganization.Nodes)
				{
					foreach (TreeNode organizationNode in organizationTreeNode.ChildNodes)
					{
						// Add to delete list, delete permissions that are unchecked or shared
						if (organizationNode.Checked)
						{
							if (!countOrg.Contains(organizationNode.Text))
							{
								countOrg.Add(organizationNode.Text);
							}

							if (!unSharedOrganizations.Contains(organizationNode.Text))
							{
								insertOrganizations.Append("," + organizationNode.Value);
							}
						}
						else
						{
							deleteOrganizations.Append("," + organizationNode.Value);
						}
					}
				}

				// Delete all unchecked and shared organizations for rmuser
				if (!string.IsNullOrEmpty(deleteOrganizations.ToString()))
				{
					string auditQuery = string.Empty;
					if (!string.IsNullOrEmpty(this.hdManuallyUnselected.Value))
					{
						auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_Organization (ChangeType,ChangeUserId,ChangeTime,RmUserId,OrganizationalUnitId) 
																					SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, OrganizationalUnitId
																					FROM RmUser_Organization_XREF WHERE OrganizationalUnitId IN ({2}) AND RmUserId NOT IN ({3});

																					DELETE FROM RmUser_Organization_XREF WHERE  OrganizationalUnitId IN ({2}) AND RmUserId NOT IN ({3});", UserCache.Usr.QId, changeTime, deleteOrganizations.ToString().Substring(1), this.hdManuallyUnselected.Value);

					}
					else
					{
						auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_Organization (ChangeType,ChangeUserId,ChangeTime,RmUserId,OrganizationalUnitId) 
																					SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, OrganizationalUnitId
																					FROM RmUser_Organization_XREF WHERE OrganizationalUnitId IN ({2});

																					DELETE FROM RmUser_Organization_XREF WHERE  OrganizationalUnitId IN ({2});", UserCache.Usr.QId, changeTime, deleteOrganizations.ToString().Substring(1));
					}
					DbHelp.ExecuteNonQueryText(auditQuery);
				}
				// Insert shared organizations for rmuser
				if (!string.IsNullOrEmpty(insertOrganizations.ToString()))
				{
					if (!string.IsNullOrEmpty(this.hdManuallyUnselected.Value))
					{
						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_Organization_XREF]([RmUserId],[OrganizationalUnitId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																											SELECT RU.RmUserId, OU.OrganizationalUnitId,'{0}','{1}','{0}','{1}'
																											FROM RmUser RU CROSS JOIN OrganizationalUnit OU 
																											WHERE OU.OrganizationalUnitId IN ({2})
																											AND RmUserId NOT IN ({3})
																											EXCEPT
																											SELECT RmUserId, OrganizationalUnitId,'{0}','{1}','{0}','{1}'
																											FROM RmUser_Organization_XREF
																											WHERE OrganizationalUnitId IN ({2})", UserCache.Usr.QId, changeTime, insertOrganizations.ToString().Substring(1), this.hdManuallyUnselected.Value));
					}
					else
					{
						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_Organization_XREF]([RmUserId],[OrganizationalUnitId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																												SELECT RU.RmUserId, OU.OrganizationalUnitId,'{0}','{1}','{0}','{1}'
																												FROM RmUser RU CROSS JOIN OrganizationalUnit OU 
																												WHERE OU.OrganizationalUnitId IN ({2})
																												EXCEPT
																												SELECT RmUserId, OrganizationalUnitId,'{0}','{1}','{0}','{1}'
																												FROM RmUser_Organization_XREF
																												WHERE OrganizationalUnitId IN ({2})", UserCache.Usr.QId, changeTime, insertOrganizations.ToString().Substring(1)));
					}
				}

				// Save Countries
				StringBuilder deleteCountries = new StringBuilder();
				StringBuilder insertCountries = new StringBuilder();

				foreach (TreeNode regionNode in this.treeViewPermissions.Nodes)
				{
					foreach (TreeNode subRegionNode in regionNode.ChildNodes)
					{
						foreach (TreeNode countryNode in subRegionNode.ChildNodes)
						{
							// Add to delete list, delete permissions that are unchecked or shared
							if (countryNode.Checked)
							{
								if (!countCountries.Contains(countryNode.Text))
								{
									countCountries.Add(countryNode.Text);
								}

								if (!unSharedCountries.Contains(countryNode.Text))
								{
									insertCountries.Append("," + countryNode.Value);
								}
							}
							else
							{
								deleteCountries.Append("," + countryNode.Value);
							}
						}
					}
				}

				// Delete all unchecked and shared countries for rmuser
				if (!string.IsNullOrEmpty(deleteCountries.ToString()))
				{
					string auditQuery = string.Empty;
					if (!string.IsNullOrEmpty(this.hdManuallyUnselected.Value))
					{

						auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_Country (ChangeType,ChangeUserId,ChangeTime,RmUserId,CountryId) 
																				SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, CountryId
																				FROM RmUser_Country_XREF WHERE RmUserId NOT IN ({3}) AND CountryId IN({2});

																				DELETE FROM RmUser_Country_XREF WHERE RmUserId NOT IN ({3}) AND CountryId IN ({2});", UserCache.Usr.QId, changeTime, deleteCountries.ToString().Substring(1), this.hdManuallyUnselected.Value);
					}
					else
					{
						auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_Country (ChangeType,ChangeUserId,ChangeTime,RmUserId,CountryId) 
																					SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, CountryId
																					FROM RmUser_Country_XREF WHERE CountryId IN({2});

																					DELETE FROM RmUser_Country_XREF WHERE CountryId IN ({2});", UserCache.Usr.QId, changeTime, deleteCountries.ToString().Substring(1));
					}
					DbHelp.ExecuteNonQueryText(auditQuery);
				}

				// Insert shared countries for rmuser
				if (!string.IsNullOrEmpty(insertCountries.ToString()))
				{
					if (!string.IsNullOrEmpty(this.hdManuallyUnselected.Value))
					{

						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_Country_XREF]([RmUserId],[CountryId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																												SELECT RU.RmUserId, C.CountryId,'{0}','{1}','{0}','{1}'
																												FROM RmUser RU CROSS JOIN Country C 
																												WHERE C.CountryId  IN ({2})
																												AND RmUserId NOT IN ({3})
																												EXCEPT
																												SELECT RmUserId, CountryId,'{0}','{1}','{0}','{1}'
																												FROM RmUser_Country_XREF
																												WHERE CountryId IN ({2})", UserCache.Usr.QId, changeTime, insertCountries.ToString().Substring(1), this.hdManuallyUnselected.Value));
					}
					else
					{
						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_Country_XREF]([RmUserId],[CountryId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																											SELECT RU.RmUserId, C.CountryId,'{0}','{1}','{0}','{1}'
																											FROM RmUser RU CROSS JOIN Country C 
																											WHERE C.CountryId  IN ({2})
																											EXCEPT
																											SELECT RmUserId, CountryId,'{0}','{1}','{0}','{1}'
																											FROM RmUser_Country_XREF
																											WHERE CountryId IN ({2})", UserCache.Usr.QId, changeTime, insertCountries.ToString().Substring(1)));
					}
				}
				#endregion
			}
			else
			{
				#region ElsePart

				// Array of unselected users
				string[] unSelectedUsers = this.hdManuallyUnselected.Value.Split(',');
				unSelectedUsers = unSelectedUsers.Select(x => "'" + x + "'").ToArray();
				// Remove the manually unselected users from main user list
				rmUserList = rmUserList.Except(unSelectedUsers).ToArray();

				foreach (string rmUser in rmUserList)
				{
					// Save Resource Type
					StringBuilder deleteResourceTypes = new StringBuilder();
					StringBuilder insertResourceTypes = new StringBuilder();
					StringBuilder exceptQuery = new StringBuilder();
					foreach (TreeNode rrtOrganization in this.listBoxResourceRequestType.Nodes)
					{
						foreach (TreeNode rrtOrgUnit in rrtOrganization.ChildNodes)
						{
							foreach (TreeNode resourceTypeNode in rrtOrgUnit.ChildNodes)
							{
								// Add to delete list, delete permissions that are unchecked or shared
								if (resourceTypeNode.Checked)
								{
									if (!countResType.Contains(resourceTypeNode.Text))
									{
										countResType.Add(resourceTypeNode.Text);
									}

									if (!unSharedResourceTypes.Contains(resourceTypeNode.Text))
									{
										exceptQuery.Append("," + resourceTypeNode.Value);
										insertResourceTypes.Append(string.Format(@"UNION SELECT {0},{1},'{2}','{3}','{2}','{3}'", rmUser, resourceTypeNode.Value, UserCache.Usr.QId, changeTime));
									}
								}
								else
								{
									deleteResourceTypes.Append("," + resourceTypeNode.Value);
								}
							}
						}
					}

					// Delete all unchecked ResouceTypes for rmuser
					if (!string.IsNullOrEmpty(deleteResourceTypes.ToString()))
					{
						string auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_ResourceType (ChangeType,ChangeUserId,ChangeTime,RmUserId,ResourceTypeId) 
																								SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, ResourceTypeId
																								FROM RmUser_ResourceType_XREF WHERE RmUserId = {2} AND ResourceTypeId IN({3});

																								DELETE FROM RmUser_ResourceType_XREF WHERE RmUserId = {2} AND ResourceTypeId IN ({3});", UserCache.Usr.QId, changeTime, rmUser, deleteResourceTypes.ToString().Substring(1));

						DbHelp.ExecuteNonQueryText(auditQuery);
					}

					// Insert shared resourcetypes for rmuser if NOT exsits
					if (!string.IsNullOrEmpty(insertResourceTypes.ToString()))
					{
						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_ResourceType_XREF]([RmUserId],[ResourceTypeId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																												{2}
																												EXCEPT
																												SELECT rmuserid,ResourceTypeId,'{0}','{1}','{0}','{1}'
																												FROM RmUser_ResourceType_XREF
																												WHERE ResourceTypeId IN ({3}) AND RmUserId = {4}", UserCache.Usr.QId, changeTime, insertResourceTypes.ToString().Substring(6), exceptQuery.ToString().Substring(1), rmUser));
					}

					// Save Organizations
					StringBuilder deleteOrganizations = new StringBuilder();
					StringBuilder insertOrganizations = new StringBuilder();
					exceptQuery = new StringBuilder();

					foreach (TreeNode organizationRootNode in this.listOrganization.Nodes)
					{
						foreach (TreeNode organizationNode in organizationRootNode.ChildNodes)
						{
							// Add to delete list, delete permissions that are unchecked or shared
							if (organizationNode.Checked)
							{
								if (!countOrg.Contains(organizationNode.Text))
								{
									countOrg.Add(organizationNode.Text);
								}

								if (!unSharedOrganizations.Contains(organizationNode.Text))
								{
									exceptQuery.Append("," + organizationNode.Value);
									insertOrganizations.Append(string.Format(@"UNION SELECT {0},{1},'{2}','{3}','{2}','{3}'", rmUser, organizationNode.Value, UserCache.Usr.QId, changeTime));
								}
							}
							else
							{
								deleteOrganizations.Append("," + organizationNode.Value);
							}
						}
					}

					// Delete all unchecked and shared organizations for rmuser
					if (!string.IsNullOrEmpty(deleteOrganizations.ToString()))
					{

						string auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_Organization (ChangeType,ChangeUserId,ChangeTime,RmUserId,OrganizationalUnitId) 
																								SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, OrganizationalUnitId
																								FROM RmUser_Organization_XREF WHERE RmUserId = {2} AND OrganizationalUnitId IN ({3});

																								DELETE FROM RmUser_Organization_XREF WHERE RmUserId = {2} AND OrganizationalUnitId IN ({3});", UserCache.Usr.QId, changeTime, rmUser, deleteOrganizations.ToString().Substring(1));
						DbHelp.ExecuteNonQueryText(auditQuery);
					}

					// Insert shared organizations for rmuser
					if (!string.IsNullOrEmpty(insertOrganizations.ToString()))
					{

						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_Organization_XREF]([RmUserId],[OrganizationalUnitId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																												{2}
																												EXCEPT
																												SELECT RmUserId, OrganizationalUnitId,'{0}','{1}','{0}','{1}'
																												FROM RmUser_Organization_XREF
																												WHERE OrganizationalUnitId IN ({3}) AND RmUserId = {4}", UserCache.Usr.QId, changeTime, insertOrganizations.ToString().Substring(6), exceptQuery.ToString().Substring(1), rmUser));
					}

					// Save Countries
					StringBuilder deleteCountries = new StringBuilder();
					StringBuilder insertCountries = new StringBuilder();
					exceptQuery = new StringBuilder();
					foreach (TreeNode regionNode in this.treeViewPermissions.Nodes)
					{
						foreach (TreeNode subRegionNode in regionNode.ChildNodes)
						{
							foreach (TreeNode countryNode in subRegionNode.ChildNodes)
							{
								// Add to delete list, delete permissions that are unchecked or shared
								if (countryNode.Checked)
								{
									if (!countCountries.Contains(countryNode.Text))
									{
										countCountries.Add(countryNode.Text);
									}

									if (!unSharedCountries.Contains(countryNode.Text))
									{
										exceptQuery.Append("," + countryNode.Value);
										insertCountries.Append(string.Format(@"UNION SELECT {0},{1},'{2}','{3}','{2}','{3}'", rmUser, countryNode.Value, UserCache.Usr.QId, changeTime));
									}
								}
								else
								{
									deleteCountries.Append("," + countryNode.Value);
								}
							}
						}
					}

					// Delete all unchecked and shared countries for rmuser
					if (!string.IsNullOrEmpty(deleteCountries.ToString()))
					{
						string auditQuery = string.Format(@"INSERT INTO ZAudit_RmUser_Country (ChangeType,ChangeUserId,ChangeTime,RmUserId,CountryId) 
																								SELECT 3 AS ChangeType,'{0}' AS ChangeUserId,'{1}' AS ChangeTime, RmUserId, CountryId
																								FROM RmUser_Country_XREF WHERE RmUserId = {2} AND CountryId IN({3});

																								DELETE FROM RmUser_Country_XREF WHERE RmUserId = {2} AND CountryId IN ({3});", UserCache.Usr.QId, changeTime, rmUser, deleteCountries.ToString().Substring(1));
						DbHelp.ExecuteNonQueryText(auditQuery);
					}

					// Insert shared countries for rmuser
					if (!string.IsNullOrEmpty(insertCountries.ToString()))
					{
						DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO [dbo].[RmUser_Country_XREF]([RmUserId],[CountryId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn])
																												{2}
																												EXCEPT
																												SELECT RmUserId, CountryId,'{0}','{1}','{0}','{1}'
																												FROM RmUser_Country_XREF
																												WHERE CountryId IN ({3}) AND RmUserId = {4}", UserCache.Usr.QId, changeTime, insertCountries.ToString().Substring(6), exceptQuery.ToString().Substring(1), rmUser));
					}
				}
				#endregion
			}
			if (chkGrantAllCountry.Checked == false && chkGrantAllOrg.Checked == false && chkGrantAllRequestType.Checked == false)
			{
				var deleteQuery = string.Format(@"DELETE  FROM RmUser_GrantAll_Xref
																					WHERE   RmUserId IN ({0})", this.hdSelectedUserRMUserId.Value);
				DbHelp.ExecuteNonQueryText(deleteQuery);
			}
			else
			{

				if (hdGrantAllOrg.Value == "0" || hdGrantAllCountry.Value == "0" || hdGrantAllResourceType.Value == "0")
				{
					StringBuilder updateQuery = new StringBuilder();
					if (hdGrantAllOrg.Value == "0")
						updateQuery.Append(string.Format("OrganizationUnit = {0},", chkGrantAllOrg.Checked ? 1 : 0));
					if (hdGrantAllCountry.Value == "0")
						updateQuery.Append(string.Format("Countries = {0},", chkGrantAllCountry.Checked ? 1 : 0));
					if (hdGrantAllResourceType.Value == "0")
						updateQuery.Append(string.Format("ResourceType = {0},", chkGrantAllRequestType.Checked ? 1 : 0));
					var insertUpdateQuery = string.Format(@"UPDATE RmUser_GrantAll_Xref 
																								SET  LastModifiedBy = '{4}',{5}
																								LastModifiedOn = GETDATE()
																								WHERE RmUser_GrantAll_Xref.RmUserId IN ({0});

																								INSERT  INTO RmUser_GrantAll_Xref ( RmUserId ,OrganizationUnit ,Countries ,ResourceType ,LastModifiedBy ,LastModifiedOn ,CreatedBy ,CreatedOn)
																								SELECT RmUserId, {1}, {2}, {3}, '{4}', GETDATE(), '{4}', GETDATE()
																								FROM dbo.RmUser
																								WHERE RmUserId IN ({0})
																								EXCEPT
																								SELECT RmUserId, {1}, {2}, {3}, '{4}', GETDATE(), '{4}', GETDATE()
																								FROM dbo.RmUser_GrantAll_Xref
																								WHERE RmUserId IN ({0});

																								DELETE  FROM RmUser_GrantAll_Xref
																								WHERE OrganizationUnit = 0 AND Countries = 0 AND ResourceType = 0;", this.hdSelectedUserRMUserId.Value, Convert.ToBoolean(Convert.ToInt32(hdGrantAllOrg.Value)) ? 0 : chkGrantAllOrg.Checked ? 1 : 0, Convert.ToBoolean(Convert.ToInt32(hdGrantAllCountry.Value)) ? 0 : chkGrantAllCountry.Checked ? 1 : 0, Convert.ToBoolean(Convert.ToInt32(hdGrantAllResourceType.Value)) ? 0 : chkGrantAllRequestType.Checked ? 1 : 0, UserCache.Usr.QId, updateQuery);
					DbHelp.ExecuteNonQueryText(insertUpdateQuery);
				}

			}
			// Reset all the values of hidden inputs text
			string user = rmUserList.Length > 1 ? "M" : hdSelectedUserList.Value.Split(',')[0].Replace("'", "");
			this.hdRmUser.Value = string.Empty;
			this.hdSelectedUserList.Value = string.Empty;
			this.hdSelectAll.Value = string.Empty;
			this.hdSelectedUserQId.Value = string.Empty;
			this.hdSelectedUserRMUserId.Value = string.Empty;
			this.hdUnsharedCountries.Value = string.Empty;
			this.hdUnsharedOrganizationUnit.Value = string.Empty;
			this.hdUnsharedResourceType.Value = string.Empty;
			//RMK:QRPM4884 Added a querystring "S" , which is track the save button click
			int saveDataFlag = 1;
			//this.hdSaveMessage.Value = saveAlert;
			Response.Redirect("/_layouts/spui/Admin/AssignPermissions.aspx?U=" + user + "&R=" + countResType.Count.ToString() + "&O=" + countOrg.Count.ToString() + "&C=" + countCountries.Count.ToString() + "&S=" + saveDataFlag);

			//string saveMsg = string.Format("Saved {0} Resource Types and {1} Organizations and {2} Countries for User {3}", countResType.Count, countOrg.Count, countCountries.Count, user);
			//ScriptManager.RegisterStartupScript(this.updatePanel1, this.updatePanel1.GetType(), "foo", saveMsg, true);
			//this.hdSelectedUserRMUserId.Value = SelectedUser;
		}
	}
}
