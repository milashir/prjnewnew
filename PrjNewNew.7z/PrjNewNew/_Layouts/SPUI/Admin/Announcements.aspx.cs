﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class Announcements : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.Announcements; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions for Announcements",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="Create",
                                Title="Create Announcement",
                                CommandJavaScript = "announcementNs.create();",
                                CommandEnableJavaScript = "announcementNs.isCreateButtonEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(13,12, revision)
                            },
                            new ButtonDefinition() {
                                Id="Modify",
                                Title="Modify Announcement",
                                CommandJavaScript = "announcementNs.editViaRibbon();",
                                CommandEnableJavaScript = "announcementNs.isUpdateButtonEnabled();",  
																Image=MapImageLibrary.GetPSImage(3,11, revision)
                                
                            },
                            
                            new ButtonDefinition() {
                                Id="Save",
                                Title="Save",
                                CommandJavaScript = "announcementNs.save();",
                                CommandEnableJavaScript = "announcementNs.isSaveButtonEnabled();",  
                                Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
                                
                            },

														new ButtonDefinition() {
                                Id="Cancel",
                                Title="Cancel",
                                 CommandJavaScript = "announcementNs.cancel();",
                                CommandEnableJavaScript = "announcementNs.isCancelButtonEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
                            },
                            new ButtonDefinition() {
                                Id="Close",
                                Title="Close",
                                CommandJavaScript = "announcementNs.close();",
                                CommandEnableJavaScript = "announcementNs.isCloseButtonEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
                            },
                            
														new ButtonDefinition() {
                                Id="Delete",
                                Title="Delete Announcement",
                                CommandJavaScript = "announcementNs.deleteAnnouncement();",
                                CommandEnableJavaScript = "announcementNs.isDeleteButtonEnabled();",  
                                Image=ImageLibrary.GetStandardImage(11,8, revision)
                            }
                }
			});

			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridreportActions",
				Title = "Reports",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] 
									 {
													new ButtonDefinition()
													{
															Id="History",
															Title="Announcement History",
															CommandJavaScript = "announcementNs.showAnnouncementChagnes();",
															CommandEnableJavaScript = "true;",
															Image=ImageLibrary.GetStandardImage(14,2, revision)
													}
									 }
			});

			return new TabDefinition()
			{
				Id = "ResourceRequestRibbon",
				Title = "Announcements",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
