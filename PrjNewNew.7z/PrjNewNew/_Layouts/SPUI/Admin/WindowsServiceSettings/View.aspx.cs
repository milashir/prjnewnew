﻿using System;
using System.Linq;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.WindowsServiceSettings
{
	public partial class View : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ViewWindowsServiceSettings; } }
		public bool NewJobRoleAdded { get; private set; }

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Service Settings",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
