﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.JobRoleAdmin
{
	public partial class Add : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.AddJobRole; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "PageActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                             new ButtonDefinition()
                            {
                                Id="SaveGrid",
                                Title="Save",
                                CommandEnableJavaScript = "addJrNs.isSaveButtonEnabled()",
                                CommandJavaScript = "addJrNs.save()",
                                Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="CancelGrid",
                                Title="Cancel",
                                CommandJavaScript = "addJrNs.cancel()",
                                CommandEnableJavaScript = "addJrNs.isCancelButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="CloseGrid",
                                Title="Close",
                                CommandJavaScript = "addJrNs.close()",
                                CommandEnableJavaScript = "addJrNs.isCloseButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
                            }
                }
			});

			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Job Roles",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
