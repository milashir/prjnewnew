﻿using System;
using System.Collections.Generic;
using System.Web;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.JobRoleAdmin
{
	public partial class Manage : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ManageJobRoles; } }
		public bool NewJobRoleAdded { get; private set; }
		
		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}
		
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			if (HttpContext.Current.Session[Constants.SessionKeys.JOBROLE_ADDED_SUCCESSFULLY] != null)
			{
				NewJobRoleAdded = true;
				HttpContext.Current.Session.Remove(Constants.SessionKeys.JOBROLE_ADDED_SUCCESSFULLY);
			}
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions for Job Roles",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = GetRibbonButtonList()
			});

			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Job Roles",
				Groups = PageGroups.ToArray()
			};
		}

		private ControlDefinition[] GetRibbonButtonList()
		{
			var hasAccessToEditJobRoles = RmFunction.HasPermissionToFunction(RmFunction_E.Edit_Job_Roles, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));

			var buttonList = new List<ControlDefinition> { 
													new ButtonDefinition()
													{
                            Id=hasAccessToEditJobRoles? "Modify" :"View",
                            Title=hasAccessToEditJobRoles? "Modify" :"View",
                            CommandJavaScript = "manageJrNs.editJobRole();",
                            CommandEnableJavaScript = "manageJrNs.isModifyButtonEnabled();",  
														Image=MapImageLibrary.GetPSImage(3,11, revision)
                          }
												};

			if (hasAccessToEditJobRoles)
			{
				buttonList.Insert(0, new ButtonDefinition()
				{
					Id = "Add",
					Title = "Add",
					CommandJavaScript = "manageJrNs.addNewJobRole();",
					CommandEnableJavaScript = "manageJrNs.isAddButtonEnabled();",
					Image = MapImageLibrary.GetFormatMapImage(13, 12, revision)
				});
			}

			return buttonList.ToArray();
		}
	}
}
