﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.JobRoleAdmin
{
	public partial class Edit : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ManageJobRoles; } }
		private const string KEY_JOB_ROLE = "jrid";
		protected bool HasError { get; private set; }
		protected string ErrorMessage { get; private set; }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			int jobRoleId;
			ValidateQueryStringParameters(out jobRoleId);

			BindControls(jobRoleId);
			HandleControlVisibility();
		}

		private void HandleControlVisibility()
		{
			phValidValues.Visible = !HasError;
		}

		private void BindControls(int jobRoleId)
		{
			hdnJobRoleId.Value = jobRoleId.ToString();

			JobRole jobRole;
			if (CacheService.AllJobRoles.TryGetValue(jobRoleId, out jobRole))
			{
				txtJobRoleName.Text = jobRole.Name;
				cbIsJobRoleEnabled.Checked = jobRole.IsEnabled;
				cbIsProjectLeadership.Checked = jobRole.IsProjectLeadership;
				cbShowCompetencyBand.Checked = jobRole.ShowCompetencyBand;
				cbShowTmfPlatform.Checked = jobRole.ShowTmfPlatform;
				txtHrName.Text = jobRole.HRName;
				if (cbIsJobRoleEnabled.Checked)
				{
					hdnWasJrEnabled.Value = "1";
				}
				if (cbIsProjectLeadership.Checked)
				{
					hdnWasPlEnabled.Value = "1";
				}
			}
			else
			{
				ErrorMessage = string.Format("Job Role with Id {0} not found in system", jobRoleId);
				HasError = true;
				return;
			}
		}

		private void ValidateQueryStringParameters(out int jobRoleId)
		{
			jobRoleId = Request.QueryString[KEY_JOB_ROLE].ToInt(Constants.UnspecifiedId);
			if (jobRoleId == Constants.UnspecifiedId) { throw new ArgumentException("Parameter jrid not specifiec or is invalid"); }
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "PageActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = GetRibbonButtonList()
			});

			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Job Roles",
				Groups = PageGroups.ToArray()
			};
		}

		private ControlDefinition[] GetRibbonButtonList()
		{
			var hasAccessToEditJobRole = RmFunction.HasPermissionToFunction(RmFunction_E.Edit_Job_Roles, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
			hdnHasAccessToEditJobRole.Value = hasAccessToEditJobRole.GetIntAsStringFromBool();

			var buttonList = new List<ControlDefinition>();
			if (hasAccessToEditJobRole)
			{
				buttonList.Add(new ButtonDefinition()
				{
					Id = "SaveGrid",
					Title = "Save",
					CommandEnableJavaScript = "editJrNs.isSaveButtonEnabled()",
					CommandJavaScript = "editJrNs.save()",
					Image = MapImageLibrary.GetFormatMapImage(8, 13, revision)
				});

				buttonList.Add(new ButtonDefinition()
				{
					Id = "CancelGrid",
					Title = "Cancel",
					CommandJavaScript = "editJrNs.cancel()",
					CommandEnableJavaScript = "editJrNs.isCancelButtonEnabled()",
					Image = MapImageLibrary.GetFormatMapImage(6, 12, revision)
				});
			}

			buttonList.Add(new ButtonDefinition()
			{
				Id = "CloseGrid",
				Title = "Close",
				CommandJavaScript = "editJrNs.close()",
				CommandEnableJavaScript = "editJrNs.isCloseButtonEnabled()",
				Image = MapImageLibrary.GetFormatMapImage(9, 14, revision)
			});

			return buttonList.ToArray();
		}
	}
}
