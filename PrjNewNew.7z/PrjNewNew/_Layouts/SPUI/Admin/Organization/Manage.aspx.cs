﻿using System;
using System.Collections.Generic;
using System.Web;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.OrganizationAdmin
{
	public partial class Manage : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ManageOrganizations; } }
		public bool NewOrganizationAdded { get; private set; }
		public bool NewOrganizationalUnitAdded { get; private set; }

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			if (HttpContext.Current.Session[Constants.SessionKeys.ORGANIZATION_ADDED_SUCCESSFULLY] != null)
			{
				NewOrganizationAdded = true;
				HttpContext.Current.Session.Remove(Constants.SessionKeys.ORGANIZATION_ADDED_SUCCESSFULLY);
			}
			else if (HttpContext.Current.Session[Constants.SessionKeys.ORGANIZATIONAL_UNIT_ADDED_SUCCESSFULLY] != null)
			{
				NewOrganizationalUnitAdded = true;
				HttpContext.Current.Session.Remove(Constants.SessionKeys.ORGANIZATIONAL_UNIT_ADDED_SUCCESSFULLY);
			}
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions for Organizations",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = GetRibbonButtons()
			});

			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Organizations",
				Groups = PageGroups.ToArray()
			};
		}

		private ControlDefinition[] GetRibbonButtons()
		{
			var hasAccessToEditOrg = RmFunction.HasPermissionToFunction(RmFunction_E.Edit_Organizations, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));

			var buttonList = new List<ControlDefinition>{
												 new ButtonDefinition()
												 {
														Id=hasAccessToEditOrg? "Modify" :"View",
														Title=hasAccessToEditOrg? "Modify" :"View",
														CommandJavaScript = "manageOrgNs.editOrganization();",
														CommandEnableJavaScript = "manageOrgNs.isModifyButtonEnabled();",  
														Image=MapImageLibrary.GetPSImage(3,11, revision)
                         }};


			if (new RmLinkManager(RmUser, CurrentProject).HasAccessToLink(RmPageLink_E.AddOrganization))
			{
				buttonList.Insert(0, new ButtonDefinition()
				{
					Id = "Add",
					Title = "Add",
					CommandJavaScript = "manageOrgNs.addNewOrganization();",
					CommandEnableJavaScript = "manageOrgNs.isAddButtonEnabled();",
					Image = MapImageLibrary.GetFormatMapImage(13, 12, revision)
				});
			}
			return buttonList.ToArray();
		}
	}
}
