﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.OrganizationAdmin
{
	public partial class Add : AbstractRmRibbonPageLayout
	{
		protected Quintiles.RM.Clinical.UI.UserControls.OrganizationalUnitPPMList ucOrgPpmList;
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.AddOrganization; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			BindControls();
		}

		private void BindControls()
		{
			UIUtility.BindDropDown(ddlOrganization, CacheService.AllOrganizationsOrderedByName, true);
			ucOrgPpmList.AddNewMode = true;
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "PageActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                             new ButtonDefinition()
                            {
                                Id="SaveGrid",
                                Title="Save",
                                CommandEnableJavaScript = "addOrgNs.isSaveButtonEnabled()",
                                CommandJavaScript = "addOrgNs.save()",
                                Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="CancelGrid",
                                Title="Cancel",
                                CommandJavaScript = "addOrgNs.cancel()",
                                CommandEnableJavaScript = "addOrgNs.isCancelButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="CloseGrid",
                                Title="Close",
                                CommandJavaScript = "addOrgNs.close()",
                                CommandEnableJavaScript = "addOrgNs.isCloseButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
                            }
                }
			});

			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Organizations",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
