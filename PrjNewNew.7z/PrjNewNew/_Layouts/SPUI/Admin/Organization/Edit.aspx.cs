﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.OrganizationAdmin
{
	public partial class Edit : AbstractRmRibbonPageLayout
	{
		protected Quintiles.RM.Clinical.UI.UserControls.OrganizationalUnitPPMList ucOrgPpmList;
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ManageOrganizations; } }
		private const string KEY_ORGANIZATION = "oid";
		private const string KEY_ORGANIZATION_UNIT = "ouid";
		protected bool HasError { get; private set; }
		protected string ErrorMessage { get; private set; }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			int organizationId;
			int organizationalUnitId;
			ValidateQueryStringParameters(out organizationId, out organizationalUnitId);

			BindControls(organizationId, organizationalUnitId);
			HandleControlVisibility();
		}

		private void HandleControlVisibility()
		{
			phValidValues.Visible = !HasError;
		}

		private void BindControls(int organizationId, int organizationalUnitId)
		{
			ucOrgPpmList.AddNewMode = false;
			ucOrgPpmList.OrganizationalUnitId = organizationalUnitId;

			hdnOrgId.Value = organizationId.ToString();
			hdnOrgUnitId.Value = organizationalUnitId.ToString();
			hdnFancyTreeChanged.Value = "0";

			Organization organization;
			if (CacheService.AllOrganizations.TryGetValue(organizationId, out organization))
			{
				txtOrgName.Text = organization.Name;
				cbIsOrgEnabled.Checked = organization.IsEnabled;
				txtOrgShortName.Text = organization.ShortName;
				txtGlobalWeeklyHours.Text = organization.GlobalWeeklyHours.ToString();
			}
			else
			{
				ErrorMessage = string.Format("Organization with Id {0} not found in system", organizationId);
				HasError = true;
				return;
			}

			OrganizationalUnit organizationalUnit;
			if (CacheService.AllOrganizationalUnits.TryGetValue(organizationalUnitId, out organizationalUnit))
			{
				txtOrgUnitName.Text = organizationalUnit.Name;
				txtOrgUnitSuffix.Text = organizationalUnit.Suffix;
				cbIsOrgUnitEnabled.Checked = organizationalUnit.IsEnabled;
				cbAllowProjectCreation.Checked = organizationalUnit.AllowProjectCreationInRm;
				cbProjOrgUnit.Checked = organizationalUnit.IsProjectOrganizationalUnit;
				if (cbIsOrgUnitEnabled.Checked)
				{
					hdnWasOrgUnitEnabled.Value = "1";
				}
			}
			else
			{
				ErrorMessage = string.Format("Organization Unit with Id {0} not found in system", organizationalUnitId);
				HasError = true;
				return;
			}

			if (organizationalUnit.OrganizationId != organizationId)
			{
				ErrorMessage = string.Format("Organizational Unit Id {0} is not associated with Organization Id {1}", organizationalUnitId, organizationId);
				HasError = true;
				return;
			}
		}

		private void ValidateQueryStringParameters(out int organizationId, out int organizationalUnitId)
		{
			organizationalUnitId = Constants.UnspecifiedId;
			organizationId = Constants.UnspecifiedId;

			var containsOrganizationKey = false;
			var containsOrganizationalUnitKey = false;
			foreach (var key in Request.QueryString.AllKeys)
			{
				if (!containsOrganizationKey && KEY_ORGANIZATION.Equals(key, StringComparison.InvariantCultureIgnoreCase))
				{
					containsOrganizationKey = true;
					organizationId = Request.QueryString[key].ToInt(Constants.UnspecifiedId);
				}

				if (!containsOrganizationalUnitKey && KEY_ORGANIZATION_UNIT.Equals(key, StringComparison.InvariantCultureIgnoreCase))
				{
					containsOrganizationalUnitKey = true;
					organizationalUnitId = Request.QueryString[key].ToInt(Constants.UnspecifiedId);
				}

			}
			if (organizationalUnitId == Constants.UnspecifiedId) { throw new ArgumentException("Parameter ouid not specifiec or is invalid"); }
			if (organizationId == Constants.UnspecifiedId) { throw new ArgumentException("Parameter oid not specifiec or is invalid"); }
		}
		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "PageActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = GetRibbonButtonList()
			});

			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Organizations",
				Groups = PageGroups.ToArray()
			};
		}

		private ControlDefinition[] GetRibbonButtonList()
		{
			var hasAccessToEditOrg = RmFunction.HasPermissionToFunction(RmFunction_E.Edit_Organizations, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
			hdnHasAccessToEditOrg.Value = hasAccessToEditOrg.GetIntAsStringFromBool();

			var buttonList = new List<ControlDefinition>();
			if (hasAccessToEditOrg)
			{
				buttonList.Add(new ButtonDefinition()
												{
													Id = "SaveGrid",
													Title = "Save",
													CommandEnableJavaScript = "editOrgNs.isSaveButtonEnabled()",
													CommandJavaScript = "editOrgNs.save()",
													Image = MapImageLibrary.GetFormatMapImage(8, 13, revision)
												});
				buttonList.Add(new ButtonDefinition()
												{
													Id = "DeleteQipGrid",
													Title = "Delete Qip Data",
													CommandEnableJavaScript = "editOrgNs.isDeleteButtonEnabled()",
													CommandJavaScript = "editOrgNs.Delete()",
													Image = ImageLibrary.GetStandardImage(11, 8, revision)
												});
				buttonList.Add(new ButtonDefinition()
												{
													Id = "CancelGrid",
													Title = "Cancel",
													CommandJavaScript = "editOrgNs.cancel()",
													CommandEnableJavaScript = "editOrgNs.isCancelButtonEnabled()",
													Image = MapImageLibrary.GetFormatMapImage(6, 12, revision)
												});
			}

			buttonList.Add(new ButtonDefinition()
															{
																Id = "CloseGrid",
																Title = "Close",
																CommandJavaScript = "editOrgNs.close()",
																CommandEnableJavaScript = "editOrgNs.isCloseButtonEnabled()",
																Image = MapImageLibrary.GetFormatMapImage(9, 14, revision)
															});

			return buttonList.ToArray();
		}
	}
}
