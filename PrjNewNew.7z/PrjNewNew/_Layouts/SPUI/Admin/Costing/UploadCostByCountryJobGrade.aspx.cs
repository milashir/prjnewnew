﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.ExcelFiles;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RM.Excel.ExcelUploadManager;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.CostingAdmin
{
	public partial class UploadCostByCountryJobGrade : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.UploadCostByCountryJobGrade; } }
		protected bool ShowSuccess { get; set; }
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			phError.Visible = false;

			if (!IsPostBack)
			{
				UIUtility.BindDropDown(ddlYear, CountryJobGradeCostRateExcel.GetAvailableYears(), true);
			}
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "PageActions",
				Title = "Costings Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                             new ButtonDefinition()
                            {
                                Id="uploadCosting",
                                Title="Upload",
                                CommandEnableJavaScript = "uploadByCjgNs.isUploadButtonEnabled()",
                                CommandJavaScript = "uploadByCjgNs.upload()",
                                Image=MapImageLibrary.GetFormatMapImage(11,15, revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="downloadCosting",
                                Title="Download",
                                CommandJavaScript = "uploadByCjgNs.download()",
                                CommandEnableJavaScript = "uploadByCjgNs.isDownloadButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(0,11, revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="downloadTemplate",
                                Title="Download Excel Template",
                                CommandJavaScript = "uploadByCjgNs.downloadTemplate()",
                                CommandEnableJavaScript = "uploadByCjgNs.isDownloadTemplateButtonEnabled()",
                                Image=ImageLibrary.GetStandardImage(0,11, revision)
                            }
                }
			});

			return new TabDefinition()
			{
				Id = "Ribbon",
				Title = "Upload Costings",
				Groups = PageGroups.ToArray()
			};
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			int year;
			if (int.TryParse(txtYear.Text, out year))
			{
				try
				{
					UploadManager.UploadExcelFile<CountryJobGradeCostRateExcel, CountryJobGradeCostRate, CountryJobGradeAdditionalData>(fuCostingFile.PostedFile.InputStream, new CountryJobGradeAdditionalData { Year = year });
					ddlYear.Items.Clear();
					UIUtility.BindDropDown(ddlYear, CountryJobGradeCostRateExcel.GetAvailableYears(), true);
					ShowSuccess = true;
				}
				catch (Exception ex)
				{
					ShowErrorOnPage(ex.Message.Replace(Environment.NewLine, "<br/>"));
				}
			}
			else
			{
				ShowErrorOnPage("Please enter integer value in Year field.");
			}
		}

		private void ShowErrorOnPage(string errorMessage)
		{
			phError.Visible = true;
			ltrError.Text = errorMessage;
		}
	}
}
