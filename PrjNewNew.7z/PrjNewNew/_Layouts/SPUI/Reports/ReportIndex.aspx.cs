﻿using System;
using System.Linq;
using System.Text;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Reports
{
	public partial class ReportIndex : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.Reports; } }
		public string PageTitle { get { return "Spotfire Reports"; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			ShowReportLinksOnPage();
		}

		private void ShowReportLinksOnPage()
		{
			var sb = new StringBuilder();

			foreach (var reportLConfig in CacheService.SpotfireReports.Values.OrderBy(r => r.SortOrder))
			{
				if (reportLConfig != null && reportLConfig.IsVisible)
				{
					if (reportLConfig.OpenDirectLink)
					{
						sb.AppendFormat(ltrRptDirectLinkTemplate.Text, reportLConfig.FullReportPath, reportLConfig.Name, reportLConfig.Blurb, reportLConfig.TargetAudience);
					}
					else
					{
						sb.AppendFormat(ltrRptEmbeddedLinkTemplate.Text, reportLConfig.Id, reportLConfig.Name, reportLConfig.Blurb, reportLConfig.TargetAudience);
					}
				}
			}
			ltrReportList.Text = sb.ToString();
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "ReportRibbon",
				Title = PageTitle,
				Groups = PageGroups.ToArray()
			};
		}
	}
}
