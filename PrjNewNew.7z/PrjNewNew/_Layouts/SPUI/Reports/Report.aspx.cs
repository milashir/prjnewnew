﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Reports
{
	public partial class Report : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.Reports; } }
		public string PageTitle { get; private set; }
		public string FullReportUrl { get; private set; }
		private const string REPORT_INDEX_PAGE = "ReportIndex.aspx";

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			ShowReport();
		}

		private void ShowReport()
		{
			int reportId;
			SpotfireReport reportLConfig;
			if (int.TryParse(Request["ReportId"], out reportId) && CacheService.SpotfireReports.TryGetValue(reportId, out reportLConfig))
			{
				if (reportLConfig.OpenDirectLink)
				{
					Response.Redirect(reportLConfig.FullReportPath);
				}
				else
				{
					FullReportUrl = reportLConfig.FullReportPath;
					PageTitle = reportLConfig.Name;
					ltrReportHeading.Text = reportLConfig.Name;
				}
			}
			else
			{
				Response.Redirect(REPORT_INDEX_PAGE);
			}
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "ReportRibbon",
				Title = PageTitle,
				Groups = PageGroups.ToArray()
			};
		}
	}
}
