﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class ProjectBackground : AbstractProjectProfileLayoutPage
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ProjectBackground; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			string projectId = string.Empty;
			string isPPMProject = string.Empty;
			if (UserCache.ProjectName != null)
			{
				ClientScript.RegisterClientScriptBlock(this.GetType(), "selectedProjectDetails", "<script>var selectedProjectDetails = {projectCode:'" + base.CurrentProject.Name + "',protocolNumber:'" + base.CurrentProject.ProtocolNumber + "'};</script>");
			}

			PopulateControls();
			if (CurrentProject != null)
			{
				LoadedSuccessfully.Value = "1";
				ProjectName.Value = CurrentProject.Name;
				ProtocolNumber.Value = CurrentProject.ProtocolNumber;
				OrganizationUnitName.Value = CurrentProject.OrganizationalUnit.Name;
				ltrIcon.Text = CurrentProject.GetNotesColumnValue();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		/// <author>Ganesan Subburaj</author>
		protected override void GetPageGroupDefinitions(IList<GroupDefinition> PageGroups)
		{
			tabTitle = "Project Background";

			PageGroups.Add(new GroupDefinition()
			{
				Id = "ActionsForRMProject",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="SaveRMProject",
                                Title="Save",
                                CommandJavaScript = "rmProjNs.saveRmProject();",
                                CommandEnableJavaScript = "rmProjNs.isSaveButtonEnabled()",
                                Image=ImageLibrary.GetStandardImage(8, 13, revision)
                            },
                            new ButtonDefinition() {
                                Id="CancelRMProject",
                                Title="Cancel",
                                CommandJavaScript = "rmProjNs.cancelRmProject();",
                                CommandEnableJavaScript = "rmProjNs.isCancelButtonEnabled()",
                                Image=ImageLibrary.GetStandardImage(6, 12, revision)
                            },
                            new ButtonDefinition() {
                                Id="RefreshCRMData",
                                Title="Refresh CRM Data",
                                CommandJavaScript = "rmProjNs.refreshProjectDataFromCrm();",
                                CommandEnableJavaScript = "true",
                                Image=MapImageLibrary.GetPSImage(7,4, revision)
                            }
                    }
			});
		}

		private void PopulateControls()
		{
			UIUtility.BindDropDown(ddlTherapeuticArea, CacheService.TherapeuticAreasActive, false);
			UIUtility.BindDropDown(ddlCompetencyBand, CacheService.AllCompetencyBands, true);
		}
	}
}
