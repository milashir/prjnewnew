﻿using System;
using System.Linq;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile
{
	public partial class ProposalProjectDetails : AbstractRmRibbonPageLayout
	{
		private RmPageLink_E? _rmPageLink = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					var strRmPageLink = Request["rmPageLink"];
					_rmPageLink = string.IsNullOrEmpty(strRmPageLink) ? RmPageLink_E.ProposalRequests : (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), strRmPageLink);
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			EnableViewState = false;
			PopulateControls();
		}

		#region PopulateControls
		private void PopulateControls()
		{
			UIUtility.BindDropDown(ddlOrganization, CacheService.AllProjectOrganizationalUnitsOrderByName, true);
			UIUtility.BindDropDown(ddlTherapeuticArea, CacheService.TherapeuticAreasActive, false);
			UIUtility.BindDropDown(ddlStudyPhase, CacheService.StudyPhases);
			UIUtility.BindDropDown(ddlWinProbability, CacheService.WinProbabilities.Values.OrderBy(wp => wp.CrmName));
		}
		#endregion

		#region GetTabDefinition
		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="SelectOpportunityNumber",
                                Title="Select Opportunity Number",
                                CommandJavaScript = "proposalNs.SelectOpportunityNumber();",
                                CommandEnableJavaScript = "true",
                                Image=MapImageLibrary.GetPSImage(6,8, revision)
                            },
														//MR: Converted from Colin's menu hack to FluentRibbon 1.4 ControlsSize
                            new FlyoutAnchorDefinition()
                            {
                                Id="RecentOpportunityNumbers",
                                Title="Recent Opportunity Numbers",
                                Image=ImageLibrary.GetStandardImage(13,5, revision),
																ControlsSize = ControlSize.Size16x16,
                                Controls = GetRecentProposalProjects()
                            }
                }
			});

			PageGroups.Add(new GroupDefinition()
			{
				Id = "ActionsForProposalForm",
				Title = "Actions for Proposal Form",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="SaveProposalForm",
                                Title="Save",
                                CommandJavaScript = "proposalNs.SaveProposalForm();",
                                CommandEnableJavaScript = "proposalNs.IsSaveProposalButtonEnabled()",
                                Image=ImageLibrary.GetStandardImage(8, 13, revision)
                            },
                            new ButtonDefinition() {
                                Id="CancelProposalForm",
                                Title="Cancel",
                                CommandJavaScript = "proposalNs.CancelProposalForm();",
                                CommandEnableJavaScript = "proposalNs.IsCancelButtonEnabled()",
                                Image=ImageLibrary.GetStandardImage(6, 12, revision)
                            }
                }
			});

			return new TabDefinition()
			{
				Id = "RequestRibbon",
				Title = "Add Proposal Project",
				Groups = PageGroups.ToArray()
			};
		}

		private ButtonDefinition[] GetRecentProposalProjects()
		{
			List<ButtonDefinition> rv = new List<ButtonDefinition>();
			//IList<RecentEntity> recents = RecentEntity.FindAllByEntity<Project>();
			IList<RecentEntity> recents = RecentEntity.GetRecentProjects(OpportunityStatus_E.Open);
			if (recents != null && recents.Count > 0)
			{
				var index = 0;
				foreach (RecentEntity re in recents)
				{
					rv.Add(new ButtonDefinition()
					{
						Id = string.Format("RecentProp_{0}", index++),
						Title = re.EntityName,
						CommandJavaScript = "proposalNs.ChangeProposalProject('" + re.EntityName + "');"
					});

				}

				rv.Add(new ButtonDefinition()
				{
					Id = "ClearRecentProjectsList",
					Title = "Clear List",
					CommandJavaScript = "proposalNs.ClearRecentProposalProjectsList();"
				});
			}
			else
			{
				rv.Add(new ButtonDefinition()
				{
					Id = "NoRecentProjectsList",
					Title = "No Recent Proposal Projects",
					CommandJavaScript = "false;"
				});
			}

			return rv.ToArray();
		}
		#endregion
	}
}
