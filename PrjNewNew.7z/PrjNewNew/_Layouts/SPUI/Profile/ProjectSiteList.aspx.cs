﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.DTE;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Models.Requests;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile
{
	public partial class ProjectSiteList : AbstractProjectProfileLayoutPage
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ProjectSiteList; } }
		public bool AllowEdit { get; set; }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			ShowAddRmProjectButton = false;

			AllowEdit = RmFunction.HasPermissionToFunction(RmFunction_E.Update_Site_Tiers, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
			hdnAllowEdit.Value = AllowEdit.GetIntAsStringFromBool();

			if (CurrentProject != null)
			{
				hdnProjectId.Value = CurrentProject.Id.ToString();
				ProjectName.Value = CurrentProject.Name;
				ProtocolNumber.Value = CurrentProject.ProtocolNumber;
				OrganizationUnitName.Value = CurrentProject.OrganizationalUnit.Name;
				isDteProject.Value = CurrentProject.IsDteProject.GetIntAsStringFromBool();
				isSchemaDefinedByUser.Value = CurrentProject.HasUserDefinedSchema.GetIntAsStringFromBool();
				hdnAllowInitialTiering.Value = CurrentProject.IsIntialTieringAllowed().GetIntAsStringFromBool();
				string tierName;
				hdnIsRequiredTierEnabledForInitialSiteTiering.Value = CurrentProject.IsRequiredTierEnabledForInitialSiteTiering(out tierName).GetIntAsStringFromBool();
				hdnIsInitialSiteTieringAlreadyPerformed.Value = CurrentProject.InitialTieringPerformed.GetIntAsStringFromBool();
				ProjectFirstSivPassed.Visible = (DateTime.Today > CurrentProject.FirstSiteInitiatedDate);
				_LoadedSuccessfully.Value = "1";
				var monitoringAttrSummary = MonitoringAttribute.GetSiteCountAndVisitCountSummary(CurrentProject.Id);
				lblTotalProjectedInitiatedSites.Text = monitoringAttrSummary.TotalProjectedInitiatedSites.ToString();
				lblTotalSelectedSites.Text = monitoringAttrSummary.TotalActualActiveSites.ToString();
				var selectedSitePct = monitoringAttrSummary.TotalProjectedInitiatedSites == 0 ? 0 : ((monitoringAttrSummary.TotalActualActiveSites * 100) / monitoringAttrSummary.TotalProjectedInitiatedSites);
				lblSelectedSitePct.Text = selectedSitePct.ToString();
				LessThan50PctSitesSelected.Visible = (selectedSitePct < 50);
				hdnHasUserDefinedSchema.Value = CurrentProject.HasUserDefinedSchema.GetIntAsStringFromBool();
				hdnIsDteSchemaAlreadyConfigured.Value = VisitSchemaLevelTier.IsDteSchemaAlreadyConfigured(CurrentProject.Id).GetIntAsStringFromBool();
				hdnIsRbmProjectManagedAsNonRbmInRm.Value = CurrentProject.IsRbmProjectManagedAsNonRbmInRm.GetIntAsStringFromBool();
				divLastPeriodicReviewDateContainer.Visible = CurrentProject.IsDteProject;

				if (CurrentProject.IsDteProject)
				{
					rpt_TierChangeReasonList.DataSource = CacheService.SiteTierChangeReasons.Values.Where(cr => cr.IsActive && cr.ShowOnUi).OrderBy(cr => cr.SortOrder);
					rpt_TierChangeReasonList.DataBind();

					rpt_NoRegTierReviewReasonList.DataSource = CacheService.NoRegularTierReviewReason.Values.OrderBy(cr => cr.Name);
					rpt_NoRegTierReviewReasonList.DataBind();

					var periodicReviewHistory = PeriodicProjectSiteTierReviewHistory.GetLastTierReviewCompletionInfo(CurrentProject.Id);
					if (periodicReviewHistory != null)
					{
						lblLastPeriodicReviewDate.Text = periodicReviewHistory.LastReviewPerformedBy;
					}
				}
			}
			else
			{
				isDteProject.Value = "0";
				isSchemaDefinedByUser.Value = "0";
				hdnAllowInitialTiering.Value = "0";
				hdnIsRequiredTierEnabledForInitialSiteTiering.Value = "0";
				hdnIsInitialSiteTieringAlreadyPerformed.Value = "0";
			}
		}

		protected override void GetPageGroupDefinitions(IList<GroupDefinition> PageGroups)
		{
			tabTitle = "Site List";

			if (CurrentProject != null && CurrentProject.IsDteProject && AllowEdit)
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "GridActions",
					Title = "Initial Site Tiering",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
                    {
                        new ButtonDefinition()
                        {
                            Id="InitialSiteTieringBtn",
                            Title="Initial Site Tiering...",
                            CommandJavaScript = "siteListNs.performInitialSiteTiering();",
                            CommandEnableJavaScript = "siteListNs.isPerformInitialSiteTieringEnabled();",
                            Image = MapImageLibrary.GetFormatMapImage(7, 2, revision)
                        }
                    }
				});

				PageGroups.Add(new GroupDefinition()
					{
						Id = "GridActions2",
						Title = "Site Intelligence Tier Review",
						Template = GroupTemplateLibrary.SimpleTemplate,
						Controls = new ControlDefinition[]
                    {
												new CheckboxDefinition()
												{
                            Id="cbNoReviewReason",
                            Title="Regular Tier Review Required",
                            CommandJavaScript = "siteListNs.handleRegularTierReivewRequiredCheckChangeEvent();",
                            CommandEnableJavaScript = "siteListNs.isRegularTierReivewRequiredEnabled();",
														Checked = CurrentProject!= null && CurrentProject.RegularTierReviewRequired.GetValueOrDefault()
                        },
												new ButtonDefinition()
                        {
                            Id="CompletePeriodicTierReviewBtn",
                            Title="Monthly Tier Review Completed",
                            CommandJavaScript = "siteListNs.completePeriodicTierReview();",
                            CommandEnableJavaScript = "siteListNs.isCompletePeriodicTierReviewEnabled();",
                            Image = MapImageLibrary.GetFormatMapImage(8, 4, revision)
                        },
												new ButtonDefinition()
                        {
                            Id="StartTierReviewBtn",
                            Title="Start Site Intelligence Tier review...",
                            CommandJavaScript = "siteListNs.startSiteIntelligenceTierReview();",
                            CommandEnableJavaScript = "siteListNs.isStartSiteIntelligenceTierReviewEnabled();",
                            Image = MapImageLibrary.GetFormatMapImage(6, 1, revision)
                        },
												new ButtonDefinition()
                        {
                            Id="AcceptRecommendedTierBtn",
                            Title="Apply Changes",
                            CommandJavaScript = "siteListNs.applyRecommendedTierChanges();",
                            CommandEnableJavaScript = "siteListNs.isApplyRecommendedTierChangesEnabled();",
                            Image = MapImageLibrary.GetFormatMapImage(8,13, revision)
                        },
												new ButtonDefinition()
                        {
                            Id="CancelRecommendedTierBtn",
                            Title="Cancel",
                            CommandJavaScript = "siteListNs.cancelSiteIntelligenceTierReview();",
                            CommandEnableJavaScript = "siteListNs.isCancelSiteIntelligenceTierReviewEnabled();",
                            Image = MapImageLibrary.GetFormatMapImage(6,12, revision)
                        },
                    }
					});
			}
		}

		protected string RenderTierChangeReasonCheckbox(SiteTierChangeReason reason)
		{
			return string.Format("<tr><td><input type='checkbox' value='{0}' isOther='{1}' class='reasonCb' /></td><td>{2}</td></tr>", reason.Id, reason.IsOther.GetIntAsStringFromBool(), reason.Name.Replace("'", "&quot;"));
		}
		protected string RenderNoRegularTierReviewReasonCheckbox(NoRegularTierReviewReason reason)
		{
			return string.Format("<input type='radio' group='rbgNoReviewReason' name='rbNoReviewReason'  id='rbNoReviewReason_{0}' value='{0}'><label for='rbNoReviewReason_{0}'> {1}<br/>", reason.Id, reason.Name.Replace("'", "&quot;"));
		}
	}
}
