﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile
{
	public partial class MonitoringAttributes : AbstractProjectProfileLayoutPage
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.MonitoringAttributes; } }
		private bool AllowEdit { get; set; }

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			this.UndefinedSchemaProject.Value = "0";
			this.UndefinedDTEProjectFlag.Value = "0";
			divQipVersion.Visible = CurrentProject != null;

			AllowEdit = RmFunction.HasPermissionToFunction(RmFunction_E.Modify_Monitoring_Attributes, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
			hdnAllowEdit.Value = AllowEdit.GetIntAsStringFromBool();
			ShowBudgetRefreshButton = AllowEdit;

			if (CurrentProject != null)
			{
				string error;
				if (!CurrentProject.AreMilestonesValidByCalcualtorGroupAndDteType(out error))
				{
					hdnDateValidatioError.Value = error;
					ltrDateValidationError.Visible = true;
				};
				hdnIsProposalProject.Value = CurrentProject.IsProposalProject.GetIntAsStringFromBool();
				hdnProjectId.Value = CurrentProject.Id.ToString();
				lblBudgetingSystem.Text = CurrentProject.BudgetingSystemName;
				lblBudgetVersion.Text = CurrentProject.GetBudgetVersion();
				ProjectName.Value = CurrentProject.Name;
				ProtocolNumber.Value = CurrentProject.ProtocolNumber;
				OrganizationUnitName.Value = CurrentProject.OrganizationalUnit.Name;
				hdnIsRbmProjectManagedAsNonRbmInRm.Value = CurrentProject.IsRbmProjectManagedAsNonRbmInRm.GetIntAsStringFromBool();
				LoadedSuccessfully.Value = "1";
				if (CurrentProject.IsDteProject && (CurrentProject.VisitSchemaLevelId == (int)VisitSchemaLevel_E.Unknown || CurrentProject.VisitSchemaLevelId == null))
				{
					this.UndefinedSchemaProject.Value = "1";
				}
				if (ProjectDteType_E.Unknown.Equals(CurrentProject.ProjectDteType))
				{
					this.UndefinedDTEProjectFlag.Value = "1";
				}

				var summary = MonitoringAttribute.GetSiteCountAndVisitCountSummary(CurrentProject.Id);
				TotalQipBudgetedSites.InnerText = summary.TotalBudgetedSites.ToString();
				TotalProjectedInitiatedSites.InnerText = summary.TotalProjectedInitiatedSites.ToString();
				TotalActualActiveSites.InnerText = summary.TotalActualActiveSites.ToString();

				TotalQipBudgetedSivCovVisitCount.InnerText = (summary.TotalQipBudgetedSivVisitCount + summary.TotalQipBudgetedCovVisitCount).ToString();
				TotalQipBudgetedOnsiteImvVisitCount.InnerText = summary.TotalQipBudgetedOnsiteImvVisitCount.ToString();
				TotalQipBudgetedPharmacyVisitCount.InnerText = summary.TotalQipBudgetedPharmacyVisitCount.ToString();
				TotalQipBudgetedRemoteVisitCount.InnerText = summary.TotalQipBudgetedRemoteVisitCount.ToString();
				TotalBudgetedBoosterVisitCount.InnerText = summary.TotalBudgetedBoosterVisitCount.ToString();

				TotalProjectedSivCovVisitCount.InnerText = (summary.TotalProjectedSivVisitCount + summary.TotalProjectedCovVisitCount).ToString();
				TotalProjectedOnsiteImvVisitCount.InnerText = summary.TotalProjectedOnsiteImvVisitCount.ToString();
				TotalProjectedPharmacyVisitCount.InnerText = summary.TotalProjectedPharmacyVisitCount.ToString();
				TotalProjectedRemoteVisitCount.InnerText = summary.TotalProjectedRemoteVisitCount.ToString();
			}
			else
			{
				ProjectName.Value = String.Empty;
				ProtocolNumber.Value = string.Empty;
				LoadedSuccessfully.Value = "0";
			}
		}

		private void ValidateProjectMilestones()
		{
			throw new NotImplementedException();
		}

		protected override void GetPageGroupDefinitions(IList<GroupDefinition> PageGroups)
		{
			//MR: Because all project summary pages inherit from parent class
			tabTitle = "Monitoring Attributes";

			if (AllowEdit)
			{
				PageGroups.Add(new GroupDefinition()
					{
						Id = "GridActions",
						Title = "Actions",
						Template = GroupTemplateLibrary.SimpleTemplate,
						Controls = new ControlDefinition[]
                    {
                        new ButtonDefinition()
                        {
                            Id="SaveGrid",
                            Title="Save",
                            CommandJavaScript = "maNs.saveGrid();",
                            CommandEnableJavaScript = "maNs.isSaveEnabled();",
                            Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
                        },
                        new ButtonDefinition()
                        {
                            Id="CancelGrid",
                            Title="Cancel",
                            CommandJavaScript = "maNs.cancelGrid();",
                            CommandEnableJavaScript = "maNs.isCancelEnabled();",
                            Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
                        },
												new ButtonDefinition() {
														Id="EditSingleRow",
														Title="Modify Country",
														CommandJavaScript = "maNs.modifySingleAttribute();",
														CommandEnableJavaScript = "maNs.isModifySingleAttributeEnabled();",
														Image=MapImageLibrary.GetPSImage(3,11, revision)
												},
												new ButtonDefinition() {
														Id="EditMultipleRow",
														Title="Modify Countries",
														CommandJavaScript = "maNs.modifyMultipleAttributes();",
														CommandEnableJavaScript = "maNs.isModifyMultipleAttributesEnabled();",
														Image=MapImageLibrary.GetPSImage(3,11, revision)
												}
                    }
					});
			}

			if (CurrentProject != null &&
					CurrentProject.OrganizationalUnit.Id == (int)OrganizationalUnit_E.Biogen &&
					RmFunction.HasPermissionToFunction(RmFunction_E.Copy_Pricing_Budgeted_Sites_to_Projected_Initiated_Sites, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null)))
			{

				PageGroups.Add(new GroupDefinition()
				{
					Id = "GridActions2",
					Title = "Other Actions",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
                    {
                        new ButtonDefinition()
                        {
															Id = "CopySiteInfo",
															Title = "Copy 'Budgeted Sites' to Projected Initiated Sites'",
															CommandJavaScript = "maNs.copyBudgetedSitesToProjectedInitiatedSites();",
															CommandEnableJavaScript = "maNs.isCopyBudgetedSitesToProjectedInitiatedSitesEnabled();",
															Image = MapImageLibrary.GetRMImage(12, 6, revision)
														}
                    }
				});
			}
		}
	}
}
