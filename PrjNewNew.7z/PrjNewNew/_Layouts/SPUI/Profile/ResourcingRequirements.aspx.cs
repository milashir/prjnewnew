﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class ResourcingRequirements : AbstractProjectProfileLayoutPage
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.OpenToAll; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			if (CurrentProject != null)
			{
				ProjectName.Value = CurrentProject.Name;
				ProtocolNumber.Value = CurrentProject.ProtocolNumber;
				OrganizationUnitName.Value = CurrentProject.OrganizationalUnit.Name;
				LoadedSuccessfully.Value = "1";
				HdnProjectId.Value = CurrentProject.Id.ToString();
				HdnResourcingRequirementsTypeId.Value = CurrentProject.ResourceRequirementsTypeId.ToString();
				var hasModifyAccess = RmFunction.HasPermissionToFunction(RmFunction_E.Modify_Resourcing_Requirements, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
				HdnUserHasEditAccess.Value = hasModifyAccess.ToString();
				divInstructionalText.Visible = !hasModifyAccess;
				if (!hasModifyAccess)
				{
					ltrResourceTypeList.Text = ResourceType.GetResourceTypesAllowingResReqMangement();
				}
			}
			else
			{
				ProjectName.Value = String.Empty;
				ProtocolNumber.Value = string.Empty;
				LoadedSuccessfully.Value = "0";
				HdnUserHasEditAccess.Value = "False";
				divInstructionalText.Visible = false;
			}
		}

		//private bool HasModifyAccessToResourcingRequirement(Project selectedProject)
		//{
		//	return selectedProject == null ? this.RmUser.HasAccessToResourcingRequirementLink() : this.RmUser.HasAccessToResourcingRequirementLink(selectedProject.Id);
		//}

		protected override void GetPageGroupDefinitions(IList<GroupDefinition> PageGroups)
		{
			//mr: because all project summary pages inherit from parent class
			tabTitle = "Resourcing Requirements";
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Resourcing Requirements",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="AddReq",
                                Title="Add",
                                CommandJavaScript = "ResourcingRequirements.AddRequirements();",
																CommandEnableJavaScript = "ResourcingRequirements.AddEnabled();",
                                Image=ImageLibrary.GetStandardImage(0,8, revision)
                            },
                            new ButtonDefinition() {
                                Id="ModifyReq",
                                Title="Modify",
                                CommandJavaScript = "ResourcingRequirements.ModifyRequirements();",
																CommandEnableJavaScript = "ResourcingRequirements.ModifyEnabled();",
                                Image=ImageLibrary.GetStandardImage(0,11, revision)
                            },
														 new ButtonDefinition() {
                                Id="SaveReq",
                                Title="Save",
                                CommandJavaScript = "ResourcingRequirements.SaveRequirements();",
																CommandEnableJavaScript = "ResourcingRequirements.SaveEnabled();",
                                Image=ImageLibrary.GetStandardImage(8,13, revision)
                            },
														 new ButtonDefinition() {
                                Id="DeleteReq",
                                Title="Delete",
                                CommandJavaScript = "ResourcingRequirements.DeleteRequirements();",
																CommandEnableJavaScript = "ResourcingRequirements.DeleteEnabled();",
                                Image=ImageLibrary.GetStandardImage(11, 8, revision)
                            },
														 new ButtonDefinition() {
                                Id="CancelReq",
                                Title="Cancel",
                                CommandJavaScript = "ResourcingRequirements.CancelRequirements();",
																CommandEnableJavaScript = "ResourcingRequirements.CancelEnabled();",
                                Image=ImageLibrary.GetStandardImage(6,12, revision)
														},
														 new ButtonDefinition() {
																Id="CloseReq",
																Title="Close",
																CommandJavaScript = "ResourcingRequirements.CloseRequirements();",
																CommandEnableJavaScript = "ResourcingRequirements.CloseEnabled();",
																Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
                            }
                    }
			});
		}
	}
}
