﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.UI.Layouts.SPUI
{
	public partial class ProjectDetails : AbstractProjectProfileLayoutPage
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ProjectSummary; } }
		protected global::Quintiles.RM.Clinical.UI.UserControls.ProjectDetailsContainer projectDetailsContainer;

		protected override void Page_Load(object sender, EventArgs e)
		{
			ShowBudgetRefreshButton = ConfigValue.QipRefreshEnabled;
			base.Page_Load(sender, e);

			if (CurrentProject != null)
			{
				projectDetailsContainer.ProjectId = CurrentProject.Id; ;
				hdnProjectId.Value = CurrentProject.Id.ToString();
				lblServiceContracted.Text = CurrentProject.ServicesContracted;
				lblotherProjectInformation.Text = CurrentProject.OtherProjectInformation;
				LoadedSuccessfully.Value = "1";
				ProjectName.Value = CurrentProject.Name;
				txtProjectNameProtocolNumber.Value = UserCache.ProjectNameProtocolNumberString;
				ProtocolNumber.Value = CurrentProject.ProtocolNumber;
				HasPermissionToEnableDisableInitialSiteTiering.Value = RmFunction.HasPermissionToFunction(RmFunction_E.Modify_Allow_Initial_Site_Tiering_Field, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null)).GetIntAsStringFromBool();
				hdnIsRbmProjectManagedAsNonRbmInRm.Value = CurrentProject.IsRbmProjectManagedAsNonRbmInRm.GetIntAsStringFromBool();
				if (CurrentProject.OrganizationalUnit != null)
				{
					OrganizationUnitName.Value = CurrentProject.OrganizationalUnit.Name;
				}
			}
			else
			{
				LoadedSuccessfully.Value = "0";
				ProjectName.Value = string.Empty;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		/// <author>Ganesan Subburaj</author>
		protected override void GetPageGroupDefinitions(IList<GroupDefinition> PageGroups)
		{

			tabTitle = "Project Summary";

			PageGroups.Add(new GroupDefinition()
			{
				Id = "ProjectBackgroundActions",
				Title = "Project Summary Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
                         {
                             new ButtonDefinition()
                             {
                                 Id="EditProject",
                                 Title="Edit Project",
                                 CommandJavaScript = "EditProjectBackground()",
                                 CommandEnableJavaScript =  CurrentProject == null ? "false": "editProject.isEditProjectEnabled()" ,
                                 Image=MapImageLibrary.GetRMImage(15, 6, revision)
														 },
                             new ButtonDefinition()
                             {
                                 Id="SaveProject",
                                 Title="Save",
                                 CommandJavaScript = "editProject.saveProject()",
                                 CommandEnableJavaScript = "editProject.isSaveProjectEnabled()",
                                 Image = MapImageLibrary.GetFormatMapImage(8,13, revision)
														 },
                             new ButtonDefinition()
                             {
                                 Id="CancelProject",
                                 Title="Cancel",
                                 CommandJavaScript = "editProject.cancelChanges()",
                                 CommandEnableJavaScript = "editProject.isCancelChangesEnabled()",
                                 Image = ImageLibrary.GetStandardImage(6, 12, revision)
														 },
                             new ButtonDefinition()
                             {
                                 Id="CloseProject",
                                 Title="Close",
                                 CommandJavaScript = "editProject.stopEditing()",
                                 CommandEnableJavaScript = "editProject.isStopEditingEnabled()",
                                 Image = MapImageLibrary.GetFormatMapImage(9,14, revision)
														 },
														 new ButtonDefinition()
                             {
                                 Id="AddFirewalledProjects",
                                 Title="Configure Firewalled Projects",
                                 CommandJavaScript = "FirewallProject.ConfigureFirewalledProjects()",
                                 CommandEnableJavaScript = (CurrentProject != null && !CurrentProject.IsProposalProject)?"true":"false",
                                 Image=MapImageLibrary.GetRMImage(10, 15, revision)
                             }
                         }
			});
		}

		private Literal GenerateDynamicFields(ProjectBackroundDetails backgroundDetail)
		{
			Literal dynamictr = new Literal();
			string titleText = string.Empty;
			if (!string.IsNullOrEmpty(backgroundDetail.FieldValue) && backgroundDetail.FieldValue.Length > 45)
			{
				titleText = backgroundDetail.FieldValue;
			}
			// Text area for Sponsor and Project description
			if (backgroundDetail.DisplayLabel.Contains("Sponsor") ||
					backgroundDetail.DisplayLabel.Contains("Description"))
			{
				dynamictr.Text = string.Format(@"<tr>
														<td class=""projectAttributesText"" nowrap>{0}</td>
														<td><div class=""projectAttributesBackgroundDynamic paBackDouble"" title=""{1}"">{2}</div></td>
													</tr>",
													backgroundDetail.DisplayLabel,
													titleText,
													backgroundDetail.FieldValue);
			}
			else if (backgroundDetail.DisplayLabel.Contains("Clinical Redesign") &&
							 CurrentProject.OrganizationType != null &&
							 CurrentProject.OrganizationType != OrganizationType_E.TDU)
			{
				dynamictr.Text = string.Format(@"<tr>
															<td class=""projectAttributesText"" nowrap>{0}</td>
															<td><div class=""projectAttributesBackgroundDynamic"" title=""{1}"">{2}</div></td>
														</tr>",
													backgroundDetail.DisplayLabel,
													titleText,
													backgroundDetail.FieldValue.ToLower() == "true" ? "Yes" : "No");
			}
			else
			{
				dynamictr.Text = string.Format(@"<tr>
														<td class=""projectAttributesText"" nowrap>{0}</td>
														<td><div class=""projectAttributesBackgroundDynamic"" title=""{1}"">{2}</div></td>
													</tr>",
													backgroundDetail.DisplayLabel,
													titleText,
													backgroundDetail.FieldValue);
			}
			return dynamictr;
		}
	}
}
