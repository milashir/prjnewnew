﻿using System;
using System.Collections.Generic;
using System.Linq;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile
{
	public partial class ProjectConfiguration : AbstractProjectProfileLayoutPage
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ProjectConfiguration; } }

		protected override void Page_Load(object sender, System.EventArgs e)
		{
			ShowBudgetRefreshButton = true;
			base.Page_Load(sender, e);
			string projectId = "0";
			string projectCode = string.Empty;
			bool isDteProject = false;
			bool isProposalProject = false;

			if (UserCache.ProjectName != null)
			{
				projectId = base.CurrentProject.Id.ToString();
				projectCode = base.CurrentProject.ProjectCode.ToString();
				LoadedSuccessfully.Value = "1";
				ProjectName.Value = CurrentProject.Name;
				ProtocolNumber.Value = base.CurrentProject.ProtocolNumber;
				OrganizationUnitName.Value = CurrentProject.OrganizationalUnit == null ? string.Empty : CurrentProject.OrganizationalUnit.Name;
				isDteProject = CurrentProject.IsDteProject;
				isProposalProject = CurrentProject.IsProposalProject;
				hdnProjectId.Value = CurrentProject.Id.ToString();
				hdnHasUserDefinedSchema.Value = CurrentProject.HasUserDefinedSchema.GetIntAsStringFromBool();
				hdnIsRbmProjectManagedAsNonRbmInRm.Value = CurrentProject.IsRbmProjectManagedAsNonRbmInRm.GetIntAsStringFromBool();
				hdnIsDteSchemaAlreadyConfigured.Value = VisitSchemaLevelTier.IsDteSchemaAlreadyConfigured(CurrentProject.Id).GetIntAsStringFromBool();
				hdnAreMilesontesValidForPseudoSchamaCreation.Value = CurrentProject.AreMilesontesValidForPseudoSchamaCreation.GetIntAsStringFromBool();
				ShowNonRbmToRbmConversionButton = CurrentProject.IsRbmProjectManagedAsNonRbmInRm &&
													RmFunction.HasPermissionToFunction(RmFunction_E.Convert_NonRbm_To_Rbm_Project,
														RmUser,
														ExtensionMethods.GetCurrentUserQid(),
														new CustomPermissionArg(CurrentProject, null));

				if (isDteProject)
				{
					VisitPatternGraphData_WS data = Project.GetVisitPatternGraphData(Convert.ToInt32(projectId));
					staticGraphData.InnerHtml = data.Body;
					ltrSivFsiWeeks.Text = CurrentProject.SivFsiWeeks.ToString();
					lblPpmProjectedInitiatedSite.Text = CurrentProject.GetSiteCountFromMonitoringAttrbute().ToString();
					lblFsiCovWeeks.Text = CurrentProject.GetFsiCovDurationWeeks();
					ShowJapanSivCovPerSite();
					hdnIsStafFileUploaded.Value = CurrentProject.HasStafExcel.GetIntAsStringFromBool();
					ltrFileSize.Text = ConfigValue.StafFileSizeLimitInMb.ToString();
					hdnAllowTierWithNoVisits.Value = CurrentProject.AllowTierWithNoVisits.GetValueOrDefault().GetIntAsStringFromBool();
				}
				lblBudgetingSystem.Text = CurrentProject.BudgetingSystemName;
				lblBudgetVersion.Text = CurrentProject.GetBudgetVersion();
				hdnIsProposalProject.Value = CurrentProject.IsProposalProject.GetIntAsStringFromBool();
			}

			var resource = Quintiles.RM.Clinical.Domain.Models.Resource.GeResourceByQId(UserCache.Usr.QId);
			var orgUnitAttributes = "organizationalUnitId:{0}, organizationalUnitName:{1}";
			if (resource != null && resource.OrganizationalUnitId.HasValue)
			{
				orgUnitAttributes = string.Format(orgUnitAttributes, resource.OrganizationalUnitId.GetValueOrDefault(), string.Format("\"{0}\"", CacheService.OrganizationalUnit(resource.OrganizationalUnitId).Name.Replace("'", "\'")));
			}
			else
			{
				orgUnitAttributes = string.Format(orgUnitAttributes, "null", "null");
			}
			var userSharePointRoleAttr = string.Format("userSharePointRole:\"{0}\"", UserCache.Usr.IsAdmin ? "Admin" : UserCache.Usr.IsSupport ? "Support" : UserCache.Usr.IsDemandPlanner ? "Demand Planner" : string.Empty);
			ClientScript.RegisterClientScriptBlock(this.GetType(), "validateuser", "<script>var globalValues = {" + userSharePointRoleAttr + "," + orgUnitAttributes + ",selectedProjectId:" + projectId + ",isProposalProject:" + isProposalProject.ToString().ToLower() + ",isDteProject:" + isDteProject.ToString().ToLower() + ",projectCode:'" + projectCode + "'};</script>");
		}

		private void ShowJapanSivCovPerSite()
		{
			var japanMa = MonitoringAttribute.FindByProjectIdCountryId(CurrentProject.Id, Constants.JapanCountryId);
			if (japanMa != null && japanMa.IsActive == 1)
			{
				var japanCalcList = FTECalculator.FindByCountryIdProjectId(Constants.JapanCountryId, CurrentProject.Id, (int)CalculatorGroup_E.DTEMonitoringCalculator);
				if (japanCalcList != null)
				{
					var japanSivCalc = japanCalcList.FirstOrDefault(sc => sc.TypeId == (int)CalculatorType_E.SIV);
					var japanCovCalc = japanCalcList.FirstOrDefault(sc => sc.TypeId == (int)CalculatorType_E.COV);
					ltrJapanSivPerSite.Text = (japanSivCalc == null) ? "N/A" : ((int)japanSivCalc.SIVPerSite.GetValueOrDefault()).ToString();
					ltrJapanCovPerSite.Text = (japanCovCalc == null) ? "N/A" : ((int)japanCovCalc.SIVPerSite.GetValueOrDefault()).ToString();
				}
				else
				{
					ltrJapanSivPerSite.Text = "N/A";
					ltrJapanCovPerSite.Text = "N/A";
				}
			}
		}

		protected override void GetPageGroupDefinitions(IList<GroupDefinition> PageGroups)
		{
			bool isMilestonesExists = false;
			bool showSchemaActions = false;

			if (base.CurrentProject != null)
			{
				CustomMilestones[] customMilestones = CustomMilestones.FindAllByProperty("ProjectId", base.CurrentProject.Id);
				if (CurrentProject.AwardDate != null ||
						CurrentProject.KickOffMeetingActualFinish != null || CurrentProject.KickOffMeetingProjectedFinish != null ||
						CurrentProject.FirstSiteSelectedActualStart != null || CurrentProject.FirstSiteSelectedProjectedStart != null ||
						CurrentProject.FirstSiteInitiatedActualStart != null || CurrentProject.FirstSiteInitiatedProjectedStart != null ||
						CurrentProject.LastSiteInitiatedActualStart != null || CurrentProject.LastSiteInitiatedProjectedStart != null ||
						CurrentProject.FirstSubjectScreenedActualStart != null || CurrentProject.FirstSubjectScreenProjectedStart != null ||
						CurrentProject.LastSubjectScreenedActual != null || CurrentProject.LastSubjectScreenedProjected != null ||
						CurrentProject.FirstSubjectEnrolledActualStart != null || CurrentProject.FirstSubjectEnrolledProjectedStart != null ||
						CurrentProject.LastSubjectEnrolledActualDate != null || CurrentProject.LastSubjectEnrolledProjectedDate != null ||
						CurrentProject.FirstSubjectRandomizedActualStart != null || CurrentProject.FirstSubjectRandomizedProjectedStart != null ||
						CurrentProject.LastSubjectRandomAct != null || CurrentProject.LastSubjectRandomPrj != null ||
						CurrentProject.LastSubjectOutAct != null || CurrentProject.LastSubjectOutPrj != null ||
						CurrentProject.DatabaseLockAct != null || CurrentProject.DatabaseLockPrj != null ||
						CurrentProject.LastSiteClosedActualStart != null || CurrentProject.LastSiteClosedProjectedStart != null ||
						CurrentProject.FinalDeliverableContractedDate != null ||
						customMilestones.Length > 0)
				{
					isMilestonesExists = true;
				}

				showSchemaActions = (CurrentProject.IsDteProject && CurrentProject.VisitSchemaLevelId == (int)VisitSchemaLevel_E.Custom);
			}

			tabTitle = "Project Configuration";

			if (RmFunction.HasPermissionToFunction(RmFunction_E.Modify_Project_Country_And_Custom_Milestones, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null)))
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "MilestoneActions",
					Title = "Milestone Actions",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
						{
							new ButtonDefinition()
							{
								Id="AddEditMilestone",
								Title=isMilestonesExists?"Modify Milestone":"Add Milestone",
								CommandJavaScript = "milestoneNs.AddEditMilestone();",
								CommandEnableJavaScript = "projConfig.isAddEditeButtonEnabled();",
								Image=isMilestonesExists?MapImageLibrary.GetRMImage(15, 8, revision):MapImageLibrary.GetRMImage(15, 10, revision)

							},
							new ButtonDefinition()
							{
								Id="SaveMilestone",
								Title="Save Milestone",
								CommandJavaScript = "SaveMilestone();",
								CommandEnableJavaScript = "projConfig.isSaveButtonEnabled();",
								Image=MapImageLibrary.GetRMImage(15, 11, revision)
							},
							 new ButtonDefinition() {
								Id="DeleteMilestone",
								Title="Delete Milestone",
								CommandJavaScript = "DeleteMilestone();",
								CommandEnableJavaScript = "projConfig.isDeleteButtonEnabled();",
								Image=MapImageLibrary.GetRMImage(15, 9, revision)
							},
							 new ButtonDefinition() {
								Id="CancelMilestone",
								Title="Cancel",
								CommandJavaScript = "CancelMilestone();",
								CommandEnableJavaScript = "projConfig.isCancelButtonEnabled();",
								Image=ImageLibrary.GetStandardImage(6, 12, revision)
							}
						}
				});
			}

			var hasAccessToSchemaActions = RmFunction.HasPermissionToFunction(RmFunction_E.Manage_Custom_Schema, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
			if (showSchemaActions && hasAccessToSchemaActions)
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "SchemaActions",
					Title = "Schema Actions",
					Template = GroupTemplateLibrary.SimpleTemplate,

					Controls = new ControlDefinition[]
					 {
						 new ButtonDefinition()
						 {
							 Id = "ModifySchema",
							 Title = "Modify Schema",
							 CommandJavaScript = "dteSchemaNs.modifySchema();",
							 CommandEnableJavaScript = "dteSchemaNs.isModifyButtonEnabled();",
							 Image = MapImageLibrary.GetFormatMapImage(4, 15, revision)
						 },
						 new ButtonDefinition()
						 {
								Id = "SaveSchema",
								Title = "Save Schema",
								CommandJavaScript = "dteSchemaNs.saveSchema();",
								CommandEnableJavaScript = "dteSchemaNs.isSaveButtonEnabled();",
								Image = MapImageLibrary.GetFormatMapImage(5, 15, revision)
						 },
						 new ButtonDefinition()
						 {
							Id = "CancelSchema",
							Title = "Cancel",
							CommandJavaScript = "dteSchemaNs.cancelSchema();",
							CommandEnableJavaScript = "dteSchemaNs.isCancelButtonEnabled();",
							Image = MapImageLibrary.GetFormatMapImage(3, 15, revision),
						 }
					 }
				});

				PageGroups.Add(new GroupDefinition()
				{
					Id = "OtherSchemaActions",
					Title = "Other Schema Actions",
					Template = GroupTemplateLibrary.SimpleTemplate,

					Controls = new ControlDefinition[]
					 {
						 new ButtonDefinition()
						 {
							Id = "OsVsRvComparison",
							Title = "Onsite Vs Remote Visit Comparison",
							CommandJavaScript = "dteSchemaNs.showOsVsRvComparison();",
							CommandEnableJavaScript = "dteSchemaNs.dteSchemaLoadComplete",
							Image = MapImageLibrary.GetFormatMapImage(9, 6, revision),
						 },
						 new ButtonDefinition()
						 {
							Id = "SiteDistributionModeler",
							Title = "Site Distribution Modeler",
							CommandJavaScript = "dteSchemaNs.showSiteDistributionModeler();",
							CommandEnableJavaScript = "dteSchemaNs.dteSchemaLoadComplete",
							Image = MapImageLibrary.GetFormatMapImage(7, 2, revision),
						 }
					 }
				});
			}

			if (hasAccessToSchemaActions)
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "STAFToolActions",
					Title = "STAF Tool Actions",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
										{
											new ButtonDefinition()
											{
												Id="uploadStafExcel",
												Title="Upload",
												CommandEnableJavaScript = "dteSchemaNs.isUploadStafExcelButtonEnabled()",
												CommandJavaScript = "dteSchemaNs.showUploadStafExcelDialog()",
												Image=MapImageLibrary.GetFormatMapImage(11,15, revision)
											},
											new ButtonDefinition()
											{
												Id="downloadStafExcel",
												Title="Download",
												CommandEnableJavaScript = "dteSchemaNs.isDownloadStafExcelButtonEnabled()",
												CommandJavaScript = "dteSchemaNs.downloadStafExcel()",
												Image=MapImageLibrary.GetFormatMapImage(0,11, revision)
											}
										}
				});
			}

		}
	}
}
