﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile
{
	public partial class SSVAttr : AbstractProjectProfileLayoutPage
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.SSVAttributes; } }
		private bool AllowEdit { get; set; }

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			AllowEdit = RmFunction.HasPermissionToFunction(RmFunction_E.Modify_Monitoring_Attributes, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(CurrentProject, null));
			hdnAllowEdit.Value = AllowEdit.GetIntAsStringFromBool();


			if (CurrentProject != null)
			{
				ProjectName.Value = CurrentProject.Name;
				ProtocolNumber.Value = CurrentProject.ProtocolNumber;
				OrganizationUnitName.Value = CurrentProject.OrganizationalUnit.Name;
				hdnProjectId.Value = CurrentProject.Id.ToString();
				hdnIsRbmProjectManagedAsNonRbmInRm.Value = CurrentProject.IsRbmProjectManagedAsNonRbmInRm.GetIntAsStringFromBool();
				LoadedSuccessfully.Value = "1";
			}
			else
			{
				ProjectName.Value = String.Empty;
				ProtocolNumber.Value = String.Empty;
				hdnProjectId.Value = string.Empty;
				LoadedSuccessfully.Value = "0";
			}
		}

		protected override void GetPageGroupDefinitions(IList<GroupDefinition> PageGroups)
		{
			tabTitle = "SSV Attributes";
			if (AllowEdit)
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "GridActions",
					Title = "Actions",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
										{
											new ButtonDefinition()
                        {
                            Id="SaveGrid",
                            Title="Save",
                            CommandJavaScript = "ssvAttrNs.saveGrid();",
                            CommandEnableJavaScript = "ssvAttrNs.isSaveEnabled();",
                            Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
                        },
                        new ButtonDefinition()
                        {
                            Id="CancelGrid",
                            Title="Cancel",
                            CommandJavaScript = "ssvAttrNs.cancelGrid();",
                            CommandEnableJavaScript = "ssvAttrNs.isCancelEnabled();",
                            Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
                        },new ButtonDefinition() {
													Id="EditSingleRow",
													Title="Modify Country",
													CommandJavaScript = "ssvAttrNs.ModifySingleAttribute();",
													CommandEnableJavaScript = "ssvAttrNs.ModifySingleRowEnabled();",
													Image=MapImageLibrary.GetPSImage(3,11, revision)
											},
											new ButtonDefinition() {
													Id="EditMultipleRow",
													Title="Modify Countries",
													CommandJavaScript = "ssvAttrNs.ModifyMultipleAttributes();",
													CommandEnableJavaScript = "ssvAttrNs.ModifyMultipleRowsEnabled();",
													Image=MapImageLibrary.GetPSImage(3,11, revision)
											}
										}
				});
			}
		}
	}
}
