﻿using System;
using Quintiles.RM.Clinical.Domain.Services;
using System.Web.UI;


namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile
{
    public partial class ProjectDetailsDialog : Page
    {
        protected global::Quintiles.RM.Clinical.UI.UserControls.ProjectDetailsContainer ProjectDetailsContainer;

        public string revision { get { return CacheService.GetRevisionQueryString; } }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["ProjectId"] != null)
            {
                ProjectDetailsContainer.ProjectId = Convert.ToInt32(Request.QueryString["ProjectId"]);
            }
        }
    }
}
