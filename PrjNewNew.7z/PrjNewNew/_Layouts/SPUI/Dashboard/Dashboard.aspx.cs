﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.UI.Layouts.SPUI
{
	public partial class Dashboard : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.Dashboard; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			Response.Redirect("/_layouts/spui/Home.aspx");
		}
		public override Ui.Ribbon.TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "DashboardRibbon",
				Title = "Dashboard",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
