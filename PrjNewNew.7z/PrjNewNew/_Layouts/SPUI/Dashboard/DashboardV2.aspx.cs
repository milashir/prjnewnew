﻿using System;
using System.Text;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.SharePoint;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.UI.Layouts.SPUI
{
	public partial class DashboardV2 : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.Dashboard; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			IsUserPersmissionConfigured();
			base.Page_Load(sender, e);
			InitialProfile();
		}

		protected void InitialProfile()
		{
			hdnRmUserid.Value = RmUser.Id.ToString();
			userRoles.Value = GetUserRoles();
		}

		private void IsUserPersmissionConfigured()
		{
			if (!RmUser.HasRequiredPermissions())
			{
				Response.Redirect("../Admin/AssignPermissions.aspx?permissionNotConfigured=true"); // QRPM-12508
			}
		}

		private string GetUserRoles()
		{
			var roles = new StringBuilder();
			foreach (var userRole in UserRoles)
			{
				roles.AppendFormat(", {0}", userRole.Name);
			}

			return roles.Length > 2 ? roles.ToString().Substring(2) : string.Empty;
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Dashboard",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="EditPreferences",
                                Title="Dashboard Preferences",
                                CommandJavaScript = "dashboardNs.EditPreferences();",
																CommandEnableJavaScript =AuthorizationHelper.DisableEditUserPreference()?"false":"true",
                                Image=ImageLibrary.GetStandardImage(0,8, revision)
                            },
                            new ButtonDefinition() {
                                Id="ExortToExcel",
                                Title="Export To Excel",
                                CommandJavaScript = "dashboardNs.ExportToExcel();",
								CommandEnableJavaScript = "dashboardNs.ExportToExcelEnabled();",
                                Image=ImageLibrary.GetStandardImage(0,11, revision)
                            },
                            new ButtonDefinition() {
                                Id="DashboardCount",
                                Title="Show dashboard counts",
																Image=MapImageLibrary.GetPSImage(7,4, revision),
																CommandJavaScript = "dashboardNs.ShowCountForAllReports();",
                                
                            }
                    }
			});

			return new TabDefinition()
			{
				Id = "ResourceRequestRibbon",
				Title = "Dashboard",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
