﻿/// <reference path="../../_Layouts/SPUI/Scripts/common/RmHelper.js" />
function Sample()
{

}
Sample.prototype.helloworld = function () { return 'Hello World'; }
var testReq = {
	selectedCountryDetails: {
		
		CountryID: 100,
		CountryName : "Australia"
	}
}
Sample.prototype.ValidateCountry = function () { return testReq.selectedCountryDetails.CountryID }
Sample.prototype.ValidateClearDialogue = function () { return }

function ToDO()
{
	this.todo = [];
}
ToDO.prototype.addToDo = function (item) {
	this.todo.push(item);
}
ToDO.prototype.getItems = function ()
{
	return this.todo;
}
ToDO.prototype.delete = function (id)
{
	this.todo = this.todo.splice(id, 1); // removes 1 element from index - id
}
