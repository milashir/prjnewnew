﻿subRqNs = {
	gridSelector: "#list",
	gridJsonResponse: null
};


function bindGrid() {
	$(subRqNs.gridSelector).jqGrid({
		url: rm.ajax.requestSvcUrl + "GetSubmittedRequests",
		datatype: 'json',
		mtype: 'POST',
		ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
		ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
		jsonReader: rm.grid.getJqGridJsonReader(),
		//postData: gridPost,
		loadui: "block",
		loadonce: false,
		pager: '#listPager',
		autowidth: false,
		shrinkToFit: false,
		height: rm.ui.getMaxGridHeight() + 15,
		width: rm.ui.getMaxGridWidth() - 50,
		multiselect: true,
		colModel: [
			{ name: 'IconColumn', index: 'IconColumn', label: 'Request Status <br />Indicator', width: 130, search: true, sortable: false, hidden: false },
			rm.grid.standardColumns.getNotesColumn(),
			rm.grid.standardColumns.getFteColumn(true),
			rm.grid.standardColumns.getEditableDateColumn('StartDate', 'StartDate', 'Start Date', true, 'StopDate', subRqNs.gridSelector),
			rm.grid.standardColumns.getEditableDateColumn('StopDate', 'StopDate', 'Stop Date', false, subRqNs.gridSelector),
			{ name: 'Region', index: 'Region', label: 'Region', width: 150, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Country', index: 'Country', label: 'Country', width: 70, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'CountryRegion', index: 'CountryRegion', label: 'Country<br />Region', width: 70, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Program', index: 'Program', label: 'Program', width: 65, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Customer', index: 'Customer', label: 'Customer', width: 70, search: true, sortable: false, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project<br/>Code', width: 70, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'ProjectDteType', index: 'ProjectDteType', label: 'RBM Project', width: 80, classes: 'ui-ellipsis', search: true, stype: 'select', searchoptions: { value: rm.grid.filterOptions.dteType } },
			{ name: 'RequestBlinded', index: 'RequestBlinded', label: 'Request<br />Blinded', width: 100, classes: 'ui-ellipsis', search: true, stype: 'select', searchoptions: { value: rm.grid.filterOptions.blinded } },
			{ name: 'ProjectOrganizationalUnit', index: 'ProjectOrganizationalUnit', label: 'Project<br/>Organizational Unit', width: 124, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'SpmClass', index: 'SpmClass', label: 'SPM Class', width: 70, search: true, sortable: false },
			{ name: 'ResourceType', index: 'ResourceType', label: 'Resource<br />Request Type', width: 100, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Resource', index: 'Resource', label: 'Resource<br/>Name', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'ProposalResource', index: 'ProposalResource', label: 'Proposal<br/>Resource Name', width: 111, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'NeedByDate', index: 'NeedByDate', label: 'Need By<br/> Date', width: 80, searchoptions: { attr: { maxlength: 11 } } },
			{ name: 'CreatedBy', index: 'CreatedBy', label: 'Created By', sortable: true, search: true, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'SiteStatus', index: 'SiteStatus', label: 'Site Status', width: 110, searchoptions: { attr: { maxlength: 100 } } },
			{ name: 'SponsorSiteName', index: 'SponsorSiteName', label: 'Sponsor<br/>Site ID', width: 50, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'PrincipalInvestigator', index: 'PrincipalInvestigator', label: 'PI', width: 50, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Location', index: 'Location', label: 'Location', width: 70, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'VisitTypeName', index: 'VisitTypeName', label: 'Visit<br />Type', width: 60, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'SSVType', index: 'SSVType', label: 'SSV Type', width: 70 },
			{ name: 'IMDate', index: 'IMDate', label: 'IM Date', width: 120, formatter: $.qGrid.showDateWithConnectIcon, align: 'right', searchoptions: { attr: { maxlength: 11 } } },
			{ name: 'CRADate', index: 'CRADate', label: 'CRA Training<br/> Date', width: 120, formatter: $.qGrid.showDateWithConnectIcon, align: 'right', searchoptions: { attr: { maxlength: 11 } } },
			{ name: 'RequestBudgeted', index: 'RequestBudgeted', label: 'Request<br />Budgeted?', width: 80, classes: 'ui-ellipsis', stype: 'select', searchoptions: { value: rm.grid.filterOptions.yesNo } },
			{ name: 'RequestIdForFilter', index: 'RequestIdForFilter', label: 'RequestId', width: 70, searchoptions: { attr: { maxlength: 10 } } },
			{ name: 'DateSubmitted', index: 'DateSubmitted', label: 'Submitted<br />Date', width: 80, searchoptions: { attr: { maxlength: 11 } } },
			{ name: 'ProjectId', index: 'ProjectId', label: 'ProjectId', hidden: true },
			{ name: 'SiteId', index: 'SiteId', label: 'SiteId', hidden: true },
			{ name: 'MonthlyFTESSVAttrCountryLevel', index: 'MonthlyFTESSVAttrCountryLevel', label: 'MonthlyFTESSVAttrCountryLevel', search: false, sort: false, editable: false, search: false, hidden: true },

			rm.grid.standardColumns.getFteMonthColumn('CurrentMonthFTE', (new Date()).getMonth()),
			rm.grid.standardColumns.getFteMonthColumn('SecondMonthFTE', (new Date()).getMonth() + 1),
			rm.grid.standardColumns.getFteMonthColumn('ThirdMonthFTE', (new Date()).getMonth() + 2),
			rm.grid.standardColumns.getFteMonthColumn('FourthMonthFTE', (new Date()).getMonth() + 3),
			rm.grid.standardColumns.getFteMonthColumn('FifthMonthFTE', (new Date()).getMonth() + 4),
			rm.grid.standardColumns.getFteMonthColumn('SixthMonthFTE', (new Date()).getMonth() + 5)
		],
		page: 1,
		sortname: "Country",
		sortorder: "desc",
		multipleSearch: true,
		serializeRowData: function (postData) {
			return JSON.stringify(postData);
		},
		serializeGridData: function (postData) {
			var data = { RmPageLink: 7 };
			return rm.grid.serializeGridData(postData, data);
		},
		beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("list"); },
		loadComplete: function (data) {
			subRqNs.gridJsonResponse = data;
			rm.grid.rowData.attachAllRowsData(subRqNs.gridSelector, data);
			setTimeout(runTestCases, 100);
		},
	});
}

$(document).ready(function () {
	bindGrid();
});


function runTestCases() {
	describe("function for Equality check", function () {
		var sample;
		beforeEach(function () {
			sample = new Sample();

		});
		it("should return Hello world", function () {
			expect(sample.helloworld()).toEqual('Hello World');
		});
		it("should return Organization ID", function () {
			expect(sample.ValidateCountry()).toEqual(100);
		});
		//it("should give the selected resource type details", function () {
		//	expect(sample.getResurceListForTypeAhead(12).toEqual(13));
		//});
	});

	describe("testing array operations", function () {
		var todo, item1, item2;
		beforeEach(function () {
			todo = new ToDO();
			item1 = {
				id: 1,
				title: " get item1"
			}
			item2 = {
				id: 2,
				title: "get item2"
			}
		})
		it('should add an item', function () {
			todo.addToDo(item1);
			expect(todo.getItems().length).toBe(1)
		})
		it('should delete an item', function () {
			todo.addToDo(item1);
			todo.addToDo(item2);
			todo.delete(1); //item index to delete
			//alert(todo.getItems()[0].id);
			expect(todo.getItems()[todo.getItems().length - 1].id).toBe(2);
		})
	});


	beforeEach(function (done) {
		setTimeout(function () {

			done();

		}, 5000);
	});
	describe("Test Rm helper function", function () {
		it("test range validation: within range", function () {
			var elementToTest = '<input type="text" id="txtWeeklyHours_5"  from="0" to="9999.99" formating="4, 2"  value="18" >';
			var isValid = rm.validation.range.validate(elementToTest);
			expect(isValid).toEqual(true);
		});

		it("test range validation:  Out of range", function () {
			var elementToTest = '<input type="text" id="txtWeeklyHours_5"  from="0" to="9999.99" formating="4, 2"  value="99999" >';
			var isValid = rm.validation.range.validate(elementToTest);
			expect(isValid).toEqual(false);
		});

		it("test range validation:  incorrect format", function () {
			var elementToTest = '<input type="text" id="txtWeeklyHours_5"  from="0" to="9999.99" formating="4, 2"  value="999.999" >';
			var isValid = rm.validation.range.validate(elementToTest);
			expect(isValid).toEqual(false);
		});


		it("test grid functions", function () {
			expect(subRqNs.gridJsonResponse.Records.length).toEqual(rm.grid.rowData.getJsonData(subRqNs.gridSelector).Records.length);


			//$.qGrid.getGridRowDataById($.qGrid.getGridUserData(subRqNs.gridSelector).Records, id);
			//return rm.grid.allowRowSelection(event);

			//var areAllEditableColumnsPresent = rm.grid.areAllEditableColumnsPresent(subRqNs.getFullColumnModelList(), subRqNs.columnModelUsedByGrid, true);
			//rm.grid.editRow(subRqNs.gridSelector, id);
			//rm.grid.attachCustomSaveHandler(subRqNs.gridSelector, id, subRqNs.saveSingleRequest);
		});
	});
}