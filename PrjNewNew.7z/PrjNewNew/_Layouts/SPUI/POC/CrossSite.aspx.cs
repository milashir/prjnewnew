﻿using System;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class CrossSite : AbstractRmRibbonPageLayout
	{
		protected void Page_Load(object sender, EventArgs e) { }
		public override TabDefinition GetTabDefinition() { return null; }
	}
}
