﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Notification
{
	public partial class SSVRequest : AbstractRmRibbonPageLayout
	{
		private RmPageLink_E? _rmPageLink = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					var strRmPageLink = Request["rmPageLink"];
					_rmPageLink = string.IsNullOrEmpty(strRmPageLink) ? RmPageLink_E.SSVRequests : (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), strRmPageLink);
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="SaveGrid",
                                Title="Save",
                                CommandJavaScript = "ssvrNs.SaveGrid();",
                                CommandEnableJavaScript = "ssvrNs.isSaveEnabled();",
                                Image=ImageLibrary.GetStandardImage(8,13, revision)
                            },
                             new ButtonDefinition() {
                                Id="SubmitGrid",
                                Title="Submit",
                                CommandJavaScript = "ssvrNs.SubmitGrid();",
                                CommandEnableJavaScript = "ssvrNs.isSubmitEnabled();",
                                Image=ImageLibrary.GetStandardImage(0,10, revision)
                            },
                            new ButtonDefinition() {
                                Id="CancelGrid",
                                Title="Cancel",
                                CommandJavaScript = "ssvrNs.CancelGrid();",
																CommandEnableJavaScript = "ssvrNs.isCancelEnabled();",
                                Image=ImageLibrary.GetStandardImage(6,12, revision)
                            },
                            new ButtonDefinition() {
									Id="EditSingleRow",
									Title="Modify Request",
									CommandJavaScript = "ssvrNs.ModifySingleRequest();",
									CommandEnableJavaScript = "ssvrNs.ModifySingleRowEnabled();",
									Image=MapImageLibrary.GetPSImage(3,11, revision)
							},
							new ButtonDefinition() {
							        Id="EditMultipleRow",
							        Title="Modify Requests",
							        CommandJavaScript = "ssvrNs.ModifyMultipleRequests();",
							        CommandEnableJavaScript = "ssvrNs.ModifyMultipleRowsEnabled();",
							        Image=MapImageLibrary.GetPSImage(3,11, revision)
							},
                            new ButtonDefinition() {
                                Id="TerminateRow",
                                Title="Delete Request",
                                CommandJavaScript = "ssvrNs.DeleteSubmittedRequests();",
                                CommandEnableJavaScript = "ssvrNs.DeleteSelectedRowEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(6,0, revision)
                            }
                        }
			});
			return new TabDefinition()
			{
				Id = "SSVRequestRibbon",
				Title = "Unsubmitted SSV Site Level Requests",
				Groups = PageGroups.ToArray()
			};
		}

	}
}
