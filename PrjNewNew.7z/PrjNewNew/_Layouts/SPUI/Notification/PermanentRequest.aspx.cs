﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Notification
{
	public partial class PermanentRequest : AbstractRmRibbonPageLayout
	{
		private RmPageLink_E? _rmPageLink = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					var strRmPageLink = Request["rmPageLink"];
					_rmPageLink = string.IsNullOrEmpty(strRmPageLink) ? RmPageLink_E.MonitoringRequests : (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), strRmPageLink);
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="SaveGrid",
                                Title="Save",
                                CommandJavaScript = "monrNs.SaveGrid();",
								CommandEnableJavaScript ="monrNs.isSaveEnabled();",
                                Image=ImageLibrary.GetStandardImage(8,13, revision)
                            },
                             new ButtonDefinition() {
                                Id="SubmitGrid",
                                Title="Submit",
                                CommandJavaScript = "monrNs.SubmitGrid();",
								CommandEnableJavaScript="monrNs.isSubmitEnabled();",
                                Image=ImageLibrary.GetStandardImage(0,10, revision)
                            },
                            new ButtonDefinition() {
                                Id="CancelGrid",
                                Title="Cancel",
                                CommandJavaScript = "monrNs.CancelGrid();",
								CommandEnableJavaScript ="monrNs.isCancelEnabled();",
                                Image=ImageLibrary.GetStandardImage(6,12, revision)
                            },
														new ButtonDefinition() {
																Id="EditSingleRow",
																Title="Modify Request",
																CommandJavaScript = "monrNs.ModifySingleRequest();",
																CommandEnableJavaScript = "monrNs.ModifySingleRowEnabled();",
																Image=MapImageLibrary.GetPSImage(3,11, revision)
														},
														new ButtonDefinition() {
																Id="EditMultipleRow",
																Title="Modify Requests",
																CommandJavaScript = "monrNs.ModifyMultipleRequests();",
																CommandEnableJavaScript = "monrNs.ModifyMultipleRowsEnabled();",
																Image=MapImageLibrary.GetPSImage(3,11, revision)
														},
                            new ButtonDefinition() {
                                Id="TerminateRow",
                                Title="Delete Request",
                                CommandJavaScript = "monrNs.DeleteSubmittedRequests();",
                                CommandEnableJavaScript = "monrNs.DeleteSelectedRowEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(6,0, revision)
                            }

                        }
			});

			return new TabDefinition()
			{
				Id = "MonitoringRequestRibbon",
				Title = "Unsubmitted Monitoring Requests",
				Groups = PageGroups.ToArray()
			};
		}
	}

}
