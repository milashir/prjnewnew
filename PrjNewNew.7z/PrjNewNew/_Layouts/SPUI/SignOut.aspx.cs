﻿using System;
using Quintiles.RM.Clinical.Domain.Utilities;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
    public partial class SignOut : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
					WebUtilities.AddCloseConnectionHeaderToResponse();
					Session.Clear();
					Session.Abandon();
        }
    }
}