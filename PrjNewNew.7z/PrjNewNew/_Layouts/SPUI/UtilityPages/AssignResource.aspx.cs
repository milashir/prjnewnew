﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;
namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.UtilityPages
{
	public partial class AssignResource : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			string nullableRequestIds = Request.QueryString["requestIds"];

			if (string.IsNullOrEmpty(nullableRequestIds))
			{
				throw new Exception("Parameter requestIds is required.");
			}

			hdnSelectedRequestIds.Value = nullableRequestIds;
			IList<models.Resource> lineManagers = models.Resource.FindAllLineManagers();
			ddlLineManager.Items.Add(new ListItem("--Select--", "-1"));
			foreach (models.Resource lineManager in lineManagers)
			{
				ddlLineManager.Items.Add(new ListItem { Text = lineManager.Name, Value = lineManager.Qid, Selected = (lineManager.Qid == ExtensionMethods.GetCurrentUserQid()) });
			}
		}
	}
}
