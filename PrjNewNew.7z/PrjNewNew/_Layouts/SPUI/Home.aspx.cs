﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.UI.Layouts.SPUI
{
    public partial class Home : AbstractProjectProfileLayoutPage
    {
        protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.Home; } }

        protected override void Page_Init(object sender, EventArgs e)
        {
            ShowAnnouncementsInDialog = false;
            base.Page_Init(sender, e);
        }

        protected override void Page_Load(object sender, EventArgs e)
        {
            base.Page_Load(sender, e);
        }

        public override TabDefinition GetTabDefinition()
        {

            return new TabDefinition()
            {
                Id = "ResourceRequestRibbon",
                Title = "Home",
                Groups = PageGroups.ToArray()
            };

        }
    }
}
