﻿using System;
using System.Collections.Generic;
using System.Linq;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile
{
	public partial class DteSchemaSimulator : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.DteSchemaSimulator; } }

		protected override void Page_Load(object sender, System.EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
				{
					Id = "Actions",
					Title = "Actions",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
          {
              new ButtonDefinition()
              {
                  Id="LoadDsmGtp",
                  Title="Load RBM Site Monitoring Global Tier Proportions",
                  CommandJavaScript = "dteSimNs.loadSiteMonGlobalTierProportions();",
                  CommandEnableJavaScript = "dteSimNs.isLoadSiteMonGlobalTierProportionsActive();",
                  Image=MapImageLibrary.GetRMImage(5, 1, revision)
              },
							new ButtonDefinition()
              {
                  Id="LoadDpmGtp",
                  Title="Load RBM Pharmacy Monitoring Global Tier Proportions",
                  CommandJavaScript = "dteSimNs.loadPharmacyGlobalTierProportions();",
                  CommandEnableJavaScript = "dteSimNs.isLoadPharmacyGlobalTierProportionsActive()",
                  Image=MapImageLibrary.GetRMImage(5, 1, revision)
              }
          }
				});

			return new TabDefinition()
			{
				Id = "RbnDteSchemaSimulator",
				Title = "RBM Schema Simulator",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
