﻿using System;
using System.Web;
using System.Web.UI;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
    public partial class AccessDenied : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
