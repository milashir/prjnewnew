﻿using System;
using Quintiles.RM.Clinical.Domain.Services;
using System.Web.UI;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class SiteListDetailsDialog : Page
	{
		public string revision { get { return CacheService.GetRevisionQueryString; } }
		protected void Page_Load(object sender, EventArgs e)
		{
			hdnProjectId.Value = Request.QueryString["projectId"];
			hdnCountryId.Value = Request.QueryString["countryId"];
		}
	}
}
