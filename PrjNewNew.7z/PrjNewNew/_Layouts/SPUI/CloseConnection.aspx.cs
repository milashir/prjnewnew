﻿using System;
using System.Web;
using Quintiles.RM.Clinical.Domain.Utilities;

namespace Quintiles.RM.Clinical.SharePoint._Layouts.SPUI
{
	public partial class CloseConnection : System.Web.UI.Page
	{
		private static string SessionKey_PreviousUser = "PreviousUser";
		private static string SessionKey_AuthenticationAttempts = "AuthenticationAttempts";
		private static string QueryString_CycleCount = "cycleCount";
		private static string QueryString_ChangeUser = "changeUser";

		public string CurrentUser { get { return HttpContext.Current.User.Identity.Name; } }

		private string _previousUser = string.Empty;
		public string PreviousUser
		{
			get
			{
				_previousUser = Convert.ToString(Session[SessionKey_PreviousUser]);
				return _previousUser;
			}
			set
			{
				_previousUser = value;
				Session[SessionKey_PreviousUser] = _previousUser;
			}
		}

		private int _authenticationAttempts = 0;
		public int AuthenticationAttempts
		{
			get
			{
				if (!string.IsNullOrEmpty(Convert.ToString(Session[SessionKey_AuthenticationAttempts])))
				{
					int.TryParse(Session[SessionKey_AuthenticationAttempts].ToString(), out _authenticationAttempts);
				}
				return _authenticationAttempts;
			}
			set
			{
				_authenticationAttempts = value;
				Session[SessionKey_AuthenticationAttempts] = value;
			}
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (Request.QueryString[QueryString_CycleCount] != null)
			{
				WebUtilities.AddCloseConnectionHeaderToResponse();
			}
			else if (Request.QueryString[QueryString_ChangeUser] == "true")
			{
				WebUtilities.DisablePageCaching();

				AuthenticationAttempts++;
				if (AuthenticationAttempts == 1 || string.Empty.Equals(PreviousUser))
				{
					PreviousUser = HttpContext.Current.User.Identity.Name;
					WebUtilities.Send401Header();
				}
				else
				{
					if (AuthenticationAttempts <= 3 && CurrentUser.Equals(PreviousUser))
					{
						WebUtilities.Send401Header();
					}
					else
					{
						Session.Remove(SessionKey_PreviousUser);
						Session.Remove(SessionKey_AuthenticationAttempts);
						PreviousUser = string.Empty;

						var redirectToUrl = Convert.ToString(Request.QueryString["source"]);
						redirectToUrl = string.IsNullOrEmpty(redirectToUrl) ? "/" : redirectToUrl;
						Response.Redirect(redirectToUrl);
					}
				}
			}
		}
	}
}