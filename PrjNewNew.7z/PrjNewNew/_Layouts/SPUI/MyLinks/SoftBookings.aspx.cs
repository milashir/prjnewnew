﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.MyLinks
{
	public partial class SoftBookings : AbstractRmRibbonPageLayout
	{
		private RmPageLink_E? _rmPageLink = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					var strRmPageLink = Request["rmPageLink"];
					_rmPageLink = string.IsNullOrEmpty(strRmPageLink) ? RmPageLink_E.SoftBookings : (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), strRmPageLink);
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}

		//protected override UserRole_E RequiredRoles { get { return UserRole_E.ResourceManager; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(
					new GroupDefinition
					{
						Id = "SoftBookingActions",
						Title = "Resourcing Actions",
						Template = GroupTemplateLibrary.SimpleTemplate,
						Controls = new ControlDefinition[]
                    {
                        new ButtonDefinition() {
                            Id = "RemoveSoftBook",
                            Title = "Release Resource",
                            CommandJavaScript = "$.rm.softBook.RemoveSoftBook();",
                            CommandEnableJavaScript = "$.rm.softBook.IsRemoveSoftBookEnabled();",
                            Image = MapImageLibrary.GetFormatMapImage(4,14,revision)
                        },

                        new ButtonDefinition() {
                            Id = "HardBook",
                            Title = "Assign Resource",
                            CommandJavaScript = "$.rm.softBook.HardBook();",
                            CommandEnableJavaScript = "$.rm.softBook.IsHardBookEnabled();",
                            Image = MapImageLibrary.GetFormatMapImage(2,13,revision)
                        }
                    }
					});
			return new TabDefinition
			{
				Id = "SoftBookingList",
				Title = "Soft Bookings",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
