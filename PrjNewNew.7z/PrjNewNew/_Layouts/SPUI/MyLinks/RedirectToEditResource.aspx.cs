﻿using System;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.MyLinks
{
	public partial class RedirectToEditResource : AbstractRmRibbonPageLayout
	{
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			var guid = CacheService.GetNewGuid();
			Session[guid] = Request.Form["selectedResourceIds"];
			Response.Redirect(string.Format("EditResource.aspx?Key={0}", guid));
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "Id",
				Title = "Title",
				Groups = PageGroups.ToArray()
			};
		}
	}
}