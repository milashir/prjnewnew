﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile.Settings
{

	public partial class Delegation : AbstractRmRibbonPageLayout
	{
		private enum RibbonButtonFlg { Create = 1, Modify = 2, Admin = 3 };
		//protected override UserRole_E RequiredRoles { get { return UserRole_E.LineManager; } }
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.Delegation; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			//write the flag that decide whether to show 
			ClientScript.RegisterClientScriptBlock(this.GetType(), "codevalue", "<script>var searchCodeValues = {showGraphErrors: " + Quintiles.RM.Clinical.Domain.Models.ConfigValue.ShowGraphErrors.ToString().ToLower() + "};</script>");

			hdnCurrentLineManagerResourceId.Value = (RmResource != null) ? RmResource.Id.ToString() : "";
			txtCurrentLineManager.Value = (RmResource != null) ? string.Format("{0} - ({1})", RmResource.Name, RmResource.Qid) : "";
			hdnMyResourceId.Value = hdnCurrentLineManagerResourceId.Value;
			hdnMyResourceName.Value = txtCurrentLineManager.Value;
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition() {
				Id = "RBCreateDelegation",
				Title = "Create Delegation Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                                new ButtonDefinition() {
                                    Id="Delegate",
                                    Title="Create Delegation",
                                    CommandJavaScript = "DelegationPage.CreateDelegation();",
                                    CommandEnableJavaScript = "DelegationPage.CreateDelegationEnabled();",  
                                    Image=MapImageLibrary.GetFormatMapImage(15,5, revision)
                                },
																new ButtonDefinition() {
																		Id="Update",
																		Title="Save",
																		CommandJavaScript = "DelegationPage.CreateNewDelegation();",
																		CommandEnableJavaScript = "DelegationPage.CreateNewDelegationEnabled();",
																		Image=MapImageLibrary.GetFormatMapImage(15,15, revision)
                                
																},
																new ButtonDefinition() {
																		Id="CancelCreateDelegation",
																		Title="Cancel",
																		CommandJavaScript = "DelegationPage.CancelCreateNewDelegation();",
																		CommandEnableJavaScript = "DelegationPage.CancelCreateNewDelegationEnabled();",
																		Image=ImageLibrary.GetStandardImage(6,12, revision)
																},
																new ButtonDefinition() {
																		Id="Close",
																		Title="Close",
																		CommandJavaScript = "DelegationPage.CloseCreateDelegation();",
																		CommandEnableJavaScript = "DelegationPage.CloseCreateDelegationEnabled();",
																		Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
																}

                    }
			});

			PageGroups.Add(new GroupDefinition() {
				Id = "RBUpdateDelegation",
				Title = "Update Delegate Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
															new ButtonDefinition() {
																	Id="UpdateDelegation",
																	Title="Update Delegation",
																	CommandJavaScript = "DelegationPage.UpdateDelegation();",
																	CommandEnableJavaScript = "DelegationPage.UpdateDelegationEnabled();",  
																	Image=ImageLibrary.GetStandardImage(0,1, revision)
                                
															},
															new ButtonDefinition() {
																	Id="CancelUpdateDelegation",
																	Title="Cancel Update",
																	CommandJavaScript = "DelegationPage.CancelUpdateDelegation();",
																	CommandEnableJavaScript = "DelegationPage.CancelUpdateDelegationEnabled();",
																	Image=ImageLibrary.GetStandardImage(6,12, revision)
															},
															new ButtonDefinition() {
																	Id="Remove",
																	Title="Remove",
																	CommandJavaScript = "DelegationPage.RemoveDelegation();",
																	CommandEnableJavaScript = "DelegationPage.RemoveDelegationEnabled();",  
																	Image=MapImageLibrary.GetFormatMapImage(15,14, revision)
                                
															}

                    }
			});

			return new TabDefinition() {
				Id = "ResourceRequestRibbon",
				Title = "Delegation",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
