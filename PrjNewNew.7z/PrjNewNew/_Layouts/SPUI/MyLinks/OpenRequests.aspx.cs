﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.MyLinks
{
	public partial class OpenRequests : AbstractRmRibbonPageLayout
	{
		//protected override UserRole_E RequiredRoles { get { return UserRole_E.ResourceManager; } }
		private RmPageLink_E? _rmPageLink = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					var strRmPageLink = Request["rmPageLink"];
					_rmPageLink = string.IsNullOrEmpty(strRmPageLink) ? RmPageLink_E.OpenResourceRequests : (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), strRmPageLink);
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "OpenRequestActions",
				Title = "Actions for Resourcing Worklist",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="AddToQueue",
                                Title="Add to Resourcing Worklist",
                                CommandJavaScript = "orNs.AddToQueue();",
                                CommandEnableJavaScript = "orNs.AddToQueueEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(0,10,revision)
                            },
                            new ButtonDefinition() {
                                Id="RemoveFromQueue",
                                Title="Remove from Resourcing Worklist",
                                CommandJavaScript = "orNs.RemoveFromQueue();",
                                CommandEnableJavaScript = "orNs.RemoveFromQueueEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(4,4,revision)
                            }
											 }
			});

			PageGroups.Add(new GroupDefinition()
			{
				Id = "ResourcingAction",
				Title = "Resourcing Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="ResourceSearch",
                                Title="Resourcing Worklist",
                                CommandJavaScript = "orNs.GoToResourceSearch();",
                                CommandEnableJavaScript = "orNs.GoToResourceSearchEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(6,8,revision)
                            }
                }
			});

			PageGroups.Add(new GroupDefinition()
			{
				Id = "Project",
				Title = "Project",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="ViewProjectSummary",
                                Title="View Project Summary",
																 CommandJavaScript = "orNs.ViewProjectSummaryOnClick();",
                                CommandEnableJavaScript = "orNs.ViewProjectSummaryButtonEnabled();",
                                Image=MapImageLibrary.GetFormatMapImage(1,11,revision)
                            }
                }
			});

			return new TabDefinition()
			{
				Id = "OpenRequests",
				Title = "Open Resource Requests",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
