﻿using System;
using System.Collections.Generic;
using System.Linq;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile.Settings
{
	public partial class MyStaff : AbstractRmRibbonPageLayout
	{
		private RmPageLink_E? _rmPageLink = null;
		public string RmPageLinkId = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					//var strRmPageLink = Request["rmPageLink"];
					RmPageLinkId = Request["rmPageLink"];
					_rmPageLink = string.IsNullOrEmpty(RmPageLinkId) ? RmPageLink_E.MyStaff : (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), RmPageLinkId);
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}
		protected bool HasOnlyLineManagerRestrictedAccessRole
		{
			get { return !RmUser.IsAdmin && !RmUser.IsSupport && !RmUser.IsResourcingCenterAdmin && !RmUser.IsLineManager && RmUser.IsLineManagerRestrictedAccess; }
		}
		protected bool AllowHardBooking { get { return RmUser.IsAdmin || RmUser.IsSupport || RmUser.IsResourceManager; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			hdnAllowHardBooking.Value = AllowHardBooking.GetIntAsStringFromBool();

			var isUserHasLMRestrictedRole = "false";
			//Since Line Manager Role and Admin Roles only can have the access to Modify Button. This value is checked and sent to the Client side. 
			if (HasOnlyLineManagerRestrictedAccessRole)
				isUserHasLMRestrictedRole = "true";
			ClientScript.RegisterClientScriptBlock(this.GetType(), "codevalue", "<script>var searchCodeValues = {isUserHasLMRestrictedRole:" + isUserHasLMRestrictedRole + ", showGraphErrors: " + Quintiles.RM.Clinical.Domain.Models.ConfigValue.ShowGraphErrors.ToString().ToLower() + "};</script>");
		}

		public override TabDefinition GetTabDefinition()
		{
			AddActionsForAllRequests();
			AddActionsForSpecialAssignments();
			AddActionsForSoftBookedRequests();
			AddActionsForAssignedRequests();
			AddActionsForResource();
			AddActionsForCompetencyband();

			return new TabDefinition()
			{
				Id = "ResourceRequestRibbon",
				Title = "My Staff",
				Groups = PageGroups.ToArray()
			};
		}

		private void AddActionsForAllRequests()
		{
			if (UserCache.Usr.IsResourcingCenterAdmin || UserCache.Usr.IsLineManager)
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "BookingActions",
					Title = "Action for Request",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
					{
						new ButtonDefinition() {
							Id="Assignments",
							Title="Modify Request",
							CommandJavaScript = "myStaffNs.editSelectedRequest();",
							CommandEnableJavaScript = "myStaffNs.editSelectedRequestEnabled();",
							Image=MapImageLibrary.GetPSImage(3,11, revision)
						}
					}
				});
			}
			else if (HasOnlyLineManagerRestrictedAccessRole)
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "BookingActionsforLMR",
					Title = "Action for Request",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
					{
						new ButtonDefinition() {
							Id="AssignmentsforLMR",
							Title="View Request",
							CommandJavaScript = "myStaffNs.viewSelectedRequest();",
							CommandEnableJavaScript = "myStaffNs.viewSelectedRequestEnabled();",
							Image=MapImageLibrary.GetPSImage(3,11, revision)
						}
					}
				});
			}
		}

		private void AddActionsForSpecialAssignments()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions for Special Assignment",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
				{
					new ButtonDefinition() {
						Id="SpecialAssigment",
						Title="Create Special Assignments",
						CommandJavaScript = "myStaffNs.showSpecialAssignmentDialog(true);",
						CommandEnableJavaScript = "myStaffNs.isCreateSpecialAssignmentButtonEnabled();",
						Image=MapImageLibrary.GetFormatMapImage(13,12, revision)
					},
					new ButtonDefinition() {
						Id="Modify",
						Title="Modify Special Assignment",
						CommandJavaScript = "myStaffNs.showSpecialAssignmentDialog(false);",
						CommandEnableJavaScript = "myStaffNs.isModifySpecialAssignmentButtonEnabled();",
						Image=MapImageLibrary.GetPSImage(3,11, revision)
					},
					new ButtonDefinition() {
						Id="Delete",
						Title="Delete",
						CommandJavaScript = "myStaffNs.deleteSpecialAssignment();",
						CommandEnableJavaScript = "myStaffNs.isDeleteSpecialAssignmentButtonEnabled();",
						Image=ImageLibrary.GetStandardImage(11,8, revision)
					},
					new ButtonDefinition() {
						Id="TerminateRow",
						Title="Terminate",
						CommandJavaScript = "myStaffNs.terminateSpecialAssignment();",
						CommandEnableJavaScript = "myStaffNs.isTerminateSpecialAssignmentButtonEnabled();",
						Image=MapImageLibrary.GetFormatMapImage(12,13, revision)
					}
				}
			});
		}

		private void AddActionsForSoftBookedRequests()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridBooking",
				Title = "Soft Bookings",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
				{
					new ButtonDefinition() {
						Id="AcceptSoftBooking",
						Title="Accept Soft Booking",
						CommandJavaScript = "AcceptSoftBooking();",
						CommandEnableJavaScript = "AcceptSoftBookingButtonEnabled();",
						Image=MapImageLibrary.GetFormatMapImage(5,2, revision)

					},
					new ButtonDefinition() {
						Id="RejectSoftBooking",
						Title="Reject Soft Booking",
						CommandJavaScript = "RejectSoftBooking();",
						CommandEnableJavaScript = "RejectSoftBookingButtonEnabled();",
						Image=MapImageLibrary.GetFormatMapImage(7,13, revision)
					}
				}
			});
		}

		private void AddActionsForAssignedRequests()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "BackfillAction",
				Title = "Assigned Resource Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
				{
					new ButtonDefinition() {
						Id="PermanentBackfill",
						Title="Create Backfill Request",
						CommandJavaScript = "myStaffNs.createBackfill();",
						CommandEnableJavaScript = "myStaffNs.isCreateBackfillEnabled();",
						Image=MapImageLibrary.GetFormatMapImage(2,5, revision)
					}
				}
			});
		}

		private void AddActionsForResource()
		{
			var loggedInUser = models.Resource.GeResourceByQId(ExtensionMethods.GetCurrentUserQid());
			var controls = new List<ControlDefinition>
			{
				new ButtonDefinition() {
					Id="EditResource",
					Title="Modify Resource",
					CommandJavaScript = "myStaffNs.editResource();",
					CommandEnableJavaScript = "myStaffNs.isEditResourceEnabled();",
					Image=MapImageLibrary.GetPSImage(3,11, revision)
				},
				new ButtonDefinition() {
					Id="EditResources",
					Title="Modify Resources",
					CommandJavaScript = "myStaffNs.editResource();",
					CommandEnableJavaScript = "myStaffNs.isEditResourceEnabled();",
					Image=MapImageLibrary.GetPSImage(3,11, revision)
				}
			};

			if (loggedInUser != null)
			{
				controls.Add(new ButtonDefinition()
				{
					Id = "EditMyConfiguration",
					Title = "Modify My Own Attributes",
					CommandJavaScript = string.Format("myStaffNs.editMyOwnConfiguration({0});", loggedInUser.Id),
					CommandEnableJavaScript = "true;",
					Image = MapImageLibrary.GetPSImage(3, 11, revision)
				});
			}

			PageGroups.Add(new GroupDefinition()
			{
				Id = "EditResource",
				Title = "Action for Resource",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = controls.ToArray()
			});
		}

		private void AddActionsForCompetencyband()
		{
			//This Dictionary is passed to the attachment Handler method so that the key value pairs are sent as query string.
			var argumentsForAttachmentHandler = new Dictionary<string, string> { { "qid", UserCache.Usr.QId } };

			PageGroups.Add(new GroupDefinition()
			{
				Id = "BookingActions",
				Title = "Reports",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
				{
					new ButtonDefinition() {
						Id = "CompetencyBandReports",
						Title = "Competency Band Report",
						CommandJavaScript =RmPageLinkHelper.GenerateReportUrl(((int)QueryToRun.CompetencyBand),argumentsForAttachmentHandler),
						CommandEnableJavaScript = "true;",
						Image = MapImageLibrary.GetFormatMapImage(0, 11, revision)
					}
				}
			});
		}
	}
}
