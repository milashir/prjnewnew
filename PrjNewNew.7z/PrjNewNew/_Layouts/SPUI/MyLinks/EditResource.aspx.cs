﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Profile.Settings
{

	public partial class EditResource : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.MyStaff; } }
		public string ResourceIdString { get; set; }
		public string PageTitle { get; private set; }
		public bool HasPermissionToSeeCompetencyBand { get; private set; }

		public bool IsInMultieditMode { get; set; }
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetValues(GetResourceIds());
		}

		private void SetValues(List<int> resourceIds)
		{
			isMultiEditMode.Value = (resourceIds.Count > 1).GetIntAsStringFromBool();
			IsInMultieditMode = resourceIds.Count > 1;
			resourceIdList.Value = ResourceIdString;
			hdnAllJapanResources.Value = models.Resource.AreAllJapanResourcesSelected(resourceIds).GetIntAsStringFromBool();
			ltrSingleResource.Visible = (resourceIds.Count == 1);
			ltrMultipleResources.Visible = !ltrSingleResource.Visible;
			ltrMultiEditMessage.Visible = !ltrSingleResource.Visible;
			PageTitle = string.Format("Modify Resource{0}", (resourceIds.Count > 1) ? "s" : string.Empty);

			string managerQids;
			ltrResourceNames.Text = models.Resource.GetCommaSeparatedResourceNamesByResourceIdList(resourceIds, out managerQids);
			ltrManagerQids.Text = managerQids;

			HasPermissionToSeeCompetencyBand = RmFunction.HasPermissionToFunction(RmFunction_E.View_Competency_Band, RmUser, ExtensionMethods.GetCurrentUserQid(), new CustomPermissionArg(null, resourceIds));
			hdnHasPermissionToSeeCompetencyBand.Value = HasPermissionToSeeCompetencyBand.GetIntAsStringFromBool();

			rptTmfplatform.DataSource = CacheService.TmfPlatform.Values.Where(p => p.ApplicableAsExperience).OrderBy(p => p.Name);
			rptTmfplatform.DataBind();
		}

		private List<int> GetResourceIds()
		{
			var SessionKey = Request["Key"] == null ? string.Empty : Request["Key"].ToString();
			ResourceIdString = Session[SessionKey] == null ? string.Empty : Session[SessionKey].ToString();
			return ValidateAndGetResourceIds(ResourceIdString);
		}

		private List<int> ValidateAndGetResourceIds(string resourceIds)
		{
			if (string.IsNullOrEmpty(resourceIds))
			{
				Response.Redirect("MyStaff.aspx");
			}

			var resourceIdList = new List<int>();

			var resourceIdStringList = resourceIds.Split(',');

			foreach (var resourceId in resourceIdStringList)
			{
				int intId;
				if (int.TryParse(resourceId, out intId))
				{
					resourceIdList.Add(intId);
				}
				else
				{
					throw new Exception(string.Format("ResourceId must be numeric. Non numeric id found:{0}", resourceId));
				}
			}

			string errorMessage;
			List<int> resourceIdsWithNoEditPermission;
			if (models.Resource.IsEditableByCurrentUser(resourceIdList, ExtensionMethods.GetCurrentUserQid(), out errorMessage, out resourceIdsWithNoEditPermission))
			{
				return resourceIdList;
			}
			else
			{
				throw new Exception(errorMessage);
			}
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
				{
					new ButtonDefinition()
					{
						Id="SaveGrid",
						Title="Save",
						CommandEnableJavaScript = "editResourceNs.isSaveButtonEnabled()",
						CommandJavaScript = "editResourceNs.save()",
						Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
					},
					new ButtonDefinition()
					{
						Id="CancelGrid",
						Title="Cancel",
						CommandJavaScript = "editResourceNs.cancel()",
						CommandEnableJavaScript = "editResourceNs.isCancelButtonEnabled()",
						Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
					},
					new ButtonDefinition()
					{
						Id="CloseGrid",
						Title="Close",
						CommandJavaScript = "editResourceNs.close()",
						CommandEnableJavaScript = "editResourceNs.isCloseButtonEnabled()",
						Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
					}
				}
			});

			return new TabDefinition()
			{
				Id = "ResourceRequestRibbon",
				Title = PageTitle,
				Groups = PageGroups.ToArray()
			};
		}

		protected string RenderTmfControls(TmfPlatform tmfPlatform)
		{
			var sbRenderTmfControls = new StringBuilder();
			sbRenderTmfControls.AppendFormat("<td class='tmfName'><input type='checkbox' value='{0}' name='cbTmfPlatformName' id='cbTmfPlatform_{0}'><label for='cbTmfPlatform_{0}'>{1}</label></td>",
								tmfPlatform.Id,
								tmfPlatform.Name);
			if(!IsInMultieditMode)
			{
				sbRenderTmfControls.Append("<td class='tdtmfPrimary' style='width:10%'><input type='radio' class='tmfCtrl tmfCtrlPrimary' name='rbPrimaryTmf' disabled='disabled'></td>")
				.Append("<td style='width:10%'><input type='checkbox' class='tmfCtrl tmfCtrlSecondary' name='cbSecondaryTmf' disabled='disabled'></td>")
				.Append("<td style='width:10%'><input type='checkbox' class='tmfCtrl tmfCtrlTertiary' name='cbTertiaryTmf' disabled='disabled'></td>");
			}
			return sbRenderTmfControls.ToString();

		}
	}
}
