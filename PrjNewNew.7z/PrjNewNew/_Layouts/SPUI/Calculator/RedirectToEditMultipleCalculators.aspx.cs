﻿using System;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Calculator
{
	public partial class RedirectToEditMultipleCalculators : AbstractRmRibbonPageLayout
	{
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			var guid = CacheService.GetNewGuid();
			Session[guid] = Request.Form["selectedEntityIds"];

			Response.Redirect(string.Format("EditMultipleCalculators.aspx?Key={0}&source={1}", guid, Request["source"]));
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "Id",
				Title = "Title",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
