﻿using System;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;
using domainModels = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Calculator
{
	public partial class EditCalculator : AbstractRmRibbonPageLayout
	{
		protected global::Quintiles.RM.Clinical.UI.UserControls.CalculatorGroupContainer fteCalc;
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.EditCalculator; } }
		public string Source { get; set; }
		public string TabTitle { get; set; }
		public string WindowTitle { get; set; }
		public string PageHeading { get; set; }
		public int EntityId { get; set; }
		private bool IsMonitoringAttribute;
		private bool IsMonitoringRequest;
		private readonly bool IsRequestHardOrSoftBooked = false;
		protected int CountryId { get; set; }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			Source = Request.QueryString["source"];

			if (CurrentProject != null)
			{
				ProjectName.Value = CurrentProject.Name;
				ProtocolNumber.Value = CurrentProject.ProtocolNumber;
				OrganizationUnitName.Value = CurrentProject.OrganizationalUnit.Name;
				LoadedSuccessfully.Value = "1";
			}
			else
			{
				if ("ssvattr".Equals(Source, StringComparison.InvariantCultureIgnoreCase))
				{ Response.Redirect("/_Layouts/SPUI/profile/SSVAttr.aspx"); }
				else
				{ Response.Redirect("/_Layouts/SPUI/profile/MonitoringAttributes.aspx"); }
			}

			if (string.IsNullOrEmpty(Source) ||
				(!"ssvattr".Equals(Source, StringComparison.InvariantCultureIgnoreCase) && //Ssv Attribute
				 !"ssvrequest".Equals(Source, StringComparison.InvariantCultureIgnoreCase) && //Ssv Request
				 !"monattr".Equals(Source, StringComparison.InvariantCultureIgnoreCase) && //Monitoring Attribute
				 !"permanent".Equals(Source, StringComparison.InvariantCultureIgnoreCase) && //Monitoring or Permanent request
				 !"submitted".Equals(Source, StringComparison.InvariantCultureIgnoreCase) && //Submitted Request
				 !"queried".Equals(Source, StringComparison.InvariantCultureIgnoreCase) && //Queried Request
				 !"backfill".Equals(Source, StringComparison.InvariantCultureIgnoreCase))) //Backfill Request
			{
				throw new ArgumentException("Invalid or missing parameter: source");
			}
			else
			{
				Source = Source.ToLower();
			}

			int? tempId = Request.QueryString["entityId"].ToInt();
			if (!tempId.HasValue)
			{
				throw new Exception("Invalid or missing parameter: entityId");
			}
			else
			{
				EntityId = tempId.GetValueOrDefault();
			}

			CalculatorGroupContainerData cd;

			if ("ssvattr".Equals(Source))
			{
				SSVAttribute sa = SSVAttribute.Find(EntityId);
				cd = CalculatorService.GetCalculatorsByAttributeId(EntityId, AttributeType_E.SsvAttribute, IsRequestHardOrSoftBooked, CurrentProject.IsDteProject, CurrentProject.VisitSchemaLevelId.GetValueOrDefault(), sa.CountryId);
				TabTitle = string.Format("SSV FTE Calculator - {0}", sa.Country.Name);
				WindowTitle = string.Format("SSV FTE Calculator - {0}", sa.Country.CountryCode);
				PageHeading = string.Format("{0} - {1} - SSV FTE Calculator", sa.Project.ProjectCode, sa.Country.CountryCode);
				CountryWeeklyHours.Value = sa.Country.WeeklyHours.ToString();
			}
			else if ("monattr".Equals(Source))
			{
				MonitoringAttribute ma = MonitoringAttribute.Find(EntityId);
				cd = CalculatorService.GetCalculatorsByAttributeId(EntityId, AttributeType_E.MonitoringAttribute, IsRequestHardOrSoftBooked, CurrentProject.IsDteProject, CurrentProject.VisitSchemaLevelId.GetValueOrDefault(), ma.CountryId);
				TabTitle = string.Format("FTE Calculator - {0}", ma.Country.Name);
				WindowTitle = string.Format("FTE Calculator - {0}", ma.Country.CountryCode);
				PageHeading = string.Format("{0} - {1} - FTE Calculator", ma.Project.ProjectCode, ma.Country.CountryCode);
				IsMonitoringAttribute = true;
				CountryId = ma.Country.Id;
				CountryWeeklyHours.Value = ma.Country.WeeklyHours.ToString();
			}
			else
			{
				domainModels.Request req = domainModels.Request.Find(EntityId);

				if (req.RequestTypeId != (int)RequestType_E.SSV && req.RequestTypeId != (int)RequestType_E.Permanent)
				{
					throw new Exception(string.Format("Request type \"{0}\" is not supported on EditRequest page", ((RequestType_E)req.RequestTypeId).ToString()));
				}
				else if (req.RequestTypeId == (int)RequestType_E.Permanent)
				{
					IsMonitoringRequest = true;
				}

				CountryWeeklyHours.Value = req.Country.WeeklyHours.ToString();

				PageHeading = String.Format("{0} - {1} - {2} - {3} - {4}",
					req.Project.ProjectCode,
					req.Country.CountryCode,
					(req.ProjectProtocolSite == null || string.IsNullOrEmpty(req.ProjectProtocolSite.SponsorSite)) ? "No Site ID" : req.ProjectProtocolSite.SponsorSite,
					ProjectProtocolSite.GetPrincipalInvestigatorName(req.ProjectProtocolSite),
					req.ResourceType.Name);

				cd = CalculatorService.GetCalculatorsByRequestId(EntityId, IsRequestHardOrSoftBooked);
				TabTitle = WindowTitle = "FTE Calculator";

				string countryName = req.Country == null ? string.Empty : string.Format(" - {0}", req.Country.Name);
				string countryCode = req.Country == null ? string.Empty : string.Format(" - {0}", req.Country.CountryCode);
				TabTitle = String.Format("{0}{1}", TabTitle, countryName);
				WindowTitle = String.Format("{0}{1}", WindowTitle, countryCode);
			}

			fteCalc.CalculatorContainerData = cd;

			ltrPrintableTitle.Text = WindowTitle;
			ltrTitle.Text = WindowTitle;
			lblHeading.Text = PageHeading;
		}

		#region GetTabDefinition
		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "calculaotrActions",
				Title = "Calculator Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
                    {
                        new ButtonDefinition()
                        {
                            Id="SaveCalc",
                            Title="Save",
                            CommandJavaScript = "calculatorGroup.saveCalculator(true)",
                            CommandEnableJavaScript = "calculatorGroup.isSaveEnabled();",
                            Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
                        },
                        new ButtonDefinition()
                        {
                            Id="CancelGrid",
                            Title="Cancel",
                            CommandJavaScript = "calculatorGroup.cancel()",
                            CommandEnableJavaScript = "calculatorGroup.isCancelEnabled()",
                            Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
                        },
                        new ButtonDefinition()
                        {
                            Id="CloseGrid",
                            Title="Close",
                            CommandJavaScript = string.Format("calculatorGroup.close('{0}')", Source),
                            CommandEnableJavaScript = "true;",
                            Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
                        }
                    }
			});

			if (IsMonitoringAttribute)
			{
				AddMonitoringAttributeActions();
			}
			else if (IsMonitoringRequest)
			{
				AddMonitoringRequestActions();
			}

			return new TabDefinition()
			{
				Id = "CalculatorRibbon",
				Title = TabTitle,
				Groups = PageGroups.ToArray()
			};
		}

		private void AddMonitoringRequestActions()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "OtherActions",
				Title = "Other Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
                {   
                    new ButtonDefinition()
                    {       
                        Id="AddAdHoc",
                        Title="Add Ad-hoc Interim Monitoring Frequency",
                        CommandJavaScript = "calculatorGroup.addAdhocCalculatorToCurrentTab()",
                        CommandEnableJavaScript = "true",
                        Image=MapImageLibrary.GetFormatMapImage(11,3, revision)
                    },
                }
			});
		}

		private void AddMonitoringAttributeActions()
		{

			bool hasPharmacyTierEnabled = domainModels.FTECalculator.HasPharmacyTierEnabled(CurrentProject.Id, CurrentProject.ProjectDteType, (int)CurrentProject.VisitSchemaLevelId.GetValueOrDefault());
			PageGroups.Add(new GroupDefinition()
			{
				Id = "OtherActions",
				Title = "Pharmacy Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
                    {   
                        new ButtonDefinition()
                        {
													  Id="RemovePharma",
                            Title="Remove Pharmacy Calculator",
                            CommandJavaScript = "calculatorGroup.removePharmacyCalculator()",
                            CommandEnableJavaScript = "calculatorGroup.hasPharmacyCalculatorGroup()",
                            Image=MapImageLibrary.GetFormatMapImage(11,8, revision)
                        },
                        new ButtonDefinition()
                        {
                            Id="AddPharma",
                            Title="Add Pharmacy Calculator",
                            CommandJavaScript = "calculatorGroup.addPharmacyCalculatorGroup()",
														CommandEnableJavaScript = "calculatorGroup.hasPharmacyCalculatorGroupAndTierEnabled(" + hasPharmacyTierEnabled.ToString().ToLower() + ")",
														Image=MapImageLibrary.GetFormatMapImage(6,2, revision)
                        },
                   
                    }
			});

			PageGroups.Add(new GroupDefinition()
			{
				Id = "iCRAActions",
				Title = "Remote Monitoring Non RBM Only Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
					{   
							new ButtonDefinition()
							{
									Id="RemoveiCRA",
									Title="Remove Remote Monitoring Non RBM Only Calculator",
									CommandJavaScript = "calculatorGroup.removeICraCalculatorGroup()",
									CommandEnableJavaScript = "calculatorGroup.hasICraCalculatorGroup()",
									Image=MapImageLibrary.GetFormatMapImage(11,8, revision)
							},
							new ButtonDefinition()
							{
									Id="AddiCRA",
									Title="Add Remote Monitoring Non RBM Only Calculator",
									CommandJavaScript = "calculatorGroup.addICraCalculatorGroup()",
									CommandEnableJavaScript = "!calculatorGroup.hasICraCalculatorGroupForAdd()",
									Image=MapImageLibrary.GetFormatMapImage(6,2, revision)
							}
					}
			});
		}
		#endregion
	}
}
