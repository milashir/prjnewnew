﻿using System;
using System.Collections.Generic;
using System.Linq;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Calculator
{
	public partial class EditMultipleCalculators : AbstractRmRibbonPageLayout
	{
		protected global::Quintiles.RM.Clinical.UI.UserControls.CalculatorGroupContainer fteCalc;
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.EditCalculator; } }
		public string Source { get; set; }
		public string TabTitle { get; set; }
		public string WindowTitle { get; set; }
		public string PageHeading { get; set; }
		public int EntityId { get; set; }
		private bool IsMonitoringAttribute;
		protected int CountryId { get; set; }
		public string SessionKey { get; set; }
		public List<int> EntityIds { get; set; }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			Source = Request.QueryString["source"];


			if (CurrentProject == null)
			{
				if ("ssvattr".Equals(Source, StringComparison.InvariantCultureIgnoreCase))
				{ Response.Redirect("/_Layouts/SPUI/profile/SSVAttr.aspx"); }
				else
				{ Response.Redirect("/_Layouts/SPUI/profile/MonitoringAttributes.aspx"); }
			}

			EntityIds = GetEntityIds();

			hdnSource.Value = Source;
			if (string.IsNullOrEmpty(Source) ||
					(!"ssvattr".Equals(Source, StringComparison.InvariantCultureIgnoreCase) && //Ssv Attribute
					 !"monattr".Equals(Source, StringComparison.InvariantCultureIgnoreCase) //Monitoring Attribute
					 ))
			{
				throw new ArgumentException("Invalid or missing parameter: source");
			}
			else
			{
				Source = Source.ToLower();
			}

			CalculatorGroupContainerData cd = null;

			string pageHeadSuffix = "<br/>Only make changes to those fields where required and leave fields blank where no change is needed. <br/>The changes entered will be applied to all the selected countries. Refer to Help for further information. ";

			if ("ssvattr".Equals(Source))
			{
				cd = CalculatorService.GetCountryCalculatorsByAttributeType(AttributeType_E.SsvAttribute, EntityIds, CurrentProject.IsDteProject, CurrentProject.VisitSchemaLevelId.GetValueOrDefault(), Constants.UnspecifiedId);
				TabTitle = string.Format("SSV FTE Calculator - {0} Countries", EntityIds.Count);
				WindowTitle = TabTitle;
				PageHeading = string.Format("For Project Code {0}, you are editing SSV Monitoring Attributes for {1}. ", CurrentProject.ProjectCode + "-" + CurrentProject.ProtocolNumber, GetSsvcountryNames());
				CountryWeeklyHours.Value = Constants.UnspecifiedId.ToString();
			}
			else if ("monattr".Equals(Source))
			{
				cd = CalculatorService.GetCountryCalculatorsByAttributeType(AttributeType_E.MonitoringAttribute, EntityIds, CurrentProject.IsDteProject, CurrentProject.VisitSchemaLevelId.GetValueOrDefault(), Constants.UnspecifiedId);
				TabTitle = string.Format("FTE Calculator - {0} Countries", EntityIds.Count);
				WindowTitle = TabTitle;
				PageHeading = string.Format("For Project Code {0}, you are editing Monitoring Attributes for {1}.", CurrentProject.ProjectCode + "-" + CurrentProject.ProtocolNumber, GetMonitoringCountryNames());
				IsMonitoringAttribute = true;
				CountryId = Constants.UnspecifiedId;
				CountryWeeklyHours.Value = Constants.UnspecifiedId.ToString();
			}

			PageHeading = PageHeading + pageHeadSuffix;

			cd.IsEditMultipleRequests = true;
			fteCalc.MultiEditMode = cd.IsEditMultipleRequests;
			fteCalc.CalculatorContainerData = cd;

			ltrPrintableTitle.Text = WindowTitle;
			ltrTitle.Text = WindowTitle;
			lblHeading.Text = PageHeading;
		}

		private string GetMonitoringCountryNames()
		{
			return GetConcatenatedCountryNames(MonitoringAttribute.FindByAttributeIdList(EntityIds));
		}

		private string GetSsvcountryNames()
		{
			return GetConcatenatedCountryNames(SSVAttribute.FindByAttributeIdList(EntityIds));
		}

		private string GetConcatenatedCountryNames(IEnumerable<ICountryAttribute> list)
		{
			return string.Join(", ", list.Select(ca => CacheService.Country(ca.CountryId).Name).ToArray());
		}

		private List<int> GetEntityIds()
		{
			SessionKey = Request["Key"] == null ? string.Empty : Request["Key"].ToString();
			string entityIds = Session[SessionKey] == null ? string.Empty : Session[SessionKey].ToString();
			EntityIdList.Value = entityIds;
			return ValidateAndGetEntityIds(entityIds);
		}


		private List<int> ValidateAndGetEntityIds(string entityIds)
		{
			if (string.IsNullOrEmpty(entityIds))
			{
				Response.Redirect("../profile/MonitoringAttributes.aspx");
				//throw new ArgumentNullException("Entity IDs cannot be null or empty");
			}

			var entityIdList = new List<int>();

			var entityIdStringList = entityIds.Split(',').ToList<string>();

			foreach (var entityId in entityIdStringList)
			{
				int intId;
				if (int.TryParse(entityId, out intId))
				{
					entityIdList.Add(intId);
				}
				else
				{
					throw new Exception(string.Format("EntityId must be numeric. Non numeric id found:{0}", entityId));
				}
			}

			return entityIdList;
		}

		#region GetTabDefinition
		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "calculaotrActions",
				Title = "Calculator Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
                    {
                        new ButtonDefinition()
                        {
                            Id="SaveCalc",
                            Title="Save",
                            CommandJavaScript = "calculatorGroup.saveCalculator(true)",
                            CommandEnableJavaScript = "calculatorGroup.isSaveEnabled();",
                            Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
                        },
                        new ButtonDefinition()
                        {
                            Id="CancelGrid",
                            Title="Cancel",
                            CommandJavaScript = "calculatorGroup.cancel()",
                            CommandEnableJavaScript = "calculatorGroup.isCancelEnabled()",
                            Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
                        },
                        new ButtonDefinition()
                        {
                            Id="CloseGrid",
                            Title="Close",
                            CommandJavaScript = string.Format("calculatorGroup.close('{0}')", Source),
                            CommandEnableJavaScript = "true;",
                            Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
                        }
                    }
			});

			if (IsMonitoringAttribute)
			{
				AddMonitoringAttributeActions();
			}

			return new TabDefinition()
			{
				Id = "CalculatorRibbon",
				Title = TabTitle,
				Groups = PageGroups.ToArray()
			};
		}

		private void AddMonitoringAttributeActions()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "OtherActions",
				Title = "Pharmacy Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
                    {   
                        new ButtonDefinition()
                        {
                            Id="RemovePharma",
                            Title="Remove Pharmacy Calculator",
                            CommandJavaScript = "calculatorGroup.removePharmacyCalculator(" + CurrentProject.IsDteProject.ToString().ToLower() + ")",
                            CommandEnableJavaScript = "calculatorGroup.hasPharmacyCalculatorGroup(" + CurrentProject.IsDteProject.ToString().ToLower() + ")",
                            Image=MapImageLibrary.GetFormatMapImage(11,8, revision)
                        },
                        new ButtonDefinition()
                        {
                            Id="AddPharma",
                            Title="Add Pharmacy Calculator",
                            CommandJavaScript = "calculatorGroup.addPharmacyCalculatorGroup(" + CurrentProject.IsDteProject.ToString().ToLower() + ")",
                            CommandEnableJavaScript = "!calculatorGroup.hasPharmacyCalculatorGroup(" + CurrentProject.IsDteProject.ToString().ToLower() + ",'" + CurrentProject.VisitSchemaLevelId + "','"+CurrentProject.Id+"')",
                            Image=MapImageLibrary.GetFormatMapImage(6,2, revision)
                        },
                   
                    }
			});


			PageGroups.Add(new GroupDefinition()
			{
				Id = "iCRAActions",
				Title = "Remote Monitoring Non RBM Only Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
					{   
							new ButtonDefinition()
							{
									Id="RemoveiCRA",
									Title="Remove Remote Monitoring Non RBM Only Calculator",
									CommandJavaScript = "calculatorGroup.removeICraCalculatorGroup()",
									CommandEnableJavaScript = "calculatorGroup.hasICraCalculatorGroup(" + CurrentProject.IsDteProject.ToString().ToLower() + ")",
									Image=MapImageLibrary.GetFormatMapImage(11,8, revision)
							},
							new ButtonDefinition()
							{
									Id="AddiCRA",
									Title="Add Remote Monitoring Non RBM Only Calculator",
									CommandJavaScript = "calculatorGroup.addICraCalculatorGroup()",
									CommandEnableJavaScript = "!calculatorGroup.hasICraCalculatorGroupForAdd(" + CurrentProject.IsDteProject.ToString().ToLower() + ")",
									Image=MapImageLibrary.GetFormatMapImage(6,2, revision)
							}
					}
			});
		}
		#endregion
	}
}
