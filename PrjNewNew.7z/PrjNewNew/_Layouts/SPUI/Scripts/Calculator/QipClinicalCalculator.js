/// <reference path="../common/rmhelper.js" />
var _countryIds = {
	Japan: 192
};

calculatorHelper =
{
	siteChanged: false,
	selectedCountryId: 0,
	selectedResourceTypeId: 0,
	covSiteVisitCount: 0,
	lastCovVisitDate: null,
	connectedStopDate: null,
	countryResourceTypeUtilization: {},
	isRequestHardOrSoftBooked: false,
	tabIdToActivateOnLoad: 0,
	timeoutInterval: 30,
	handleDirty: true,
	onConnectImageClick: function () { },
	onDeleteAdhocClick: function () { },
	onAdhocDateEdit: function () { },
	onSaveSuccess: function () {
		calculatorHelper.onSaveSuccessInternal();
	},
	onSiteChangeComplete: function (eventData) { },
	onSaveSuccessInternal: function () {
		calculatorHelper.removedDeletedCalculatorsFromDomAndJson(calculatorIdJson);
		calculatorHelper.bindDirtyToEntireForm(calculatorIdJson); //bind dirty again to prevent save prompt
		//calculatorHelper.preventQipConnect(calculatorIdJson, calculatorHelper.getSelectedTabIndex());
		rm.ui.ribbon.delayedRefresh();
	},
	onRemoveGroupSuccess: function () { },
	onAddGroupSuccess: function () { },
	onTabReady: function () { },
	connectStatusDialogOnOkClick: function () { alert("Override calculatorHelper.connectStatusDialogOnOkClick()"); },
	getRequestStopDateFromUi: function () { alert("Override calculatorHelper.getRequestStopDateFromUi()"); },
	conectedValAttr: "connectedValue",
	tabsSelector: "#tabs",
	tabContainerSelector: "#tabsul",

	notInSubmittedPage: function () {
		return window.location.href.toLowerCase().indexOf("submitted") == -1;
	},

	getProjectId: function () { return $("[id$=hdnProjectId]").val(); },

	getProjectDteTypeId: function () { return $("[id$=hdnProjectDteTypeId]").val(); },

	isDteProject: function () { return $("[id$=hdnProjectDteTypeId]").val() == ProjectDteType_E.Dte; },

	getVisitSchemaLevelId: function () { return $("[id$=hdnVisitSchemaLevelId]").val(); },

	DataChangeValidationRequired: function () {
		return (calculatorHelper.isDteProject() && calculatorHelper.notInSubmittedPage());
	},

	getAttributeIdList: function () {
		var idListString = $("[id$=EntityIdList]").val();
		return (idListString == undefined || idListString == null) ? [] : idListString.split(",");
	},

	isNewRequest: function () { return ($("[id$=hdnIsNewRequest]").val() == "1"); },

	isRequestCalculator: function () { return (typeof (calculatorIdJson) !== 'undefined' && calculatorIdJson.IsRequestCalculator); /*return (calculatorHelper.getRequestId() > 0 || calculatorHelper.isNewRequest());*/ },

	isIndependentCalculator: function () { return ($("[id$=hdnIsIndependentCalculator]").val() == "1"); },

	isInMultiEditMode: function () { return ($("[id$=hdnMultiEditMode]").val() == "1"); },

	getCalculatorGroupId: function (controlPrefix) { return $(calculatorHelper.getControlSelector(controlPrefix, "calculatorGroupId")).val(); },//function () { return $("[id$=calculatorGroupId]").val(); },

	getCalculatorTypeId: function (controlPrefix) { return $(calculatorHelper.getControlSelector(controlPrefix, "calculatorTypeId")).val(); },

	getIsCountryChanged: function () { return ($("[id$=hdnIsCountryChanged]").val() == "1"); },

	setIsCountryChanged: function () { $("[id$=hdnIsCountryChanged]").val("1"); },

	getRequestId: function () { return $("[id$=hdnRequestId]").val() > 0 ? $("[id$=hdnRequestId]").val() : null; },

	getAttributeId: function () { return $("[id$=hdnAttributeId]").val(); },

	setAttributeId: function (newId) { return $("[id$=hdnAttributeId]").val(newId); },

	setJobGrade: function (jobGrade) { $("#divCalculator [id$=hdnJobGrade]").val(jobGrade); },
	setJobGradeInfoString: function (jobGradeInfoString) { $("#divCalculator [id$=hdnJobGradeInfoString]").val(jobGradeInfoString); },
	getJobGrade: function () { return $("#divCalculator [id$=hdnJobGrade]").val(); },
	getJobGradeInfoString: function () { return $("#divCalculator [id$=hdnJobGradeInfoString]").val(); },
	getAttributeTypeId: function () { return $("[id$=hdnAttributeTypeId]").val(); },

	getRequestTypeId: function () { return $("[id$=hdnRequestTypeId]").val(); },

	getSource: function () { return $("[id$=hdnSource]").val(); },

	getSsvAttributeId: function () { return ((calculatorHelper.getAttributeTypeId() == AttributeType_E.SsvAttribute) ? calculatorHelper.getAttributeId() : null); },

	getMonitoringAttributeId: function () { return ((calculatorHelper.getAttributeTypeId() == AttributeType_E.MonitoringAttribute) ? calculatorHelper.getAttributeId() : null); },

	overrideDmlOperation: function (controlPrefix, isAddingNew) { return (isAddingNew && !calculatorHelper.isConnected(controlPrefix) && calculatorHelper.showConnectDisconnect(controlPrefix)); },

	showConnectedImage: function (controlPrefix) {
		$(calculatorHelper.getControlSelector(controlPrefix, "imgReConnect")).hide();
		$(calculatorHelper.getControlSelector(controlPrefix, "imgConnect")).show();
	},

	showDisConnectedImage: function (controlPrefix) {
		$(calculatorHelper.getControlSelector(controlPrefix, "imgConnect")).hide();
		$(calculatorHelper.getControlSelector(controlPrefix, "imgReConnect")).show();
	},

	getControlSelector: function (controlPrefix, controlId) {
		return "[id$=" + controlPrefix + "_" + controlId + "]";
	},

	getControlValueOrNullIfBlank: function (controlPrefix, controlId) {
		var controlValue = $(calculatorHelper.getControlSelector(controlPrefix, controlId)).val();
		return controlValue == "" ? null : controlValue;
	},

	getFrequencyNameFromCalculatorTypeId: function (calculatorTypeId) {
		var calcName = "";
		switch (calculatorTypeId) {
			case CalculatorType_E.SIV: calcName = "SIV"; break;
			case CalculatorType_E.SIV_FPI: calcName = "SIV-FSI"; break;
			case CalculatorType_E.IMV_Freq1_FPI_LPI: calcName = calculatorHelper.isDteProject() ? "FSI-LSI" : "IMV Freq1<br/>FSI-LSI"; break;
			case CalculatorType_E.IMV_Freq2_LPI_LPO: calcName = calculatorHelper.isDteProject() ? "LSI-LSO" : "IMV Freq2<br/>LSI-LSO"; break;
			case CalculatorType_E.IMV_Freq34_LPO_DBL: calcName = "IMV Freq3<br/>LSO-DBL"; break;
			case CalculatorType_E.DBL_COV: calcName = "DBL-COV"; break;
			case CalculatorType_E.COV: calcName = "COV"; break;
			case CalculatorType_E.PharmacyMonitoring: calcName = "Pharmacy<br/>Monitoring"; break;
			case CalculatorType_E.AdHoc: calcName = "Ad-Hoc"; break;
			case CalculatorType_E.IMV_Freq4_LPO_DBL: calcName = "IMV Freq 4<br/>DBL-COV"; break;
			case CalculatorType_E.SSV: calcName = "SSV"; break;
			case CalculatorType_E.LSO_COV: calcName = "LSO-COV"; break;
			case CalculatorType_E.MonitoringSiteSpecific: calcName = "MonitoringSiteSpecific"; break;
		}
		return calcName;
	},

	getBlankValueIfNull: function (controlPrefix, controlId) {
		var value = $(calculatorHelper.getControlSelector(controlPrefix, controlId)).val();

		return (!value || value == null) ? "" : value;
	},

	wasImageClickedToConnect: function (controlPrefix) {
		return ($(calculatorHelper.getControlSelector(controlPrefix, "connectedByImageClick")).val() == "1");
	},

	imageClickedToConnect: function (controlPrefix) {
		$(calculatorHelper.getControlSelector(controlPrefix, "connectedByImageClick")).val("1");
		$(calculatorHelper.getControlSelector(controlPrefix, "isConnected")).val("1");
	},

	updateConnectStatus: function (controlPrefix, connectValue) {
		if (connectValue == "1") {
			calculatorHelper.showConnectedImage(controlPrefix);
		}
		else {
			calculatorHelper.showDisConnectedImage(controlPrefix);
		}

		$(calculatorHelper.getControlSelector(controlPrefix, "isConnected")).val(connectValue);
	},

	showConnectDisconnect: function (controlPrefix) { return $(calculatorHelper.getControlSelector(controlPrefix, "imgConnect")).length != 0 },
	getSelectorForRangeValidation: function (controlPrefix) { return $.validationHelper.validateRangeSelector + "[id*=" + controlPrefix + "]"; },
	getSelectorForChangeEventHandler: function (controlPrefix) { return $.validationHelper.validateRangeClass + "[id*=" + controlPrefix + "]"; },
	getSelectedTabIndex: function () { return rm.ui.tabs.getSelecteTabIndex(calculatorHelper.tabsSelector); },
	getGroupIdFromSelectedTab: function () { return calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()].CalculatorGroupId; },
	setConnectedValue: function (controlPrefix, controlName, connectedValue) {
		$(calculatorHelper.getControlSelector(controlPrefix, controlName)).attr(calculatorHelper.conectedValAttr, typeof connectedValue == "undefined" ? "" : connectedValue);
	},
	updateFrequencyHeader: function (controlPrefix, connectedValue) {
		if (connectedValue && connectedValue.FrequencyHeader) {
			$(calculatorHelper.getControlSelector(controlPrefix, "frequencyHeader")).html(connectedValue.FrequencyHeader);
		}
		if (connectedValue && connectedValue.FrequencyHeaderToolTip) {
			var headerSelector = calculatorHelper.getControlSelector(controlPrefix, "header");
			$(headerSelector).qtip('destroy')
			rm.qtip.showInfo(headerSelector, connectedValue.FrequencyHeaderToolTip);
			$(headerSelector + " span").attr("toolTip", connectedValue.FrequencyHeaderToolTip);
		}
	},
	isQipClinicalCalculatorDirty: function () { return calculatorHelper.isCurrentTabDirty(calculatorIdJson); },

	isCurrentTabDirty: function (calculatorIdJson) {
		var isDirty = false;

		var calcGroup = calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()];
		if (calcGroup && $("#" + calcGroup.GroupPrefix).is(":visible")) {
			$.each(calcGroup.Calculators, function (index, calculator) {
				isDirty = calculatorHelper.isCalculatorDirty(calculator.ControlPrefix);
				if (isDirty) {
					return false;
				}
			});
		}
		return isDirty;
	},

	onControlLoad: function (controlPrefix) {
		var selector = calculatorHelper.getSelectorForRangeValidation(controlPrefix);
		var selectorForChangeHandler = calculatorHelper.getSelectorForChangeEventHandler(controlPrefix);

		//calculatorHelper.bindErrorQTip(selector);
		calculatorHelper.formatText(selector);
		calculatorHelper.bindTextboxChange(selectorForChangeHandler, controlPrefix);
		calculatorHelper.bindTextManualChange(selectorForChangeHandler, controlPrefix);
		calculatorHelper.tierChangeEvent(controlPrefix);
		var headerSelector = calculatorHelper.getControlSelector(controlPrefix, "header");
		if ($(headerSelector).length > 0) {
			rm.qtip.showInfo(headerSelector, $(headerSelector + " span").attr("toolTip"));
		}

	},

	getOnsitecontrolSelector: function (controlPrefix) {
		return calculatorHelper.getControlSelector(controlPrefix, "travelTimeCluster") + "," +
			 calculatorHelper.getControlSelector(controlPrefix, "onSiteTime") + "," +
			 calculatorHelper.getControlSelector(controlPrefix, "prepFollowUpTime");
	},

	getPhonecontrolSelector: function (controlPrefix) {
		return calculatorHelper.getControlSelector(controlPrefix, "phoneVisitTime") + "," +
			 calculatorHelper.getControlSelector(controlPrefix, "phonePrepFollowUpTime");
	},

	recalculateOnsiteAndPhoneFte: function (controlPrefix) {
		calculatorHelper.recalculateFte(calculatorHelper.getOnsitecontrolSelector(controlPrefix), calculatorHelper.getControlSelector(controlPrefix, "fte"), calculatorGroup.countryWeeklyHours);
		calculatorHelper.recalculateFte(calculatorHelper.getPhonecontrolSelector(controlPrefix), calculatorHelper.getControlSelector(controlPrefix, "phoneFte"), calculatorGroup.countryWeeklyHours);
	},

	bindRecalculateFteEvent: function (controlPrefix) {
		var onsiteSelector = calculatorHelper.getOnsitecontrolSelector(controlPrefix);

		$(onsiteSelector).bind("paste cut drop keyup", function () {
			calculatorHelper.recalculateFte(onsiteSelector, calculatorHelper.getControlSelector(controlPrefix, "fte"), calculatorGroup.countryWeeklyHours);
		});

		var phoneSelector = calculatorHelper.getPhonecontrolSelector(controlPrefix);

		$(phoneSelector).bind("paste cut drop keyup", function () {
			calculatorHelper.recalculateFte(phoneSelector, calculatorHelper.getControlSelector(controlPrefix, "phoneFte"), calculatorGroup.countryWeeklyHours);
		});
	},

	recalculateFte: function (sourceSelector, destinationSelector, countryWeeklyHours) {
		var controls = $(sourceSelector);
		var total = 0;
		var monthlyHours = (countryWeeklyHours * calculatorHelper.getTargetUtilization() * 22.5) / RmConstants.NumberOfDaysInAWeek; //Convert weekly hours to monthly hours
		$.each(controls, function (index, control) {
			if ($.isNumeric($(control).val()) && $(control).val() > 0)
				total += $(control).val() * 1;
		});

		$(destinationSelector).val($.q.formatNumberString(total / monthlyHours, $(destinationSelector).attr("formating")));
	},

	onRibbonClick: function () {
		//Only one tab can be modified at a time. So run all checks only for current tab
		var calcGroup = calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()];
		$.each(calcGroup.Calculators, function (index, calc) {
			calculatorHelper.onTextChange(calculatorHelper.getSelectorForRangeValidation(calc.ControlPrefix), calc.ControlPrefix);
		});

		//Call onRibbonClick of all groups
		var nameSpace = calculatorGroup.monitoringCalculatorGroup;
		if (nameSpace) { nameSpace.onRibbonClick(); }

		nameSpace = calculatorGroup.pharmacyCalculatorGroup;
		if (nameSpace) { nameSpace.onRibbonClick(); }

		nameSpace = calculatorGroup.iCraCalculatorGroup;
		if (nameSpace) { nameSpace.onRibbonClick(); }

		nameSpace = calculatorGroup.ssvCalculatorGroup;
		if (nameSpace) { nameSpace.onRibbonClick(); }

		nameSpace = calculatorGroup.initiateCalculatorGroup;
		if (nameSpace) { nameSpace.onRibbonClick(); }

		var nameSpace = calculatorGroup.dteMonitoringCalculatorGroup;
		if (nameSpace) { nameSpace.onRibbonClick(); }

		nameSpace = calculatorGroup.dtePharmacyCalculatorGroup;
		if (nameSpace) { nameSpace.onRibbonClick(); }

		nameSpace = calculatorGroup.monitoringSiteSpecificCalculatorGroup;
		if (nameSpace) { nameSpace.onRibbonClick(); }
	},

	getCalculatorByCalculatorTypeId: function (calculatorTypeId) {
		var calculatorObject;
		var calcGroup = calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()];
		if (calcGroup) {
			$.each(calcGroup.Calculators, function (index, calc) {
				if (calc.CalculatorTypeId == calculatorTypeId) {
					calculatorObject = calc;
					return false;
				}
			});
		}
		return calculatorObject;

	},

	removeUnusedNamespaces: function (selectedResourceTypeId) {
		switch (selectedResourceTypeId) {
			case ResourceTypeName.Standard_Monitoring:
				calculatorGroup.pharmacyCalculatorGroup = null;
				calculatorGroup.iCraCalculatorGroup = null;
				calculatorGroup.ssvCalculatorGroup = null;
				calculatorGroup.initiateCalculatorGroup = null;
				calculatorGroup.monitoringSiteSpecificCalculatorGroup = null;
				calculatorGroup.dteMonitoringCalculatorGroup = null;
				calculatorGroup.dtePharmacyCalculatorGroup = null;
				break;
			case ResourceTypeName.Pharmacy_Monitoring:
				calculatorGroup.monitoringCalculatorGroup = null;
				calculatorGroup.iCraCalculatorGroup = null;
				calculatorGroup.ssvCalculatorGroup = null;
				calculatorGroup.initiateCalculatorGroup = null;
				calculatorGroup.monitoringSiteSpecificCalculatorGroup = null;
				calculatorGroup.dteMonitoringCalculatorGroup = null;
				calculatorGroup.dtePharmacyCalculatorGroup = null;
				break;
			case ResourceTypeName.iCRA_Monitoring:
				calculatorGroup.monitoringCalculatorGroup = null;
				calculatorGroup.pharmacyCalculatorGroup = null;
				calculatorGroup.ssvCalculatorGroup = null;
				calculatorGroup.initiateCalculatorGroup = null;
				calculatorGroup.monitoringSiteSpecificCalculatorGroup = null;
				calculatorGroup.dteMonitoringCalculatorGroup = null;
				calculatorGroup.dtePharmacyCalculatorGroup = null;
				break;
			case ResourceTypeName.SSV_Monitoring:
				calculatorGroup.monitoringCalculatorGroup = null;
				calculatorGroup.pharmacyCalculatorGroup = null;
				calculatorGroup.iCraCalculatorGroup = null;
				calculatorGroup.initiateCalculatorGroup = null;
				calculatorGroup.monitoringSiteSpecificCalculatorGroup = null;
				calculatorGroup.dteMonitoringCalculatorGroup = null;
				calculatorGroup.dtePharmacyCalculatorGroup = null;
				break;
			case ResourceTypeName.Short_term_SWAT_Monitoring_OnSite_Visit:
			case ResourceTypeName.Short_term_SWAT_Monitoring_Phone_Visit:
			case ResourceTypeName.Co_monitoring_SiteSpecific:
			case ResourceTypeName.Non_Standard_Monitoring_SiteSpecific:
				calculatorGroup.monitoringCalculatorGroup = null;
				calculatorGroup.pharmacyCalculatorGroup = null;
				calculatorGroup.iCraCalculatorGroup = null;
				calculatorGroup.ssvCalculatorGroup = null;
				calculatorGroup.dteMonitoringCalculatorGroup = null;
				calculatorGroup.dtePharmacyCalculatorGroup = null;
				break;
			case ResourceTypeName.DTESite_Monitoring:
				calculatorGroup.monitoringCalculatorGroup = null;
				calculatorGroup.pharmacyCalculatorGroup = null;
				calculatorGroup.iCraCalculatorGroup = null;
				calculatorGroup.ssvCalculatorGroup = null;
				calculatorGroup.initiateCalculatorGroup = null;
				calculatorGroup.monitoringSiteSpecificCalculatorGroup = null;
				calculatorGroup.dtePharmacyCalculatorGroup = null;
				break;
			case ResourceTypeName.DTEPharmacy_Monitoring:
				calculatorGroup.monitoringCalculatorGroup = null;
				calculatorGroup.pharmacyCalculatorGroup = null;
				calculatorGroup.iCraCalculatorGroup = null;
				calculatorGroup.ssvCalculatorGroup = null;
				calculatorGroup.initiateCalculatorGroup = null;
				calculatorGroup.monitoringSiteSpecificCalculatorGroup = null;
				calculatorGroup.dteMonitoringCalculatorGroup = null;
				break;
			default:
				calculatorGroup.monitoringCalculatorGroup = null;
				calculatorGroup.pharmacyCalculatorGroup = null;
				calculatorGroup.iCraCalculatorGroup = null;
				calculatorGroup.ssvCalculatorGroup = null;
				calculatorGroup.initiateCalculatorGroup = null;
				calculatorGroup.monitoringSiteSpecificCalculatorGroup = null;
				calculatorGroup.dteMonitoringCalculatorGroup = null;
				calculatorGroup.dtePharmacyCalculatorGroup = null;
				break;
		}
	},

	handleCountryChange: function (projectId, countryId, attributeTypeId) {
		var isSuccessful = true;
		calculatorHelper.setIsCountryChanged();

		var postData = {
			projectId: projectId,
			countryId: countryId,
			calculatorGroup: calculatorHelper.getGroupIdFromSelectedTab()
		};

		$.rm.Ajax_Calculator("GetConnectedCalculatorValues", postData, function (data) {
			if (data.ContainsValidationErrors) {
				$.validationHelper.ShowErrorMessages(data.ValidationErrors);
				isSuccessful = false;
			}
			else {
				var connectedValues = data.RequestExecutionStatus.AdditionalData.ConnectedValues;
				var attributeId = data.RequestExecutionStatus.AdditionalData.AttributeId;
				calculatorGroup.countryWeeklyHours = data.RequestExecutionStatus.AdditionalData.CountryWeeklyHours;

				calculatorHelper.setAttributeId(attributeId); //Update the attribute id in DOM
				calculatorHelper.setJobGrade(data.RequestExecutionStatus.AdditionalData.JobGrade); //Update the JobGrade in DOM
				calculatorHelper.setJobGradeInfoString(data.RequestExecutionStatus.AdditionalData.JobGradeInfoStr); //Update the JobGradeInfoString in DOM

				//Call handle country change of all groups
				var nameSpace = calculatorGroup.monitoringCalculatorGroup;
				if (nameSpace) { if (!nameSpace.handleCountryChange(connectedValues, attributeId)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.pharmacyCalculatorGroup;
				if (nameSpace) { if (!nameSpace.handleCountryChange(connectedValues, attributeId)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.iCraCalculatorGroup;
				if (nameSpace) { if (!nameSpace.handleCountryChange(connectedValues, attributeId)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.ssvCalculatorGroup;
				if (nameSpace) { if (!nameSpace.handleCountryChange(connectedValues, attributeId)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.initiateCalculatorGroup;
				if (nameSpace) { if (!nameSpace.handleCountryChange(connectedValues, attributeId)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.monitoringSiteSpecificCalculatorGroup;
				if (nameSpace) { if (!nameSpace.handleCountryChange(connectedValues, attributeId)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.dteMonitoringCalculatorGroup;
				if (nameSpace) { if (!nameSpace.handleCountryChange(connectedValues, attributeId)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.dtePharmacyCalculatorGroup;
				if (nameSpace) { if (!nameSpace.handleCountryChange(connectedValues, attributeId)) { isSuccessful = false; } }
			}
			calculatorHelper.handleCovByCountryId(countryId);

		}, true, false);

		return isSuccessful;
	},

	handleCovByCountryId: function (countryId) {
		calculatorObject = calculatorHelper.getCalculatorByCalculatorTypeId(CalculatorType_E.COV);

		if (calculatorObject) {
			var sivPerSiteSelector = calculatorHelper.getControlSelector(calculatorObject.ControlPrefix, "sivPerSite");
			var visitFrequencySelector = calculatorHelper.getControlSelector(calculatorObject.ControlPrefix, "visitFrequency");

			if (_countryIds.Japan == countryId) {
				$(sivPerSiteSelector).show().removeClass("q_validation_error").attr("title", "");
				$(visitFrequencySelector).show().removeClass("q_validation_error").attr("title", "");
			}
			else {
				$(sivPerSiteSelector).hide().removeClass("q_validation_error").attr("title", "");
				$(visitFrequencySelector).hide().removeClass("q_validation_error").attr("title", "");

				if ($(sivPerSiteSelector).val() == "" && !calculatorHelper.isInMultiEditMode()) {
					$(sivPerSiteSelector).val("1");
				}
				if ($(visitFrequencySelector).val() == "" && !calculatorHelper.isInMultiEditMode()) {
					$(visitFrequencySelector).val("4");
				}
			}
		}
	},

	getFrequencyDateDetailsByCalculatorTypeId: function (siteSchedule, calculatorTypeId) {
		var frequencyDates;
		if (siteSchedule && siteSchedule.FrequencyDates) {
			$.each(siteSchedule.FrequencyDates, function (index, element) {
				if (element.CalculatorType == calculatorTypeId) {
					frequencyDates = element;
					return false;
				}
			});
		}
		return frequencyDates;
	},

	showStartStopDatesWithSource: function (controlPrefix, frequencyDateDetail) {
		var infoValue = "<b>Start Date:</b> " + frequencyDateDetail.StartDate +
		"<br /><b>Start Date Source:</b> " + frequencyDateDetail.StartDateSource +
		"<br /><b>Stop Date:</b> " + frequencyDateDetail.StopDate +
		"<br /><b>Stop Date Source:</b> " + frequencyDateDetail.StopDateSource;

		var iconSelector = calculatorHelper.getControlSelector(controlPrefix, "infoIcon");
		rm.qtip.showInfo(iconSelector, infoValue);
		$(iconSelector).removeClass("ui-iconHide");
	},

	handleEmptySite: function () {
		var nameSpace = calculatorGroup.monitoringCalculatorGroup;
		if (nameSpace) { nameSpace.handleEmptySite(); }

		nameSpace = calculatorGroup.pharmacyCalculatorGroup;
		if (nameSpace) { nameSpace.handleEmptySite(); }

		nameSpace = calculatorGroup.iCraCalculatorGroup;
		if (nameSpace) { nameSpace.handleEmptySite(); }

		var nameSpace = calculatorGroup.dteMonitoringCalculatorGroup;
		if (nameSpace) { nameSpace.handleEmptySite(); }

		nameSpace = calculatorGroup.dtePharmacyCalculatorGroup;
		if (nameSpace) { nameSpace.handleEmptySite(); }

	},

	hideInfoIcons: function (calcGroup) {
		if (calcGroup) {
			//Loop through all calculators and hode info icon
			for (var calcIndex = 0; calcIndex < calcGroup.Calculators.length; calcIndex++) {
				var iconSelector = calculatorHelper.getControlSelector(calcGroup.Calculators[calcIndex].ControlPrefix, "infoIcon");
				rm.qtip.showInfo(iconSelector, " ");
				$(iconSelector).addClass("ui-iconHide");
			}
		}
	},

	showInfoIcons: function (calcGroup, data) {
		if (calcGroup && data.FrequencyDates && data.FrequencyDates.length > 0) {
			//Loop through all calculators and show info icon and shoe start stop dates with their source
			for (var calcIndex = 0; calcIndex < calcGroup.Calculators.length; calcIndex++) {
				var calcDetails = calcGroup.Calculators[calcIndex];
				var frequencyDateDetail = calculatorHelper.getFrequencyDateDetailsByCalculatorTypeId(data, calcDetails.CalculatorTypeId);
				if (calcDetails.CalculatorTypeId != CalculatorType_E.AdHoc) {
					calculatorHelper.showStartStopDatesWithSource(calcDetails.ControlPrefix, frequencyDateDetail);
				}
				else {
					continue;
				}
			}
		}
	},

	handleSiteChange: function (siteId, projectId, countryId, requestId, resourceTypeId, pageManager, updateRequestTierValueFromSite, onAjaxComplete) {
		if (resourceTypeId == ResourceTypeName.Standard_Monitoring ||
				resourceTypeId == ResourceTypeName.Pharmacy_Monitoring ||
				resourceTypeId == ResourceTypeName.iCRA_Monitoring ||
				resourceTypeId == ResourceTypeName.DTESite_Monitoring ||
				resourceTypeId == ResourceTypeName.DTEPharmacy_Monitoring) {
			calculatorHelper.siteChanged = true;
			var calculatorGroupId = $("[id$=calculatorGroupId]").val();
			var postData = { calculatorGroupId: calculatorGroupId, siteId: siteId, projectId: projectId, countryId: countryId, requestId: requestId, resourceType: resourceTypeId };

			rm.ajax.calculatorSvcAsyncPost("GetSiteSchedule", postData, function (data) {
				calculatorHelper.covSiteVisitCount = data.NumberOfCovVisits;
				calculatorHelper.lastCovVisitDate = data.LastCovVisitDate;
				calculatorHelper.connectedStopDate = data.ConnectedStopDate;

				if (data.SiteSchedule.FrequencyDates && data.SiteSchedule.FrequencyDates.length > 0) {
					calculatorHelper.callHandleSiteChangeFromGroup(data.SiteSchedule);
				}
				if (pageManager) {
					var calculatorTypeId = (resourceTypeId == ResourceTypeName.Standard_Monitoring || resourceTypeId == ResourceTypeName.DTESite_Monitoring) ? CalculatorType_E.SS_SIV : CalculatorType_E.SIV;
					var frequencyRow = calculatorHelper.getFrequencyDateDetailsByCalculatorTypeId(data.SiteSchedule, calculatorTypeId);
					pageManager.SetRequestStartDateFromCalculatedSIVFrequencyDate(frequencyRow != undefined ? frequencyRow.StartDate : "", true);
				}
				if (onAjaxComplete) {
					onAjaxComplete();
				}

				if (data.SiteSchedule.HasError) {
					alert(data.SiteSchedule.ErrorMessage);
				}
			});
		}
	},
	setTiersFromSite: function (siteId, requestId, resourceTypeId, siteData) {
		if (resourceTypeId == ResourceTypeName.DTESite_Monitoring || resourceTypeId == ResourceTypeName.DTEPharmacy_Monitoring) {
			if (siteData && siteData.length > 0) {
				$.each(siteData, function (index, data) {
					if (data.SiteId == siteId) {
						var calcGroup = calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()];

						$.each(data.DefaultTierListByCalculatorTypeId, function (index, tierDetail) {
							$.each(calcGroup.Calculators, function (calcIndex, calc) {
								if (tierDetail.Key == calc.CalculatorTypeId) {
									$(calculatorHelper.getControlSelector(calc.ControlPrefix, "ddlTierLevel")).val(tierDetail.Value);
									setTimeout(function () { $(calculatorHelper.getControlSelector(calc.ControlPrefix, "ddlTierLevel")).change(); }, 10);
									return false;
								}
							});
						});

						return false;
					}
				});
			}
		}
	},
	callHandleSiteChangeFromGroup: function (data) {
		var nameSpace = calculatorGroup.monitoringCalculatorGroup;
		if (nameSpace) { nameSpace.handleSiteChange(data); }

		nameSpace = calculatorGroup.pharmacyCalculatorGroup;
		if (nameSpace) { nameSpace.handleSiteChange(data); }

		nameSpace = calculatorGroup.iCraCalculatorGroup;
		if (nameSpace) { nameSpace.handleSiteChange(data); }

		var nameSpace = calculatorGroup.dteMonitoringCalculatorGroup;
		if (nameSpace) { nameSpace.handleSiteChange(data); }

		nameSpace = calculatorGroup.dtePharmacyCalculatorGroup;
		if (nameSpace) { nameSpace.handleSiteChange(data); }
	},

	formatText: function (selector) {
		$(selector).bind('blur', function () { $.q.formatText(this); });
	},

	bindTextboxChange: function (selector, controlPrefix) {
		$(selector).bind('change', function () {
			$.q.formatText(this);
			calculatorHelper.onTextChange(selector, controlPrefix);
		});
	},

	onTextChange: function (selector, controlPrefix) {
		if ($(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val() == "1") {
			var isConnected = true;
			$.each($(selector), function (index, element) {
				var eleObj = $(element);
				//var elementValue = $.q.formatText(element, false);
				var elementValue = eleObj.val();
				//if proj is DTE and and if it is Freq1,Freq2 and pharmacy and if  it is only visit Frequency then do not compare the values.
				//if (!(calculatorHelper.isProjectDTE && (element.id.indexOf("Freq1") != -1 || element.id.indexOf("Freq2") != -1 || element.id.indexOf("Pharmacy_") != -1) && (element.id.toLowerCase().indexOf("visitfrequency") != -1)))
				//Changing logic to skip checking disables controls rather than looking for specific IDs
				if (eleObj.attr("disabled") != "disabled") {
					if (elementValue != eleObj.attr(calculatorHelper.conectedValAttr)) {
						isConnected = false;
						return false;
					}
				}
			});

			if (isConnected) {
				if (!calculatorHelper.isInMultiEditMode()) {
					calculatorHelper.showConnectedImage(controlPrefix);
					$(calculatorHelper.getControlSelector(controlPrefix, "isConnected")).val("1");

					////Update connect status back to connected for country calculators only when connect disconnect icons are present in the UI. 
					////Icons are not rendered when count calculator is already disconnected.
					//if (!calculatorHelper.isRequestCalculator() && $(calculatorHelper.getControlSelector(controlPrefix, "imgReConnect")).length > 0) {
					//	$(calculatorHelper.getControlSelector(controlPrefix, "isConnected")).val("1");
					//}
				}
			}
			else {
				$(calculatorHelper.getControlSelector(controlPrefix, "isConnected")).val("-1");
				calculatorHelper.showDisConnectedImage(controlPrefix);
			}
		}
	},

	bindTextManualChange: function (selector, controlPrefix) {
		$.each($(selector), function (index, element) {
			calculatorHelper.keyDownHandler(element, controlPrefix);
			calculatorHelper.mouseEventHandler(element, controlPrefix);
		});
	},

	keyDownHandler: function (element, controlPrefix) {
		$(element).bind("keydown", function (e) {
			//manual change detected on keys 0 to 9 period, backspace and delete
			if ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode == 190 || e.keyCode == 8 || e.keyCode == 46) {
				$(calculatorHelper.getControlSelector(controlPrefix, "connectedByImageClick")).val("-1");
				$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1");
			}
		});
	},

	mouseEventHandler: function (element, controlPrefix) {
		$(element).bind("paste cut drop", function (e) {
			$(calculatorHelper.getControlSelector(controlPrefix, "connectedByImageClick")).val("-1");
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1");
		});
	},

	tierChangeEvent: function (controlPrefix) {
		var element = $(calculatorHelper.getControlSelector(controlPrefix, "ddlTierLevel"))
		$(element).bind("change", function (e) {
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1");
		});
	},

	isConnected: function (controlPrefix) {
		return $(calculatorHelper.getControlSelector(controlPrefix, "isConnected")).val() == "1";
	},

	getCalculatorGroupByGroupId: function (calculatorIdJson, calculatorGroupId) {
		var requiredGroup = {};

		if (calculatorIdJson && calculatorIdJson.CalculatorGroups) {
			$.each(calculatorIdJson.CalculatorGroups, function (index, calcGroup) {
				if (calcGroup.CalculatorGroupId == calculatorGroupId && calcGroup.DmlOperation != DMLOperation_E.Delete) {
					requiredGroup = { calculatorGroup: calcGroup, groupIndex: index };
					return false;
				}
			});
		}

		return requiredGroup;
	},

	getCalculatorByControlPrefix: function (calcGroup, controlPrefix) {
		var requiredCalc;

		if (calcGroup && calculatorIdJson.CalculatorGroups) {
			$.each(calcGroup.Calculators, function (index, calc) {
				if (calc.ControlPrefix == controlPrefix) {
					requiredCalc = calc;
					return false;
				}
			});
		}

		return requiredCalc;
	},

	promptForConnectDisconnect: function (calculatorIdJson, selectedTabIndex) {
		var promptRequired = false;

		if (!calculatorHelper.isInMultiEditMode()) {
			var calcGroup = calculatorIdJson.CalculatorGroups[selectedTabIndex];
			$.each(calcGroup.Calculators, function (calcIndex, calc) {
				if (calculatorHelper.showConnectDisconnect(calc.ControlPrefix) && !calculatorHelper.wasImageClickedToConnect(calc.ControlPrefix) && calculatorHelper.isConnected(calc.ControlPrefix)) {
					promptRequired = true;
					return false;
				}
			});
		}

		return promptRequired;
	},

	hasCalculatorGroup: function (calculatorIdJson, calculatorGroupId) {
		var calcGroup = calculatorHelper.getCalculatorGroupByGroupId(calculatorIdJson, calculatorGroupId).calculatorGroup;
		return (calcGroup ? true : false);
	},

	isStopDateChangePromptRequired: function () {
		return calculatorHelper.selectedCountryId == _countryIds.Japan &&
			 calculatorHelper.isRequestCalculator() &&
			 calculatorHelper.isMonitoringCalculator() &&
			 (calculatorHelper.siteChanged ||
				calculatorHelper.isCovInfoChanged());
	},

	isCovInfoChanged: function () {
		var nameSpace = calculatorGroup.monitoringCalculatorGroup;
		return nameSpace != undefined && nameSpace.isCovInfoChanged(calculatorIdJson);
	},

	isMonitoringCalculator: function () {
		return CalculatorGroup_E.MonitoringCalculator == calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()].CalculatorGroupId;
	},

	isDTEMonitoringCalculator: function () {
		return CalculatorGroup_E.DTEMonitoringCalculator == calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()].CalculatorGroupId;
	},

	addCalculatorGroup: function (calculatorIdJson, calculatorGroupId, attributeId) {
		var postData = {
			calculatorGroupId: calculatorGroupId,
			monitoringAttrId: attributeId,
			visitSchemaLevelId: calculatorHelper.getVisitSchemaLevelId(),
			attributeIdList: calculatorHelper.getAttributeIdList()
		};

		var wsMethod = calculatorHelper.isInMultiEditMode() ? "AddCalculatorGroupToMultipleAttributes" : "RenderCalculatorGroup";
		var makeGetCall = !calculatorHelper.isInMultiEditMode();
		$.rm.Ajax_Calculator(wsMethod, postData, function (data) {
			rm.ui.messages.clearAllMessages();
			var tabInsertIndex = 0;
			var tabBodySelector = calculatorHelper.tabContainerSelector;

			if (data.GroupOrder != 0) {
				$.each(calculatorIdJson.CalculatorGroups, function (index, calcGroup) {
					//Find the tab body after which the new group should be added
					if (calcGroup.DmlOperation != DMLOperation_E.Delete) {
						if (data.GroupOrder > calcGroup.GroupOrder) {
							tabInsertIndex++;
							tabBodySelector = calcGroup.TabId;
						}

						if (data.GroupOrder <= calcGroup.GroupOrder) {
							return false;
						}
					}
				});
			}

			//Add html to as tab
			rm.ui.tabs.add(calculatorHelper.tabsSelector, data.TabId, data.TabText, data.GroupHtml, tabInsertIndex);
			rm.ui.tabs.activateByIndex(calculatorHelper.tabsSelector, tabInsertIndex);

			data.GroupHtml = ""; //html is not required after it is added to DOM
			calculatorHelper.addGroupToCalculatorDetailsJson(calculatorIdJson, data);
			setTimeout(function () {
				$("#tabs > div:visible").find("[id$=imgReConnect]").click(function () {
					calculatorHelper.handleConnectClick($(this).attr("controlPrefix"));
				});
			}, 10);

			rm.ui.messages.showSuccess((calculatorGroupId == CalculatorGroup_E.PharmacyCalculator || calculatorGroupId == CalculatorGroup_E.DTEPharmacyCalculator) ? Resources.PharmacyCalculatorAddSuccessful : Resources.IcraCalculatorAddSuccessful);
			calculatorHelper.bindDirtyToEntireForm(calculatorIdJson); //bind dirty again to prevent save prompt
			calculatorHelper.onAddGroupSuccess();
		}, makeGetCall, false);
	},

	isCalculatorValid: function (calculatorIdJson, selectedTabIndex) {
		var isValid = true;
		var calcGroup = calculatorIdJson.CalculatorGroups[selectedTabIndex];

		if (calculatorHelper.areAdhocDatesBeyondRequestStopDate()) { isValid = false; }

		$.each(calcGroup.Calculators, function (calcIndex, calculator) {
			var selector = calculatorHelper.getSelectorForRangeValidation(calculator.ControlPrefix);
			$.each($(selector), function (elementIndex, element) {
				if (!$.q.rangeValidate($(element))) {
					isValid = false;
				}
			});
		});

		return isValid;
	},

	saveCalculatorFromDialog: function (functionParams) {
		calculatorHelper.saveCalculatorToDb(functionParams.calculatorIdJson, functionParams.selectedTabIndex, functionParams.adhocCalcIdsToDelete);
	},

	saveCalculatorToDb: function (calculatorIdJson, selectedTabIndex, adhocCalcIdsToDelete) {
		var postData = { calculatorGroupData: calculatorHelper.getCalculatorGroupData(selectedTabIndex, adhocCalcIdsToDelete) };
		$.rm.Ajax_Calculator(calculatorHelper.isInMultiEditMode() ? "SaveMultipleCountryCalculators" : "SaveCalculator", postData, function (data) {
			if (data.ContainsValidationErrors) {
				if (calculatorHelper.isInMultiEditMode()) {
					calculatorHelper.handlSaveErrorResponseForMultiedit(data);
					calculatorHelper.bindDirtyToEntireForm(calculatorIdJson);
					return false;
				}
				else {
					var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
					if (data.ValidationErrors[0].Value == Resources.ProjectDetailsUpdated && $.inArray("source=monattr", hashes) != -1) {
						window.onbeforeunload = null;//to avoid ie showing warning message before navigation
						alert(data.ValidationErrors[0].Value);
						window.location.href = "/_Layouts/SPUI/profile/MonitoringAttributes.aspx";
						return false;
					}
				}
				rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
				$.validationHelper.ShowErrorMessages(data.ValidationErrors);
			}
			else {
				calculatorHelper.handlSaveResponse(data);
				if (isBackfillRequest) {
					alert("Please go back to Modify Submitted to update the original request's FTE appropriately.");
				}
				rm.ui.messages.showSuccess(Resources.AllDataSavedSuccessfully);
			}
		}, false, false);
	},

	handlSaveErrorResponseForMultiedit: function (response) {
		$.each(response.RequestExecutionStatus, function (index, item) {
			calculatorHelper.bindCalculatorDirty(item.AdditionalData.ControlPrefix); //clear dirty so that we don't save this calulator untill it is updated
		});

		var failedAttributeList = new Array();
		var htmlMessage = "<table class='validationTable'><tr class='headerRow'><td valign='top'>Validaton Error</td></tr>";
		$.each(response.ValidationErrors, function (index, message) {
			htmlMessage += "<tr><td>" + message.Value + "</td></tr>";
			failedAttributeList.push(message.Key);
		});
		htmlMessage += "</table>";
		rmCommon.showDialogWithOkButton("Unable to save some or all attributes", htmlMessage, function () { calculatorHelper.navigateBackToGrid(failedAttributeList); });
	},

	navigateBackToGrid: function (idList) {
		$.cookie("multiEditFailedAttributeIds", JSON.stringify(idList), { path: "/" });
		setTimeout(function () { calculatorGroup.close(calculatorHelper.getSource()); }, 50);
	},

	handlSaveResponse: function (data) {
		rm.ui.messages.clearAllMessages();
		var controlHtmlUpdated = false;
		$.each(data.RequestExecutionStatus, function (dataIndex, dataEle) {
			var additionalData = dataEle.AdditionalData;
			var calcGroup = calculatorHelper.getCalculatorGroupByGroupId(calculatorIdJson, additionalData.CalculatoGroupId).calculatorGroup;
			var calculator = calculatorHelper.getCalculatorByControlPrefix(calcGroup, additionalData.ControlPrefix);

			if (!controlHtmlUpdated) {
				$("#" + calcGroup.GroupPrefix).parent().find(".visitProjectionDiv").html(data.ControlHtml);
				controlHtmlUpdated = true;
			}
			if (calculator) {
				calculator.CalculatorId = additionalData.CalculatorId; //Update the calculator Id since it might have changed at server side because of connect/disconnect
				calculator.DmlOperation = DMLOperation_E.NoAction;
			}

			$(calculatorHelper.getControlSelector(additionalData.ControlPrefix, "calculatorId")).val(additionalData.CalculatorId); //update the value in hidden field
			$(calculatorHelper.getControlSelector(additionalData.ControlPrefix, "isChanged")).val("-1"); //update is change to -1 to indicate the there are no pending changes
			$(calculatorHelper.getControlSelector(additionalData.ControlPrefix, "dmlOperation")).val(DMLOperation_E.NoAction); //set DML operation to no action do that we don't insert/updat this calculator again
			calculatorHelper.updateTimeStamps(additionalData.ControlPrefix, additionalData.Timestamp);


			calculatorHelper.bindCalculatorDirty(additionalData.ControlPrefix); //clear dirty so that we don't save this calulator untill it is updated
			calculatorHelper.onSaveSuccessInternal();
		});
	},

	updateTimeStamps: function (controlPrefix, data) {
		if (data) {
			$(calculatorHelper.getControlSelector(controlPrefix, "countryLastModifiedOn")).val(calculatorHelper.getTimestampValue(data.CountryTimestamp));
			$(calculatorHelper.getControlSelector(controlPrefix, "countryCalculatorId")).val(calculatorHelper.getIdValue(data.CountryCalculatorId));
			$(calculatorHelper.getControlSelector(controlPrefix, "requestCalculatorLastModifiedOn")).val(calculatorHelper.getTimestampValue(data.RequestCalculatorTimestamp));
			$(calculatorHelper.getControlSelector(controlPrefix, "requestCalculatorId")).val(calculatorHelper.getIdValue(data.RequestCalculatorId));
		}
	},

	getTimestampValue: function (data) {
		return data ? data : 0;
	},

	getIdValue: function (data) {
		return data ? data : 0;
	},

	getCalculatorCount: function (calculatorIdJson, calculatorGroupId) {
		var calculatorCount = 0;
		var calcGroup = calculatorHelper.getCalculatorGroupByGroupId(calculatorIdJson, calculatorGroupId).calculatorGroup;

		if (calcGroup && calcGroup.Calculators) {
			calculatorCount = calcGroup.Calculators.length;
		}

		return calculatorCount;
	},

	getGroupContainerId: function (calculatorDetails, calculatorGroupId) {
		return calculatorHelper.getCalculatorGroupByGroupId(calculatorIdJson, calculatorGroupId).calculatorGroup.GroupPrefix;
	},

	hideCalculatorAndMarkDeleted: function (calcGroup, controlPrefix) {
		$("#" + controlPrefix).hide(); //hide control from DOM
		$(calculatorHelper.getControlSelector(controlPrefix, "dmlOperation")).val(DMLOperation_E.Delete);
		$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val() == "1";
		//Remove calculator from the group
		$.each(calcGroup.Calculators, function (index, calc) {
			if (calc.ControlPrefix == controlPrefix) {
				calc.DmlOperation = DMLOperation_E.Delete;
				return false;
			}
		});
	},

	removeCalculatorFromDomAndObjectModel: function (calcGroup, controlPrefix) {
		$("#" + controlPrefix).remove(); //remove control from DOM

		//Remove calculator from the group
		$.each(calcGroup.Calculators, function (index, calc) {
			if (calc.ControlPrefix == controlPrefix) {
				calcGroup.Calculators.splice(index, 1);
				return false;
			}
		});
	},

	removedDeletedCalculatorsFromDomAndJson: function (calculatorIdJson) {
		var calcGroup = calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()];
		var calculatorCount = calcGroup.Calculators.length;
		var controlPrefix;

		for (var index = calculatorCount - 1; index > 0; index--) {
			controlPrefix = calcGroup.Calculators[index].ControlPrefix;
			if (calcGroup.Calculators[index].DmlOperation == DMLOperation_E.Delete) {
				$("#" + controlPrefix).remove(); //remove calculator from dom
				calcGroup.Calculators.splice(index, 1); //remove calculator from Json
			}
			else if ($(calculatorHelper.getControlSelector(controlPrefix, "calculatorTypeId")).val() == CalculatorType_E.AdHoc) {
				$(calculatorHelper.getControlSelector(controlPrefix, "originalStartDate")).val($(calculatorHelper.getControlSelector(controlPrefix, "startDate")).val());
			}
		}
	},

	removeCalculator: function (calculatorDetails, calculatorGroupId, controlPrefix) {
		if (confirm(Resources.ConfirmDeleteFrequency)) {
			var calcGroup = calculatorHelper.getCalculatorGroupByGroupId(calculatorIdJson, calculatorGroupId).calculatorGroup;
			var calc = calculatorHelper.getCalculatorByControlPrefix(calcGroup, controlPrefix);
			var calculatorId = $(calculatorHelper.getControlSelector(controlPrefix, "calculatorId")).val();
			if (calculatorId <= 0) {
				calculatorHelper.removeCalculatorFromDomAndObjectModel(calcGroup, controlPrefix);
			}
			else {
				calculatorHelper.hideCalculatorAndMarkDeleted(calcGroup, controlPrefix);
				calculatorHelper.onDeleteAdhocClick();
			}
		}
	},

	addCalculatorToDetailsJson: function (calculatorDetails, calculatorGroupId, calculatorToAdd) {
		var calcGroup = calculatorHelper.getCalculatorGroupByGroupId(calculatorIdJson, calculatorGroupId).calculatorGroup;

		calculatorToAdd.DmlOperation = DMLOperation_E.Insert;
		calcGroup.Calculators.push(calculatorToAdd);
		$("#" + calculatorToAdd.ControlPrefix + " input[type=text]:visible:first").focus();
	},

	removeCalculatorGroup: function (calculatorIdJson, calculatorGroupId, attributeId, attributeTypeId) {
		if (confirm(Resources.CalculatorGroupRemoveConfirm)) {
			var postData = {
				calculatorGroup: calculatorGroupId,
				attributeType: attributeTypeId,
				attributeId: attributeId,
				attributeIdList: calculatorHelper.getAttributeIdList()
			};

			var wsMethodName = calculatorHelper.isInMultiEditMode() ? "RemoveCalculatorGroupFromMultipleAttributes" : "RemoveCalculatorGroup";
			$.rm.Ajax_Calculator(wsMethodName, postData, function (data) {
				if (data.ContainsValidationErrors) {
					if (calculatorHelper.isInMultiEditMode()) {
						calculatorHelper.handleRemoveCalculatorGroupErrorResponseForMultiedit(data);
					}
					else {
						$.validationHelper.ShowErrorMessages(data.ValidationErrors);
					}
				}
				else {
					$.each(calculatorIdJson.CalculatorGroups, function (index, calcGroup) {
						if (calcGroup.CalculatorGroupId == calculatorGroupId) {
							calculatorIdJson.CalculatorGroups.splice(index, 1);

							var tabIndex = $(calcGroup.TabId).index() - 1;
							rm.ui.tabs.removeByIndex(calculatorHelper.tabsSelector, tabIndex);

							return false;
						}
					});
					rm.ui.messages.showSuccess((calculatorGroupId == CalculatorGroup_E.PharmacyCalculator || calculatorGroupId == CalculatorGroup_E.DTEPharmacyCalculator) ? Resources.PharmacyCalculatorRemoveSuccessful : Resources.IcraCalculatorRemoveSuccessful);
					calculatorHelper.onRemoveGroupSuccess();
				}
			}, false, false);
		}
	},

	handleRemoveCalculatorGroupErrorResponseForMultiedit: function (response) {
		var failedAttributeList = new Array();
		var htmlMessage = "<table class='validationTable'><tr class='headerRow'><td>Attribute Id</td><td valign='top'>Validaton Error</td></tr>";
		$.each(response.ValidationErrors, function (index, message) {
			htmlMessage += "<tr><td>" + message.Key + "</td><td>" + message.Value + "</td></tr>";
			failedAttributeList.push(message.Key);
		});
		htmlMessage += "</table>";
		rmCommon.showDialogWithOkButton("Unable to remove calculator for some or all attributes", htmlMessage, function () { calculatorHelper.navigateBackToGrid(failedAttributeList); });
	},

	addGroupToCalculatorDetailsJson: function (calculatorDetails, groupDetails) {
		var insertIndex = 0;
		if (groupDetails.GroupOrder != 0) {
			$.each(calculatorIdJson.CalculatorGroups, function (index, calcGroup) {
				//Find the tab body after which the new group should be added
				if (groupDetails.GroupOrder > calcGroup.GroupOrder) {
					insertIndex++;
				}

				if (groupDetails.GroupOrder <= calcGroup.GroupOrder) {
					return false;
				}
			});
		}

		calculatorIdJson.CalculatorGroups.splice(insertIndex, 0, groupDetails);
	},

	isCalculatorDirty: function (controlPrefix) {
		return ($.formStatus.isDirty({ items: [{ selector: calculatorHelper.getSelectorForRangeValidation(controlPrefix) }] }) ||
				$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val() == "1");
	},

	bindDirtyToEntireForm: function (calculatorIdJson) {
		$.each(calculatorIdJson.CalculatorGroups, function (index, calcGroup) {
			$.each(calcGroup.Calculators, function (calcIndex, calc) {
				calculatorHelper.bindCalculatorDirty(calc.ControlPrefix);
			});
		});
	},

	bindCalculatorDirty: function (controlPrefix) {
		$.formStatus.clearDirty({ items: [{ selector: "[id*=" + controlPrefix + "]" }] });
		$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("-1");
	},
	//preventQipConnect: function (calculatorIdJson, selectedTabIndex) {
	//	if (!calculatorHelper.isRequestCalculator()) {
	//		var calcGroupObject = calculatorIdJson.CalculatorGroups[selectedTabIndex];
	//		if (calcGroupObject) {
	//			for (var calcIndex = 0; calcIndex < calcGroupObject.Calculators.length; calcIndex++) {
	//				var calculatorDetails = calcGroupObject.Calculators[calcIndex];
	//				if ($(calculatorHelper.getControlSelector(calculatorDetails.ControlPrefix, "imgReConnect")).is(":visible")) {
	//					$(calculatorHelper.getControlSelector(calculatorDetails.ControlPrefix, "imgConnect")).remove();
	//					$(calculatorHelper.getControlSelector(calculatorDetails.ControlPrefix, "imgReConnect")).remove();
	//				}
	//			}
	//		}
	//	}
	//},
	getAdhocCalculatorIds: function () {
		var idArray = new Array();
		if (typeof (calculatorIdJson) != "undefined") {
			var caclGroup = calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()];

			if (caclGroup) {
				$.each(caclGroup.Calculators, function (index, calc) {
					//Do not include new adhoc calculators
					if (calc.CalculatorTypeId == CalculatorType_E.AdHoc && calc.CalculatorId > 0) {
						idArray.push(calc.CalculatorId);
					}
				});
			}
		}

		return idArray;
	},

	getDmlOperation: function (calculatorDetails) {
		var dmlOperation = $(calculatorHelper.getControlSelector(calculatorDetails.ControlPrefix, "dmlOperation")).val();
		return (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Delete) ?
			dmlOperation :
								calculatorHelper.isCalculatorDirty(calculatorDetails.ControlPrefix) ?
												DMLOperation_E.Update : DMLOperation_E.NoAction;
	},

	getCommonPostData: function (controlPrefix) {
		return ({
			CalculatorId: $(calculatorHelper.getControlSelector(controlPrefix, "calculatorId")).val(),
			IsConnected: calculatorHelper.isConnected(controlPrefix),
			ControlPrefix_WS: controlPrefix,
			ShowConnectDisconnect: calculatorHelper.showConnectDisconnect(controlPrefix),
			IsRequestCalculator: calculatorHelper.isRequestCalculator(),
			IsNewRequest: calculatorHelper.isNewRequest(),
			RequestId: calculatorHelper.getRequestId(),
			SsvAttributeId: calculatorHelper.getSsvAttributeId(),
			MonitoringAttributeId: calculatorHelper.getMonitoringAttributeId(),
			IsIndependentCalculator: calculatorHelper.isIndependentCalculator(),
			CalculatorGroup: calculatorHelper.getCalculatorGroupId(controlPrefix),
			CalculatorType: calculatorHelper.getCalculatorTypeId(controlPrefix),
			IsCountryChanged: calculatorHelper.getIsCountryChanged()
		});
	},

	getAdhocDeletePostData: function (calculatorIdToDelete) {
		return ({
			CalculatorId: calculatorIdToDelete,
			IsRequestCalculator: calculatorHelper.isRequestCalculator(),
			IsNewRequest: calculatorHelper.isNewRequest(),
			RequestId: calculatorHelper.getRequestId(),
			SsvAttributeId: calculatorHelper.getSsvAttributeId(),
			MonitoringAttributeId: calculatorHelper.getMonitoringAttributeId(),
			IsIndependentCalculator: calculatorHelper.isIndependentCalculator(),
			CalculatorGroup: calculatorGroup.getCalculatorGroupIdForCurrentTab(),
			CalculatorType: CalculatorType_E.AdHoc,
			DmlOperation: DMLOperation_E.Delete,
			IsCountryChanged: calculatorHelper.getIsCountryChanged()
		});
	},

	getCalculatorEventData: function () {
		var isAddingNew = true;
		var includeUnchangedValues = true;
		var selectedTabIndex = calculatorHelper.getSelectedTabIndex();
		var adhocCalcIdsToDelete = new Array();
		var calculatorData = null;

		var nameSpace = calculatorGroup.monitoringCalculatorGroup;
		if (nameSpace) { calculatorData = nameSpace.getMonitoringCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, includeUnchangedValues); }

		nameSpace = calculatorGroup.pharmacyCalculatorGroup;
		if (nameSpace) { calculatorData = nameSpace.getPharmacyCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, includeUnchangedValues); }

		nameSpace = calculatorGroup.iCraCalculatorGroup;
		if (nameSpace) { calculatorData = nameSpace.getICraCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, includeUnchangedValues); }

		nameSpace = calculatorGroup.ssvCalculatorGroup;
		if (nameSpace) { calculatorData = nameSpace.getSsvCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, includeUnchangedValues); }

		nameSpace = calculatorGroup.initiateCalculatorGroup;
		if (nameSpace) { calculatorData = nameSpace.getInitiateCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, includeUnchangedValues); }

		var nameSpace = calculatorGroup.dteMonitoringCalculatorGroup;
		if (nameSpace) { calculatorData = nameSpace.getDteMonitoringCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, includeUnchangedValues); }

		nameSpace = calculatorGroup.dtePharmacyCalculatorGroup;
		if (nameSpace) { calculatorData = nameSpace.getDtePharmacyCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, includeUnchangedValues); }

		nameSpace = calculatorGroup.monitoringSiteSpecificCalculatorGroup;
		if (nameSpace) { calculatorData = nameSpace.getMonitoringSiteSpecificCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, includeUnchangedValues); }

		return {
			covSiteVisitCount: calculatorHelper.covSiteVisitCount,
			lastCovVisitDate: calculatorHelper.lastCovVisitDate,
			connectedStopDate: calculatorHelper.connectedStopDate,
			calculatorGroupData: calculatorData
		};
	},

	getCalculatorGroupData: function (selectedTabIndex, isAddingNew, adhocCalcIdsToDelete) {
		var calculatorGroupData = {
			RequestId: calculatorHelper.getRequestId(),
			AttributeId: calculatorHelper.getAttributeId(),
			AttributeTypeId: calculatorHelper.getAttributeTypeId(),
			IsNewRequest: calculatorHelper.isNewRequest(),
			IsRequestCalculator: calculatorHelper.isRequestCalculator(),
			MonitoringCalculatorGroup: calculatorHelper.getMonitoringCalculatorGroupData(selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, false),
			PharmacyCalculatorGroup: calculatorHelper.getPharmacyCalculatorGroupData(selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, false),
			ICraCalculatorGroup: calculatorHelper.getICraCalculatorGroupData(selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, false),
			SsvCalculatorGroup: calculatorHelper.getSsvCalculatorGroupData(selectedTabIndex, isAddingNew),
			InitiateCalculatorGroup: calculatorHelper.getInitiateCalculatorGroupData(selectedTabIndex, isAddingNew),
			MonitoringSiteSpecificCalculatorGroup: calculatorHelper.getMonitoringSiteSpecificCalculatorGroupData(selectedTabIndex, isAddingNew),
			DteMonitoringCalculatorGroup: calculatorHelper.getDteMonitoringCalculatorGroupData(selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, false),
			DtePharmacyCalculatorGroup: calculatorHelper.getDtePharmacyCalculatorGroupData(selectedTabIndex, isAddingNew, adhocCalcIdsToDelete, false),
			ProjectDteType: calculatorHelper.getProjectDteTypeId(),
			VisitSchemaLevelId: calculatorHelper.getVisitSchemaLevelId(),
			ProjectId: calculatorHelper.getProjectId(),
			DataChangeValidationRequired: calculatorHelper.DataChangeValidationRequired(),
			AttributeIds: calculatorHelper.getAttributeIdList()
		};

		return calculatorGroupData;
	},

	getAdhocCalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (isAddingNew) {
				if (dmlOperation == DMLOperation_E.Delete) {
					dmlOperation = DMLOperation_E.NoAction;
				}
				else {
					dmlOperation = DMLOperation_E.Insert;
				}
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || dmlOperation == DMLOperation_E.Delete || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					StartDate: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "startDate"),
					StopDate: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "stopDate"),
					Comment: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "comment"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getAdhocCalculatorsToDelete: function (adhocCalcIdsToDelete) {
		var adhocDeleteData = new Array();
		if (adhocCalcIdsToDelete && adhocCalcIdsToDelete.length) {
			$.each(adhocCalcIdsToDelete, function (index, element) {
				adhocDeleteData.push(calculatorHelper.getAdhocDeletePostData(element));
			});
		}
		return adhocDeleteData;
	},

	getCovCalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,

					SivPerSite: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "sivPerSite"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getDblCovCalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getFsiCovCalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte"),
					RequestTierLevel: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "ddlTierLevel")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getFreq1CalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte"),
					RequestTierLevel: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "ddlTierLevel")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getFreq2CalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte"),
					RequestTierLevel: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "ddlTierLevel")
				});

				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}

		return calcData;
	},

	getFreq3CalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					PhoneSivPerSite: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneSivPerSite"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getLSOCOVCalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					PhoneSivPerSite: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneSivPerSite"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte"),
					RequestTierLevel: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "ddlTierLevel")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getFreq4CalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					PhoneSivPerSite: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneSivPerSite"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getPharmacyCalculatorData: function (calculatorDetails, isAddingNew, includeUnchangedValues) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update || includeUnchangedValues) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					CalculatorId: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "calculatorId"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte"),
					RequestTierLevel: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "ddlTierLevel")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getSivCalculatorData: function (calculatorDetails, isAddingNew) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update) {
				calcData = ({
					DmlOperation: dmlOperation,
					SivPerSite: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "sivPerSite"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneSivPerSite: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneSivPerSite"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},
	getSsSivCalculatorData: function (calculatorDetails, isAddingNew) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},
	getSivFsiCalculatorData: function (calculatorDetails, isAddingNew) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update) {
				calcData = ({
					DmlOperation: dmlOperation,
					AdminTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "adminTime")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getSsvCalculatorData: function (calculatorDetails, isAddingNew) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (calculatorHelper.overrideDmlOperation(calculatorDetails.ControlPrefix, isAddingNew)) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update) {
				calcData = ({
					DmlOperation: dmlOperation,
					SsvPerSite: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "ssvPerSite"),
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PhoneSsvPerSite: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneSsvPerSite"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					PhoneVisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitFrequency"),
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte"),
					OnSiteNumberOfSites: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onsiteNumberOfSites"),
					PhoneNumberOfSites: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneNumberOfSites"),

				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getOnSiteVisitCalculatorData: function (calculatorDetails, isAddingNew) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (isAddingNew) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update) {
				calcData = ({
					DmlOperation: dmlOperation,
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getMonitoringSiteSpecificCalculatorData: function (calculatorDetails, isAddingNew) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (isAddingNew) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update) {
				calcData = ({
					DmlOperation: dmlOperation,
					VisitFrequency: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "visitFrequency"),
					ClusterTravelTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "travelTimeCluster"),
					OnSiteTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "onSiteTime"),
					PrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "prepFollowUpTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
				calcData.IsConnected = false;
			}
		}
		return calcData;
	},

	getPhoneVisitCalculatorData: function (calculatorDetails, isAddingNew) {
		var calcData = null;
		if (calculatorDetails) {
			var dmlOperation = calculatorHelper.getDmlOperation(calculatorDetails);
			if (isAddingNew) {
				dmlOperation = DMLOperation_E.Insert;
			}
			if (dmlOperation == DMLOperation_E.Insert || dmlOperation == DMLOperation_E.Update) {
				calcData = ({
					DmlOperation: dmlOperation,
					PhoneVisitTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneVisitTime"),
					PhonePrepFollowUpTime: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phonePrepFollowUpTime"),
					Fte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "fte"),
					PhoneFte: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "phoneFte")
				});
				$.extend(calcData, calculatorHelper.getCommonPostData(calculatorDetails.ControlPrefix));
			}
		}
		return calcData;
	},

	getTimestampData: function (calculatorDetails) {
		var timestampData = null;
		if (calculatorDetails) {
			timestampData = {
				CountryTimestamp: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "countryLastModifiedOn"),
				CountryCalculatorId: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "countryCalculatorId"),
				RequestCalculatorTimestamp: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "requestCalculatorLastModifiedOn"),
				RequestCalculatorId: calculatorHelper.getControlValueOrNullIfBlank(calculatorDetails.ControlPrefix, "requestCalculatorId")
			};

			timestampData.CountryTimestamp = timestampData.CountryTimestamp == 0 ? null : timestampData.CountryTimestamp;
			timestampData.CountryCalculatorId = timestampData.CountryCalculatorId == 0 ? null : timestampData.CountryCalculatorId;
			timestampData.RequestCalculatorTimestamp = timestampData.RequestCalculatorTimestamp == 0 ? null : timestampData.RequestCalculatorTimestamp;
			timestampData.RequestCalculatorId = timestampData.RequestCalculatorId == 0 ? null : timestampData.RequestCalculatorId;
		}
		return timestampData;
	},

	//note that we cannot handle adhoc connected values
	getConnectedValueByCalculatorTypeIdAndGroupId: function (connectedValues, calculatorTypeId, calculatorGroupId) {
		var connectedValue;
		$.each(connectedValues, function (index, val) {
			if (val.CalculatorType == calculatorTypeId && val.CalculatorGroup == calculatorGroupId) {
				connectedValue = val;
				return false;
			}
		});

		return connectedValue;
	},

	getAdhocPreviousValueByCalculatorId: function (previousValues, calculatorId) {
		var previousValue;
		$.each(previousValues, function (index, val) {
			if (val.CalculatorId == calculatorId) {
				previousValue = val;
				return false;
			}
		});

		return previousValue;
	},
	mapSsvCalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "ssvPerSite", connectedValue.SsvPerSite);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneSsvPerSite", connectedValue.PhoneSsvPerSite);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitFrequency", connectedValue.PhoneVisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapSivCalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "sivPerSite", connectedValue.SivPerSite);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneSivPerSite", connectedValue.PhoneSivPerSite);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitFrequency", connectedValue.PhoneVisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},
	mapSsSivCalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},
	mapSivFsiCalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapDblCovCalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapCovCalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "sivPerSite", connectedValue.SivPerSite);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapPharmacyCalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitFrequency", connectedValue.PhoneVisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapFsiCovCalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitFrequency", connectedValue.PhoneVisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapFreq1CalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitFrequency", connectedValue.PhoneVisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapFreq2CalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitFrequency", connectedValue.PhoneVisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapFreq3CalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitFrequency", connectedValue.PhoneVisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	mapFreq4CalculatorConnectedValues: function (controlPrefix, connectedValue) {
		var isSuccessful = false;
		if (connectedValue) {
			calculatorHelper.updateFrequencyHeader(controlPrefix, connectedValue);
			calculatorHelper.setConnectedValue(controlPrefix, "adminTime", connectedValue.AdminTime);
			calculatorHelper.setConnectedValue(controlPrefix, "visitFrequency", connectedValue.VisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "travelTimeCluster", connectedValue.ClusterTravelTime);
			calculatorHelper.setConnectedValue(controlPrefix, "onSiteTime", connectedValue.OnSiteTime);
			calculatorHelper.setConnectedValue(controlPrefix, "prepFollowUpTime", connectedValue.PrepFollowUpTime);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitFrequency", connectedValue.PhoneVisitFrequency);
			calculatorHelper.setConnectedValue(controlPrefix, "phoneVisitTime", connectedValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1"); //Set is changed to 1 so that the data is sent to server even if just attribute is changed
			isSuccessful = true;
		}
		return isSuccessful;
	},

	getMonitoringCalculatorGroupData: function (selectedTabIndex, isAddingNew, adhocCalcIdsToDelete) {
		var monitoringCalculatorGroupData = null;
		var mcNameSpace = calculatorGroup.monitoringCalculatorGroup;

		if (mcNameSpace) {
			monitoringCalculatorGroupData = mcNameSpace.getMonitoringCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete);
		}

		return monitoringCalculatorGroupData;
	},

	getPharmacyCalculatorGroupData: function (selectedTabIndex, isAddingNew, adhocCalcIdsToDelete) {
		var pharmacyCalculatorGroupData = null;
		var pcNameSpace = calculatorGroup.pharmacyCalculatorGroup;

		if (pcNameSpace) {
			pharmacyCalculatorGroupData = pcNameSpace.getPharmacyCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete);
		}

		return pharmacyCalculatorGroupData;
	},

	getICraCalculatorGroupData: function (selectedTabIndex, isAddingNew, adhocCalcIdsToDelete) {
		var iCraCalculatorGroupData = null;
		var icNameSpace = calculatorGroup.iCraCalculatorGroup;

		if (icNameSpace) {
			iCraCalculatorGroupData = icNameSpace.getICraCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete);
		}

		return iCraCalculatorGroupData;
	},

	getDteMonitoringCalculatorGroupData: function (selectedTabIndex, isAddingNew, adhocCalcIdsToDelete) {
		var monitoringCalculatorGroupData = null;
		var mcNameSpace = calculatorGroup.dteMonitoringCalculatorGroup;

		if (mcNameSpace) {
			monitoringCalculatorGroupData = mcNameSpace.getDteMonitoringCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete);
		}

		return monitoringCalculatorGroupData;
	},

	getDtePharmacyCalculatorGroupData: function (selectedTabIndex, isAddingNew, adhocCalcIdsToDelete) {
		var pharmacyCalculatorGroupData = null;
		var pcNameSpace = calculatorGroup.dtePharmacyCalculatorGroup;

		if (pcNameSpace) {
			pharmacyCalculatorGroupData = pcNameSpace.getDtePharmacyCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew, adhocCalcIdsToDelete);
		}

		return pharmacyCalculatorGroupData;
	},

	getSsvCalculatorGroupData: function (selectedTabIndex, isAddingNew) {
		var ssvCalculatorGroupData = null;
		var scNameSpace = calculatorGroup.ssvCalculatorGroup;

		if (scNameSpace) {
			ssvCalculatorGroupData = scNameSpace.getSsvCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew);
		}

		return ssvCalculatorGroupData;
	},

	getInitiateCalculatorGroupData: function (selectedTabIndex, isAddingNew) {
		var initiateCalculatorGroupData = null;
		var icNameSpace = calculatorGroup.initiateCalculatorGroup;

		if (icNameSpace) {
			initiateCalculatorGroupData = icNameSpace.getInitiateCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew);
		}

		return initiateCalculatorGroupData;
	},

	getMonitoringSiteSpecificCalculatorGroupData: function (selectedTabIndex, isAddingNew) {
		var monitoringSiteSpecificCalculatorGroupData = null;
		var sscNameSpace = calculatorGroup.monitoringSiteSpecificCalculatorGroup;

		if (sscNameSpace) {
			monitoringSiteSpecificCalculatorGroupData = sscNameSpace.getMonitoringSiteSpecificCalculatorGroupData(calculatorIdJson, selectedTabIndex, isAddingNew);
		}

		return monitoringSiteSpecificCalculatorGroupData;
	},

	showPreviousValuesInUi: function (controlPrefix, previousValue) {
		var isSuccessful = false;
		if (previousValue) {
			$(calculatorHelper.getControlSelector(controlPrefix, "old_fte")).html(previousValue.Fte);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_sivPerSite")).html(previousValue.SivPerSite);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_ssvPerSite")).html(previousValue.SsvPerSite);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_adminTime")).html(previousValue.AdminTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_visitFrequency")).html(previousValue.VisitFrequency);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_travelTimeCluster")).html(previousValue.ClusterTravelTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_onSiteTime")).html(previousValue.OnSiteTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_prepFollowUpTime")).html(previousValue.PrepFollowUpTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_phoneSsvPerSite")).html(previousValue.PhoneSsvPerSite);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_phoneSivPerSite")).html(previousValue.PhoneSivPerSite);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_phoneVisitFrequency")).html(previousValue.PhoneVisitFrequency);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_phoneVisitTime")).html(previousValue.PhoneVisitTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_phonePrepFollowUpTime")).html(previousValue.PhonePrepFollowUpTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_phoneFte")).html(previousValue.PhoneFte);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_divTotalHours")).html(previousValue.ClusterTravelTime + previousValue.OnSiteTime + previousValue.PrepFollowUpTime);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_monitoringSiteSpecific")).html(previousValue.MonitoringSiteSpecific);

			$(calculatorHelper.getControlSelector(controlPrefix, "old_onsiteNumberOfSites")).html(previousValue.OnSiteNumberOfSites);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_phoneNumberOfSites")).html(previousValue.PhoneNumberOfSites);
			$(calculatorHelper.getControlSelector(controlPrefix, "old_totalNumberOfSites")).html(previousValue.OnSiteNumberOfSites + previousValue.PhoneNumberOfSites);
			isSuccessful = true;
		}
		return isSuccessful;
	},

	getTargetUtilization: function () {
		var targetUtilization = 0.85;
		if (calculatorHelper.countryResourceTypeUtilization[calculatorHelper.selectedCountryId] && calculatorHelper.countryResourceTypeUtilization[calculatorHelper.selectedCountryId][calculatorHelper.selectedResourceTypeId]) {
			targetUtilization = calculatorHelper.countryResourceTypeUtilization[calculatorHelper.selectedCountryId][calculatorHelper.selectedResourceTypeId];
		}
		else {
			//$.rm.Ajax_Utility("GetResourceTypeCountryTargetUtilization", { countryId: calculatorHelper.selectedCountryId }, function (data)
			//{
			//	calculatorHelper.countryResourceTypeUtilization[data.CountryId] = {};

			//	$.each(data.ResourceTypeUtilizationList, function (index, value)
			//	{
			//		if (!calculatorHelper.countryResourceTypeUtilization[data.CountryId])
			//		{
			//			calculatorHelper.countryResourceTypeUtilization[data.CountryId] = {};
			//		}
			//		calculatorHelper.countryResourceTypeUtilization[data.CountryId][value.Key] = value.Value
			//		if (value.Key == calculatorHelper.selectedResourceTypeId)
			//		{
			//			targetUtilization = value.Value * 1;
			//		}
			//	});
			//}, true, false);
		}
		return targetUtilization;
	},

	handleConnectClick: function (controlPrefix) {
		var currentFrequency = $.grep(calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()].Calculators, function (obj) {
			return obj.CalculatorTypeId == $(calculatorHelper.getControlSelector(controlPrefix, "calculatorTypeId")).val();
		});
		if (calculatorHelper.isInMultiEditMode()) {
			calculatorHelper.showConnectedImage(controlPrefix);
			calculatorHelper.imageClickedToConnect(controlPrefix);
			$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1");
			setTimeout(function () { calculatorHelper.onConnectImageClick(); }, calculatorHelper.timeoutInterval);
		}
		else if (calculatorHelper.isRequestCalculator() || (!calculatorHelper.isRequestCalculator() && currentFrequency[0].HasQipCalculator)) {
			if (confirm(calculatorHelper.isRequestCalculator() ? Resources.ConfirmOnConnectToCountryClick : Resources.ConfirmOnConnectToQipClick)) {
				calculatorGroup.showConnectedValues(controlPrefix);
				calculatorHelper.showConnectedImage(controlPrefix);
				calculatorHelper.imageClickedToConnect(controlPrefix);
				$(calculatorHelper.getControlSelector(controlPrefix, "isChanged")).val("1");
				setTimeout(function () { calculatorHelper.onConnectImageClick(); }, calculatorHelper.timeoutInterval);
			}
		}
		else {
			alert(Resources.NoQipCalculatorAlert);
		}
	},
	isCurrentAdhocDateBeyondRequestStopDate: function () {
		var areDatesBeyondRequestStop = false;
		if (calculatorHelper.isRequestCalculator() && !calculatorHelper.isInMultiEditMode()) {
			var requestStopQDateString = calculatorHelper.getRequestStopDateFromUi();

			if (rm.date.isValidDate(requestStopQDateString, false)) {
				var requestStopDate = rm.date.getDateFromQDateString(requestStopQDateString);

				var stopDate = rm.date.getDateFromQDateString($("#txtAdhocStopDate").val());
				if (stopDate > requestStopDate) {
					areDatesBeyondRequestStop = true;
					rm.validation.addError($("#txtAdhocStopDate"), Resources.RequestStopDateBeforeAdhocStop.replace("{0}", requestStopQDateString));
				}
			}

		} return areDatesBeyondRequestStop;
	},
	areAdhocDatesBeyondRequestStopDate: function () {
		var areDatesBeyondRequestStop = false;
		if (calculatorHelper.isRequestCalculator() && !calculatorHelper.isInMultiEditMode()) {
			var requestStopQDateString = calculatorHelper.getRequestStopDateFromUi();

			if (rm.date.isValidDate(requestStopQDateString, false)) {
				var requestStopDate = rm.date.getDateFromQDateString(requestStopQDateString);
				var calculators = calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()].Calculators;

				$.each(calculators, function (index, calculator) {
					if (calculator.CalculatorTypeId == CalculatorType_E.AdHoc && calculator.DmlOperation != DMLOperation_E.Delete) {
						var currentAdhocStopDate = rm.date.getDateFromQDateString($(calculatorHelper.getControlSelector(calculator.ControlPrefix, "stopDate")).val());
						if (currentAdhocStopDate > requestStopDate) {
							rm.validation.addError($(calculatorHelper.getControlSelector(calculator.ControlPrefix, "hlAdhocDates")), Resources.RequestStopDateBeforeAdhocStop.replace("{0}", requestStopQDateString));
							areDatesBeyondRequestStop = true;
						}
						else { rm.validation.clearError($(calculatorHelper.getControlSelector(calculator.ControlPrefix, "hlAdhocDates"))); }
					}
				});
			}
		}
		return areDatesBeyondRequestStop;
	},
	clearAdhocStopDateError: function () {
		var adhocDates = $(".fteCalculatorTable [id$=_hlAdhocDates]");
		$.each(adhocDates, function (index, ele) {
			rm.validation.clearError($(ele));
			rm.validation.clearError($(ele).parent());
		});
	}
};

var calculatorGroup =
{
	countryWeeklyHours: -1,
	showConnectedValues: function (controlPrefix) {
		$("[type=text][id*=" + controlPrefix + "][" + calculatorHelper.conectedValAttr + "]").each(function (index, item) {
			jqItem = $(item);
			var tId = jqItem[0].id;
			//if proj is DTE and and if it is Freq1,Freq2 and pharmacy and if  it is only visit Frequency then do not set the value.
			if (!(calculatorHelper.isDteProject() && (tId.indexOf("Freq1") != -1 || tId.indexOf("Freq2") != -1 || tId.indexOf("Pharmacy_") != -1) && (tId.toLowerCase().indexOf("visitfrequency") != -1))) {
				jqItem.val(jqItem.attr(calculatorHelper.conectedValAttr));
			}
			rm.validation.clearError(jqItem);
		});
	},

	calculatorRedrawnAfterCountryChange: function (countryId, onNoCalculatorFound, onCalculatorFound) {
		calculatorHelper.setIsCountryChanged();
		var selectedTabIndex = calculatorHelper.getSelectedTabIndex();

		if (selectedTabIndex >= 0) {
			var caclGroup = calculatorIdJson.CalculatorGroups[selectedTabIndex];

			$.each(caclGroup.Calculators, function (index, calc) {
				$(calculatorHelper.getControlSelector(calc.ControlPrefix, "isChanged")).val("1");
			});

			if (typeof onCalculatorFound === "function") {
				onCalculatorFound();
			}
		}
		else {
			if (typeof onNoCalculatorFound === "function") {
				onNoCalculatorFound();
			}
			else {
				alert(Resources.NoCalculatorDataFound);
			}
		}

		if (countryId) {
			calculatorHelper.handleCovByCountryId(countryId);
		}
	},

	addAdhocCalculatorToCurrentTab: function () {
		calculatorGroup.addAdhocCalculator(calculatorGroup.getCalculatorGroupIdForCurrentTab());
	},

	getCalculatorGroupIdForCurrentTab: function () {
		return calculatorIdJson.CalculatorGroups[calculatorHelper.getSelectedTabIndex()].CalculatorGroupId;
	},

	hasMonitoringCalculatorGroup: function () {
		return calculatorHelper.hasCalculatorGroup(calculatorIdJson, CalculatorGroup_E.MonitoringCalculator);
	},

	hasPharmacyCalculatorGroup: function () {
		calculatorGroup.bindQtipText();
		return calculatorHelper.hasCalculatorGroup(calculatorIdJson, calculatorHelper.isDteProject() ? CalculatorGroup_E.DTEPharmacyCalculator : CalculatorGroup_E.PharmacyCalculator);
	},

	hasPharmacyCalculatorGroupAndTierEnabled: function (hasPharmacyTierEnabled) {
		return (hasPharmacyTierEnabled && (!calculatorGroup.hasPharmacyCalculatorGroup()));
	},

	bindQtipText: function () {
		bindToolTipFreq1();
		bindToolTipFreq2();
	},

	hasICraCalculatorGroup: function () {
		if (calculatorHelper.isDteProject()) { return false; }
		else
		{
			return calculatorHelper.hasCalculatorGroup(calculatorIdJson, CalculatorGroup_E.ICraCalculator);
		}
	},

	hasICraCalculatorGroupForAdd: function () {
		if (calculatorHelper.isDteProject()) { return true; }
		else
		{
			return calculatorHelper.hasCalculatorGroup(calculatorIdJson, CalculatorGroup_E.ICraCalculator);
		}
	},

	addPharmacyCalculatorGroup: function () {
		if (calculatorHelper.isRequestCalculator()) {
			alert("Cannot add Pharmacy calculator at request level.");
		}
		else if (calculatorHelper.getAttributeTypeId() == AttributeType_E.SsvAttribute || calculatorHelper.getRequestTypeId() == RequestType_E.SSV) {
			alert("Cannot add Pharmacy calculator group to Ssv calculator.");
		}
		else if (calculatorHelper.hasCalculatorGroup(calculatorIdJson, calculatorHelper.isDteProject() ? CalculatorGroup_E.DTEPharmacyCalculator : CalculatorGroup_E.PharmacyCalculator)) {
			alert("Pharmacy calculator group already exists.");
		}
		else if (confirm(Resources.PharmacyCalculatorAddConfirm)) {
			calculatorHelper.addCalculatorGroup(calculatorIdJson, calculatorHelper.isDteProject() ? CalculatorGroup_E.DTEPharmacyCalculator : CalculatorGroup_E.PharmacyCalculator, calculatorHelper.getAttributeId(), calculatorHelper.getAttributeTypeId());
		}
	},

	addICraCalculatorGroup: function () {
		if (calculatorHelper.isRequestCalculator()) {
			alert("Cannot add Remote Monitoring Non RBM Only calculator group at request level.");
		}
		else if (calculatorHelper.getAttributeTypeId() == AttributeType_E.SsvAttribute || calculatorHelper.getRequestTypeId() == RequestType_E.SSV) {
			alert("Cannot add Remote Monitoring Non RBM Only calculator group to Ssv calculator.");
		}
		else if (calculatorHelper.hasCalculatorGroup(calculatorIdJson, CalculatorGroup_E.ICraCalculator)) {
			alert("Remote Monitoring Non RBM Only calculator group already exists.");
		}
		else if (confirm(Resources.IcraCalculatorAddConfirm)) {
			calculatorHelper.addCalculatorGroup(calculatorIdJson, CalculatorGroup_E.ICraCalculator, calculatorHelper.getAttributeId(), calculatorHelper.getAttributeTypeId());
		}
	},

	removeICraCalculatorGroup: function () {
		if (calculatorHelper.hasCalculatorGroup(calculatorIdJson, CalculatorGroup_E.ICraCalculator)) {
			calculatorHelper.removeCalculatorGroup(calculatorIdJson, CalculatorGroup_E.ICraCalculator, calculatorHelper.getAttributeId(), calculatorHelper.getAttributeTypeId());
		}
		else {
			alert("Remote Monitoring Non RBM Only calculator does not exist.");
		}
	},

	removePharmacyCalculator: function () {
		var CalcGroupId = calculatorHelper.isDteProject() ? CalculatorGroup_E.DTEPharmacyCalculator : CalculatorGroup_E.PharmacyCalculator
		if (calculatorHelper.hasCalculatorGroup(calculatorIdJson, CalcGroupId)) {
			calculatorHelper.removeCalculatorGroup(calculatorIdJson, CalcGroupId, calculatorHelper.getAttributeId(), calculatorHelper.getAttributeTypeId());
		}
		else {
			alert("Pharmacy calculator does not exist.");
		}
	},

	addAdhocCalculator: function (calculatorGroupId, isRequestHardOrSoftBooked) {
		if (calculatorGroupId == CalculatorGroup_E.SsvCalculator) {
			alert("Cannot add Adhoc to Ssv calculator.");
		}
		if (!calculatorHelper.isRequestCalculator()) {
			alert("Cannot add Adhoc calculator at Country level.");
		}
		else if (calculatorHelper.hasCalculatorGroup(calculatorIdJson, calculatorGroupId)) {
			adhocDialog.initialValues = {
				startDate: "",
				stopDate: "",
				comment: "",
				isRequestHardOrSoftBooked: isRequestHardOrSoftBooked,
				dialogTitle: "Add Ad-hoc Interim Monitoring Frequency"
			};
			adhocDialog.okClickHandler = calculatorGroup.createAdhocCalculator;
			adhocDialog.dialogDivSelector = "#divAdhocDialog";
			adhocDialog.areDatesOverlaping = calculatorGroup.areDatesOverlaping;
			adhocDialog.isCurrentAdhocDateBeyondRequestStopDate = calculatorHelper.isCurrentAdhocDateBeyondRequestStopDate;
			adhocDialog.functionParams = {
				calculatorIdJson: calculatorIdJson,
				calculatorGroupId: calculatorGroupId,
				isRequestHardOrSoftBooked: calculatorHelper.isRequestHardOrSoftBooked,
				controlPrefix: ""
			};

			adhocDialog.setInitialValues();
			adhocDialog.openAdhocDialog();
		}
		else {
			alert("GroupId " + calculatorGroupId + " does not exist.");
		}
	},

	areDatesOverlaping: function (jsonParm, newStartDate, newStopDate) {
		var datesOverlap = false;

		var calcGroup = calculatorHelper.getCalculatorGroupByGroupId(jsonParm.calculatorIdJson, jsonParm.calculatorGroupId).calculatorGroup;
		var newStartDateObj = rm.date.getDateFromQDateString(newStartDate);
		var newStopDateObj = rm.date.getDateFromQDateString(newStopDate);

		$.each(calcGroup.Calculators, function (index, calc) {
			if (calc.CalculatorTypeId == CalculatorType_E.AdHoc && calc.DmlOperation != DMLOperation_E.Delete && calc.ControlPrefix != jsonParm.controlPrefix) {
				var startDate = rm.date.getDateFromQDateString($(adhocDialog.startDateSelector).val());
				var stopDate = rm.date.getDateFromQDateString($(adhocDialog.stopDateSelector).val());

				var existingStartDate = rm.date.getDateFromQDateString($(calculatorHelper.getControlSelector(calc.ControlPrefix, "startDate")).val());
				var existingStopDate = rm.date.getDateFromQDateString($(calculatorHelper.getControlSelector(calc.ControlPrefix, "stopDate")).val());

				if ((existingStartDate <= newStartDateObj && existingStopDate >= newStartDateObj) ||
		(existingStartDate <= newStopDateObj && existingStopDate >= newStopDateObj) ||
(newStartDateObj <= existingStartDate && newStopDateObj >= existingStartDate) ||
		(newStartDateObj <= existingStopDate && newStopDateObj >= existingStopDate)) {
					datesOverlap = true;
					return false;
				}
			}
		});

		return datesOverlap;
	},

	createAdhocCalculator: function (jsonParm, startDate, stopDate, comment) {
		var postData = {
			adhocDetails: {
				CalculatorGroupId: jsonParm.calculatorGroupId,
				CalculatorIndex: calculatorHelper.getCalculatorCount(jsonParm.calculatorIdJson, jsonParm.calculatorGroupId),
				IsRequestCalculator: calculatorHelper.isRequestCalculator(),
				IsNewRequest: calculatorHelper.isNewRequest(),
				RequestId: calculatorHelper.getRequestId(),
				AttributeId: calculatorHelper.getAttributeId(),
				IsRequestHardOrSoftBooked: jsonParm.isRequestHardOrSoftBooked,
				StartDate: startDate,
				StopDate: stopDate,
				Comment: comment,
				ShowConnectDisconnect: false,
				PrefixForNewCalculator: "New"
			}
		};

		$.rm.Ajax_Calculator("RenderAdhocCalculator", postData, function (data) {
			if (data.ContainsValidationErrors) {
				$.validationHelper.ShowErrorMessages(data.ValidationErrors);
			}
			else {
				rm.ui.messages.clearAllMessages();
				var aditionalData = data.RequestExecutionStatus[0].AdditionalData;
				$("#" + calculatorHelper.getGroupContainerId(jsonParm.calculatorIdJson, jsonParm.calculatorGroupId) + " > .searchCalculatorInner").append(aditionalData.ControlHtml);
				aditionalData.ControlHtml = ""; //html is not required after it is added to DOM
				calculatorHelper.addCalculatorToDetailsJson(jsonParm.calculatorIdJson, jsonParm.calculatorGroupId, aditionalData);
			}
		}, false, false);
	},

	editAdhocDates: function (calculatorGroupId, controlPrefix) {
		adhocDialog.initialValues = {
			startDate: $(calculatorHelper.getControlSelector(controlPrefix, "startDate")).val(),
			stopDate: $(calculatorHelper.getControlSelector(controlPrefix, "stopDate")).val(),
			comment: $(calculatorHelper.getControlSelector(controlPrefix, "comment")).val(),
			dialogTitle: "Update Ad-hoc Interim Monitoring Frequency"
		};
		adhocDialog.okClickHandler = calculatorGroup.updateAdhocDatesInDom;
		adhocDialog.dialogDivSelector = "#divAdhocDialog";
		adhocDialog.areDatesOverlaping = calculatorGroup.areDatesOverlaping;
		adhocDialog.isCurrentAdhocDateBeyondRequestStopDate = calculatorHelper.isCurrentAdhocDateBeyondRequestStopDate;
		adhocDialog.functionParams = {
			calculatorIdJson: calculatorIdJson,
			calculatorGroupId: calculatorGroupId,
			controlPrefix: controlPrefix
		};
		adhocDialog.setInitialValues();
		adhocDialog.openAdhocDialog();
	},

	updateAdhocDatesInDom: function (jsonParm, startDate, stopDate, comment) {
		rm.validation.clearError($(calculatorHelper.getControlSelector(jsonParm.controlPrefix, "hlAdhocDates")));

		$(calculatorHelper.getControlSelector(jsonParm.controlPrefix, "startDate")).val(startDate);
		$(calculatorHelper.getControlSelector(jsonParm.controlPrefix, "stopDate")).val(stopDate);
		$(calculatorHelper.getControlSelector(jsonParm.controlPrefix, "comment")).val(comment);
		$(calculatorHelper.getControlSelector(jsonParm.controlPrefix, "hlAdhocDates")).html(startDate + "<br />" + stopDate);
		$(calculatorHelper.getControlSelector(jsonParm.controlPrefix, "isChanged")).val("1");

		calculatorHelper.onAdhocDateEdit();
	},

	showPreviousValues: function () {
		var postData = {
			requestId: calculatorHelper.getRequestId(),
			attributeId: calculatorHelper.getAttributeId(),
			calculatorGroup: calculatorGroup.getCalculatorGroupIdForCurrentTab()
		};

		if (postData.requestId != "" || postData.attributeId != "") {
			$.rm.Ajax_Calculator("GetPreviousFrequencyCalculatorValues", postData, function (data) {
				var nameSpace = calculatorGroup.monitoringCalculatorGroup;
				if (nameSpace) { if (!nameSpace.showPreviousValues(data)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.pharmacyCalculatorGroup;
				if (nameSpace) { if (!nameSpace.showPreviousValues(data)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.iCraCalculatorGroup;
				if (nameSpace) { if (!nameSpace.showPreviousValues(data)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.ssvCalculatorGroup;
				if (nameSpace) { if (!nameSpace.showPreviousValues(data)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.initiateCalculatorGroup;
				if (nameSpace) { if (!nameSpace.showPreviousValues(data)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.monitoringSiteSpecificCalculatorGroup;
				if (nameSpace) { if (!nameSpace.showPreviousValues(data)) { isSuccessful = false; } }

				var nameSpace = calculatorGroup.dteMonitoringCalculatorGroup;
				if (nameSpace) { if (!nameSpace.showPreviousValues(data)) { isSuccessful = false; } }

				nameSpace = calculatorGroup.dtePharmacyCalculatorGroup;
				if (nameSpace) { if (!nameSpace.showPreviousValues(data)) { isSuccessful = false; } }

				$(".oldValue").removeClass("hideMe");

				if (calculatorHelper.selectedCountryId != _countryIds.Japan) {
					$(".oldValue.onlyForJapan").addClass("hideMe");
				}
			}, false, false);
		}
	},

	editCalculatorDisabled: function () {
		alert(Resources.AdhocEditDisabled);
	},

	removeCalculator: function (calculatorGroupId, controlPrefix) {
		calculatorHelper.removeCalculator(calculatorIdJson, calculatorGroupId, controlPrefix);
	},

	saveCalculator: function (saveIfConnectDisconnectPromptNotRequired, adhocCalcIdsToDelete) {
		calculatorHelper.onRibbonClick(); //this function makes sure that all required actions are performed which would be skipped when user clicks on 
		var selectedTabIndex = calculatorHelper.getSelectedTabIndex();

		if (calculatorHelper.isCalculatorValid(calculatorIdJson, selectedTabIndex)) {
			if (calculatorHelper.promptForConnectDisconnect(calculatorIdJson, selectedTabIndex)) {
				connectStatusDialog.functionParams.adhocCalcIdsToDelete = adhocCalcIdsToDelete;
				connectStatusDialog.onOkClick = calculatorHelper.connectStatusDialogOnOkClick;
				connectStatusDialog.functionParams = { calculatorIdJson: calculatorIdJson, selectedTabIndex: calculatorHelper.getSelectedTabIndex() };
				connectStatusDialog.initialize(calculatorIdJson, calculatorHelper.getSelectedTabIndex());
				connectStatusDialog.dialogDivSelector = "#divConnectDisconnectDialog";
				connectStatusDialog.openDialog()

				rm.ui.messages.clearAllMessages();
			}
			else {
				if (saveIfConnectDisconnectPromptNotRequired) {
					calculatorHelper.saveCalculatorToDb(calculatorIdJson, selectedTabIndex, adhocCalcIdsToDelete);
				}
				else {
					calculatorHelper.connectStatusDialogOnOkClick();
				}
			}
		}
		else {
			rm.ui.messages.addError(Resources.FixAllErrorsAndTryAgain);
		}
	},

	isSaveEnabled: function () {
		return calculatorHelper.isCurrentTabDirty(calculatorIdJson);
	},

	isCancelEnabled: function () {
		return calculatorHelper.isCurrentTabDirty(calculatorIdJson);
	},

	isCalculatorContainerDirty: function () {
		return calculatorHelper.isCurrentTabDirty(calculatorIdJson);
	},

	cancel: function () {
		var isDirty = calculatorGroup.isCalculatorContainerDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			$.cookie("activeCalculatorTabId", calculatorHelper.getSelectedTabIndex());
			RefreshPage();
		}
	},

	close: function (source) {
		var isDirty = calculatorGroup.isCalculatorContainerDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;

			if (source == 'ssvattr') {
				window.location.href = "/_Layouts/SPUI/profile/SSVAttr.aspx";
			}
			else if (source == 'monattr') {
				window.location.href = "/_Layouts/SPUI/profile/MonitoringAttributes.aspx";
			}
			else if (source == "submitted") {
				window.location.href = "/_Layouts/SPUI/Requests/SubmittedRequest.aspx?reqGroup=" + RequestGroup_E.Submitted;
			}
			else if (source == "queried") {
				window.location.href = "/_Layouts/SPUI/Requests/SubmittedRequest.aspx?reqGroup=" + RequestGroup_E.Queried;
			}
			else if (source == "backfill") {
				window.location.href = "/_Layouts/SPUI/Requests/SubmittedRequest.aspx?reqGroup=" + RequestGroup_E.Backfill;
			}
			else if (source == "permanent") {
				window.location.href = "/_Layouts/SPUI/Notification/PermanentRequest.aspx";
			}
			else if (source == "ssvrequest") {
				window.location.href = "/_layouts/SPUI/Notification/SSVRequest.aspx";
			}
			else {
				alert("Unsupported source:'" + source + "'");
			}
		}
	},
	getJobGrade: function () {
		var jobGrade = calculatorHelper.getJobGrade();
		return (jobGrade == "") ? null : jobGrade;
	},
	getJobGradeInfoString: function () {
		var jobGradeInfoString = calculatorHelper.getJobGradeInfoString();
		return (jobGradeInfoString == "") ? null : jobGradeInfoString;
	}
};
