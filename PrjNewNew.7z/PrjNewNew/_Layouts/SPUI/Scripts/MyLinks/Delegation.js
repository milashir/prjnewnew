﻿/// <reference path="../common/rmhelper.js" />
$(function () {
	DelegationPage.initDelegationPage();
	DelegationPage.buildDelegateGrid();
	DelegationPage.CreateDelegationKeyPress();
});

var DelegationPage =
{
	initDelegationPage: function () {
		$("#MyLinks_Delegation").addClass("left-static-selected-menu");
		$("#txtDelegateStartDate,#txtDelegateStopDate").qDatepicker();
		DelegationPage.BindEvent();
		DelegationPage.initializeSmartSearchLookupData();
		DelegationPage.DisableCreateDelegation();
	},
	DisableCreateDelegation: function () {
		$('[id$=txtCurrentLineManager]').val('');
		$('[id$=txtCurrentLineManager]').attr("disabled", "disabled");
		$('[id$=txtDelegatedLineManager]').attr("disabled", "disabled");
		$("#txtDelegateStartDate").attr("disabled", "disabled");
		$("#txtDelegateStopDate").attr("disabled", "disabled");
		$('[id$=txtCurrentLineManager]').addClass("disabledinput");
		$('[id$=txtDelegatedLineManager]').addClass("disabledinput");
		$("#txtDelegateStartDate").addClass("disabledinput");
		$("#txtDelegateStopDate").addClass("disabledinput");
		$(".ui-datepicker-trigger").hide();
	},
	EnableCreateDelegation: function () {
		$('[id$=txtCurrentLineManager]').val($('[id$=hdnMyResourceName]').val());
		$('[id$=txtCurrentLineManager]').removeAttr("disabled");
		$('[id$=txtDelegatedLineManager]').removeAttr("disabled");
		$("#txtDelegateStartDate").removeAttr("disabled");
		$("#txtDelegateStopDate").removeAttr("disabled");
		$('[id$=txtCurrentLineManager]').removeClass("disabledinput");
		$('[id$=txtDelegatedLineManager]').removeClass("disabledinput");
		$("#txtDelegateStartDate").removeClass("disabledinput");
		$("#txtDelegateStopDate").removeClass("disabledinput");
		$(".ui-datepicker-trigger").show();
	},
	BindEvent: function () {
		$("#divNewManager :input").bind("keyup", function (event) {
			DelegationPage.EnableSaveCancelForCreateDelegation();
		});

		$("#divNewManager :input").bind("change", function (event) {
			DelegationPage.EnableSaveCancelForCreateDelegation();
		});
	},
	ActiveRibbonButton: 10,
	CreateDelegationKeyPress: function () {
		var element = ['[id$=txtCurrentLineManager]', '[id$=txtDelegatedLineManager]', '#txtDelegateStartDate', '#txtDelegateStopDate'];

		$('[id$=txtCurrentLineManager]').keypress(function (e) {
			if (e.keyCode !== 13) {
				rm.validation.addError('[id$=txtCurrentLineManager]', "Please pick up a valid delegated line manager by the smart search.");
			}
		});

		$('[id$=txtDelegatedLineManager]').keypress(function (e) {
			if (e.keyCode !== 13) {
				rm.validation.addError("#" + $('[id$=txtDelegatedLineManager]').attr("id"), "Please pick up a valid delegated line manager by the smart search.");
			}
		});

		$('[id$=txtDelegateStartDate]').keypress(function (e) {
			if (e.keyCode !== 13) {
				//DelegationPage.EnableSaveCancel();
			}
		});

		$('[id$=txtDelegateStopDate]').keypress(function (e) {
			if (e.keyCode !== 13) {
				//DelegationPage.EnableSaveCancel();
			}
		});
	},
	EnableSaveCancelForCreateDelegation: function () {
		DelegationPage.isCreateNewDelegationEnabled = true;
		DelegationPage.isCancelCreateNewDelegationEnabled = true;
		rm.ui.ribbon.refresh();
	},
	DisableSaveCancel: function () {
		DelegationPage.ResetRibbonButton();
	},
	RibbonButton:
	{
		CreateDelegation: 10,
		ModifyDelegation: 20,
		SaveDelegation: 30,
		RemoveDelegation: 40
	},
	CreateDelegation: function () {
		if (DelegationPage.isUpdateDelegationEnabled && (!confirm(Resources.UnsavedChangesOnThePage))) {
			return;
		}
		rm.grid.cancelGridEditModeWithoutConfirm("#delegateList");
		rm.grid.uncheckAllGridRows("#delegateList");
		DelegationPage.ResetCreateDelegation();
		DelegationPage.isCloseCreateDelegationEnabled = true;
		rm.ui.ribbon.refresh();
		DelegationPage.ActiveRibbonButton = DelegationPage.RibbonButton.CreateDelegation;
		DelegationPage.EnableCreateDelegation();
		DelegationPage.ResetRibbonButton();
	},
	CloseCreateDelegation: function () {
		if (DelegationPage.isCreateNewDelegationEnabled && (!confirm(Resources.UnsavedChangesOnThePage))) {
			return;
		}
		DelegationPage.ResetCreateDelegation();
		DelegationPage.isCloseCreateDelegationEnabled = false;
		DelegationPage.isCreateDelegationEnabled = true;
		rm.ui.ribbon.refresh();
		$("#divCreateDelegation").hide();
	},
	CloseCreateDelegationEnabled: function () {
		return DelegationPage.isCloseCreateDelegationEnabled;
	},
	isCloseCreateDelegationEnabled: false,
	isCreateDelegationEnabled: true,
	CreateDelegationEnabled: function () {
		return DelegationPage.isCreateDelegationEnabled;
	},
	CreateNewDelegation: function () {
		DelegationPage.ResourceDelegate();
	},
	isCreateNewDelegationEnabled: false,
	CreateNewDelegationEnabled: function () {
		return DelegationPage.isCreateNewDelegationEnabled;
	},
	CancelCreateNewDelegation: function () {
		DelegationPage.Cancel();
	},
	isCancelCreateNewDelegationEnabled: false,
	CancelCreateNewDelegationEnabled: function () {
		return DelegationPage.isCancelCreateNewDelegationEnabled;
	},
	CreateDelegationEnabled: function () {
		return DelegationPage.isCreateDelegationEnabled;
	},
	CancelUpdateDelegation: function () {
		DelegationPage.Cancel();
	},
	isCancelUpdateDelegationEnabled: false,
	CancelUpdateDelegationEnabled: function () {
		return DelegationPage.isCancelUpdateDelegationEnabled;
	},
	RemoveDelegation: function () {
		var postData = { resourceDelegateIds: $("#delegateList").getGridParam('selarrrow') };

		rm.ajax.resourceSvcAsyncPost("DeleteResourceDelegateList", postData, function (result) {
			if (result) {
				var rowIds = $("#delegateList").getGridParam('selarrrow');
				while (rowIds.length > 0) {
					rm.grid.cancelRowEditMode("#delegateList", rowIds[0]);
					rm.grid.removeRow("#delegateList", rowIds[0]);
				}

				rm.ui.messages.showSuccess("Delegation(s) removed successfully.");
				setTimeout(function () { DelegationPage.ResetRibbonButton(); }, 100);
			} else {
				rm.ui.messages.addError('Unable to save.');
				rm.ui.messages.showSuccess("The operation failed!");
			}
		});
	},
	isRemoveDelegationEnabled: false,
	RemoveDelegationEnabled: function () {
		return DelegationPage.isRemoveDelegationEnabled;
	},
	isModifyDelegationEnabled: true,
	ModifyDelegationEnabled: function () {
		return DelegationPage.isModifyDelegationEnabled;
	},
	isUpdateDelegationEnabled: false,
	isCancelEnabled: false,
	CancelEnabled: function () {
		return DelegationPage.isCancelEnabled;
	},
	UpdateDelegationEnabled: function () {
		return DelegationPage.isUpdateDelegationEnabled;
	},
	HasRowsSelected: function () {
		return rm.grid.hasRowsSelected("#delegateList");
	},
	HasRowsInEditMode: function () {
		return rm.grid.hasRowsInEditMode("#delegateList");
	},
	ResetRibbonButton: function () {
		DelegationPage.isCreateDelegationEnabled = ((DelegationPage.ActiveRibbonButton === DelegationPage.RibbonButton.ModifyDelegation) && (!(DelegationPage.HasRowsSelected() || DelegationPage.HasRowsInEditMode())));

		if (DelegationPage.ActiveRibbonButton === DelegationPage.RibbonButton.ModifyDelegation) {
			DelegationPage.isCloseCreateDelegationEnabled = false;
			$("#divCreateDelegation").hide();
		} else if (DelegationPage.ActiveRibbonButton === DelegationPage.RibbonButton.CreateDelegation) {
			$("#divCreateDelegation").show();
			DelegationPage.isCloseCreateDelegationEnabled = true;
		}

		DelegationPage.isCreateNewDelegationEnabled = false;
		DelegationPage.isCancelCreateNewDelegationEnabled = false;
		DelegationPage.isUpdateDelegationEnabled = DelegationPage.HasRowsInEditMode();
		DelegationPage.isCancelUpdateDelegationEnabled = DelegationPage.HasRowsInEditMode();
		DelegationPage.isRemoveDelegationEnabled = DelegationPage.HasRowsSelected();

		rm.ui.ribbon.refresh();
	},
	SmartSearchLookUp: null,
	initializeSmartSearchLookupData: function () {
		rm.ajax.resourceSvcAsyncGet("GetSmartSearchLookupListForDelegateResource", {}, function (result) {
			DelegationPage.SmartSearchLookUp = result;

			DelegationPage.bindResourceLookupAutoComplete($('[id$=txtCurrentLineManager]'), $("[id$=hdnCurrentLineManagerResourceId]"));
			DelegationPage.bindResourceLookupAutoComplete($('[id$=txtDelegatedLineManager]'), $("[id$=hdnDelegatedLineManager]"));
		});
	},
	IsExistedLineManager: function (txtObj, hdnObj) {
		var isExisted = false, item;
		for (var i = 0, len = DelegationPage.SmartSearchLookUp.length; i < len; i++) {
			item = DelegationPage.SmartSearchLookUp[i];
			if (txtObj.val() === item.value) {
				isExisted = true;
				hdnObj.val(item.id);
				break;
			}
		}
		return isExisted;
	},
	bindResourceLookupAutoComplete: function (textboxObj, copyIdToObject, writeText) {

		textboxObj.autocomplete({
			source: DelegationPage.SmartSearchLookUp,
			minLength: 1
		});

		//When option in list is , do something
		textboxObj.bind("autocompleteselect", function (event, ui) {
			rm.validation.clearError(textboxObj);

			copyIdToObject.val(ui.item.id);
		});

	},
	saveSuccessCallback: function (data, isSingleRowUpdate) {
		rm.ui.messages.clearAllMessages();

		if (data.ContainsValidationErrors) {
			rm.validation.processErrorMessages(data.ValidationErrors, "#delegateList", 'Message');
			rm.ui.messages.addError('Please correct the errors and click save again. Hover over controls for more details.');
			return false;
		}
		else {
			setTimeout(function () { DelegationPage.ResetRibbonButton(); }, 5);
			rm.ui.messages.showSuccess('Delegation updated successfully.');
			return true;
		}
	},
	UpdateDelegation: function () {
		rm.ui.messages.clearAllMessages();
		DelegationPage.ChangeDelegation();
	},
	ResourceDelegate: function () {
		var errMsgArr = [];
		var msg = {};
		if (!DelegationPage.IsExistedLineManager($('[id$=txtCurrentLineManager]'), $("[id$=hdnCurrentLineManagerResourceId]"))) {
			rm.validation.addError("[id$=txtCurrentLineManager]", "Please pick up a valid current line manager by the smart search.");
			//return;
			msg = { Key: "[id$=txtCurrentLineManager]", MessageType: 1, Value: "Please pick up a valid current line manager by the smart search." };
			errMsgArr.push(msg);
		}

		if (!DelegationPage.IsExistedLineManager($('[id$=txtDelegatedLineManager]'), $("[id$=hdnDelegatedLineManager]"))) {
			msg = { Key: "[id$=txtDelegatedLineManager]", MessageType: 1, Value: "Please pick up a valid delegated line manager by the smart search." };
			errMsgArr.push(msg);
		}

		if ($("[id$=txtCurrentLineManager]").val() === $("[id$=txtDelegatedLineManager]").val()) {
			msg = { Key: "[id$=txtDelegatedLineManager]", MessageType: 1, Value: "Please pick up a delegated line manager who is not the current line manager." };
			errMsgArr.push(msg);
		}

		if (errMsgArr.length > 0) {
			rm.validation.processErrorMessages(errMsgArr);
			return;
		}

		var originalManagerResourceId = ($("[id$=hdnCurrentLineManagerResourceId]").val() === '') ? -1 : $("[id$=hdnCurrentLineManagerResourceId]").val();
		var delegateManagerResourceId = ($("[id$=hdnDelegatedLineManager]").val() === '') ? -1 : $("[id$=hdnDelegatedLineManager]").val();

		var postData = { originalManagerResourceId: originalManagerResourceId, delegateManagerResourceId: delegateManagerResourceId, StartDate: $("#txtDelegateStartDate").val(), StopDate: $("#txtDelegateStopDate").val() };
		var ServiceName = 'CreateDelegation';

		rm.ajax.resourceSvcAsyncPost(ServiceName, postData, function (data) {
			if (data.ContainsValidationErrors) {
				rm.ui.messages.clearAllMessages();
				rm.validation.processErrorMessages(data.ValidationErrors);
				rm.ui.messages.addError("Please correct all errors and click Save again.");
			}
			else {
				rm.ui.messages.clearAllMessages();
				DelegationPage.ResetCreateDelegation();
				rm.ui.messages.showSuccess('Data saved succesfully.');
				$("#delegateList").setGridParam({ datatype: 'json', page: 1 }).trigger('reloadGrid');
			}
		}, false, true);


	},
	ChangeDelegation: function () {
		DelegationPage.SaveGrid();
	},
	SaveGrid: function () {
		//Saves only rows that are in edit mode
		//Override the hidden dates too or the sorting is broken until you reload the page

		var mygrid = $("#delegateList");
		var ids = mygrid.getDataIDs();  //all the rowids

		rowsEditing.AjaxCount = 0;
		for (var i = 0; i < ids.length; i++) {
			var rowid = ids[i];
			if ($($("#delegateList").jqGrid("getInd", rowid, true)).attr("editable") === "1") {
				rowsEditing.AjaxCount++;
			}
		}
		rm.grid.clearGridError("#delegateList", "Message"); //Clear all grid errors before saving
		//Count in one loop, save in the next - otherwise creates a race condition
		for (var i = 0; i < ids.length; i++) {
			var rowid = ids[i];
			//From docs http://www.trirand.com/jqgridwiki/doku.php?id=wiki:inline_editing
			mygrid.jqGrid("saveRow", rowid, saveSuccessCallback, null, null, aftersaveCallback, errorCallback, null);
		}
	},
	CheckGridRows: function () {
		DelegationPage.ResetRibbonButton();
	},
	HasRowSelected: function () {
		return $("#delegateList").getGridParam('selarrrow').length > 0;
	},
	Cancel: function () {
		rm.ui.messages.clearAllMessages();
		switch (DelegationPage.ActiveRibbonButton) {
			case DelegationPage.RibbonButton.CreateDelegation:
				DelegationPage.CancelCreateDelegation();
				DelegationPage.DisableSaveCancel();
				break;
			case DelegationPage.RibbonButton.ModifyDelegation:
				DelegationPage.CancelGrid();
				DelegationPage.ResetRibbonButton();
				break;
			default:
				break;
		}
	},
	CancelCreateDelegation: function () {
		if (confirm(Resources.UnsavedChangesOnThePage)) {
			DelegationPage.ResetCreateDelegation();
		}
	},
	ResetCreateDelegation: function () {
		$('[id$=txtCurrentLineManager]').val($('[id$=hdnMyResourceName]').val());
		$('[id$=hdnCurrentLineManagerResourceId]').val($('[id$=hdnMyResourceId]').val());
		$('[id$=txtDelegatedLineManager]').val("");
		$('[id$=hdnDelegatedLineManagerResourceId]').val("0");
		$('[id$=txtDelegateStartDate]').val("");
		$('[id$=txtDelegateStopDate]').val("");
		rm.validation.clearError($('[id$=txtCurrentLineManager]'));
		rm.validation.clearError($('[id$=txtDelegatedLineManager]'));
		rm.validation.clearError($('#txtDelegateStartDate'));
		rm.validation.clearError($('#txtDelegateStopDate'));
		rm.ui.messages.clearAllMessages();
		DelegationPage.isRemoveDelegationEnabled = false;
		DelegationPage.isUpdateDelegationEnabled = DelegationPage.HasRowsInEditMode();
		DelegationPage.isCancelUpdateDelegationEnabled = DelegationPage.HasRowsInEditMode();
		DelegationPage.isCreateNewDelegationEnabled = false;
		DelegationPage.isCancelCreateNewDelegationEnabled = false;
		rm.ui.ribbon.refresh();
	},
	//Cancel editing for the entire grid.  Restores last saved values.
	CancelGrid: function () {
		rm.grid.cancelGridEditMode("#delegateList");
		rowsEditing.clearAll();
		DelegationPage.isUpdateDelegationEnabled = false;
		DelegationPage.isCancelUpdateDelegationEnabled = false;
		rm.ui.ribbon.delayedRefresh();
	},
	buildDelegateGrid: function () {
		var gridSelector = "#delegateList";
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.Delegation };
		rm.grid.showGridTools(gridSelector, gridToolsConfig);
		$(gridSelector).jqGrid({
		    url: rm.ajax.resourceSvcUrl + "GetDelegatedResourceList",
		    editurl: rm.ajax.resourceSvcUrl + "UpdateDelegation",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			postData: {},
			loadonce: true,
			pager: '#listPager',
			autowidth: false,
			shrinkToFit: false,
			height: rm.ui.getMaxGridHeight() - 10,
			width: 980,
			multiselect: true,
			colModel: [
					{
						name: '', label: '', index: 'actions',
						formatter: 'actions', editable: false, sortable: true, resizable: false,
						fixed: true, width: 40, search: false,
						formatoptions: {
							keys: true, editbutton: false, delbutton: false,
							onEdit: function (rowid) {   //only fires when you click the icon, not when you call editRow
								addToRowsEditing(rowid);
								return true;
							},
							afterRestore: function (rowid) {
								rowsEditing.pop(rowid);
								DelegationPage.ResetRibbonButton();
								rm.grid.scrollTableBodyToFixAlignmentIssue(gridSelector);
							},
							onError: function (rowid, response, errorType) { },
							onSuccess: function (response) { return DelegationPage.saveSuccessCallback($.parseJSON(response.responseText), true); }
						}
					},
				rm.grid.standardColumns.getMessageColumn(),
				{ name: 'OriginalManager', index: 'OriginalManager', label: "Original Manager", width: 250, editable: false, searchoptions: { sopt: ['cn'] } },
				{ name: 'DelegateManagerResourceId', index: 'DelegateManagerResourceId', hidden: true, editable: true, searchoptions: { sopt: ['cn'] } },
				{
					name: 'DelegateManager', index: 'DelegateManager', label: "Delegate Manager", searchoptions: { sopt: ['cn'] }, width: 250, editable: true,
					editoptions: {
						dataInit: function (element) {
							setTimeout(function () {
								var copyIdToObject = $(element).parent().prev().find("input");
								DelegationPage.bindResourceLookupAutoComplete($(element), copyIdToObject);
								$(element).keypress(function (e) {
									if (e.keyCode !== 13) {
										copyIdToObject.val(0);
										rm.validation.addError("#" + $(element).attr("id"), "Please pick up a valid delegated line manager by the smart search.");
									}
								});
							}, 10);
						}
					}
				},
				rm.grid.standardColumns.getEditableDateNoConnectColumn('StartDate', 'StartDate', 'Start Date', gridSelector),
				rm.grid.standardColumns.getEditableDateNoConnectColumn('StopDate', 'StopDate', 'Stop Date', gridSelector)
			],
			multipleSearch: true,
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			ondblClickRow: function (id) {
				if (DelegationPage.isCreateNewDelegationEnabled && (!confirm(Resources.UnsavedChangesOnThePage))) {
					return;
				}
				DelegationPage.ActiveRibbonButton = DelegationPage.RibbonButton.ModifyDelegation;
				addToRowsEditing(id);
				$(this).jqGrid('editRow', id, false);   //handleResult only fires when saving using Keys!! damnit
				$("tr#" + id + " div.ui-inline-edit, " + "tr#" + id + " div.ui-inline-del").hide();
				$("tr#" + id + " div.ui-inline-save, " + "tr#" + id + " div.ui-inline-cancel").show();
				DelegationPage.ResetRibbonButton();

			},
			onSelectRow: function (id, status) {
				if (status) {
					if (DelegationPage.isCreateNewDelegationEnabled && (!confirm(Resources.UnsavedChangesOnThePage))) {
						rm.grid.uncheckAllGridRows('#delegateList');
						return;
					}
					else {
						DelegationPage.ActiveRibbonButton = DelegationPage.RibbonButton.ModifyDelegation;
						setTimeout(function () {
							DelegationPage.ResetRibbonButton();
						}, 10)
					}
				}
				else {
					if (DelegationPage.ActiveRibbonButton === DelegationPage.RibbonButton.CreateDelegation) {
						return;
					}
					else {
						DelegationPage.ActiveRibbonButton = DelegationPage.RibbonButton.ModifyDelegation;
						setTimeout(function () {
							DelegationPage.ResetRibbonButton();
						}, 10)
					}
				}

			},
			onSelectAll: function (rowIdxArray, sts) {
				if (DelegationPage.isCreateNewDelegationEnabled && (!confirm(Resources.UnsavedChangesOnThePage))) {
					setTimeout(function () {
						$('.cbox').attr('checked', false);
						$("#delegateList tr").removeClass("ui-state-highlight");
					}, 10)
					return;
				}
				DelegationPage.ActiveRibbonButton = DelegationPage.RibbonButton.ModifyDelegation;
				DelegationPage.ResetRibbonButton();

			},
			onPaging: function () { rm.ui.ribbon.delayedRefresh(); },
			serializeRowData: function (postData) {
				return JSON.stringify(postData);
			}
		});
		$("#delegateList").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	}
};

//MR: Keep track of all the AJAX return messages and display a message if there were any problems
var rowsEditing = new Hash();
rowsEditing.HasMessage = false;
rowsEditing.LastMessage = '';
rowsEditing.AjaxCount = 0;
rowsEditing.SavedSomething = false;
rowsEditing.clearAll = function () {
	rowsEditing.empty();
	rowsEditing.HasMessage = false;
	rowsEditing.LastMessage = '';
	rowsEditing.AjaxCount = 0;
	rowsEditing.SavedSomething = false;
};
addToRowsEditing = function (rowid) {
	var row = { 'message': '', 'ajaxComplete': false };
	rowsEditing.put(rowid, row);
	DelegationPage.ResetRibbonButton();
};
saveSuccessCallback = function (response, singleRow) {
	var d = $.parseJSON(response.responseText);
	var additionalData = d.RequestExecutionStatus[0].AdditionalData;
	if (!d.ContainsValidationErrors) {
		//rm.ui.messages.showSuccess(Resources.AllDataSavedSuccessfully);

		//Give it a split second so the row can go back to read-only mode
		setTimeout(function () {
			$("#delegateList").setCell(additionalData.RowId, "StartDate", additionalData.StartDateQ, "", "", true);
			$("#delegateList").setCell(additionalData.RowId, "StopDate", additionalData.StopDateQ, "", "", true);
		}, 100);


		rm.grid.cancelRowEditMode("#delegateList", additionalData.RowId);
		$("#delegateList").setCell(additionalData.RowId, "Message", " ");
		checkForErrorsOnSuccess(additionalData.RowId, singleRow);

	}
	else {
		errorCallback(additionalData.RowId, response, null, singleRow);
		return false;
	}

	return true;
};
//Successful Ajax response, so dequeue the Ajax call
checkForErrorsOnSuccess = function (rowid, singleRow) {
	var row = rowsEditing.pop(rowid);
	rowsEditing.AjaxCount--;
	rowsEditing.SavedSomething = true;

	if (rowsEditing.AjaxCount == 0 || singleRow) {
		if (rowsEditing.length == 0) {
			rm.ui.messages.clearAllMessages();
			rm.ui.messages.showSuccess(Resources.AllDataSavedSuccessfully);
			rowsEditing.clearAll();

			DelegationPage.ResetRibbonButton();
		} else if (singleRow) {
			rm.ui.messages.clearAllMessages();
			rm.ui.messages.showSuccess(Resources.DataSavedSuccessfully);
			if (rowsEditing.length == 0) {
				DelegationPage.ResetRibbonButton();
			}
		} else if (rowsEditing.length > 0) {
			rm.ui.messages.addError('Data saved with some errors found.');
		}
		if (rowsEditing.HasMessage) {
			alert(rowsEditing.LastMessage);
		}
		rowsEditing.HasMessage = false;
		rowsEditing.SavedSomething = false;
	}

	SetButtonAsRowSelected();
};
errorCallback = function (rowid, response, errorType, singleRow) {
	var d = $.parseJSON(response.responseText);
	var row = rowsEditing.get(rowid);
	if (row !== undefined) {
		row.ajaxComplete = true;
		rm.validation.processErrorMessages(d.ValidationErrors, "#delegateList", "Message");
		rowsEditing.HasMessage = true;
		rowsEditing.LastMessage = row.message;

		checkForErrorsOnError(rowid, singleRow);
	}
};
aftersaveCallback = function () {
	var args = arguments;
};
//Failed Ajax response, so leave on the queue
checkForErrorsOnError = function (rowid, singleRow) {
	var row = rowsEditing.get(rowid);
	rowsEditing.AjaxCount--;

	if (rowsEditing.AjaxCount == 0 || singleRow) {
		if (rowsEditing.length > 0) {
			if (rowsEditing.SavedSomething) {
				rm.ui.messages.addError('Data saved with some errors found.');
			} else {
				rm.ui.messages.addError('Errors found.  Nothing saved.');
			}
		}

		rowsEditing.HasMessage = false;
		rowsEditing.SavedSomething = false;
	}
};
function SetButtonAsRowSelected() {
	var selectedIds = rm.grid.getSelectedIds("#delegateList").split(',');
	if (selectedIds.length == 1) //single row selected
	{
		//DelegationPage.isRemoveDelegationEnabled = true;
	}

	rm.ui.ribbon.refresh();
}
