﻿/// <reference path="../common/rmhelper.js" />
$(document).ready(function () {
	$("#MyLinks_OpenRequests").addClass("left-static-selected-menu");
	orNs.BuildGrid();
	orNs.BuildQueue();

	$("#aspnetForm").ajaxStart(function () { rm.ui.block(); });

	$("#aspnetForm").ajaxStop(function () {
		if (orNs._ajaxErrors) {
			orNs._ajaxErrors = false;
			if (orNs._source == "queue") {
				rm.ui.messages.addError("Error occurred whilst removing requests from Resourcing Work list Summary.  Hover over error indicator for more details.", false);
				$("#list").setGridParam({ datatype: 'json', page: 1 }).trigger('reloadGrid');
			}
			if (orNs._source == "list") {
				rm.ui.messages.addError("Error occurred whilst adding requests to Resourcing Work list Summary.  Hover over error indicator for more details.", false);
				$("#queue").setGridParam({ datatype: 'json', page: 1 }).trigger('reloadGrid');
			}
		} else {
			if (!orNs._onLoad && orNs._onSaving) {
				if (orNs._source == "queue") {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess("Successfully removed requests from Resourcing Worklist Summary.", false);
				}
				if (orNs._source == "list") {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess("Successfully added requests to Resourcing Worklist Summary.", false);
				}
				$("#list").setGridParam({ datatype: 'json', page: 1 }).trigger('reloadGrid');
				$("#queue").setGridParam({ datatype: 'json', page: 1 }).trigger('reloadGrid');
			}
		}
		orNs._onLoad = false;
		orNs._onSaving = false;
		orNs.CheckGridRows();
		rm.ui.unblock();
	});
	rm.grid.bindEventsToResizeGrid("#list", "#queue");
	orNs.bindLabelQtip();
	rm.qtip.showInfo("[id$=_ViewProjectSummary]", "Display Project Summary");
});

orNs = {

	_source: '',
	_onLoad: true,
	_onSaving: false,
	_ajaxErrors: false,
	uniqueProjectId: -1,

	AddToQueueEnabled: function () { return orNs.HasListRowsSelected(); },
	ResetRibbonIcons: function () { rm.ui.ribbon.refresh(); },
	CheckGridRows: function () { rm.ui.ribbon.refresh(); },
	ViewProjectSummaryButtonEnabled: function () {
		if (orNs.HasListRowsSelected()) {
			var isEnabled = false;
			var selectedrows = $("#list").getGridParam('selarrrow');
			for (var i = 0; i < selectedrows.length; i++) {
				var jsonValFirst = $.parseJSON($('#list').getCell(selectedrows[0], 'HiddenJson'));
				var jsonVal = $.parseJSON($('#list').getCell(selectedrows[i], 'HiddenJson'));
				if (jsonValFirst.projectId == jsonVal.projectId) {
					isEnabled = true;
					orNs.uniqueProjectId = jsonValFirst.projectId;
				}
				else {
					isEnabled = false;
					break;
				}
			}
			return isEnabled;
		}
		else { return false };
	},
	ViewProjectSummaryOnClick: function () {
		$("#divDialogProject").load("../Profile/ProjectDetailsDialog.aspx?ProjectId=" + orNs.uniqueProjectId + "").dialog({
			autoOpen: false,
			modal: true,
			width: 1200,
			title: "Project Summary",
			height: 500,
			open: function (event, ui) {
				//hide close button.
				$(this).parent().children().children('.ui-dialog-titlebar-close').hide();
			},
			buttons: {
				"Close": function () {
					$(this).dialog("close");
				}
			}
		});
		$("#divDialogProject").dialog('open');
	},
	HasItemsInQueue: function () { return $("#queue").getGridParam('records') > 0; },
	HasQueueRowSelected: function () { return $("#queue").getGridParam('selarrrow').length > 0; },
	HasListRowsSelected: function () { return $("#list").getGridParam('selarrrow').length > 0; },
	AddToQueue: function () {
		if (orNs._onSaving) return;

		orNs._onSaving = true;
		orNs._ajaxErrors = false;
		orNs._source = 'list';

		var selectedrows = $("#list").getGridParam('selarrrow');
		if (selectedrows.length == 0) { rm.ui.messages.addError("No requests selected.", true); }

		var idArray = new Array();
		var rowIdArray = new Array();
		for (var i = 0; i < selectedrows.length; i++) {
			var listOfIds = $('#list').getCell(selectedrows[i], 'IdList');
			var jsonVal = $.parseJSON($('#list').getCell(selectedrows[i], 'HiddenJson'));
			var itemToSend = {
				rowId: jsonVal.rowId,
				listOfIds: jsonVal.listOfIds,
				countryId: jsonVal.countryId,
				regionId: jsonVal.regionId,
				projectId: jsonVal.projectId,
				protocolNumber: jsonVal.protocolNumber,
				countryRegionId: jsonVal.countryRegionId,
				requestTypeResourceTypeGroupId: jsonVal.requestTypeResourceTypeGroupId
			};
			idArray.push(itemToSend);
		}

		var myData = { idArray: idArray };

		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.requestSvcUrl + "RequestQueue/Add",
			data: JSON.stringify(myData),
			dataType: "json",
			success: function (result) {
				var rows = result.Rows;
				for (var i = 0; i < rows.length; i++) {
					if (rows[i].IsError) {
						orNs._ajaxErrors = true;
						rm.grid.showErrorIconInMessageColumn('#list', rows[i].RowId, 'Message', rows[i].Message);
					} else {
						rm.grid.removeRow("#list", rows[i].RowId);
					}
				}
			},
			error: function (x, e) {
				$.rm.ShowHtmlPopup("Web Service Error: RequestQueue/Add", x.responseText);
				orNs._ajaxErrors = true;
			}
		});
		rm.serviceCalls.getRequestCounts();
	},

	RemoveFromQueueEnabled: function () { return orNs.HasQueueRowSelected(); },

	RemoveFromResourcingQueue: function () {
		var selectedrows = $("#queue").getGridParam('selarrrow');
		if (selectedrows.length == 0) { rm.ui.messages.addError("No requests in queue selected.", true); }
		else {
			var listOfIds = "";
			for (var i = 0; i < selectedrows.length; i++) {
				listOfIds += $('#queue').getCell(selectedrows[i], 'OpenRequestQueueId') + "|";
			}

			$.ajax({
				type: "POST",
				contentType: "application/json; charset=utf-8",
				url: rm.ajax.requestSvcUrl + "ResourceSearchQueue/Remove",
				data: '{"listOfIds":"' + listOfIds + '"}',
				dataType: "json",
				success: function (result) {
					alert('TODO: uncheck the rows');
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess("Requests removed from your resourcing queue.", false);
				},
				error: function (errMsg) {
					orNs._ajaxErrors = true;
				}
			});
		}
	},

	GetSelectedIds: function () {
		var ids = "";
		$.each($("#queue").getGridParam('selarrrow'), function (index, ele) { ids += "," + ele; })
		return ids.replace(",", "");
	},

	RemoveFromResourcingQueueEnabled: function () { return orNs.HasQueueRowSelected(); },
	GoToResourceSearch: function () {
		rm.ui.dialog.showWaitModalWithNoClose("Opening Search Page");
		document.location = '/_Layouts/SPUI/Requests/ResourceSearch.aspx';
	},

	GoToResourceSearchEnabled: function () { return true; },

	RemoveFromQueue: function () {
		if (orNs._onSaving) return;

		orNs._onSaving = true;
		orNs._ajaxErrors = false;
		orNs._source = 'queue';

		var selectedrows = $("#queue").getGridParam('selarrrow');
		if (selectedrows.length == 0) { rm.ui.messages.addError("No requests in queue selected.", true); }
		var success = false;
		var error = false;

		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.requestSvcUrl + "RequestQueue/Remove",
			data: JSON.stringify({ listOfIds: orNs.GetSelectedIds() }),
			dataType: "json",
			success: function (result) { },
			error: function (errMsg) {
				orNs._ajaxErrors = true;
			}
		});
	},

	GetFilterValues: function () {
		if (GetRmPageLinkId() == RmPageLink_E.OverDue_All_OpenResourceRequests)
			return rm.grid.filterOptions.iconSearch_OpenRequestsOverdue;
		else
			return rm.grid.filterOptions.iconSearch_OpenRequestsAll;
	},
	BuildGrid: function () {
		var gridPost = { RmPageLink: GetRmPageLinkId(), SummaryList: 0 };
		var gridSelector = "#list";
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = gridPost;
		rm.grid.showGridTools(gridSelector, gridToolsConfig);

		$(gridSelector).jqGrid({
		    url: rm.ajax.requestSvcUrl + "GetOpenResourceRequests",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false, 'OpenRequest/List'),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			postData: gridPost,
			loadonce: false,
			pager: '#listPager',
			height: rm.ui.getMaxGridHeight() - 10,
			width: rm.ui.getMaxGridWidth(),
			multiselect: true,
			viewsortcols: [true, 'vertical', true],
			sortname: 'Country',
			autowidth: true,
			shrinkToFit: false,
			forceFit: true,
			jsonReader: rm.grid.getJqGridJsonReader(),
			colModel: [
				{ name: 'Region', index: 'Region', label: 'Region', resizable: true, width: 50, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'Country', index: 'Country', label: 'Country', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'Message', index: 'Message', label: ' ', width: 20, search: false, classes: 'ui-ellipsis', formatter: orNs.DrawIndicator, formatoptions: {} },
				{ name: 'IconColumn', index: 'IconColumn', label: 'Request<br/>Status <br />Indicator', width: 60, search: true, sortable: false, hidden: false, stype: 'select', searchoptions: { sopt: ['cn'], value: orNs.GetFilterValues() } },
				{ name: 'CountryRegion', index: 'CountryRegion', label: 'Country<br/>Region', width: 80, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 50 } } },
				{ name: 'Sponsor', index: 'Sponsor', label: 'Customer', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'Program', index: 'Program', label: 'Program', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project<br/>Code', width: 65, search: true, searchoptions: { attr: { sopt: ['cn'], maxlength: 255 } } },
				{ name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'StaffRole', index: 'StaffRole', label: 'Request Group', width: 200, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'ProjectDteType', index: 'ProjectDteType', label: 'RBM <br/>Project', width: 50, search: true, searchoptions: { sopt: ['cn'], attr: { maxlength: 7 } } },
        { name: 'Organization', index: 'Organization', label: 'Organization', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'TherapeuticAreaName', index: 'TherapeuticAreaName', label: 'Therapeutic Area', width: 200, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'SitesBudgeted', index: 'SitesBudgeted', label: 'Request<br/>Counts', width: 65, search: true, searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
				{ name: 'NeedDate', index: 'NeedDate', label: 'Need by<br/>Date', width: 80, search: true, searchoptions: { attr: { maxlength: 11 } } },
				{ name: 'SubmittedDateRange', index: 'SubmittedDateRange', label: 'Submitted Date Range', width: 200, searchoptions: { sopt: ['cn'], attr: { sopt: ['cn'], maxlength: 25 } } },
				{ name: 'HiddenJson', index: 'HiddenJson', label: '', hidden: true },
			],
			caption: 'Open Resource Requests',
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("list"); },
			onSelectRow: function (id) { orNs.CheckGridRows(); },
			onSelectAll: function (rowIdxArray, sts) { orNs.CheckGridRows(); },
			onPaging: function () { orNs.ResetRibbonIcons(); },
			serializeRowData: function (postData) { return JSON.stringify(postData); },
			gridComplete: function () { },
			serializeGridData: rm.grid.serializeGridData,
			loadComplete: function (data) {
				rm.grid.addTitlesOnIconColumn();
				rm.grid.rowData.attachAllRowsData("#list", data);
			}
		});
		$("#list").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},

	DrawIndicator: function (cellvalue, options, rowObject) {
		var imgId = "img" + options.rowId;
		if (cellvalue === "") {
			rm.qtip.clear("#" + imgId);
			return ' ';
		} else {
			var imgsrc = "<img id='" + imgId + "' src='/_layouts/SPUI/images/errorIcon.png' " +
                    "alt='Error' style='cursor: pointer;' " +
                    "title='" + cellvalue + "' />";
			setTimeout(function () { rm.qtip.showError("#" + imgId, cellvalue); }, 100);
			return imgsrc;
		}
	},

	BuildQueue: function () {
		var gridSelector = "#queue";
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.OpenResourceRequests, SummaryList: 1 };
		rm.grid.showGridTools(gridSelector, gridToolsConfig);

		$(gridSelector).jqGrid({
		    url: rm.ajax.requestSvcUrl + "GetResourcingWorklistSummary",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false, 'OpenRequestQueue/List'),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			postData: {},
			loadonce: true,
			pager: '#queuePager',
			height: "auto",
			width: rm.ui.getMaxGridWidth(),
			multiselect: true,
			autowidth: true,
			shrinkToFit: false,
			viewsortcols: [true, 'vertical', true],
			sortname: 'Region',
			jsonReader: rm.grid.getJqGridJsonReader(),
			colModel: [
						{ name: 'Region', index: 'Region', label: 'Region', resizable: true, width: 50, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'Country', index: 'Country', label: 'Country', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'Message', index: 'Message', label: ' ', width: 20, search: false, classes: 'ui-ellipsis' },
						{ name: 'CountryRegion', index: 'CountryRegion', label: 'Country<br/>Region', width: 80, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'Sponsor', index: 'Sponsor', label: 'Customer', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'Program', index: 'Program', label: 'Program', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project<br/>Code', width: 65, search: true, searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'StaffRole', index: 'StaffRole', label: 'Request Group', width: 200, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'ProjectDteType', index: 'ProjectDteType', label: 'RBM <br/>Project', width: 50, search: true, searchoptions: { sopt: ['cn'], attr: { maxlength: 3 } } },
            { name: 'Organization', index: 'Organization', label: 'Organization', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'TherapeuticAreaName', index: 'TherapeuticAreaName', label: 'Therapeutic Area', width: 200, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
						{ name: 'SitesBudgeted', index: 'SitesBudgeted', label: 'Request<br/>Counts', width: 65, search: true, searchoptions: { attr: { sopt: ['cn'], sopt: ['cn'], maxlength: 255 } } },
						{ name: 'NeedDate', index: 'NeedDate', label: 'Need by<br/>Date', width: 80, search: true, sorttype: function (cellValue, rowObject) { return rowObject.NeedDateSort; }, searchoptions: { attr: { maxlength: 11 } } },
						{ name: 'SubmittedDateRange', index: 'SubmittedDateRange', label: 'Submitted Date Range', width: 200, sorttype: function (cellValue, rowObject) { return rowObject.SubmittedDateRangeSort; }, searchoptions: { sopt: ['cn'], attr: { maxlength: 25 } } },
						{ name: 'NeedDateSort', index: 'NeedDateSort', label: ' ', sorttype: 'date', hidden: true },
						{ name: 'SubmittedDateRangeSort', index: 'SubmittedDateRangeSort', label: ' ', sorttype: 'date', hidden: true }
			],
			hiddengrid: true,
			caption: 'Resourcing Worklist - Summary',
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("queue"); },
			onSelectRow: function (id) { orNs.CheckGridRows(); },
			onSelectAll: function (rowIdxArray, sts) { orNs.CheckGridRows(); },
			onPaging: function () { orNs.ResetRibbonIcons(); },
			serializeRowData: function (postData) { return JSON.stringify(postData); },
			serializeGridData: rm.grid.serializeGridData,
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData("#queue", data); }
		});
		$("#queue").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},

	bindLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn("#list_Country", "May be the preferred resource location or the country where the study is taking place.");
		rm.qtip.showInfoOnGridColumn("#list_CountryRegion", "The region within the country.");
		rm.qtip.showInfoOnGridColumn("#list_Sponsor", "Customer.");
		rm.qtip.showInfoOnGridColumn("#list_Program", "Program.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectCode", "Project Code.");
		rm.qtip.showInfoOnGridColumn("#list_Protocol", "Protocol.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectDteType", "RBM Project");
		rm.qtip.showInfoOnGridColumn("#list_Organization", "Project Organization.");
		rm.qtip.showInfoOnGridColumn("#list_TherapeuticAreaName", "Request's Project's Therapeutic Area.");
		rm.qtip.showInfoOnGridColumn("#list_SitesBudgeted", "Each of this grid's rows represents a group of requests (one or more), categorized and counted here as three numbers - a/b/c:<br/><ol type='a' style='padding:10px 0px 0px 20px;'><li>Budgeted Sites - Sourced from the 'Total Sites Open' metric in CTMS if non-zero, otherwise initially from budget on Project Award.<br/></li><li>Total number of Unassigned Submitted requests which are ready for resourcing in system<br/></li><li>Total number of Resourced requests (Both Hard and Soft Booked)</li></ol>");
		rm.qtip.showInfoOnGridColumn("#list_StaffRole", "Request Group.");
		rm.qtip.showInfoOnGridColumn("#list_NeedDate", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn("#list_SubmittedDateRange", "Earliest to last submitted date");

		rm.qtip.showInfoOnGridColumn("#queue_Country", "May be the preferred resource location or the country where the study is taking place.");
		rm.qtip.showInfoOnGridColumn("#queue_CountryRegion", "The region within the country.");
		rm.qtip.showInfoOnGridColumn("#queue_Sponsor", "Customer.");
		rm.qtip.showInfoOnGridColumn("#queue_Program", "Program.");
		rm.qtip.showInfoOnGridColumn("#queue_ProjectCode", "Project Code.");
		rm.qtip.showInfoOnGridColumn("#queue_Protocol", "Protocol.");
		rm.qtip.showInfoOnGridColumn("#queue_ProjectDteType", "RBM Project");
		rm.qtip.showInfoOnGridColumn("#queue_Organization", "Therapeutic Delivery Unit.");
		rm.qtip.showInfoOnGridColumn("#queue_TherapeuticAreaName", "Request's Project's Therapeutic Area.");
		rm.qtip.showInfoOnGridColumn("#queue_SitesBudgeted", "Each of this grid's rows represents a group of requests (one or more), categorized and counted here as three numbers - a/b/c:<br/><ol type='a' style='padding:10px 0px 0px 20px;'><li>Budgeted Sites - Sourced from the 'Total Sites Open' metric in CTMS if non-zero, otherwise initially from budget on Project Award.<br/></li><li>Total number of Unassigned Submitted requests which are ready for resourcing in system<br/></li><li>Total number of Resourced requests (Both Hard and Soft Booked)</li></ol>");
		rm.qtip.showInfoOnGridColumn("#queue_StaffRole", "Request Group.");
		rm.qtip.showInfoOnGridColumn("#queue_NeedDate", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn("#queue_SubmittedDateRange", "Earliest to last submitted date");
	}
}