﻿/// <reference path="../common/rmhelper.js" />
var _bAcceptSoftBookingButtonEnabled = false;
var _bRejectSoftBookingButtonEnabled = false;
var _oCurrentSelRes = null; // current Resource Selected and charted. Format: { resourceID: id, resourceTitle: namePlusQId }

var selectedId = null;
var isUserHasLMRestrictedRole;
var _onlyMissingAttributes = false;
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });

	rm.qtip.showInfo("[id$=_CompetencyBandReports]", "Download an Excel report of resources' Competency Bands and the SPM Classifications of their assignments.");
	rm.qtip.showInfo($('#imgSAAllocationHelp'), "Enter the proportion of this resource's time that this Special Assignment will utilize, in the range 1 - 100.<br/><br/><b>e.g. 1:</b> For a part time employee contracted to work 20 hours a week, at an expected 85% Utilization, being assigned to a Special Assignment requiring 17 hours per week, enter 100%.<br/><br/><b>e.g. 2:</b> For a part time employee contracted to work 20 hours a week, at an expected 85% Utilization, being assigned to a Special Assignment requiring 8.5 hours per week, enter 50%.<br/><br/><pre>                         Special Assignment Hours X 100<br/>% Allocation = ---------------------------------------------------------<br/>                       Capped Contract Hours X Utilization</pre>", { width: "300px" });

	$(myStaffNs.ribbonButtonSelector_EditResources).hide();
	$("#MyLinks_MyStaff").addClass("left-static-selected-menu");

	SetUserDetails();
	_onlyMissingAttributes = (GetRmPageLinkId() == RmPageLink_E.IncompleteResourceAttributes);
	buildGrid();

	$("#divResourceProfile,#divResourceHardBookings").width(rm.ui.getContentContainerWidth() - 50);
	$("#divResourceProfile").accordion({ collapsible: true, active: 0 });
	$("#divResourceHardBookings").accordion({ collapsible: true, active: 0 });

	rm.ui.ribbon.refresh();

	rm.grid.bindEventsToResizeGrid("#list", "#listAssignment");
	bindLabelQtip();
	rm.qtip.showInfo($('#paraProjectCodeNA'), "Enter 'NA' (without the quote characters) in the Project Code field for work which is 'Not Applicable' to any Project.", { width: '250px' });
	ShowPastAssignments();
});

function ShowPastAssignments() {
	$('#cbShowPastAssignments').change(function () {
		handleMyStaffResourceRowSelection($(this).is(':checked'));
	});
}
function SetUserDetails() {
	isUserHasLMRestrictedRole = (typeof searchCodeValues === "undefined") ? false : searchCodeValues.isUserHasLMRestrictedRole;
};
function AcceptSoftBookingButtonEnabled() { return _bAcceptSoftBookingButtonEnabled; };

function RejectSoftBookingButtonEnabled() { return _bRejectSoftBookingButtonEnabled; };

function buildGrid() {
	var gridSelector = "#list";
	var gridToolsParentContainerSelector = "#myStaffGridToolsParent";
	var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
	gridToolsConfig.showManageColumns = false;
	gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.MyStaff };
	var gridPost = rm.grid.getGridFilterFromCookieAndSetGridFilterTextboxes(gridSelector, rm.constants.keys.cookie.MyStaffGridFilter);
	rm.grid.showGridToolsV2(gridToolsParentContainerSelector, RmPageLink_E.MyStaff, DataGrid.MyStaff, gridSelector, null, gridPost.selectedRowFilterId, false);

	$(gridSelector).jqGrid({
		url: rm.ajax.resourceSvcUrl + "GetResourcesByCurrentUser",
		datatype: 'json',
		mtype: 'POST',
		postData: { OnlyMissingAttributes: _onlyMissingAttributes },
		ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
		loadonce: false,
		pager: '#gridPager',
		multiselect: true,
		viewsortcols: [true, 'vertical', true],
		sortname: 'Name',
		sortable: true,
		ignoreCase: true,
		autowidth: true,
		shrinkToFit: false,
		height: rm.ui.getMaxGridHeight() - 10,
		width: rm.ui.getMaxGridWidth(),
		jsonReader: rm.grid.getJqGridJsonReader(),
		colModel: [
			rm.grid.standardColumns.getMessageColumnWithJsonData(false),
			{ name: 'Qid', index: 'Qid', label: 'QID', resizable: true, width: 60 },
			{ name: 'Name', index: 'Name', label: 'Name', width: 125, search: true, classes: 'ui-ellipsis' },
			{ name: 'JobTitle', index: 'JobTitle', label: 'Job Title', width: 100, classes: 'ui-ellipsis' },
			{ name: 'Office', index: 'Office', label: 'Office', resizable: true, width: 60, classes: 'ui-ellipsis' },
			{ name: 'Status', index: 'Status', label: 'Status', resizable: true, width: 60, align: 'center' },
			{ name: 'ContractHours', index: 'ContractHours', label: 'Capped<br/>Contract Hrs', resizable: true, formatter: myStaffNs.renderContractHours, width: 85, sorttype: 'int', align: 'center' },
			{ name: 'City', index: 'City', label: 'Home City', width: 95, classes: 'ui-ellipsis' },
			{ name: 'StateProvince', index: 'StateProvince', label: 'Home<br/>ST/Prov', width: 75 },
			{ name: 'Country', index: 'Country', label: 'Work<br/>Country', width: 75, formatter: myStaffNs.renderCountry },
			{ name: 'Notes', index: 'Notes', label: 'Notes', sortable: false, align: 'center', width: 50, search: false },
			{ name: 'ManagerName', index: 'ManagerName', label: 'Line Manager', width: 125, search: true, classes: 'ui-ellipsis' },
			{ name: 'Organization', index: 'Organization', label: 'Organization', width: 119 },
			{ name: 'OrganizationalUnit', index: 'OrganizationalUnit', label: 'Organizational<br/>Unit', width: 100 },
			{ name: 'JobRole', index: 'JobRole', label: 'Job Role', width: 75 },
			{ name: 'PreferredSponsor', index: 'PreferredSponsor', label: 'Preferred Sponsor<br/>(if applicable)', width: 120, sortable: false, search: false },
			{ name: 'CompetencyBand', index: 'CompetencyBand', label: 'Competency<br/>Band', width: 100 },
			{ name: 'ResourceTmfPlatform', index: 'ResourceTmfPlatform', label: 'Resource<br/>TMF Platforms', width: 250, sortable: false, search: false },
			{ name: 'ResourceRequestTypes', index: 'ResourceRequestTypes', label: 'Resource Request<br/>Types', width: 250, sortable: false, search: false },
			{ name: 'TherapeuticAreas', index: 'TherapeuticAreas', label: 'ELVIS Therapeutic <br/>Area(s)', width: 250, sortable: false, search: false }
		],
		caption: 'My Staff',
		beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
		serializeGridData: function (postData) {
			var data = null;
			return rm.grid.serializeGridData(postData, data);
		},
		gridComplete: function () {
			rm.grid.setHeaderRowHeightDoubleLine("list");
			rm.ui.notes.bindNotesIconClick();
			AddResourceAttributeFilterCheckbox();

			$.each($(".imgContractHourWarning"), function (index, element) {
				var objEle = $(element);
				var toolTipText = "1. Resource's Contract Hours: " + objEle.attr("OriginalContractHours") +
					"<br>2. Country Hours: " + objEle.attr("ContractHours") +
					"<br>3. Capped Hours: " + objEle.attr("ContractHours");
				rm.qtip.showInfo(objEle, toolTipText);
				objEle.closest("td").css({ backgroundColor: "#FFBBCC" });
			});

			$.each($(".imgWorkHomeCountryDiffWarning"), function (index, element) {
				var objEle = $(element);
				var toolTipText = "Resource's Work Country: " + objEle.attr("Country") +
					"<br>Home Country: " + (objEle.attr("HomeCountry") || "Not supplied in HR feed");
				rm.qtip.showInfo(objEle, toolTipText);
				objEle.closest("td").css({ backgroundColor: "#FFBBCC" });
			});
		},
		beforeSelectRow: function (id, e) { return true; },
		onSelectRow: function (id, status) {
			$('#cbShowPastAssignments').prop('checked', false);
			handleMyStaffResourceRowSelection(false);
			var isAllCheckBoxSelected = true;
			$("input[id^='jqg_list_']").each(function (i, el) {
				if (el.checked == false)
					isAllCheckBoxSelected = false;
			});

			if (!isAllCheckBoxSelected) {
				if ($('#cb_list').prop("checked")) {
					$("#cb_list").prop("checked", false);
				}
			}
		},
		onSelectAll: function (id, status) {
			$('#cbShowPastAssignments').prop('checked', false);
			handleMyStaffResourceRowSelection(false);
		}
	});
	$("#list").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
};

function handleMyStaffResourceRowSelection(showPastAssignments) {
	var currentCheckedRows = $("#list").getGridParam('selarrrow');
	var currentCheckedRowCount = currentCheckedRows.length;

	if (currentCheckedRowCount == 0) {

		$("#divResourceProfile,#divResourceHardBookings,#divAssignmentGrid,#divShowPastAssignments").hide();
		$(myStaffNs.ribbonButtonSelector_EditResources).hide();
		$(myStaffNs.ribbonButtonSelector_EditResource).show();

		rm.ui.ribbon.delayedRefresh();

		return true;
	}
	else if (currentCheckedRowCount == 1) {
		selectedId = currentCheckedRows[0];
		var resourceName = $("#list").getCell(selectedId, "Name");
		$("#txtResourceName").html(resourceName);
		$("#txtHoursPerMonth").html("");

		$(myStaffNs.ribbonButtonSelector_EditResources).hide();
		$(myStaffNs.ribbonButtonSelector_EditResource).show();

		$("#listAssignment").jqGrid("GridUnload");
		$("#divAssignmentGrid").show();//SD:rendering grid with auto width calculates incorrect width
		$("#divShowPastAssignments").show();
		setTimeout(function () {
			buildGridAssignment($("#list").getCell(selectedId, "Name"), selectedId, showPastAssignments);
			rm.ui.openCollapsiblePanel('#divResourceProfile');
		}, 20);

		setTimeout(function () {
			var chartHeading = 'Name:' + resourceName + ' QID:' + $("#list").getCell(selectedId, "Qid");
			_oCurrentSelRes = { resourceId: selectedId, chartHeading: chartHeading + " - All Allocations" };
			$("#divResourceProfile,#divResourceHardBookings").show(); // show chart that we are going to build
			rmChart.showMyStaffChart(rmChart.chartType.MyStaff, _oCurrentSelRes, 'divChartResourceCont', 'aResourceProfile', false);

			_oCurrentSelRes = { resourceId: selectedId, chartHeading: chartHeading + " - Hard-Booked Allocation(s)" };
			$("#spnFteHardBookings").attr("rm_resourceId", selectedId);
			$("#spnHoursHardBookings").attr("rm_resourceId", selectedId);

			rmChart.clearMyStaffHardBookingChartSeries();
			rmChart.showMyStaffHardBookingsChart(rmChart.chartType.MyStaffHardBookings, _oCurrentSelRes, 'divChartResourceHardBoolingCont', 'aResourceHardBookingProfile', false);
		}, 50);

		rm.ui.ribbon.delayedRefresh();
	}
	else if (currentCheckedRowCount > 1) {

		$(myStaffNs.ribbonButtonSelector_EditResources).show();
		$(myStaffNs.ribbonButtonSelector_EditResource).hide();

		$("#divResourceProfile,#divResourceHardBookings,#divAssignmentGrid,#divShowPastAssignments").hide();

		rm.ui.ribbon.delayedRefresh();
	}
}

function AddResourceAttributeFilterCheckbox() {
	if (_onlyMissingAttributes)
		$("#gbox_list").find('.ui-search-toolbar').find('th')[1].innerHTML = "<input id='chkFilterData' type='checkbox' checked='" + _onlyMissingAttributes + "' />";
	else
		$("#gbox_list").find('.ui-search-toolbar').find('th')[1].innerHTML = "<input id='chkFilterData' type='checkbox' />";

	$("#chkFilterData").click(function () {
		_onlyMissingAttributes = !_onlyMissingAttributes;
		$('#list').GridUnload();
		buildGrid();
		$("#cb_list").hide();
		setTimeout(function () {
			$("#chkFilterData").prop('checked', _onlyMissingAttributes);
		}, 100);
	});
}

function buildGridAssignment(assignmentName, resourceId, showPastAssignments) {
	$("#aResourceProfile").html("<b>" + assignmentName + " Resource Profile</b>");
	$("#listAssignment").jqGrid({
		url: rm.ajax.resourceSvcUrl + "GetMyStaffAssignment",
		datatype: 'json',
		postData: { ResourceId: resourceId, AssignmentType: $("#gs_AssignmentType").val(), ShowPastAssignments: showPastAssignments },
		mtype: 'POST',
		ajaxGridOptions: rm.grid.getJqGridAjaxOptions(true, 'GetResourcesByCurrentUser'), // VG: handle error
		loadonce: false,
		pager: '#gridPagerAssignment',
		multiselect: true,
		viewsortcols: [true, 'vertical', true],
		sortname: 'Name',
		ignoreCase: true,
		autowidth: true,
		shrinkToFit: false,
		height: 200,
		forceFit: true,
		jsonReader: rm.grid.getJqGridJsonReader(),
		caption: assignmentName + " Assignments",
		colModel: [
			{ name: 'HiddenJSON', index: 'HiddenJSON', hidden: true },
			{
				name: 'Message', index: 'Message', label: ' ', width: 15, hidden: true, search: false, sortable: false,
				formatter: rm.grid.drawIndicator, formatoptions: {}
			},
			{ name: 'AssignmentIndicator', index: 'AssignmentIndicator', label: 'Assignment<br />Indicator', resizable: false, width: 90, sortable: false, search: false },
			{
				name: 'AssignmentType', index: 'AssignmentType', label: 'Assignment Type', resizable: false, width: 145,
				stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.assignmentType }
			},
			{ name: 'CountryName', index: 'CountryName', label: 'Country', width: 125, search: true, classes: 'ui-ellipsis' },
			{ name: 'ProgramName', index: 'ProgramName', label: 'Program', width: 100, classes: 'ui-ellipsis' },
			{
				name: 'SpecialAssignmentCategoryId', index: 'SpecialAssignmentCategoryId', label: 'Category', resizable: true, width: 230,
				stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.getFiltersFromDictionary(SpecialAssignmentCategories) }
			},
			{ name: 'SpecialAssignmentProjectCode', index: 'SpecialAssignmentProjectCode', label: 'Special<br/>Assignment<br/>Project', resizable: true, width: 90, sortable: true, search: true },
			{ name: 'AssignmentDescription', index: 'AssignmentDescription', label: 'Assignment<br />Description', resizable: true, width: 120 },
			{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project', resizable: true, width: 60, classes: 'ui-ellipsis' },
			{ name: 'AssignmentId', index: 'AssignmentId', label: 'Assignment<br />Id', resizable: true, width: 120, hidden: true },
			{ name: 'Sponsor', index: 'Sponsor', label: 'Sponsor', resizable: true, width: 220 },
			{ name: 'SiteId', index: 'SiteId', label: 'Site ID', resizable: true, width: 220, sorttype: 'int' },
			{ name: 'AccountName', index: 'AccountName', label: 'Account Name', width: 120, classes: 'ui-ellipsis' },
			{ name: 'ResourceType', index: 'ResourceType', label: 'Resource<br />Request Type', width: 120, classes: 'ui-ellipsis' },
			{ name: 'StartDate', index: 'StartDate', label: 'Start Date', width: 80 },
			{ name: 'StopDate', index: 'StopDate', label: 'Stop Date', width: 80 },
			{ name: 'SpecialAssignmentAllocation', index: 'SpecialAssignmentAllocation', label: 'Special<br/>Assignment<br/>% Allocation', width: 90, sortable: false, search: false, align: 'center' },
			{ name: 'FTE', index: 'FTE', label: 'FTE', width: 30, sortable: false, search: false, align: 'center', cellsformat: 'F3' },
			{ name: 'Notes', index: 'Notes', label: 'Notes', sortable: false, align: 'center', width: 50, search: false },
			{ name: 'RequestId', index: 'RequestId', label: 'RequestId', sortable: true, width: 70, search: true },
			{ name: 'allowModify', index: 'allowModify', label: 'Allow<br />Modify', hidden: true },
			{ name: 'SpecialAssignmentProjectCodeInRm', index: 'SpecialAssignmentProjectCodeInRm', hidden: true }
		],
		beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
		serializeGridData: rm.grid.serializeGridData,
		gridComplete: function () {
			rm.grid.addTitlesOnIconColumn();
			$("#cb_listAssignment").hide();
			rm.ui.notes.bindNotesIconClick();
			myStaffNs.bindFTECalculatorClick();
			EnableSoftBookingButton();
			rm.qtip.showInfoOnGridColumn("#jqgh_listAssignment_StopDate", "Assignments to requests terminated more than six months ago are not included.");
		},
		loadComplete: function (data) { rm.grid.rowData.attachAllRowsData(myStaffNs.assignmentGridSelector, data); },

		onSelectRow: function (id, status) {
			EnableSoftBookingButton();
			rm.ui.ribbon.refresh();
		}
	});
	$("#listAssignment").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
};

function EnableSoftBookingButton() {
	var grid = $("#listAssignment");
	var ids = grid.getGridParam('selarrrow');
	var rejectedBookingSelected = false;
	var selectionsAreAllSoftBookings = true;

	for (var i = 0, il = ids.length; i < il; i++) {
		var jsonObject = $.parseJSON(grid.getCell(ids[i], 'HiddenJSON'));

		if (jsonObject.wasBookingRejected) {
			rejectedBookingSelected = true;
			break;
		}
		if (jsonObject.requestStatus != RequestStatusName.Pending) {
			selectionsAreAllSoftBookings = false;
			break;
		}
	}

	if (ids.length > 0 && selectionsAreAllSoftBookings && !rejectedBookingSelected) {
		_bRejectSoftBookingButtonEnabled = true;
	}
	else {
		_bRejectSoftBookingButtonEnabled = false;
	}

	if (rm.grid.hasSingleRowSelected("#listAssignment") && !rejectedBookingSelected) {
		jsonObject = $.parseJSON(grid.getCell($("#listAssignment").getGridParam('selarrrow')[0], 'HiddenJSON'));
		_bAcceptSoftBookingButtonEnabled = (jsonObject.requestStatus == RequestStatusName.Pending);
	}
	else {
		_bAcceptSoftBookingButtonEnabled = false;
	}

	rm.ui.ribbon.refresh();
};

function GetFirstSelectedRow() {
	var ids = $("#listAssignment").getGridParam('selarrrow');
	var IdOfFirstSelectedRow = "";
	for (var i = 0, il = ids.length; i < il; i++) {
		IdOfFirstSelectedRow = ids[i];
		break;
	}
	return $.parseJSON($("#listAssignment").getCell(IdOfFirstSelectedRow, 'HiddenJSON'));
};

function AcceptSoftBooking() {
	var selectedrows = $(myStaffNs.assignmentGridSelector).getGridParam('selarrrow');
	var assignmentId = selectedrows[0];

	var jsonObject = GetFirstSelectedRow();
	if (jsonObject.requestStatus == RequestStatusName.Pending && jsonObject.requestType == RequestType_E.Proposal && !confirm(Resources.CanAttendBidDefense + " If Yes Press OK. If No Press Cancel.")) {
		$.ajax({
			url: "/_Layouts/SPUI/Requests/BidDefenseDialog.aspx?source=MyStaff",
			type: "POST",
			success: function (data) {
				var container = $("#dialogBidDefense");
				if (container.length == 0) {
					container = $("<div id='dialogBidDefense' />");
					$('body').append(container);
				}
				container.html(data).dialog({
					modal: true,
					cache: false,
					title: "Select reason",
					resizable: false,
					width: 350,
					height: 200
				});
			},
			error: function (x, e) {
				alert(x.responseText);
			}
		});
	}
	else {
		SubmitBooking({ CanAttendBidDefense: true });
	}
};

function SubmitBooking(bidDefenseReson) {
	$('#listAssignment').hideCol("Message");
	rm.grid.clearGridError("#listAssignment", 'Message');
	var postData = { resourceRequestAssignmentId: rm.grid.getSelectedIds("#listAssignment"), bidDefenseResult: bidDefenseReson };
	$.ajax({
		type: "POST",
		contentType: "application/json; charset=utf-8",
		url: rm.ajax.requestSvcUrl + "AcceptSoftBooking",
		dataType: "json",
		data: JSON.stringify(postData),
		success: function (data) {
			if (data.IsSuccessful) {
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showSuccess('Request assigned successfully.');
				setTimeout(function () { window.location.href = window.location.href; }, 2000);
				$("#listAssignment").trigger("reloadGrid");
				$.q.RebindQtip("#listAssignment");
			}
			else {
				$('#listAssignment').setCell(postData.resourceRequestAssignmentId, 'Message', data.Message);
				$('#listAssignment').showCol("Message");
			}
			rm.serviceCalls.getRequestCounts();
		},
		error: function (x, e) {
			alert(x.responseText);
			rm.ui.messages.addError('Failed to hard book the resource.');
		}
	});
};

function RejectSoftBooking() {
	try {
		$.ajax({
			url: "/_Layouts/SPUI/Requests/RejectSoftBookingDiaglog.aspx",
			type: "POST",
			success: function (data) {
				var container = $("#dialogRejectSoftBooking");
				if (container.length == 0) {
					container = $("<div id='dialogRejectSoftBooking' />");
					$('body').append(container);
				}
				container.html(data).dialog({
					modal: true,
					cache: false,
					title: "Reject Booking",
					resizable: false,
					width: 435,
					height: 170
				});
			},
			error: function (x, e) {
				alert(x.responseText);
			}
		});
	}
	catch (e) {
		alert(e.Description);
	}
};

function RejectBooking(rejectNotes) {
	$('#listAssignment').hideCol("Message");
	rm.grid.clearGridError("#listAssignment", 'Message');
	var postData = { selectedSoftBookingIds: $("#listAssignment").getGridParam('selarrrow'), rejectedNotes: rejectNotes };
	$.ajax({
		type: "POST",
		contentType: "application/json; charset=utf-8",
		url: rm.ajax.requestSvcUrl + "RemoveSoftBookings",
		dataType: "json",
		data: JSON.stringify(postData),
		success: function (data) {
			$.each(data, function (index, element) {
				if (element.IsSuccessful) {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess('Rejected successfully.');
					setTimeout(function () { window.location.href = window.location.href; }, 2000);
				}
				else {
					$('#listAssignment').setCell(element.EntityId, 'Message', element.Message);
					$('#listAssignment').showCol("Message");
				}
			});

			$("#listAssignment").trigger("reloadGrid");
			$.q.RebindQtip("#listAssignment");

			rm.serviceCalls.getRequestCounts();
		},
		error: function (x, e) {
			alert(x.responseText);
			rm.ui.messages.addError('Failed to hard book the resource.');
		}
	});
};

bindLabelQtip = function () {
	rm.qtip.showInfoOnGridColumn("#list_Qid", "QID");
	rm.qtip.showInfoOnGridColumn("#list_Name", "Name of the direct report.");
	rm.qtip.showInfoOnGridColumn("#list_JobTitle", "Job Title");
	rm.qtip.showInfoOnGridColumn("#list_Office", "Office");
	rm.qtip.showInfoOnGridColumn("#list_Status", "Employment status at Quintiles.");
	rm.qtip.showInfoOnGridColumn("#list_ContractHours", "Number of weekly hours in employee's contract.");
	rm.qtip.showInfoOnGridColumn("#list_City", "Home City");
	rm.qtip.showInfoOnGridColumn("#list_StateProvince", "Home State / Province");
	rm.qtip.showInfoOnGridColumn("#list_Country", "Resource's Work Country - highlighted where different from Home Country.");
	rm.qtip.showInfoOnGridColumn("#list_Notes", "Notes");
	rm.qtip.showInfoOnGridColumn("#list_ResourceRequestTypes", "Resource Request Types that this Resource can fulfill.");
	rm.qtip.showInfoOnGridColumn("#list_CompetencyBand", "Competency Band.");
};

var myStaffNs = {
	resourceGridSelector: "#list",
	assignmentGridSelector: "#listAssignment",
	ribbonButtonSelector_EditResource: "a[id$=EditResource]",
	ribbonButtonSelector_EditResources: "a[id$=EditResources]",
	rmUserIsAdminOrRCA: $("[id*=hdnRmUserIsAdminOrRCA]").val(),
	rmUserqId: $("[id*=hdnrmUserqId]").val(),
	isCreateBackfillEnabled: function () { return myStaffNs.areAllSelectedRequestsHardBooked(); },
	allowHardBooking: function () { return $("[id$=hdnAllowHardBooking]").val() == "1"; },
	getSelectedResourceDetailsArray: function () {
		var selectedResourceIds = rm.grid.getSelectedIdArray(myStaffNs.resourceGridSelector);
		var selectedResourceDetailsArray = [];
		if (Array.isArray(selectedResourceIds)) {
			selectedResourceIds.forEach(function (resourceId) {
				selectedResourceDetailsArray.push({
					resourceId: resourceId,
					resourceName: $(myStaffNs.resourceGridSelector).getCell(resourceId, "Name")
				});
			});
		}
		return selectedResourceDetailsArray;
	},
	showSpecialAssignmentDialog: function (createNewSpecialAssignment) {
		saNs.onSaveSuccessfulHandler = myStaffNs.reloadAssignmentGridAndChart;
		var selectedSpecialAssignmentIds = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);
		if (createNewSpecialAssignment || (Array.isArray(selectedSpecialAssignmentIds) && selectedSpecialAssignmentIds.length == 1)) {
			var saDetails = {
				selectedResourceDetails: myStaffNs.getSelectedResourceDetailsArray(),
				selectedSpecialAssignment: (createNewSpecialAssignment ? {} : rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, selectedSpecialAssignmentIds[0])),
				createNewSpecialAssignment: createNewSpecialAssignment
			};
			saNs.showDialog(saDetails);
		}
		else {
			rm.ui.messages.addError("Only one Special Assignment can be modified at a time. Please select only one Special Assignment as try again.");
		}
	},
	isCreateSpecialAssignmentButtonEnabled: function () { return rm.grid.hasRowsSelected(myStaffNs.resourceGridSelector); },
	isModifySpecialAssignmentButtonEnabled: function () {
		return rm.grid.hasSingleRowSelected(myStaffNs.resourceGridSelector) &&
			rm.grid.hasSingleRowSelected(myStaffNs.assignmentGridSelector) &&
			myStaffNs.areAllSelectedRecordsSpecialAssignments();
	},
	isDeleteSpecialAssignmentButtonEnabled: function () { return myStaffNs.areAllSelectedRecordsSpecialAssignments(); },
	isTerminateSpecialAssignmentButtonEnabled() {
		var allowSaTermination = false;
		var selectedAssignments = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);
		if (Array.isArray(selectedAssignments)) {
			$.each(selectedAssignments, function (index, assignmentRowId) {
				var rowData = rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, assignmentRowId);
				if (rowData.AssignmentId > 0) {
					if (rm.date.isQDateDateGreaterThanToday(rowData.StartDate) || rm.date.isQDateDateInPast(rowData.StopDate)) {
						allSpecialAssignments = true;
					}
					else {
						allSpecialAssignments = false;
						return false;
					}
				}
				else {
					allowSaTermination = false;
					return false;
				}
			});
		}
		return allowSaTermination;
	},
	areAllSelectedRecordsSpecialAssignments: function () {
		var allSpecialAssignments = false;
		var selectedAssignments = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);
		if (Array.isArray(selectedAssignments)) {
			$.each(selectedAssignments, function (index, assignmentRowId) {
				var rowData = rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, assignmentRowId);
				if (rowData.AssignmentId > 0) { allSpecialAssignments = true; }
				else {
					allSpecialAssignments = false;
					return false;
				}
			});
		}
		return allSpecialAssignments;
	},
	areAllSelectedRequestsHardBooked: function () {
		var allHardBooked = false;
		var selectedRows = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);
		if (Array.isArray(selectedRows)) {
			$.each(selectedRows, function (index, ele) {
				var rowJson = rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, ele);
				if (rowJson.RequestStatusId != RequestStatusName.Assigned &&
					rowJson.RequestStatusId != RequestStatusName.Backfilled) {
					allHardBooked = false;
					return false;
				}
				else { allHardBooked = true; }
			});
		}
		return allHardBooked;
	},
	editSelectedRequestEnabled: function () {
		var selectedAssignmentIds = $(myStaffNs.assignmentGridSelector).getGridParam('selarrrow');
		return selectedAssignmentIds && selectedAssignmentIds.length == 1 && $(myStaffNs.assignmentGridSelector).getCell(selectedAssignmentIds[0], 'RequestId') != "";
	},
	viewSelectedRequestEnabled: function () {
		var selectedAssignmentIds = $(myStaffNs.assignmentGridSelector).getGridParam('selarrrow');
		return selectedAssignmentIds && selectedAssignmentIds.length == 1 && $(myStaffNs.assignmentGridSelector).getCell(selectedAssignmentIds[0], 'RequestId') != "" && isNaN($(myStaffNs.assignmentGridSelector).getCell(selectedAssignmentIds[0], 'FTE'));
	},
	bindFTECalculatorClick: function () {
		if (isUserHasLMRestrictedRole != true) {
			$(".calcImage").click(function () {
				if ($(this).attr("allowModify") == "True") {
					myStaffNs.editRequest($(this).attr("requestId"), $(this).attr("assignmentId"));
				}
				else {
					alert(Resources.AllowModifyMessage);
				}
			});
		}
		else {
			$(".calcImage").click(function () {
				myStaffNs.viewRequest($(this).attr("requestId"), $(this).attr("assignmentId"));
			});
		}
	},
	viewSelectedRequest: function () {
		var selectedrows = $(myStaffNs.assignmentGridSelector).getGridParam('selarrrow');
		if (selectedrows.length > 1) {
			alert("Can only edit one request at a time.");
			return false;
		}

		if (selectedrows.length == 0) {
			alert("No request selected.");
			return false;
		}

		var assignmentId = selectedrows[0];
		var requestId = $(myStaffNs.assignmentGridSelector).getCell(assignmentId, "RequestId");
		myStaffNs.viewRequest(requestId, assignmentId);
	},
	viewRequest: function (requestId, assignmentId) {
		rm.grid.uncheckAllGridRows(myStaffNs.assignmentGridSelector);
		rm.grid.checkRowById(myStaffNs.assignmentGridSelector, assignmentId);
		rm.ui.ribbon.delayedRefresh();

		if (rm.serviceCalls.isRequestValid(requestId, true, RmPageLink_E.MyStaff)) {
			var divid = "div_" + requestId;
			$.rm.requestCommon.GetReadOnlyCalculatorDetails(requestId, divid);
		}
	},
	editSelectedRequest: function () {
		var selectedrows = $(myStaffNs.assignmentGridSelector).getGridParam('selarrrow');
		$.validationHelper.GetCustomeMilestoneStatus(selectedrows.join(","), "", false, false);

		if (selectedrows.length > 1) {
			alert("Can only edit one request at a time.");
			return false;
		}

		if (selectedrows.length == 0) {
			alert("No request selected.");
			return false;
		}

		if (!($(myStaffNs.assignmentGridSelector).getCell(selectedrows[0], "allowModify") == "true")) {
			alert(Resources.AllowModifyMessage);
			return false;
		}

		var assignmentId = selectedrows[0];
		var requestId = $(myStaffNs.assignmentGridSelector).getCell(assignmentId, "RequestId");
		myStaffNs.editRequest(requestId, assignmentId);
	},
	editRequest: function (requestId, assignmentId) {
		rm.grid.uncheckAllGridRows(myStaffNs.assignmentGridSelector);
		rm.grid.checkRowById(myStaffNs.assignmentGridSelector, assignmentId);
		rm.ui.ribbon.delayedRefresh();

		if (rm.serviceCalls.isRequestValid(requestId, true, RmPageLink_E.MyStaff)) {
			var url = "/_layouts/SPUI/Requests/EditRequestNew.aspx?source=submitted&requestId=" + requestId + "&rmPageLink=" + RmPageLink_E.MyStaff;
			window.open(url, "_blank");
		}
	},
	isEditResourceEnabled: function () { return rm.grid.hasRowsSelected("#list"); },
	editResource: function () {
		$("#selectedResourceIds").val(rm.grid.getSelectedIds("#list"));
		var action = "RedirectToEditResource.aspx";
		$("#aspnetForm").attr("action", action);
		$("#aspnetForm").submit();
	},
	editMyOwnConfiguration: function (resourceId) {
		$("#selectedResourceIds").val(resourceId);
		var action = "RedirectToEditResource.aspx";
		$("#aspnetForm").attr("action", action);
		$("#aspnetForm").submit();
	},
	renderContractHours: function (cellvalue, options, rowObject) {
		return (rowObject.ContractHours == rowObject.OriginalContractHours) ? rowObject.ContractHours :
			rowObject.ContractHours + $("<div/>").append($("<img>", { class: 'imgContractHourWarning', src: '/_layouts/SPUI/images/warningIcon.png', ContractHours: rowObject.ContractHours, OriginalContractHours: rowObject.OriginalContractHours, css: { cursor: "pointer", paddingLeft: "5px" } })).html();
	},
	renderCountry: function (cellvalue, options, rowObject) {
		return (rowObject.Country == rowObject.HomeCountry) ? rowObject.Country :
			rowObject.Country + $("<div/>").append($("<img>", { class: 'imgWorkHomeCountryDiffWarning', src: '/_layouts/SPUI/images/warningIcon.png', Country: rowObject.Country, HomeCountry: rowObject.HomeCountry, css: { cursor: "pointer", paddingLeft: "5px" } })).html();
	},
	getResourceTypesFromSelectedRequests: function () {
		var selectedRequestIds = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);
		var selectedResourceTypeIds = [];

		selectedRequestIds.forEach(function (requestId) {
			var rowData = rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, requestId);
			if (selectedResourceTypeIds.find(function (resourceTypeId) { return resourceTypeId == rowData.ResourceTypeId; }) == null) {
				selectedResourceTypeIds.push(rowData.ResourceTypeId);
			}
		});

		return selectedResourceTypeIds;
	},
	isProposalRequestSelected: function () {
		var proposalRequestSelected = false;
		var selectedRequestIds = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);

		for (var index = 0; index < selectedRequestIds.length; index++) {
			if (rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, selectedRequestIds[index]).RequestTypeId == RequestType_E.Proposal) {
				proposalRequestSelected = true;
				break;
			}
		}
		return proposalRequestSelected;
	},
	getSelectedRequestIds: function () {
		var selectedRequetIds = [];

		var selectedRecordIds = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);

		for (var index = 0; index < selectedRecordIds.length; index++) {
			var requestId = rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, selectedRecordIds[index]).RequestId;
			if (requestId != "") { selectedRequetIds.push(requestId); }
		}

		return selectedRequetIds;
	},
	requestWithFteErrorSelected: function () {
		var requestWithFteErrorSelected = false;
		var selectedRequestIds = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);

		for (var index = 0; index < selectedRequestIds.length; index++) {
			if (rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, selectedRequestIds[index]).hasFTEError) {
				requestWithFteErrorSelected = true;
				break;
			}
		}
		return requestWithFteErrorSelected;
	},
	getProjectIdsFromSelectedRequests: function () {
		var selectedRequestIds = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);
		var selectedProjectIds = [];

		selectedRequestIds.forEach(function (requestId) {
			var rowData = rm.grid.rowData.getById(myStaffNs.assignmentGridSelector, requestId);
			if (selectedProjectIds.find(function (projectId) { return projectId == rowData.ProjectId; }) == null) {
				selectedProjectIds.push(rowData.ProjectId);
			}
		});

		return selectedProjectIds;
	},
	createBackfill: function () {
		var selectedRequetIds = myStaffNs.getSelectedRequestIds();
		var resourceTypeId = null;
		$.validationHelper.GetCustomeMilestoneStatus(selectedRequetIds.join(","), "", false, false);

		if (!$.validationHelper.isAnyMilestoneDeactivated) {
			var requestWithFteSelected = myStaffNs.requestWithFteErrorSelected();
			var proposalRequestSelected = myStaffNs.isProposalRequestSelected();
			if (requestWithFteSelected) {
				alert("You have selected one or more requests with FTE Allocation Error. These requests cannot be assigned. If you want to assign a resource, unselect request(s) with FTE allocation error and try again. If you do not want to assign a resource during backfill process, you can continue with the current selection.");
			}
			else if (proposalRequestSelected) {
				alert("You have selected one or more proposal requests. Proposal requests cannot be assigned from Submitted Request page. If you want to assign a resource, unselect proposal request(s) and try again. If you do not want to assign a resource during backfill process, you can continue with the current selection.");
			}
			var allowBooking = myStaffNs.allowHardBooking() && !proposalRequestSelected && !requestWithFteSelected;
			if (allowBooking) {
				var selectedResourceTypeIds = myStaffNs.getResourceTypesFromSelectedRequests();
				allowBooking = selectedResourceTypeIds.length == 1;
				resourceTypeId = (allowBooking ? selectedResourceTypeIds[0] : null);
			}

			var selectedProjectIds = myStaffNs.getProjectIdsFromSelectedRequests();
			var singleProjectSelected = (selectedProjectIds.length == 1);
			var projectId = singleProjectSelected ? selectedProjectIds[0] : -1;
			permBfNs.showControl(myStaffNs.assignmentGridSelector, "Resource", selectedRequetIds, allowBooking, resourceTypeId, singleProjectSelected, projectId, selectedId);
		}
	},
	deleteSpecialAssignment: function () { myStaffNs.makeDeleteOrTerminateSaCall(true); },
	terminateSpecialAssignment: function () { myStaffNs.makeDeleteOrTerminateSaCall(false); },
	makeDeleteOrTerminateSaCall: function (isDeleteCall) {
		if (!isDeleteCall || (isDeleteCall && confirm("This action will remove the Special Assignment from the system. Are you sure you want to continue? Click OK to remove the Special Assignment. Click Cancel to keep the Special Assignment."))) {
			var selectedSaIds = rm.grid.getSelectedIdArray(myStaffNs.assignmentGridSelector);
			if (Array.isArray(selectedSaIds) && selectedSaIds.length > 0) {
				var ids = "";
				selectedSaIds.forEach(function (gridRowId) { ids += "," + $(myStaffNs.assignmentGridSelector).getCell(gridRowId, "AssignmentId"); });

				var serviceMethodName = isDeleteCall ? "DeleteSpecialAssignment" : "TerminateSpecialAssignment";
				rm.ajax.resourceSvcAsyncPost(serviceMethodName, { assignmentIds: ids.replace(",", "") }, function (data) {
					if (data == "Success") {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showSuccess("Special Assignment " + (isDeleteCall ? "deleted" : "terminated") + " successfully.");
					}
					else { rm.ui.messages.addError("Failed to " + (isDeleteCall ? "deleted" : "terminated") + " one or more Special Assignments"); }

					myStaffNs.reloadAssignmentGridAndChart();
					$.q.RebindQtip(myStaffNs.assignmentGridSelector);
				});
			}
		}
	},
	reloadAssignmentGridAndChart: function () {
		var gridPost = $(myStaffNs.assignmentGridSelector).getGridParam("postData");
		rm.grid.reloadGrid(myStaffNs.assignmentGridSelector);
		setTimeout(function () {
			for (property in gridPost) {
				$("#gview_listAssignment #gs_" + property).val(gridPost[property]);
			}
		}, 10);

		// Reload Chart
		if (_oCurrentSelRes) {
			setTimeout(function () {
				//rmChart.clearChart(rmChart.chartType.MyStaff, false);//was not getting called on adding or updating SA
				rmChart.showMyStaffChart(rmChart.chartType.MyStaff, _oCurrentSelRes, 'divChartResourceCont', 'aResourceProfile', true);
			}, 50);
		}
	}
};
//total # of lines 1513 from old code