﻿/// <reference path="../common/rmhelper.js" />
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); rm.ui.ribbon.refresh(); });

	editResourceNs.initUi();
});
var editResourceNs = {
	selectOptionItemDisplayText: "--Select--",
	selectOptionItemValue: "-1",
	jobRoleSelector: "#ddlJobRole",
	organizationSelector: "#ddlOrganization",
	organizationalUnitSelector: "#ddlOrganizationalUnit",
	competencyBandSelector: "#ddlCompetencyBand",
	homeCountryTrSelector: "#trHomeCountry",
	homeCountrySelector: "#tdHomeCountry",
	workCountrySelector: "#ddlWorkCountry",
	workRegionSelector: "#ddlWorkRegion",
	isMultiEditModeSelector: "[id$=isMultiEditMode]",
	resourceIdSelector: "[id$=resourceIdList]",
	resourceTypeDivSelector: "#divResourceType",
	resourceTypeIdsSelector: "[id$=resourceTypeIds]",
	deSelectAllRRTsSelector: "[id$=deSelectAll]",
	isResourcedInRmSelector: "[id$=cbIsResourcedInRm]",
	hdnAllJapanResourcesSelector: "[id$=hdnAllJapanResources]",
	hdnHasPermissionToSeeCompetencyBandSeelctor: "[id$=hdnHasPermissionToSeeCompetencyBand]",
	cbTmfPlatformNameSelector: "[name=cbTmfPlatformName]",
	hasResourceableResourceTypesSelector: "#cbHasResourceableResourceTypes",
	rbPrimaryTmfPlatformSelector: "[name=rbPrimaryTmf]",
	cbSecondaryTmfPlatformSelector: "[name=cbSecondaryTmf]",
	cbTertiaryTmfPlatformSelector: "[name=cbTertiaryTmf]",
	tmfPlatformContainerSelector: "#trTmfPlatformContainer",
	trTmfPlatformClassSelector: ".trTmfPlatform",
	tdTmfPrimarySelector: ".tdtmfPrimary",
	tmfCtrlSelector: ".tmfCtrl",
	tmfCtrlPrimarySelector: ".tmfCtrlPrimary",
	tmfCtrlSecondarySelector: ".tmfCtrlSecondary",
	tmfCtrlTertiarySelector: ".tmfCtrlTertiary",
	txtPreferredSponsorSelector: "#txtPreferredSponsor",
	trPreferredSponsorSelector: ".trPreferredSponsor",
	txtIntendedFteSelector: "[name=txtIntendedFte]",
	tdIntendedFteResourceTypeSelector: ".tdIntendedFteResourceType",
	intendedFteTemplateRowSelector: "#trIntendedFteTemplateRow",
	tblIntendedFteSelector: "#tblIntendedFte",
	getHasResourceableResourceTypes: function () { return $(editResourceNs.hasResourceableResourceTypesSelector).prop("checked"); },
	allJapanResourcesSelected: function () { return $(editResourceNs.hdnAllJapanResourcesSelector).val() == "1"; },
	isMultiEditMode: function () { return ($(editResourceNs.isMultiEditModeSelector).val() == "1"); },
	_organizationOrganizationalList: null,
	_orgOrgUnitJobRoleHierarchy: null,
	_jobRoleList: null,
	_resourceTypeList: null,
	_competencyBandList: null,
	_resourceConfiguration: null,
	_projectSponsorList: null,
	getResourceId: function () { return $(editResourceNs.resourceIdSelector).val(); },
	getResourceIdList: function () { return $(editResourceNs.resourceIdSelector).val().split(","); },
	hasPermissionToSeeCompetencyBand: function () { return $(editResourceNs.hdnHasPermissionToSeeCompetencyBandSeelctor).val() == "1"; },
	getIsResourcedInRmValue: function () { return $(editResourceNs.isResourcedInRmSelector).prop("checked"); },
	getOrganizationalUnitId: function () {
		var organizationalUnitId = $(editResourceNs.organizationalUnitSelector).val();
		return (organizationalUnitId == -1) ? null : organizationalUnitId;
	},
	getOrganizationId: function () {
		var organizationId = $(editResourceNs.organizationSelector).val();
		return (organizationId == -1) ? null : organizationId;
	},
	getJobRoleId: function () {
		var jobRoleId = $(editResourceNs.jobRoleSelector).val();
		return (jobRoleId == -1) ? null : jobRoleId;
	},
	getCompetencyBandId: function () {
		var competencyBandId = -1;
		if ($(editResourceNs.competencyBandSelector).is(":visible")) {
			var competencyBandId = $(editResourceNs.competencyBandSelector).val();
		}
		return (competencyBandId == -1) ? null : competencyBandId;
	},
	getWorkCountryId: function () {
		var workCountryId = $(editResourceNs.workCountrySelector).val();
		return (workCountryId == -1) ? null : workCountryId;
	},
	getWorkRegionId: function () {
		var workRegionId = $(editResourceNs.workRegionSelector).val();
		return (workRegionId == -1) ? null : workRegionId;
	},
	refreshRibbonAfterDelay: function () { rm.ui.ribbon.delayedRefresh(); },
	getSelectedResourceTypeIds: function () {
		var selectedResourceTypeIds = new Array();
		$.each($(editResourceNs.resourceTypeDivSelector).fancytree("getTree").getSelectedNodes(), function (index, node) { selectedResourceTypeIds.push(parseInt(node.key)); });
		return selectedResourceTypeIds;
	},
	getResourceableResourceTypeDetails: function () {
		var resourceableResourceDetails = new Array();
		var intendedFte = null;
		$.each($(editResourceNs.resourceTypeDivSelector).fancytree("getTree").getSelectedNodes(), function (index, node) {
			if (node.selected && ResourceTypeDetails[node.key].ShowIntendedFte) {
				intendedFte = $(editResourceNs.tblIntendedFteSelector).find("tr[resourceTypeId=" + node.key + "]").closest("tr").find(editResourceNs.txtIntendedFteSelector).val();
			}
			else { intendedFte = null; }

			resourceableResourceDetails.push({
				ResourceTypeId: node.key,
				IntendedFte: (intendedFte == "") ? null : intendedFte
			});
		});
		return resourceableResourceDetails;
	},
	getPreferredSponsorValue: function () {
		if (editResourceNs.isMultiEditMode() && $(editResourceNs.txtPreferredSponsorSelector).val() == "" && $(editResourceNs.organizationSelector).val() == -1) {
			return null;
		}
		else { return $(editResourceNs.txtPreferredSponsorSelector).val(); }
	},
	setCommaSeparatedSelectedResourceTypeIds: function () {
		return $(editResourceNs.resourceTypeIdsSelector).val(editResourceNs.getSelectedResourceTypeIds().sort().join(","));
	},
	getCountryRegionHierarchy: function () { return CountriesByRegion; },
	displayResourceInformation: function () {
		if (!editResourceNs.isMultiEditMode()) {
			$(editResourceNs.homeCountryTrSelector).removeClass("hideMe");
			editResourceNs.showCurrentUserConfiguration();
			$(".mandatoryFieldMarker").removeClass("hideMe");

			editResourceNs.handleIsResourcedInRmChange();
			editResourceNs.handleHasResourceableResourceTypesChange();
		}
		else {
			editResourceNs.showValuesInDropdown(editResourceNs.organizationalUnitSelector, [], true);
			editResourceNs.handleTmfPlatformVisibility(false);
			editResourceNs.bindResourceTypeCheckboxList();
			editResourceNs.handleIntendedFteContainerVisibility();
		}
	},
	initUi: function () {
		$('#trCompetencyBand').hide();
		$("#MyLinks_MyStaff").addClass("left-static-selected-menu");
		editResourceNs.initDataList(editResourceNs.displayResourceInformation);

		$(editResourceNs.organizationSelector).change(function () { editResourceNs.handleOrganizationChange(); });
		$(editResourceNs.workRegionSelector).change(editResourceNs.handleWorkRegionChange);
		$(editResourceNs.workCountrySelector).change(editResourceNs.handleWorkCountryChange);
		$(editResourceNs.organizationalUnitSelector).change(editResourceNs.handleOrganizationalUnitChange);
		$(editResourceNs.jobRoleSelector).change(editResourceNs.handleJobRoleChange);
		$(editResourceNs.isResourcedInRmSelector).change(editResourceNs.handleIsResourcedInRmChange);
		$(editResourceNs.hasResourceableResourceTypesSelector).change(editResourceNs.handleHasResourceableResourceTypesChange);
		$(editResourceNs.competencyBandSelector).change(editResourceNs.handleCompetencyBandChange);
		$(editResourceNs.deSelectAllRRTsSelector).click(function () {
			$(editResourceNs.resourceTypeDivSelector).fancytree("getTree").visit(function (node) { node.setSelected(false); });
			return false;
		});
		$(editResourceNs.txtPreferredSponsorSelector).change(editResourceNs.refreshRibbonAfterDelay);
		$("#tblIntendedFte").on("change", editResourceNs.txtIntendedFteSelector, function () {
			var element = this;
			setTimeout(function () {
				editResourceNs.handleIntendedFteChange(element);
				editResourceNs.refreshRibbonAfterDelay;
			}, 10);
		});

		editResourceNs.enableDisableDeselectAll();
		editResourceNs.bindLabelQtip();
		setTimeout(function () { editResourceNs.bindDirty(); editResourceNs.refreshRibbonAfterDelay(); }, 50);

		$(editResourceNs.cbTmfPlatformNameSelector).change(editResourceNs.handleTmfPlatformChange);
		$(editResourceNs.rbPrimaryTmfPlatformSelector).change(editResourceNs.refreshRibbonAfterDelay);
		$(editResourceNs.cbSecondaryTmfPlatformSelector).change(function () { editResourceNs.handleSecTerChange(this, editResourceNs.tmfCtrlSecondarySelector) });
		$(editResourceNs.cbTertiaryTmfPlatformSelector).change(function () { editResourceNs.handleSecTerChange(this, editResourceNs.tmfCtrlTertiarySelector) });
		editResourceNs.getSponsorsListForTypeAhead();
	},
	handleSecTerChange: function (control, controlGroupSelector) {
		if ($(control).is(":checked")) {
			$(controlGroupSelector).prop("checked", false);
			$(control).prop("checked", true);
		}
		editResourceNs.refreshRibbonAfterDelay();
	},
	populateWorkRegionDropdown: function (countryRegionHierarchy) {
		var regionOptionItemArray = new Array();
		CountriesByRegion.forEach(function (region, index) { regionOptionItemArray.push({ Id: region.Key, DisplayName: region.Value }); });
		editResourceNs.showValuesInDropdown(editResourceNs.workRegionSelector, regionOptionItemArray, true);
	},
	handleWorkRegionChange: function () {
		rm.validation.clearError($(editResourceNs.workRegionSelector));
		editResourceNs.populateWorkCountryDropdown(editResourceNs.getCountryRegionHierarchy(), editResourceNs.getWorkRegionId());
		editResourceNs.refreshRibbonAfterDelay();
	},
	handleTmfPlatformChange: function () {
		var cbTmfPlatform = $(this);
		var tmfRow = cbTmfPlatform.closest("tr");
		var isChecked = cbTmfPlatform.is(":checked");

		tmfRow.find(editResourceNs.tmfCtrlSelector).prop("disabled", !isChecked);
		if (!isChecked) {
			tmfRow.find(editResourceNs.tmfCtrlSelector).prop("checked", false);
			tmfRow.find(editResourceNs.tmfCtrlSelector).closest("td").removeClass(rm.validation.errorClass);
		}
		editResourceNs.refreshRibbonAfterDelay();
	},
	populateWorkCountryDropdown: function (countryRegionHierarchy, selectedRegionId) {
		var countryOptionItemArray = new Array();
		CountriesByRegion.forEach(function (region, index) {
			if (region.Key == selectedRegionId) {
				region.CountryList.forEach(function (country, index) { countryOptionItemArray.push({ Id: country.Key, DisplayName: country.Value }); });
			}
		});
		editResourceNs.showValuesInDropdown(editResourceNs.workCountrySelector, countryOptionItemArray, true);
	},
	handleWorkCountryChange: function () { rm.validation.clearError($(editResourceNs.workCountrySelector)); editResourceNs.refreshRibbonAfterDelay(); },
	initDataList: function (onInitComplete) {
		$.rm.Ajax_Utility("GetEditResourceConfiguration", {}, function (response) {
			$(editResourceNs.isResourcedInRmSelector).attr("checked", true);
			$(editResourceNs.hasResourceableResourceTypesSelector).attr("checked", true);
			editResourceNs.setOrganizationOrganizationalList(response.OrganizationalUnitList);
			editResourceNs.setOrganizationOrganizationalUnitJobRoleHierarchy(response.ResourceTypeOrganizationOrganizationUnitHierarchy, response.OrganizationalUnitJobRoleMapping);
			editResourceNs.setJobRoleList(response.JobRoleList);
			editResourceNs._resourceTypeList = response.ResourceTypeData;
			editResourceNs.setCompetencyBandList(response.CompetencyBandList);
			editResourceNs.bindOrganizationDropdown();
			editResourceNs.populateWorkRegionDropdown(editResourceNs.getCountryRegionHierarchy());
			if (typeof onInitComplete == "function") { onInitComplete(); }
		}, false, false);
	},

	setOrganizationOrganizationalUnitJobRoleHierarchy: function (flatList, organizatiohnalUnitJobRoleList) {
		editResourceNs._orgOrgUnitJobRoleHierarchy = new Array();
		if (flatList != null) {
			$.each(flatList, function (index, element) {
				var organization = editResourceNs.getObjectById(editResourceNs._orgOrgUnitJobRoleHierarchy, "Id", element.OrganizationId);
				if (organization == null) {
					organization = { Id: element.OrganizationId, DisplayName: element.OrganizationName, IsProjectLeadership: element.IsProjectLeadership, OrganizationalUnitList: new Array() };
					editResourceNs._orgOrgUnitJobRoleHierarchy.push(organization);
				}

				var organizationalUnit = editResourceNs.getObjectById(organization.OrganizationalUnitList, "Id", element.OrganizationUnitId);
				if (organizationalUnit == null) {
					organizationalUnit = { Id: element.OrganizationUnitId, DisplayName: element.OrganizationUnitName, JobRoleList: new Array() };
					organization.OrganizationalUnitList.push(organizationalUnit);
				}
				organizationalUnit.JobRoleList.push({ Id: element.JobRoleId, DisplayName: element.JobRoleName });
			});


			if (organizatiohnalUnitJobRoleList != null) {
				$.each(organizatiohnalUnitJobRoleList, function (index, element) {
					var organization = editResourceNs.getObjectById(editResourceNs._orgOrgUnitJobRoleHierarchy, "Id", element.OrganizationId);
					if (organization == null) {
						organization = { Id: element.OrganizationId, DisplayName: element.OrganizationName, OrganizationalUnitList: new Array() };
						editResourceNs._orgOrgUnitJobRoleHierarchy.push(organization);
					}

					var organizationalUnit = editResourceNs.getObjectById(organization.OrganizationalUnitList, "Id", element.OrganizationalUnitId);
					if (organizationalUnit == null) {
						organizationalUnit = { Id: element.OrganizationalUnitId, DisplayName: element.OrganizationalUnitName, JobRoleList: new Array() };
						organization.OrganizationalUnitList.push(organizationalUnit);
					}
					organizationalUnit.JobRoleList.push({ Id: element.JobRoleId, DisplayName: element.JobRoleName });
				});
			}

			//Project leadership is a special case. Show all Roles in all organizatinal units under project leadership
			$.each(editResourceNs._orgOrgUnitJobRoleHierarchy, function (index, element) {
				if (element.IsProjectLeadership) {
					var orgUnitList = editResourceNs.getOrganizationalUnitListByOrganizationId(element.Id);
					//retrieve and remove Project leadership org from hierarchy.
					var projectLeadershipOrgUnit = editResourceNs.retrieveAndRemoveProjectLeadershpOrgUnitFromHierarchy(element);
					var clonedJobRoleList = projectLeadershipOrgUnit.JobRoleList.slice();
					$.each(orgUnitList, function (index, orgUnit) {
						//Add each organizational unit to the hirerchy only if it is not already existing
						if (!editResourceNs.idExists(element.OrganizationalUnitList, orgUnit.Id)) {
							element.OrganizationalUnitList.push($.extend(orgUnit, { JobRoleList: clonedJobRoleList }));
						}
					});
					return false;
				}
			});
		}
	},
	idExists: function (arrayOfObjects, lookupId) {
		var idExists = false;
		if (arrayOfObjects) {
			$.each(arrayOfObjects, function (index, obj) {
				if (obj.Id == lookupId) {
					idExists = true;
					return false;
				}
			});
		}
		return idExists;
	},
	retrieveAndRemoveProjectLeadershpOrgUnitFromHierarchy: function (projectLeadershipOrg) {
		var projectLeadershipOrgUnit = null;
		if (projectLeadershipOrg && projectLeadershipOrg.OrganizationalUnitList.length > 0) {
			$.each(projectLeadershipOrg.OrganizationalUnitList, function (index, orgUnit) {
				if (orgUnit.Id == -1) {
					projectLeadershipOrgUnit = projectLeadershipOrg.OrganizationalUnitList.splice(index, 1)[0];
					return false;
				}
			})
		}
		return projectLeadershipOrgUnit;
	},
	getObjectById: function (objectList, propertyToLookup, lookupValue) {
		var object = null;

		if (objectList != null) {
			$.each(objectList, function (index, element) {
				if (element[propertyToLookup] == lookupValue) {
					object = element;
					return false;
				}
			});
		}
		return object;
	},
	bindLabelQtip: function () {
		rm.qtip.showInfo("#spnCompetencyBand", "Optionally select the resource's Competency Band");
		rm.qtip.showInfo("#imgIsResourcedInRm", "Uncheck this checkbox if this resource is not resourced in RM. Unchecking this checkbox will stop reminder emails to line manager when resource attributes are not completed.");
		rm.qtip.showInfo("#imgHasResourceableResourceTypes", "Uncheck this checkbox if this resource is resourced in RM but only has special assignments.");
		rm.qtip.showInfo("#imgPreferredSponsor", "Only applicable to people dedicated to Special Accounts, e.g. Merck, Daiichi, Takeda. Leave empty for others.");
	},
	setOrganizationOrganizationalList: function (organizationOrganizationalUnitList) {
		editResourceNs._organizationOrganizationalList = new Array();

		if (organizationOrganizationalUnitList != null) {
			$.each(organizationOrganizationalUnitList, function (index, element) {
				var organization = editResourceNs.getOrganizationById(editResourceNs._organizationOrganizationalList, element.Id);

				if (organization == null) {
					organization = { Id: element.Id, DisplayName: element.Name, OrganizationalUnitList: new Array() };
					editResourceNs._organizationOrganizationalList.push(organization);
				}
				organization.OrganizationalUnitList.push({ Id: element.OrganizationalUnitId, DisplayName: element.OrganizationalUnitName, ShowPreferredSponsor: element.ShowPreferredSponsor });
			});
		}
	},

	getOrganizationById: function (organizationList, organizationId) {
		var organization = null;

		if (organizationList != null) {
			$.each(organizationList, function (index, element) {
				if (element.Id == organizationId) {
					organization = element;
					return false;
				}
			});
		}
		return organization;
	},

	setJobRoleList: function (jobRoleList) {
		editResourceNs._jobRoleList = new Array();

		if (jobRoleList != null) {
			$.each(jobRoleList, function (index, element) {
				editResourceNs._jobRoleList.push({ Id: element.Id, DisplayName: element.Name, OrganizationId: element.OrganizationId, ShowCompetencyBand: element.ShowCompetencyBand, ShowTmfPlatform: element.ShowTmfPlatform });
			});
		}
	},

	setCompetencyBandList: function (competencyBandList) {
		editResourceNs._competencyBandList = new Array();

		if (competencyBandList != null) {
			$.each(competencyBandList, function (index, element) {
				editResourceNs._competencyBandList.push({ Id: element.Id, DisplayName: element.Name });
			});
		}
	},

	handleJobRoleChange: function () {
		rm.validation.clearError($(editResourceNs.jobRoleSelector));
		editResourceNs.refreshRibbonAfterDelay();
		editResourceNs.bindCompetencyBandDropdown();
		$.each(editResourceNs._jobRoleList, function (index, element) {
			if (element.Id == $(editResourceNs.jobRoleSelector).val()) {
				editResourceNs.handleCompetencyBandVisibility(element.ShowCompetencyBand);
				editResourceNs.handleTmfPlatformVisibility(element.ShowTmfPlatform);
			}
		});
	},
	handleCompetencyBandVisibility: function (showCompetencyBand) {
		$('#trCompetencyBandDelegateToLm').hide();
		showCompetencyBand ? $('#trCompetencyBand').show() : $('#trCompetencyBand').hide();

		if (showCompetencyBand) {
			if (editResourceNs.hasPermissionToSeeCompetencyBand()) {
				$('#spnCompetencyBand').show();
				$('#divCompetencyBandDelegateToLm').hide();
			}
			else {
				$('#spnCompetencyBand').hide();
				$('#divCompetencyBandDelegateToLm').show();
			}
		}
	},
	handleTmfPlatformVisibility: function (showTmfPlatform) {
		if (showTmfPlatform) {
			$(editResourceNs.tmfPlatformContainerSelector).show();
		}
		else {
			$(editResourceNs.tmfPlatformContainerSelector).hide().find(editResourceNs.tmfCtrlSelector).attr("checked", false);
		}

	},
	handlePreferredSponsorVisibility: function (showPreferredSponsor) {
		if (showPreferredSponsor) { $(editResourceNs.trPreferredSponsorSelector).show(); }
		else {
			$(editResourceNs.txtPreferredSponsorSelector).val("");
			$(editResourceNs.trPreferredSponsorSelector).hide();
		}
	},
	handleCompetencyBandChange: function () {
		editResourceNs.refreshRibbonAfterDelay();
	},
	enableFulfillableResourceTypeTree: function () { $(editResourceNs.resourceTypeDivSelector).fancytree("enable"); },
	disableFulfillableResourceTypeTree: function () { $(editResourceNs.resourceTypeDivSelector).fancytree("disable"); },
	enableControls: function () {
		$(editResourceNs.organizationalUnitSelector).prop("disabled", false);
		$(editResourceNs.organizationSelector).prop("disabled", false);
		$(editResourceNs.jobRoleSelector).prop("disabled", false);
		$(editResourceNs.competencyBandSelector).prop("disabled", false);
		$(editResourceNs.workCountrySelector).prop("disabled", false);
		$(editResourceNs.workRegionSelector).prop("disabled", false);
		$(editResourceNs.hasResourceableResourceTypesSelector).prop("disabled", false);
		if (editResourceNs.getHasResourceableResourceTypes()) { editResourceNs.enableFulfillableResourceTypeTree(); }
		$(editResourceNs.enableDisableDeselectAll());
		if ($(editResourceNs.resourceTypeDivSelector).fancytree("getTree").getSelectedNodes().length >= 1) { $(editResourceNs.tblIntendedFteSelector).show(); }
		else {
			if (!editResourceNs.getIsResourcedInRmValue()) {
				editResourceNs.clearIntendedFteTable();
				editResourceNs.buildIntendedFteTable();
			}
		}
		editResourceNs.handleIntendedFteContainerVisibility();
	},
	disableControls: function () {
		$(editResourceNs.organizationalUnitSelector).prop('selectedIndex', 0);
		rm.validation.clearError($(editResourceNs.organizationalUnitSelector));
		$(editResourceNs.organizationalUnitSelector).prop("disabled", true);
		$(editResourceNs.organizationSelector).prop('selectedIndex', 0);
		rm.validation.clearError($(editResourceNs.organizationSelector));
		$(editResourceNs.organizationSelector).prop("disabled", true);
		$(editResourceNs.jobRoleSelector).prop('selectedIndex', 0);
		rm.validation.clearError($(editResourceNs.jobRoleSelector));
		$(editResourceNs.jobRoleSelector).prop("disabled", true);
		$(editResourceNs.competencyBandSelector).prop("disabled", true);
		$(editResourceNs.competencyBandSelector).prop('selectedIndex', 0);
		$(editResourceNs.hasResourceableResourceTypesSelector).prop("disabled", true).prop("checked", false);

		//	editResourceNs.resetCountryAndRegion();
		$(editResourceNs.workRegionSelector).prop('selectedIndex', 0);
		rm.validation.clearError($(editResourceNs.workRegionSelector));
		$(editResourceNs.workRegionSelector).prop("disabled", true);
		$(editResourceNs.workCountrySelector).prop('selectedIndex', 0);
		rm.validation.clearError($(editResourceNs.workCountrySelector));
		$(editResourceNs.workCountrySelector).prop("disabled", true);
		$(editResourceNs.deSelectAllRRTsSelector).prop("disabled", true);

		editResourceNs.disableFulfillableResourceTypeTree();
		editResourceNs.handleTmfPlatformVisibility(false);
		editResourceNs.handlePreferredSponsorVisibility(false);
		$(editResourceNs.tblIntendedFteSelector).hide();
	},
	handleOrganizationChange: function () {
		if (editResourceNs.getIsResourcedInRmValue()) { editResourceNs.enableControls(); }
		else { editResourceNs.disableControls(); }
		editResourceNs.refreshRibbonAfterDelay();
	},
	handleIsResourcedInRmChange: function () {
		if (editResourceNs.getIsResourcedInRmValue()) { editResourceNs.enableControls(); }
		else { editResourceNs.disableControls(); }
		editResourceNs.refreshRibbonAfterDelay();
	},
	handleHasResourceableResourceTypesChange: function () {
		if (editResourceNs.getHasResourceableResourceTypes()) {
			editResourceNs.enableFulfillableResourceTypeTree();
			editResourceNs.handleIntendedFteContainerVisibility();
		}
		else {
			editResourceNs.disableFulfillableResourceTypeTree();
			$(editResourceNs.tblIntendedFteSelector).hide();
		}
		editResourceNs.refreshRibbonAfterDelay();
	},
	handleIntendedFteChange: function (element) {
		$.q.formatText(element);
		editResourceNs.refreshRibbonAfterDelay();
	},
	enableDisableDeselectAll: function () {
		if (editResourceNs.getSelectedResourceTypeIds().length > 0) {
			$(editResourceNs.deSelectAllRRTsSelector).prop("disabled", false);
			rm.qtip.showInfo("#deSelectAll", "Deselect all Resource Request Type checkboxes.");
		}
		else {
			$(editResourceNs.deSelectAllRRTsSelector).prop("disabled", true);
			rm.qtip.clear("#deSelectAll");
		}

		editResourceNs.refreshRibbonAfterDelay();
	},


	handleOrganizationalUnitChange: function () {
		editResourceNs.bindJobRoleDropdown();
		rm.validation.clearError($(editResourceNs.organizationalUnitSelector));
		editResourceNs.refreshRibbonAfterDelay();
	},

	getOrganizationalUnitListByOrganizationId: function (organizationId) {
		var organizationalUnitList = new Array();

		if (editResourceNs._organizationOrganizationalList != null) {
			$.each(editResourceNs._organizationOrganizationalList, function (index, element) {
				if (element.Id == organizationId) {
					organizationalUnitList = element.OrganizationalUnitList;
					return false;
				}
			});
		}
		return organizationalUnitList;
	},
	handleOrganizationChange: function (organizationId) {
		if (organizationId == null) { organizationId = $(editResourceNs.organizationSelector).val(); }
		editResourceNs.showValuesInDropdown(editResourceNs.jobRoleSelector, [], true);
		rm.validation.clearError($(editResourceNs.organizationSelector));
		var organizationalUnitList = editResourceNs.getOrganizationalUnitListByOrganizationId(organizationId);
		editResourceNs.showValuesInDropdown(editResourceNs.organizationalUnitSelector, organizationalUnitList, true);
		editResourceNs.handlePreferredSponsorVisibility(editResourceNs.getPreferredSponsorVisibility());
		editResourceNs.refreshRibbonAfterDelay();
	},

	getPreferredSponsorVisibility: function () {
		var showPreferredSponsor = null;
		$.each(editResourceNs._organizationOrganizationalList, function (index, element) {
			if (element.Id == $(editResourceNs.organizationSelector).val()) {
				$.each(element.OrganizationalUnitList, function (index, subelement) {
					if (element.Id == $(editResourceNs.organizationSelector).val()) {
						showPreferredSponsor = subelement.ShowPreferredSponsor;
						return false;
					}
				});
			}
		});
		return showPreferredSponsor;
	},
	mapResourceTypeIdsToResourceConfigChildren: function (resourceTypeIdList, children) {
		if (children != null && children.length > 0) {
			$.each(children, function (index, child) {
				$.each(resourceTypeIdList, function (index, resourceableResourceType) {
					if (parseInt(child.key) == resourceableResourceType.ResourceTypeId ||
						child.key == resourceableResourceType.ResourceTypeId) {
						child.selected = true;
					}
				});
				editResourceNs.mapResourceTypeIdsToResourceConfigChildren(resourceTypeIdList, child.children);
			});
		}
	},
	mapResourceTypeIdsToResourceConfig: function (resourceTypeIdList) {
		$.each(editResourceNs._resourceTypeList.treeNodes, function (index, treenode) {
			$.each(resourceTypeIdList, function (index, resourceableResourceType) {
				if (parseInt(treenode.key) == resourceTypeIdList.ResourceTypeId || treenode.key == resourceTypeIdList.ResourceTypeId) {
					treenode.selected = true;
				}
			});
			editResourceNs.mapResourceTypeIdsToResourceConfigChildren(resourceTypeIdList, treenode.children);
		});
	},

	showCurrentUserConfiguration: function () {
		$.rm.Ajax_Resource("GetResourceConfiguration", { resourceId: editResourceNs.getResourceId() }, function (response) {
			editResourceNs._resourceConfiguration = response;
			editResourceNs.resetValues();
		}, false, false);
	},
	getJobRoleConfiguration: function (jobRoleId) {
		var jobRoleConfiguration = null;
		if (editResourceNs._jobRoleList != null) {
			$.each(editResourceNs._jobRoleList, function (index, jobRoleConfig) {
				if (jobRoleConfig.Id == jobRoleId) {
					jobRoleConfiguration = jobRoleConfig;
					return false;
				}
			});
		}
		return jobRoleConfiguration;
	},
	isTmfPlatformApplicableToJobRole: function (jobRoleId) {
		var jobRoleConfig = editResourceNs.getJobRoleConfiguration(editResourceNs.getJobRoleId());
		return jobRoleConfig != null && jobRoleConfig.ShowTmfPlatform;
	},
	resetCountryAndRegion: function () {
		var workCountryId = (editResourceNs._resourceConfiguration != null) ? editResourceNs._resourceConfiguration.WorkCountryId : editResourceNs.selectOptionItemValue;
		editResourceNs.getCountryRegionHierarchy().every(function (region, index) {
			return region.CountryList.every(function (country, index) {
				if (country.Key == workCountryId) {
					$(editResourceNs.workRegionSelector).val(region.Key);
					editResourceNs.populateWorkCountryDropdown(editResourceNs.getCountryRegionHierarchy(), region.Key);
					setTimeout(function () { $(editResourceNs.workCountrySelector).val(workCountryId); }, 5);
					return false;
				}
				return true;
			});
		});
	},
	resetValues: function (onAfterReset) {
		var organizationId = editResourceNs.selectOptionItemValue;
		var organizationalUnitId = editResourceNs.selectOptionItemValue;
		var jobRoleId = editResourceNs.selectOptionItemValue;
		var competencyBandId = editResourceNs.selectOptionItemValue;
		$(editResourceNs.tmfCtrlSelector).attr("checked", false);

		if (editResourceNs._resourceConfiguration != null) {
			$(editResourceNs.homeCountrySelector).text(editResourceNs._resourceConfiguration.HomeCountry || "Not supplied in HR feed");
			organizationId = editResourceNs._resourceConfiguration.OrganizationId;
			organizationalUnitId = editResourceNs._resourceConfiguration.OrganizationalUnitId;
			jobRoleId = editResourceNs._resourceConfiguration.PrimaryJobRoleId;
			competencyBandId = editResourceNs._resourceConfiguration.CompetencyBandId;
			editResourceNs.resetCountryAndRegion();
			$(editResourceNs.hasResourceableResourceTypesSelector).attr("checked", editResourceNs._resourceConfiguration.HasResourceableResourceTypes);
			$(editResourceNs.isResourcedInRmSelector).attr("checked", editResourceNs._resourceConfiguration.IsResourcedInRm);

			$.each(editResourceNs._resourceConfiguration.TmfPlatforms, function (index, tmfPlatform) {
				var tmfRow = $("#cbTmfPlatform_" + tmfPlatform.TmfPlatformId).attr("checked", true).closest("tr");
				tmfRow.find(editResourceNs.rbPrimaryTmfPlatformSelector).attr("disabled", false).attr("checked", tmfPlatform.IsPrimary);
				tmfRow.find(editResourceNs.cbSecondaryTmfPlatformSelector).attr("disabled", false).attr("checked", tmfPlatform.IsSecondary);
				tmfRow.find(editResourceNs.cbTertiaryTmfPlatformSelector).attr("disabled", false).attr("checked", tmfPlatform.IsTertiary);
			});
			$(editResourceNs.txtPreferredSponsorSelector).val(editResourceNs._resourceConfiguration.PreferredSponsor);
			editResourceNs.clearIntendedFteTable();
			editResourceNs.buildIntendedFteTable();
		}
		else { editResourceNs.clearIntendedFteTable(); }
		editResourceNs.handleIntendedFteContainerVisibility();
		$(editResourceNs.organizationSelector).val(organizationId);
		if (editResourceNs._resourceConfiguration == null) {
			$(editResourceNs.resourceTypeIdsSelector).val("");
			editResourceNs.mapResourceTypeIdsToResourceConfig([]);
		}
		else {
			//  $(editResourceNs.resourceTypeIdsSelector).val(editResourceNs._resourceConfiguration.ResourceableResourceTypes.ResourceTypeId.sort().join(","));
			editResourceNs.mapResourceTypeIdsToResourceConfig(editResourceNs._resourceConfiguration.ResourceableResourceTypes);
		}
		editResourceNs.bindResourceTypeCheckboxList();

		var jobRoleConfig = editResourceNs.getJobRoleConfiguration(jobRoleId);
		if (jobRoleConfig != null) {
			editResourceNs.handleCompetencyBandVisibility(jobRoleConfig.ShowCompetencyBand);
			editResourceNs.handleTmfPlatformVisibility(jobRoleConfig.ShowTmfPlatform);
		}

		editResourceNs.bindCompetencyBandDropdown();
		editResourceNs.handleOrganizationChange(organizationId);
		editResourceNs.bindJobRoleDropdown(organizationId, organizationalUnitId);

		setTimeout(function () {
			$(editResourceNs.competencyBandSelector).val(competencyBandId);
			$(editResourceNs.organizationalUnitSelector).val(organizationalUnitId);
			$(editResourceNs.jobRoleSelector).val(jobRoleId);
			editResourceNs.handleIsResourcedInRmChange();
			editResourceNs.handleHasResourceableResourceTypesChange();
			if (typeof onAfterReset == "function") { onAfterReset(); }
		}, 5);
	},
	//organizationId, organizationalUnitId: Both arguments are optional
	bindJobRoleDropdown: function (organizationId, organizationalUnitId) {
		rm.validation.clearError($(editResourceNs.jobRoleSelector));
		editResourceNs.showValuesInDropdown(editResourceNs.jobRoleSelector, editResourceNs.getJobRoleListFromSelectedOrganizationalUnit(organizationId, organizationalUnitId), true);
	},
	//organizationId, organizationalUnitId: Both arguments are optional
	getJobRoleListFromSelectedOrganizationalUnit: function (organizationId, organizationalUnitId) {
		var jobRoleList = new Array();
		if (organizationId == null) { organizationId = editResourceNs.getOrganizationId(); }
		if (organizationalUnitId == null) { organizationalUnitId = editResourceNs.getOrganizationalUnitId(); }

		if (editResourceNs.allJapanResourcesSelected()) {
			if (organizationId != null && organizationalUnitId != null) {
				jobRoleList = editResourceNs._jobRoleList;
			}
		} else {
			$.each(editResourceNs._orgOrgUnitJobRoleHierarchy, function (index, organization) {
				if (organization.Id == organizationId) {
					$.each(organization.OrganizationalUnitList, function (index, organizationalUnit) {
						if (organizationalUnit.Id == organizationalUnitId) {
							jobRoleList = organizationalUnit.JobRoleList;
							return false;
						}
					});
					return false;
				}
			});
		}

		jobRoleList = editResourceNs.getUniqueValues(jobRoleList, function () { });

		return jobRoleList.sort(function (a, b) {
			if (a.DisplayName.toLowerCase() > b.DisplayName.toLowerCase()) { return 1; }
			if (a.DisplayName.toLowerCase() < b.DisplayName.toLowerCase()) { return -1; }
			return 0;
		});
	},
	getUniqueValues: function (arrayWithDuiplicates) {
		var uniqueArray = new Array();
		if (Array.isArray(arrayWithDuiplicates)) {
			for (var index = 0; index < arrayWithDuiplicates.length; index++) {
				var currentItem = arrayWithDuiplicates[index];
				var duplicate = false;

				for (var innerId = 0; innerId < uniqueArray.length; innerId++) {
					if (uniqueArray[innerId].Id == currentItem.Id) {
						duplicate = true;
						break;
					}
				}
				if (!duplicate) { uniqueArray.push(currentItem); }
			}
		}
		return uniqueArray;
	},
	bindOrganizationDropdown: function () {
		editResourceNs.showValuesInDropdown(editResourceNs.organizationSelector, editResourceNs._organizationOrganizationalList, true);

	},
	bindCompetencyBandDropdown: function () {
		rm.validation.clearError($(editResourceNs.competencyBandSelector));
		editResourceNs.showValuesInDropdown(editResourceNs.competencyBandSelector, editResourceNs._competencyBandList, true);
	},
	bindResourceTypeCheckboxList: function () {
		$(editResourceNs.resourceTypeDivSelector).fancytree({
			checkbox: true,
			selectMode: 2,
			source: editResourceNs._resourceTypeList.treeNodes,

			select: function (event, data) {
				if (ResourceTypeDetails[data.node.key].ShowIntendedFte && data.node.selected) {
					editResourceNs.addRowToIntendedFteTable(data.node.key, data.node.title, "");
				}
				else if (!data.node.selected) {
					$(editResourceNs.tblIntendedFteSelector).find("tr[resourceTypeId=" + data.node.key + "]").remove();
				}

				setTimeout(function () {
					editResourceNs.handleIntendedFteContainerVisibility();
					(editResourceNs.enableDisableDeselectAll());
				}, 10);
			},
			click: function (event, data) {
				// We should not toggle, if target was "checkbox", because this
				// would result in double-toggle (i.e. no toggle)
				if ($.ui.fancytree.getEventTargetType(event) === "title") {

					data.node.toggleSelected();
					data.node.toggleExpanded();
				}
				if (!data.node.unselectable) {
					setTimeout(editResourceNs.setCommaSeparatedSelectedResourceTypeIds, 10);
					editResourceNs.refreshRibbonAfterDelay();
				}
			},
		});
	},
	clearIntendedFteTable: function () { $(editResourceNs.tblIntendedFteSelector).find("tr[resourceTypeId]").remove(); },
	buildIntendedFteTable: function () {
		$.each(editResourceNs._resourceConfiguration.ResourceableResourceTypes, function (index, resourceableResourceType) {
			var resourceTypeDetails = ResourceTypeDetails[resourceableResourceType.ResourceTypeId];
			if (resourceTypeDetails.ShowIntendedFte) {
				editResourceNs.addRowToIntendedFteTable(resourceTypeDetails.Id, resourceTypeDetails.Name, resourceableResourceType.IntendedFte);
			}
		});
	},
	addRowToIntendedFteTable: function (resourceTypeId, resourceTypeName, intendedFte) {
		$(editResourceNs.tblIntendedFteSelector).append(editResourceNs.getIntendedFteRowFromTemplate(resourceTypeId, resourceTypeName, intendedFte));
	},
	getIntendedFteRowFromTemplate: function (resourceTypeId, resourceTypeName, intendedFte) {
		var intendedFteTemplateRow = $(editResourceNs.intendedFteTemplateRowSelector).clone();
		intendedFteTemplateRow.removeAttr("id").attr("resourceTypeId", resourceTypeId).show();
		intendedFteTemplateRow.find(editResourceNs.tdIntendedFteResourceTypeSelector).html(resourceTypeName);
		intendedFteTemplateRow.find(editResourceNs.txtIntendedFteSelector).val(intendedFte);
		return intendedFteTemplateRow;
	},
	handleIntendedFteContainerVisibility: function () {
		if ($(editResourceNs.tblIntendedFteSelector).find("tr[resourceTypeId]").length > 0) {
			$(editResourceNs.tblIntendedFteSelector).show();
		}
		else { $(editResourceNs.tblIntendedFteSelector).hide(); }
	},
	showValuesInDropdown: function (selector, optionItemList, addSelectItem) {
		$(selector).empty();

		if (addSelectItem) { $(selector).append($("<option>", { value: editResourceNs.selectOptionItemValue, html: editResourceNs.selectOptionItemDisplayText })); }

		$.each(optionItemList, function (index, element) {
			$(selector).append($("<option>", { value: element.Id, html: element.DisplayName }));
		});
	},

	isSaveButtonEnabled: function () { return editResourceNs.isFormDirty(); },

	isCancelButtonEnabled: function () { return editResourceNs.isFormDirty(); },

	isCloseButtonEnabled: function () { return true; },

	getJsonObjectForDirtyCheck: function () {
		var dirtySelector = "#editResource input:hidden,#editResource select:visible,#editResource input:visible," + editResourceNs.isResourcedInRmSelector + ",.tmfCtrl:visible,[name=cbTmfPlatformName]," + editResourceNs.hasResourceableResourceTypesSelector + ",#divResourceType span.fancytree-checkbox";
		return { items: [{ selector: dirtySelector, dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},

	isFormDirty: function () {
		return $.formStatus.isDirty(editResourceNs.getJsonObjectForDirtyCheck());
	},

	getPostData: function () {
		return {
			resourceIdList: editResourceNs.getResourceIdList(),
			organizationalUnitId: editResourceNs.getOrganizationalUnitId(),
			primaryJobRole: editResourceNs.getJobRoleId(),
			resourceableResourceTypeList: editResourceNs.getResourceableResourceTypeDetails(),
			isResourcedInRm: editResourceNs.getIsResourcedInRmValue(),
			competencyBandId: editResourceNs.getCompetencyBandId(),
			workCountryId: editResourceNs.getWorkCountryId(),
			tmfPlatformDetails: editResourceNs.getTmfPlatformDetails(),
			hasResourceableResourceTypes: editResourceNs.getHasResourceableResourceTypes(),
			preferredSponsor: editResourceNs.getPreferredSponsorValue()
		};
	},
	getTmfPlatformDetails: function () {
		var tmfPlatformDetails = new Array();
		if (editResourceNs.isTmfPlatformApplicableToJobRole(editResourceNs.getJobRoleId())) {
			$.each($(editResourceNs.cbTmfPlatformNameSelector + ":checked"), function (index, tmfPlatform) {
				var tmfRow = $(tmfPlatform).closest("tr");

				tmfPlatformDetails.push({
					TmfPlatformId: $(tmfPlatform).val(),
					IsPrimary: tmfRow.find(editResourceNs.rbPrimaryTmfPlatformSelector + ":visible").is(':checked'),
					IsSecondary: tmfRow.find(editResourceNs.cbSecondaryTmfPlatformSelector + ":visible").is(':checked'),
					IsTertiary: tmfRow.find(editResourceNs.cbTertiaryTmfPlatformSelector + ":visible").is(':checked'),
				});
			});
		}
		return tmfPlatformDetails;
	},
	bindDirty: function () {
		setTimeout(function () {
			rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, editResourceNs.getJsonObjectForDirtyCheck());
		}, 10);
	},

	clearDirty: function () {
		rm.formStatus.clearDirty(editResourceNs.getJsonObjectForDirtyCheck());
	},
	isTmfPlatformSelectionValid: function () {
		if (editResourceNs.isTmfPlatformApplicableToJobRole(editResourceNs.getJobRoleId())) {
			var primaryPlatformValid = true;
			if ($(editResourceNs.cbTmfPlatformNameSelector + ":checked").length > 0) {
				primaryPlatformValid = ($(editResourceNs.rbPrimaryTmfPlatformSelector + ":checked").length > 0);
				if (!primaryPlatformValid) {
					rm.ui.messages.addError("Please select Primary TMF Platform.");
					$(editResourceNs.tdTmfPrimarySelector).addClass(rm.validation.errorClass);
				}
				else {
					$(editResourceNs.tdTmfPrimarySelector).removeClass(rm.validation.errorClass);
				}
			}
			else {
				$(editResourceNs.tdTmfPrimarySelector).removeClass(rm.validation.errorClass);
			}

			var multipleControlsChecked = true;

			$.each($(editResourceNs.trTmfPlatformClassSelector + ":visible"), function (index, tmfRow) {
				multipleControlsChecked = ($(tmfRow).find(editResourceNs.tmfCtrlSelector + ":checked").length > 1);
				if (multipleControlsChecked) {
					$(tmfRow).find(editResourceNs.tmfCtrlSelector + ":checked").closest("td").addClass(rm.validation.errorClass);
				}
				else {
					var controlTypeRestriction = (primaryPlatformValid) ? "" : "[type=checkbox] ";
					$(tmfRow).find(controlTypeRestriction + editResourceNs.tmfCtrlSelector).closest("td").removeClass(rm.validation.errorClass);
				}

				return !multipleControlsChecked;
			});
			if (multipleControlsChecked) {
				rm.ui.messages.addError("A platform can either be Primary or Secondary or Tertiary.");
			}

			return primaryPlatformValid && !multipleControlsChecked;
		}
		else { return true; }
	},
	isPreferredSponsorValid: function () {
		var isValid = false;
		if ($(editResourceNs.txtPreferredSponsorSelector).val() == "") {
			isValid = true;
			rm.validation.clearError(editResourceNs.txtPreferredSponsorSelector);
		}
		else {
			$.each($(editResourceNs._projectSponsorList), (function (index, element) {
				if (element == $(editResourceNs.txtPreferredSponsorSelector).val()) {
					isValid = true;
					rm.validation.clearError(editResourceNs.txtPreferredSponsorSelector);
					return;
				}
			}
			));
		}
		return isValid;

	},
	isValidIntendedFte: function () {
		var isValid = true;
		$.each($(editResourceNs.txtIntendedFteSelector + ":visible"), function (index, intendedFte) {
			if (intendedFte.value != "") {
				isValid = rm.validation.range.validate(intendedFte) && isValid;
			}
		});
		return isValid;
	},
	isFormValid: function () {
		var isValid = true;
		if (editResourceNs.isMultiEditMode()) {
			if (editResourceNs.getIsResourcedInRmValue() && editResourceNs.getOrganizationId() != null && editResourceNs.getOrganizationalUnitId() == null) {
				rm.validation.addError($(editResourceNs.organizationalUnitSelector), "Please select Organizational Unit");
				isValid = false;
			}

			if (editResourceNs.getOrganizationalUnitId() != null && editResourceNs.getJobRoleId() == null) {
				rm.validation.addError($(editResourceNs.jobRoleSelector), "Please select Job Role");
				isValid = false;
			}

			if (editResourceNs.getWorkRegionId() != null && editResourceNs.getWorkCountryId() == null) {
				rm.validation.addError($(editResourceNs.workCountrySelector), "Please select Work Country or unselect Work Region");
				isValid = false;
			}
			if (!editResourceNs.isValidIntendedFte()) {
				rm.ui.messages.addError("Please enter valid value for intended fte")
				isValid = false;
			}
			return isValid;
		}
		else {
			if (editResourceNs.getIsResourcedInRmValue()) {
				if (editResourceNs.getWorkRegionId() == null) {
					rm.validation.addError($(editResourceNs.workRegionSelector), "Please select Work Region");
					isValid = false;
				}
				if (editResourceNs.getWorkCountryId() == null) {
					rm.validation.addError($(editResourceNs.workCountrySelector), "Please select Work Country");
					isValid = false;
				}

				if (editResourceNs.getOrganizationId() == null) {
					rm.validation.addError($(editResourceNs.organizationSelector), "Please select Organization");
					isValid = false;
				}

				if (editResourceNs.getOrganizationalUnitId() == null) {
					rm.validation.addError($(editResourceNs.organizationalUnitSelector), "Please select Organizational Unit");
					isValid = false;
				}

				if (editResourceNs.getJobRoleId() == null) {
					rm.validation.addError($(editResourceNs.jobRoleSelector), "Please select Job Role");
					isValid = false;
				}

				if (!editResourceNs.isTmfPlatformSelectionValid()) { isValid = false; }

				if (!editResourceNs.isPreferredSponsorValid()) {
					rm.ui.messages.addError("Please select a valid sponsor.")
					rm.validation.addError(editResourceNs.txtPreferredSponsorSelector, "Please select a valid sponsor");
					isValid = false;
				}

				if (!editResourceNs.isValidIntendedFte()) {
					rm.ui.messages.addError("Please enter valid value for intended fte")
					isValid = false;
				}

			}
		}
		return isValid;
	},
	save: function () {
		rm.ui.messages.clearAllMessages();
		if (editResourceNs.isFormValid()) {
			var postData = editResourceNs.getPostData();

			rm.ajax.resourceSvcAsyncPost("UpdateResourceConfiguration", postData, function (response) {
				if (response.ContainsValidationErrors) {
					rm.validation.processErrorMessages(response.ValidationErrors);
				}
				else {
					rm.ui.messages.showSuccess(Resources.DataSavedSuccessfully);
					if (editResourceNs.isMultiEditMode()) {
						window.onbeforeunload = null; //Prevent prompt
						editResourceNs.close();
					}
					else {
						editResourceNs._resourceConfiguration.ResourceTypeIdList = editResourceNs.getSelectedResourceTypeIds();
						editResourceNs._resourceConfiguration.WorkCountryId = postData.workCountryId;
						editResourceNs._resourceConfiguration.OrganizationId = editResourceNs.getOrganizationId();
						editResourceNs._resourceConfiguration.OrganizationalUnitId = postData.organizationalUnitId;
						editResourceNs._resourceConfiguration.PrimaryJobRoleId = postData.primaryJobRole;
						editResourceNs._resourceConfiguration.CompetencyBandId = postData.competencyBandId;
						editResourceNs._resourceConfiguration.TmfPlatformIdList = postData.tmfPlatformIdList;

						editResourceNs.mapResourceTypeIdsToResourceConfig(editResourceNs.getSelectedResourceTypeIds());
						setTimeout(function () {
							editResourceNs.clearDirty();
							editResourceNs.refreshRibbonAfterDelay();
						}, 5);
					}
				}
			});
		}
	},

	cancel: function () {
		var isDirty = editResourceNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePageShort))) {
			$(editResourceNs.resourceTypeDivSelector).fancytree("destroy");
			editResourceNs.resetValues(function () {
				editResourceNs.enableControls();
				$(editResourceNs.isResourcedInRmSelector).prop("checked", true);
				setTimeout(function () {
					editResourceNs.clearDirty();
					editResourceNs.refreshRibbonAfterDelay();
				}, 20);
			});
		}
	},

	close: function () { document.location = "MyStaff.aspx"; },

	getSponsorsListForTypeAhead: function () {
		var sponsorsitesList = null;
		rm.ajax.projectSvcSyncPost("GetSponsorListFromProject", {}, function (response) {
			editResourceNs._projectSponsorList = response;
			editResourceNs.bindAutoComplete(response, editResourceNs.txtPreferredSponsorSelector);
		});
	},
	bindAutoComplete: function (sponsorsitesList, txtPreferredSponsorSelector) {
		var textboxObj = $(txtPreferredSponsorSelector).unbind("keydown");
		if (textboxObj.data("ui-autocomplete") != undefined) { alert('destroy'); textboxObj.autocomplete("destroy"); }

		//bind the autocomplete plugin to the search box
		textboxObj.autocomplete({
			source: sponsorsitesList,
			matchContains: false,
			open: function (event, ui) {
				var dialog = $(this).closest('.ui-dialog');
				if (dialog.length > 0) {
					$('.ui-autocomplete.ui-front').css("zIndex", dialog.css("zIndex") + 1);
				}
			}

		});
	},
};