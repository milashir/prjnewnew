﻿$(document).ready(function () {
	$("#softBookingNavLink").addClass("left-static-selected-menu");
	$.rm.softBook.BuildGrid(GetRmPageLinkId());

	//the object attached to is irrelevant.  this is a global handler
	$("#aspnetForm").ajaxStart(function () { rm.ui.block(); });

	//the object attached to is irrelevant.  this is a global handler
	$("#aspnetForm").ajaxStop(function () { rm.ui.unblock(); });
	rm.grid.bindEventsToResizeGrid("#softBookingList");

	$.rm.softBook.bindLabelQtip();
});

$.rm.softBook =
{
	metricType: null,
	_isRemoveSoftBookEnabled: false,
	_isHardBookEnabled: false,

	ResetRibbonIcons: function () {
		$.rm.softBook._isRemoveSoftBookEnabled = false;
		$.rm.softBook._isHardBookEnabled = false;
		rm.ui.ribbon.refresh();
	},

	IsRemoveSoftBookEnabled: function () { return $.rm.softBook._isRemoveSoftBookEnabled; },
	IsHardBookEnabled: function () { return $.rm.softBook._isHardBookEnabled; },

	RemoveSoftBook: function () {
		if (confirm("By continuing, the resource soft booked to the selected request(s) will be released. Click OK to continue.  Click Cancel to keep the selected soft booking(s).")) {
			rm.grid.clearGridError("#softBookingList", 'Message');
			$.rm.softBook.HideMessageColumn();

			var formData =
			{
				selectedSoftBookingIds: $("#softBookingList").getGridParam('selarrrow')
			};

			$.ajax({
			    url: rm.ajax.requestSvcUrl + "RemoveSoftBookings",
				contentType: "application/json; charset=utf-8",
				data: JSON.stringify(formData),
				type: "POST",
				dataType: "json",
				success: function (data) {
					var isSuccess = true;

					$.each(data, function (index, ele) {
						if (ele.IsSuccessful) {
							$.rm.softBook.RemoveRow(ele.EntityId);
						}
						else {
							$('#softBookingList').setCell(ele.EntityId, 'Message', ele.Message);
							$('#softBookingList').showCol("Message");
							isSuccess = false;
						}
					});

					$.q.RebindQtip("#softBookingList");
					$.rm.softBook.ResetRibbonIcons();
					if (isSuccess) {
						$.rm.softBook.clearSelectAllCheckedButton();
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showSuccess('Soft booking(s) removed successfully.');
					}
					else {
						rm.ui.messages.addError('Failed to remove one or more soft bookings.');
					}
					rm.serviceCalls.getRequestCounts();
				},
				error: function (x, e) {
					alert(x.responseText);
					rm.ui.messages.addError('Failed to remove soft booking.');
				}
			});
		}
	},

	HardBook: function () {
		rm.grid.clearGridError("#softBookingList", 'Message');
		$.rm.softBook.HideMessageColumn();
		var postData = { resourceRequestAssignmentId: rm.grid.getSelectedIds("#softBookingList") };
		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.requestSvcUrl + "AcceptSoftBooking",
			dataType: "json",
			data: JSON.stringify(postData),
			success: function (data) {
				if (data.IsSuccessful) {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess('Request assigned successfully.');
					setTimeout(function () { RefreshPage(); }, 2000);
				}
				else {
					$('#softBookingList').setCell(postData.resourceRequestAssignmentId, 'Message', data.Message.replace(/'/g, "&#39;"));
					$.rm.softBook.ShowMessageColumn();
				}
				$.q.RebindQtip("#softBookingList");
				$.rm.softBook.ResetRibbonIcons();
				rm.serviceCalls.getRequestCounts();
			},
			error: function (x, e) {
				alert(x.responseText);
				rm.ui.messages.addError('Failed to hard book the resource.');
			}
		});
	},

	CheckGridRows: function () {
		ChangeButtonStatus();
	},

	clearSelectAllCheckedButton: function () {
		if ($("#cb_softBookingList").is(":checked") && !$.rm.softBook.HasRowsSelected())
			$("#softBookingList").jqGrid('resetSelection');
	},

	HasRowsSelected: function () {
		return $("#softBookingList").getGridParam('selarrrow').length > 0;
	},
	HasSingleRowSelected: function () {
		return $("#softBookingList").getGridParam('selarrrow').length == 1;
	},


	BuildGrid: function (rmPageLinkId) {
		var gridSelector = "#softBookingList";
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: rmPageLinkId };
		rm.grid.showGridTools(gridSelector, gridToolsConfig);
		$(gridSelector).jqGrid({
		    url: rm.ajax.requestSvcUrl + "GetSoftBookingList",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false, 'SoftBookingList'), // VG: handle error
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			loadonce: false,
			pager: '#listPager',
			height: (window.screen.height - 440),
			multiselect: true,
			viewsortcols: [true, 'vertical', true],
			sortname: 'Region',
			sortorder: 'asc',
			autowidth: true,
			shrinkToFit: false,
			forceFit: true,
			jsonReader: rm.grid.getJqGridJsonReader(),
			colModel: [
					{ name: 'IconColumn', index: 'IconColumn', label: 'Status <br />Indicator', width: 160, align: 'center', search: true, sortable: false, hidden: false, stype: 'select', searchoptions: { sopt: ['cn'], value: ":All;" + rm.grid.filterOptions.iconSearch_Softbook } },
					rm.grid.standardColumns.getMessageColumn(),
					{ name: 'Region', index: 'Region', label: 'Region', width: 150, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Country', index: 'Country', label: 'Country', width: 70, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'CountryRegion', index: 'CountryRegion', label: 'Country Region', width: 100, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'SponsorName', index: 'SponsorName', label: 'Customer', width: 90, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Program', index: 'Program', label: 'Program', width: 90, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project Code', width: 100, searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'ProjectDteType', index: 'ProjectDteType', label: 'RBM Project', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 7 } } },
					{ name: 'SiteStatus', index: 'SiteStatus', label: 'Site Status', width: 100, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'SponsorSiteName', index: 'SponsorSiteName', label: 'Site Id', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'PrincipalInvestigator', index: 'PrincipalInvestigator', label: 'PI', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Location', index: 'Location', label: 'Location', width: 90, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'VisitTypeName', index: 'VisitTypeName', label: 'Visit<br />Type', width: 60, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'SSVType', index: 'SSVType', label: 'SSV Type', width: 70 },
					{ name: 'Cluster', index: 'Cluster', label: 'Cluster', width: 90, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'ResourceType', index: 'ResourceType', label: 'Resource Request Type', width: 165, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'LineManager', index: 'LineManager', label: 'Line Manager', width: 100, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Resource', index: 'Resource', label: 'Resource Name', width: 120, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'ProposalResource', index: 'ProposalResource', label: 'Proposal<br/>Resource Name', width: 120, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'FTE', index: 'FTE', label: 'FTE', align: 'center', width: 50, classes: 'ui-ellipsis', search: false, sortable: false, cellsformat: 'F3' },
					{ name: 'NeedByDate', index: 'NeedByDate', label: 'Need By Date', width: 100, searchoptions: { attr: { maxlength: 11 } } },
					{ name: 'StartDate', index: 'StartDate', label: 'Start Date', width: 90, searchoptions: { attr: { maxlength: 11 } } },
					{ name: 'StopDate', index: 'StopDate', label: 'Stop Date', width: 90, searchoptions: { attr: { maxlength: 11 } } },
					{ name: 'DateSubmitted', index: 'DateSubmitted', label: 'Submitted<br />Date', width: 80 },
					rm.grid.standardColumns.getNotesColumn()
			],
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			onSelectRow: function (id) { $.rm.softBook.CheckGridRows(); },
			onSelectAll: function (rowIdxArray, sts) { $.rm.softBook.CheckGridRows(); },
			onPaging: function () { $.rm.softBook.ResetRibbonIcons(); },
			serializeRowData: function (postData) { return JSON.stringify(postData); },
			gridComplete: function () {
				rm.ui.notes.bindNotesIconClick();
				$.rm.requestCommon.BindFTECalculatorClick('.calcImage');
				ChangeButtonStatus();
			},
			loadComplete: function (data) {
				rm.grid.addTitlesOnIconColumn();
			},
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("softBookingList"); },
			serializeGridData: function (postData) {
				var data = { RmPageLink: rmPageLinkId };
				return rm.grid.serializeGridData(postData, data);
			}
		});
		$("#softBookingList").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},

	RemoveRow: function (rowId) {
		jQuery("#softBookingList").jqGrid('setSelection', rowId);
		$('#softBookingList').jqGrid('delRowData', rowId);
	},

	HideMessageColumn: function () {
		$('#softBookingList').hideCol("Message");
		$.rm.softBook.ClearGridError();
	},

	ShowMessageColumn: function () {
		$('#softBookingList').showCol("Message");
	},

	ClearGridError: function () {
		var selectedrows = $("#softBookingList").getGridParam('selarrrow');
		for (var i = 0; i < selectedrows.length; i++) {
			$('#softBookingList').setCell(selectedrows[i], 'Message', "");
		}
	},

	bindLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn("#softBookingList_IconColumn", "Request Status Indicator.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_Country", "May be the preferred resource location or the country where the study is taking place.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_CountryRegion", "The region within the country.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_Sponsor", "Customer.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_Program", "Program.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_ProjectCode", "Project Code.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_Protocol", "Protocol.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_ProjectDteType", "RBM Project");
		rm.qtip.showInfoOnGridColumn("#softBookingList_SiteStatus", "The site status from CTMS/InnTrax.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_SponsorSiteName", "Site ID.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_PrincipalInvestigator", "Principal Investigator.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_Location", "Location of the site.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_VisitTypeName", "Visit description or reason for the visit. Applicable to some request types.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_SSVType", "Visit description (On-site or Phone) applicable to SSV requests.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_Cluster", "Currently not applicable in QRPM.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_ResourceType", "Resource Request Type.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_LineManager", "Line Manager.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_Resource", "Resource Name.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_FTE", "Provides the details of the resource request and takes into account the country working hours and % utilization.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_NeedByDate", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_StartDate", "The date when the work begins for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_StopDate", "The date when the work ends for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_Notes", "Use to add/view comments about the particular project/request.");
		rm.qtip.showInfoOnGridColumn("#softBookingList_DateSubmitted", "Date request was submitted");
	}
}

function ChangeButtonStatus() {
	$.rm.softBook._isRemoveSoftBookEnabled = $.rm.softBook.HasRowsSelected();
	$.rm.softBook._isHardBookEnabled = $.rm.softBook.HasSingleRowSelected();
	rm.ui.ribbon.refresh();
}
