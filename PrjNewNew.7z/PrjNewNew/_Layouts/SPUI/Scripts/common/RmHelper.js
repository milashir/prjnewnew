﻿
//TODO:Move to appropriate namespace

//Customized Quintiles Datepicker jQuery plugin
//Attaches datepicker with Quintiles default options, attaches a date validator, and blurs the input field
//Calling syntax: 
//    $("input#myinputid").qDatepicker();               //for single input field
//    $("input.datefield").qDatepicker();               //for all inputs with class 'datefield'
//Maintains jQuery chainability
//Author: Matt Rakestraw

(function ($) {
	var methods = {
		//init runs when no parameters sent to qDatepicker
		init: function (options) {
			var settings = {
				'allowBlank': true,
				'validate': true,
				'destroy': false
			};

			return this.each(function () {
				if (options) {
					$.extend(settings, options);
					if (options.maxDate) {
						rm.datepicker.options.maxDate = options.maxDate;
					}
				}

				var $this = $(this);
				$this.datepicker(rm.datepicker.options);
				if (settings['validate']) {
					$this.delayedObserver(function () {
						if (!rm.date.isValidDate($(this).val(), settings['allowBlank'])) {
							if ($(this).val() == "") { rm.validation.addError(this, "This Date cannot be blank."); }
							else { rm.validation.addError(this, "Invalid Date format. (dd-MMM-yyyy)"); }
						}
						else { rm.validation.clearError(this); }
					});
				}
				if (settings['destroy']) { $this.datepicker('destroy'); }
				$this.blur(); //ensures that the if the first editable cell is a datepicker, it won't have cursor in it before datepicker is avail
			});
		},
		enable: function () { $(this).datepicker("enable"); },
		disable: function () { $(this).datepicker("disable"); },
	};

	$.fn.qDatepicker = function (method) {
		if (methods[method]) {
			return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
		} else if (typeof method === 'object' || !method) {
			return methods.init.apply(this, arguments);
		} else {
			$.error('Method ' + method + ' does not exist on jQuery.qDatepicker');
		}
	};
})(jQuery);

//MR: Override the grep function in autocomplete plugin to only search on starting characters
//  instead of the default any match
$.extend($.ui.autocomplete, {
	filter: function (array, term) {
		var isIe11 = ($.browser != null && $.browser.mozilla == true && $.browser.version == "11.0");
		if ((term || "").length >= (isIe11 ? 4 : 3)) {
			//var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(term), "i");
			var matcher = new RegExp($.ui.autocomplete.escapeRegex(term), "i");
			return $.grep(array, function (value) {
				return matcher.test(value.label || value.value || value);
			});
		}
	}
});

//Keeps TODOs above this line.
//  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
// /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\ /|\
//  |   |	  |   |	  |   |	  |   |	  |   |	  |   |	  |   |	  |   |	  |   |	  |   |	  |   |	  |   |
//================================================================================================
//Hide X next to the search box int he grid
if (jQuery.jgrid) {
	jQuery.extend(jQuery.jgrid.defaults, {
		rowNum: 25,
		rowList: [25, 50, 100, 250, 500],
		viewrecords: true,
		recordpos: "left",
		cmTemplate: {
			searchoptions: {
				clearSearch: false
			}
		}
	});
}

var rm = {};
rm.datepicker = {
	options: {
		//monthNamesShort: { 0: "JAN", 1: "FEB", 2: "MAR", 3: "APR", 4: "MAY", 5: "JUN", 6: "JUL", 7: "AUG", 8: "SEP", 9: "OCT", 10: "NOV", 11: "DEC" },
		monthNamesShort: ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],

		//autoSize: true,
		dateFormat: 'dd-M-yy',
		upperCase: true,
		changeMonth: true,
		changeYear: true,
		yearRange: '-1:+10',
		showButtonPanel: true,
		showOn: 'button',  //focus is default
		buttonText: 'Select a Date',
		buttonImage: '/_layouts/SPUI/images/calendarBig.png',
		buttonImageOnly: true,

		onClose: function () {
			if (!rm.date.isValidDate($(this).val(), true)) {
				$(this).addClass("q_validation_error");
			} else {
				rm.validation.clearError($(this));
			}
		}
	},

};
rm.events = {
	onBudgetRefreshComplete: "rm:budgetRefreshComplete"
};
rm.eventManager = {
	onGlobalDocumentReady: function () {
		rm.eventManager.bindWindowResizeHandler();
		rm.eventManager.bindWindowErrorHandler();
		rm.eventManager.bindRangeValidation();
		rm.cookie.setTimeZoneOffsetCookie();
		rm.budget.initRefresh();
		setTimeout(rm.eventManager.handleWindowResize, 10);
		setTimeout(rm.eventManager.highlightTopLevelMenu, 100);

	},
	highlightTopLevelMenu: function () { $(".left-static-selected-menu").closest(".topMostParent").find("div:first()").addClass("highlightedMenuItem"); },
	bindWindowResizeHandler: function () { $(window).resize(rm.eventManager.handleWindowResize); },
	handleWindowResize: function () {
		$("#s4-workspace").height(rm.ui.getContentContainerHeight());
		$("#RmTopMenu").width(rm.ui.getContentContainerWidth() - 275);
	},
	bindWindowErrorHandler: function () {
		window.onerror = function (msg, url, line) {
			try { rm.serviceCalls.submitClientException({ ErrorInfo: { Message: escape(msg), URL: escape(url), LineNo: escape(line) } }); }
			catch (error) { alert('Exception Handler: Error:' + error.name + ',' + error.message); }
		};
	},
	bindRangeValidation: function () {
		$(document).on("change", ".validateRange", function () { rm.validation.range.validate(this); })
	}
};
rm.eventHandlers = {
	onNavigationShow: function () { },
	onNavigationHide: function () { }
};
rm.staticValues = {
	helpPageBaseUrl: "http://qrpmppm.quintiles.com/help/rm/Pages"
};
rm.runtimeValues = {
	helpPageUrl: "",
	gridOffsetWidth: null
};
rm.constants = {
	keys: {
		cookie: {
			SubReqGridFilter: "SubReqGridFilter",
			SsvAttrGridFilter: "SsvAttrGridFilter",
			MonAttrGridFilter: "MonAttrGridFilter",
			UnSubSsvReqGridFilter: "UnSubSsvReqGridFilter",
			UnSubMonReqGridFilter: "UnSubMonReqGridFilter",
			MyStaffGridFilter: "MyStaffGridFilter"
		}
	}
}
rm.math = {
	max: function (number1, number2) { return number1 > number2 ? number1 : number2; },
	min: function (number1, number2) { return number1 < number2 ? number1 : number2; }
};
rm.announcements = {
	checkForNew: function () {
		rm.ajax.dashboardSvcAsyncGet("AreNewAnnouncementsAvailable", {}, function (hasNewAnnouncements) {
			if (hasNewAnnouncements) {
				$("#newAnnouncementsIndicator").removeClass("hideMe");
			}
			else {
				$.rm.pollForNewAnnouncements();
			}
		});
	},
	pollForNew: function () {
		var pollingInterval = 1000 * 60 * 10;
		setTimeout(rm.announcements.checkForNew, pollingInterval);
	},
};
rm.ajax = {
	requestSvcUrl: "/WCF/Request/Request.svc/",
	resourceSvcUrl: "/WCF/Resource/Resource.svc/",
	projectSvcUrl: "/WCF/Project/ProjectSvc.svc/",
	attributeSvcUrl: "/WCF/Attribute/Attribute.svc/",
	utilitySvcUrl: "/WCF/Utility/Utility.svc/",
	calculatorSvcUrl: "/WCF/Calculator/Calculator.svc/",
	maintenanceUtilitySvcUrl: "/WCF/MaintenanceUtility/MaintenanceUtility.svc/",
	dashboardSvcUrl: "/WCF/DashboardService/dashboardservice.svc/",
	adminSvcUrl: "/WCF/Administration/Administration.svc/",
	userPreferencesSvcUrl: "/WCF/UserPreferences/UserPreferences.svc/",

	makeAjaxCall: function (baseUrl, serviceMethodName, data, isAsync, isGet, successFunction, errorFunction, settings) {
		var ajaxConfig = {
			url: baseUrl + serviceMethodName,
			datatype: 'json',
			cache: false,
			async: isAsync,
			type: isGet ? "GET" : "POST",
			data: isGet ? data : JSON.stringify(data),
			contentType: 'application/json; charset=utf-8',
			success: successFunction,
			error: errorFunction ? errorFunction : function (x, e, serviceError) {
				rm.ui.dialog.showServiceErrorModal("Web Service Error: " + serviceMethodName, x.responseText ? x.responseText : serviceError);
			}
		};
		if (settings) { ajaxConfig.global = settings.global; }
		$.ajax(ajaxConfig);
	},

	requestSvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.requestSvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction, settings);
	},
	requestSvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.requestSvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction);
	},
	requestSvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.requestSvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction);
	},
	requestSvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.requestSvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction);
	},

	resourceSvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.resourceSvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction);
	},
	resourceSvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.resourceSvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction);
	},
	resourceSvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.resourceSvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction);
	},
	resourceSvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.resourceSvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction);
	},

	projectSvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.projectSvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction, settings);
	},
	projectSvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.projectSvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction);
	},
	projectSvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.projectSvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction);
	},
	projectSvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.projectSvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction);
	},

	attributeSvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.attributeSvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction);
	},
	attributeSvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.attributeSvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction);
	},
	attributeSvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.attributeSvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction);
	},
	attributeSvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.attributeSvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction);
	},

	utilitySvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.utilitySvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction);
	},
	utilitySvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.utilitySvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction, settings);
	},
	utilitySvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.utilitySvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction);
	},
	utilitySvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.utilitySvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction);
	},

	calculatorSvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.calculatorSvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction);
	},
	calculatorSvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.calculatorSvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction);
	},
	calculatorSvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.calculatorSvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction);
	},
	calculatorSvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.calculatorSvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction);
	},

	maintenanceUtilitySvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.maintenanceUtilitySvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction, settings);
	},
	maintenanceUtilitySvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.maintenanceUtilitySvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction, settings);
	},
	maintenanceUtilitySvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.maintenanceUtilitySvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction, settings);
	},
	maintenanceUtilitySvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.maintenanceUtilitySvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction, settings);
	},

	dashboardSvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.dashboardSvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction);
	},
	dashboardSvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.dashboardSvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction);
	},
	dashboardSvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.dashboardSvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction);
	},
	dashboardSvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.dashboardSvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction);
	},

	adminSvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.adminSvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction);
	},
	adminSvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.adminSvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction);
	},
	adminSvcSyncPost: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.adminSvcUrl, serviceMethodName, data, false, false, successFunction, errorFunction);
	},
	adminSvcSyncGet: function (serviceMethodName, data, successFunction, errorFunction) {
		this.makeAjaxCall(rm.ajax.adminSvcUrl, serviceMethodName, data, false, true, successFunction, errorFunction);
	},

	preferencesSvcAsyncPost: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.userPreferencesSvcUrl, serviceMethodName, data, true, false, successFunction, errorFunction, settings);
	},
	preferencesSvcAsyncGet: function (serviceMethodName, data, successFunction, errorFunction, settings) {
		this.makeAjaxCall(rm.ajax.userPreferencesSvcUrl, serviceMethodName, data, true, true, successFunction, errorFunction, settings);
	},

	serverPageSyncGet: function (fullPagePath, data, successFunction, errorFunction) {
		this.makeAjaxCall(fullPagePath, "", data, false, true, successFunction, errorFunction);
	},
	serverPageAsyncGet: function (fullPagePath, data, successFunction, errorFunction) {
		this.makeAjaxCall(fullPagePath, "", data, true, true, successFunction, errorFunction);
	},
};

rm.serviceCalls = {
	projectDetails: {},
	submitClientException: function (postData) { rm.ajax.maintenanceUtilitySvcAsyncPost("SubmitClientException", postData, null, null, { global: false }); },
	//This method returns the AllOrganizationOrganizationalUnitRRTs Object for the User
	getAllOrganizationOrganizationalUnitRRTListForUser: function (projectId, forMultiInit) {
		var returnValue = null;
		rm.ajax.requestSvcSyncGet("GetAllOrganizationOrganizationalUnitRRTListForUser", { projectId: projectId, forMultiInit: forMultiInit }, function (data) { returnValue = data; });
		return returnValue;
	},
	getOrganizationsOrganizationalUnitsRRTsWithActiveResourceTypesByProjectId: function (projectId, forMultiInit) {
		initMultiReq.organizationOrganizationalUnitRRTData = rm.serviceCalls.getAllOrganizationOrganizationalUnitRRTListForUser(projectId, true);
		return initMultiReq.organizationOrganizationalUnitRRTData;
	},
	//This method will be used to derive Organizational Units for a Particular Organization from the global variable passed.
	getAllOrganizationalUnitForOrganizationalId: function (organizationId, allOrgOrgUnitRRTList) {
		return $.map(allOrgOrgUnitRRTList, function (element, index) { if (element.organizationId == organizationId) return element.orgUnitKVList });
	},
	getRRTForOrganizationalUnit: function (organizationId, organizationalUnitId) {
		var rrtListForOrgUnit = [];
		var organizationalUnitList = rm.serviceCalls.getAllOrganizationalUnitForOrganizationalId(organizationId, initMultiReq.organizationOrganizationalUnitRRTData);
		if (organizationalUnitId == initMultiReq.anyOrganizationalUnit) {
			//Whenever OrganizationUnit Value is null , then pick RRTs from all orgUnits and display in the RRT DDL
			$.each(organizationalUnitList, function (key, orgUnit) {
				$.each(orgUnit.resourceTypeKVList, function (key, resType) {
					var rrt = { resourceTypeId: resType.resourceTypeId, resourceTypeName: resType.resourceTypeName };
					rrtListForOrgUnit.push(rrt);
				});
			});
			//Sort the RRT List
			rrtListForOrgUnit = rrtListForOrgUnit.sort(function (a, b) {
				return a.resourceTypeName.localeCompare(b.resourceTypeName);
			});
		}
		else {
			rrtListForOrgUnit = $.map(organizationalUnitList, function (element, index) { if (element.organizationalUnitId == organizationalUnitId) return element.resourceTypeKVList });
		}
		return rrtListForOrgUnit;
	},
	getFulfillableResourcesByResourceTypeId: function (resourceTypeId) {
		var resourceList = null;
		rm.ajax.resourceSvcSyncPost("GetFulfillableResourcesByResourceTypeId", { resourceTypeId: resourceTypeId }, function (data) { resourceList = data; });
		return resourceList;
	},
	getAwardedAndProposalProjectList: function () {
		var projectLookupList = null;
		rm.ajax.projectSvcSyncPost("GetAwardedAndProposalProjectList", {}, function (data) { projectLookupList = data; });
		return projectLookupList;
	},
	getProjectDetailsByProjectId: function (projectId) {
		var selectedProjectData = rm.serviceCalls.projectDetails[projectId];
		if (selectedProjectData == null) {
			rm.ajax.requestSvcSyncGet("GetProjectDetailsForInitiateRequest", { projectId: projectId }, function (data) {
				selectedProjectData = data;
				rm.serviceCalls.projectDetails[projectId] = data;
			}, true);
		}
		return selectedProjectData;
	},
	getRequestCounts: function () {
		rm.ajax.requestSvcAsyncPost("RequestCount", {}, function (data) {
			$("#ResourcingWLCountDisplay").html(data.ResourcingRequestCount);
			$("#PendingSoftBookingCount").html(data.SoftbookingCount);
			$("#QueriedRequestCount").html(data.QueriedRequestCount);
			$("#BackfillRequestCount").html(data.BackfillRequestCount);
			$("#SSVRequestCountDisplay").html(data.SsvRequestCount);
			$("#PermanentRequestCountDisplay").html(data.MonitoringRequestCount);
			$("#AwardedProposalRequestCount").html(data.AwardedProposalRequestCount);
		}, null, { global: false });
	},
	calculateWeeklyHours: function (countryId, resourceTypeId, weeklyFte, jobRoleId) {
		var weeklyHours = null;
		rm.ajax.requestSvcSyncGet("CalculateWeeklyHourFTE", { jobRoleId: jobRoleId, countryId: countryId, resourceId: resourceTypeId, modifiedWeeklyHoursFTE: weeklyFte, type: "WF" }, function (data) { weeklyHours = data; });
		return weeklyHours;
	},
	calculateWeeklyFte: function (countryId, resourceTypeId, weeklyHours, jobRoleId) {
		var weeklyFte = null;
		rm.ajax.requestSvcSyncGet("CalculateWeeklyHourFTE", { jobRoleId: jobRoleId, countryId: countryId, resourceId: resourceTypeId, modifiedWeeklyHoursFTE: weeklyHours, type: "WH" }, function (data) { weeklyFte = data; });
		return weeklyFte;
	},
	calculateRegionalWeeklyHours: function (regionId, resourceTypeId, weeklyFte, jobRoleId) {
		var weeklyHours = null;
		rm.ajax.requestSvcSyncGet("CalculateRegionalWeeklyHours", { jobRoleId: jobRoleId, regionId: regionId, resourceId: resourceTypeId, fte: weeklyFte }, function (data) { weeklyHours = data; });
		return weeklyHours;
	},
	calculateRegionalWeeklyFte: function (regionId, resourceTypeId, weeklyHours, jobRoleId) {
		var weeklyFte = null;
		rm.ajax.requestSvcSyncGet("CalculateRegionalFte", { jobRoleId: jobRoleId, regionId: regionId, resourceId: resourceTypeId, weeklyHours: weeklyHours }, function (data) { weeklyFte = data; });
		return weeklyFte;
	},
	calculateGlobalWeeklyHours: function (organizationId, resourceTypeId, weeklyFte, jobRoleId) {
		var weeklyHours = null;
		rm.ajax.requestSvcSyncGet("CalculateGlobalWeeklyHours", { jobRoleId: jobRoleId, organizationId: organizationId, resourceTypeId: resourceTypeId, fte: weeklyFte }, function (data) { weeklyHours = data; });
		return weeklyHours;
	},
	calculateGlobalWeeklyFte: function (organizationId, resourceTypeId, weeklyHours, jobRoleId) {
		var weeklyFte = null;
		rm.ajax.requestSvcSyncGet("CalculateGlobalFte", { jobRoleId: jobRoleId, organizationId: organizationId, resourceTypeId: resourceTypeId, weeklyHours: weeklyHours }, function (data) { weeklyFte = data; });
		return weeklyFte;
	},
	getQipOthersData: function (projectId, countryId, resourceTypeId) {
		var qipData = null;
		rm.ajax.requestSvcSyncGet("RenderInitiateCalculator", { projectId: projectId, countryId: countryId, resourceId: resourceTypeId }, function (data) { qipData = data; });
		return qipData;
	},
	getQipRegionalData: function (projectId, regionId, resourceTypeId, startDate) {
		var qipData = null;
		rm.ajax.requestSvcSyncGet("RenderRegionBasedInitiateCalculator", { projectId: projectId, regionId: regionId, resourceId: resourceTypeId, requestStartDate: startDate }, function (data) { qipData = data; });
		return qipData;
	},
	getQipGlobalData: function (projectId, organizationId, resourceTypeId, startDate, stopDate) {
		var qipData = null;
		rm.ajax.requestSvcSyncGet("RenderGlobalInitiateCalculator", { projectId: projectId, organizationId: organizationId, resourceTypeId: resourceTypeId, requestStartDate: startDate, requestStopDate: stopDate }, function (data) { qipData = data; });
		return qipData;
	},
	getCustomFieldsByResourceTypeId: function (resourceTypeId, requestId, projectId, successHandler) {
		rm.ajax.requestSvcAsyncPost("GetResourceTypeCustomFieldsByResourceType", { resourceTypeId: resourceTypeId, requestId: requestId, projectId: projectId }, successHandler);
	},
	getPreferredRegion: function (projectId) {
		var response = null;
		rm.ajax.requestSvcSyncPost("GetAssignedRegions", { projectId: projectId }, function (data) { response = data; });
		return response;
	},
	getAssignedRegionAndCountriesByProjectId: function (projectId) {
		var response = null;
		rm.ajax.utilitySvcSyncGet("GetAssignedRegionAndCountriesByProjectId", { projectId: projectId }, function (data) { response = data; });
		return response;
	},
	getAllMilestonesByProjectId: function (projectId, countryId, requestId, getActiveOnly, resourceTypeOrganizationId, resourceTypeId) {
		var returnValue;
		rm.ajax.projectSvcSyncPost("GetAllMilestonesByProjectId", {
			countryId: countryId,
			getActiveOnly: getActiveOnly,
			projectId: projectId,
			requestId: requestId,
			resourceTypeOrganizationId: resourceTypeOrganizationId,
			resourceTypeId: resourceTypeId
		}, function (response) { returnValue = response; });
		return returnValue;
	},
	getCountryRegionsByCountryIdList: function (data, successFunction) { rm.ajax.requestSvcAsyncGet("GetCountryRegionCountryName", data, successFunction); },
	getCountryRegionsByCountryIdListSync: function (data, successFunction) { rm.ajax.requestSvcSyncGet("GetCountryRegionCountryName", data, successFunction); },
	calculateTotalHours: function (data, successFunction) { rm.ajax.utilitySvcAsyncGet("CalculateTotalHours", data, successFunction); },
	getResourcableResourcesForSpecialResourcingNeed: function (successFunction) { rm.ajax.resourceSvcAsyncPost("GetResourcableResourcesForSpecialResourcingNeed", {}, successFunction); },
	getRegionsByUserPermissions: function () {
		var response = null;
		rm.ajax.utilitySvcSyncGet("Geography/GetRegions", {}, function (data) { response = $.parseJSON(data); });
		return response;
	},
	getRegionConnectedMilestoneDetailsFromDb: function (resourceTypeId, projectId, regionId) {
		var connectedMilestoneDetails;
		rm.ajax.requestSvcSyncPost("GetRegionConnectedMilestoneDetailsFromDb", { resourceTypeId: resourceTypeId, projectId: projectId, regionId: regionId }, function (data) {
			connectedMilestoneDetails = data;
		}, false);

		return connectedMilestoneDetails;
	},
	getCustomFieldDefaultvalues: function (resourceTypeId, projectId, countryId, successFunction) { rm.ajax.requestSvcAsyncGet("GetCustomFieldDefaultvalues", { resourceTypeId: resourceTypeId, projectId: projectId, countryId: countryId }, successFunction); },
	getAllComputedReqestMilestoneDaysToAdd: function () {
		var returnValue;
		rm.ajax.requestSvcSyncGet("GetAllComputedReqestMilestoneDaysToAdd", {}, function (data) { returnValue = data; });
		return returnValue;
	},
	isRequestValid: function (requestId, getAlertForReadOnly, rmPageLink) {
		var isValid = true;
		var postData = { requestId: requestId, getAlertForReadOnly: getAlertForReadOnly, rmPageLink: rmPageLink };
		rm.ajax.requestSvcSyncPost("IsRequestValid", postData, function (data) {
			if (data.ContainsValidationErrors) {
				rm.validation.processErrorMessages(data.ValidationErrors);
				isValid = false;
			}
		});

		return isValid;
	},
	getRmUserDataGridColumnPreferences: function (dataGridId, onSuccessHandler) {
		rm.ajax.preferencesSvcAsyncPost(
			"GetRmUserDataGridColumnPreferences",
			{ dataGridId: dataGridId },
			onSuccessHandler);
	},
	getRegionsByResourceTypId: function (resourceTypeId) {
		var response = null;
		rm.ajax.utilitySvcSyncPost("GetRegionsByResourceTypId", { resourceTypeId: resourceTypeId }, function (serviceResponse) { response = serviceResponse; });
		return response;
	},
	getCountriesByResourceTypId: function (resourceTypeId, projectId, regionId) {
		var response = null;
		rm.ajax.utilitySvcSyncPost("GetCountriesByResourceTypId", { resourceTypeId: resourceTypeId, regionId: regionId, projectId: projectId }, function (serviceResponse) { response = serviceResponse; });
		return response;
	},
	getCountryPhaseCalculatorsByRequestIdSync: function (requestId) {
		var response;
		rm.ajax.requestSvcSyncGet("GetInitiateCalculatorbyRequest?requestId=" + requestId, null, function (svcResponse) { response = svcResponse; });
		return response;
	},
	GetCalculatorsByRequestId: function (requestId) {
		var response;
		rm.ajax.requestSvcSyncGet("GetCalculatorsByRequestId?requestId=" + requestId, null, function (svcResponse) { response = svcResponse; });
		return response;
	},
};

rm.dropdown = {
	empty: function (selector) { $(selector).empty(); },
	emptyWithSelect: function (selector) { $(selector).empty().append($("<option>").val("-1").html("--Select--")); },
	emptyWithAny: function (selector) { $(selector).empty().append($("<option>").val("0").html("--Any--")); },
	fill: function (selector, data, keyName, valueName, selectedValue, addSelectAsFirstItem, addAnyAsFirstItem) {
		if (addAnyAsFirstItem) { this.emptyWithAny(selector); }
		else
			if (addSelectAsFirstItem != false) { this.emptyWithSelect(selector); }
			else { this.empty(selector); }

		if (data) {
			$.each(data, function (index, element) {
				$(selector).append($("<option>", (element[keyName] == selectedValue) ? { "selected": "selected" } : {}).val(element[keyName]).html(element[valueName]));
			});
		}
	}
};
rm.validation = {
	errorClass: "q_validation_error",
	validateRangeClass: "validateRange",
	visibleValidateRangeSelector: ".validateRange:visible",
	processErrorMessages: function (validationErrors, gridSelector, iconColumnName) {
		var arrayMessagesfordialog = [];
		$.each(validationErrors, function (index, ele) {
			switch (ele.MessageType) {
				case MessageType_E.Error:
					rm.validation.addError(ele.Key, ele.Value);
					break;
				case MessageType_E.Warning:
					rm.ui.messages.addWarningWithCloseButton(ele.Value);
					break;
				case MessageType_E.AlertMessage:
					alert(ele.Value);
					break;
				case MessageType_E.SharepointNotification:
					rm.ui.messages.addError(ele.Value);
					break;
				case MessageType_E.GridIcon:
					rm.grid.showErrorIconInMessageColumn(gridSelector, ele.Key, iconColumnName, ele.Value);
					break;
				case MessageType_E.AlertMessageThenRefreshPage:
					window.onbeforeunload = null;
					alert(ele.Value);
					RefreshPage();
					return false;
					break;
				case MessageType_E.ConsolidateAndShowInDialog:
					arrayMessagesfordialog.push(ele.Value);
					break;
				case MessageType_E.CustomHandling:
					//Custom handling is done from code that makes web service call
					break;
				default: alert("Invalid message type:" + ele.MessageType);
			}
		});
		if (arrayMessagesfordialog.length > 0) {
			var divSelector = "#" + rm.ui.constants.errorDialogId;
			if ($(divSelector).length == 0) { $("body").append($("<div>", { id: rm.ui.constants.errorDialogId })); }
			var htmlMessage = "<table class='validationTable'><tr class='headerRow'><td valign='top'>Validaton Error</td></tr>";
			$.each(arrayMessagesfordialog, function (index, message) {
				htmlMessage += "<tr><td>" + message + "</td></tr>";
			});
			htmlMessage += "</table>";
			//rmCommon.showDialogWithOkButton("Error occured", htmlMessage, null);

			rm.ui.dialog.showModalWithButtons(divSelector, "Error occured", htmlMessage, true, 620, "auto", [{ text: "Ok", click: function () { $(this).dialog("close"); } }])
		}

	},
	clearError: function (elementOrSelector) {
		rm.qtip.clear(elementOrSelector);
		$(elementOrSelector).removeClass(this.errorClass);
	},
	clearAllErrors: function (selector) { $.each($(selector), function (index, ele) { rm.validation.clearError($(ele)); }); },
	utility: {
		isFormatted: function (element) {
			var jqElement = $(element);
			var formating = jqElement.attr('formating').split(',');
			var valueToFormat = jqElement.val().split('.');

			// if no decimal allowed (whole number) i.e. without decimal point like 100. & 100.0 ect.
			if ((parseInt(formating[1], 10) == 0) && (valueToFormat.length > 1)) {
				return false;
			}

			// Show error if there are more then 2 decimal points in the value (12.34.56)
			if (valueToFormat.length > 2) {
				return false;
			}
			if (valueToFormat[0].length > parseInt(formating[0], 10)) {
				return false;
			}

			// If there are no decimal point
			if (valueToFormat.length > 1 &&
				valueToFormat[1].length > parseInt(formating[1], 10)) {
				return false;
			}
			return true;
		},
		bindEventsOnTextareaForMaxLengthValidation: function (textAreaSelector, charactersRemainingSelector) {
			var maxLength = parseInt($(textAreaSelector).attr("maxLength"));
			$(textAreaSelector).keyup(function () {
				var fieldValue = $(this).val();
				var charactersRemaining = maxLength - fieldValue.length;
				$(charactersRemainingSelector).html(charactersRemaining);

				if (charactersRemaining >= 0) { rm.validation.clearError($(this)); }
				else { rm.validation.addError($(this), "Maximum character limit: " + maxLength); }
			});
		}
	},
	addError: function (elementOrSelector, errorMessage) {
		rm.qtip.showError(elementOrSelector, errorMessage);
		$(elementOrSelector).addClass(this.errorClass);
	},
	numeric: {
		isInteger: function (inputString) { return /^\d+$/.test(inputString); },
		isDecimal: function (inputString) { return /^\d+\.?\d*$/.test(inputString); },
		isNumber: function (inputString) { return rm.validation.numeric.isDecimal(inputString); }
	},
	hasError: function (elementOrSelector) { return $(elementOrSelector).hasClass(rm.validation.errorClass); },
	hasControlsWithErrors: function () { return ($("." + rm.validation.errorClass).length > 0); },
	range: {
		validate: function (selector) {
			var jqElement = $(selector);
			var valueToValidate = jqElement.val();
			var numericValueToValidate = parseFloat(valueToValidate, 10);

			var format = jqElement.attr('formating');
			var errorMessage = jqElement.attr('errorMessage');
			var allowedMinValue = parseFloat(jqElement.attr('from'), 10);
			var allowedMaxValue = parseFloat(jqElement.attr('to'), 10);
			var allowBlank = jqElement.attr('allowBlank');
			var correctRangeMessage = 'Correct range is: ' + allowedMinValue + ' - ' + allowedMaxValue;
			var numberOfAllowedDecimals = 0;
			var indexOfComma = format.indexOf(",");

			if (indexOfComma > -1) {
				numberOfAllowedDecimals = format.substring(indexOfComma + 1);
			}

			var isInteger = (numberOfAllowedDecimals == 0);
			rm.validation.clearError(selector);

			if ($.trim(valueToValidate) == "" && typeof allowBlank !== 'undefined' && allowBlank !== "false") {
				return true;
			}

			if (!rm.validation.numeric.isDecimal(valueToValidate)) {
				if (!errorMessage) {
					errorMessage = (isInteger ? 'Enter integer value only, ' : 'Enter numeric value only, ') + correctRangeMessage;
				}

				rm.validation.addError(jqElement, 'Incorrect formatting. ' + errorMessage);
				return false;
			}
			else if (numericValueToValidate > allowedMaxValue || numericValueToValidate < allowedMinValue) {
				if (!errorMessage) {
					errorMessage = 'The value entered is not within the expected range. ' + correctRangeMessage;
				}
				rm.validation.addError(selector, errorMessage);
				return false;
			}

			if (!rm.validation.utility.isFormatted(jqElement)) {
				correctFormatMessage = isInteger ? "Enter integer value only." : "Correct format is: (" + format.replace(",", ".") + ")";
				rm.validation.addError(jqElement, 'Incorrect formatting. ' + correctFormatMessage);
				return false;
			}
			return true;
		}
	},
	bindMaxLengthForTextArea: function () {
		$.each($(".maxLengthForTextarea"), function (index, element) {
			var jqObject = $(element);

			if (!jqObject.attr("hasMaxLength")) {
				jqObject.attr("hasMaxLength", true);
				var container = $("<div>").insertBefore(jqObject);
				container.append(jqObject);
				$("<div class='CharLeftContainer'>Chars left: <span class='CharLeftValue'>" + jqObject.attr("maxLength") + "</span></div>").insertAfter($(element));
				setTimeout(function () { $.validationHelper.bindKeypressOnTextArea(jqObject); }, 10);
			}
		});
	},
	setCharactersLeftCount: function (jqObject) { jqObject.parent().find(".CharLeftValue").html(jqObject.attr("maxLength") - jqObject.val().length); },
	bindKeypressOnTextArea: function (jqObject) {
		jqObject.bind("keydown cut paste drop", function () {
			setTimeout(function () {
				var maxLength = jqObject.attr("maxLength");
				var maxLengthError = jqObject.attr("maxLengthError") || "";
				var blankValueError = jqObject.attr("blankValueError") || "";
				var currentContentLength = jqObject.val().length;
				jqObject.parent().find(".CharLeftValue").html(maxLength - currentContentLength);

				if (maxLength < currentContentLength) {
					maxLengthError = maxLengthError || "Maximum character limit: " + maxLength;
					rm.validation.addError(jqObject, maxLengthError);
				}
				else {
					if ($.trim(jqObject.val()) != "") {
						rm.validation.clearError(jqObject);
					}
					else if (blankValueError != "") {
						rm.validation.addError(jqObject, blankValueError);
					}
				}
			}, 10);
		});
	}
};
rm.qtip = {
	config: {
		content: { content: { attr: "title" } },
		show: { event: "focus mouseenter", delay: 500 },
		hide: { event: "blur mouseleave" },
		position: { my: "bottom left", at: "top right", viewport: $(window) },
		style: { width: "295px", classes: "qTipNoMaxWidth" },
		errorStyle: { classes: "qtip-red", width: "295px" }
	},
	hasQtip: function (elementSelector) { return $(elementSelector).attr("data-hasqtip") != undefined; },
	destroy: function (elementSelector) { $(elementSelector).removeAttr('oldtitle').removeAttr('title').qtip("destroy", true); },
	clear: function (elementSelector) { $(elementSelector).removeAttr('oldtitle').removeAttr('title').qtip("destroy", true); },
	update: function (elementSelector, message) { $(elementSelector).attr("title", message); },
	showError: function (elementSelector, message, errorStyleConfig, positionConfig, showConfig, hideConfig) {
		$(elementSelector).attr("title", message);
		if (!rm.qtip.hasQtip(elementSelector)) { rm.qtip.bindError(elementSelector, message, errorStyleConfig, positionConfig, showConfig, hideConfig); }
	},
	showInfo: function (elementSelector, message, styleConfig, positionConfig, showConfig, hideConfig) {
		$(elementSelector).attr("title", message);
		if (!rm.qtip.hasQtip(elementSelector)) { rm.qtip.bindInfo(elementSelector, message, styleConfig, positionConfig, showConfig, hideConfig); }
	},
	showInfoOnGridColumn: function (elementSelector, message, styleConfig, positionConfig, showConfig, hideConfig) {
		rm.qtip.showInfo(elementSelector, message, $.extend({ width: "200px" }, styleConfig), $.extend({ my: "bottom center", at: "top center" }, positionConfig), showConfig, hideConfig);
	},
	bind: function (elementSelector, message, styleConfig, positionConfig, showConfig, hideConfig) {
		if ($(elementSelector).length > 0) {
			$(elementSelector).attr("title", message || " ").qtip({
				style: $.extend({}, rm.qtip.config.style, styleConfig),
				position: $.extend({}, rm.qtip.config.position, positionConfig),
				show: $.extend({}, rm.qtip.config.show, showConfig),
				hide: $.extend({}, rm.qtip.config.hide, hideConfig),
				content: rm.qtip.config.content
			});
		}
	},
	bindError: function (elementSelector, message, errorStyleConfig, positionConfig, showConfig, hideConfig) { rm.qtip.bind(elementSelector, message, $.extend({}, rm.qtip.config.errorStyle, errorStyleConfig), positionConfig, showConfig, hideConfig); },
	bindInfo: function (elementSelector, message, styleConfig, positionConfig, showConfig, hideConfig) { rm.qtip.bind(elementSelector, message, $.extend({}, rm.qtip.config.style, styleConfig), positionConfig, showConfig, hideConfig); },
};
rm.utilities = {
	controlcharacterArray: [9, 11, 13, 16, 17, 18, 20, 27, 33, 34, 35, 36, 37, 38, 39, 40, 45, 91, 93, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 255],
	isControlCharacter: function (keyCode) { return rm.utilities.controlcharacterArray.indexOf(keyCode) != -1; },
	isNonControlCharacter: function (keyCode) { return !rm.utilities.isControlCharacter(keyCode); },
	isEnterKey: function (keyCode) { return (keyCode == $.ui.keyCode.ENTER); },
	getCountriesBySelectedRegion: function (regionId) {
		var countryList = null;
		$.each(CountriesByRegion, function (index, countryRegion) {
			if (countryRegion.Key == regionId) {
				countryList = countryRegion.CountryList;
				return false;
			}
		});
		return countryList;
	},
	pad: function (n) {
		n = String(n);
		return n < 10 ? '0' + n : n;
	},
	formatNumberString: function (value, formatString) {
		finalValue = value;
		if ((formatString !== undefined && formatString != "") && formatString.indexOf(",") != -1 && value != "") {
			var digitsAfterDecimal = formatString.split(",")[1];
			if (digitsAfterDecimal > 0) {
				var myValue = parseFloat(value).toFixed(digitsAfterDecimal);
				var formattedValue = myValue.toString();
				if (formattedValue[0] == ".") {
					formattedValue = "0" + formattedValue;
				}
				while (formattedValue[formattedValue.length - 1] == "0") {
					formattedValue = formattedValue.substring(0, formattedValue.length - 1);
				}
				if (formattedValue[formattedValue.length - 1] == ".") {
					formattedValue = formattedValue.substring(0, formattedValue.length - 1);
				}
				finalValue = formattedValue;
			}
		}
		return finalValue;
	},
	formatTextboxText: function (element) {
		var me = $(element);
		var formattedValue = rm.utilities.formatNumberString(me.val(), me.attr("formating"))
		$(element).val(formattedValue);

		return formattedValue;
	},
	preventNavigationOnBackSpace: function (e) {
		if ((e.keyCode || e.which) == 8) {
			e.preventDefault();
			e.stopPropagation();
		}
	},
	reloadPageWithDelay: function (delay) { setTimeout(rm.utilities.reloadPage, (delay || 1000)); },
	reloadPage: function () { location.reload(); },
	redirectToUrl: function (url) { document.location.href = url; },
	getSignInAsDifferentUserUrl: function () { return ("/_layouts/SPUI/SignInAsDifferentUser.aspx?changeUser=true&source=" + encodeURIComponent(window.location.href)); },
	setSelectedNavLinkAndHelpUrl: function (rmPageLink) {
		var helpURL = "";
		var selector;
		switch (rmPageLink) {
			case RmPageLink_E.InitiateNewRequests:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_All_Initiate:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Initiate:
				helpURL = "Initiate-New-Requests.aspx";
				selector = "#InitiateRequest";
				break;
			case RmPageLink_E.AwardedProposalRequest:
				helpURL = "Awarded-Proposal-Requests.aspx";
				selector = "#AwardedProposalRequest";
				break;
			case RmPageLink_E.SubmittedRequests:
			case RmPageLink_E.OverDue_All_SubmittedRequests:
			case RmPageLink_E.OverDue_DirectReport_SubmittedRequests:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_All_Submitted:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Submitted:
			case RmPageLink_E.InactiveResourceStillAssigned_All:
			case RmPageLink_E.InactiveResourceStillAssigned_DirectReports:
			case RmPageLink_E.UnassignedSubmittedRequests:
				helpURL = "Submitted-Request.aspx";
				selector = "#SubmittedRequest";
				break;
			case RmPageLink_E.QueriedRequests:
			case RmPageLink_E.OverDue_All_QueriedRequests:
			case RmPageLink_E.OverDue_DirectReport_QueriedRequests:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_All_Queried:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Queried:
				helpURL = "Queried-Request.aspx";
				selector = "#queriedRequestNavLink";
				break;
			case RmPageLink_E.BackfillRequests:
			case RmPageLink_E.OverDue_All_BackfillRequests:
			case RmPageLink_E.OverDue_DirectReport_BackfillRequests:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_All_Backfill:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Backfill:
			case RmPageLink_E.UnsubmittedBackfillRequests_All:
			case RmPageLink_E.UnsubmittedBackfillRequests_DirectReports:
				helpURL = "Backfill-Request.aspx";
				selector = "#backfillRequestNavLink";
				break;
			case RmPageLink_E.SSVRequests:
			case RmPageLink_E.Autogenerated_SsvRequests:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_All_Ssv:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Ssv:
				helpURL = "SSV-Request.aspx";
				selector = "#SSVRequest";
				break;
			case RmPageLink_E.MonitoringRequests:
			case RmPageLink_E.Autogenerated_MonitoringRequests:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_All_Monitoring:
			case RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Monitoring:
				helpURL = "Monitoring-Request.aspx";
				selector = "#MonitoringRequest";
				break;
			case RmPageLink_E.MyStaff:
				helpURL = "My-Staff.aspx";
				selector = "#MyLinks_MyStaff";
				break;
			case RmPageLink_E.InitiateMultipleRequests:
				helpURL = "Multiple-Initiate-and-Assign.aspx";
				selector = "#InitiateMultipleRequestsNav";
				break;
			case RmPageLink_E.ResourcingWorklist:
				helpURL = "Resourcing-Worklist.aspx";
				selector = "#Resourcing_Worklist";
				break;
			default:
				rm.ui.messages.addError('Bad request group in query string: ' + rmPageLink);
				break;
		}

		$(selector).addClass("left-static-selected-menu");
		rm.runtimeValues.helpPageUrl = helpURL;
	},
	getAbsoluteHelpUrl: function () { return rm.staticValues.helpPageBaseUrl + "/" + rm.runtimeValues.helpPageUrl; },
	openHelp: function () {
		window.open(rm.utilities.getAbsoluteHelpUrl(), "HelpWindow");
		return false;
	},
	goHome: function () {
		document.location = "/_layouts/spui/Dashboard/Dashboard.aspx";
	},
	goDashboard: function () {
		document.location = "/_layouts/spui/Dashboard/Dashboard.aspx";
	},
	checkIfProcessIsRunning: function (entityId, processId, entityTypeId, processRunningResponseHandler) {
		if ($.isNumeric(entityId)) {
			rm.ajax.utilitySvcAsyncGet("IsProcessRunning", { entityId: entityId, processId: processId, entityTypeId: entityTypeId }, function (serviceResponse) {
				if ($.isFunction(processRunningResponseHandler)) {
					processRunningResponseHandler(serviceResponse);
				}
				setTimeout(function () {
					rm.utilities.checkIfProcessIsRunning(entityId, processId, entityTypeId, processRunningResponseHandler);
				}, rm.time.getMillisecondsFromSeconds(30));
			}, null, { global: false });
		}
	},
	getJsonOrStringArray: function (jsonOrValueString) { try { return JSON.parse(jsonOrValueString); } catch (ex) { return [jsonOrValueString]; } },
	getNullIfEmpty: function (value) { return $.trim(value) == "" ? null : value; },
	peoplePicker: {
		getValue: function (serverControlId) {
			lookedUpValue = $("[id$=" + serverControlId + "] [id=content]").html();
			valueBeingTyped = $("[id$=" + serverControlId + "] [id$=" + serverControlId + "_upLevelDiv]").html();
			valueBeingTyped = valueBeingTyped.replace(/&nbsp;/, "");
			valueBeingTyped = valueBeingTyped.replace(/<br>/, "");
			return (lookedUpValue != "") ? lookedUpValue : valueBeingTyped;
		},
		setValue: function (serverControlId, value) { $("[id$=" + serverControlId + "_upLevelDiv]").html(value); },
		getDivId: function (serverControlId) { return $("[id$=" + serverControlId + "_upLevelDiv]").attr("id"); },
		lookupValue: function (serverControlId) { $("[id$=" + serverControlId + "_checkNames]").click(); },
	},
	insertArrayInArrayAtIndex: function (targetArray, arrayToInsert) {
		if (Array.isArray(targetArray) && Array.isArray(arrayToInsert) && arrayToInsert.length > 0) {
			for (var index = arrayToInsert.length - 1; index >= 0; index--) {
				targetArray.splice(0, 0, arrayToInsert[index]);
			}
		}
	},
	addDivToDomIfNotPresent: function (divId) {
		var container = $("#" + divId);
		if (container.length == 0) {
			container = $("<div>", { id: divId });
			$("body").append(container);
		}
	},
	showReadonlyCalculatorInDialog: function (requestId, divId) {
		var isDataAvailable = true;

		if ((divId || "") != "") {
			var fteReadonlyDiv = $("#" + divId);
			if (fteReadonlyDiv.length == 0) {
				fteReadonlyDiv = $("<div id='" + divId + "' />");
				$("body").append(fteReadonlyDiv);
				isDataAvailable = false;
			}
		}
		else {
			divId = "DivReqRoCalc";
			$("#" + divId).remove();
			fteReadonlyDiv = $("<div id='" + divId + "' />");
			$("body").append(fteReadonlyDiv);
			isDataAvailable = false;
		}

		if (!isDataAvailable) {
			rm.ajax.requestSvcAsyncGet("GetCalculatorDetails", { requestId: requestId }, function (data) {
				fteReadonlyDiv.html(data.Body).dialog({
					modal: true,
					cache: false,
					title: data.Title,
					resizable: false,
					width: data.Width,
					height: data.Height
				});
				setTimeout(function () {
					$.each($(".fteTableTitlesHover"), function (index, element) {
						var jqObj = $(element).find("span");
						rm.qtip.showInfo(jqObj, jqObj.attr("toolTip"));
					});
				}, 10);

				if (data.SiteSchedule) {
					$.each(data.SiteSchedule.FrequencyDates, function (index, frequencyDateDetail) {
						var infoValue = "<b>Start Date:</b> " + frequencyDateDetail.StartDate +
							"<br /><b>Start Date Source:</b> " + frequencyDateDetail.StartDateSource +
							"<br /><b>Stop Date:</b> " + frequencyDateDetail.StopDate +
							"<br /><b>Stop Date Source:</b> " + frequencyDateDetail.StopDateSource;

						var iconSelector = "#infoIcon_" + requestId + "_" + frequencyDateDetail.CalculatorType;
						rm.qtip.showInfo(iconSelector, infoValue);
					});
				}
			});
		}
		else {
			$("#" + divId).dialog("open");
		}
	},
	delayedBindInfoOnGridFteIconColumn: function () {
		setTimeout(function () {
			$.each($("[id^=infoIcon_]"), function (index, ele) {
				var title = $.trim($(ele).attr("title"));
				if (title != "") {
					rm.qtip.showInfo(ele, title, { width: '730' }, {});
				}
			});
		}, 100);
	},
	getFteCalcInfoTextByResourceTypeId: function (resourceTypeId) {
		return RequestInfoIconText_E[resourceTypeId];
	},
	getFteCalculatorTextByResourceTypeId: function (resouceTypeId) {
		return RequestInfoIconTextForFTECalculatorText_E[parseInt(resouceTypeId)];
	}
};
rm.projectInContext = {
	getProjectCode: function () { return $("#ProjectNameDisplay").text(); },
	getProtocolNumber: function () { return $("[id$=_ProtocolNumber]").val(); },
	getOrganizationalUnitName: function () { return $("[id$=_OrganizationUnitName]").val(); }
};
rm.time = {
	getMillisecondsFromDays: function (numberOfDays) { return this.getMillisecondsFromHours(24) * numberOfDays; },
	getMillisecondsFromHours: function (numberOfHours) { return this.getMillisecondsFromMinutes(60) * numberOfHours; },
	getMillisecondsFromMinutes: function (numberOfMinutes) { return this.getMillisecondsFromSeconds(60) * numberOfMinutes; },
	getMillisecondsFromSeconds: function (numberOfSeconds) { return 1000 * numberOfSeconds; },
};
rm.date = {
	monthNames: { JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5, JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11 },
	monthNumbers: { 0: "JAN", 1: "FEB", 2: "MAR", 3: "APR", 4: "MAY", 5: "JUN", 6: "JUL", 7: "AUG", 8: "SEP", 9: "OCT", 10: "NOV", 11: "DEC" },
	isValidDate: function (qdate, allowBlank) {
		var isValid = false;

		if (qdate && qdate != "") {
			var datePartArr = qdate.split("-");
			if (datePartArr.length == 3) {
				var d = new Date(0, 0, 1);
				var year = datePartArr[2];
				var month = this.monthNames[datePartArr[1]];
				var day = datePartArr[0];

				if (day.length != 2 || !rm.validation.numeric.isNumber(day) || (day * 1) < 1 || (day * 1) > 31) {
					isValid = false;
				}
				else {
					d.setFullYear(year, month, day);
					isValid = (d.getMonth() == month && d.getFullYear() == year && d.getDate() == day);
					if (isValid && (year < 1900 || year > 9999 || year.toString().length != 4)) {
						isValid = false;
					}
				}
			}
			else {
				isValid = false;
			}
		}
		else {
			isValid = (allowBlank == null) ? false : allowBlank;
		}

		return isValid;
	},
	getQDateStringFromDate: function (date) {
		var qDateString = "";
		if (date && date.getMonth) {
			qDateString = rm.utilities.pad(date.getDate()) + "-" + this.monthNumbers[date.getMonth()] + "-" + date.getFullYear();
		}
		return qDateString;
	},
	getDateFromQDateString: function (qdate) {
		var d = new Date(0, 0, 1);
		if (qdate != null && qdate != "") {
			var datePartArr = qdate.split("-");
			if (datePartArr.length == 3) {
				var year = datePartArr[2];
				var month = this.monthNames[datePartArr[1]];
				var day = datePartArr[0];
				d.setFullYear(year, month, day);
			}
		}
		return d;
	},
	isQDateDateGreaterThanToday: function (qDate) { return this.getDateFromQDateString(qDate) > this.today(); },
	isQDateDateGreaterOrEqualToToday: function (qDate) { return this.getDateFromQDateString(qDate) >= this.today(); },
	isQDateDateInPast: function (qDate) { return this.getDateFromQDateString(qDate) < this.today(); },
	isDateInPast: function (date) { return date < this.today(); },
	today: function () { return (new Date((new Date()).setHours(0, 0, 0, 0))); },
	getTodayAsQDateString: function () { return this.getQDateStringFromDate(this.today()); },
	addDaysToQdate: function (qDate, numberOfDays) { return this.getQDateStringFromDate(this.addDays(this.getDateFromQDateString(qDate), numberOfDays)); },
	addDays: function (date, numberOfDays) { return new Date(date.getTime() + rm.time.getMillisecondsFromDays(numberOfDays)); },
	addMonthsToQdate: function (qDate, monthsToAdd) { return this.getQDateStringFromDate(this.addMonths(this.getDateFromQDateString(qDate), monthsToAdd)); },
	addMonths: function (date, monthsToAdd) {
		var m, d = (date = new Date(+date)).getDate()
		date.setMonth(date.getMonth() + monthsToAdd, 1)
		m = date.getMonth();
		date.setDate(d);
		if (date.getMonth() !== m) { date.setDate(0); }

		return new Date(date);
	},
	dateDiffDays: function (startDate, stopDate) { return (stopDate - startDate) / rm.time.getMillisecondsFromDays(1); },
	qDateDiffDays: function (startDate, stopDate) { return this.dateDiffDays(this.getDateFromQDateString(startDate), this.getDateFromQDateString(stopDate)); },
	qDateDiffWeeks: function (startDate, stopDate) { return this.qDateDiffDays(startDate, stopDate) / 7; },
	maxDate: function (date1, date2) { return (date1 > date2) ? date1 : date2; },
	areStartStopDatesValid: function (startDateCtrl, stopDateCtrl, allowStartDateInPast) {
		var isValid = true;
		var isStartDateValid = rm.date.isValidDate(startDateCtrl.val());
		if (isStartDateValid) {
			if (!allowStartDateInPast && !rm.date.isQDateDateGreaterOrEqualToToday(startDateCtrl.val())) {
				rm.validation.addError(startDateCtrl, Resources.StartDateInPast);
				isValid = false;
			}
			else { rm.validation.clearError(startDateCtrl); }
		}
		else { isValid = false; }

		if (rm.date.isValidDate(stopDateCtrl.val())) {
			if (isStartDateValid && rm.date.getDateFromQDateString(startDateCtrl.val()) > rm.date.getDateFromQDateString(stopDateCtrl.val())) {
				rm.validation.addError(startDateCtrl, Resources.StartDateGreaterThanStopDate);
				rm.validation.addError(stopDateCtrl, Resources.StopDateLessThanStartDate);
				isValid = false;
			}
			else { rm.validation.clearError(stopDateCtrl); }
		}
		else { isValid = false; }

		return isValid;
	}
};
rm.cookie = {
	setTimeZoneOffsetCookie: function () {
		var timezoneOffsetCookieName = "QRPM_timezoneOffsetCookie";
		var today = new Date();
		if (document.cookie) {
			var cIndex = document.cookie.indexOf(timezoneOffsetCookieName);
			if (cIndex == -1) {
				//Cookie does not exist. Write the cookie and refresh the page
				document.cookie = timezoneOffsetCookieName + "=" + today.getTimezoneOffset() +
					"; path=/; expires=" + new Date(today.getTime() + rm.time.getMillisecondsFromDays(1)).toGMTString();
			}
		}
	},
	setValue: function (cookieKey, value) { $.cookie(cookieKey, JSON.stringify(value)); },
	clearValue: function (cookieKey) { $.cookie(cookieKey, null); },
	pushProperties: function (cookieKey, properties) {
		var cookieValue = $.cookie(cookieKey);
		var cookieJson = {};
		if (cookieValue) { cookieJson = JSON.parse(cookieValue); }

		for (var prop in properties) {
			if (properties.hasOwnProperty(prop)) {
				cookieJson[prop] = properties[prop];
			}
		}
		$.cookie(cookieKey, JSON.stringify(cookieJson));
	},
	removeProperty: function (cookieKey, propertyToRemove) {
		var cookieValue = $.cookie(cookieKey);
		var cookieJson = {};
		try {
			if (cookieValue) { cookieJson = JSON.parse(cookieValue); }
			delete cookieJson[propertyToRemove];
			$.cookie(cookieKey, JSON.stringify(cookieJson));
		}
		catch (e) { rm.cookie.clearValue(cookieKey); }
	},
};
rm.queryString = {
	getValue: function (parmName) {
		//new URLSearchParams(window.location.search).get(parmName); works with latest browsers
		var pageUrl = window.location.search.substring(1);
		var keyValuePairList = pageUrl.split('&');

		for (var i = 0; i < keyValuePairList.length; i++) {
			var keyValuePair = keyValuePairList[i];
			if (keyValuePair.toLowerCase().indexOf((parmName || "").toLowerCase()) == 0) {
				return keyValuePair.split("=")[1];
			}
		}
		return null;
	}
};
rm.grid = {
	filterOptions: {
		activeInactive: ":All;1:Active;0:Inactive",
		completeIncomplete: ":All;1:Complete;0:Incomplete;2:Pharmacy Calculator Not Added",
		yesNo: ":All;1:Yes;0:No",
		yesNoString: ":All;Yes:Yes;No:No",
		blinded: ":All;Blinded:Blinded;Unblinded:Unblinded;Open Label:Open Label",
		dteType: ":All;1:Yes;2:No;3:Unknown",
		assignmentType: "All:All;AVT:AVT;HardBooked:Hard Booked;RejectedSoftBooking:Rejected Soft Bookings;SoftBooked:Soft Booked;SpecialAssignment:Special Assignment;Terminated:Terminated",
		iconSearch: "HardBooked:Hard Booked;OverDue:Overdue;PermanentBackfill:Permanent Backfills;ProposalRequest:Proposal Request;Returned:Return Request;PPMDteIncompatible:PPM RBM Incompatible",
		iconSearch_SubmittedPage: "FTEError:Error - FTE Allocation;PPMDteIncompatible:Error - PPM/RM RBM Mismatch;HardBooked:Hard Booked;OverDue:Overdue;Backfill:Backfill;ProposalRequest:Proposal Requests;Returned:Queried Requests;AnsweredQuery:Queries Answered;SoftBooked:Soft Booked;Submitted:Unassigned;PPMInactiveCountry:PPM Inactive Country",
		iconSearch_Softbook: "OverDue:Overdue;PermanentBackfill:Permanent Backfills;ProposalRequest:Proposal Request;RejectedSoftBooking:Rejected Soft Bookings;Returned:Return Request;PPMDteIncompatible:PPM RBM Incompatible",
		iconSearch_ClientSide: "iconOverdue:Overdue;iconBackfill:Permanent Backfills;iconProposal:Proposal Request;iconReturned:Return Request;iconRmPpmDteMismatch:PPM RBM Incompatible",
		iconSearch_OpenRequestsOverdue: "OverDue:Overdue;All:All;PPMDteIncompatible:PPM RBM Incompatible",
		iconSearch_OpenRequestsAll: "All:All;OverDue:Overdue;PPMDteIncompatible:PPM RBM Incompatible",
		iconSearch_MonitoringRequests: ":All;PPMDteIncompatible:PPM RBM Incompatible",
		activeMonFrequency: ":All;FSI-LSI:FSI-LSI;LSI-LSO:LSI-LSO;LSO-COV:LSO-COV;Post-COV:Post-COV;Pre-FSI:Pre-FSI;UNKNOWN:UNKNOWN",
		getCompetencyBand: function () {
			var filterString = ":All";
			if (CompetencyBand) {
				for (var prop in CompetencyBand) {
					if (CompetencyBand.hasOwnProperty(prop)) {
						filterString += ";" + prop + ":" + CompetencyBand[prop];
					}
				}
			}
			return filterString;
		},
		getFiltersFromDictionary: function (dictionary) {
			var fOpt = ":All";
			var temp = [];
			if (dictionary) {
				$.each(dictionary, function (key, value) {
					temp.push({ v: value, k: key });
				});
			}
			temp.sort(function (a, b) {
				if (a.v > b.v) { return 1 }
				if (a.v < b.v) { return -1 }
				return 0;
			});
			$.each(temp, function (key, obj) {
				fOpt += ";" + obj.k + ":" + obj.v;
			});
			return fOpt;
		},
		getFiltersFromArray: function (array) {
			var dictionary = {};
			if (array) {
				for (var index = 0; index < array.length; index++) {
					if (array[index].Key != "" && array[index].Value != "") {
						dictionary[array[index].Key] = array[index].Value;
					}
				}
			}
			return this.getFiltersFromDictionary(dictionary);
		}
	},
	helperFunctiuons: {
		bindConnectToQip: function (gridId, rowId, columnName, connectToQipSaveFunction) {
			setTimeout(function () {
				var gridSelector = "#" + gridId;
				var rowData = rm.grid.rowData.getById(gridSelector, rowId);
				$("tr#" + rowId).find("img.disconnected[columnName=" + columnName + "]").click(function () {
					var connectedValue = (rowData[columnName].ConnectedValue || "");
					if (connectedValue != "") {
						var disconnectedImage = $(this);
						connectToQipSaveFunction(rowId, columnName, connectedValue, function () {
							disconnectedImage.remove();
							rowData[columnName].Value = connectedValue;
							rowData[columnName].IsConnected = true;
							$(gridSelector).setCell(rowId, columnName, connectedValue, "", "", true);
						});
					}
					else {
						alert("Reconnection is not possible as there are no values entered into budget.");
					}
				});
			}, 10);
		}
	},
	standardFormatters: {
		getGridRowDataHelper: function (columnName, gridId, rowId, rowObject) {
			var gridRowData = rm.grid.rowData.getById("#" + gridId, rowId);
			//gridRowData is not available when grid is loading for the first time and rowObject is not avaialble when canceling out of edit mode
			return (gridRowData == null ? rowObject : gridRowData);
		},
		getQipConnectedIcon: function (columnName) { return "<img columnName='" + columnName + "' src='/_layouts/SPUI/images/ConnectedBudget.png' title='Connected to Budget' class='connected' style='padding:0px 3px;vertical-align: bottom'>"; },
		getQipDisconnectedIcon: function (columnName, allowConnect) {
			var title = allowConnect ? " title='Reconnect to Budget' " : "";
			var cursorStyle = allowConnect ? "cursor: pointer;" : "";
			return "<img columnName='" + columnName + "' src='/_layouts/SPUI/images/DisconnectedBudget.png' class='disconnected' style='padding:0px 3px;vertical-align: bottom;" + cursorStyle + "'" + title + ">";
		},
		getQipConnectDisconnectIcon: function (columnName, gridId, rowId, rowObject, allowConnect) {
			var rowData = rm.grid.standardFormatters.getGridRowDataHelper(columnName, gridId, rowId, rowObject, allowConnect);
			return (rowData[columnName].IsConnected == true ? rm.grid.standardFormatters.getQipConnectedIcon(columnName) : rm.grid.standardFormatters.getQipDisconnectedIcon(columnName, allowConnect));
		},
		showDataWithQipConnectDisconnectIcon: function (cellvalue, options, rowObject, connectToQipSaveFunction, allowConnect) {
			var rowData = rm.grid.standardFormatters.getGridRowDataHelper(options.colModel.name, options.gid, options.rowId, rowObject);
			if (allowConnect) { rm.grid.helperFunctiuons.bindConnectToQip(options.gid, options.rowId, options.colModel.name, connectToQipSaveFunction); }
			return rowData[options.colModel.name].Value + rm.grid.standardFormatters.getQipConnectDisconnectIcon(options.colModel.name, options.gid, options.rowId, rowObject, allowConnect);
		}
	},
	standardColumns: {
		getMessageColumnWithJsonData: function (hidden) {
			return {
				name: 'Message', index: 'Message', label: ' ', width: 20, hidden: (hidden == null) ? true : hidden, search: false, sortable: false,//name: 'Message', index: 'Message', label: ' ', width: 20, hidden: (hidden == null) ? true : hidden, search: false, sortable: false,
				formatter: rm.grid.drawIndicatorWithJsonData, formatoptions: {}
			};
		},
		getMessageColumn: function () {
			return {
				name: 'Message', index: 'Message', label: ' ', width: 15, hidden: false, search: false, sortable: false, frozen: true,
				formatter: rm.grid.drawIndicator, formatoptions: {}
			};
		},
		getNotesColumn: function () {
			return { name: 'Notes', index: 'Notes', label: 'Notes', sortable: false, align: 'center', width: 50, search: false };
		},
		getFteColumn: function (rememberGridFilters) {
			return {
				name: 'FTE', index: 'FTE', label: 'FTE', sortable: false, align: 'center', width: 60, search: false, cellsformat: 'F3',
				formatter: function (cellvalue, options, rowObject) { return ShowFteCalcImage(cellvalue, options, rowObject, rememberGridFilters); }, formatoptions: {}
			};
		},
		getFteMonthColumn: function (columnName, monthval) {
			var columnHeader = rm.date.monthNumbers[monthval % 12] + ' FTE';
			return { name: columnName, index: columnName, label: columnHeader, width: 70, sortable: false, search: false };
		},
		getMilestoneDateColumn: function (rememberGridFilters) {
			return {
				name: 'FTE', index: 'FTE', label: 'FTE', sortable: false, align: 'center', width: 40, search: false,
				formatter: function (cellvalue, options, rowObject) { return ShowFteCalcImage(cellvalue, options, rowObject, rememberGridFilters); }, formatoptions: {}
			};
		},
		getEditableDateNoConnectColumn: function (columnName, columnIndex, columnLabel, gridSelector) {
			return {
				name: columnName, index: columnIndex, label: columnLabel, editable: true, width: 140, align: 'right',
				editoptions: {
					class: "editable",
					size: 15, maxlength: 15,
					onEdit: function () { rm.grid.scrollTableBodyToFixAlignmentIssue(gridSelector); },
					dataInit: function (element) {
						//Use setTimeout per instructions from jqGrid online docs
						setTimeout(function () { $(element).qDatepicker(); }, 50);
					}
				}
			};
		},
		getEditableMilestoneNameColumn: function (columnName, columnIndex, columnLabel) {
			return {
				name: columnName, index: columnIndex, label: columnLabel, sortable: true, editable: true, width: 250, align: 'left',
				editoptions: {
					class: "editable",
					size: 40, maxlength: 40,
					onEdit: function () { rm.grid.scrollTableBodyToFixAlignmentIssue(gridSelector); },
					dataInit: function (element) { }
				}
			};
		},
		getEditableMilestoneDateColumn: function (columnName, columnIndex, columnLabel) {
			return {
				name: columnName, index: columnIndex, label: columnLabel, sortable: true, editable: true, width: 146, align: 'right',
				editoptions: {
					size: 15, maxlength: 15,
					onEdit: function () { rm.grid.scrollTableBodyToFixAlignmentIssue(gridSelector); },
					dataInit: function (element) {
						//Use setTimeout per instructions from jqGrid online docs
						setTimeout(function () { $(element).qDatepicker(); }, 50);
					}
				},
			};
		},
		getEditableQipConnectableIntColumn: function (columnName, columnIndex, columnLabel, columnWidth, gridSelector, allowSearch, allowSort, minValue, maxValue, userAllowedValueFormat, connectToQipSaveFunction, allowConnect) {
			return {
				name: columnName, index: columnIndex, label: columnLabel, editable: true, width: columnWidth, align: 'right', search: allowSearch, sort: allowSort,
				editoptions: {
					class: "inlineQipInt editable validateRange",
					maxlength: 5,
					onEdit: function () { rm.grid.scrollTableBodyToFixAlignmentIssue(gridSelector); },
					dataInit: function (element) {
						setTimeout(function () {
							var gridId = gridSelector.replace("#", "");
							var rowId = $(element).parent().closest("tr").attr("id");
							var rowData = rm.grid.standardFormatters.getGridRowDataHelper(columnName, gridId, rowId, null);

							$(element).parent().append(rm.grid.standardFormatters.getQipConnectDisconnectIcon(columnName, gridId, rowId, null, allowConnect));
							//function to handle connect to QIP click in edit mode
							var bindConnectToQip = function () {
								if (allowConnect) {
									setTimeout(function () {
										$(element).parent().find("img.disconnected").click(function () {
											var connectedValue = (rowData[columnName].ConnectedValue || "");
											if (connectedValue != "") {
												$(this).remove();
												$(element).val(connectedValue);
												$(element).parent().append(rm.grid.standardFormatters.getQipConnectedIcon(columnName));
											}
											else {
												alert("Reconnection is not possible as there are no values entered into budget.");
											}
										});
									}, 10);
								}
							};

							$(element).attr("from", minValue).attr("to", maxValue).attr("formating", userAllowedValueFormat).attr("connectedValue", (rowData[columnName].ConnectedValue || "")).on('keyup keypress paste keydown', function (e) {
								if (rm.utilities.isNonControlCharacter(e.which)) {
									var connectedImage = $(element).parent().find("img.connected");
									if (connectedImage.length > 0) {
										connectedImage.remove();
										$(element).parent().append(rm.grid.standardFormatters.getQipDisconnectedIcon(columnName, allowConnect));
										bindConnectToQip();
									}
								}
							});

							bindConnectToQip();
						}, 50);
					}
				},
				formatter: function (cellvalue, options, rowObject) { return rm.grid.standardFormatters.showDataWithQipConnectDisconnectIcon(cellvalue, options, rowObject, connectToQipSaveFunction, allowConnect); },
				unformat: this.getUnformattedCellValueForEdit
			};
		},
		getEditableDateColumn: function (columnName, columnIndex, columnLabel, updateStopDateOnStartDateChange, stopDateColumnName, gridSelector) {
			return {
				name: columnName, index: columnIndex, label: columnLabel, editable: true, width: 130, align: 'right',
				editoptions: {
					class: "inlineDate editable",
					maxlength: 15,
					onEdit: function () { rm.grid.scrollTableBodyToFixAlignmentIssue(gridSelector); },
					dataInit: function (element) {
						//Use setTimeout per instructions from jqGrid online docs
						setTimeout(function () {
							$(element).qDatepicker();
							if (updateStopDateOnStartDateChange) {
								$(element).bind("change", function () {
									var rowId = $(element).attr("id").replace("_" + columnName, "");
									var stopDateJqElement = $("#" + rowId + "_" + stopDateColumnName);
									var rowJson = rm.grid.rowData.getById(gridSelector, rowId);

									qrpmRmHelper.setRequestStopDateFromComputedRequestMilestone(rowJson.ResourceTypeId, rowJson.RegionId, $(element).val(), stopDateJqElement);
								});
							}
						}, 50);
						$.qGrid.updateCalendarIcon(element);
					}
				},
				formatter: $.qGrid.showDateWithConnectIcon, unformat: this.getUnformattedCellValueForEdit,
				searchoptions: { attr: { maxlength: 11 } }
			};
		},
		//getEditableDateColumnDefinitionWithNoSearch: function (columnName, columnIndex, columnLabel) {
		//	return {
		//		name: columnName, index: columnIndex, label: columnLabel, editable: true, width: 140, align: 'right', search: false,
		//		editoptions: {
		//			size: 15, maxlength: 15,
		//			onEdit: function () { rm.grid.scrollTableBodyToFixAlignmentIssue(gridSelector); },
		//			dataInit: function (element) {
		//				$(element).on('keyup keypress paste keydown', function (e) {
		//					if (e.which == 27 || e.which == 13) {
		//						return false;
		//					}
		//				});
		//				//Use setTimeout per instructions from jqGrid online docs
		//				setTimeout(function () { $(element).qDatepicker(); }, 50);
		//				$.qGrid.updateCalendarIcon(element);
		//			}
		//		},
		//		formatter: $.qGrid.showDateWithConnectIcon, unformat: this.getUnformattedCellValueForEdit
		//	};
		//},
		getRequestInfoIconColumn: function () {
			return {
				name: 'Message', index: 'Message', label: ' ', width: 15, hidden: true, search: false, sortable: false,
				formatter: rm.grid.drawIndicator, formatoptions: {}
			};
		},
		//Unformat cell value, i.e remove img tag from cell value and just return the string
		getUnformattedCellValueForEdit: function (cellvalue, options, cell) {
			var endIndex = cellvalue.indexOf("<img");
			return $.trim((endIndex == -1) ? cellvalue : cellvalue.substr(0, endIndex));
		},
	},
	rowData: {
		attachAllRowsData: function (gridSelector, data) { $(gridSelector).setGridParam({ userData: data }); },
		addData: function (gridSelector, newRow) { this.getAllRowsData(gridSelector).Records.push(newRow); },
		getAllRowsData: function (gridSelector) { return $(gridSelector).getGridParam('userData'); },
		getById: function (gridSelector, rowId) {
			var rowDataList = this.getAllRowsData(gridSelector).Records;
			var rowData;

			if (rowDataList) {
				$.each(rowDataList, function (index, element) {
					if (element.id == rowId) {
						rowData = element;
						return false;
					}
				});
			}
			return rowData;
		},
		updateData: function (gridSelector, newRow) {
			var gridData = this.getAllRowsData(gridSelector);
			$.each(gridData.Records, function (index, element) {
				if (element.id == newRow.id) {
					gridData.Records[index] = newRow;
					return false;
				}
			});
		},
		getJsonData: function (options, rowObject) {
			var rowData = this.getById("#" + options.gid, options.rowId);
			return (rowData == undefined || rowData == null) ? rowObject : rowData;
		},
	},
	reloadGrid: function (gridSelector) { $(gridSelector).trigger('reloadGrid'); },
	clearGridFilters: function (gridSelector) { rm.grid.getFilterControls(gridSelector).val(""); },
	getFilterControls: function (gridSelector) { return $("#gbox_" + gridSelector.replace("#", "")).find("[id^=gs_]"); },
	getFilterDropdownControls: function (gridSelector) { return $("#gbox_" + gridSelector.replace("#", "")).find("select[id^=gs_]"); },
	delayedTriggerGridSearch: function (gridSelector) { setTimeout(function () { $(gridSelector)[0].triggerToolbar(); }, 10); },
	editRow: function (gridSelector, rowId) {
		$(gridSelector).jqGrid('editRow', rowId);
		$("tr#" + rowId + " div.ui-inline-save, " + "tr#" + rowId + " div.ui-inline-cancel").show();
	},
	getHtmlRow: function (gridSelector, rowId) { return $(gridSelector + " tr[id=" + rowId + "]"); },
	getHtmlCell: function (gridSelector, rowId, columnName) { return rm.grid.getHtmlRow(gridSelector, rowId).find("td[aria-describedby$=" + columnName + "]"); },
	getControlFromEditRow: function (gridSelector, rowId, controlName) { return rm.grid.getHtmlRow(gridSelector, rowId).find("[name=" + controlName + "]"); },
	getUpdatedRowDataById: function (gridSelector, rowId) {
		var rowData = { Id: rowId };
		$.each($(gridSelector + " tr[id=" + rowId + "]").find("input.editable"), function (innerIndex, control) {
			rowData[$(control).attr("name")] = $(control).val();
			if ($(control).hasClass("inlineQipInt")) {
				rowData["Is" + $(control).attr("name") + "Connected"] = ($(control).parent().find("img.connected").length > 0);
			}
		});
		return rowData;
	},
	getRowsInEditMode: function (gridSelector) { return $(gridSelector).getGridParam("savedRow"); },
	getUpdatedRowDataArray: function (gridSelector) {
		var postData = [];
		var rowsInEditMode = this.getRowsInEditMode(gridSelector);
		if (rowsInEditMode && rowsInEditMode.length > 0) {
			$.each(rowsInEditMode, function (index, gridRow) {
				postData.push(rm.grid.getUpdatedRowDataById(gridSelector, gridRow.id));
			});
		}
		return postData;
	},
	attachCustomSaveHandler: function (gridSelector, rowId, saveHandler) {
		var rowSelector = " tr[id=" + rowId + "]";
		var normalRowSelector = gridSelector + rowSelector;
		var frozenRowSelector = gridSelector + "_frozen" + rowSelector;
		$(normalRowSelector + "," + frozenRowSelector).find(".ui-inline-save").removeAttr("onclick").unbind("click").click(function () {
			if ($.isFunction(saveHandler)) { saveHandler(gridSelector, rowId); }
		});
	},
	setHeaderRowHeightDoubleLine: function (gridId) { $("#gbox_" + gridId).find("table tr.ui-jqgrid-labels th div").addClass("gridHeaderDoubleLine"); },
	setHeaderRowHeightTripleLine: function (gridId) { $("#gbox_" + gridId).find("table tr.ui-jqgrid-labels th div").addClass("gridHeaderTripleLine"); },
	setHeaderRowHeightFourLine: function (gridId) { $("#gbox_" + gridId).find("table tr.ui-jqgrid-labels th div").addClass("gridHeaderFourLine"); },
	setHeaderRowHeightFiveLine: function (gridId) { $("#gbox_" + gridId).find("table tr.ui-jqgrid-labels th div").addClass("gridHeaderFiveLine"); },
	hideSearchRow: function (gridId) { $("#gview_" + gridId + " .ui-search-toolbar").hide(); },
	bindEventsToResizeGrid: function () {
		if (arguments && arguments.length > 0) {
			var selectorList = arguments;

			$(window).resize(function () {
				for (var i = 0; i < selectorList.length; i++) {
					rm.grid.resizeGrid(selectorList[i], $(window).width() - (rm.runtimeValues.gridOffsetWidth || 63));
				}
			});
		}
	},
	resizeGrid: function (gridSelector, width) {
		$(gridSelector).setGridWidth(width);
	},
	//additionalData is json object {key1: value1, key2:value2}
	serializeGridData: function (postData, additionalData) {
		var data = { gridSearch: {} };

		for (var key in postData) {
			if (postData.hasOwnProperty(key)) {
				data.gridSearch[key] = postData[key];
			}
		}

		if (additionalData) {
			for (var key in additionalData) {
				if (additionalData.hasOwnProperty(key)) {
					data.gridSearch[key] = additionalData[key];
				}
			}
		}

		return JSON.stringify(data);
	},
	hasRowsInEditMode: function (gridSelector) {
		var rowsInEditMode = this.getRowsInEditMode(gridSelector);
		return rowsInEditMode && rowsInEditMode.length > 0;
	},
	cancelGridEditMode: function (gridSelector, askForContirmation) {
		var rowsInEditMode = this.getRowsInEditMode(gridSelector);
		if (rowsInEditMode && rowsInEditMode.length > 0) {
			if (!askForContirmation || (askForContirmation && confirm(Resources.UnsavedChangesOnThePage))) {
				for (var i = rowsInEditMode.length; i > 0; i--) {
					rm.grid.cancelRowEditMode(gridSelector, rowsInEditMode[0].id);
				}
			}
		}
	},
	cancelGridEditModeWithoutConfirm: function (gridSelector) { this.cancelGridEditMode(gridSelector, false); },
	cancelRowEditMode: function (gridSelector, rowId) {
		$(gridSelector).jqGrid("restoreRow", rowId);
		$(gridSelector + " tr[id=" + rowId + "]").find("div.ui-inline-save,div.ui-inline-cancel").hide();
	},
	getJqGridJsonReader: function () {
		return {
			repeatitems: false,
			root: "Records",
			page: "CurrentPageNumber",
			total: "TotalPages",
			records: "RecordCount"
		};
	},
	getJqGridAjaxOptions: function (isAsmx, WebServiceMethodName, unblockUi, async) {
		return {
			contentType: 'application/json; charset=utf-8',
			async: (async != undefined) ? async : true,
			error: function (data, textStatus) {
				if (unblockUi) { rm.ui.unblock(); }
				var dialogTitle = "Web Service Error" + (WebServiceMethodName ? ": " + WebServiceMethodName : "");
				var message = "";

				if (isAsmx && (!data.responseText || (data.responseText.substring(0, 14) != "<?xml version="))) {
					var err = $.parseJSON(data.responseText);
					message = "\n\nException Type = " + err.ExceptionType +
						"\n\nMessage = " + err.Message +
						"\n\nStack Trace = " + err.StackTrace;
				}
				else { message = data.responseText; }

				rm.ui.dialog.showModal("#divDialog", dialogTitle, message, true, 500, 300);
			}
		};
	},
	//SD: Use this function to remove selected row from a grid. Function first unselects the row to make sure check all checkbox reflects correct state.
	removeAllCheckedRows: function (gridSelector) {
		//Do not use $.each or foreach. The arry of selected rowIds is reference of grids internal array which
		//changes as soon as the row is removed from the grid. (i.e. array length gets decremented by one everytime the row gets deleted)
		var rowIds = $(gridSelector).getGridParam('selarrrow');
		while (rowIds.length > 0) {
			rm.grid.removeRow(gridSelector, rowIds[0]);
		}
	},
	checkRowById: function (gridSelector, rowId) {
		jQuery(gridSelector).jqGrid('setSelection', rowId);
	},
	removeRow: function (gridSelector, rowId) {
		jQuery(gridSelector).jqGrid('setSelection', rowId);
		$(gridSelector).jqGrid('delRowData', rowId);
	},
	hasRowsSelected: function (gridSelector) {
		var selectedRows = $(gridSelector).getGridParam('selarrrow');
		return selectedRows && selectedRows.length > 0;
	},
	hasSingleRowSelected: function (gridSelector) {
		var selectedRows = $(gridSelector).getGridParam('selarrrow');
		return selectedRows && selectedRows.length == 1;
	},
	uncheckAllGridRows: function (gridSelector) {
		var rowIds = new Array();
		$.each($(gridSelector).getGridParam('selarrrow'), function () { rowIds.push(this) });

		$.each(rowIds, function (index, rowId) {
			jQuery(gridSelector).jqGrid('setSelection', rowId);
		});
		rm.ui.ribbon.refresh();
	},
	unHighlightAllRows: function (gridSelector) {
		$.each($(gridSelector + " tr"), function () {
			if (!($(this).find(".cbox").is(":checked"))) {
				$(this).removeClass("ui-state-highlight");
			}
		});
	},
	getSelectedIdArray: function (gridSelector) { return $(gridSelector).getGridParam('selarrrow'); },
	getSelectedIds: function (gridSelector) {
		var ids = "";
		$.each($(gridSelector).getGridParam('selarrrow'), function (index, ele) { ids += "," + ele; });
		return ids.replace(",", "");
	},
	isRowSelected: function (gridSelector, rowId) {
		var isRowSelected = false;
		$.each($(gridSelector).getGridParam('selarrrow'), function (index, ele) {
			if (rowId == ele) {
				isRowSelected = true;
				return false;
			}
		});
		return isRowSelected;
	},
	showErrorIconInMessageColumn: function (gridSelector, rowId, iconColumnName, message) {
		$(gridSelector).setCell(rowId, iconColumnName, message.replace(/\'/g, "&#39;"));
		$(gridSelector).showCol(iconColumnName);
		var img = rm.grid.drawIndicator(message, { rowId: rowId + "_frz" }, null);
		$(gridSelector + "_frozen").find("tr#" + rowId).find("td[aria-describedby=" + gridSelector.replace("#", "") + "_Message]").html(img);
	},
	getHighlightedRowId: function (gridSelector) {
		gridSelector = gridSelector ? gridSelector : "";
		return $(gridSelector + " tr[class~=ui-state-highlight]").attr("id");
	},
	drawIndicator: function (cellvalue, options, rowObject) {
		var imgId = "img" + options.rowId;
		if ($.trim(cellvalue) === "") {
			rm.qtip.clear("#" + imgId);
			return ' ';
		} else {
			var imgsrc = "";
			var message = 'Backfill request has been successfully created.';

			if (cellvalue == "success" || cellvalue == message) {
				imgsrc = "<img id='" + imgId + "' src='/_layouts/SPUI/images/GreenCheck.png' " +
					"alt='Success' style='cursor: pointer;' title='" + message + "'/>";
				setTimeout(function () {
					rm.qtip.showInfo("#" + imgId, message);
				}, 100);
			}
			else {
				imgsrc = "<img id='" + imgId + "' src='/_layouts/SPUI/images/errorIcon.png' " +
					"alt='Error' style='cursor: pointer;' />";
				setTimeout(function () {
					var showCloseButton = (cellvalue != null && cellvalue.indexOf("<") != -1);
					if (showCloseButton) {
						cellvalue += "<input type='button' value='Ok' onclick='$(&#39;#" + imgId + "&#39;).qtip(&#39;hide&#39;);' style='float: right;'>";
					}
					setTimeout(function () { rm.qtip.showError("#" + imgId, cellvalue, null, null, null, { event: "click unfocus" }); }, 100);
				}, 100);
			}
			return imgsrc;
		}
	},
	drawIndicatorWithJsonData: function (cellvalue, options, rowObject) {
		var imgId = "img" + options.rowId;
		var imgSelector = "#" + imgId;

		if ($.trim(cellvalue) === "") {
			rm.qtip.clear(imgSelector);
			return '&nbsp;';
		}
		else {
			var cellJson = $.parseJSON(cellvalue);
			var imgsrc = "&nbsp;";

			if (cellJson.MessageType == MessageType_E.Success) {
				imgsrc = "<img id='" + imgId + "' src='/_layouts/SPUI/images/GreenCheck.png' " +
					"alt='Success' style='cursor: pointer;' title='" + cellJson.Message + "'/>";
				setTimeout(function () { rm.qtip.showInfo(imgSelector, cellJson.Message); }, 100);
			}
			else if (cellJson.MessageType == MessageType_E.Error) {
				imgsrc = "<img id='" + imgId + "' src='/_layouts/SPUI/images/errorIcon.png' " +
					"alt='Error' style='cursor: pointer;' " +
					"title='" + cellJson.Message + "' />";
				setTimeout(function () { rm.qtip.showError(imgSelector, cellJson.Message); }, 100);
			}
			return imgsrc;
		}
	},
	clearGridError: function (gridSelector, columnName) {
		var mygrid = $(gridSelector);
		var ids = mygrid.getDataIDs();  //all the rowids
		for (var i = 0; i < ids.length; i++) {
			//$(mygrid).setCell(ids[i], columnName, "", "", "", true);
			rm.grid.clearSingleGridRowError(gridSelector, columnName, ids[i]);
		}
	},
	clearSingleGridRowError: function (gridSelector, columnName, rowId) {
		$(gridSelector).setCell(rowId, columnName, "", "", "", true);
		$(gridSelector + "_frozen").find("tr#" + rowId).find("td[aria-describedby=" + gridSelector.replace("#", "") + "_Message]").html("");
	},
	hideMessageColumn: function (gridSelector, columnName) {
		$(gridSelector).hideCol(columnName);
		rm.grid.clearGridError(gridSelector, columnName);
	},
	//TODO: AI: SD- if two resources have same name and if both are selected then this method will give wrong result. (need to fixed)
	multilpeResourcesSelected: function (gridSelector, resourceColumn) {
		var multipleResourcesSelected = false;
		var resourceName = "";
		$.each($(gridSelector).getGridParam('selarrrow'), function (index, rowId) {
			if (resourceName == "") {
				resourceName = rm.grid.rowData.getById(gridSelector, rowId).Resource;
			}
			if (resourceName != rm.grid.rowData.getById(gridSelector, rowId).Resource) {
				multipleResourcesSelected = true;
				return false;
			}
		});
		return multipleResourcesSelected;
	},
	rememberGridFilterCriteria: function (gridSelector, cookieName, additionalData) {
		var gridState = {
			searchCriteria: $(gridSelector).getGridParam("postData")
		};
		if (additionalData) {
			$.extend(gridState, additionalData);
		}
		$.cookie(cookieName, JSON.stringify(gridState));
	},
	getFilterCriateriaFromCookie: function (cookieName, arrAdditionalPropertiesToMap, defaultSearchCriteria) {
		var cookieData;
		var gridPost;
		if ($.cookie(cookieName) != null) {
			cookieData = $.parseJSON($.cookie(cookieName));
			gridPost = cookieData.searchCriteria;

			if (arrAdditionalPropertiesToMap) {
				for (property in arrAdditionalPropertiesToMap) {
					gridPost[property] = cookieData[property];
				}
			}

			$.cookie(cookieName, null);
		}
		else if (defaultSearchCriteria) {
			gridPost = defaultSearchCriteria;
		}

		return gridPost;
	},
	allowRowSelection: function (event) { return event && $(event.target).attr("type") == "checkbox"; },
	scrollTableBodyToFixAlignmentIssue: function (gridSelector) {
		setTimeout(function () {
			var parentDiv = $(gridSelector).closest("div.ui-jqgrid-bdiv");
			//Issue occurs only when the grid body is scrolled down. If user has scrolled all the way down to the bottom, adding 1 to scroll top doesn't help. Hence subrtacting 1.
			var scrollTop = parentDiv.scrollTop() - 1;
			parentDiv.scrollTop(scrollTop);
			parentDiv.scrollTop(scrollTop + 1);
		}, 50);
	},
	applyFilterCriateriaToGrid: function (filterCriateriaJson) {
		if (filterCriateriaJson) {
			//Set values in filter textboxes
			setTimeout(function () {
				for (property in filterCriateriaJson) {
					$("#gs_" + property).val(filterCriateriaJson[property]);
				}
			}, 200);
		}
	},
	addTitlesOnIconColumn: function () {
		$(".iconRmPpmDteMismatch").attr("title", Resources.RmPpmDteMismatchError);
		$(".iconRmPpmDteMismatchOrq").attr("title", Resources.RmPpmDteMismatchRequestGroupError);
		$(".iconPpmInactiveCountry").attr("title", "This Site-level Request is for a Project-Country marked as 'Inactive' in PPM's Project Schedule QRPM: RM does not project any Visits for such site-level Requests in Inactive Project-Countries If this Project-Country has been incorrectly marked as 'Inactive', then please consult with the QRPM: PPM Project Management Analyst (PMA). If this Project-Country is truly Inactive, please Terminate/Delete this Request");
		setTimeout(function () { $.each($(".iconRmPpmDteMismatch,.iconRmPpmDteMismatchOrq,.iconPpmInactiveCountry"), function (index, element) { rm.qtip.showError(element, $(element).attr("title")); }); }, 10);

		$(".iconBackfill").attr("title", "Permanent Backfill");
		$(".iconOverdue").attr("title", "Over Due");
		$(".iconReturned").attr("title", "Return Request");
		$(".iconProposal").attr("title", "Proposal Request");
		$(".iconSoftbooked").attr("title", "Soft Booked");
		$(".iconHardBooked").attr("title", "Hard Booked");
		$(".iconTerminated").attr("title", "Terminated");
		$(".iconRejectedSoftBook").attr("title", "Rejected Soft Booking");
	},
	getGridToolDefaultConfig: function () {
		return {
			toolsParentContainerSelector: null,//if provided, tools will be rendered in this container. otherwise it will be added just before the grid
			showClearFilter: true,
			showExport: true,
			showManageColumns: true,
			showManageFilters: false,
			exportParameters: {},
			manageColumnsParameters: {
				SelectedColumnList: [],
				AvailableColumnList: [],
				DataGridId: null,
				UiColumnConfiguration: []
			},
			manageFilterConfig: {
				selectedFilterId: null,
				dataGridId: null,
				userFilters: [],
				onFilterChange: function () { }
			}
		};
	},
	bindclearGridToolFilterDropdownGridSearch: function (gridSelector) {
		rm.grid.getFilterControls(gridSelector).keydown(function (event) {
			if (rm.utilities.isNonControlCharacter(event.keyCode)) {
				rm.grid.clearGridToolFilterDropdown(gridSelector);
			}
		});
		rm.grid.getFilterDropdownControls(gridSelector).change(function (event) {
			rm.grid.clearGridToolFilterDropdown(gridSelector);
		});
	},
	getGridToolFilterDropdownValueFromControlOrCookie: function (gridSelector, filterCookieKey) {
		if (rm.grid.isGridToolFilterDropdownRendered(gridSelector)) {
			return rm.grid.getGridToolFilterDropdownValue(gridSelector) || "";
		}
		else {
			var gridAutoSavedFilter = $.cookie(filterCookieKey);
			if (gridAutoSavedFilter) {
				var filterJson = JSON.parse(gridAutoSavedFilter);
				return filterJson.selectedRowFilterId || "";
			}
		}
	},
	isGridToolFilterDropdownRendered: function (gridSelector) {
		return $("div.gridToolStrip[gridselector=" + gridSelector + "]").find("select.manageFilters").length != 0;
	},
	getGridToolFilterDropdownValue: function (gridSelector) {
		return $("div.gridToolStrip[gridselector=" + gridSelector + "]").find("select.manageFilters").val();
	},
	setGridToolFilterDropdownValue: function (gridSelector, value) {
		$("div.gridToolStrip[gridselector=" + gridSelector + "]").find("select.manageFilters").val(value);
	},
	clearGridToolFilterDropdown: function (gridSelector) {
		$("div.gridToolStrip[gridselector=" + gridSelector + "]").find("select.manageFilters").val("");
	},
	//gridSelector: JquerySelector for grid
	//exportParameters: {key1:value1, key2:value2 } json key/value pair
	showGridTools: function (gridSelector, config) {
		var toolConfig = $.extend({}, rm.grid.getGridToolDefaultConfig(), config);
		var gridId =
			$(".gridToolStrip[gridSelector=" + gridSelector + "]").remove();
		var toolStripContainer = $("<div>", { class: "gridToolStrip", gridSelector: gridSelector });
		if (toolConfig.showClearFilter !== false) {
			toolStripContainer.append($("<div>", {
				class: "clearFilter",
				text: "Clear Filter",
				click: function () {
					$($(this).parent().data("gridSelector")).trigger("clearToolbar").trigger('reloadGrid');
					rm.grid.clearGridToolFilterDropdown(gridSelector);
				}
			}));
		}

		if (toolConfig.showExport) {
			toolStripContainer.append($("<div>", {
				class: "exportToExcel",
				text: "Export to Excel",
				click: function () {
					var jqGridSelector = $(this).parent().data("gridSelector");
					var gridRecordCount = $(jqGridSelector).getGridParam('records');
					if (gridRecordCount == 0) { alert("There are no records to export."); }
					else if (gridRecordCount <= 15000) {
						var postData = {};
						$.extend(postData, $(jqGridSelector).jqGrid('getGridParam', 'postData'), { rows: 0 });
						rm.grid.postForExportData($(this).parent().data("exportParameters"), postData);
					}
					else { alert("Please filter the grid before exporting data. Export limt is 15000 records."); }
				}
			}));
		}

		if (toolConfig.showManageColumns) {
			toolStripContainer.append($("<div>", {
				class: "manageColumns",
				text: "Manage Columns",
				click: function () {
					var columnConfiguration = $(this).parent().data("manageColumnsParameters");
					colSelNs.showControl(columnConfiguration);
				}
			}));
		}

		if (config.showManageFilters) {
			var select = $("<select>", { class: "manageFilters" })
				.append($("<option>", { value: "save", text: "Save Current Filter As..." }))
				.append($("<option>", { value: "manage", text: "Manage Filters..." }))
				.append($("<option>", { value: "", disabled: "disabled", text: "---Filter Options---" }));
			var hasUserSelectedFilter = false;
			if (Array.isArray(toolConfig.manageFilterConfig.userFilters)) {
				toolConfig.manageFilterConfig.userFilters.forEach(function (userFilter) {
					var option = $("<option>", { value: userFilter.Key, text: userFilter.Value });
					if (userFilter.Key == toolConfig.manageFilterConfig.selectedFilterId) {
						option.attr("selected", "selected");
						hasUserSelectedFilter = true;
					}
					select.append(option);
				});
			}
			if (!hasUserSelectedFilter) { select.val(""); }
			select.on("change", toolConfig.manageFilterConfig.onFilterChange);
			toolStripContainer.append(select);
		}
		toolStripContainer.insertBefore(toolConfig.toolsParentContainerSelector || gridSelector);
		setTimeout(function () { toolStripContainer.data("gridSelector", gridSelector).data("exportParameters", toolConfig.exportParameters).data("manageColumnsParameters", toolConfig.manageColumnsParameters) }, 10);
	},
	showGridToolsV2: function (gridToolsParentContainerSelector, rmPageLinkId, dataGridId, gridSelector, userColumnPreferences, selectedFilterId, showManageColumns) {
		mrfNs.preInit(gridSelector, dataGridId);
		rm.ajax.preferencesSvcAsyncPost("GetUserGridFilterList", { dataGridId: dataGridId }, function (response) {
			var userFilterDetails = response;
			var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
			gridToolsConfig.toolsParentContainerSelector = gridToolsParentContainerSelector;
			gridToolsConfig.exportParameters = { rmPageLink: rmPageLinkId, dataGridId: dataGridId };
			gridToolsConfig.manageColumnsParameters = userColumnPreferences;
			gridToolsConfig.showManageColumns = showManageColumns;
			gridToolsConfig.showManageFilters = true;
			gridToolsConfig.manageFilterConfig = {
				selectedFilterId: 1,
				dataGridId: dataGridId,
				userFilters: userFilterDetails,
				onFilterChange: mrfNs.onFilterChange
			};

			rm.grid.showGridTools(gridSelector, gridToolsConfig);
			rm.grid.setGridToolFilterDropdownValue(gridSelector, selectedFilterId)
			mrfNs.init(gridSelector, dataGridId, userFilterDetails);
		});
	},
	postForExportData: function (queryStringParms, gridSearchParameters, downloadToken) {
		queryStringParms.ID = 12;

		if (downloadToken == null || downloadToken == "") {
			downloadToken = RmConstants.DownloadCompleteFlag;
		}
		$.cookie(downloadToken, "0", { path: "/" });
		var parameters = { DownloadToken: downloadToken };
		$.extend(parameters, queryStringParms, gridSearchParameters);
		window.location = "/ViewAttachment.ashx?" + jQuery.param(parameters);
		rm.grid.waitForDownloadToComplete(downloadToken);
	},
	waitForDownloadToComplete: function (downloadToken) {
		var lookupFunction;
		rm.ui.block();

		lookupFunction = setInterval(function () {
			if ($.cookie(downloadToken) == "1") {
				clearInterval(lookupFunction);
				$.cookie(downloadToken, null, { expires: 0, path: "/" });
				rm.ui.unblock();
			}
		}, 1000);
	},

	getFinalColumnModelFromFullColumnListAndUserColumnPreferences: function (uiDefinedColumnModelList, userSelectedColumnPreferences, mandatoryColumns) {
		var columnModel = rm.grid.getColumnModelFromUserPreferences(uiDefinedColumnModelList, userSelectedColumnPreferences);
		rm.utilities.insertArrayInArrayAtIndex(columnModel, mandatoryColumns);
		return rm.grid.removeActionsColumnIfNoEditableColumns(columnModel);
	},
	getColumnModelFromUserPreferences: function (uiDefinedColumnModelList, userSelectedColumnPreferences) {
		var sortByDefaultDisplayIndex = function (columnConfig) {
			return columnConfig.sort(function (a, b) {
				return (a.DefaultDisplayIndex > b.DefaultDisplayIndex) ? (a.DefaultDisplayIndex > b.DefaultDisplayIndex) ? 1 : 0 : -1
			});
		};
		var columnModelList = [];
		if (uiDefinedColumnModelList && userSelectedColumnPreferences) {
			var userSelectedColumns = (userSelectedColumnPreferences.SelectedColumnList && userSelectedColumnPreferences.SelectedColumnList.length > 0) ?
				userSelectedColumnPreferences.SelectedColumnList :
				sortByDefaultDisplayIndex(userSelectedColumnPreferences.AvailableColumnList);

			userSelectedColumns.forEach(function (userSelectedColumn) {
				var uiColumnModel = uiDefinedColumnModelList.find(function (columnModel) {
					return columnModel.name == userSelectedColumn.ColumnKey;
				});
				if (uiColumnModel) {
					if (userSelectedColumn.ColumnWidth > 0) { uiColumnModel.width = userSelectedColumn.ColumnWidth; }
					uiColumnModel.frozen = userSelectedColumn.IsFrozen;
					columnModelList.push(uiColumnModel);
				}
			});
		}
		else { columnModelList = uiDefinedColumnModelList; }
		return columnModelList;
	},
	removeActionsColumnIfNoEditableColumns: function (columnModel) {
		var filteredColumnModelList = columnModel;
		if (Array.isArray(columnModel)) {
			var editableColumn = columnModel.find(function (columnConfig) { return columnConfig.editable; });
			if (editableColumn == null) {
				filteredColumnModelList = columnModel.filter(function (column, index, arr) {
					return "actions".localeCompare(column.index, "en", { sensitivity: "base" }) != 0;
				});
			}
		}
		return filteredColumnModelList;
	},
	areAllEditableColumnsPresent: function (fullColumnList, columnModelUsedByGrid, showWarningOnUiIfMissingEditableColumn) {
		var totalEditableColumCount = 0;
		var totalSelectedEditableColumCount = 0;

		if (Array.isArray(fullColumnList)) {
			totalEditableColumCount = fullColumnList.filter(function (columnConfig) { return columnConfig.editable; }).length;
		}
		if (Array.isArray(columnModelUsedByGrid)) {
			totalSelectedEditableColumCount = columnModelUsedByGrid.filter(function (columnConfig) { return columnConfig.editable; }).length;
		}
		if (showWarningOnUiIfMissingEditableColumn && totalEditableColumCount != totalSelectedEditableColumCount) {
			rm.ui.messages.addWarningWithCloseButton("Rows cannot be edited in-line because not all editable columns are shown. Click 'Manage Columns' and add all editable columns.");
		}
		return totalEditableColumCount == totalSelectedEditableColumCount;
	},
	getDataGridColumnIdFromColIndexColModelAndUserPref: function (columnIndex, columnModel, userColumnPreferences) {
		var dataGridColumnId = -1;
		if (Array.isArray(columnModel) && userColumnPreferences && Array.isArray(userColumnPreferences.AvailableColumnList) && Array.isArray(userColumnPreferences.SelectedColumnList)) {
			var columnKey = columnModel[columnIndex].name;
			var resizedColumnConfig = userColumnPreferences.AvailableColumnList.concat(userColumnPreferences.SelectedColumnList).find(function (colConfig) { return colConfig.ColumnKey == columnKey; });
			if (resizedColumnConfig) {
				dataGridColumnId = resizedColumnConfig.Id;
			}
		}
		return dataGridColumnId;
	},
	saveDataGridColumnWidthPreference: function (newWidth, dataGridId, dataGridColumnId, gridSelector) {
		if (dataGridColumnId > 0) {
			var postData = {
				columnPreference: {
					ColumnWidth: newWidth,
					DataGridId: dataGridId,
					Id: dataGridColumnId
				}
			};
			rm.ajax.preferencesSvcAsyncPost("SaveRmUserDataGridColumnWidthPreference", postData, null, null, { global: false });
		}
		rm.grid.delayedAdjustFrozenColumnParentTableWidth(gridSelector);
	},
	delayedRebindFrozenColumns: function (gridSelector) {
		setTimeout(function () { $(gridSelector).jqGrid("setFrozenColumns"); }, 50);
		rm.grid.delayedAdjustFrozenColumnParentTableWidth(gridSelector);
	},
	delayedAdjustFrozenColumnParentTableWidth: function (gridSelector) {
		if (navigator.userAgent.search(/Edge/) != -1) {
			setTimeout(function () {
				/*Frozen header table width gets messed up only on Edge when user tries to resize the columns.
				The width issue affects only the frozen header table. Therefore, we need to determine the widts
				of each column from the non-frozen table which is hidden behind the frozen table and set 
				frozen table width based on sum of hidden non-frozen column widths.*/

				//Find out frozen header table
				var frozenHeaderTable = $("#gbox_" + gridSelector.replace("#", "")).find(".frozen-div.ui-jqgrid-hdiv > table:first()");
				var frozenHeaderCells = frozenHeaderTable.find("tr:first() th");

				//Find out non-frozen header table
				var headerTable = $("#gbox_" + gridSelector.replace("#", "")).find(".ui-jqgrid-hdiv:not(.frozen-div)").find("table.ui-jqgrid-htable");
				var headerCells = headerTable.find("tr:first() th");

				var frozenHeaderTableWidth = 0;
				//Find out number of frozen columns
				var frozenHeaderCellCount = frozenHeaderCells.length;
				if (frozenHeaderCellCount > 0) {
					var processedColumnCount = 0;
					//find out widths of first n columns from non-frozen table where n = frozen column count. 
					//We cannot use frozen column to determine widths becasue after resizing it the widths are completely mesed up and cannot be used to determine accurate width.
					$.each(headerCells, function (index, cell) {
						frozenHeaderTableWidth += $(cell).outerWidth();
						processedColumnCount++;
						if (processedColumnCount == frozenHeaderCellCount) {
							return false;
						}
					});
				}
				frozenHeaderTable.width(frozenHeaderTableWidth || "");
				//headerTable.parent().width(frozenHeaderTableWidth || "");
			}, 50);
		}
	},
	//autoSaveFilterOnGridSearch: function (gridSelector, filterCookieKey) {
	//	var gridState = {
	//		page: $(gridSelector).getGridParam("page"),
	//		rows: $(gridSelector).getGridParam("rowNum"),
	//		sidx: $(gridSelector).getGridParam("sortname"),
	//		sord: $(gridSelector).getGridParam("sortorder")
	//		//_search: $(gridSelector).getGridParam("search")
	//	};

	//	$.each(rm.grid.getFilterControls(gridSelector), function (index, element) {
	//		var filterValue = $(element).val();
	//		if (filterValue != "") {
	//			var filterName = $(element).attr("id").replace("gs_", "");
	//			gridState[filterName] = filterValue;
	//		}
	//	});
	//	$.cookie(filterCookieKey, JSON.stringify(gridState));
	//},
	setFilters: function (gridSelector, filterPropertiesJson) {
		if (filterPropertiesJson) {
			setTimeout(function () {
				for (var prop in filterPropertiesJson) {
					if (filterPropertiesJson.hasOwnProperty(prop)) {
						//convert to a function
						$.each(rm.grid.getFilterControls(gridSelector), function (index, filterControl) {
							if ($(filterControl).attr("id") == ("gs_" + prop)) {
								$(filterControl).val(filterPropertiesJson[prop]);
								/*Do not return false. When columns are frozen, grid adds duplicate header column thay overlays the original grid column.
								If we prematurely break out of the loop, the frozen column will not display the user selected filter value.*/
							}
						});
					}
				}
			}, 200);
		}
	},
	getGridFilterFromCookieAndSetGridFilterTextboxes: function (gridSelector, filterCookieKey) {
		var gridState = {};
		var gridAutoSavedFilter = $.cookie(filterCookieKey);
		if (gridAutoSavedFilter) {
			var filterJson = JSON.parse(gridAutoSavedFilter);

			for (var prop in filterJson) {
				if (filterJson.hasOwnProperty(prop)) {
					gridState[prop] = filterJson[prop];
				}
			}
			rm.grid.setFilters(gridSelector, filterJson);
		}

		return gridState;
	},
};
rm.customFields = {
	renderResourceTypeCustomfields: function (response, customFieldsContainerJqObject, showHeader, requestRowNumber, onLoadComplete) {
		customFieldsContainerJqObject.empty();
		if (response.length > 0) {
			var mandatoryField = "<span class='styleColorRed'>*</span>";
			if (showHeader) {
				customFieldsContainerJqObject.append('<h4>Custom Fields</h4>');
			}

			var missingProjectLevelCustomFieldValue = false;
			$.each(response, function (index, element) {
				var currentField = response[index];
				var mandatoryAttribute = currentField.IsControlMandatory ? " isMandatory='1' " : " allowBlank='true' ";
				var pageLevelUniqueId = currentField.UniqueControlId + "_" + requestRowNumber + "_" + index;
				var maxLengthAttribute = currentField.MaxLength == null ? "" : " maxLength='" + currentField.MaxLength + "' ";
				var errorMessageAttribute = " controlErrorMessage='" + currentField.ControlErrorMessage.replace(/'/g, '&quot;') + "' ";
				var disabledAttribute = currentField.ShowAsReadonly ? " disabled='disabled' " : "";
				var readonlyAttribute = currentField.IsReadonly ? "readonly='readonly'" : "";
				if (!missingProjectLevelCustomFieldValue) {
					missingProjectLevelCustomFieldValue = currentField.ShowWarningIfBlank && currentField.ShowAsReadonly && $.trim(currentField.DefaultValue) == "";
				}
				switch (currentField.ControlTypeId) {
					case DynamicControlTypes_E.Textarea:
						var inputTextOrNumericField = "<div><label class='inline fieldSetControl customControlsLabel'><strong id='Label" + pageLevelUniqueId + "'>" + currentField.ControlLabelName + ": </strong>";
						var inputFieldControl = "</label><div class='inline'><textarea " + maxLengthAttribute + mandatoryAttribute + errorMessageAttribute + disabledAttribute + readonlyAttribute + " ResourceTypeCustomFieldId ='" + currentField.ResourceTypeCustomFieldId + "'type='text' id='" + pageLevelUniqueId + "' class='customFieldTextArea'></textarea></div></div>";

						if (currentField.IsControlMandatory) {
							inputTextOrNumericField += mandatoryField;
						}
						inputTextOrNumericField += inputFieldControl;
						customFieldsContainerJqObject.append(inputTextOrNumericField);

						if ($.trim(currentField.DefaultValue) != "") {
							$("#" + pageLevelUniqueId).val(currentField.DefaultValue);
						}
						if (currentField.ControlToolTip != "") {
							rm.qtip.showInfo("#Label" + pageLevelUniqueId, currentField.ControlToolTip);
						}
						if (currentField.IsControlMandatory) {
							rm.customFields.attachHandlerForCustomFieldsValidation("#" + pageLevelUniqueId, currentField.ControlErrorMessage, DynamicControlTypes_E.Textarea);
						}
						break;
					case DynamicControlTypes_E.Textbox:
					case DynamicControlTypes_E.Date:
						var cssClass = (currentField.ControlTypeId == DynamicControlTypes_E.Textbox) ? "customFieldTextBox" : "fieldsetLabelWIdthMedium";
						var inputTextOrNumericField = "<div><label class='inline fieldSetControl customControlsLabel'><strong id='Label" + pageLevelUniqueId + "'>" + currentField.ControlLabelName + ": </strong>";
						var inputFieldControl;
						if (currentField.IsFieldNumeric) {
							inputFieldControl = "</label><div class='inline'><input " + maxLengthAttribute + mandatoryAttribute + errorMessageAttribute + disabledAttribute + readonlyAttribute + " ResourceTypeCustomFieldId ='" + currentField.ResourceTypeCustomFieldId + "' type='text' id='" + pageLevelUniqueId + "' class='validateRange fieldsetLabelWIdthMedium' formating='6,0' to='" + currentField.MaxNumericValue + "' from='" + currentField.MinNumericValue + "' /></input></div></div>";
						} else {
							var defaultValue = (disabledAttribute.indexOf('disabled') != -1) ? "' title ='" + currentField.DefaultValue : "";
							inputFieldControl = "</label><div class='inline'><input " + maxLengthAttribute + mandatoryAttribute + errorMessageAttribute + disabledAttribute + readonlyAttribute + " ResourceTypeCustomFieldId ='" + currentField.ResourceTypeCustomFieldId + defaultValue + "' type='text' id='" + pageLevelUniqueId + "' class='" + cssClass + "'></input></div></div>";
						}
						if (currentField.IsControlMandatory) {
							inputTextOrNumericField += mandatoryField;
						}
						inputTextOrNumericField += inputFieldControl;
						customFieldsContainerJqObject.append(inputTextOrNumericField);
						if (currentField.ControlTypeId == DynamicControlTypes_E.Date) { $("#" + pageLevelUniqueId).qDatepicker(); }
						if ($.trim(currentField.DefaultValue) != "") {
							$("#" + pageLevelUniqueId).val(currentField.DefaultValue);
						}
						if (currentField.ControlToolTip != "") {
							rm.qtip.showInfo("#Label" + pageLevelUniqueId, currentField.ControlToolTip);
						}
						if (currentField.IsFieldNumeric && currentField.IsControlMandatory) {
							rm.customFields.attachHandlerForCustomFieldsValidation("#" + pageLevelUniqueId, currentField.ControlErrorMessage);
						} else if (currentField.IsControlMandatory && currentField.ControlTypeId == DynamicControlTypes_E.Textbox) {
							rm.customFields.attachHandlerForCustomFieldsValidation("#" + pageLevelUniqueId, currentField.ControlErrorMessage, DynamicControlTypes_E.Textbox);
						}
						break;
					case DynamicControlTypes_E.RadioButtonGroup:
						var radioBtnGroupField = "<div id='" + pageLevelUniqueId + "'><span class='inline fieldSetControl customControlsLabel'><strong id='Label" + pageLevelUniqueId + "'>" + currentField.ControlLabelName + ": </strong>";
						if (currentField.IsControlMandatory) {
							radioBtnGroupField += mandatoryField;
						}
						radioBtnGroupField += "</span>";
						var valuesList = rm.utilities.getJsonOrStringArray(currentField.ValuesList);
						for (i = 0; i < valuesList.length; i++) {
							var defaultValue = "";
							if (valuesList[i] == currentField.DefaultValue) {
								defaultValue = "checked='checked'";
							}
							var rbUniqueId = pageLevelUniqueId + "_" + i;
							radioBtnGroupField += "<div class='inline'><span id='span_" + rbUniqueId + "' class='spanYesNo rb' >" + valuesList[i] + "</span><input " + mandatoryAttribute + errorMessageAttribute + disabledAttribute + readonlyAttribute + " id='" + rbUniqueId + "' ResourceTypeCustomFieldId ='" + currentField.ResourceTypeCustomFieldId + "' class='radioYes' type='radio' " + defaultValue + " name='" + pageLevelUniqueId + "' dataValue='" + valuesList[i].replace(/'/g, '&quot;') + "'></input></div>";
						}
						radioBtnGroupField += "</div>";
						customFieldsContainerJqObject.append(radioBtnGroupField);
						setTimeout(function () {
							for (i = 0; i < valuesList.length; i++) {
								var controlId = pageLevelUniqueId + "_" + i;
								$("#" + controlId).click(function () {
									$("[name=" + $(this).attr("name") + "]").each(function (index, element) {
										rm.validation.clearError($(element).parent().find("span.rb"));
										rm.validation.clearError($(element));
									})
								});
							}
						}, 10);
						if (currentField.ControlToolTip != "") {
							rm.qtip.showInfo("#Label" + pageLevelUniqueId, currentField.ControlToolTip);
						}
						break;
					case DynamicControlTypes_E.Checkbox:
						var checkboxField = "<div><label class='inline fieldSetControl customControlsLabel'><strong id='Label" + pageLevelUniqueId + "'>" + currentField.ControlLabelName + ": ";
						if (currentField.IsControlMandatory) {
							checkboxField += mandatoryField + "</strong></label><div class='inline'><table id='" + pageLevelUniqueId + "'>";
						} else {
							checkboxField += "</strong></label><div class='inline'><table style='margin-left: -4px;' id='" + pageLevelUniqueId + "'>";
						}
						var valuesList = rm.utilities.getJsonOrStringArray(currentField.ValuesList);
						for (i = 0; i < valuesList.length; i++) {
							checkboxField += "<tr><td><input " + mandatoryAttribute + errorMessageAttribute + disabledAttribute + readonlyAttribute + " ResourceTypeCustomFieldId ='" + currentField.ResourceTypeCustomFieldId + "' type='checkbox' style='vertical-align: middle;' id='" + pageLevelUniqueId + "_" + i + "' name='" + valuesList[i] + "' groupName='" + pageLevelUniqueId + "' dataValue='" + valuesList[i].replace(/'/g, '&quot;') + "'/>" + valuesList[i] + "</td></tr>";
						}
						checkboxField += "</table></div></div>";
						customFieldsContainerJqObject.append(checkboxField);
						var defaultValueObj = rm.utilities.getJsonOrStringArray(currentField.DefaultValue);
						$.each(defaultValueObj, function (indexVal, element) {
							$("#" + pageLevelUniqueId + " [name='" + defaultValueObj[indexVal] + "']").prop("checked", "checked");
						});

						if (currentField.ControlToolTip != "") {
							rm.qtip.showInfo("#Label" + pageLevelUniqueId, currentField.ControlToolTip);
						}
						setTimeout(function () {
							for (i = 0; i < valuesList.length; i++) {
								var controlId = pageLevelUniqueId + "_" + i;
								$("#" + controlId).click(function () {
									$("[groupname=" + $(this).attr("groupname") + "]").each(function (index, element) {
										rm.validation.clearError($(element).parent());
										rm.validation.clearError($(element));
									})
								});
							}
						}, 10);
						break;
					case DynamicControlTypes_E.Dropdown:
						if (currentField.IsMultiSelectControl) {
							var multiselectDdlField = "<div><label class='inline fieldSetControl customControlsLabel'><strong id='Label" + pageLevelUniqueId + "'>" + currentField.ControlLabelName + ": </strong>";
							if (currentField.IsControlMandatory) {
								multiselectDdlField += mandatoryField;
							}
							multiselectDdlField += "</label><div class='inline'><select " + mandatoryAttribute + errorMessageAttribute + disabledAttribute + readonlyAttribute + " ResourceTypeCustomFieldId ='" + currentField.ResourceTypeCustomFieldId + "' id='" + pageLevelUniqueId + "' multiple='multiple'>";

							var values = rm.utilities.getJsonOrStringArray(currentField.ValuesList);
							for (i = 0; i < values.length; i++) {
								multiselectDdlField += "<option value='" + values[i] + "'>" + values[i] + "</option>";
							}

							multiselectDdlField += "</select></div></div>";
							customFieldsContainerJqObject.append(multiselectDdlField);
							$("#" + pageLevelUniqueId).multiselect({ selectedList: 2 });
							if (currentField.DefaultValue != "") {
								var defaultValueObj = rm.utilities.getJsonOrStringArray(currentField.DefaultValue);
								$.each(defaultValueObj, function (indexVal, element) {
									$("#" + pageLevelUniqueId + " option[value='" + defaultValueObj[indexVal] + "']").prop("selected", "selected");
								});
							}
							$("#" + pageLevelUniqueId).multiselect('refresh');
							$('.ui-multiselect').attr("style", "width:200px;");
							if (currentField.ControlToolTip != "") {
								rm.qtip.showInfo("#Label" + pageLevelUniqueId, currentField.ControlToolTip);
							}
							break;
						} else {
							var dropdownField = "<div><label class='inline fieldSetControl customControlsLabel'><strong id='Label" + pageLevelUniqueId + "'>" + currentField.ControlLabelName + ": </strong>";
							if (currentField.IsControlMandatory) {
								dropdownField += mandatoryField;
							}
							dropdownField += "</label><div class='inline'><select " + mandatoryAttribute + errorMessageAttribute + disabledAttribute + " ResourceTypeCustomFieldId ='" + currentField.ResourceTypeCustomFieldId + "' id='" + pageLevelUniqueId + "' class='fieldsetLabelmaxWidth200'>";
							var valuesList = rm.utilities.getJsonOrStringArray(currentField.ValuesList);
							if (valuesList.length > 0) { dropdownField += "<option value='-1'>--Select--</option>"; }
							for (i = 0; i < valuesList.length; i++) {
								dropdownField += "<option value='" + valuesList[i] + "'>" + valuesList[i] + "</option>";
							}
							dropdownField += "</select></div></div>";
							customFieldsContainerJqObject.append(dropdownField);
							if (currentField.DefaultValue != "") {
								$("#" + pageLevelUniqueId + " option[value='" + currentField.DefaultValue + "']").attr("selected", "selected");
							}
							if (currentField.ControlToolTip != "") {
								rm.qtip.showInfo("#Label" + pageLevelUniqueId, currentField.ControlToolTip);
							}
							if (currentField.IsControlMandatory) { rm.customFields.attachHandlerForCustomFieldsValidation("#" + pageLevelUniqueId, currentField.ControlErrorMessage, DynamicControlTypes_E.Dropdown); }
							break;
						}
				};
			});

			if (missingProjectLevelCustomFieldValue) {
				rm.ui.messages.addWarningAsBlock("One or more Project Level fields are not set. Consider asking the project owner to set a value in the QRPM: PPM Project Background page.");
			}
		}
		if (onLoadComplete != null && $.isFunction(onLoadComplete)) {
			setTimeout(onLoadComplete, 10);
		}
	},
	getCustomFieldUserEnteredValues: function (customFieldsContainerJqObject) {
		var customFieldData = new Array();
		var readCheckboxGroupNames = new Array();
		$.each(customFieldsContainerJqObject.find("input[type=text]:not([disabled]),input:checked:not([disabled]),select:not([disabled]),textarea:not([disabled])"), function (index, element) {
			var jqElement = $(element);
			var customFieldValue = null;

			if (jqElement.is(':checkbox')) {
				var checkboxGroupName = jqElement.attr("groupName");
				if ($.inArray(checkboxGroupName, readCheckboxGroupNames) == -1) {
					var checkboxValueList = new Array();
					$.each(customFieldsContainerJqObject.find("[groupName=" + checkboxGroupName + "]:checked"), function (index, checkBox) {
						checkboxValueList.push($(checkBox).attr("dataValue"));
					});
					customFieldValue = checkboxValueList.join("~|~");
					readCheckboxGroupNames.push(checkboxGroupName);
				}
			}
			else if (jqElement.attr("multiple") == "multiple") { customFieldValue = jqElement.val().join("~|~") }
			else if (jqElement.is(':radio')) { customFieldValue = jqElement.attr("dataValue"); }
			else { customFieldValue = jqElement.val(); }

			if (customFieldValue != null) {
				customFieldData.push({ ResourceTypeCustomFieldId: jqElement.attr("ResourceTypeCustomFieldId"), Value: customFieldValue });
			}
		});

		return customFieldData;
	},
	getCustomFieldValue: function (jqElement) {
		var customFieldValue = null;

		if (jqElement.is(':checkbox')) {
			var checkboxGroupName = jqElement.attr("groupName");
			var checkboxValueList = [];
			$.each($("[groupName=" + checkboxGroupName + "]:checked"), function (index, checkBox) {
				checkboxValueList.push($(checkBox).attr("dataValue"));
			});
			customFieldValue = JSON.stringify(checkboxValueList);
		}
		else if (jqElement.attr("multiple") == "multiple") { customFieldValue = JSON.stringify(jqElement.val()) }
		else if (jqElement.is(':radio')) { customFieldValue = $("[groupName=" + jqElement.attr("groupName") + "]:checked").attr("datavalue"); }
		else { customFieldValue = jqElement.val(); }

		return customFieldValue;
	},
	attachHandlerForCustomFieldsValidation: function (elementId, controlErrorMessage, controlType) {
		$(document).on("blur change", elementId, function () {
			if ($(elementId).val() == "" || ($(elementId).val() == -1 && controlType == DynamicControlTypes_E.Dropdown)) {
				rm.validation.addError(elementId, controlErrorMessage);
			}
			else if ($(elementId).val() != -1 && controlType == DynamicControlTypes_E.Dropdown) {
				rm.validation.clearError($(elementId));
				rm.validation.clearError($(elementId).parent());
			}
			else if ($(elementId).val() != "" && (controlType == DynamicControlTypes_E.Textbox || controlType == DynamicControlTypes_E.Textarea)) {
				rm.validation.clearError($(elementId));
			}
			else if ($(elementId).val() != "" && controlType == DynamicControlTypes_E.Checkbox) {
				rm.validation.clearError($(elementId));
				rm.validation.clearError($(elementId).parent());
			}
		});
	},
	areCustomFieldsValid: function (customFieldsContainerJqObject) {
		var isValid = true;
		$.each(customFieldsContainerJqObject.find("input,select,textarea"), function (index, element) {
			var jqElement = $(element);

			if (jqElement.attr("isMandatory") == "1") {
				if ((jqElement.is(":text") && $.trim(jqElement.val()) == "" && !jqElement.hasClass("validateRange")) ||
					(jqElement.is("select") && (jqElement.val() == "" || jqElement.val() == "-1")) ||
					(jqElement.is("textarea") && $.trim(jqElement.val()) == "")) {
					isValid = false;
					rm.validation.addError(jqElement, jqElement.attr("controlErrorMessage"));
				}
				else { rm.validation.clearError(jqElement); }

				if (jqElement.is(":radio")) {
					if ($("[name=" + jqElement.prop("name") + "]:checked").length == 0) {
						isValid = false;
						rm.validation.addError(jqElement, jqElement.attr("controlErrorMessage"));
						var span = jqElement.parent().find("span.rb");
						rm.validation.addError(span, jqElement.attr("controlErrorMessage"));
					}
					else { rm.validation.clearError(jqElement); }
				}

				if (jqElement.is(":checkbox")) {
					if ($("[groupName=" + jqElement.attr("groupName") + "]:checked").length == 0) {
						isValid = false;
						rm.validation.addError(jqElement, jqElement.attr("controlErrorMessage"));
						rm.validation.addError(jqElement.parent(), jqElement.attr("controlErrorMessage"));
					}
					else { rm.validation.clearError(jqElement); }
				}
			}

			if (jqElement.hasClass("validateRange")) {
				if (rm.validation.range.validate(jqElement)) { rm.validation.clearError(jqElement); }
				else { isValid = false; }
			}

		});
		return isValid;
	}
};
rm.ui = {
	jqUiClasses: {
		disabledControl: "ui-state-disabled"
	},
	jqControlBuilder: {
		errorIcon: function (options) {
			options = options || {};
			options.src = "/_layouts/SPUI/images/errorIcon.png";
			return $("<img>", options);
		}
	},
	constants: {
		minimumPageHeight: 100,
		errorDialogId: "errorDialogDiv"
	},
	utilities: {
		disableJqUiControl: function (elementOrSelector) {
			element = (elementOrSelector instanceof $) ? elementOrSelector : $(elementOrSelector);
			element.prop("disabled", "disabled").addClass(rm.ui.jqUiClasses.disabledControl);
		},
		enableJqUiControl: function (elementOrSelector) {
			element = (elementOrSelector instanceof $) ? elementOrSelector : $(elementOrSelector);
			element.removeProp("disabled").removeClass(rm.ui.jqUiClasses.disabledControl);
		},
		bringAutocompleteMenuForward: function (autocompleteTextbox) {
			var dialog = $(autocompleteTextbox).closest('.ui-dialog');
			if (dialog.length > 0) {
				$('.ui-autocomplete.ui-front').css("zIndex", dialog.css("zIndex") + 1);
			}
		},
		disableDatePicker: function (datePickerSelector) { $(datePickerSelector).qDatepicker().qDatepicker("disable"); },
		enableDatePicker: function (datePickerSelector) { $(datePickerSelector).qDatepicker().qDatepicker("enable"); },
	},
	messages: {
		pageContentContainerId: "#s4-workspace",
		dialogContentContainer: ".ui-dialog-content:visible",
		displayBehavior: { showCloseButton: 1, showAndFadeAway: 2, alwaysVisible: 3 },
		messageAction: { add: 1, replace: 2 },
		messageType: { success: 1, warning: 2, error: 3 },
		messageBoardBlockContainerId: "divMessageBoardBlockContainer",
		messageBoardBlockContainerClass: "messageBoardBlockContainer",
		messageBoardContainerId: "divMessageBoardContainer",
		messageBoardContainerClass: "messageBoardContainer",
		successContainerId: "divSuccessContainer",
		successContainerClass: "successContainer",
		successMessageClass: "successMessage",
		errorContainerId: "divErrorContainer",
		errorContainerClass: "errorContainer",
		errorBlockContainerId: "divErrorBlockContainer",
		errorBlockContainerClass: "errorBlockContainer",
		errorMessageClass: "errorMessage",
		warningBlockContainerId: "divWarningBlockContainer",
		warningBlockContainerClass: "warningBlockContainer",
		warningContainerId: "divWarningContainer",
		warningContainerClass: "warningContainer",
		warningMessageClass: "warningMessage",
		getSelector: function (containerId, containerClass) { return "#" + containerId + "." + containerClass; },
		showMessageOnUi: function (message, containerId, containerClass, messageClass, displayBehavior, messageAction, messageType, renderAsBlock, renderInDialog) {
			var pageContainerId = this.pageContentContainerId;
			var boardContainerId = (renderAsBlock == true) ? this.messageBoardBlockContainerId : this.messageBoardContainerId;
			if (renderInDialog) {
				boardContainerId = "dialog" + boardContainerId;
				containerId = "dialog" + containerId;
				pageContainerId = this.dialogContentContainer;
			}
			var boardContainerClass = renderAsBlock ? this.messageBoardBlockContainerClass : this.messageBoardContainerClass;
			//Make sure message board exists
			var messageBoardDiv = $(this.getSelector(boardContainerId, boardContainerClass));
			if (messageBoardDiv.length == 0) {
				messageBoardDiv = $("<div/>", { id: boardContainerId, class: boardContainerClass });
				var insertBefore;
				if (renderAsBlock) {
					insertBefore = $(this.getSelector(this.messageBoardContainerId, this.messageBoardContainerClass));
					if (insertBefore.length == 0) {
						insertBefore = $(pageContainerId);
					}
				}
				else {
					insertBefore = $(pageContainerId);
				}
				insertBefore.before(messageBoardDiv);

				if (renderInDialog) {
					$("#" + boardContainerId).width($(rm.ui.messages.dialogContentContainer).width())
				}
				setTimeout(function () { if (renderInDialog != true && renderAsBlock) { $(rm.ui.messages.pageContentContainerId).height($(rm.ui.messages.pageContentContainerId).height() - messageBoardDiv.height()); } }, 1000);
			}
			//Make sure message container exists for given message type error, warning, success etc.
			//var messageContainerDiv = $(this.getSelector(containerId, containerClass));
			var messageContainerDiv = messageBoardDiv.find("." + containerClass);
			if (messageContainerDiv.length == 0) {
				messageContainerDiv = $("<div/>", { id: containerId, class: containerClass, css: { display: "none" } });
				messageBoardDiv.append(messageContainerDiv);
			}
			var messageDiv = $("<div/>", { class: messageClass }).html(message);

			if (messageAction == this.messageAction.add) {
				messageContainerDiv.append(messageDiv)
			}
			else if (messageAction == this.messageAction.replace) {
				messageContainerDiv.html("").append(messageDiv);
			}

			if (displayBehavior == this.displayBehavior.showAndFadeAway) {
				messageContainerDiv.fadeIn(500, function () { setTimeout(function () { messageContainerDiv.fadeOut(400); }, 3500); });
			}
			else if (displayBehavior == this.displayBehavior.showCloseButton) {
				var closeImgId = "imgCloseError"
				var closeImg = messageContainerDiv.find("#" + closeImgId);
				if (closeImg.length == 0) {
					messageContainerDiv.prepend($("<img>", { id: closeImgId, src: "/_Layouts/SPUI/images/Close3.png", css: { float: "right", marginRight: "30px" }, click: function () { messageContainerDiv.html("").hide(); } }));
				}
				messageContainerDiv.show();
			}
			else if (displayBehavior == this.displayBehavior.alwaysVisible) {
				messageContainerDiv.show();
			}
		},
		addMessage: function (message, containerId, containerClass, messageClass, displayBehavior, messageType, renderInDialog) { this.showMessageOnUi(message, containerId, containerClass, messageClass, displayBehavior, this.messageAction.add, messageType, false, renderInDialog) },
		showMessage: function (message, containerId, containerClass, messageClass, displayBehavior, messageType, renderAsBlock, renderInDialog) {
			if (renderInDialog != true) { this.clearMessages(containerId, containerClass); }
			this.showMessageOnUi(message, containerId, containerClass, messageClass, displayBehavior, this.messageAction.replace, messageType, renderAsBlock, renderInDialog);
		},
		clearMessages: function (containerId, containerClass) { $(this.getSelector(containerId, containerClass)).html("").hide(); },
		showSuccess: function (message) { this.showMessage(message, this.successContainerId, this.successContainerClass, this.successMessageClass, this.displayBehavior.showAndFadeAway, this.messageType.success); },
		addSuccess: function (message) { this.addMessage(message, this.successContainerId, this.successContainerClass, this.successMessageClass, this.displayBehavior.showAndFadeAway, this.messageType.success); },
		clearSuccess: function () { this.clearMessages(this.successContainerId, this.successContainerClass); },
		showWarning: function (message) { this.showMessage(message, this.warningContainerId, this.warningContainerClass, this.warningMessageClass, this.displayBehavior.alwaysVisible, this.messageType.warning); },
		showWarningAndFadeAway: function (message) { this.showMessage(message, this.warningContainerId, this.warningContainerClass, this.warningMessageClass, this.displayBehavior.showAndFadeAway, this.messageType.warning); },
		addwWarning: function (message) { this.showMessage(message, this.warningContainerId, this.warningContainerClass, this.warningMessageClass, this.displayBehavior.alwaysVisible, this.messageType.warning); },
		addWarningAsBlock: function (message) { this.showMessage(message, this.warningBlockContainerId, this.warningBlockContainerClass, this.warningMessageClass, this.displayBehavior.alwaysVisible, this.messageType.warning, true); },
		showWarningWithCloseButton: function (message) { this.showMessage(message, this.warningContainerId, this.warningContainerClass, this.warningMessageClass, this.displayBehavior.showCloseButton, this.messageType.warning); },
		addWarningWithCloseButton: function (message) { this.addMessage(message, this.warningContainerId, this.warningContainerClass, this.warningMessageClass, this.displayBehavior.showCloseButton, this.messageType.warning); },
		clearWarning: function () { this.clearMessages(this.warningContainerId, this.warningContainerClass); },
		clearBlockWarning: function () { this.clearMessages(this.warningBlockContainerId, this.warningBlockContainerClass); },
		showError: function (message) { this.showMessage(message, this.errorContainerId, this.errorContainerClass, this.errorMessageClass, this.displayBehavior.alwaysVisible, this.messageType.error); },
		addError: function (message) { this.addMessage(message, this.errorBlockContainerId, this.errorBlockContainerClass, this.errorMessageClass, this.displayBehavior.showCloseButton, this.messageType.error); },
		showErrorAsBlock: function (message) { this.showMessage(message, this.errorContainerId, this.errorContainerClass, this.errorMessageClass, this.displayBehavior.alwaysVisible, this.messageType.error, true); },
		clearAllError: function () { this.clearBlockError(); this.clearError() },
		clearBlockError: function () { this.clearMessages(this.errorBlockContainerId, this.errorBlockContainerClass); },
		clearError: function () { this.clearMessages(this.errorContainerId, this.errorContainerClass); },
		clearAllMessages: function () { this.clearSuccess(); this.clearWarning(); this.clearBlockWarning(); this.clearAllError(); },
		showErrorInDialog: function (message) { this.showMessage(message, this.errorContainerId, this.errorContainerClass, this.errorMessageClass, this.displayBehavior.alwaysVisible, this.messageType.error, false, true); },
		addErrorInDialog: function (message) { this.addMessage(message, this.errorBlockContainerId, this.errorBlockContainerClass, this.errorMessageClass, this.displayBehavior.showCloseButton, this.messageType.error, true); },
	},
	dialog: {
		defaultOptions: {
			title: "",
			htmlMessage: "Override this message",
			width: 400,
			height: 400,
			resizable: true,
			showModal: true,
			buttons: [],
			onOpen: null,
			onClose: null
		},
		standardButtons: {
			cancel: { text: "Cancel", click: function () { $(this).dialog("close"); } }
		},
		getMaxAllowedHeight: function () { return window.screen.availHeight - 180; },
		close: function (dialogContainerSelector) { $(dialogContainerSelector).dialog("close"); },
		show: function (messageContainer, dialogOptions) {
			if ($.trim(dialogOptions.htmlMessage) != "") { $(messageContainer).html(dialogOptions.htmlMessage); }
			var elementInFocus = $("[type=text]:focus");
			return $(messageContainer).dialog({
				modal: dialogOptions.showModal,
				title: dialogOptions.title,
				resizable: dialogOptions.resizable,
				width: dialogOptions.width,
				height: dialogOptions.height,
				close: function (ev, ui) {
					if (dialogOptions.onClose) { dialogOptions.onClose(); }
					$(document).unbind("focusin");//addressing _focustabbable issue
					setTimeout(function () { if (elementInFocus && elementInFocus.length > 0 && elementInFocus.is(":visible")) { elementInFocus.focus(); } }, 20);
				},
				open: function (ev, ui) { if (dialogOptions.onOpen) { dialogOptions.onOpen(); } },
				buttons: dialogOptions.buttons
			});
		},
		showWithButtonsAndCloseHandler: function (messageContainer, title, htmlMessage, resizable, width, height, showModal, buttonArray, onClose, onOpen) {
			var dialogOptions = JSON.parse(JSON.stringify(this.defaultOptions));
			dialogOptions.title = title;
			dialogOptions.htmlMessage = htmlMessage;
			dialogOptions.resizable = resizable;
			dialogOptions.showModal = showModal;
			dialogOptions.width = width;
			dialogOptions.height = height;
			dialogOptions.buttons = buttonArray;
			dialogOptions.onOpen = onOpen;
			dialogOptions.onClose = onClose;
			return this.show(messageContainer, dialogOptions);
		},
		showModalWithButtonsAndCloseHandler: function (messageContainer, title, htmlMessage, resizable, width, height, buttonArray, onClose, onOpen) {
			return this.showWithButtonsAndCloseHandler(messageContainer, title, htmlMessage, resizable, width, height, true, buttonArray, onClose, onOpen);
		},
		showModalWithButtons: function (messageContainer, title, htmlMessage, resizable, width, height, buttonArray) {
			return this.showModalWithButtonsAndCloseHandler(messageContainer, title, htmlMessage, resizable, width, height, buttonArray, null, null);
		},
		showModal: function (messageContainer, title, htmlMessage, resizable, width, height, onClose, onOpen) { return this.showModalWithButtonsAndCloseHandler(messageContainer, title, htmlMessage, resizable, width, height, null, onClose, onOpen); },
		showServiceErrorModal: function (title, htmlMessage) {
			var divId = "serviceErrorModalContainer";
			var divSelector = "#" + divId;
			if ($(divSelector).length == 0) { $("body").append($("<iframe>", { id: divId, style: { height: "300px", width: "700px" } })); }
			setTimeout(function () { $(divSelector).width("700px").contents().find('body').html(htmlMessage); }, 10);
			return this.showModal(divSelector, title, "", true, 720, 300);
		},
		showWaitModalWithNoClose: function (message) {
			var divId = "waitModalContainer";
			var divSelector = "#" + divId;
			if ($(divSelector).length == 0) { $("body").append($("<div>", { id: divId })); }

			message = "<div style='padding: 10px;'><table><tbody><tr><td style='vertical-align: top; padding-top: 6px;'><img src='/_layouts/SPUI/images/gears_anv4.gif'></td><td style='padding-left:5px;'>" + message + "</td></tr></tbody></table></div>";
			return this.showWithButtonsAndCloseHandler(divSelector, "Please Wait ...", message, false, 360, 105, true, null, null, function () { $(divSelector).parent().find(".ui-dialog-titlebar-close").hide(); }).dialog("option", "closeOnEscape", false);;
		},
		closeWaitModal: function () { },
		toggleButtonEnableDisable: function (buttonText, isEnabled) { $(".ui-dialog-buttonpane button:contains('" + buttonText + "')").button(isEnabled ? "enable" : "disable"); },
		setDefaultButton: function (dialogSelector, buttonText) { $(dialogSelector).parent().find(".ui-dialog-buttonpane button:contains(" + buttonText + ")").focus() }
	},
	block: function (optionalMessage) { this.handle = this.dialog.showWaitModalWithNoClose(optionalMessage ? optionalMessage : "Loading..."); },
	unblock: function () { if (this.handle) { this.handle.dialog("close"); } },
	ribbon: {
		containerSelector: "#RmRibbonrow",
		disabledClass: "rm-ribbon-disabled",
		tabPanelAttr: "rmTabPanel",
		tabAttr: "rmTab",
		selectedTabClass: "rm-tt-s",
		classRmRibbonCtlItems: "rm-ribbon-menusection-items",
		classRmRibbonCtlMenuOn: "rm-ribbon-ctl-menu-on",
		classRmRibbonCtlHoverdOver: "rm-ribbon-ctl-hoveredOver",
		getTabPanelSelector: function () { return "[role=" + rm.ui.ribbon.tabPanelAttr + "]" },
		getTabSelector: function () { return "[role=" + rm.ui.ribbon.tabAttr + "]" },
		handleMenuClick: function (commandId) {
			setTimeout(function () {
				var menuButton = $("#" + commandId).addClass(rm.ui.ribbon.classRmRibbonCtlHoverdOver);
				$("#" + menuButton.attr("id") + "_Menu").show().css({ top: menuButton.offset().top + menuButton.height() + 6, left: menuButton.offset().left });
			}, 10);
		},
		handleTabHeaderClick: function () {
			var tab = $(this);
			$(rm.ui.ribbon.getTabPanelSelector()).hide();
			$("#" + tab.attr("tabBodyId")).show();
			$(rm.ui.ribbon.getTabSelector()).removeClass(rm.ui.ribbon.selectedTabClass);
			tab.addClass(rm.ui.ribbon.selectedTabClass);
		},
		enableDisableRibbonButtons: function () {
			var ribbonCommands = getRmRibbonGlobalCommands();
			if (Array.isArray(ribbonCommands)) {
				$.each(ribbonCommands, function (index, ribbonCommandId) {
					if (rmRibbonCommandEnabled(ribbonCommandId) === true) { $("#" + ribbonCommandId).removeClass(rm.ui.ribbon.disabledClass).removeAttr("disabled"); }
					else { $("#" + ribbonCommandId).addClass(rm.ui.ribbon.disabledClass).attr("disabled", "disabled"); }
				});
			}
		},
		bindRibbonButtonClick: function () {
			var ribbonCommands = getRmRibbonGlobalCommands();
			if (Array.isArray(ribbonCommands)) {
				$.each(ribbonCommands, function (index, ribbonCommandId) {
					$("#" + ribbonCommandId).click(function () {
						if (!$("#" + ribbonCommandId).hasClass(rm.ui.ribbon.disabledClass)) {
							if ($("#" + ribbonCommandId).parent().hasClass(rm.ui.ribbon.classRmRibbonCtlItems)) {
								var menuButtonId = $("#" + ribbonCommandId).closest("div[role=menu]").hide().attr("id").replace(/_Menu$/, "");
								$("#" + menuButtonId).removeClass(rm.ui.ribbon.classRmRibbonCtlHoverdOver)
							}
							rmRibbonHandleCommand(ribbonCommandId);
						}
					});
				});
			}
		},
		hideMenuOnDocumentClick: function () {
			var ribbonCommands = getRmRibbonGlobalCommands();
			if (Array.isArray(ribbonCommands)) {
				$.each(ribbonCommands, function (index, ribbonCommandId) {
					$("#" + ribbonCommandId).removeClass(rm.ui.ribbon.classRmRibbonCtlHoverdOver).removeClass(rm.ui.ribbon.classRmRibbonCtlMenuOn);
					$("#" + ribbonCommandId + "_Menu").hide();
				});
			}
		},
		bindRibbonTabHeaderClick: function () { $(rm.ui.ribbon.getTabSelector()).click(rm.ui.ribbon.handleTabHeaderClick); },
		bindRibbonMenuItemHover: function () {
			$("li." + rm.ui.ribbon.classRmRibbonCtlItems).mouseenter(function () { $(this).addClass(rm.ui.ribbon.classRmRibbonCtlMenuOn) })
				.mouseleave(function () { $(this).removeClass(rm.ui.ribbon.classRmRibbonCtlMenuOn) });
		},
		onLoad: function () {
			rm.ui.ribbon.bindRibbonTabHeaderClick();
			rm.ui.ribbon.bindRibbonButtonClick();
			rm.ui.ribbon.bindRibbonMenuItemHover();
			$(document).click(rm.ui.ribbon.hideMenuOnDocumentClick);
			rm.ui.ribbon.delayedRefresh();
		},
		refresh: function () {
			if ($(rm.ui.ribbon.containerSelector).length > 0) {
				rm.ui.ribbon.enableDisableRibbonButtons();
			}
		},
		delayedRefresh: function () { setTimeout(rm.ui.ribbon.refresh, 50); },
		addHiddenWaitSpinner: function (buttonSelector, spinnerId) {
			var ribbonButton = $(buttonSelector);
			if (ribbonButton.length > 0) {
				var position = ribbonButton.offset();
				var spinnerTop = position.top + 8;
				var spinnerLeft = position.left + 25;
				var html = "<img id='" + spinnerId + "' src='/_layouts/SPUI/images/gears_anv4.gif' style='z-index:10;display:none;position:fixed;top:" + spinnerTop + "px;left:" + spinnerLeft + "px;' />";
				$(ribbonButton).append(html);
			}
		}
	},
	getContentContainerHeight: function () { return $(window).height() - $("#RmRibbonrow").height() - $("#RmTopNav").height() - 10; },
	getContentContainerWidth: function () { return $(window).width(); },
	getPageHeight: function () { return $(window).height() - 350; },
	getMinPageHeight: function () {
		var pageHeight = this.getPageHeight();
		return pageHeight < this.constants.minimumPageHeight ? this.constants.minimumPageHeight : pageHeight;
	},
	getMaxGridWidth: function () { return rm.ui.getContentContainerWidth(); },
	getMaxGridHeight: function () { return rm.ui.getContentContainerHeight() - 170 },
	openCollapsiblePanel: function (selector) {
		if (!$("#accordionTitle").hasClass("ui-state-active")) {
			$(selector).accordion("option", "active", 0);
		}
	},
	closeCollapsiblePanel: function (selector) {
		$(selector).accordion("option", "active", 999);
	},
	tabs: {
		destroy: function (tabSelector) { $(tabSelector).tabs("destroy"); },
		activateByIndex: function (tabSelector, tabIndex) { $(tabSelector).tabs("option", "active", tabIndex); },
		enableByIndex: function (tabSelector, tabIndex) { $(tabSelector).tabs("enable", tabIndex); },
		disableByIndex: function (tabSelector, tabIndexArray) { $(tabSelector).tabs("option", "disabled", tabIndexArray); },
		getSelecteTabIndex: function (tabSelector) { var selectedTabIndex = $(tabSelector).tabs("option", "active"); return (selectedTabIndex === false) ? -1 : selectedTabIndex; },
		removeByIndex: function (tabSelector, tabIndex) {
			var tabNumber = parseInt(tabIndex) + 1;
			$(tabSelector + "-" + tabNumber.toString()).remove();
			$(tabSelector).find("a[href=" + tabSelector + "-" + tabNumber + "]").parent().remove();
			$(tabSelector).tabs("refresh");
		},
		add: function (tabSelector, tabId, tabText, tabBody) {
			$("<li><a href='" + tabId + "'>" + tabText + "</a></li>").appendTo(tabSelector + " .ui-tabs-nav");
			$(tabSelector).append(tabBody);
			$(tabSelector).tabs("refresh");
		},
		removeByTabTitle: function (tabSelector, tabTitle) {
			var tab = $(tabSelector).find("a:contains('" + tabTitle + "')");
			$(tab.attr("href")).remove();//Removing tab body
			tab.parent().remove();//removing tab title
		},
		removeAllTabs: function (tabSelector) {
			$(tabSelector).find("a").each(function (index, element) {
				$($(element).attr("href")).remove();//Removing tab body
				$(element).parent().remove();//removing tab title
			});
		}
	},
	notes: {
		bindNotesIconClick: function () {
			$('.q_entity_has_comments,.q_entity_has_no_comments').unbind("click").click(function () {
				var title;
				var messageDiv = $(this);
				var qString = "entityId=" + messageDiv.attr("entityId")
					+ "&searchLevel=" + messageDiv.attr("searchLevel")
					+ "&entityTypeId=" + messageDiv.attr("entityTypeId")
					+ "&countryId=" + messageDiv.attr("countryId")
					+ "&regionId=" + messageDiv.attr("regionId")
					+ "&projectId=" + messageDiv.attr("projectId")
					+ "&resourceTypeId=" + messageDiv.attr("resourceTypeId")
					+ "&projectJobRoleId=" + messageDiv.attr("projectJobRoleId")
					+ "&random=" + Math.random();

				switch (messageDiv.attr("entityTypeName")) {
					case "Project":
						title = messageDiv.attr("projectCode");
						break;
					case "Region":
						title = messageDiv.attr("projectCode") + " - " + messageDiv.attr("regionCode");
						break;
					case "SsvAttribute":
						title = messageDiv.attr("projectCode") + " - " + messageDiv.attr("countryCode");
						break;
					case "MonitoringAttribute":
						title = messageDiv.attr("projectCode") + " - " + messageDiv.attr("countryCode");
						break;
					case "Request":
						title = messageDiv.attr("projectCode") + " - " + messageDiv.attr("countryCode") + " - " + messageDiv.attr("resourceTypeName");
						break;
					case "JobRole":
						title = messageDiv.attr("projectCode") + " - " + messageDiv.attr("projectJobRoleName");
						break;
					case "Staff":
						title = messageDiv.attr("resourceName");
						break;
					case "SpecialAssignment":
						title = "Special Assignment";
						break;
					default:

				}

				$.ajax({
					url: "/_Layouts/SPUI/MessageCenter/CommentsV2.aspx?" + qString,
					success: function (data) {
						var container = $("#dialogContainer");
						if (container.length == 0) {
							container = $("<div id='dialogContainer' />");
							$('body').append(container);
						}

						setTimeout(function () { rm.ui.dialog.showModal("#dialogContainer", title, data, false, 400, 450); }, 10);
					}
				});
			});
		}
	}
};
rm.budget = {
	isRefreshRunning: false,
	_allowRefresh: null,
	getProjectId: function () { return $("[id$=hdnProjectId]").val() * 1; },
	isProposalProject: function () { return $("[id$=hdnIsProposalProject]").val() == "1"; },
	initRefresh: function () {
		if (this.isRefreshSupportedOnPage()) {
			this.addHiddenRefreshSpinner();
			this.isBudgetRefreshRunning();
		}
	},
	isRefreshSupportedOnPage: function () {
		return $("[id*=RefreshBudgetDataButton]").length > 0;
	},
	refresh: function () {
		if (this.allowBudgetRefresh(true) && confirm(Resources.ConfirmQipRefresh)) {
			this._allowRefresh = false;
			rm.ajax.projectSvcAsyncPost("RefreshBudgetData", { projectId: this.getProjectId() }, function (response) {
				rm.budget.isRefreshRunning = true;
				$("#budgetSpinner").show();
				rm.ui.ribbon.refresh();
				setTimeout(function () { rm.budget.isBudgetRefreshRunning(); }, 30000);
			});
		}
	},
	isRefreshEnabled: function () { return (!this.isRefreshRunning && this.getProjectId() > 0 && this.allowBudgetRefresh(false)); },
	isBudgetRefreshRunning: function () {
		var projectId = this.getProjectId();
		if (projectId > 0) {
			rm.ajax.projectSvcAsyncPost("IsBudgetRefreshRunning", { projectId: projectId }, function (response) {
				if (response.IsRunning) { $("#budgetSpinner").show(); }
				else {
					$("#budgetSpinner").hide();
					if (rm.budget.isRefreshRunning) {
						$(document).trigger(rm.events.onBudgetRefreshComplete, [response.LatestQipVersion]);
						alert(Resources.QipRefreshComplete);
						rm.budget.showTooltipOnRefreshButton(response.DenialReason);
					}
				}
				rm.budget.isRefreshRunning = response.IsRunning;
				//if (response.IsRunning || !response.RefreshedToday) { setTimeout(function () { rm.budget.isBudgetRefreshRunning(); }, 30000); }
				if (response.IsRunning) { setTimeout(function () { rm.budget.isBudgetRefreshRunning(); }, 30000); }
			}, null, { global: false });
		}
	},
	allowBudgetRefresh: function (showReason) {
		if (this._allowRefresh == null) {
			var projectId = this.getProjectId();
			var isProposalProject = this.isProposalProject();
			if (projectId > 0 && !isProposalProject) {
				rm.ajax.projectSvcSyncPost("AllowBudgetRefresh", { projectId: projectId }, function (response) {
					rm.budget._allowRefresh = response.AllowBudgetRefresh;
					if (!response.AllowBudgetRefresh && response.ShowReasonToUser && showReason) { alert(response.DenialReason); }
					if (!response.AllowBudgetRefresh && response.ShowReasonToUser != "") { rm.budget.showTooltipOnRefreshButton(response.DenialReason); }
				});
			}
		}
		return this._allowRefresh;
	},
	showTooltipOnRefreshButton: function (message) {
		var budgetRefreshButton = $("[id*=RefreshBudgetDataButton]");
		if (budgetRefreshButton.length > 0) {
			var position = budgetRefreshButton.offset();
			var spinnerTop = position.top;
			var spinnerLeft = position.left;
			var html = "<img id='qipSpacer' src='/_layouts/spui/images/spacer.gif' width='80' height='80' style='z-index:10;position:fixed;top:" + spinnerTop + "px;left:" + spinnerLeft + "px;' alt='" + message + "' />";
			$(budgetRefreshButton).append(html);
			setTimeout(function () { rm.qtip.showInfo("#qipSpacer", message) }, 10);
		}
	},
	addHiddenRefreshSpinner: function () {
		rm.ui.ribbon.addHiddenWaitSpinner("[id*=RefreshBudgetDataButton]", "budgetSpinner");
	}
};

rm.formStatus = {
	//Sample object format
	//var jsonSelectorObject = { items : [{selector:"#ctelId input:text", dirtyAlertMessage : "Un-saved changes found."}] };
	bindDirty: function (alertMessage, jsonSelectorObject) {
		rm.formStatus.clearDirty(jsonSelectorObject);

		window.onbeforeunload = function () {
			if (rm.formStatus.isDirty(jsonSelectorObject)) {
				return (alertMessage);
			}
		};
	},

	//Sample object format
	//var jsonSelectorObject = { items : [{selector:"#ctelId input:text", dirtyAlertMessage : "Un-saved changes found."}] };
	isDirty: function (jsonSelectorObject) {
		var isFormDirty = false;
		$.each(jsonSelectorObject.items, function (index, value) {
			inputs = $(value.selector);
			$.each(inputs, function (key, input) {
				var type = $(input).attr("type");
				var tagName = $(input).prop("tagName").toLowerCase();

				if (type == "radio" || type == "checkbox") {
					if ($(input).data("initial") != $(input).is(":checked")) {
						isFormDirty = true;
						return false;
					}
				} else if (tagName == "a") {
					if ($(input).data("initial") != $(input).text()) {
						isFormDirty = true;
						return false;
					}
				}
				else if ($(input).data("initial") !== $(input).val()) {
					isFormDirty = true;
					return false;
				}
			});

			if (isFormDirty) {
				//rm.ui.messages.showSuccess(value.dirtyAlertMessage);
				return false;
			}
		});
		return isFormDirty;
	},

	clearDirty: function (jsonSelectorObject) {
		$.each(jsonSelectorObject.items, function (index, value) {
			var inputs = $(value.selector);
			$.each(inputs, function (key, input) {
				var type = $(input).attr("type");
				var tagName = $(input).prop("tagName").toLowerCase();

				if (type == "radio" || type == "checkbox") {
					$(input).data("initial", $(input).is(":checked"))
				}
				else if (tagName == "a") {
					$(input).data("initial", $(input).text())
				}
				else {
					$(input).data("initial", $(input).val());
				}
			});
		});
	},
	resetForm: function (jsonSelectorObject) {
		$.each(jsonSelectorObject.items, function (index, value) {
			var inputs = $(value.selector);
			$.each(inputs, function (key, input) {
				var type = $(input).attr("type");
				var tagName = $(input).prop("tagName").toLowerCase();

				if (type == "radio" || type == "checkbox") {
					$(input).prop("checked", $(input).data("initial"));
				}
				else if (tagName == "a") {
					$(input).text($(input).data("initial"));
				}
				else {
					$(input).val($(input).data("initial"));
				}
			});
		});
	}
};

rm.bizRules = {
	getNeedByDate: function (startDate, resourceTransitionTimeInDays) {
		var needByDate = rm.date.addDays(rm.date.getDateFromQDateString(startDate), resourceTransitionTimeInDays);
		if (rm.date.isDateInPast(needByDate)) { needByDate = rm.date.today(); }
		return rm.date.getQDateStringFromDate(needByDate);
	},
	getRegionListByResourceTypeId: function (resourceTypeId) {
		var regionList = [];
		var response = rm.serviceCalls.getRegionsByResourceTypId(resourceTypeId);

		if (response != null && Array.isArray(response)) {
			response.forEach(function (region) {
				regionList.push({
					Value: region.Name,
					Key: region.Id
				})
			});
		}

		return regionList;
	},
	getCountryListByResourceTypeId: function (resourceTypeId, projectId, regionId) {
		var countryList = [];
		var response = rm.serviceCalls.getCountriesByResourceTypId(resourceTypeId, projectId, regionId);

		if (response != null && Array.isArray(response)) {
			response.forEach(function (country) {
				countryList.push({
					Value: country.Name,
					Key: country.Id
				})
			});
		}

		return countryList;
	},
};
rm.uiComponents = {
	showProjectDetails: function (projectId) {
		$("#divDialogProject").load("../Profile/ProjectDetailsDialog.aspx?projectId=" + projectId + "").dialog({
			autoOpen: false,
			modal: true,
			width: 1200,
			title: "Project Summary",
			height: 500,
			open: function (event, ui) {
				//hide close button.
				$(this).parent().children().children('.ui-dialog-titlebar-close').hide();
			},
			buttons: {
				"Close": function () {
					$(this).dialog("close");
				}
			}
		});
		$("#divDialogProject").dialog('open');
	},
};

$(document).ready(rm.eventManager.onGlobalDocumentReady);
