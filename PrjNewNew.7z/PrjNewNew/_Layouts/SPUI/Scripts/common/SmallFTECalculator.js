﻿/// <reference path="rmhelper.js" />
var smallCalculator = {
	isInMultiEditMode: function () { return $.SmallFTECalculator.multiEditMode; },
	isSingleRequestEditValid: function () {
		var isValid = true;

		if ($($.SmallFTECalculator.resourceTypeSelector).val() != -1 &&
			$($.SmallFTECalculator.countrySelector).val() != -1 &&
			$.trim($($.SmallFTECalculator.startDateSelector).val()) != "" &&
			$.trim($($.SmallFTECalculator.stopDateSelector).val()) != "" &&
			$.trim($($.SmallFTECalculator.fteSelector).val()) != ""
		   ) {
			if (rm.date.isValidDate($($.SmallFTECalculator.startDateSelector).val(), false) && rm.date.isValidDate($($.SmallFTECalculator.stopDateSelector).val(), false)) {
				var startDate = rm.date.getDateFromQDateString($($.SmallFTECalculator.startDateSelector).val());
				var stopDate = rm.date.getDateFromQDateString($($.SmallFTECalculator.stopDateSelector).val());

				if (startDate > stopDate) {
					rm.validation.addError($.SmallFTECalculator.startDateSelector, Resources.StartDateGreaterThanStopDate);
					rm.validation.addError($.SmallFTECalculator.stopDateSelector, Resources.StopDateLessThanStartDate);
					isValid = false;
				}
				else if (!$.q.rangeValidate($($.SmallFTECalculator.fteSelector))) {
					$("#small_Calc_SpanTotalHours").empty();
					$.SmallFTECalculator._totalHours = "";
					isValid = false;
				}
				else {
					$.q.formatText($("#small_Calc_TxtFTE").get(0));
					$.SmallFTECalculator._totalHours = $("#small_Calc_SpanTotalHours").html();
				}
			}
			else { isValid = false; }
		}
		else { isValid = false; }

		return isValid;
	},
	isMultipleRequestEditValid: function () {
		var isValid = true;

		if (!$.q.rangeValidate($($.SmallFTECalculator.fteSelector))) {
			$("#small_Calc_SpanTotalHours").empty();
			$.SmallFTECalculator._totalHours = "";
			isValid = false;
		}
		else {
			$.q.formatText($("#small_Calc_TxtFTE").get(0));
			$.SmallFTECalculator._totalHours = $("#small_Calc_SpanTotalHours").html();
		}

		return isValid;
	},
	getCountryIdForFteCalculation: function () { alert("Caller must override function smallCalculator.getCountryIdForFteCalculation()"); },
	getJobRoleIdForFteCalculation: function () { alert("Caller must override function smallCalculator.getJobRoleIdForFteCalculation()"); },

}

$.SmallFTECalculator = {
	_resourceTypeId: -1,
	_countryId: -1,
	_startDate: "",
	_stopDate: "",
	_FTE: 0,
	_totalHours: 0,
	_interimFrequencyEnabled: false,
	_calculateDuration: false,
	_requestId: null,
	resourceTypeSelector: "#ddlResourceType",
	countrySelector: "#ddlCountry",
	startDateSelector: "#txtStartDate",
	stopDateSelector: "#txtStopDate",
	fteSelector: "#small_Calc_TxtFTE",
	multiEditMode: false,

	isInterimFrequencyButtonEnabled: function () {
		return $.SmallFTECalculator._interimFrequencyEnabled;
	},

	ShowPreviousPhaseValues: function () {
		var postData = { requestId: $.SmallFTECalculator._requestId };

		if (postData.requestId != "") {
			$.rm.Ajax_Calculator("GetPreviousFlatFteCalculatorValues", postData, function (data) {
				$("[id$=SmallFTECalculator_old_fte]").html(data.Fte);
				$("[id$=SmallFTECalculator_old_hours]").html(data.Hours);
				$(".oldValue").removeClass("hideMe");
			}, false, false);
		}
	},

	renderCalculator: function (requestId, projectId, resourceId, countryId, calculatorTitle) // AI: do not remove this parameter, it may be in used in next stories.
	{
		$.SmallFTECalculator._requestId = requestId;
		$("#smallCalculatorTitle").html(calculatorTitle);
		if (requestId != "" && requestId != null) {
			setTimeout(function () { $("#btnPreviousValuesSmallFte").removeClass("hideMe"); }, 5);
		}
		$(".oldValue").addClass("hideMe");

		if (smallCalculator.isInMultiEditMode()) {
			$($.SmallFTECalculator.fteSelector).attr("allowBlank", "true");
		}
		else {
			$("#trSmallCaclTotalHours").removeClass("hideMe");
		}
	},
	save: function () {
		return $.SmallFTECalculator.IsValid();
	},

	ClearCalculatorDirty: function () { $("#isDirtyCalculator").val('False'); },

	IsValid: function () {
		return smallCalculator.isInMultiEditMode() ? smallCalculator.isMultipleRequestEditValid() : smallCalculator.isSingleRequestEditValid();
	},

	CalculateTotalHours: function () {
		if ($.SmallFTECalculator.IsValid()) {
			$("#isDirtyCalculator").val('True');

			var postData =
			{
				resourceTypeId: $($.SmallFTECalculator.resourceTypeSelector).val(),
				//countryId: $($.SmallFTECalculator.countrySelector).val(),
				startDate: $($.SmallFTECalculator.startDateSelector).val(),
				stopDate: $($.SmallFTECalculator.stopDateSelector).val(),
				FTE: $($.SmallFTECalculator.fteSelector).val(),
				countryId: smallCalculator.getCountryIdForFteCalculation(),
				jobRoleId: smallCalculator.getJobRoleIdForFteCalculation()
			};
			$.rm.Ajax_Utility("CalculateTotalHours", postData, function (data) {
				$("#small_Calc_SpanTotalHours").html(data);
				$.SmallFTECalculator._totalHours = data;
			}, true, false);

		}
	},

	ClearCalculator: function () {
		$("#small_Calc_TxtFTE").val("");
		$("#small_Calc_SpanTotalHours").empty();
		rm.validation.clearError($("#small_Calc_TxtFTE"));
	},

	SetCalculatorValues: function (FTE, totalHours) {
		$("#small_Calc_TxtFTE").val(FTE);
		$("#small_Calc_SpanTotalHours").html(totalHours);
	},

	GetValues: function () {
		return (
		{
			FTE: $.trim($("#small_Calc_TxtFTE").val()) != "" ? $("#small_Calc_TxtFTE").val() : (smallCalculator.isInMultiEditMode() ? null : "0"),
			TotalHours: $("#small_Calc_SpanTotalHours").html() != "" ? $("#small_Calc_SpanTotalHours").html() : (smallCalculator.isInMultiEditMode() ? null : "0")
		});
	}
};

$(document).delegate("#small_Calc_TxtFTE", 'change', function () {
	$("#isDirtyCalculator").val('True');
	$.q.formatText(this);
	if (!smallCalculator.isInMultiEditMode()) {
		$.SmallFTECalculator.CalculateTotalHours();
	}
});