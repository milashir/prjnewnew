﻿/// <reference path="rmhelper.js" />
var qipOtherCalculator = {
	multiEditMode: false,
	resourceTypeId: -1,
	isRegionBasedCalculator: false,
	isGlobalCalculator: false,
	regionId: -1,
	countryId: -1,
	organizationId: -1,
	getOrganizationIdFromUi: function () { alert("Caller must override function qipOtherCalculator.getOrganizationIdFromUi()"); },
	getRegionIdFromUi: function () { alert("Caller must override function qipOtherCalculator.getRegionIdFromUi()"); },
	getCountryIdFromUi: function () { alert("Caller must override function qipOtherCalculator.getCountryIdFromUi()"); },
	getRequestStopDateFromUi: function () { alert("Caller must override function qipOtherCalculator.getRequestStopDateFromUi()"); },
	getCountryIdForFteCalculation: function () { alert("Caller must override function qipOtherCalculator.getCountryIdForFteCalculation()"); },
	getJobRoleIdForFteCalculation: function () { alert("Caller must override function qipOtherCalculator.getJobRoleIdForFteCalculation()"); },
	isProposalReqeustOrProjectSelected: function () { return false; },
	staticRowSelector: "#staticRow",
	bindChangeEvents: function () {
		if (qipOtherCalculator.multiEditMode) {
			$(".clsWeeklyhours").bind("keydown paste", function (e) {
				//manual change detected on keys 0 to 9 period, backspace and delete
				if (!$.q.isNonPrintableKey(e.keyCode)) {
					var element = $(e.currentTarget).closest("tr").find(".clsFTE").val("");
					rm.validation.clearError(element);
					$.Calculator.reconnect(e.currentTarget, false);
				}
			});

			$(".clsFTE").bind("keydown  paste", function (e) {
				if (!$.q.isNonPrintableKey(e.keyCode)) {
					var element = $(e.currentTarget).closest("tr").find(".clsWeeklyhours").val("");
					rm.validation.clearError(element);
					$.Calculator.reconnect(e.currentTarget, false);
				}
			});

		}
	},
	connectClick: function () { },
	isCountryOrRegionChanged: function () {
		var valueChanged = false;
		if (qipOtherCalculator.isRegionBasedCalculator) {
			valueChanged = qipOtherCalculator.getRegionIdFromUi() != qipOtherCalculator.regionId;
		}
		else {
			valueChanged = qipOtherCalculator.getCountryIdFromUi() != qipOtherCalculator.countryId;
		}
		return valueChanged;
	},
	isCurrentAdhocDateBeyondRequestStopDate: function () {
		var areDatesBeyondRequestStop = false;
		var requestStopQDateString = qipOtherCalculator.getRequestStopDateFromUi();

		if (rm.date.isValidDate(requestStopQDateString, false)) {
			var requestStopDate = rm.date.getDateFromQDateString(requestStopQDateString);

			var stopDate = rm.date.getDateFromQDateString($("#d_endDate").val());
			if (stopDate > requestStopDate) {
				areDatesBeyondRequestStop = true;
				rm.validation.addError($("#d_endDate"), Resources.RequestStopDateBeforeAdhocStop.replace("{0}", requestStopQDateString));
			}
		}
		return areDatesBeyondRequestStop;
	},
	areAdhocDatesBeyondRequestStopDate: function () {
		var areDatesBeyondRequestStop = false;
		var adhockTableRows = $("#AdHocRow tr");

		if (adhockTableRows.length > 0) {
			var requestStopQDateString = qipOtherCalculator.getRequestStopDateFromUi();

			if (rm.date.isValidDate(requestStopQDateString, false)) {
				var requestStopDate = rm.date.getDateFromQDateString(requestStopQDateString);

				$.each(adhockTableRows, function (index, ele) {
					var tableRow = $(ele);
					var currentAdhocStopDate = rm.date.getDateFromQDateString(tableRow.find("[id^=lblEndDate] a").html());
					if (currentAdhocStopDate > requestStopDate) {
						rm.validation.addError(tableRow.find("[id^=lblEndDate] a"), Resources.RequestStopDateBeforeAdhocStop.replace("{0}", requestStopQDateString));
						areDatesBeyondRequestStop = true;
					}
					else {
						rm.validation.clearError(tableRow.find('[id^=lblEndDate]'));
						rm.validation.clearError(tableRow.find('[id^=lblEndDate] a'));
					}
				});
			}
		}
		return areDatesBeyondRequestStop;
	},
	clearAdhocStopDateError: function () {
		var adhockTableRows = $("#AdHocRow tr");
		$.each(adhockTableRows, function (index, ele) {
			rm.validation.clearError($(ele).find('[id^=lblEndDate] a'));
		});
	},
	jsonSelectorForDirtyForm: function () { return { items: [{ selector: "#QIP_Calculator input:text:not([readonly]),#QIP_Calculator select:visible,#QIP_Calculator textarea:visible,#QIP_Calculator input:radio:visible", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },
	bindDirtyForCalculator: function () {
		$.formStatus.clearDirty(qipOtherCalculator.jsonSelectorForDirtyForm());
	},
	getPhaseValues: function () {
		var phaseValues = [];

		$.each($(qipOtherCalculator.staticRowSelector).find("tr"), function (index, ele) {
			weeklyHours = $(ele).find('[id^=txtWeeklyHours]').val();
			fte = $(ele).find('[id^=txtFTE]').val();
			calculatorId = $(ele).find("[id^=hdnRequestCalculatorId]").val();

			phaseValues.push({
				FTETypeFTEMilestoneTypeId: $(ele).find('[id^=hdnStaticId]').val(),
				FTE: fte == "" ? null : fte,
				WeeklyHours: weeklyHours == "" ? null : weeklyHours,
				Status: $(ele).find('[id^=imgStatic]').attr('connectStatus'),
			});
		});

		return phaseValues;
	},
};

$.Calculator = {
	isRequestHardOrSoftBooked: false,
	DialogOkClickHandler: function () { alert("You must assign function to $.Calculator.DialogOkClickHandler to callback final submit method."); },
	OnAdhocRowRemoveHandler: function () { },
	OnCalculatorRenderComplete: function (regionId, countryId) { },
	InterimFrequencyOkClickHandler: function (startDate, stopDate) { },
	OnConnectImageClick: function () { },
	OnDeleteAdhocClick: function () { },
	OnCalculatorEdit: function () { },
	AfterCalculatorDraw: function () { },
	getNullIfEmpty: function (value) { return value == "" ? null : value; },
	getJobGrade: function () { return $.Calculator.getNullIfEmpty($(".FTE_Calculator #fteJobGrade").val()); },
	getJobGradeInfoString: function () { return $.Calculator.getNullIfEmpty($(".FTE_Calculator #fteJobGradeInfoString").val()); },
	//AllowDeletingAdhocRowsWithStartDateInPast: false,
	AllowEditing: true,
	StartDateSelector: "#txtStartDate",
	StopDateSelector: "#txtStopDate",
	_countryId: -1,
	_resourceId: -1,
	_PageManager: "",
	_PageManagerID: -1,
	_newRowID: 0,
	_staticValues: "",
	_adHocValues: "",
	_staticTimestampValues: "",
	_adHocTimestampValues: "",
	_interimFrequencyEnabled: false,
	_fireChangeEvent: true,
	_deletedList: new Array(),
	_deletedOldAdhocList: new Array(),
	_editAdhocId: "",
	_requestid: null,
	isInterimFrequencyButtonEnabled: function () {
		var isProposalProjectSelected = qipOtherCalculator.isProposalReqeustOrProjectSelected();
		return $.Calculator._interimFrequencyEnabled && (!isProposalProjectSelected || (isProposalProjectSelected && (LoggedInUser.IsResourcingCenterAdmin || LoggedInUser.IsAdmin || LoggedInUser.IsDemandPlanner || LoggedInUser.IsSupport)));
	},

	InterimFrequency: function () {
		$.Calculator.OpenAddAdHocDialog("New");
	},


	ShowPreviousPhaseValues: function () {
		var postData = { requestId: $.Calculator._requestId };

		if (postData.requestId != "") {
			$.rm.Ajax_Calculator("GetPreviousPhaseCalculatorValues", postData, function (data) {
				$.each(data.staticInitiateCalculatorList, function (index, element) {
					$("#old_static_txtWeeklyHours_" + element.FTETypeFTEMilestoneTypeId).html(element.WeeklyHours);
					$("#old_static_txtFTE_" + element.FTETypeFTEMilestoneTypeId).html(element.FTE);
				});

				$.each(data.adhocInitiateCalculatorList, function (index, element) {
					$("#old_adhoc_txtWeeklyHours_" + element.Id).html(element.WeeklyHours);
					$("#old_adhoc_txtFTE_" + element.Id).html(element.FTE);
				});

				$(".oldValue").removeClass("hideMe");
			}, false, false);
		}
	},

	EditInterimFrequency: function (obj) {
		$.Calculator.OpenAddAdHocDialog(obj);
	},

	OpenAddAdHocDialog: function (obj) {
		var startDate = "";
		var endDate = "";
		var comments = "";
		var edit = false;
		if (obj != "New") {
			startDate = $(obj.parentNode.parentNode.parentNode).find('[id^=lblStartDate]').find("a").html();
			endDate = $(obj.parentNode.parentNode.parentNode).find('[id^=lblEndDate]').find("a").html();
			comments = unescape($(obj.parentNode.parentNode.parentNode).find('[id^=hdnExplanation]').val()); //.replace(/'/g, "&#39;");
			edit = true;
			$.Calculator._editAdhocId = "#" + $(obj.parentNode).attr("id");
		}

		var d = "<div id='fteCalculator' class='monitoringCalculatorPaddings'>" +
                "<form id='frmDialog'>" +
                "<table class='styleWidthNinety'>" +
                "<tr><td>Start Date <span class='styleColorRed'>*</span></td><td><input type = 'text' id='d_startDate' value='" + startDate + "' originalValue='" + startDate + "' /></td></tr>" +
                "<tr><td>Stop Date <span class='styleColorRed'>*</span></td><td><input type = 'text' id='d_endDate' value='" + endDate + "' /></td></tr>" +
                "<tr><td>Explanation <span class='styleColorRed'>*</span></td><td class='monitoringCalculatorAdHocExplanationHeight'><input type='text' id='c_comments' value='" + comments + "' /></td></tr>" +
                "</table></form></div>";

		$("#divDialog").html(d);

		setTimeout(function () {
			$("#d_startDate").qDatepicker().change(function () {
				if (rm.date.isValidDate($("#d_endDate").val(), false)) {
					rm.validation.clearError($("#d_endDate"));
				}
			});

			$("#d_endDate").qDatepicker().change(function () {
				if (rm.date.isValidDate($("#d_startDate").val(), false)) {
					rm.validation.clearError($("#d_startDate"));
				}
			});

			$("#c_comments").change(function () {
				if ($.trim($("#c_comments").val()).length > 0) {
					rm.validation.clearError($("#c_comments"));
				}
			});

			$("#d_startDate").val(startDate);
			$("#d_endDate").val(endDate);
			$("#c_comments").val(comments);
		}, 10);

		var btnArray = [{ text: "OK", click: function () { $.Calculator.onAdhocDialogOkClick.apply(this, [edit]); } }, rm.ui.dialog.standardButtons.cancel];
		rm.ui.dialog.showModalWithButtons($("#divDialog"), "Add Ad-hoc Interim Frequency", "", false, 370, 220, btnArray);
	},

	onDialogClose: function (dialogResult, returnValue) { $("#ui-datepicker-div").attr("style", "display:none"); },

	onAdhocDialogOkClick: function (isEdit) {
		var isDatevalid = $.Calculator.isvalidDate($("#d_startDate").val(), $("#d_endDate").val());
		var isCommentValid = $.Calculator.validatecomments($("#c_comments").val());
		if (isDatevalid && isCommentValid) {
			if ($("#d_startDate").attr("originalValue") != $("#d_startDate").val() && rm.date.isQDateDateInPast($("#d_startDate").val())) {
				rm.validation.addError("#d_startDate", Resources.StartDateInPast);
				return false;
			}
			else if (rm.date.isQDateDateInPast($("#d_endDate").val())) {
				rm.validation.addError("#d_endDate", Resources.StopDateInPast);
				return false;
			}
			else if ($.Calculator.AreDatesOverlapping()) {
				alert(Resources.OverlapingAdhocFrequencyDates);
				return false;
			}
			else if (qipOtherCalculator.isCurrentAdhocDateBeyondRequestStopDate()) {
				return false;
			}
			else {
				if (isEdit) { $.Calculator.UpdateAdHoc(); }
				else { $.Calculator.AddNewAdHoc(); }

				//Call the ok click handler and reset it back to empty function. This is added so that we can call back a function when user is changing the start/stop date of initiate request.
				$.Calculator.InterimFrequencyOkClickHandler($("#d_startDate").val(), $("#d_endDate").val());

				$("#d_startDate").val("");
				$("#d_endDate").val("");
				$("#c_comments").val("");
				$.Calculator._editAdhocId = "";
				setTimeout(function () { $.Calculator.OnCalculatorEdit(); rm.ui.ribbon.refresh(); }, 10);
				$(this).dialog("close");
			}
		}
		else { return false; }

	},
	AreDatesOverlapping: function () {
		var datesOverlap = false;
		var startDate = rm.date.getDateFromQDateString($("#d_startDate").val());
		var stopDate = rm.date.getDateFromQDateString($("#d_endDate").val());
		var adhockTableRows = $("#AdHocRow tr");
		$.each(adhockTableRows, function (index, ele) {
			var tableRow = $(ele);
			var startDateLblId = "#" + tableRow.find("[id^=lblStartDate]").attr("id");
			var stopDateLblId = "#" + tableRow.find("[id^=lblEndDate]").attr("id");
			var existingStartDate = rm.date.getDateFromQDateString(tableRow.find("[id^=lblStartDate] a").html());
			var existingStopDate = rm.date.getDateFromQDateString(tableRow.find("[id^=lblEndDate] a").html());

			if ($.Calculator._editAdhocId != startDateLblId
					&& $.Calculator._editAdhocId != stopDateLblId
					&& (
						   (existingStartDate <= startDate && existingStopDate >= startDate)
						|| (existingStartDate <= stopDate && existingStopDate >= stopDate)
						|| (startDate <= existingStartDate && stopDate >= existingStartDate)
						|| (startDate <= existingStopDate && stopDate >= existingStopDate)
					  )
				 ) {
				datesOverlap = true;
				return false;
			}
		});

		return datesOverlap;
	},

	UpdateAdHoc: function () {

		rm.validation.clearError($($($.Calculator._editAdhocId)[0].parentNode.parentNode).find('[id^=lblEndDate] a'));
		rm.validation.clearError($($($.Calculator._editAdhocId)[0].parentNode.parentNode).find('[id^=lblEndDate]'));
		$($($.Calculator._editAdhocId)[0].parentNode.parentNode).find('[id^=lblStartDate]').find("a").html($("#d_startDate").val());
		$($($.Calculator._editAdhocId)[0].parentNode.parentNode).find('[id^=lblEndDate]').find("a").html($("#d_endDate").val());
		$($($.Calculator._editAdhocId)[0].parentNode.parentNode).find('[id^=hdnExplanation]').val($("#c_comments").val());
		$("#isDirtyCalculator").val('True')
		$.Calculator_editAdhocId = "";
	},

	AddNewAdHoc: function () {
		$.Calculator._newRowID++;

		var addAdhocRow = "<tr style='line-height:24px;'>" +
            "<td style='visibility:hidden; width:1%'>" +
            "     <input type='hidden' id='hdnExplanation_" + $.Calculator._newRowID + "' value='" + escape($("#c_comments").val()) + "'/>" +
            "</td>" +
            " <td style='width: 6%; text-align:left;'>" +
            "     <img id='imgDelete_New" + $.Calculator._newRowID + "' adHockRowId='New" + $.Calculator._newRowID + "' src='/_layouts/SPUI/images/closeSmall.png' style= 'margin: 2px 0 0 10px;' alt='' class='imgDeleteAdHoc' originalStartDate='" + $("#d_startDate").val() + "' />" +
            "</td>" +
            "<td style='width: 11%;'>" +
            "    <span id = 'lblStartDate_New_" + $.Calculator._newRowID + "'><a class='adhocDate' style='text-decoration: underline;' href='JavaScript://' onClick='$.Calculator.EditInterimFrequency(this); return false;'>" + $("#d_startDate").val() + "</a></span>" +
            "</td>" +
            "<td style='width: 18%;'>" +
            "    <span id = 'lblEndDate_New_" + $.Calculator._newRowID + "'><a class='adhocDate' style='text-decoration: underline;' href='JavaScript://' onClick='$.Calculator.EditInterimFrequency(this); return false;'>" + $("#d_endDate").val() + "</a></span>" +
            "</td>" +
            "<td style='text-align:center; width: 11%;'>" +
            "    <input type='text' id='txtWeeklyHours_New_" + $.Calculator._newRowID + "' value='' class='clsWeeklyhoursAdHoc validateRange' from='0' to='9999.99' formating='4,2' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px; padding-left: 2px;' />" +
            "</td>" +
            "<td style='text-align:center; width: 11%;'>" +
            "    <input type='text' id='txtFTE_New_" + $.Calculator._newRowID + "' value='' class='clsFTEAdHoc validateRange' from='0' to='999.999' formating='3,3' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px; padding-left: 2px;' />" +
            "</td>" +
            "</tr>";

		$("#AdHocRow").append(addAdhocRow);
		$("#isDirtyCalculator").val('True');
	},

	ClearCalculatorDirty: function () { $("#isDirtyCalculator").val('False'); },

	ClearCalculator: function () {
		$("#staticRow").empty();
		$("#AdHocRow").empty();
		$(".FTE_Calculator #fteJobGrade").val("");
		$(".FTE_Calculator #fteJobGradeInfoString").val("");
	},

	DeleteAdHocRow: function (obj) {
		var adhocRow = $(obj).parent().parent();
		var isNewAdhocRow = ($(obj).attr("adHockRowId").indexOf('New') != -1);

		if (!isNewAdhocRow) {
			$.Calculator._deletedList.push({ FTETAdHocId: $(obj).attr("adHockRowId") });
			$("#isDirtyCalculator").val('True');
			rm.ui.ribbon.delayedRefresh();
		}

		adhocRow.remove();
		$.Calculator.OnAdhocRowRemoveHandler();
	},

	DeleteAllAdHocRow: function () {
		$.each($("#AdHocRow").find("tr"), function (index, ele) {
			if ($(ele).find('[id^=imgDelete]').attr('adHockRowId').indexOf('New') == -1) {
				$.Calculator._deletedOldAdhocList.push({
					FTETAdHocId: $(ele).find('[id^=imgDelete]').attr('adHockRowId')
				});
			}
		});
	},

	getInputAttributesForWeeklyHours: function (isProposalReqeustOrProjectSelected, isConnected, allowQipConnection) {
		return ($.Calculator.AllowEditing && allowQipConnection) ? "class='clsWeeklyhours validateRange'" : " readonly='readonly' class='clsWeeklyhours validateRange grayed' ";
	},

	getInputAttributesForFte: function (isProposalReqeustOrProjectSelected, isConnected, allowQipConnection) {
		return ($.Calculator.AllowEditing && allowQipConnection) ? " class='clsFTE validateRange' " : " readonly='readonly' class='clsFTE validateRange grayed' ";
	},

	getAdhocFrequencyDateLink: function (displayValue, allowEdit) {
		if (allowEdit) {
			return $.Calculator.AllowEditing ? "<a class='adhocDate' style='text-decoration: underline;' href='JavaScript://' onClick='$.Calculator.EditInterimFrequency(this); return false;'>" + displayValue + "</a>" : displayValue;
		}
		else {
			return $.Calculator.AllowEditing ? "<a class='adhocDate' style='text-decoration: underline;' href='JavaScript://' onClick='alert(Resources.AdhocEditDisabled); return false;'>" + displayValue + "</a>" : displayValue;
		}
	},

	UpdatedRegionalConnedtedValues: function (requestId, projectId, resourceId, regionId) {
		var url = rm.ajax.requestSvcUrl + "RenderRegionBasedInitiateCalculator?projectId=" + projectId + "&resourceId=" + resourceId + "&regionId=" + regionId + "&requestStartDate=" + $($.Calculator.StartDateSelector).val() + "&requestStopDate=" + $($.Calculator.StopDateSelector).val(); // New Request.
		//TODO:Figure out way to update connected values
		$.ajax({
			url: url,
			cache: false,
			success: function (data) {
				$(".FTE_Calculator #fteJobGrade").val(data.JobGrade);
				$(".FTE_Calculator #fteJobGradeInfoString").val(data.JobGradeInfoStr);
				if (data.staticInitiateCalculatorList) {
					var styleConfig = { width: '250px' };
					var stylePosition = { my: 'bottom center', at: 'top center' };
					$.each($("#staticRow tr"), function (index, staticRow) {

						if (data.staticInitiateCalculatorList.length > index) {
							var staticRowObj = $(staticRow);
							var stageData = data.staticInitiateCalculatorList[index];
							var newId = stageData.FTETypeFTEMilestoneTypeId;
							//update the control ids

							staticRowObj.find("[id^=txtWeeklyHours_]").prop("id", "txtWeeklyHours_" + newId).attr("qipValue", stageData.QipWeeklyHours);
							staticRowObj.find("[id^=txtFTE_]").prop("id", "txtFTE_" + newId).attr("qipValue", stageData.QipFTE);
							staticRowObj.find("[id^=hdnCountryCalculatorId_]").prop("id", "hdnCountryCalculatorId_" + newId).val(stageData.CountryCalculatorId);
							staticRowObj.find("[id^=lblMilestones_]").prop("id", "lblMilestones_" + newId).text(stageData.Milestones);
							staticRowObj.find("[id^=hdnCountryTimestamp_]").prop("id", "hdnCountryTimestamp_" + newId).val(stageData.CountryTimestamp);


							staticRowObj.find("[id^=hdnStaticId_]").prop("id", "hdnStaticId_" + newId);
							staticRowObj.find("[id^=hdnStaticIdNew_]").prop("id", "hdnStaticIdNew_" + newId);
							staticRowObj.find("[id^=hdnRequestCalculatorId_]").prop("id", "hdnRequestCalculatorId_" + newId);
							staticRowObj.find("[id^=hdnRequestCalculatorTimestamp_]").prop("id", "hdnRequestCalculatorTimestamp_" + newId);
							staticRowObj.find("[id^=hdnFTETypeId_]").prop("id", "hdnFTETypeId_" + newId);
							staticRowObj.find("[id^=lblPhase_]").prop("id", "lblPhase_" + newId);
							staticRowObj.find("[id^=old_static_txtWeeklyHours_]").prop("id", "old_static_txtWeeklyHours_" + newId);
							staticRowObj.find("[id^=old_static_txtFTE_]").prop("id", "old_static_txtFTE_" + newId);

							var milestoneInfo = "<b>Start Date: </b>" + stageData.StartDate +
										"<br /><b>Start Date Source: </b>" + stageData.StartDateSource +
										"<br /><b>Stop Date: </b>" + stageData.StopDate +
										"<br /><b>Stop Date Source: </b>" + stageData.StopDateSource;
							rm.qtip.showInfo("#spnMileStoneDates_" + stageData.FTETypeFTEMilestoneTypeId + "", milestoneInfo, {}, {}, stylePosition, styleConfig, {});
						}
						else {
							alert("Stage count does not match");
						}
					});
				}
			},
			error: function () { rm.ui.messages.addError(Resources.FailedToGetQipData); }
		});
	},

	UpdatedConnedtedValues: function (requestId, projectId, resourceId, countryId) {
		var requestIdParm = (requestId == null ? "" : "&requestId=" + requestId);
		var url = rm.ajax.requestSvcUrl + "RenderInitiateCalculator?projectId=" + projectId + "&resourceId=" + resourceId + "&countryId=" + countryId + requestIdParm; // New Request.
		var styleConfig = { width: '250px' };
		var stylePosition = { my: 'bottom center', at: 'top center' };

		$.ajax({
			url: url,
			cache: false,
			success: function (data) {
				$(".FTE_Calculator #fteJobGrade").val(data.JobGrade);
				$(".FTE_Calculator #fteJobGradeInfoString").val(data.JobGradeInfoStr);
				if (data.staticInitiateCalculatorList) {
					for (var i = 0; i < data.staticInitiateCalculatorList.length; i++) {
						var currentPhase = data.staticInitiateCalculatorList[i];
						$("#txtWeeklyHours_" + currentPhase.FTETypeFTEMilestoneTypeId).attr("qipValue", currentPhase.QipWeeklyHours);
						$("#txtFTE_" + currentPhase.FTETypeFTEMilestoneTypeId).attr("qipValue", currentPhase.QipFTE);

						$("#hdnRequestCalculatorTimestamp_" + currentPhase.FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].RequestCalculatorTimestamp);
						$("#hdnRequestCalculatorId_" + currentPhase.FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].RequestCalculatorId);
						$("#hdnCountryTimestamp_" + currentPhase.FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].CountryTimestamp);
						$("#hdnCountryCalculatorId_" + currentPhase.FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].CountryCalculatorId);
						$("#hdnFTETypeId_" + currentPhase.FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].FteTypeId);

						if (!qipOtherCalculator.multiEditMode) {
							var milestoneInfo = "<b>Start Date: </b>" + currentPhase.StartDate +
																	"<br /><b>Start Date Source: </b>" + currentPhase.StartDateSource +
																	"<br /><b>Stop Date: </b>" + currentPhase.StopDate +
																	"<br /><b>Stop Date Source: </b>" + currentPhase.StopDateSource;
							rm.qtip.showInfo("#spnMileStoneDates_" + currentPhase.FTETypeFTEMilestoneTypeId + "", milestoneInfo);
						}
					}
				}
			},
			error: function () { rm.ui.messages.addError(Resources.FailedToGetQipData); }
		});
	},
	renderCalculator: function (requestId, projectId, resourceId, countryId, calculatorTitle, makeAsyncCall, regionId, requestIdForRerender, organizationId) {
		requestIdForRerender = (requestIdForRerender == null) ? -1 : requestIdForRerender;
		setTimeout(function () {
			(requestId != "" && requestId != null)
				? $("#spanPreviousValues").removeClass("hideMe")
				: $("#spanPreviousValues").addClass("hideMe");
		}, 5);
		$.Calculator._requestId = requestId;
		$("#calculatorTitle").html(calculatorTitle);
		$.Calculator._deletedList.length = 0;

		$.each($('#staticRow').children(), function (i) {
			$(this).remove();
		});

		$.each($('#AdHocRow').children(), function (i) {
			$(this).remove();
		});

		$(".FTE_Calculator").hide();
		$.Calculator._interimFrequencyEnabled = false;

		var url = "";
		if (qipOtherCalculator.multiEditMode) {
			if (qipOtherCalculator.isRegionBasedCalculator) {
				url = rm.ajax.requestSvcUrl + "GetRegionalPhaseCalculatorsByResourceTypeId?resourceType=" + qipOtherCalculator.resourceTypeId + "&regionId=" + qipOtherCalculator.regionId;
			} else if (qipOtherCalculator.isGlobalCalculator) {
				url = rm.ajax.requestSvcUrl + "GetGlobalPhaseCalculatorsByResourceTypeId?resourceType=" + qipOtherCalculator.resourceTypeId + "&organizationId=" + qipOtherCalculator.organizationId;
			} else {
				url = rm.ajax.requestSvcUrl + "GetPhaseCalculatorsByResourceTypeId?resourceType=" + qipOtherCalculator.resourceTypeId;
			}
		}
		else if (requestId != null) {
			if (qipOtherCalculator.isRegionBasedCalculator) {
				url = rm.ajax.requestSvcUrl + "GetRegionBasedInitiateCalculatorbyRequest?requestId=" + requestId + "&regionId=" + regionId;
			} else if (qipOtherCalculator.isGlobalCalculator) {
				url = rm.ajax.requestSvcUrl + "GetGlobalInitiateCalculatorbyRequest?requestId=" + requestId + "&organizationId=" + organizationId;
			} else {
				url = rm.ajax.requestSvcUrl + "GetInitiateCalculatorbyRequest?requestId=" + requestId;
			}
		}
		else if (qipOtherCalculator.isRegionBasedCalculator) {
			url = rm.ajax.requestSvcUrl + "RenderRegionBasedInitiateCalculator?projectId=" + projectId + "&resourceId=" + resourceId + "&regionId=" + regionId + "&requestId=" + requestIdForRerender + "&requestStartDate=" + $($.Calculator.StartDateSelector).val() + "&requestStopDate=" + $($.Calculator.StopDateSelector).val(); // for  New Request or for existing request on region change
		}
		else if (qipOtherCalculator.isGlobalCalculator) {
			url = rm.ajax.requestSvcUrl + "RenderGlobalInitiateCalculator?projectId=" + projectId + "&resourceTypeId=" + resourceId + "&organizationId=" + organizationId + "&requestId=" + requestIdForRerender + "&requestStartDate=" + $($.Calculator.StartDateSelector).val() + "&requestStopDate=" + $($.Calculator.StopDateSelector).val(); // for  New Request or for existing request on region change
		}
		else {
			url = rm.ajax.requestSvcUrl + "RenderInitiateCalculator?projectId=" + projectId + "&resourceId=" + resourceId + "&countryId=" + countryId + "&requestId=" + requestIdForRerender; // for  New Request or for existing request on country change
		}

		$.ajax({
			url: url,
			cache: false,
			async: makeAsyncCall,
			success: function (data) {
				$("#isDirtyCalculator").val('False');
				var qipData = { startDate: "", stopDate: "", hasQipData: false };
				var weeklyHours;
				var FTE;
				var allowBlankAttr = qipOtherCalculator.multiEditMode ? " allowBlank='true' " : "";
				var styleConfig = { width: '250px' };
				var stylePosition = { my: 'bottom center', at: 'top center' };
				$(".FTE_Calculator #fteJobGrade").val(data.JobGrade);
				$(".FTE_Calculator #fteJobGradeInfoString").val(data.JobGradeInfoStr);
				for (var i = 0; i < data.staticInitiateCalculatorList.length; i++) {
					var currentPhase = data.staticInitiateCalculatorList[i];
					if (i == 0) { qipData.startDate = currentPhase.StartDate; }
					if (i + 1 == data.staticInitiateCalculatorList.length) { qipData.stopDate = currentPhase.StopDate; }

					weeklyHours = currentPhase.WeeklyHours;
					qipWeeklyHours = currentPhase.QipWeeklyHours;
					FTE = currentPhase.FTE;
					qipFTE = currentPhase.QipFTE;
					calcStatus = currentPhase.Status;
					var isConnected = (calcStatus == 1);
					qipData.hasQipData = (qipData.hasQipData || isConnected || (qipWeeklyHours != "" && qipWeeklyHours != "-1" && qipWeeklyHours != null))
					var qipImage = "<img id='imgStatic_" + currentPhase.FTETypeFTEMilestoneTypeId + "' src='/_layouts/SPUI/images/" + (isConnected ? 'ConnectedBudget.png' : 'DisconnectedBudget.png') + "' alt='' title='" + (isConnected ? "" : "Reconnect to Budget") + "' connectStatusChanged='0' connectStatus='" + calcStatus + "' class='" + (isConnected ? 'imgConnected' : 'imgReconnect') + "' " + ($.Calculator.AllowEditing ? "" : "disabled='disabled'") + " />";

					var addStaticRow = "<tr>" +
                        "<td style='width: 6%; text-align:center;'>" +
                        (currentPhase.AllowQipConnection ? qipImage : "") +
                        "   <input type='hidden' id='hdnStaticId_" + currentPhase.FTETypeFTEMilestoneTypeId + "' value='" + currentPhase.FTETypeFTEMilestoneTypeId + "'/>" +
						"   <input type='hidden' id='hdnRequestCalculatorTimestamp_" + currentPhase.FTETypeFTEMilestoneTypeId + "' value='" + data.StaticInitiateCalcTimestamp[i].RequestCalculatorTimestamp + "'/>" +
						"   <input type='hidden' id='hdnRequestCalculatorId_" + currentPhase.FTETypeFTEMilestoneTypeId + "' value='" + data.StaticInitiateCalcTimestamp[i].RequestCalculatorId + "'/>" +
						"   <input type='hidden' id='hdnCountryTimestamp_" + currentPhase.FTETypeFTEMilestoneTypeId + "' value='" + data.StaticInitiateCalcTimestamp[i].CountryTimestamp + "'/>" +
						"   <input type='hidden' id='hdnCountryCalculatorId_" + currentPhase.FTETypeFTEMilestoneTypeId + "' value='" + data.StaticInitiateCalcTimestamp[i].CountryCalculatorId + "'/>" +
						"   <input type='hidden' id='hdnFTETypeId_" + currentPhase.FTETypeFTEMilestoneTypeId + "' value='" + data.StaticInitiateCalcTimestamp[i].FteTypeId + "'/>" +
                        "</td>" +
                        "<td style='width: 7%;'>" +
                        "   <span id = 'lblPhase_" + currentPhase.FTETypeFTEMilestoneTypeId + "'>" + currentPhase.Phase + "</span>" +
                        "</td>" +
                        "<td style='width: 20%;'>" +
                        "   <span id = 'lblMilestones_" + currentPhase.FTETypeFTEMilestoneTypeId + "'>" + currentPhase.Milestones + "</span>" +
                        "</td>" +
                        "<td style='width: 3%;'>" +
												"<span id='spnMileStoneDates_" + currentPhase.FTETypeFTEMilestoneTypeId + "'><img src='/_layouts/SPUI/images/searchIcon.png' class='cursorPointer' id=imgMileStoneDates_'" + currentPhase.FTETypeFTEMilestoneTypeId + "' /></span>" +
                        "</td>" +
                        "<td style='text-align:center; width: 11%;'>" +
                        "   <span class='oldValue hideMe'><span id='old_static_txtWeeklyHours_" + currentPhase.FTETypeFTEMilestoneTypeId + "' /></span>" +
                        "   <input type='text' " + allowBlankAttr + " id='txtWeeklyHours_" + currentPhase.FTETypeFTEMilestoneTypeId + "'" + $.Calculator.getInputAttributesForWeeklyHours(qipOtherCalculator.isProposalReqeustOrProjectSelected(), isConnected, currentPhase.AllowQipConnection) + " from='0' to='9999.99' formating='4,2' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px;' value='" + (weeklyHours == null ? "" : weeklyHours) + "' actualValue='" + (weeklyHours == null ? "" : weeklyHours) + "' qipValue='" + qipWeeklyHours + "' />" +
                        "</td>" +
                        "<td style='text-align:center; width: 11%;'>" +
												"   <span class='oldValue hideMe'><span id='old_static_txtFTE_" + currentPhase.FTETypeFTEMilestoneTypeId + "' /></span>" +
                        "   <input type='text' " + allowBlankAttr + " id='txtFTE_" + currentPhase.FTETypeFTEMilestoneTypeId + "' " + $.Calculator.getInputAttributesForFte(qipOtherCalculator.isProposalReqeustOrProjectSelected(), isConnected, currentPhase.AllowQipConnection) + " from='0' to='999.999' formating='3,3' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px;' value='" + (FTE == null ? "" : FTE) + "' actualValue='" + (FTE == null ? "" : FTE) + "' qipValue='" + qipFTE + "' />" +
                        "</td>" +
                        "</tr>";

					$("#staticRow").append(addStaticRow);
					if (!qipOtherCalculator.multiEditMode) {
						var milestoneInfo = "<b>Start Date: </b>" + currentPhase.StartDate +
																"<br /><b>Start Date Source: </b>" + currentPhase.StartDateSource +
																"<br /><b>Stop Date: </b>" + currentPhase.StopDate +
																"<br /><b>Stop Date Source: </b>" + currentPhase.StopDateSource;
						rm.qtip.showInfo("#spnMileStoneDates_" + currentPhase.FTETypeFTEMilestoneTypeId + "", milestoneInfo, {}, {}, stylePosition, styleConfig, {});
					}
					else {
						$("#spnMileStoneDates_" + currentPhase.FTETypeFTEMilestoneTypeId).css('display', 'none');
					}
				}

				if (data.adhocInitiateCalculatorList != null) {
					for (var i = 0; i < data.adhocInitiateCalculatorList.length; i++) {
						var allowEdit = true;
						var disabledString = "";
						if ($.Calculator.isRequestHardOrSoftBooked && !rm.date.isQDateDateGreaterOrEqualToToday(data.adhocInitiateCalculatorList[i].EndDate)) {
							allowEdit = false;
							disabledString = " disabled='disabled' ";
						}
						var addAdhocRow = "<tr style='line-height:24px;'>" +
                            "<td style='visibility:hidden; width:1%'>" +
                            "   <input type='hidden' id='hdnExplanation_" + data.adhocInitiateCalculatorList[i].Id + "' value='" + escape(data.adhocInitiateCalculatorList[i].Comments) + "' actualValue='" + escape(data.adhocInitiateCalculatorList[i].Comments) + "'/>" +
														"   <input type='hidden' id='hdnAdhocCalculatorTimestamp_" + data.adhocInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId + "' value='" + data.AdhocInitiateCalcTimestamp[i].RequestCalculatorTimestamp + "'/>" +
														"   <input type='hidden' id='hdnAdhocCalculatorId_" + data.adhocInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId + "' value='" + data.AdhocInitiateCalcTimestamp[i].RequestCalculatorId + "'/>" +
                            "</td>" +
                            " <td style='width: 6%; text-align:left;'>" +
                            "     <img id='imgDelete_" + data.adhocInitiateCalculatorList[i].Id + "' adHockRowId='" + data.adhocInitiateCalculatorList[i].Id + "' src='/_layouts/SPUI/images/closeSmall.png' style='margin: 2px 0 0 10px;' alt='' class='imgDeleteAdHoc'" + ($.Calculator.AllowEditing ? "" : "disabled='disabled'") + "  originalStartDate='" + data.adhocInitiateCalculatorList[i].StartDate + "'/>" +
                            "</td>" +
                            "<td style='width: 11%;'>" +
                            "    <span id = 'lblStartDate_" + data.adhocInitiateCalculatorList[i].Id + "' actualValue='" + data.adhocInitiateCalculatorList[i].StartDate + "'>" + $.Calculator.getAdhocFrequencyDateLink(data.adhocInitiateCalculatorList[i].StartDate, allowEdit) + "</span>" +
                            "</td>" +
                            "<td style='width: 17%;'>" +
                            "    <span id = 'lblEndDate_" + data.adhocInitiateCalculatorList[i].Id + "' actualValue='" + data.adhocInitiateCalculatorList[i].EndDate + "'>" + $.Calculator.getAdhocFrequencyDateLink(data.adhocInitiateCalculatorList[i].EndDate, allowEdit) + "</span>" +
                            "</td>" +
                            "<td style='text-align:center; width: 11%;'>" +
														"    <span class='oldValue hideMe'><span id='old_adhoc_txtWeeklyHours_" + data.adhocInitiateCalculatorList[i].Id + "' /></span>" +
                            "    <input type='text' id='txtWeeklyHours_" + data.adhocInitiateCalculatorList[i].Id + "' value='" + data.adhocInitiateCalculatorList[i].WeeklyHours + "' actualValue='" + data.adhocInitiateCalculatorList[i].WeeklyHours + "'" + $.Calculator.getInputAttributesForWeeklyHours(qipOtherCalculator.isProposalReqeustOrProjectSelected(), false, true) + disabledString + " from='0' to='9999.99' formating='4,2' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px;' />" +
                            "</td>" +
                            "<td style='text-align:center; width: 11%;'>" +
														"    <span class='oldValue hideMe'><span id='old_adhoc_txtFTE_" + data.adhocInitiateCalculatorList[i].Id + "' /></span>" +
                            "    <input type='text' id='txtFTE_" + data.adhocInitiateCalculatorList[i].Id + "' value='" + data.adhocInitiateCalculatorList[i].FTE + "' actualValue='" + data.adhocInitiateCalculatorList[i].FTE + "'" + $.Calculator.getInputAttributesForFte(qipOtherCalculator.isProposalReqeustOrProjectSelected(), false, true) + disabledString + " from='0' to='999.999' formating='3,3' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px;' />" +
                            "</td>" +
                            "</tr>";

						$("#AdHocRow").append(addAdhocRow);
					}
				}

				if (data.adhocInitiateCalculatorList.length > 0 || data.staticInitiateCalculatorList.length > 0) {
					$(".FTE_Calculator").show();
					$.Calculator._interimFrequencyEnabled = true;
					if (!qipOtherCalculator.multiEditMode) {
						$("#adhocFreqContainer").removeClass("hideMe");
						$("#tblPhaseAdhocCalc").removeClass("hideMe");
					}
				}

				if ($.Calculator.OnCalculatorRenderComplete) {
					$.Calculator.OnCalculatorRenderComplete(data.RegionId, data.CountryId, qipData);
				}

				setTimeout(function () {
					$.Calculator.enableDisableAddButton();
					$.Calculator.AfterCalculatorDraw();
				}, 200);
				setTimeout(function () { qipOtherCalculator.bindDirtyForCalculator(); rm.ui.ribbon.delayedRefresh(); }, 200);
			},
			error: function (errmsg) {
				rm.ui.messages.addError(Resources.FailedToRenderInitiateCalculator);
			}
		});
	},

	disconnectAll: function () {
		$(".imgConnected").attr('src', '/_layouts/SPUI/images/qipDisconnected.png').addClass('imgReconnect').removeClass('imgConnected').attr("connectStatus", 0).attr("connectStatusChanged", 1);
	},

	RecalculateFTEValues: function () {
		$.each($(".clsWeeklyhours"), function (index, ele) {
			$.Calculator.CalculateWeeklyHourFTE($(ele), "WH", true);
		});
	},

	reconnect: function (obj, withQipValue) {
		var isConnected = true;
		$.each($(obj).closest("tr").find("input:visible"), function (index, ele) {
			if (!withQipValue) {
				if ($(ele).attr("qipValue") != $(ele).val()) {
					isConnected = false;
					return false;
				}
			}
			else {
				//if ($.Calculator.isRequestHardOrSoftBooked && !qipOtherCalculator.multiEditMode && !qipOtherCalculator.isGlobalCalculator && !qipOtherCalculator.isRegionBasedCalculator && qipOtherCalculator.getCountryIdForFteCalculation() != qipOtherCalculator.countryId) {
				if ($.Calculator.isRequestHardOrSoftBooked && !qipOtherCalculator.multiEditMode && qipOtherCalculator.getCountryIdForFteCalculation() != qipOtherCalculator.countryId) {
					if (qipOtherCalculator.isGlobalCalculator || qipOtherCalculator.isRegionBasedCalculator) { alert(Resources.ReconnectNotAllowedForGlobalAndRegionalRrts); }
					else { alert(Resources.RequestCountryDoesNotMatchResourceCountry); }

					isConnected = false;
					return false;
				}
				else {
					if ($(ele).attr("qipValue") == -1 || $(ele).attr("qipValue") == "null" || $(ele).attr("qipValue") == "" || $(ele).attr("qipValue") == null) {
						alert("Reconnection is not possible as there are no values entered into budget.");
						isConnected = false;
						return false;
					}
					else {
						$(ele).val($(ele).attr("qipValue"));
						$(ele).removeClass("q_validation_error").attr("title", "");
					}

				}
			}
		});

		if ($(obj).parent().parent().parent().attr("id") != "AdHocRow") {
			if (isConnected) {
				$(obj).parent().parent().find("img:not('.cursorPointer')").attr('src', '/_layouts/SPUI/images/ConnectedBudget.png').removeClass('imgReconnect').addClass('imgConnected').attr("connectStatus", "1").attr("connectStatusChanged", "1").attr("title", "");
				if (withQipValue) {
					$(obj).parent().parent().find('[id^=txtFTE]').attr('iconClicked', "true");
				}
			}
			else {
				$(obj).parent().parent().find("img:not('.cursorPointer')").attr('src', '/_layouts/SPUI/images/DisconnectedBudget.png').removeClass('imgConnected').addClass('imgReconnect').attr("connectStatus", "0").attr("connectStatusChanged", "1").attr("title", "Reconnect to Budget");
			}
		}

		if (qipOtherCalculator.connectClick && $.isFunction(qipOtherCalculator.connectClick)) {
			qipOtherCalculator.connectClick();
		}
	},

	IsPromptRequiredForConnectDisconnectStatus: function () {
		var promptNeeded = false;

		$.each($("#staticRow").find("tr"), function (index, ele) {
			var icon = $(ele).find('[id^=imgStatic]');
			var connectStatus = icon.attr('connectStatus');
			var weeklyHours = $(ele).find('[id^=txtWeeklyHours]');
			var fte = $(ele).find('[id^=txtFTE]');
			var iconClicked = fte.attr('iconClicked');
			if (connectStatus == 1 && iconClicked && iconClicked == "false") {
				//Check if user clicked on connect icon or typed the values which match qip values
				if ((weeklyHours.val() == weeklyHours.attr("qipValue")) || (fte.val() == fte.attr("qipValue"))) {
					//Do not break out of the loop. This function tags all rows which require prompt
					promptNeeded = true;
					$(ele).attr("promtRequired", "true");
				}
				else {
					$(ele).attr("promtRequired", "false");
				}
			}
		});

		return promptNeeded;
	},

	ShowConnectDisconnectChoiceDialog: function (addingNewRequest) {
		var confirmationTable = "<div class='instructionalText'>" + Resources.QuipValuesMatchInstructionalText + "</div>";
		confirmationTable += "<table id='dialogTable' class='dialogTableConfirmConnect' border='1'><tr style='font-weight:600; line-height: 24px;'><td>Stage</td><td>Milestones</td><td>Weekly hours</td><td>FTE</td><td>Connect To budget</td><td>Keep Disconnected</td></tr>";

		$.each($("#staticRow").find("tr[promtRequired=true]"), function (index, ele) {
			var rowObj = $(ele);
			var icon = rowObj.find('[id^=imgStatic]');
			var connectStatus = icon.attr('connectStatus');
			var fteTypeFTEMileStoneTypeId = rowObj.find('[id^=hdnStaticId]').val();
			var weeklyHours = rowObj.find('[id^=txtWeeklyHours]').val();
			var fte = rowObj.find('[id^=txtFTE]').val();
			var milestone = rowObj.find('[id^=lblMilestones_]').html();
			var phase = rowObj.find('[id^=lblPhase_]').html();

			//Generate HTML string and show it to user in modal dialog
			confirmationTable += "<tr calculatorRow='true' fteTypeFTEMileStoneTypeId='" + fteTypeFTEMileStoneTypeId + "'>" +
                        "<td style='width: 6%; text-align:center;'>" + phase + "</td>" +
                        "<td style='width: 7%;'>" + milestone + "</td>" +
                        "<td style='width: 11%;'>" + weeklyHours + "</td>" +
                        "<td style='text-align:center; width: 11%;'>" + fte + "</td>" +
                        "<td style='text-align:center; width: 11%;'><input type='radio' name='rbConnectStatus_" + fteTypeFTEMileStoneTypeId + "' value='1'/></td>" +
                        "<td style='text-align:center; width: 11%;'><input type='radio' name='rbConnectStatus_" + fteTypeFTEMileStoneTypeId + "' value='0'/></td>" +
                        "</tr>";
		});

		confirmationTable += "</table> <div class='dialogTableConfirmConnectButtons'><input type='button' id='btnOk_connectDisconnect' value='OK' class='button q_calculatorButtonSave btnOklChangeProject'><input type='button' id='btnCancel_connectDisconnect' class='button btnCancelChangeProject' value='Cancel'> </div>";

		var container = $("#connectDisconnectDialog");
		if (container.length == 0) {
			container = $("<div id='connectDisconnectDialog' />");
			$('body').append(container);
		}
		container.html(confirmationTable).dialog({
			modal: true,
			cache: false,
			closeOnEscape: false,
			title: "Confirm connect status",
			resizable: false,
			width: 620,
			height: 400,
			open: function () {
				$('.ui-dialog-titlebar-close').unbind('click');
				$("#btnCancel_connectDisconnect,.ui-dialog-titlebar-close").click(function () {
					if (confirm(Resources.ConfirmOnConnectDisconnectDialogCancel)) {
						container.html("").dialog('close');
					}
				});

				$("#btnOk_connectDisconnect").click(function () {
					var errorFound = false;
					var tableRows = $("#dialogTable tr[calculatorRow='true']");
					$.each(tableRows, function (index, ele) {
						checkedRadio = $(ele).find("[type=radio]:checked");
						if (checkedRadio.length == 0) {
							alert("Please select the option to connect or disconnect and click OK again.");
							errorFound = true;
							return false;
						}
						else {
							$("#imgStatic_" + $(ele).attr("fteTypeFTEMileStoneTypeId")).attr('connectStatus', checkedRadio.val());
						}
					});

					if (!errorFound) {
						$.Calculator.save(addingNewRequest);
						$.Calculator.DialogOkClickHandler();
						container.html("").dialog('close');
					}
				});
			}
		});
	},

	isValid: function () {
		var isValid = true;
		var allInputs = $("#QIP_Calculator .validateRange:visible");

		$.each(allInputs, function () {
			if (!$.q.rangeValidate($(this))) { isValid = false; }
		});

		if (qipOtherCalculator.areAdhocDatesBeyondRequestStopDate()) {
			isValid = false;
		}

		return isValid;
	},

	save: function (addingNewRequest) {
		if (!$(this).hasClass("q_validation_error")) {
			var staticValues = new Array();
			var adHocValues = new Array();
			var staticTimestampValues = new Array();
			var adHocTimestampValues = new Array();

			$.each($("#staticRow").find("tr"), function (index, ele) {
				if (addingNewRequest ||
						($(ele).find('[id^=txtWeeklyHours]').val() != $(ele).find('[id^=txtWeeklyHours]').attr("actualValue")) ||
						($(ele).find('[id^=txtFTE]').val() != $(ele).find('[id^=txtFTE]').attr("actualValue")) ||
						 $(ele).attr("promtRequired") == "true" ||
						 $(ele).find('[id^=imgStatic]').attr('connectStatusChanged') == "1" ||
						 qipOtherCalculator.isCountryOrRegionChanged()
					 ) {
					var weeklyHours = $(ele).find('[id^=txtWeeklyHours]').val();
					var fte = $(ele).find('[id^=txtFTE]').val();
					var calculatorId = $(ele).find("[id^=hdnRequestCalculatorId]").val();
					var data = {
						FTETypeFTEMilestoneTypeId: $(ele).find('[id^=hdnStaticId]').val(),
						Status: $(ele).find('[id^=imgStatic]').attr('connectStatus'),
						WeeklyHours: weeklyHours == "" ? null : weeklyHours,
						FTE: fte == "" ? null : fte
					}
					if (calculatorId != "null" && calculatorId != "") { data.Id = calculatorId; }
					staticValues.push(data);
				}

				var countryTimestamp = $(ele).find('[id^=hdnCountryTimestamp]').val();
				var countryCalculatorId = $(ele).find('[id^=hdnCountryCalculatorId]').val();
				var requestCalculatorTimestamp = $(ele).find('[id^=hdnRequestCalculatorTimestamp]').val();
				var requestCalculatorId = $(ele).find('[id^=hdnRequestCalculatorId]').val();
				var fteTypeId = $(ele).find('[id^=hdnFTETypeId]').val();

				staticTimestampValues.push({
					CountryTimestamp: countryTimestamp == "null" || countryTimestamp == "" ? null : countryTimestamp,
					CountryCalculatorId: countryCalculatorId == "null" || countryCalculatorId == "" ? null : countryCalculatorId,
					RequestCalculatorTimestamp: requestCalculatorTimestamp == "null" || requestCalculatorTimestamp == "" ? null : requestCalculatorTimestamp,
					RequestCalculatorId: requestCalculatorId == "null" || requestCalculatorId == "" ? null : requestCalculatorId,
					FteTypeId: fteTypeId == "null" || fteTypeId == "" ? null : fteTypeId
				});
			});

			$.each($("#AdHocRow").find("tr"), function (index, ele) {
				var isUpdated = "";
				if (addingNewRequest || $(ele).find('[id^=imgDelete]').attr('adHockRowId').indexOf('New') != -1) {
					isUpdated = DMLOperation_E.Insert; // "Insert";
				}
				else if (($(ele).find('[id^=txtWeeklyHours]').val() != $(ele).find('[id^=txtWeeklyHours]').attr("actualValue")) ||
                        ($(ele).find('[id^=txtFTE]').val() != $(ele).find('[id^=txtFTE]').attr("actualValue")) ||
                        ($(ele).find('[id^=lblStartDate]').find("a").html() != $(ele).find('[id^=lblStartDate]').find("a").attr("actualValue")) ||
                        ($(ele).find('[id^=lblEndDate]').find("a").html() != $(ele).find('[id^=lblEndDate]').find("a").attr("actualValue")) ||
                        (unescape($(ele).find('[id^=hdnExplanation]').val()) != unescape($(ele).find('[id^=hdnExplanation]').attr("actualValue")))) {
					isUpdated = DMLOperation_E.Update; //"Update";
				}

				if (isUpdated != DMLOperation_E.Insert) {
					var requestCalculatorTimestamp = $(ele).find('[id^=hdnAdhocCalculatorTimestamp]').val();
					var requestCalculatorId = $(ele).find('[id^=hdnAdhocCalculatorId]').val();

					adHocTimestampValues.push({
						CountryTimestamp: null,
						CountryCalculatorId: null,
						RequestCalculatorTimestamp: requestCalculatorTimestamp == "null" || requestCalculatorTimestamp == "" ? null : requestCalculatorTimestamp,
						RequestCalculatorId: requestCalculatorId == "null" || requestCalculatorId == "" ? null : requestCalculatorId
					});
				}

				if (isUpdated != "") {
					adHocValues.push({
						FTETypeId: $(ele).find('[id^=imgDelete]').attr('adHockRowId').replace("New", ""),
						WeeklyHours: $(ele).find('[id^=txtWeeklyHours]').val(),
						FTE: $(ele).find('[id^=txtFTE]').val(),
						Comments: unescape($(ele).find('[id^=hdnExplanation]').val()),
						StartDate: $(ele).find('[id^=lblStartDate]').find("a").html(),
						EndDate: $(ele).find('[id^=lblEndDate]').find("a").html(),
						DMLOperation: isUpdated
					});
				}
			});

			$.each($.Calculator._deletedList, function (index, ele) {
				adHocValues.push({
					FTETypeId: ele.FTETAdHocId,
					WeeklyHours: 0,
					FTE: 0,
					Comments: "",
					StartDate: Date(),
					EndDate: Date(),
					DMLOperation: DMLOperation_E.Delete//"Delete"
				});
			});

			if (!addingNewRequest) {
				$.each($.Calculator._deletedOldAdhocList, function (index, ele) {
					adHocValues.push({
						FTETypeId: ele.FTETAdHocId,
						WeeklyHours: 0,
						FTE: 0,
						Comments: "",
						StartDate: Date(),
						EndDate: Date(),
						DMLOperation: DMLOperation_E.Delete//"Delete"
					});
				});
			}

			if (PostBackForm()) {
				$('[id$=FTECalculatorStatic]').val(JSON.stringify(staticValues));
				$('[id$=FTECalculatorAdhoc]').val(JSON.stringify(adHocValues));
			}
			else {
				$.Calculator._staticValues = staticValues;
				$.Calculator._adHocValues = adHocValues;
				$.Calculator._staticTimestampValues = staticTimestampValues;
				$.Calculator._adHocTimestampValues = adHocTimestampValues;
			}
		}
		$.Calculator._deletedOldAdhocList.length = 0;
	},

	CalculateWeeklyHoursOrFteOnRibbonClick: function () {
		if (!qipOtherCalculator.multiEditMode) {
			var weeklyHours = $(".clsWeeklyhours");
			$.each(weeklyHours, function (index, ele) {
				$.Calculator.WeeklyHourChangeHandler(ele);
			});

			var adhocWeeklyHours = $(".clsWeeklyhoursAdHoc");
			$.each(adhocWeeklyHours, function (index, ele) {
				$.Calculator.AdhocWeeklyHourChangeHandler(ele);
			});

			var fte = $(".clsFTE");
			$.each(fte, function (index, ele) {
				$.Calculator.FteChangeHandler(ele);
			});

			var adhocFte = $(".clsFTEAdHoc");
			$.each(adhocFte, function (index, ele) {
				$.Calculator.AdhocFteChangeHandler(ele);
			});
		}
	},

	WeeklyHourChangeHandler: function (element) {
		if (!qipOtherCalculator.multiEditMode) {
			$.q.formatText(element);

			if ($.Calculator._fireChangeEvent) {
				if (eval($(element).attr('isChanged')) && !$(element).hasClass("q_validation_error")) {
					$.Calculator.CalculateWeeklyHourFTE(element, "WH", true);
				}
			}
		}

		$.Calculator._fireChangeEvent = true;
	},

	AdhocWeeklyHourChangeHandler: function (element) {
		$.q.formatText(element);

		if ($.Calculator._fireChangeEvent) {
			if (eval($(element).attr('isChanged')) && !$(element).hasClass("q_validation_error")) {
				$.Calculator.CalculateWeeklyHourFTE(element, "WH", false);
			}
		}

		$.Calculator._fireChangeEvent = true;
	},

	FteChangeHandler: function (element) {
		if (!qipOtherCalculator.multiEditMode) {
			$.q.formatText(element);

			if ($.Calculator._fireChangeEvent) {
				if (eval($(element).attr('isChanged')) && !$(element).hasClass("q_validation_error")) {
					$.Calculator.CalculateWeeklyHourFTE(element, "FTE", true);
				}
			}
		}

		$.Calculator._fireChangeEvent = true;
	},

	AdhocFteChangeHandler: function (element) {
		$.q.formatText(element);

		if ($.Calculator._fireChangeEvent) {
			if (eval($(element).attr('isChanged')) && !$(element).hasClass("q_validation_error")) {
				$.Calculator.CalculateWeeklyHourFTE(element, "FTE", false);
			}
		}

		$.Calculator._fireChangeEvent = true;
	},

	CalculateWeeklyHourFTE: function (modifiedWeeklyHoursFTE, type, evaluateConnectStatus) {
		var countryIdForFteCalculation = (qipOtherCalculator.getCountryIdForFteCalculation() == null) ? -1 : qipOtherCalculator.getCountryIdForFteCalculation();
		var selectedResourceType = ResourceTypeDetails[$.Calculator._resourceTypeId];
		var jobRoleIdForFteCalculation = (qipOtherCalculator.getJobRoleIdForFteCalculation() == null) ? -1 : qipOtherCalculator.getJobRoleIdForFteCalculation();
		var url = "";
		if (qipOtherCalculator.isRegionBasedCalculator) {
			if (type == "WH") {
				url = rm.ajax.requestSvcUrl + "CalculateRegionalFte?regionId=" + qipOtherCalculator.getRegionIdFromUi() + "&resourceId=" + $.Calculator._resourceTypeId + "&weeklyHours=" + $(modifiedWeeklyHoursFTE).val() + "&resourceCountryId=" + countryIdForFteCalculation + "&jobRoleId=" + jobRoleIdForFteCalculation;
			} else {
				url = rm.ajax.requestSvcUrl + "CalculateRegionalWeeklyHours?regionId=" + qipOtherCalculator.getRegionIdFromUi() + "&resourceId=" + $.Calculator._resourceTypeId + "&fte=" + $(modifiedWeeklyHoursFTE).val() + "&resourceCountryId=" + countryIdForFteCalculation + "&jobRoleId=" + jobRoleIdForFteCalculation;
			}
		}
		else if (qipOtherCalculator.isGlobalCalculator) {
			if (type == "WH") {
				url = rm.ajax.requestSvcUrl + "CalculateGlobalFte?organizationId=" + qipOtherCalculator.getOrganizationIdFromUi() + "&resourceTypeId=" + $.Calculator._resourceTypeId + "&weeklyHours=" + $(modifiedWeeklyHoursFTE).val() + "&resourceCountryId=" + countryIdForFteCalculation + "&jobRoleId=" + jobRoleIdForFteCalculation;
			} else {
				url = rm.ajax.requestSvcUrl + "CalculateGlobalWeeklyHours?organizationId=" + qipOtherCalculator.getOrganizationIdFromUi() + "&resourceTypeId=" + $.Calculator._resourceTypeId + "&fte=" + $(modifiedWeeklyHoursFTE).val() + "&resourceCountryId=" + countryIdForFteCalculation + "&jobRoleId=" + jobRoleIdForFteCalculation;
			}
		}
		else {
			url = rm.ajax.requestSvcUrl + "CalculateWeeklyHourFTE?countryId=" + countryIdForFteCalculation + "&resourceId=" + $.Calculator._resourceTypeId + "&modifiedWeeklyHoursFTE=" + $(modifiedWeeklyHoursFTE).val() + "&type=" + type + "&jobRoleId=" + jobRoleIdForFteCalculation;
		}
		if ($(modifiedWeeklyHoursFTE).val() != "") {
			$.ajax({
				url: url,
				cache: false,
				async: false,
				success: function (data) {
					$.Calculator._fireChangeEvent = false;
					$(modifiedWeeklyHoursFTE).parent().parent().find("input").attr('isChanged', 'false');

					if (type == "WH") {
						var element = $(modifiedWeeklyHoursFTE).parent().next().find("input");
						element.val(data).removeClass("q_validation_error").attr("title", "");
						$.q.rangeValidate(element[0]);
						if (element.hasClass("q_validation_error")) {
							element.attr("title", "The value entered is not within expected range for FTE.  Correct range is:" + element.attr("from") + "-" + element.attr("to"));
						}
					}
					else {
						var element = $(modifiedWeeklyHoursFTE).parent().prev().find("input");
						element.val(data).removeClass("q_validation_error").attr("title", "");
						$.q.rangeValidate(element[0]);
						if (element.hasClass("q_validation_error")) {
							element.attr("title", "The value entered is not within expected range for weekly Hours. Correct range is:" + element.attr("from") + "-" + element.attr("to"));
						}
					}

					if (evaluateConnectStatus) {
						setTimeout(function () {
							$.Calculator.reconnect(element, false);
						}, 50);
					}
				},
				error: function (errmsg) {
					rm.ui.messages.addError(Resources.FailedToCalculateWeeklyHourFTE);
				}
			});
		}
	},

	isvalidDate: function (date1, date2) {
		var isValid = true;

		if (!rm.date.isValidDate(date1, false)) {
			isValid = false;
		}

		if (!rm.date.isValidDate(date2, false)) {
			isValid = false;
		}

		if (rm.date.getDateFromQDateString($(":input[id$=d_startDate]").val()) > rm.date.getDateFromQDateString($(":input[id$=d_endDate]").val())) {
			rm.validation.addError("#d_startDate", Resources.StartDateGreaterThanStopDate);
			rm.validation.addError("#d_endDate", Resources.StopDateLessThanStartDate);
			isValid = false;
		}

		return isValid;
	},

	validatecomments: function (comments) {
		if ($.trim(comments).length === 0) {
			rm.validation.addError("#c_comments", "The Explanation is required.");
			return false;
		}
		else {
			return true;
		}
	},

	enableDisableAddButton: function () {
		if ($.Calculator.AllowEditing && $.Calculator.isInterimFrequencyButtonEnabled()) {
			$("#btnAdd,#Button1").removeAttr("disabled");
		}
		else {
			$("#btnAdd,#Button1").attr("disabled", "disabled");
		}
	}
}

$(document).delegate(".clsWeeklyhours,.clsFTE,.clsWeeklyhoursAdHoc,.clsFTEAdHoc", 'paste cut', function (e) {
	$("#isDirtyCalculator").val('True');
	$(this).attr('isChanged', 'true');
	$(this).parent().parent().find('[id^=txtFTE]').attr('iconClicked', "false");
	setTimeout(function () { $.Calculator.OnCalculatorEdit(); }, 10);
});

$(document).delegate(".clsWeeklyhours,.clsFTE,.clsWeeklyhoursAdHoc,.clsFTEAdHoc", 'keydown', function (e) {
	//Allow ajax call on keys 0 to 9, ., backspace and delete
	if ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode == 190 || e.keyCode == 8 || e.keyCode == 46) {
		$("#isDirtyCalculator").val('True');
		$(this).attr('isChanged', 'true');
		$(this).parent().parent().find('[id^=txtFTE]').attr('iconClicked', "false");
		setTimeout(function () { $.Calculator.OnCalculatorEdit(); }, 10);
	}
});

$(document).delegate(".clsWeeklyhours", 'change', function () {
	var element = this;
	//Wait for updated value of isChanged attribute to be available in the dom
	setTimeout(function () {
		$.Calculator.WeeklyHourChangeHandler(element);
	}, 10);
});

$(document).delegate(".clsFTE", 'change', function () {
	var element = this;
	//Wait for updated value of isChanged attribute to be available in the dom
	setTimeout(function () {
		$.Calculator.FteChangeHandler(element);
	}, 10);
});

$(document).delegate(".clsFTEAdHoc", 'change', function () {
	var element = this;
	//Wait for updated value of isChanged attribute to be available in the dom
	setTimeout(function () {
		$.Calculator.AdhocFteChangeHandler(element);
	}, 10);
});

$(document).delegate(".clsWeeklyhoursAdHoc", 'change', function () {
	var element = this;
	//Wait for updated value of isChanged attribute to be available in the dom
	setTimeout(function () {
		$.Calculator.AdhocWeeklyHourChangeHandler(element);
	}, 10);
});

$(document).delegate(".imgDeleteAdHoc", 'click', function () {
	if (confirm('Are you sure you want to delete this frequency?')) {
		$.Calculator.DeleteAdHocRow(this);
		$("#isDirtyCalculator").val('True');
		setTimeout(function () { $.Calculator.OnDeleteAdhocClick(); }, 10);
	}
});

$(document).delegate(".imgReconnect", 'click', function () {
	$("#isDirtyCalculator").val('True');
	$.Calculator.reconnect($($(this).parent().parent()[0].cells[4]).find("input"), true);
	if (qipOtherCalculator.multiEditMode) {
		$(this).closest("tr").find(".clsFTE,.clsWeeklyhours").val("");
	}
	else {
		setTimeout(function () { $.Calculator.OnConnectImageClick(); }, 10);
	}
});

$(document).ready(function () {
	var styleConfig = { width: '250px' };
	var stylePosition = { my: 'bottom center', at: 'top center' };
	rm.qtip.showInfo(".fteAdHocHover", "Creating an Ad-hoc Interim frequency <b><u>replaces</u></b> the FTE allocation during the date range for Ad-hoc.", {}, {}, stylePosition, styleConfig, {});
	qipOtherCalculator.bindChangeEvents();
	isProposal = qipOtherCalculator.isProposalReqeustOrProjectSelected();
	$.Calculator.enableDisableAddButton();
});