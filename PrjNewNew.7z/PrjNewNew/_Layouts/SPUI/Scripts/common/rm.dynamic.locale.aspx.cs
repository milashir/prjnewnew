﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using log4net;
using Newtonsoft.Json;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.Domain.Models.DTE;
using Quintiles.RM.Clinical.Domain.Models.ResourceMatching;
using Quintiles.RM.Clinical.Domain.Properties;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;


namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Scripts.common
{
	public partial class rm : System.Web.UI.Page
	{
		ILog _log = null;
		public ILog Logger
		{
			get
			{
				if (_log == null)
				{
					_log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
					log4net.Config.XmlConfigurator.Configure();
				}
				return _log;
			}
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			try
			{
				StringBuilder sb = new StringBuilder();

				#region Code tables from database
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("Resources", GetResourcesDictionary()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestStatusName", GetDictionary(CacheService.RequestStatus.Values.Cast<ICodeTable>(), typeof(RequestStatusName))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("JobRoleName", GetDictionary(CacheService.AllJobRoles.Values.Cast<ICodeTable>(), typeof(JobRoleName), false)));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ResourceTypeName", GetDictionary(CacheService.ResourceTypes.Values.Cast<ICodeTable>(), typeof(ResourceTypeName), false)));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("FTETypeName", GetDictionary(CacheService.FTETypes.Values.Cast<ICodeTable>(), typeof(CalculatorType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("BackfillTypeName", GetDictionary(CacheService.BackfillTypes.Values.Cast<ICodeTable>(), typeof(BackfillTypeName))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("CommentTypeName", GetDictionary(CacheService.CommentTypes.Values.Cast<ICodeTable>(), typeof(CommentTypeName))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("OpportunityStatus_E", GetDictionary(CacheService.OpportunityStatus.Values.Cast<ICodeTable>(), typeof(OpportunityStatus_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("BidDefenseReason_E", GetDictionary(CacheService.BidDefenseReason.Values.Cast<ICodeTable>(), typeof(BidDefenseReason_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ProjectStage_E", GetDictionary(CacheService.ProjectStage.Values.Cast<ICodeTable>(), typeof(ProjectStage_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestType_E", GetDictionary(CacheService.RequestType.Values.Cast<ICodeTable>(), typeof(RequestType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("CountryResourceTypeWithSpecialResourcingNeed", CountryResourceTypeWithSpecialResourcingNeed.GetObjectForJson()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("OrganizationalUnit_E", GetDictionary(CacheService.AllEnabledOrganizationalUnits.Values.Cast<ICodeTable>(), typeof(OrganizationalUnit_E), false)));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestInfoIconText_E", RequestInfoIconText.GetObjectForJson()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestInfoIconTextForFTECalculatorText_E", RequestInfoIconText.GetFTECalcultorTextObjectForJson()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ResourceTypeDetails", ResourceType.GetObjectForJson()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("CountriesByRegion", Region.GetAllCountriesByRegion()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("LoggedInUser", RmUser.GetCurrentUserAttributes()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("SpecialAssignmentCategories", SpecialAssignmentCategory.GetObjectForJson()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("SharepointRole", GetDictionary(CacheService.SharePointRoles.Values.Where(sr => sr.ShowOnUi).OrderBy(sr => sr.Name).Cast<ICodeTable>())));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("CustomFunctionPermissionRules", GetDictionary(CacheService.CustomFunctionPermissionRules.Values.Cast<ICodeTable>())));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RmFunction", GetDictionary(CacheService.RmFunctions.Values.Cast<ICodeTable>())));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("SiteStatus", SiteStatus.GetObjectForJson()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("JobGradeList", JobGrade.GetJobGradeArray()));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("DataGrid", GetDictionary(CacheService.DataGrids.Values.Cast<ICodeTable>(), typeof(DataGrid_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("CompetencyBand", GetDictionary(CacheService.AllCompetencyBands.Values.Cast<ICodeTable>())));
				#endregion

				#region From Enumerations
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestConnect_E", GetDictionary(typeof(RequestConnect_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ProjectStage_E", GetDictionary(typeof(ProjectStage_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("DMLOperation_E", GetDictionary(typeof(DMLOperation_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("MessageType_E", GetDictionary(typeof(MessageType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestGroup_E", GetDictionary(typeof(RequestGroup_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("CalculatorGroup_E", GetDictionary(typeof(CalculatorGroup_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("CalculatorType_E", GetDictionary(typeof(CalculatorType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("SSVType_E", GetDictionary(typeof(SSVType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("AttributeType_E", GetDictionary(typeof(AttributeType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RmPageLink_E", GetDictionary(typeof(RmPageLink_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ProjectDteType_E", GetDictionary(typeof(ProjectDteType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ResourceTypeName_E", GetDictionary(typeof(ResourceTypeName))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("AnnouncementType_E", GetDictionary(typeof(AnnouncementType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ResourcingRequirementsType_E", GetDictionary(typeof(ResourcingRequirementsType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ResourceRequirementsResouceTypeGroup_E", GetDictionary(typeof(ResourceRequirementsResouceTypeGroup_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequirementType_E", GetDictionary(typeof(RequirementType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ExperienceCategory_E", GetDictionary(typeof(ExperienceCategory_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("DynamicControlTypes_E", GetDictionary(typeof(DynamicControlTypes_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("DownloadAction_E", GetDictionary(typeof(QueryToRun))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("BlindedUnblindedStatus_E", GetDictionary(typeof(BlindedUnblindedStatus_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestTypeResourceTypeGroup_E", GetDictionary(typeof(RequestTypeResourceTypeGroup_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("OrganizationType_E", GetDictionary(typeof(OrganizationType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("JobRoleGroupName_E", GetDictionary(typeof(JobRoleGroupName_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("PageManagerType_E", GetDictionary(typeof(PageManagerType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestMilestoneType_E", GetDictionary(typeof(RequestMilestoneType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("BackfillDeleteOption_E", GetDictionary(typeof(BackfillDeleteOption_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("ProjectSource", GetDictionary(typeof(ProjectService.PROJECT_SOURCE))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RequestSchedulerType_E", GetDictionary(typeof(RequestSchedulerType_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("Process_E", GetDictionary(typeof(Process_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("EntityType", GetDictionary(typeof(EntityTypes))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("SiteTierChangeReason_E", GetDictionary(typeof(SiteTierChangeReason_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RegionRestriction_E", GetDictionary(typeof(RegionRestriction_E))));
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("CountryRestriction_E", GetDictionary(typeof(CountryRestriction_E))));

				#endregion
				sb.AppendFormat("{0}\r\n", GetJsonObjectForJavasctipt("RmConstants", GetConstantsDictionary()));

				ltrDynamicScript.Text = sb.ToString();
			}
			catch (Exception ex)
			{
				ltrDynamicScript.Text = string.Format("alert('{0}')", System.Web.HttpUtility.HtmlAttributeEncode(ex.Message).Replace("'", "\""));
			}
		}

		#region GetJsonObjectForJavasctipt
		private string GetJsonObjectForJavasctipt(string objectName, object objectInstance)
		{
			return string.Format("var {0}={1};", objectName, JsonConvert.SerializeObject(objectInstance, Formatting.None));
		}
		#endregion

		#region GetResourcesDictionary
		private Dictionary<string, string> GetResourcesDictionary()
		{
			IDictionaryEnumerator resEnumerator = Resources.ResourceManager.GetResourceSet(Thread.CurrentThread.CurrentCulture, true, true).GetEnumerator();
			Dictionary<string, string> resourceDictionary = new Dictionary<string, string>();

			while (resEnumerator.MoveNext())
			{
				if (resEnumerator.Value is string)
				{
					resourceDictionary.Add((string)resEnumerator.Key, (string)resEnumerator.Value);
				}
			}

			return resourceDictionary;
		}
		#endregion

		#region GetDictionary
		private Dictionary<string, int> GetDictionary(IEnumerable<ICodeTable> entityList, Type enumType)
		{
			return GetDictionary(entityList, enumType, true);
		}
		private Dictionary<string, int> GetDictionary(IEnumerable<ICodeTable> entityList, Type enumType, bool validateDbAgainstEnumValues)
		{
			Dictionary<string, int> resultDictionary = new Dictionary<string, int>();
			string enumName;
			foreach (ICodeTable entity in entityList)
			{
				if (HasMatchingEnum(enumType, entity.Id, out enumName))
				{
					resultDictionary.Add(enumName, entity.Id);
				}
				else if (validateDbAgainstEnumValues)
				{
					string errorMessage = string.Format("{0} not defined in enum {1}.", entity.Name, enumType.FullName).Replace("'", "\"");
					Response.Output.Write("alert('{0}');", errorMessage);
					Logger.Error(errorMessage);
				}
			}
			return resultDictionary;
		}
		private Dictionary<int, string> GetDictionary(IEnumerable<ICodeTable> entityList)
		{
			return entityList.ToDictionary(el => el.Id, el => el.Name);
		}
		#endregion

		#region GetDictionary
		private Dictionary<string, int> GetDictionary(Type enumType)
		{
			Dictionary<string, int> resultDictionary = new Dictionary<string, int>();
			foreach (var enumItem in Enum.GetValues(enumType))
			{
				resultDictionary.Add(enumItem.ToString(), (int)enumItem);
			}
			return resultDictionary;
		}
		#endregion

		#region HasMatchingEnum
		private bool HasMatchingEnum(Type enumType, int enumIntValue, out string enumName)
		{
			bool enumFound = false;
			enumName = null;

			foreach (var enumItem in Enum.GetValues(enumType))
			{
				if (enumIntValue == (int)enumItem)
				{
					enumName = enumItem.ToString();
					enumFound = true;
					break;
				}
			}

			return enumFound;
		}
		#endregion

		#region GetDictionary
		private Dictionary<string, string> GetConstantsDictionary()
		{
			return new Dictionary<string, string> 
			{ 
				{ "DownloadCompleteFlag", Constants.DOWNLOAD_COMPLETE_FLAG },
				{ "NumberOfDaysInAWeek", Constants.NumberOfDaysInAWeek.ToString() }
			};
		}
		#endregion
	}
}