﻿/// <reference path="rmhelper.js" />

var rmConstants = { JapanCountryId: 192, JapanCountryName: "Japan" };

rmCommon = {
	controlcharacterArray: [11, 16, 17, 18, 20, 27, 33, 34, 35, 36, 37, 38, 39, 40, 45, 91, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 255],
	isNonControlCharacter: function (keyCode) { return $.inArray(keyCode, rmCommon.controlcharacterArray) == -1; },
	validateDecimal: function (value) {
		var RegEx = /^\d*(\.\d{1})?\d{0,1}$/; //This will Validate whether the Organizational Hours Per Week Field has only 2 DP value.
		if (RegEx.test(value)) {
			return true;
		} else {
			return false;
		}
	},
	showDialogWithOkButton: function (popupTitle, htmlPage, onCloseHandler) {
		return rmCommon.showDialogWithButtons(popupTitle, htmlPage, onCloseHandler, [{ text: "Ok", click: function () { $(this).dialog("close"); } }]);
	},
	showDialogWithButtons: function (popupTitle, htmlPage, onCloseHandler, buttonsArray) {
		return $('<div id="dialogContainer"></div>').html(htmlPage).dialog({
			modal: true,
			title: popupTitle,
			resizable: true,
			width: 620,
			close: function (ev, ui) { if (onCloseHandler) { onCloseHandler(); } },
			buttons: buttonsArray
		});
	},
	DisplayAllContries: function (projectDetails) {
		return ((projectDetails.OrganizationalUnitId == OrganizationalUnit_E.Early_Clinical_Development) || (projectDetails.OrganizationalUnitId == OrganizationalUnit_E.Novella) || (projectDetails.ExternalSource == ProjectSource.RM))
	},
	ValidateSSVPerSite: function (ssvTypeSelector, onSiteSsvPerSiteSelector, phoneSsvPerSiteSelector) {
		var isValid = true;
		var ssvType = $(ssvTypeSelector).val();
		if (ssvType == 1) {
			if ($(onSiteSsvPerSiteSelector).val() == 0) {
				rm.validation.addError($(onSiteSsvPerSiteSelector), Resources.RequestWithZeroSSVPerSiteForOnSite);
				isValid = false;
			}
			else
				rm.validation.clearError($(onSiteSsvPerSiteSelector));
		}
		else if (ssvType == 2) {
			if ($(phoneSsvPerSiteSelector).val() == 0) {
				rm.validation.addError($(phoneSsvPerSiteSelector), Resources.RequestWithZeroSSVPerSiteForPhone);
				isValid = false;
			}
			else
				rm.validation.clearError($(phoneSsvPerSiteSelector));
		}

		return isValid;
	},
	arrUniqueFilterResourceType: function (rrtList) {
		var uniqueResourceTypes = {};
		var uniqueRrtList = new Array();

		if (rrtList && rrtList.length > 0) {
			rrtList.forEach(function (element, index, array) {
				if (!(element.resourceTypeName in uniqueResourceTypes)) {
					uniqueRrtList.push(element)
					; uniqueResourceTypes[element.resourceTypeName] = 1;
				}
			});
		}
		return uniqueRrtList;
	}
};

$.q = {
	pad: function (n) {
		n = String(n);
		return n < 10 ? '0' + n : n;
	},

	isPpmConnectDisconnectApplicable: function (requestTypeId, resourceTypeId) {
		return requestTypeId != RequestType_E.Proposal && (
	ResourceTypeDetails[resourceTypeId].RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Project ||
	ResourceTypeDetails[resourceTypeId].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Project);
	},

	isCountryConnectDisconnectApplicable: function (requestTypeId, resourceTypeId) {
		return requestTypeId != RequestType_E.Proposal && (
	ResourceTypeDetails[resourceTypeId].RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Monitoring ||
	ResourceTypeDetails[resourceTypeId].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Monitoring ||
	ResourceTypeDetails[resourceTypeId].RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Ssv ||
	ResourceTypeDetails[resourceTypeId].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Ssv);
	},

	formatText: function (element) {
		var me = $(element);
		var finalValue = me.val();
		$.q.rangeValidate(element);
		if (!isNaN(me.val()) && !me.hasClass("q_validation_error")) {
			var formatString = me.attr("formating");
			if ((formatString !== undefined || formatString != "") && formatString.indexOf(",") != -1 && me.val() != "") {
				var digitsAfterDecimal = formatString.split(",")[1];
				if (digitsAfterDecimal > 0) {
					var myValue = parseFloat(me.val()).toFixed(digitsAfterDecimal);
					var formattedValue = myValue.toString();
					if (formattedValue[0] == ".") {
						formattedValue = "0" + formattedValue;
					}
					while (formattedValue[formattedValue.length - 1] == "0") {
						formattedValue = formattedValue.substring(0, formattedValue.length - 1);
					}
					if (formattedValue[formattedValue.length - 1] == ".") {
						formattedValue = formattedValue.substring(0, formattedValue.length - 1);
					}
					me.val(formattedValue);
					finalValue = formattedValue;
				}
			}
		}

		return finalValue;
	},

	formatNumberString: function (value, formatString) {
		finalValue = value;
		if (formatString !== undefined)//SS:QRPM-4764-Check for undefined before you continue.if variable is undefined it was breaking for below if condition. 
		{
			if ((formatString !== undefined || formatString != "") && formatString.indexOf(",") != -1 && value != "") {
				var digitsAfterDecimal = formatString.split(",")[1];
				if (digitsAfterDecimal > 0) {
					var myValue = parseFloat(value).toFixed(digitsAfterDecimal);
					var formattedValue = myValue.toString();
					if (formattedValue[0] == ".") {
						formattedValue = "0" + formattedValue;
					}
					while (formattedValue[formattedValue.length - 1] == "0") {
						formattedValue = formattedValue.substring(0, formattedValue.length - 1);
					}
					if (formattedValue[formattedValue.length - 1] == ".") {
						formattedValue = formattedValue.substring(0, formattedValue.length - 1);
					}
					finalValue = formattedValue;
				}
			}
		}
		return finalValue;
	},

	isNumber: function (n) { return /^\d*\.?\d+$/.test(n); },

	isValid: function (eleSelector) { return !$(eleSelector).hasClass("q_validation_error"); },

	findInArray: function (ar, valueToFind, sAttr, iStartIndex) {
		for (var i = (iStartIndex ? iStartIndex : 0) ; i < ar.length; i++)
			if (ar[i] && ((sAttr ? ar[i][sAttr] : ar[i]) == valueToFind))
				return i;
		return -1;
	},

	preventNavigationOnBackSpace: function (e) {
		if ((e.keyCode || e.which) == 8) {
			e.preventDefault();
			e.stopPropagation();
		}
	},

	getPeoplePickerValue: function (serverControlId) {
		lookedUpValue = $("[id$=" + serverControlId + "] [id=content]").html();
		valueBeingTyped = $("[id$=" + serverControlId + "] [id$=" + serverControlId + "_upLevelDiv]").html();
		valueBeingTyped = valueBeingTyped.replace(/&nbsp;/, "");
		valueBeingTyped = valueBeingTyped.replace(/<br>/, "");
		return (lookedUpValue != "") ? lookedUpValue : valueBeingTyped;
	},

	isNonPrintableKey: function (keyCode) {
		return (keyCode == 9 ||
		keyCode == 12 ||
		(keyCode >= 16 && keyCode <= 20) ||
		keyCode == 27 ||
		(keyCode >= 33 && keyCode <= 40) ||
		(keyCode >= 44 && keyCode <= 46) ||
		keyCode == 91 ||
		keyCode == 93 ||
		(keyCode >= 112 && keyCode <= 123) ||
		keyCode == 144 ||
		keyCode == 145);
	},

	setPeoplePickerValue: function (serverControlId, value) {
		$("[id$=" + serverControlId + "_upLevelDiv]").html(value);
	},

	getPeoplePickerDivId: function (serverControlId) {
		return $("[id$=" + serverControlId + "_upLevelDiv]").attr("id");
	},

	lookupPeoplePickerValue: function (serverControlId) {
		$("[id$=" + serverControlId + "_checkNames]").click();
	},

	closeDatePicker: function () {
		$(".ui-datepicker-close").click();
	},
	/**
* jQuery function to Validate from & to range value. 
* Expects html attributes 'from' and 'to' to be present
*
* @author Anup Indurkar
*/

	rangeValidate: function (element) {

		var format = $(element).attr('formating');
		var numberOfAllowedDecimals = 0;
		var indexOfComma = format.indexOf(",");
		var isInteger = true;
		var errorMessage = $(element).attr('errorMessage');
		var correctRangeMessage = 'Correct range is: ' + $(element).attr('from') + ' - ' + $(element).attr('to');

		if (indexOfComma > -1) {
			numberOfAllowedDecimals = format.substring(indexOfComma + 1);
		}

		isInteger = (numberOfAllowedDecimals == 0);
		rm.validation.clearError($(element));

		if ($.trim($(element).val()) == "") {
			var attr = $(element).attr('allowBlank')
			if (typeof attr !== 'undefined' && attr !== "false") {
				return true;
			}
		}

		if (!$.q.isNumber($(element).val())) {
			if (!errorMessage) {
				errorMessage = (isInteger ? 'Enter integer value only, ' : 'Enter numeric value only, ') + correctRangeMessage;
			}

			rm.validation.addError(element, 'Incorrect formatting. ' + errorMessage);
			return false;
		}
		else if (parseFloat($(element).val(), 10) > parseFloat($(element).attr('to'), 10) ||
		parseFloat($(element).val(), 10) < parseFloat($(element).attr('from'), 10)) {
			if (!errorMessage) {
				errorMessage = 'The value entered is not within the expected range. ' + correctRangeMessage;
			}

			rm.validation.addError(element, errorMessage);
			return false;
		}

		if (!$.q.isFormatted(element)) {
			correctFormatMessage = isInteger ? "Enter integer value only." : "Correct format is: (" + format.replace(",", ".") + ")";
			rm.validation.addError(element, 'Incorrect formatting. ' + correctFormatMessage);
			return false;
		}

		return true;
	},

	/**
* Formating decimal value to ##.### 
*
* @author Anup Indurkar
*/
	FormatToDecimal: function (value) {
		var num = new Number(value);
		return num.toFixed(3);
	},

	FormatToTwoDecimal: function (value) {
		var num = new Number(value);
		return num.toFixed(2);
	},

	RemoveTrailingZeros: function (value) {
		value = value + "";

		while (value.indexOf(".") != -1 && (value[value.length - 1] == "0" || value[value.length - 1] == ".")) {
			value = value.substring(0, value.length - 1);
		}
		return value;
	},

	/**
* Function to Validate integer & decimal formating of the input text value Ex: for 2 integer & 3 decimal formating='2,3'
* Expects html attributes 'formating' to be present
*
* @author Anup Indurkar
*/
	isFormatted: function (element) {
		var formating = $(element).attr('formating').split(',');
		var formatValue = $(element).val().split('.');

		// if no decimal allowed (whole number) i.e. without decimal point like 100. & 100.0 ect.
		if ((parseInt(formating[1], 10) == 0) && (formatValue.length > 1)) {
			return false;
		}

		// Show error if there are more then 2 decimal points in the value (12.34.56)
		if (formatValue.length > 2) {
			return false;
		}
		if (parseInt(formatValue[0].length, 10) > parseInt(formating[0], 10)) {
			return false;
		}

		// If there are no decimal point
		if (formatValue.length > 1) {
			if (parseInt(formatValue[1].length, 10) > parseInt(formating[1], 10)) {
				return false;
			}
		}

		return true;
	},

	RebindQtip: function (gridSelector) {
		var mygrid = $(gridSelector);
		var ids = mygrid.getDataIDs();  //all the rowids
		for (var i = 0; i < ids.length; i++) {
			var cellValue = $(mygrid).getCell(ids[i], 'Message');
			if (cellValue != undefined && $.trim(cellValue) != "") {
				var imageTitle = $(cellValue).attr("title");
				if (imageTitle != undefined) {
					$(mygrid).setCell(ids[i], 'Message', imageTitle);
				}
			}
		}
	},

	textCounter: function (field, maxlimit, elementSelector) {
		$(elementSelector).html(maxlimit - field.value.length);
		if ((maxlimit - field.value.length) < 0) {
			return false;
		}
		return true;
	}
};

//Global functions, options, constants, etc., specific to the RM application go here
//Author: Matt Rakestraw
$.rm = {
	GetRequestCounts: function () {/*kept only to prevent sharepoint site pages from throwing error*/ },
	/**
* Call Web Services in Request.svc and set default Error function
*
* @WebServiceMethodName {String} name of web service to be called
* @data {Object} list of parameters to be passed to the web service: { param1Name: param1Value, param2Name: param2Value ... }
*   - paramName must match name of parameter in web service
* @fnSuccess {Function} Callback if web service success
* @isGet {Boolean} optional, default to false, flag for POST or GET
*/
	Ajax_Request: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.requestSvcUrl, fnError);
	},
	Ajax_RequestSynchronous: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.requestSvcUrl, false, fnError);
	},
	Ajax_Resource: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.resourceSvcUrl, fnError);
	},

	Ajax_ResourceSynchronous: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.resourceSvcUrl, false, fnError);
	},
	Ajax_Project: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.projectSvcUrl, fnError);
	},

	Ajax_ProjectSynchronous: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.projectSvcUrl, false, fnError);
	},

	Ajax_Attribute: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.attributeSvcUrl, fnError);
	},
	Ajax_AttributeAsync: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.attributeSvcUrl, true, fnError);
	},
	Ajax_Utility: function (WebServiceMethodName, data, fnSuccess, isGet, makeAsyncCall, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.utilitySvcUrl, makeAsyncCall, fnError);
	},

	Ajax_Calculator: function (WebServiceMethodName, data, fnSuccess, isGet, makeAsyncCall, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.calculatorSvcUrl, makeAsyncCall, fnError);
	},

	Ajax_MaintenanceUtility: function (WebServiceMethodName, data, fnSuccess, isGet, fnError, makeAsyncCall) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.maintenanceUtilitySvcUrl, makeAsyncCall, fnError);
	},

	Ajax_Dashboard: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.dashboardSvcUrl, fnError);
	},

	Ajax_DashboardSynchronous: function (WebServiceMethodName, data, fnSuccess, isGet, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.dashboardSvcUrl, false, fnError);
	},

	Ajax_Administration: function (WebServiceMethodName, data, makeAsyncCall, isGet, fnSuccess, fnError) {
		this.Ajax_WS(WebServiceMethodName, data, fnSuccess, isGet, rm.ajax.adminSvcUrl, makeAsyncCall, fnError);
	},

	Ajax_WS: function (WebServiceMethodName, data, fnSuccess, isGet, urlStart, makeAsyncCall, fnError) {
		$.ajax({
			url: urlStart + WebServiceMethodName,
			datatype: 'json',
			cache: false,
			async: makeAsyncCall,
			type: isGet ? "GET" : "POST",
			data: isGet ? data : JSON.stringify(data),
			contentType: 'application/json; charset=utf-8',
			success: fnSuccess,
			error: fnError ? fnError : function (x, e, serviceError) {
				$.rm.ShowHtmlPopup("Web Service Error: " + WebServiceMethodName, x.responseText ? x.responseText : serviceError);
			}
		});
	},

	/**
* Show JQuery popup with an entire HTML
*
* @popupTitle {String} title of popup
* @htmlPage {String} HTML markup of an entire page
* Security Warning: no encoding is performed with htmlPage
*/
	ShowHtmlPopup: function (popupTitle, htmlPage) {
		$('<div id="dialogContainer"><iframe id="frmWsErrID" style="height:100%;width:100%"></iframe></div>').dialog({
			modal: true,
			title: popupTitle,
			resizable: true,
			open: function (event, ui) { event.target.firstChild.contentWindow.document.write(htmlPage); },
			/*resize: function (event, ui) {
var divCont = event.target;
wDivCont = divCont.offsetWidth - 10;
hDivCont = divCont.offsetHeight - 20;
divCont.firstChild.style.width = wDivCont;
divCont.firstChild.style.height = hDivCont;
},*/
			width: 620,
			//height: "480px", "auto"
			close: function (ev, ui) { $(this).remove(); }
		});
	},

	datepickerOptions: {
		//monthNamesShort: { 0: "JAN", 1: "FEB", 2: "MAR", 3: "APR", 4: "MAY", 5: "JUN", 6: "JUL", 7: "AUG", 8: "SEP", 9: "OCT", 10: "NOV", 11: "DEC" },
		monthNamesShort: ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],

		//autoSize: true,
		dateFormat: 'dd-M-yy',
		upperCase: true,
		changeMonth: true,
		changeYear: true,
		yearRange: '-1:+10',
		showButtonPanel: true,
		showOn: 'button',  //focus is default
		buttonText: 'Select a Date',
		buttonImage: '/_layouts/SPUI/images/calendarBig.png',
		buttonImageOnly: true,

		onClose: function () {
			if (!rm.date.isValidDate($(this).val(), true)) {
				$(this).addClass("q_validation_error");
			} else {
				rm.validation.clearError($(this));
			}
		}
	},

	BindAwardedProjectAutoCompleteList: function () {
		SetupProjectAutoComplete($("#Q_ProjectList"));
		$("#Q_ProjectList_SearchIcon").bind('click', function () {
			var projectCode = $("#Q_ProjectList").val();
			if (projectCode !== '') {
				ReloadPageWithProjectCode(projectCode);
			}
		});
	},


	SetRequestBlindedFieldVisibility: function (displaysBlindedField) {
		if (displaysBlindedField) {
			$('#initiateFieldBlindedSpan').show();
		} else {
			$('#initiateFieldBlindedSpan').hide();
		}
	}
};

RefreshPage = function () {
	location.reload();
};

function SetupProjectAutoComplete(TextboxObj) {
	var resultset;

	$.ajax({
		type: "POST",
		contentType: "application/json; charset=utf-8",
		url: rm.ajax.projectSvcUrl + "GetAwardedProjectList?filterBasedonRMUser=false",
		dataType: "json",
		success: function (data) {
			//bind the autocomplete plugin to the search box
			TextboxObj.autocomplete({
				source: data,//.split("[,]"),
				matchContains: false
			}).keypress(function (e) {
				if (e.keyCode === 13) {
					var indexOfHyphen = $(this).val().indexOf("-");
					projectCode = $.trim($(this).val()).substring(0, indexOfHyphen);
					ReloadPageWithProjectCode($(this).val());

				}
			});

			//When option in list is selected, do something
			TextboxObj.bind("autocompleteselect", function (event, ui) {
				var indexOfHyphen = ui.item.value.indexOf("-");
				projectCode = $.trim((ui.item.value).substring(0, indexOfHyphen));
				ReloadPageWithProjectCode(ui.item.value);
			});
		},
		error: function (errMsg) {
			alert('Unable to load master list of projects.');
		}
	});
}

function SetupProposalAndAwardedProjectAutoComplete(TextboxObj) {
	var resultset;

	$.rm.Ajax_Project("GetAwardedAndProposalProjectList", {},
		function (data) {
			//bind the autocomplete plugin to the search box
			TextboxObj.autocomplete({
				source: data,
				matchContains: false
			}).keypress(function (e) {
				if (e.keyCode === 13) {
					var indexOfHyphen = $(this).val().indexOf("-");
					projectCode = $.trim($(this).val()).substring(0, indexOfHyphen);
					ReloadPageWithProjectCode($(this).val());
				}
			});

			//When option in list is selected, do something
			TextboxObj.bind("autocompleteselect", function (event, ui) {
				var indexOfHyphen = ui.item.value.indexOf("-");
				projectCode = $.trim((ui.item.value).substring(0, indexOfHyphen));
				ReloadPageWithProjectCode(ui.item.value);
			});
		}, false, function (errMsg) {
			alert('Unable to load master list of projects.');
		});
}

/**
* Call this funtion with a valid projectCode (validation takes place) to reload the current page
* and passing in the new 
code
*
* @author Colin Boatwright
*/
function ReloadPageWithProjectCode(projectCode_protocolNumber) {
	var indexOfHyphen = projectCode_protocolNumber.indexOf("-");
	var projectCode = "";
	var protocolNumber = "";
	if (indexOfHyphen == -1) {
		projectCode = projectCode_protocolNumber;
	}
	else {
		projectCode = $.trim(projectCode_protocolNumber.substring(0, indexOfHyphen));
		protocolNumber = $.trim(projectCode_protocolNumber.substring(indexOfHyphen + 1, projectCode_protocolNumber.length));
	}

	if (projectCode_protocolNumber != GetCurrentProjectCodeProtocolNumber() && IsProjectCodeFormatValid(projectCode_protocolNumber)) {
		rm.ui.dialog.showWaitModalWithNoClose("Loading " + projectCode_protocolNumber);
		window.onbeforeunload = null
		var url = $.url();
		href = url.attr('path');
		document.location = href + "?projectCode=" + encodeURIComponent(projectCode) + '&protocolNumber=' + encodeURIComponent(protocolNumber) + '&search=1';
	}
}

/**
* Validate the format of a project code. Does NOT validate if the code exists or not, just the format (XXX#####)
*
* @author Colin Boatwright
*/
function IsProjectCodeFormatValid(projectCode) {
	var rv = true;

	if (projectCode == null || projectCode == "") {
		alert('Please enter a project code');
		rv = false;
	}

	return rv;
}

/**
* @author Colin Boatwright
*/
function GetCurrentProjectName() {
	return $("[id$=_ProjectName]").val();
}

function GetCurrentProjectCodeProtocolNumber() {
	return $("[id$=_ProtocolNumber]").val();
}

function GetCurrentProjectOrganizationUnitName() {
	return $("[id$=_OrganizationUnitName]").val();
}

function GetSelectedProjectCodeAndProtocol() {
	return $("[id$=_txtProjectNameProtocolNumber]").val();
}


/**
* jQuery.fn.sortElements
* --------------
* @param Function comparator:
*   Exactly the same behaviour as [1,2,3].sort(comparator)
*   
* @param Function getSortable
*   A function that should return the element that is
*   to be sorted. The comparator will run on the
*   current collection, but you may want the actual
*   resulting sort to occur on a parent or another
*   associated element.
*   
*   E.g. $('td').sortElements(comparator, function(){
*      return this.parentNode; 
*   })
*   
*   The <td>'s parent (<tr>) will be sorted instead
*   of the <td> itself.
*/
jQuery.fn.sortElements = (function () {
	var sort = [].sort;

	return function (comparator, getSortable) {
		getSortable = getSortable || function () { return this; };

		var placements = this.map(function () {
			var sortElement = getSortable.call(this),
					parentNode = sortElement.parentNode,

// Since the element itself will change position, we have
// to have some way of storing its original position in
// the DOM. The easiest way is to have a 'flag' node:
					nextSibling = parentNode.insertBefore(
							document.createTextNode(''),
							sortElement.nextSibling
					);

			return function () {
				if (parentNode === this) {
					throw new Error(
							"You can't sort elements if any one is a descendant of another."
					);
				}

				// Insert before flag:
				parentNode.insertBefore(this, nextSibling);
				// Remove flag:
				parentNode.removeChild(nextSibling);
			};
		});

		return sort.call(this, comparator).each(function (i) {
			placements[i].call(getSortable.call(this));
		});
	};
})();

$(document).ready(function () {
	//Handle Project Profile pages
	if ($("[id$=_LoadedSuccessfully]")) {
		//Found the project loaded successfully field, so ok to run following code
		var ls = $("[id$=_LoadedSuccessfully]").val();
		if (ls == "0") {
			var url = $.url();
			//MR: If search=1, then show error, otherwise suppress
			if (url.param("search") === "1") {
				setTimeout(function () { rm.ui.messages.addError(Resources.ProjectNotFound); }, 100);
			}
			$("#ProjectNameDisplay").html('<a href="JavaScript://" onClick="ChangeProject(); return false;">No Project</a>');
		}
		else if (ls == "1") {
			var url = $.url();
			var projectName = GetCurrentProjectName();
			var protocolNumber = GetCurrentProjectCodeProtocolNumber(); // url.param("protocolNumber") != undefined ? " - " + url.param("protocolNumber") : "";
			var organizationunitname = GetCurrentProjectOrganizationUnitName();
			$("#ProjectNameDisplay").show();

			$("#ProjectNameDisplay").html(projectName + " - " + protocolNumber);
			$("#ProjectNameDisplay").attr("title", projectName + " - " + protocolNumber + " - " + organizationunitname);
		}
	}
});

var IsPopulateZLoaderRunning = function () {
	var isPopulateZLoaderRunning = false;
	$.rm.Ajax_Utility("IsPopulateZLoaderRunning", {}, function (data) {
		isPopulateZLoaderRunning = data;
	}, true, false);

	return isPopulateZLoaderRunning;
}

// Executes function after delays
// usefull because closure will retain parameters
// It must exist in jQuery but I didn't find it (Vincent)
function rm_timeOut(fn, delay, scope) {
	var args = Array.prototype.slice.call(arguments, 3),
	fnBind = function () { fn.apply(scope || window, args) }
	setTimeout(fnBind, delay);
}

//Global functions for jqgrid
//Author: Shrirang Dolas
$.qGrid = {
	qGridOptions: {
		calendarIcon: "/_layouts/SPUI/images/calendarBig.png",
		connectedImageSrc: "/_layouts/SPUI/images/calendarConnected.png",
		disconnectedImageSrc: "/_layouts/SPUI/images/calendarDisconnected.png",
		connectedPpmImageSrc: "/_layouts/SPUI/images/calendarConnected.png",
		disconnectedPpmImageSrc: "/_layouts/SPUI/images/calendarDisconnected.png",
		timeout: 50,
		imageError: "Unable to determine connected status"
	},

	getGridRowDataById: function (rowDataList, rowId) {
		var rowData;

		if (rowDataList) {
			$.each(rowDataList, function (index, element) {
				if (element.id == rowId) {
					rowData = element;
					return false;
				}
			});

		}
		return rowData;
	},

	addGridRowJsonToUserData: function (gridSelector, newRow) {
		var userData = $.qGrid.getGridUserData(gridSelector);
		userData.Records.push(newRow);
	},

	updateGridRowJsonInUserData: function (gridSelector, newRow) {
		var userData = $.qGrid.getGridUserData(gridSelector);

		$.each(userData.Records, function (index, element) {
			if (element.id == newRow.id) {
				userData.Records[index] = newRow;
				return false;
			}
		});
	},

	getGridRowJsonData: function (options, rowObject) {
		var gridSelector = "#" + options.gid;
		var rowData = rm.grid.rowData.getById(gridSelector, options.rowId);

		if (rowData == undefined || rowData == null) {
			rowData = rowObject;
		}

		return rowData;
	},

	getGridUserData: function (gridSelector) {
		return $(gridSelector).getGridParam('userData');
	},

	getGridRowUserData: function (gridSelector, rowId) {
		return $.qGrid.getGridRowDataById($.qGrid.getGridUserData(gridSelector).Records, rowId);
	},

	//Update calendar icon of the datepicker to show connected/disconnected image
	updateCalendarIcon: function (element) {
		setTimeout(function () {
			var gridSelector = "#" + $(element).closest("table").attr("id");
			var id = $(element).parent().parent().attr("id");
			var dateJson = rm.grid.rowData.getById(gridSelector, id);

			if (dateJson) {
				var dateStatusColumnName = element.name + "Status";
				var connected = dateJson[dateStatusColumnName].connected;
				if (dateJson[dateStatusColumnName].changeIcon) {
					var imageSrc = $.qGrid.qGridOptions.calendarIcon;

					if ($.q.isPpmConnectDisconnectApplicable(dateJson.RequestTypeId, dateJson.ResourceTypeId)) {
						imageSrc = (connected == 1 ? $.qGrid.qGridOptions.connectedPpmImageSrc : $.qGrid.qGridOptions.disconnectedPpmImageSrc);
					}
					else if ($.q.isCountryConnectDisconnectApplicable(dateJson.RequestTypeId, dateJson.ResourceTypeId)) {
						imageSrc = (connected == 1 ? $.qGrid.qGridOptions.connectedImageSrc : $.qGrid.qGridOptions.disconnectedImageSrc);
					}
					$(element).parent().find("img").attr("src", imageSrc);
				}
			}
		}, $.qGrid.qGridOptions.timeout);
	},

	showDateWithConnectIcon: function (cellvalue, options, rowObject) {
		var imageHtml = "";
		var rowJson = $.qGrid.getGridRowJsonData(options, rowObject);
		if (rowJson != undefined && rowJson != null) {
			var column = options.colModel.index;

			var connected = rowJson[column + "Status"].connected;
			var serviceUrl = rm.ajax.requestSvcUrl + "SubmittedRequest/ReconnectDate";
			var imageFactory = new $.imageFactory();

			imageHtml = " " + imageFactory.GetImage(rowJson.id, column, connected, rowJson.RequestTypeId, rowJson.ResourceTypeId, serviceUrl, "", rowJson.ParentRequestId);
		}
		else {
			return $.qGrid.qGridOptions.imageError;
		}

		return ($.trim(cellvalue.replace(/<img .*>/, "") + imageHtml));
	},

	//Unformat date, i.e remove img tag from cell value and just return date
	getUnformattedDate: function (cellvalue, options, cell) {
		var endIndex = cellvalue.indexOf(" <img");
		return $.trim((endIndex == -1) ? cellvalue : cellvalue.substr(0, endIndex));
	},

	//Get jsonObject from hidden column's cellValue
	getJsonFromHiddnColumn: function (options, rowObject, jsonHiddenColumn, gridSelector) {
		var rawRowData = $(gridSelector).getCell(options.rowId, jsonHiddenColumn);
		if (!rawRowData) {
			//If row is in read mode, raw data is available in rowObject 
			rawRowData = rowObject[0];
		}
		if (rawRowData === undefined) {
			//In search mode the data is accessible via different API
			rawRowData = rowObject[jsonHiddenColumn];
		}
		return (rawRowData === undefined) ? null : $.parseJSON(rawRowData);
	}
};

$.imageFactory = function () {
	imageFactoryOptions = {
		connectedImageSrc: "/_layouts/SPUI/images/conncted.png",
		disconnectedImageSrc: "/_layouts/SPUI/images/reconnect.png",
		connectedPpmImageSrc: "/_layouts/SPUI/images/ppmLinkIcon.png",
		disconnectedPpmImageSrc: "/_layouts/SPUI/images/ppmUnLinkIcon.png",
		connectedImageTitle: "The values for this date are connected to the country level values.",
		disconnectedImageTitle: "The values for this date are not connected to the country level values.",
		connectedPpmImageTitle: "This date is connected to the PPM milestone date.",
		disconnectedPpmImageTitle: "This date is not connected to the PPM milestone date.",
		spacerTag: "<img src='/_layouts/SPUI/images/spacer.gif' width='22' height='10' />",
		connectToPpmDate: rm.ajax.requestSvcUrl + "ReconnectToPpmDate",
		connectToCountryDate: rm.ajax.requestSvcUrl + "SubmittedRequest/ReconnectDate"

	};

	this.GetImage = function (id, column, connected, requestType, resourceType, serviceUrl, postData, parentRequestId) {
		var showCountryIcon = false;
		var showPpmIcon = false;

		if (resourceType && RequestType_E.Proposal != requestType) {
			if (resourceType != ResourceTypeName.SSV_Monitoring &&
					ResourceTypeDetails[resourceType].IsClinical &&
					(column == "StartDate" || column == "StopDate" || column == "IMDate" || column == "CRADate")) {
				showCountryIcon = true;
				showPpmIcon = false;
				serviceUrl = imageFactoryOptions.connectToCountryDate;
			}
			else if (resourceType == ResourceTypeName.SSV_Monitoring && (column == "StartDate" || column == "StopDate")) {
				showCountryIcon = true;
				showPpmIcon = false;
				serviceUrl = imageFactoryOptions.connectToCountryDate;
			}
			else if (ResourceTypeDetails[resourceType].IsOthers && (column == "StartDate" || column == "StopDate")) {
				showCountryIcon = false;
				showPpmIcon = true;
				serviceUrl = imageFactoryOptions.connectToPpmDate;
			}
			else if ((ResourceTypeDetails[resourceType].RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Monitoring ||
					ResourceTypeDetails[resourceType].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Monitoring ||
					ResourceTypeDetails[resourceType].RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Ssv ||
					ResourceTypeDetails[resourceType].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Ssv) &&
					(column == "StartDate" || column == "StopDate")) {
				showCountryIcon = true;
				showPpmIcon = false;
				serviceUrl = imageFactoryOptions.connectToCountryDate;
			}
			else if ((ResourceTypeDetails[resourceType].RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Project ||
					ResourceTypeDetails[resourceType].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Project) &&
				 (column == "StartDate" || column == "StopDate")) {
				showCountryIcon = false;
				showPpmIcon = true;
				serviceUrl = imageFactoryOptions.connectToPpmDate;
			}
			else if (resourceType == ResourceTypeName.Co_monitoring ||
				 resourceType == ResourceTypeName.Co_monitoring_NonSiteSpecific ||
				 resourceType == ResourceTypeName.Non_Standard_Monitoring_NonSiteSpecific ||
				 resourceType == ResourceTypeName.Non_Standard_Monitoring_SiteSpecific ||
				 resourceType == ResourceTypeName.Short_term_SWAT_Monitoring_OnSite_Visit ||
				 resourceType == ResourceTypeName.Short_term_SWAT_Monitoring_Phone_Visit ||
				 resourceType == ResourceTypeName.Co_monitoring_SiteSpecific) {
				showCountryIcon = false;
				showPpmIcon = false;
			}
		}
		else {
			showCountryIcon = false;
			showPpmIcon = false;
		}

		if (showCountryIcon) {
			return this.GetCountryConnectImage(id, column, connected, serviceUrl, postData, parentRequestId);
		}
		else if (showPpmIcon) {
			if (((column == 'StartDate') && ResourceTypeDetails[resourceType].ShowStartDateConnectDisconnectIcon) || ((column == 'StopDate') && ResourceTypeDetails[resourceType].ShowStopDateConnectDisconnectIcon))
				return this.GetPpmConnectImage(id, column, connected, serviceUrl, postData, parentRequestId);
			else
				return imageFactoryOptions.spacerTag;
		}
		else {
			return imageFactoryOptions.spacerTag;
		}
	};

	this.GetPpmConnectImage = function (id, column, connected, serviceUrl, postData, parentRequestId) {
		if (connected == 1) {
			return "<img src='" + imageFactoryOptions.connectedPpmImageSrc + "' " +
					"alt='" + column + id + "' " +
					"title='" + imageFactoryOptions.connectedPpmImageTitle + "' " +
					" class=\"connectDisconnectIcon\" />";
		}
		else {
			var onclickFunction = "";
			if (column == "StartDate" && parentRequestId && parentRequestId != -1) {
				onclickFunction = "alert(\"Start Date of the backfill request cannot be connect to PPM milestone date.\");";
			}
			else {
				onclickFunction = "ConnectMeToPpm(" + id + ",\"" + column + "\",\"" + serviceUrl + "\", \"" + postData.replace(/\"/gi, "\\\"") + "\");";
			}
			return "<img src='" + imageFactoryOptions.disconnectedPpmImageSrc + "' " +
				 "alt='" + column + id + "' class='connectDisconnectIcon' style='cursor: pointer;' " +
				 "title='" + imageFactoryOptions.disconnectedPpmImageTitle + "' " +
				 "onclick='" + onclickFunction + "' />";
		}
	};

	this.GetCountryConnectImage = function (id, column, connected, serviceUrl, postData, parentRequestId) {
		if (connected == 1) {
			return "<img src='" + imageFactoryOptions.connectedImageSrc + "' " +
					"alt='" + column + id + "' " +
					"title='" + imageFactoryOptions.connectedImageTitle + "' " +
					" class=\"connectDisconnectIcon\" />";
		} else {
			var onclickFunction = "";
			if (column == "StartDate" && parentRequestId && parentRequestId != -1) {
				onclickFunction = "alert(\"Start Date of the backfill request cannot be connect to PPM milestone date.\");";
			}
			else {
				onclickFunction = "ConnectMeToCountry(" + id + ",\"" + column + "\",\"" + serviceUrl + "\", \"" + postData.replace(/\"/gi, "\\\"") + "\");";
			}

			return "<img src='" + imageFactoryOptions.disconnectedImageSrc + "' " +
				 "alt='" + column + id + "' class='connectDisconnectIcon' style='cursor: pointer;' " +
				 "title='" + imageFactoryOptions.disconnectedImageTitle + "' " +
				 "onclick='" + onclickFunction + "' />";
		}
	};
	getRequestStopDateFromComputedRequestMilestone = function (resourceTypeId, regionId, startQDateString, stopDateJqElement) {
		var milestoneList = qrpmRmHelper.getComputedReqestMilestoneDaysToAdd();
		var stopDate = "";
		$.each(milestoneList, function (index, item) {
			if ((regionId > 0 && item.ResourceTypeId == resourceTypeId && item.RegionId == regionId) || item.ResourceTypeId == resourceTypeId) {
				rm.validation.clearError(stopDateJqElement)
				if (stopDate == "") stopDate = rm.date.addDaysToQdate(startQDateString, item.DaysToAdd);
			}
		});
		return stopDate;
	},

	ConnectMeToPpm = function (id, column, serviceUrl, postData) {
		if (confirm("By completing this action, the system will reconnect back to the PPM milestone date.")) {
			if (postData !== undefined) {
				if (postData != "" && postData.indexOf(",") != 0) {
					postData = "," + postData;
				}
			}
			else {
				postData = "";
			}
			$.ajax({
				type: "POST",
				contentType: "application/json; charset=utf-8",
				url: serviceUrl,
				data: '{"requestId":"' + id + '","column":"' + column + '"' + postData + '}',
				dataType: "text",
				success: function (response) { try { ConnectMeToPpmOnSuccess(response, id, column); } catch (ex) { alert("JavaScript function ConnectMeToPpmOnSuccess(response, id, column) not defined"); } },
				error: function (errMsg) { try { ConnectMeToPpmOnError(errMsg); } catch (ex) { alert("JavaScript function ConnectMeToPpmOnError(errMsg) not defined"); } }
			});
		}
	};

	ConnectMeToCountry = function (id, column, serviceUrl, postData) {
		if (confirm("By completing this action, the system will reconnect back to the country level values.")) {
			if (postData !== undefined) {
				if (postData != "" && postData.indexOf(",") != 0) {
					postData = "," + postData;
				}
			}
			else {
				postData = "";
			}
			$.ajax({
				type: "POST",
				contentType: "application/json; charset=utf-8",
				url: serviceUrl,
				data: '{"requestId":"' + id + '","column":"' + column + '"' + postData + '}',
				dataType: "text",
				success: function (response) { try { ConnectMeToCountryOnSuccess(response, id, column); } catch (ex) { alert("JavaScript function ConnectMeToCountryOnSuccess(response, id, column) not defined"); } },
				error: function (errMsg) { try { ConnectMeToCountryOnError(errMsg); } catch (ex) { alert("JavaScript function ConnectMeToCountryOnError(errMsg) not defined"); } }
			});
		}
	};
};

function GetStatusFromStatusString(statusString) {
	var status = "";
	if (statusString !== undefined && statusString != "") {
		status = statusString.split("|")[1];
	}
	return status;
}

$.formStatus = {
	//Sample object format
	//var jsonSelectorObject = { items : [{selector:"#ctelId input:text", dirtyAlertMessage : "Un-saved changes found."}] };
	bindDirty: function (alertMessage, jsonSelectorObject) {
		$.formStatus.clearDirty(jsonSelectorObject);

		window.onbeforeunload = function () {
			if ($.formStatus.isDirty(jsonSelectorObject)) {
				return (alertMessage);
			}
		};
	},

	//Sample object format
	//var jsonSelectorObject = { items : [{selector:"#ctelId input:text", dirtyAlertMessage : "Un-saved changes found."}] };
	isDirty: function (jsonSelectorObject) {
		var isFormDirty = false;
		$.each(jsonSelectorObject.items, function (index, value) {
			inputs = $(value.selector);
			$.each(inputs, function (key, input) {
				var type = $(input).attr("type");
				var tagName = $(input).prop("tagName").toLowerCase();

				if (type == "radio" || type == "checkbox") {
					if ($(input).data("initial") != $(input).is(":checked")) {
						isFormDirty = true;
						return false;
					}
				} else if (tagName == "a") {
					if ($(input).data("initial") != $(input).text()) {
						isFormDirty = true;
						return false;
					}
				}
				else if ($(input).data("initial") !== $(input).val()) {
					isFormDirty = true;
					return false;
				}
			});

			if (isFormDirty) {
				//rm.ui.messages.showSuccess(value.dirtyAlertMessage);
				return false;
			}
		});
		return isFormDirty;
	},

	clearDirty: function (jsonSelectorObject) {
		$.each(jsonSelectorObject.items, function (index, value) {
			var inputs = $(value.selector);
			$.each(inputs, function (key, input) {
				var type = $(input).attr("type");
				var tagName = $(input).prop("tagName").toLowerCase();

				if (type == "radio" || type == "checkbox") {
					$(input).data("initial", $(input).is(":checked"))
				}
				else if (tagName == "a") {
					$(input).data("initial", $(input).text())
				}
				else {
					$(input).data("initial", $(input).val());
				}
			});
		});
	},
	resetForm: function (jsonSelectorObject) {
		$.each(jsonSelectorObject.items, function (index, value) {
			var inputs = $(value.selector);
			$.each(inputs, function (key, input) {
				var type = $(input).attr("type");
				var tagName = $(input).prop("tagName").toLowerCase();

				if (type == "radio" || type == "checkbox") {
					$(input).prop("checked", $(input).data("initial"));
				}
				else if (tagName == "a") {
					$(input).text($(input).data("initial"));
				}
				else {
					$(input).val($(input).data("initial"));
				}
			});
		});
	}
};

$.validationHelper = {
	errorClass: "q_validation_error",
	validateRangeClass: ".validateRange",
	validateRangeSelector: ".validateRange:visible",
	ShowErrorMessages: function (validationErrors, gridSelector, iconColumnName) {
		$.each(validationErrors, function (index, ele) {
			var arrayMessagesfordialog = new Array();
			switch (ele.MessageType) {
				case MessageType_E.Error:
					rm.validation.addError(ele.Key, ele.Value);
					break;
				case MessageType_E.Warning:
					rm.ui.messages.addWarningWithCloseButton(ele.Value);
					break;
				case MessageType_E.AlertMessage:
					alert(ele.Value);
					break;
				case MessageType_E.SharepointNotification:
					rm.ui.messages.addError(ele.Value);
					break;
				case MessageType_E.GridIcon:
					rm.grid.showErrorIconInMessageColumn(gridSelector, ele.Key, iconColumnName, ele.Value);
					break;
				case MessageType_E.AlertMessageThenRefreshPage:
					window.onbeforeunload = null;
					alert(ele.Value);
					RefreshPage();
					return false;
					break;
				case MessageType_E.ConsolidateAndShowInDialog:
					arrayMessagesfordialog.push(ele.Value);
					break;
				case MessageType_E.CustomHandling:
					//Custom handling is done from code that make web service call
					break;
				default: alert("Invalid message type:" + ele.MessageType);
			}

			if (arrayMessagesfordialog.length > 0) {
				var htmlMessage = "<table class='validationTable'><tr class='headerRow'><td valign='top'>Validaton Error</td></tr>";
				$.each(arrayMessagesfordialog, function (index, message) {
					htmlMessage += "<tr><td>" + message + "</td></tr>";
				});
				htmlMessage += "</table>";
				rmCommon.showDialogWithOkButton("Error occured", htmlMessage, null);
			}
		});
	},

	IsFormValid: function () {
		return ($("." + rm.validation.errorClass).length == 0);
	},

	isAnyMilestoneDeactivated: false,

	GetCustomeMilestoneStatus: function (requestIds, milestoneIds, reloadPage, validateForAssignedRequest, DeletedMilestones) {
		var postData = { requestIds: requestIds, milestoneIds: milestoneIds, reloadPage: reloadPage, validateForAssignedRequest: validateForAssignedRequest, DeletedMilestones: DeletedMilestones };

		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.requestSvcUrl + "ValidateRequestHasDeactivatedMilestones",
			dataType: "json",
			async: false,
			data: JSON.stringify(postData),
			success: function (jsonData) {
				$.validationHelper.isAnyMilestoneDeactivated = jsonData.IsAnyMilestoneDeactivated;
				if ($.validationHelper.isAnyMilestoneDeactivated) {
					var reloadPage = jsonData.ReloadPage;
					var validationMessage = jsonData.ValidationMessage;
					alert(validationMessage);
					if (reloadPage) {
						window.onbeforeunload = null
						RefreshPage();
					}
				}
				else
					$.validationHelper.isAnyMilestoneDeactivated = false;
			},
			error: function (x, e) {
				$.validationHelper.isAnyMilestoneDeactivated = false;
				rm.ui.messages.addError('Failed to complete deactivated milestone validation');
			}
		});
	},

	isRequestWithSpecialAssignmentNeed: function (resourceTypeId, countryId) {
		var requestWithSpecialAssignmentNeed = false;

		$.each(CountryResourceTypeWithSpecialResourcingNeed, function (index, element) {
			if (element.CountryId == countryId && element.ResourceTypeId == resourceTypeId) {
				requestWithSpecialAssignmentNeed = true;
				return false;
			}
		});

		return requestWithSpecialAssignmentNeed;
	},

	bindMaxLengthForTextArea: function () {
		$.each($(".maxLengthForTextarea"), function (index, element) {
			var jqObject = $(element);

			if (!jqObject.attr("hasMaxLength")) {
				jqObject.attr("hasMaxLength", true);
				var container = $("<div>").insertBefore(jqObject);
				container.append(jqObject);
				$("<div class='CharLeftContainer'>Chars left: <span class='CharLeftValue'>" + jqObject.attr("maxLength") + "</span></div>").insertAfter($(element));
				setTimeout(function () { $.validationHelper.bindKeypressOnTextArea(jqObject); }, 10);
			}
		});
	},

	setCharactersLeftCount: function (jqObject) {
		jqObject.parent().find(".CharLeftValue").html(jqObject.attr("maxLength") - jqObject.val().length);
	},

	bindKeypressOnTextArea: function (jqObject) {
		jqObject.bind("keydown cut paste drop", function () {
			setTimeout(function () {
				var maxLength = jqObject.attr("maxLength");
				var maxLengthError = jqObject.attr("maxLengthError") || "";
				var blankValueError = jqObject.attr("blankValueError") || "";
				var currentContentLength = jqObject.val().length;
				jqObject.parent().find(".CharLeftValue").html(maxLength - currentContentLength);

				if (maxLength < currentContentLength) {
					maxLengthError = maxLengthError || "Maximum character limit: " + maxLength;
					rm.validation.addError(jqObject, maxLengthError);
				}
				else {
					if ($.trim(jqObject.val()) != "") {
						rm.validation.clearError(jqObject);
					}
					else if (blankValueError != "") {
						rm.validation.addError(jqObject, blankValueError);
					}
				}
			}, 10);
		});
	}
};

//Draw the FTE calculator image in the cell
ShowFteCalcImage = function (cellvalue, options, rowObject, rememberGridFilters) {
	var returnValue = "";
	if (rowObject != null) {
		if ((rowObject.RequestTypeId == RequestType_E.Proposal && ResourceTypeDetails[rowObject.ResourceTypeId].ProposalRequestSchedulerType == RequestSchedulerType_E.FlatFteValue) ||
				rowObject.ResourceTypeId == ResourceTypeName.Co_monitoring ||
				rowObject.ResourceTypeId == ResourceTypeName.Co_monitoring_NonSiteSpecific ||
				rowObject.ResourceTypeId == ResourceTypeName.Non_Standard_Monitoring_NonSiteSpecific ||
				rowObject.ResourceTypeId == ResourceTypeName.Global_RSUL ||
				rowObject.ResourceTypeId == ResourceTypeName.Non_DTE_CRA_Project_Country ||
				rowObject.ResourceTypeId == ResourceTypeName.Non_DTE_Pharmacy_CRA_Project_Country ||
				rowObject.ResourceTypeId == ResourceTypeName.DTE_CRA_Project_Country ||
				rowObject.ResourceTypeId == ResourceTypeName.Maintenance_Specialist ||
				rowObject.ResourceTypeId == ResourceTypeName.DTE_Pharmacy_CRA_Project_Country) {
			returnValue = (("<span class='infoIconAlignment'>" || "").indexOf("infoIconAlignment") == -1) ? ("<span class='infoIconAlignment'>" + cellvalue + "</span>") : cellvalue;
		}
		else {
			iconTitle = "";
			if (rowObject.RequestTypeId == RequestType_E.Initiate) {
				iconTitle = "Initiate Request FTE Calculator";
			}
			else if (rowObject.RequestTypeId == RequestType_E.SSV) {
				iconTitle = "SSV Request FTE Calculator";
			}
			else if (rowObject.RequestTypeId == RequestType_E.Permanent) {
				iconTitle = "Country Monitoring FTE Calculator";
			}
			returnValue = ShowEditRequestLink(rowObject, iconTitle, rememberGridFilters);
		}
		if (rowObject.RmPageLinkId == RmPageLink_E.SubmittedRequests) {
			var infoIcon = "<span style='vertical-align:middle;'><img src='/_layouts/SPUI/images/searchIcon.png' alt='InfoIcon' id='infoIcon_" + rowObject.id + "' class='iconPaddingRight infoFte' /></span>";
			returnValue = returnValue + infoIcon;

			if (rowObject.ResourceTypeId == ResourceTypeName.SSVMonitoring_CountrySpecific) {
				setInfoIconTooltip(rowObject.id, rowObject.MonthlyFTESSVAttrCountryLevel);
			}
			else {
				setInfoIconTooltip(rowObject.id, rm.utilities.getFteCalcInfoTextByResourceTypeId(rowObject.ResourceTypeId));
			}
		}
	}
	else {
		returnValue = "error";
	}
	return returnValue;
};

ShowEditRequestLink = function (rowObject, iconTitle, rememberGridFilters) {
	var iconClickFunction = rememberGridFilters ? "HandleCalculatorIconClick" : "";
	var imgHtml = "<img src='/_layouts/SPUI/images/{ICON_NAME}' alt='{ICON_TITLE}' style='cursor: pointer; padding-right:5px;' title='{ICON_TITLE}' />";
	var url = "/_layouts/SPUI/Requests/EditRequestNew.aspx?requestId=" + rowObject.id + "&rmPageLink=" + rowObject.RmPageLinkId;
	var finalHtml;
	if (rowObject.CalculatorIndicator == "1" || rowObject.CalculatorIndicator == "0") {
		var iconName = "";

		if (rowObject.ResourceTypeId == ResourceTypeName.Short_term_SWAT_Monitoring_OnSite_Visit || rowObject.ResourceTypeId == ResourceTypeName.Short_term_SWAT_Monitoring_Phone_Visit) {
			iconName = "CalculatorIcon.gif";
		}
		else {
			iconName = (rowObject.CalculatorIndicator == "1") ? "CalculatorIcon.png" : "brokenCalculatorIcon.png";
		}

		imgHtml = imgHtml.replace("{ICON_NAME}", iconName).replace(/{ICON_TITLE}/g, iconTitle);
	}

	if (iconClickFunction != "") {
		finalHtml = "<a href='javascript:void(0);' onclick='" + iconClickFunction + "(" + rowObject.id + ")'>" + imgHtml + "</a>";
	}
	else {
		finalHtml = "<a href='" + url + "'>" + imgHtml + "</a>";
	}
	return finalHtml;
};

function setInfoIconTooltip(objectID, informationText) {
	setTimeout(function () {
		var iconSelector = "[id$=infoIcon_" + objectID + "]";
		rm.qtip.showInfo(iconSelector, informationText, { width: '730' }, {});
		$(iconSelector).removeClass("ui-iconHide");
	}, 100);
}

var qrpmRmHelper = {
	_computedReqestMilestoneDaysToAddFor: null,
	getComputedReqestMilestoneDaysToAdd: function () {
		if (qrpmRmHelper._computedReqestMilestoneDaysToAddFor == null) {
			$.rm.Ajax_RequestSynchronous("GetAllComputedReqestMilestoneDaysToAdd", {}, function (data) {
				qrpmRmHelper._computedReqestMilestoneDaysToAddFor = data;
			}, true);
		}

		return qrpmRmHelper._computedReqestMilestoneDaysToAddFor;
	},
	setRequestStopDateFromComputedRequestMilestone: function (resourceTypeId, regionId, startQDateString, stopDateJqElement) {
		if (ResourceTypeDetails[resourceTypeId].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Request) {
			var milestoneList = qrpmRmHelper.getComputedReqestMilestoneDaysToAdd();
			$.each(milestoneList, function (index, item) {
				if ((ResourceTypeDetails[resourceTypeId].IsRegionBased > 0 && item.ResourceTypeId == resourceTypeId && item.RegionId == regionId) ||
						(!ResourceTypeDetails[resourceTypeId].IsRegionBased && item.ResourceTypeId == resourceTypeId)) {
					rm.validation.clearError(stopDateJqElement);
					stopDateJqElement.val(rm.date.addDaysToQdate(startQDateString, item.DaysToAdd));
					return false;
				}
			});
		}
	}
};
var editReq = {
	handleBackfillDeleteLinkClick: function (event) {
		event.stopPropagation();
		event.preventDefault();

		var lnkObj = $(this);
		var postData = { requestId: lnkObj.attr("requestId"), backfillDeleteOption: lnkObj.attr("backfillDeleteOption") };

		if (postData.backfillDeleteOption == BackfillDeleteOption_E.None) {
			rm.grid.clearSingleGridRowError("#list", "Message", postData.requestId);
		}
		else {
			$.rm.Ajax_Request("DeleteBackfillRequest", postData, editReq.handleBackfillDeleteResponse, false);
		}
	},

	handleBackfillDeleteResponse: function (response) {
		if (response.IsSuccessful) {
			rm.grid.removeRow("#list", response.EntityId);
			rm.ui.messages.showSuccess('Request deleted successfully.');
			rm.serviceCalls.getRequestCounts();
		}
		else {
			rm.grid.showErrorIconInMessageColumn('#list', response.EntityId, 'Message', response.Message);
		}
	}
};