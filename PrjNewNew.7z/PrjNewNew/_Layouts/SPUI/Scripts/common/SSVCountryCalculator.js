﻿
var SSVCountryCalculatorNs = {
	//_resourceTypeId: -1,
	//_countryId: -1,
	//_startDate: "",
	//_stopDate: "",
	//_FTE: 0,
	//_totalHours: 0,
	//_interimFrequencyEnabled: false,
	//_calculateDuration: false,
	//_requestId: null,
	resourceTypeSelector: "#ddlResourceType",
	countrySelector: "#ddlCountry",
	startDateSelector: "#txtStartDate",
	stopDateSelector: "#txtStopDate",
	totalSitesSelector: "#ssvCountry_Calc_txtTotalSites",
	totalHoursSelector: "#ssvCountry_Calc_txtTotalHours",
	TotalHoursPerSite: "#ssvCountry_Calc_txtTotalHoursPerSite",
	calculatorTitle: "#SSVCountryCalculatorTitle",
	dirtyCalculatorSelector: "#isDirtyCalculatorSmall",
	monthlyFteSelector: "#SSVCountry_Calc_SpanMonthlyFTE",
	totalFTESelector: "#SSVCountry_Calc_SpanTotalFTE",
	monthlyFtePerSiteSelector: "#SSVCountry_Calc_SpanMonthlyFTEPerSite",

	isValidRequest: function () {
		var isValid = true;

		if ($(SSVCountryCalculatorNs.resourceTypeSelector).val() != -1 &&
			$(SSVCountryCalculatorNs.countrySelector).val() != -1 &&
			$.trim($(SSVCountryCalculatorNs.startDateSelector).val()) != "" &&
			$.trim($(SSVCountryCalculatorNs.stopDateSelector).val()) != "" &&
			$.trim($(SSVCountryCalculatorNs.totalHoursSelector).val()) > 0 &&
			$.trim($(SSVCountryCalculatorNs.totalSitesSelector).val()) > 0 &&
			$.trim($(SSVCountryCalculatorNs.TotalHoursPerSite).val()) > 0
		   ) {
			if (rm.date.isDateValid($(SSVCountryCalculatorNs.startDateSelector).val(), false) && rm.date.isDateValid($(SSVCountryCalculatorNs.stopDateSelector).val(), false)) {
				var startDate = rm.date.getDateFromQDateString($(SSVCountryCalculatorNs.startDateSelector).val());
				var stopDate = rm.date.getDateFromQDateString($(SSVCountryCalculatorNs.stopDateSelector).val());

				if (startDate > stopDate) {
					rm.validation.addError(SSVCountryCalculatorNs.startDateSelector, Resources.StartDateGreaterThanStopDate);
					rm.validation.addError(SSVCountryCalculatorNs.stopDateSelector, Resources.StopDateLessThanStartDate);
					isValid = false;
				}
			}
			else {
				isValid = false;
			}
		}
		else {
			isValid = false;
		}

		return isValid;
	},
	isInterimFrequencyButtonEnabled: function () {
		return SSVCountryCalculatorNs._interimFrequencyEnabled;
	},
	//TODO:refactor
	renderCalculator: function (requestId, projectId, resourceId, countryId, calculatorTitle) // AI: do not remove this parameter, it may be in used in next stories.
	{
		SSVCountryCalculatorNs._requestId = requestId;
		$(SSVCountryCalculatorNs.calculatorTitle).html(calculatorTitle);
	},

	save: function () {
		return SSVCountryCalculatorNs.isValidRequest();
	},

	ClearCalculatorDirty: function () { $(SSVCountryCalculatorNs.dirtyCalculatorSelector).val('False'); },

	IsValid: function () {
		return SSVCountryCalculatorNs.isValidRequest();
	},

	CalculateTotalFTE: function () {
		if (SSVCountryCalculatorNs.IsValid()) {
			$(SSVCountryCalculatorNs.dirtyCalculatorSelector).val('True');

			var postData =
			{
				resourceTypeId: $(SSVCountryCalculatorNs.resourceTypeSelector).val(),
				countryId: $(SSVCountryCalculatorNs.countrySelector).val(),
				startDate: $(SSVCountryCalculatorNs.startDateSelector).val(),
				stopDate: $(SSVCountryCalculatorNs.stopDateSelector).val(),
				modifiedWeeklyHoursFTE: $(SSVCountryCalculatorNs.totalHoursSelector).val(),
				hoursPerSite: $(SSVCountryCalculatorNs.TotalHoursPerSite).val(),

			};
			$.rm.Ajax_Utility("CalculateFTE", postData, function (data) {
				$(SSVCountryCalculatorNs.monthlyFteSelector).html(data.MonthlyFTE);
				$(SSVCountryCalculatorNs.totalFTESelector).html(data.TotalFTE);
				$(SSVCountryCalculatorNs.monthlyFtePerSiteSelector).html(data.MonthlyFTEPerSite);
			}, true, false);

		}
	},
	ClearCalculator: function () {
		$(SSVCountryCalculatorNs.monthlyFteSelector).html("");
		$(SSVCountryCalculatorNs.totalFTESelector).html("");
		$(SSVCountryCalculatorNs.monthlyFtePerSiteSelector).html("");
		$(SSVCountryCalculatorNs.totalHoursSelector).val("");
		$(SSVCountryCalculatorNs.totalSitesSelector).val("");
		$(SSVCountryCalculatorNs.TotalHoursPerSite).val("");

		//$("#SSVCountry_Calc_SpanTotalHours").empty();
		//rm.validation.clearError($("#SSVCountry_Calc_SpanMonthlyFTE"));
	},

	SetCalculatorValues: function (FTE, totalHours, totalHoursPerSite, totalSites, totalFte, monthlyFTEPerSite) {
		$(SSVCountryCalculatorNs.monthlyFteSelector).html(FTE);
		$(SSVCountryCalculatorNs.totalFTESelector).html(totalFte);
		$(SSVCountryCalculatorNs.totalHoursSelector).val(totalHours);
		$(SSVCountryCalculatorNs.totalSitesSelector).val(totalSites);
		$(SSVCountryCalculatorNs.TotalHoursPerSite).val(totalHoursPerSite);
		$(SSVCountryCalculatorNs.monthlyFtePerSiteSelector).html(monthlyFTEPerSite);
		//$("#SSVCountry_Calc_SpanTotalHours").html(totalHours);
	},

	GetValues: function () {
		return (
		{
			TotalSites: $.trim($(SSVCountryCalculatorNs.totalSitesSelector).val()) != "" ? $(SSVCountryCalculatorNs.totalSitesSelector).val() : "0",
			TotalHours: $.trim($(SSVCountryCalculatorNs.totalHoursSelector).val()) != "" ? $(SSVCountryCalculatorNs.totalHoursSelector).val() : "0",
			FTE: $.trim($(SSVCountryCalculatorNs.monthlyFteSelector).html()) != "" ? $(SSVCountryCalculatorNs.monthlyFteSelector).html() : "0",
			TotalHoursPerSite: $.trim($(SSVCountryCalculatorNs.TotalHoursPerSite).val()) != "" ? $(SSVCountryCalculatorNs.TotalHoursPerSite).val() : "0",
		});
	},
	CalculateTotalHoursPerSite: function (sites, totalHours) {
		if (sites > 0 && totalHours > 0) {
			$(SSVCountryCalculatorNs.TotalHoursPerSite).val((totalHours / sites).toFixed(2));
		}
		else {
			$(SSVCountryCalculatorNs.TotalHoursPerSite).val("0");
		}
		SSVCountryCalculatorNs.CalculateTotalFTE();
	},
	CalculateTotalHours: function (sites, totalHoursPerSite) {
		if (sites > 0 && totalHoursPerSite > 0) {
			$(SSVCountryCalculatorNs.totalHoursSelector).val((sites * totalHoursPerSite).toFixed(2));
		}
		else {
			$(SSVCountryCalculatorNs.totalHoursSelector).val("0");
		}
		SSVCountryCalculatorNs.CalculateTotalFTE();
	},
};
$(document).ready(function () {
	$(SSVCountryCalculatorNs.totalSitesSelector).on('change', function (event) {
		$(SSVCountryCalculatorNs.dirtyCalculatorSelector).val('True');
		$.q.formatText(this);
		SSVCountryCalculatorNs.CalculateTotalHoursPerSite($(SSVCountryCalculatorNs.totalSitesSelector).val(), $(SSVCountryCalculatorNs.totalHoursSelector).val());
		SSVCountryCalculatorNs.CalculateTotalHours($(SSVCountryCalculatorNs.totalSitesSelector).val(), $(SSVCountryCalculatorNs.TotalHoursPerSite).val());
	});
	$(SSVCountryCalculatorNs.TotalHoursPerSite).on('change', function (event) {
		$(SSVCountryCalculatorNs.dirtyCalculatorSelector).val('True');
		$.q.formatText(this);
		SSVCountryCalculatorNs.CalculateTotalHours($(SSVCountryCalculatorNs.totalSitesSelector).val(), $(SSVCountryCalculatorNs.TotalHoursPerSite).val());
	});
	$(SSVCountryCalculatorNs.totalHoursSelector).on('change', function (event) {
		$(SSVCountryCalculatorNs.dirtyCalculatorSelector).val('True');
		$.q.formatText(this);
		SSVCountryCalculatorNs.CalculateTotalHoursPerSite($(SSVCountryCalculatorNs.totalSitesSelector).val(), $(SSVCountryCalculatorNs.totalHoursSelector).val());
	});
});