﻿//MR: superceded by v1.01

/**
* This is really a 0.1alpha release of this as I've never really writtena plug-in from scratch, so I'm sure I'm screwing up some of the
* core cnocepts (99% sure I am with some of my helper funtions and my 'oneclick_settingsMapping' variable!). But it's a first go
*
* This widget will show a list of selected and unselected options. The idea if you click ones (hence the name 'oneclick') to turn a item 
* from selected to unselected and vice-versa. You can also have a parent/child relationship and if the parent is unselected, all children
* are redacted from the child list. For example, Region->Subregion->Country. You can have an unlimited number of levels.
*
* Currently, the setup is split between the options you pass when you create the object and properies in the JSON object. I might get smarter
* later with that ...
*
* Todos (in no order):
*		- Think about letting the user use a <SELECT> box and "convert" like some some of the other libraries do.
*		- Combine where options are set ('options' or in the data arary?)
*		- Add some event handling so an external call can update the underlying lists
*		- Support jquery.DirtyForm
*		- Add support to preserve selected items between page refreshes (via cookies)
*
* Usage:
*		$('#MyDiv').oneclick({ label: 'My Label', data: myDataArray, position: 'first'});
*
* Required Libraries:
*		TBD
*
* Good to have ones:
*		jquery-ui
*
* @author Colin B. Boatwright
* @date 22/SEP/2011
*/

/*
Matt thoughts:

- the 2 this. variables have no scope within the plugin and so need to be moved
- how do I add a slider bar to this??
*/

this.oneclick_settingsMapping = new Array();
this.count = 0;

(function ($)
{
  $.fn.oneclick = function (options)
  {
    var settings =
		{
		  label: null, 					// What is shown on the screen
		  showLabel: true, 				//
		  showNoneSelected: false,
		  showNoneSelectedLabel: 'None Selected',
		  name: null, 						// The 'behind-the-scenes' name ... defaults to same as 'label'
		  maxSelected: '-1', 			// -1 means there is no max
		  classes: '', 					// 
		  headerClasses: '', 			//
		  header: 'span', 				// 
		  position: 'last', 			// valid values are 'last' or 'first'
		  data: null, 						// The JSON object with a 'items' list
		  ajaxDataUrl: null,
		  dataNameProperty: 'name', 	//
		  dataIdProperty: 'Id', 		//
		  parentData: null, 				// Does this oneclick's data have a parent? Must also be in the same JSON format as 'data'
		  redactBasedOnParent: false, // Should this oneclick redact (not show) children elements in another oneclick?
		  dialogBox:
      {
        enabled: false,
        modal: true,
        cache: false,
        title: '',
        resizable: false,
        width: 560,
        height: 550,
        position: [200, 300],
        close: null,
        open: null,
        beforeClose: null
      },
		  speechBubble: {
		    enabled: false,
		    selected: false,
		    unselected: false,
		    contentId: '',
		    contentKey: '',
		    titleKey: 'name'
		  },
		  styles: {
		    table_selected: 'oneclick_table_selected',
		    table_unselected: 'oneclick_table_unselected',
		    table_row: 'oneclick_row',
		    table_cell: 'oneclick_cell',
		    table_label: 'oneclick_label',
		    expander_bar: 'oneclick_expander_bar'
		  },
		  events: {
		    onSelect: function (settings, item) { },
		    onDeselect: function (settings, item) { }
		  }
		};

    if (options)
    {
      $.extend(settings, options);
    }

    if (settings.name == null)
    {
      settings.name = settings.label;
    }

    // Clean up the settings ...
    settings.name = settings.name.replace(/[^A-Za-z0-9 ]+/g, "").replace(/\s/g, "");
    settings.maxSelected = (isNaN(parseInt(settings.maxSelected)) ? -1 : settings.maxSelected);
    settings.redactBasedOnParent = (settings.redactBasedOnParent || settings.redactBasedOnParent == 'true' || settings.redactBasedOnParent == '1') ? true : false;

    // More error checking
    if (oneclick_settingsMapping[settings.name] != undefined)
    {
      alert('You cannot have more than one OneClick with the name [' + settings.name + ']');
      return false;
    }

    // Store away the settings. Can't seem to get the jQuery'.data(...)' method tow work, probably because properties are not quoted?
    oneclick_settingsMapping[settings.name] = settings;

    var me = this;
    if (settings.ajaxDataUrl != null)
    {
      $.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: settings.ajaxDataUrl,
        dataType: "text",
        success: function (result)
        {
          var data = { items: [] };
          data.items = eval($.parseJSON(result));

          settings.data = data;
          $.fn.oneclick.processOneClick(settings, me)
        },
        error: function (errMsg) { }
      });
    }
    else
    {
      return me.each(function () { $.fn.oneclick.processOneClick(settings, me) });
    }
  };

  $.fn.oneclick.processOneClick = function (settings, oneClickObj)
  {
    aId = 'oneclick_' + settings.name;
    var html =
			'<div id="' + aId + '" class="' + settings.classes + '">' +
			((settings.showLabel) ? ('   <' + settings.header + ' style="width:99%" class="' + settings.headerClasses + '">' + settings.label + '</' + settings.header + '>') : '') +
			'   <div id="oneclick_' + settings.name + '" >' +
			'         <div id="oneclick_selected_' + settings.name + '" class="' + settings.styles.table_selected + '"></div>' +
			'         <div id="oneclick_bar_' + settings.name + '" class="' + settings.styles.expander_bar + ' oneclick_expander_bar_down">&nbsp;</div>' +
			'         <div id="oneclick_unselected_' + settings.name + '" class="' + settings.styles.table_unselected + '" expanded="false"></div>' +
			'   </div>' +
			'</div>';
    if (settings.position == 'last')
    {
      $(oneClickObj).append(html);
    }
    else
    {
      $(oneClickObj).prepend(html);
    }

    //expand or collapse the options below the expander bar
    $('#oneclick_bar_' + settings.name).click(function ()
    {
      if ($('#oneclick_unselected_' + settings.name).attr('expanded') == "false")
      {
        $(this).removeClass('oneclick_expander_bar_down');
        $(this).addClass('oneclick_expander_bar_up');
        $('#oneclick_unselected_' + settings.name).slideDown('fast', function ()
        {
          $('#oneclick_unselected_' + settings.name).attr('expanded', "true");
        });
      }
      else
      {
        $(this).addClass('oneclick_expander_bar_down');
        $(this).removeClass('oneclick_expander_bar_up');

        $('#oneclick_unselected_' + settings.name).slideUp('fast', function ()
        {
          $('#oneclick_unselected_' + settings.name).attr('expanded', "false")
        });
      }
    });

    $.fn.oneclick.populateItems(settings, true);
  }

  $.fn.oneclick.isParentSelected = function (parentDataArray, searchId)
  {
    var rv = false;

    if (parentDataArray != undefined)
    {
      var searchIdIsArray = (typeof searchId.length === "number"); //.isArray is expensive according to JS profiler

      for (var x = 0; x < parentDataArray.items.length; x++)
      {
        if (searchIdIsArray)
        {
          for (var xx = 0; xx < searchId.length; xx++)
          {
            if (parentDataArray.items[x].Id == searchId[xx])
            {
              rv = parentDataArray.items[x].selected;
            }

            if (rv)
            {
              break;
            }
          }
        }
        else if (parentDataArray.items[x].Id == searchId)
        {
          rv = parentDataArray.items[x].selected;
        }

        if (rv)
        {
          break;
        }
      }
    }

    return rv;
  }

  $.fn.oneclick.populateItems = function (settings, isFirstRun)
  {
    var name = settings.name;
    var dataArray = settings.data;
    var showNoneSelected = settings.showNoneSelected;
    $('#oneclick_unselected_' + name).html("");
    $('#oneclick_selected_' + name).html("");

    if (showNoneSelected)
    {
      for (var x = 0; x < dataArray.items.length; x++)
      {
        if (dataArray.items[x].selected)
        {
          showNoneSelected = false;
          break;
        }
      }

      //MR: why check this again??
      if (showNoneSelected)
      {
        var row = '<div id="' + IdPrefix + '_row" class="' + settings.styles.table_row + '" style="text-align:center">';
        row += '<div class="' + settings.styles.table_cell + '" style="width:25px"></div>';
        row += '<div class="' + settings.styles.table_label + '">' + settings.showNoneSelectedLabel + '</div>';
        $('#oneclick_selected_' + name).append(row);
      }
    }

    var redactBasedOnParent = settings.redactBasedOnParent && settings.parentData != undefined && settings.parentData != null;
    for (var x = 0; x < dataArray.items.length; x++)
    {
      var isParentSelected = redactBasedOnParent && $.fn.oneclick.isParentSelected(settings.parentData, dataArray.items[x].parentId);
      //if (count++ < 5) alert('dataArray.name=' + dataArray.name + ', isParentSelected=' + isParentSelected + ', dataArray.items[x].parentId=' + dataArray.items[x].parentId);
      if (redactBasedOnParent == false || (redactBasedOnParent && isParentSelected))
      {
        var IdPrefix = name + dataArray.items[x][settings.dataIdProperty];
        var useSpeechBubble = (settings.speechBubble &&
												settings.speechBubble.enabled &&
												((settings.speechBubble.selected && dataArray.items[x].selected) ||
												 (settings.speechBubble.unselected && !dataArray.items[x].selected)));

        var row = '<div id="' + IdPrefix + '_row" class="' + settings.styles.table_row + '">';
        row += '<div class="' + settings.styles.table_cell + '" style="width:25px" title="' + dataArray.items[x][settings.dataNameProperty] + '">';
        row += '<input index=' + x + ' oneclick="' + settings.name + '" id="' + IdPrefix + '_checkbox" type="checkbox" ';
        if (dataArray.items[x].selected)
        {
          row += 'checked="true" onclick="return $.fn.oneclick.removeItem';
        }
        else
        {
          row += 'onclick="return $.fn.oneclick.addItem';
        }
        row += '($(this))"/></div>';
        //				row += '<div class="oneclick_cell"';
        row += '<div id="' + IdPrefix + '_label' + '" class="' + settings.styles.table_label + '"';
        if (useSpeechBubble == false)
        {
          row += ' title="' + dataArray.items[x][settings.dataNameProperty] + '"';
        }
        row += '><label>' + dataArray.items[x][settings.dataNameProperty] + '</label></div>';
        row += '</div>';

        //if (count++ < 5) alert(dataArray.items[x][settings.dataNameProperty] + '=' + dataArray.items[x].selected);
        if (dataArray.items[x].selected)
        {
          $('#oneclick_selected_' + name).append(row);
        }
        else
        {
          $('#oneclick_unselected_' + name).append(row);
        }

        //TODO: MR: too specific, need to generalize some more...
        if (settings.dialogBox.enabled)
        {
          var eventName = "click";
          var projectId = dataArray.items[x][settings.dataIdProperty];
          var projectName = dataArray.items[x][settings.dataNameProperty];
          var divId = '#hoverTip_' + projectId;
          var dataKey = "MSAData_" + projectId;
          var dialogContainerId = "#dialogContainer";

          //MR: have to pass in event data or closure remembers only the last item associated with a dialog box
          $('#' + IdPrefix + '_label').bind(eventName, { dId: divId, dKey: dataKey, pName: projectName }, function (event)
          {
            var html = $(event.data.dId).data(event.data.dKey);
            $(dialogContainerId).html(html.HtmlString).dialog({
              modal: settings.dialogBox.modal,
              cache: settings.dialogBox.cache,
              title: settings.dialogBox.title + " - " + event.data.pName,
              resizable: settings.dialogBox.resizable,
              width: settings.dialogBox.width,
              height: settings.dialogBox.height,
              position: settings.dialogBox.position,
              close: settings.dialogBox.close,
              beforeClose: settings.dialogBox.beforeClose

            });
            settings.dialogBox.open();   //why is this not just the 'open' callback??
          }).addClass("cursorPointer");
        }

        if (useSpeechBubble)
        {
          $('#' + IdPrefix + '_row').qtip({
            content: {
              //dataArray.items[x][settings.dataIdProperty]
              //MR: SIGH: Can't do this because element does not exist yet!
              text: $('#' + settings.speechBubble.contentId + dataArray.items[x][settings.dataIdProperty]).clone(),
              //text: settings.speechBubble.contentId + dataArray.items[x][settings.dataIdProperty],

              //text: $('#' + settings.speechBubble.contentId).clone(),
              title: {
                text: (settings.speechBubble.titleKey) ? eval('dataArray.items[x].' + settings.speechBubble.titleKey) : dataArray.items[x][settings.dataIdProperty],
                button: 'Close'
              }
            },
            show: {
              event: 'mouseenter',
              effect: function (offset) { $(this).slideDown(100); }
            },
            hide: {
              fixed: true
            },
            position: {
              my: 'left center',
              at: 'right center'
            }
          });
        }
      }
      else
      {
        dataArray.items[x].selected = false;
      }
    }

    // Either save away a parent's child settings (if first run) or use the child settings to rebuild the children based on how
    // the parent was just rebuilt. This allows a parent to seek out its own children
    if (isFirstRun)
    {
      if (settings.parentData != null &&
					settings.parentData != undefined &&
					(settings.parentData.childSettings == undefined ||
					 settings.parentData.childSettings == null ||
					 settings.parentData.childSettings[settings.name] == undefined ||
					 settings.parentData.childSettings[settings.name] == null))
      {
        if (settings.parentData.childSettings == undefined || settings.parentData.childSettings == null)
        {
          settings.parentData.childSettings = [];
        }

        settings.parentData.childSettings[settings.name] = settings;
      }
    }
    else if (settings.data.childSettings != undefined && settings.data.childSettings != null)
    {
      var childSettings = settings.data.childSettings;
      for (var x in childSettings)
      {
        $.fn.oneclick.populateItems(childSettings[x], false);
      }
    }
  }

  // Can't seem to get the jQuery .data(...) method to work ... so using a map instead
  $.fn.oneclick.getSettings = function (name)
  {
    return oneclick_settingsMapping[name];
  }

  //...  overwrite the data associated with this instance of the plugin
  $.fn.oneclick.setData = function (name, newData)
  {
    oneclick_settingsMapping[name].data = newData;
  }

  //Add an item to the list ABOVE the expander bar and mark it as selected
  $.fn.oneclick.addItem = function (item)
  {
    var settings = $.fn.oneclick.getSettings(item.attr('oneclick'));
    var rv = true;
    var index = item.attr('index');
    var currentSelected = -2;

    // A maxSelected of 0 or less will cause this to skip, best practive is to set to '-1' to mean "unlimited"
    if (settings.maxSelected > 0)
    {
      currentSelected = 0;
      for (var x = 0; x < settings.data.items.length; x++)
      {
        if (settings.data.items[x].selected)
        {
          currentSelected++;
        }
      }

      // So if we added one more, would it still be equal to or less than our max?
      rv = ((currentSelected + 1) <= settings.maxSelected);
    }

    if (rv)
    {
      settings.data.items[index].selected = true;
      $.fn.oneclick.populateItems(settings, false);
    }
    else
    {
      alert("This list is limited to " + settings.maxSelected + " items selected at once");
    }


    return rv && settings.events.onSelect(settings, item);
  };

  //Remove an item from the list ABOVE the expander bar and mark it as unselected
  $.fn.oneclick.removeItem = function (item)
  {
    var settings = $.fn.oneclick.getSettings(item.attr('oneclick'));
    var index = item.attr('index');

    settings.data.items[index].selected = false;
    $.fn.oneclick.populateItems(settings, false);

    return settings.events.onDeselect(settings, item);
  };
})(jQuery);

