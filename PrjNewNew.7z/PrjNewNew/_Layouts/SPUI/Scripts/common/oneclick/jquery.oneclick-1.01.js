﻿/**
* This is really a 0.1alpha release of this as I've never really writtena plug-in from scratch, so I'm sure I'm screwing up some of the
* core cnocepts (99% sure I am with some of my helper funtions and my 'oneclick_settingsMapping' variable!). But it's a first go
*
* This widget will show a list of selected and unselected options. The idea if you click ones (hence the name 'oneclick') to turn a item 
* from selected to unselected and vice-versa. You can also have a parent/child relationship and if the parent is unselected, all children
* are redacted from the child list. For example, Region->Subregion->Country. You can have an unlimited number of levels.
*
* Currently, the setup is split between the options you pass when you create the object and properies in the JSON object. I might get smarter
* later with that ...
*
* Todos (in no order):
*		- Think about letting the user use a <SELECT> box and "convert" like some some of the other libraries do.
*		- Combine where options are set ('options' or in the data arary?)
*		- Add some event handling so an external call can update the underlying lists
*		- Support jquery.DirtyForm
*		- Add support to preserve selected items between page refreshes (via cookies)
*
* Usage:
*		$('#MyDiv').oneclick({ label: 'My Label', data: myDataArray, position: 'first'});
*
* Required Libraries:
*		TBD
*
* Good to have ones:
*		jquery-ui
*
* @author Colin B. Boatwright
* @date 22/SEP/2011
*/

// Changes: 07-SEP-2011
// MR: Refactored into recommended jQuery plugin pattern

/*
Matt thoughts:

- TODO: oneclick_settingsMapping can be moved and kept as data member
- DONE: add a slider bar to the selectable options
- TODO: save the min/max value for ranged skills
*/

this.oneclick_settingsMapping = [];

(function ($) {

	var methods = {
		//init runs when no valid methodname is sent to the plugin and thus all paramaters are considered options
		init: function (options) {
			var settings =
		  {
		  	label: null, 					// What is shown on the screen
		  	showLabel: true, 				//
		  	showNoneSelected: false,
		  	showNoneSelectedLabel: 'None Selected',
		  	includeSlider: false,
		  	Name: null, 						// The 'behind-the-scenes' Name ... defaults to same as 'label'
		  	maxSelected: '-1', 			// -1 means there is no max
		  	classes: '', 					// 
		  	headerClasses: '', 			//
		  	header: 'span', 				// 
		  	position: 'last', 			// valid values are 'last' or 'first'
		  	data: null, 						// The JSON object with a 'items' list
		  	ajaxDataUrl: null,
		  	dataNameProperty: 'Name', 	//
		  	dataIdProperty: 'Id', 		//
		  	parentData: null, 		//MR: Do not pass this in, pass in the Key instead		// Does this oneclick's data have a parent? Must also be in the same JSON format as 'data'
		  	parentDataKey: null,
		  	redactBasedOnParent: false, // Should this oneclick redact (not show) children elements in another oneclick?
		  	dialogBox:
        {
        	enabled: false,
        	modal: true,
        	cache: false,
        	title: '',
        	resizable: false,
        	width: 560,
        	height: 550,
        	position: [200, 300],
        	close: null,
        	open: null,
        	beforeClose: null,
        	eventName: 'click',
        	divIdPrefix: '#GenerichoverTip_',
        	dataKeyPrefix: 'GenericData',
        	dialogContainerId: '#GenericdialogContainer'
        },
		  	speechBubble: {
		  		enabled: false,
		  		selected: false,
		  		unselected: false,
		  		contentId: '',
		  		contentKey: '',
		  		titleKey: 'Name'
		  	},
		  	styles: {
		  		table_selected: 'oneclick_table_selected',
		  		table_unselected: 'oneclick_table_unselected',
		  		table_row: 'oneclick_row',
		  		table_cell: 'oneclick_cell',
		  		table_label: 'oneclick_label',
		  		expander_bar: 'oneclick_expander_bar',
		  		custom_style_attribute: 'style'
		  	},
		  	events: {
		  		onSelect: function (settings, item) { },
		  		onDeselect: function (settings, item) { },
		  		onRangeChange: function (settings, item) { }
		  	}
		  };

			//Bind Qtip
			rm.qtip.showInfo(".searchNavigationRMDefinedCriteriaTitle", "Nothing selected.");
			$("#h3JobGrade").attr("title", jobGrades[0] + " ... " + jobGrades[jobGrades.length - 1]);

			//maintain chainability
			return this.each(function () {
				//Override any options sent in through constructor
				if (options) {
					$.extend(true, settings, options);   //MR: perform deep merge instead

					//So we can chain together dependent oneclick objects
					if (settings.parentDataKey !== null) {
						settings.parentData = $.fn.oneclick('getSettings', settings.parentDataKey).data;
					}
				}

				var me = $(this);

				//Initialization of plugin goes here...
				if (settings.Name == null) {
					settings.Name = settings.label;
				}

				// Clean up the settings ...
				// MR: I think this strips out any spaces in the Name
				settings.Name = settings.Name.replace(/[^A-Za-z0-9 ]+/g, "").replace(/\s/g, "");

				settings.maxSelected = (isNaN(parseInt(settings.maxSelected)) ? -1 : settings.maxSelected);
				settings.redactBasedOnParent = (settings.redactBasedOnParent || settings.redactBasedOnParent == 'true' || settings.redactBasedOnParent == '1') ? true : false;

				// More error checking
				if (oneclick_settingsMapping[settings.Name] != undefined) {
					alert('You cannot have more than one OneClick with the Name [' + settings.Name + ']');
					return false;
				}

				//TODO: MR: Store away the settings. Can't seem to get the jQuery'.data(...)' method to work, probably because properties are not quoted?
				oneclick_settingsMapping[settings.Name] = settings;

				if (settings.ajaxDataUrl != null) {
					//Load the settings via AJAX...  db driven...
					$.ajax({
						type: "GET",
						contentType: "application/json; charset=utf-8",
						url: settings.ajaxDataUrl,
						dataType: "text",
						success: function (result) {
							var data = { items: [] };
							data.items = result;

							settings.data = data;
							$(this).oneclick('processOneClick', settings, me);
						},
						error: function (errMsg) { }
					});
				}
				else {
					//Typical pattern so far
					$(this).oneclick('processOneClick', settings, me);
				}

			});
		},

		//Attach oneclick to the DOM element
		processOneClick: function (settings, oneClickObj) {
			aId = 'oneclick_' + settings.Name;
			var html =
			'<div id="' + aId + '" class="' + settings.classes + '">' +
			((settings.showLabel) ? ('   <' + settings.header + ' style="width:99%" class="' + settings.headerClasses + '">' + settings.label + '</' + settings.header + '>') : '') +
			'   <div id="oneclick_' + settings.Name + '" >' +
			'         <div id="oneclick_selected_' + settings.Name + '" class="' + settings.styles.table_selected + '"></div>' +
			//			'         <div id="oneclick_bar_' + settings.Name + '" class="' + settings.styles.expander_bar + ' oneclick_expander_bar_down">&nbsp;</div>' +
			//			'         <div id="oneclick_unselected_' + settings.Name + '" class="' + settings.styles.table_unselected + '" expanded="false"></div>' +
			'         <div id="oneclick_bar_' + settings.Name + '" class="' + settings.styles.expander_bar + ' oneclick_expander_bar_up">&nbsp;</div>' +
			'         <div id="oneclick_unselected_' + settings.Name + '" class="' + settings.styles.table_unselected + '" expanded="true"></div>' +
			'   </div>' +
			'</div>';
			if (settings.position == 'last') {
				$(oneClickObj).append(html);
			}
			else {
				$(oneClickObj).prepend(html);
			}

			if ($('#oneclick_unselected_' + settings.Name).attr('expanded') == "true") {
				$('#oneclick_unselected_' + settings.Name).slideDown('fast');
			}

			//expand or collapse the options below the expander bar
			$('#oneclick_bar_' + settings.Name).click(function () {
				if ($('#oneclick_unselected_' + settings.Name).attr('expanded') == "false") {
					$(this).removeClass('oneclick_expander_bar_down');
					$(this).addClass('oneclick_expander_bar_up');
					$('#oneclick_unselected_' + settings.Name).slideDown('fast', function () {
						$('#oneclick_unselected_' + settings.Name).attr('expanded', "true");
					});
				}
				else {
					$(this).addClass('oneclick_expander_bar_down');
					$(this).removeClass('oneclick_expander_bar_up');

					$('#oneclick_unselected_' + settings.Name).slideUp('fast', function () {
						$('#oneclick_unselected_' + settings.Name).attr('expanded', "false")
					});
				}
			});

			$(this).oneclick('populateItems', settings, true);
		},

		//Check to see if parent oneclick element is selected
		isParentSelected: function (parentDataArray, searchId) {
			var rv = false;

			if (parentDataArray != undefined) {
				var searchIdIsArray = (typeof searchId.length === "number"); //.isArray is expensive according to JS profiler

				for (var x = 0; x < parentDataArray.items.length; x++) {
					if (searchIdIsArray) {
						for (var xx = 0; xx < searchId.length; xx++) {
							if (parentDataArray.items[x].Id == searchId[xx]) {
								rv = parentDataArray.items[x].selected;
							}

							if (rv) {
								break;
							}
						}
					}
					else if (parentDataArray.items[x].Id == searchId) {
						rv = parentDataArray.items[x].selected;
					}

					if (rv) {
						break;
					}
				}
			}

			return rv;
		},

		//TODO: MR: when adding/removing items, it redraws all the selected items.  This was fine when all we were doing was checking the items...
		//   but now it needs to keep the selected slider bar values intact.
		//   it's also REALLY slow when we have a lot of items (i.e. Indications, Languages)

		//Add the selectable items to the checkbox list and establish whether they are checked or not
		populateItems: function (settings, isFirstRun) {
			var Name = settings.Name;
			var dataArray = settings.data;
			var showNoneSelected = settings.showNoneSelected;
			$('#oneclick_unselected_' + Name).html("");
			$('#oneclick_selected_' + Name).html("");

			if (showNoneSelected) {
				for (var x = 0; x < dataArray.items.length; x++) {
					if (dataArray.items[x].selected) {
						showNoneSelected = false;
						break;
					}
				}

				//MR: could have been set false before we get here!!
				if (showNoneSelected) {
					var row = '<div id="' + IdPrefix + '_row" class="' + settings.styles.table_row + '" style="text-align:center">';
					row += '<div class="' + settings.styles.table_cell + '" style="width:25px"></div>';
					row += '<div class="' + settings.styles.table_label + '">' + settings.showNoneSelectedLabel + '</div>';
					$('#oneclick_selected_' + Name).append(row);
				}
			}

			var redactBasedOnParent = settings.redactBasedOnParent && settings.parentData != undefined && settings.parentData != null;
			for (var x = 0; x < dataArray.items.length; x++) {
				var isParentSelected = $(this).oneclick('isParentSelected', settings.parentData, dataArray.items[x].parentId);
				//var isParentSelected = redactBasedOnParent && $(this).oneclick('isParentSelected', settings.parentData, dataArray.items[x].parentId);
				if (redactBasedOnParent == false || (redactBasedOnParent && isParentSelected)) {
					var IdPrefix = Name + dataArray.items[x][settings.dataIdProperty];
					var useSpeechBubble = (settings.speechBubble &&
												settings.speechBubble.enabled &&
												((settings.speechBubble.selected && dataArray.items[x].selected) ||
												 (settings.speechBubble.unselected && !dataArray.items[x].selected)));

					//Build the row element that will contain the checkbox and label
					var row = '<div id="' + IdPrefix + '_row" class="' + settings.styles.table_row + '">';
					row += '<div class="' + settings.styles.table_cell + '" style="width:25px" title="' + dataArray.items[x][settings.dataNameProperty] + '">';
					row += '<input index=' + x + ' oneclick="' + settings.Name + '" id="' + IdPrefix + '_checkbox" type="checkbox" ';
					if (dataArray.items[x].selected) {
						row += 'checked="true" ';
					}
					else {
						row += ' ';
					}
					row += '/></div>';
					//var style = dataArray.items[x]["style"];
					var style = dataArray.items[x][settings.styles.custom_style_attribute];

					if (style != "") {
						style = ' style="' + style + '"';
					}
					row += '<div id="' + IdPrefix + '_label' + '" class="' + settings.styles.table_label + '"' + style;
					if (useSpeechBubble == false) {
						row += ' title="' + dataArray.items[x][settings.dataNameProperty] + '"';
					}
					row += '><label>' + dataArray.items[x][settings.dataNameProperty] + '</label></div>';
					row += '</div>';

					//If it was selected, then bind the removeItem event to it and add any other features required by it in the 'selected' state
					if (dataArray.items[x].selected) {
						$('#oneclick_selected_' + Name).append(row);
						$('#' + IdPrefix + '_checkbox').bind('click', function () {
							$(this).oneclick('removeItem', $(this));
						});

						//*** SLIDER BARS ***
						if (settings.showSlider && dataArray.items[x].isRange) {
							var sliderRangeValues = dataArray.items[x].rangeValues;

							//MR: following id's and classes are required for UI to format slider properly
							var sliderDiv = '<div id="' + IdPrefix + '_sliderContainer" class="sliderContainer">';
							sliderDiv += '<div id="' + IdPrefix + '_sliderContent" class="sliderContent"></div>';
							sliderDiv += '<div id="' + IdPrefix + '_slider"></div>';
							sliderDiv += '<div id="' + IdPrefix + '_sliderValue" class="sliderValue"></div>';
							sliderDiv += '</div>';

							$('#' + IdPrefix + '_row').append(sliderDiv);

							//MR: set the values if they were already adjusted previously
							var minValue = dataArray.items[x].minSelected === undefined ? 0 : dataArray.items[x].minSelected;
							var maxValue = dataArray.items[x].maxSelected === undefined ? sliderRangeValues.length - 1 : dataArray.items[x].maxSelected;



							if ($.trim(dataArray.items[x].rangeValues[0]) != "Yes" || $.trim(dataArray.items[x].rangeValues[1]) != "No") {
								$('#' + IdPrefix + '_slider').slider({
									min: 0,
									max: sliderRangeValues.length - 1,
									values: [minValue, maxValue],
									range: true,
									step: 1
								});
								//MR: detect change in slider position and update values
								//  pass in vars via event.data to avoid closure/scope problems
								$('#' + IdPrefix + '_slider').bind('slidechange', {
									dataArrayItem: dataArray.items[x],
									sliderId: '#' + IdPrefix + '_slider',
									sliderValueId: '#' + IdPrefix + '_sliderValue',
									sliderValues: sliderRangeValues
								},
									function (event, ui) {
										var values = $(event.data.sliderId).slider("option", "values");
										var minSelected = event.data.sliderValues[values[0]];
										var maxSelected = event.data.sliderValues[values[1]];
										event.data.dataArrayItem.minSelected = values[0];
										event.data.dataArrayItem.maxSelected = values[1];
										if (values[0] === values[1]) {
											$(event.data.sliderValueId).html(minSelected + ' yrs');
										} else {
											$(event.data.sliderValueId).html(minSelected + " ... " + maxSelected + ' yrs');
										}
										settings.events.onRangeChange();
									}
								);

								//MR: initialize the values being displayed
								$('#' + IdPrefix + '_slider').trigger('slidechange');

							}
						}
					}
					else {
						//Not selected, so just show it in the list as unselected and bind the addItem event to it
						//  no need to attach Qtips, DialogBoxes, etc to it until 'selected'
						$('#oneclick_unselected_' + Name).append(row);
						$('#' + IdPrefix + '_checkbox').bind('click', function () {
							$(this).oneclick('addItem', $(this));
						});
					}

					// *** DIALOG BOX *** 
					//MR: Note - I doubt this will be re-usable as-is if we want to add another dialogbox to one of the other accordian select lists, but it's a good start
					if (settings.dialogBox.enabled) {
						var itemId = dataArray.items[x][settings.dataIdProperty];
						var labelText = dataArray.items[x][settings.dataNameProperty];

						var eventName = settings.dialogBox.eventName;
						var divId = settings.dialogBox.divIdPrefix + itemId;
						var dataKey = settings.dialogBox.dataKeyPrefix;
						var dialogContainerId = settings.dialogBox.dialogContainerId;

						//MR: have to pass in event data or closure remembers only the last item associated with a dialog box
						$('#' + IdPrefix + '_label').bind(eventName, { dId: divId, dKey: dataKey, label: labelText }, function (event) {
							var html = $(event.data.dId).data(event.data.dKey);
							$('<div id="dialogContainer">' + html.HtmlString + '</div>').dialog({
								modal: settings.dialogBox.modal,
								cache: settings.dialogBox.cache,
								title: settings.dialogBox.title + " - " + event.data.label,
								resizable: settings.dialogBox.resizable,
								width: settings.dialogBox.width,
								height: settings.dialogBox.height,
								position: settings.dialogBox.position,
								buttons: { "Confirm": function () { $(this).dialog('close'); } },
								open: settings.dialogBox.open,
								close: function (ev, ui) { settings.dialogBox.close(); $(this).remove(); },
								beforeClose: settings.dialogBox.beforeClose
							});
						}).addClass("cursorPointer");
					}

					// *** QTIP ***
					if (useSpeechBubble) {
						$('#' + IdPrefix + '_row').qtip({
							content: {
								//dataArray.items[x][settings.dataIdProperty]
								//MR: SIGH: Can't do this because element does not exist yet!
								text: $('#' + settings.speechBubble.contentId + dataArray.items[x][settings.dataIdProperty]).clone(),
								//text: settings.speechBubble.contentId + dataArray.items[x][settings.dataIdProperty],

								//text: $('#' + settings.speechBubble.contentId).clone(),
								title: {
									text: (settings.speechBubble.titleKey) ? eval('dataArray.items[x].' + settings.speechBubble.titleKey) : dataArray.items[x][settings.dataIdProperty],
									button: 'Close'
								}
							},
							show: {
								event: 'mouseenter',
								effect: function (offset) { $(this).slideDown(100); }
							},
							hide: {
								fixed: true
							},
							position: {
								my: 'left center',
								at: 'right center'
							}
						});
					}
				}
				else {
					dataArray.items[x].selected = false;
				}
			}

			// Either save away a parent's child settings (if first run) or use the child settings to rebuild the children based on how
			// the parent was just rebuilt. This allows a parent to seek out its own children
			if (isFirstRun) {
				if (settings.parentData != null &&
					settings.parentData != undefined &&
					(settings.parentData.childSettings == undefined ||
					 settings.parentData.childSettings == null ||
					 settings.parentData.childSettings[settings.Name] == undefined ||
					 settings.parentData.childSettings[settings.Name] == null)) {
					if (settings.parentData.childSettings == undefined || settings.parentData.childSettings == null) {
						settings.parentData.childSettings = [];
					}

					settings.parentData.childSettings[settings.Name] = settings;
				}
			}
			else if (settings.data.childSettings != undefined && settings.data.childSettings != null) {
				var childSettings = settings.data.childSettings;
				for (var x in childSettings) {
					$(this).oneclick('populateItems', childSettings[x], false);
				}
			}
		},

		// Can't seem to get the jQuery .data(...) method to work ... so using a map instead
		getSettings: function (Name) {
			if (oneclick_settingsMapping[Name] !== undefined && [Name] !== null) {
				return oneclick_settingsMapping[Name];
			} else {
				return null;
			}
		},

		//...  overwrite the data associated with this instance of the plugin
		setData: function (Name, newData) {
			oneclick_settingsMapping[Name].data = newData;
		},

		//Add an item to the list ABOVE the expander bar and mark it as selected
		addItem: function (item) {
			var settings = $(this).oneclick('getSettings', item.attr('oneclick'));
			var rv = true;
			var index = item.attr('index');
			var currentSelected = -2;

			// A maxSelected of 0 or less will cause this to skip, best practice is to set to '-1' to mean "unlimited"
			if (settings.maxSelected > 0) {
				currentSelected = 0;
				for (var x = 0; x < settings.data.items.length; x++) {
					if (settings.data.items[x].selected) {
						currentSelected++;
					}
				}

				// So if we added one more, would it still be equal to or less than our max?
				rv = ((currentSelected + 1) <= settings.maxSelected);
			}

			if (rv) {
				settings.data.items[index].selected = true;
				$(this).oneclick('populateItems', settings, false);
			}
			else {
				alert("This list is limited to " + settings.maxSelected + " items selected at once");
			}

			$(this).oneclick('setTooltip', settings.Name);

			return rv && settings.events.onSelect(settings, item);
		},

		//Remove an item from the list ABOVE the expander bar and mark it as unselected
		removeItem: function (item) {
			var settings = $(this).oneclick('getSettings', item.attr('oneclick'));
			var index = item.attr('index');

			settings.data.items[index].selected = false;
			$(this).oneclick('populateItems', settings, false);   //TODO: MR: this is where it's slow...
			$(this).oneclick('setTooltip', settings.Name);

			return settings.events.onDeselect(settings, item);
		},

		setTooltip: function (tabName) {
			var tooltip = "";
			var elementsH3;
			if (tabName == "UpdateAllTooltip") {
				elementsH3 = $("#SearchCriteria h3:not('#h3JobGrade')");
			}
			else {
				if (tabName == "StudyPhaseNotQ") {
					tabName = "StudyPhase";
				}
				else if (tabName == "Project") {
					tabName = "Projects";
				}
				else if (tabName == "Region" || tabName == "Subregion" || tabName == "Country" || tabName == "CountryRegion" || tabName == "StateProvince") {
					tabName = "Geographical";
				}
				else if (tabName == "Language") {
					tabName = "Languages";
				}
				else if (tabName == "TherapeuticArea") {
					tabName = "Area";
				}

				elementsH3 = $("#SearchCriteria [id='SearchCriteria_" + tabName + "'] h3");
			}

			$.each(elementsH3, function (indexH3, elementH3) {
				var elementsDiv = $(elementH3).next().find("div");
				var elementsSpan = elementsDiv.find("span");
				var elementsCheckbox;

				if (elementsSpan.size() > 0) {
					tooltip = "";
					$.each(elementsSpan, function (indexSpan, elementSpan) {
						elementsCheckbox = $(elementSpan).next().find("[type=checkbox]:checked");
						if ($(elementsCheckbox).size() > 0) {
							tooltip += (tooltip == "" ? "" : "</br>") + "<b>" + $(elementSpan).html() + ":</b> ";
							$.each(elementsCheckbox, function (indexChechbox, elementChechbox) {
								tooltip += $.trim($(elementChechbox).parent().attr("title")) + ", ";
							});
							tooltip = tooltip.substr(0, tooltip.length - 2);
						}
					});
				}
				else {
					elementsCheckbox = $(elementsDiv).find("[type=checkbox]:checked");
					tooltip = "";
					$.each(elementsCheckbox, function (indexChechbox, elementChechbox) {
						tooltip += $.trim($(elementChechbox).parent().attr("title")) + ", ";
					});
					tooltip = (tooltip == "" ? "" : tooltip.substr(0, tooltip.length - 2));
				}

				if (tooltip == "") {
					$(elementH3).attr("title", "Nothing selected.");
					$(elementH3).find("img").addClass("ui-iconHide");
				}
				else {
					$(elementH3).attr("title", tooltip);
					$(elementH3).find("img").removeClass("ui-iconHide").addClass("ui-iconNew");
				}
			});
		}
	};

	//Public access method that takes either a method + parameters or just the options to init the plugin
	$.fn.oneclick = function (method) {
		if (methods[method]) {
			//Call one of the methods
			return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
		} else if (typeof method === 'object' || !method) {
			//Initialize the plugin
			return methods.init.apply(this, arguments);
		} else {
			$.error('Method ' + method + ' does not exist on jQuery.oneclick');
		}
	};

})(jQuery);
