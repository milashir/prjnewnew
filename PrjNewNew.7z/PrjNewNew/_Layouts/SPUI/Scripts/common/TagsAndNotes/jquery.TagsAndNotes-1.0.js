﻿/**
 * This is really a 0.1alpha release of a jQuery plug-in that allows yuo to put Notes (and later tags) against an arbitary "thing." 
 *
 * Later version of this may support other repositories ...
 *
 * Todos (in no order):
 *		- A bunch of stuff ...
 *		- Implement the "IsPrivate" and "IsImporant" feature ... they are hardcoded to false for now, but the model support it
 *
 * Usage:
 *		<div id="MyDiv" class="q_entity_comments"/>
 *		$('.q_entity_comments').TagsAndNotes();
 *
 * Required Libraries:
 *		qTip
 *		dateFormat
 *
 * Good to have ones:
 *		None
 *
 * @author Colin B. Boatwright
 * @date 05/OCT/2011
 */

	(function ($)
{
	$.fn.TagsAndNotes = function (options)
	{
		var settings =
		{
			endpoint: {
				service: '/_vti_bin/RM/MessageCenter.svc',
				dataType : 'json',
				createComment: 'CreateComment',
				readComments: 'ReadComments',
				updateComment: 'UpdateComment',
				deleteComment: 'DeleteComment',
			},
			maximumItemsToReturn: 12,
			width: '450px',
			messages: {
				create_comment_successful: 'Comment saved successfully',
				update_comment_successful: 'Comment updated successfully',
				delete_comment_successful: 'Comment removed successfully',
			},
			assembleTitle: function (metadata) { return metadata; }
		}; 

		if (options)
		{
			$.extend(settings, options);
		}

		return this.each(function ()
		{
			var me = $(this);
			
 			var entityName = $(me).attr("entityName");
 			var entityId = parseInt($(me).attr("entityId"));
 			var metadata = $(me).attr("metadata");
			var title = settings.assembleTitle(metadata);

			var id = entityName + "_" +  entityId;
			var qTipId = id + '_qTip';
			me.attr('id', qTipId);
			
			var dialog = '<form>' +
							'<div class="q_entity_comments_dialog" id="' + id + '_note" contenteditable="true"></div>' +
								'<br /><div class="q_entity_comments_buttons">' +
								'<input id="' + id+ '_saveButton" type="button" value="Save" target="_self" class="button" onclick=""/>' +
								'<input id="' + id + '_cancelButton" type="button" value="Cancel" target="_self" class="button btnCancelNotes" onclick="$(\'#' + qTipId + '\').qtip(\'hide\');"/></div>'+
								'<br /><div id="' + id + '_notesList" class="q_entity_comments_notesList">Loading Notes ...</div>';

			me.qtip({
				prerender: true,
				content: {
					text: dialog,
					title: {
						text: title,
						button: 'Close'
					}
				},
				style: {
					width: settings.width
				},
				show: {
					event: 'click'
				},
				events: {
					visible: function (event, api)
					{
						$('#' + id + '_saveButton').bind('click', function()
							{ 
								TagsAndNotes_AddComment(settings, { id: id, title: title, entityName: entityName, entityId: entityId });
							});
						TagsAndNotes_GetComments(settings, { id: id, title: title, entityName: entityName, entityId: entityId });
					},
					hide: function(event, api)
					{
						TagsAndNotes_CancelComment(qTipId, id, event);
					}
				},
				hide: {
					event: 'close',
					fixed: true,
					effect: function (offset)
					{
						$(this).slideDown(100);
					}
				},
				position: {
					my: 'top right',
					at: 'bottom center'
				}
			});

			me.bind('click', function() { me.qtip('show'); } );
		});
	}
})(jQuery);

/**
 * @author Colin Boatwright
 */
function TagsAndNotes_CancelComment(qTipId, id, event)
{
	var note = $("#" + id + "_note");
	var bCancel = false;
	if (note.text() == "" || confirm('Cancel without saving?'))
	{
		note.text('');
	}
	else
	{
		event.preventDefault();
	}

	return false;
}

/**
 * @author Colin Boatwright
 */
function TagsAndNotes_GetComments(settings, data)
{
	var endpoint = settings.endpoint.service + "/" + settings.endpoint.readComments + "?entityName=" + data.entityName + '&entityId=' + data.entityId;

	var id = data.id;
	var entityName = data.entityName;
	var entityId = data.entityId;

	$.ajax({
		url: endpoint,
		type: settings.endpoint.type,
		//contentType: settings.endpoint.contentType,
		dataType: settings.endpoint.dataType,
		headers: {
			Pragma: "no-cache"
		},
		cache: false,
		success: function (data)
		{
			var ExistingComments = new Array();
			var comments = jQuery.parseJSON(data);
			for (var x = 0; x < comments.length; x++)
			{
				ExistingComments[ExistingComments.length] = {
						Id: comments[x].Id,
						EntityName: comments[x].RefEntityType,
						EntityId: comments[x].RefEntityId,
						Owner: comments[x].LastModifiedBy,
						Comment:  comments[x].Comment,
						IsHighPriority: comments[x].IsHighPriority == "true" ? true : false,
						IsPrivate: comments[x].IsPrivate== "true" ? true : false,
						LastModifiedDateTime: comments[x].LastModifiedOn,
						commentUid: comments[x].RefEntityType + comments[x].RefEntityId + comments[x].Id };
			}

			var notesList = $("#" + id + "_notesList");
			notesList.children().remove();
			notesList.html('');
			for (var x = 0; x < ExistingComments.length; x++)
			{
				var EntityCommentId = ExistingComments[x].Id;
				var EntityComment = ExistingComments[x].Comment;

				var actionAlinkPrefix = '<a href="JavaScript://" entityCommentId="' + EntityCommentId +
												'" entityName="' + ExistingComments[x].EntityName +
												'" entityId="' + ExistingComments[x].EntityId +
												'" commentUid="' + ExistingComments[x].commentUid +
												'" id="' +  ExistingComments[x].commentUid;

				notesList.append('<div class="q_entity_comments_notesList_elemets">' + ExistingComments[x].Owner + ' @ ' + ExistingComments[x].LastModifiedDateTime +
									'<br/><span id="' + ExistingComments[x].commentUid + '_Comment">' + ExistingComments[x].Comment +
									'</span><span class="q_notes_edit_save">' +
									actionAlinkPrefix + '_Edit"><img src="/_Layouts/SPUI/Scripts/common/TagsAndNotes/edit.png"></a>' +
									actionAlinkPrefix + '_Delete"><img src="/_Layouts/SPUI/Scripts/common/TagsAndNotes/delete.png"></a></span></div>');
				$('#' + ExistingComments[x].commentUid + '_Delete').bind('click', function() { TagsAndNotes_DeleteComment(settings, $(this)); } );
				$('#' + ExistingComments[x].commentUid + '_Edit').bind('click', function() { TagsAndNotes_SetCommentTextForEdit(settings, $(this)); } );
			}

		},
		error: function (data)
		{
			alert('error');
		}
	});
}

/**
 * @author Colin Boatwright
 */
function TagsAndNotes_SetCommentTextForEdit(settings, actionObj)
{
	var entityCommentId = actionObj.attr('entityCommentId');
	var entityName      = actionObj.attr('entityName');
	var entityId        = actionObj.attr('entityId');
	var commentUid      = actionObj.attr('commentUid');
	var entityComment   = $('#' + commentUid + '_Comment');
	var id              = entityName + "_" + entityId;

	var note = $("#" + id + "_note");
	var existingEntityCommentId = note.attr("entityCommentId");

	// Are we already editing?
	var bProceed = true;
	if (existingEntityCommentId != undefined && isNaN(parseInt(existingEntityCommentId)) == false)
	{
		$('.q_notes_edit').removeClass('q_notes_edit'); // This may look silly, but basically if a row was already in edit mode I want to clear the style
		
		var existingCommentUid = note.attr("commentUid");
		var existingEntityComment = $('#' + existingCommentUid + '_Comment');
		if (existingEntityComment.text() != note.text())
		{
			bProceed = confirm("Discard edits?");
		}
	}

	if (bProceed)
	{
		entityComment.parent().addClass('q_notes_edit');

		note.attr("entityCommentId", entityCommentId);
		note.attr("commentUid", commentUid);
		note.text(entityComment.text());
	}
	
	note.focus();
}

/**
 * @author Colin Boatwright
 */
function TagsAndNotes_DeleteComment(settings, actionObj)
{
	if (confirm('Remove note?')) 
	{
		var entityCommentId = actionObj.attr('entityCommentId');
		var entityName = actionObj.attr('entityName');
		var entityId = actionObj.attr('entityId');
		var id = entityName + "_" + entityId;

		var endpoint = settings.endpoint.service + "/" + settings.endpoint.deleteComment + "?entityCommentId=" + entityCommentId;

		$.ajax({
			url: endpoint,
			type: settings.endpoint.type,
			dataType: settings.endpoint.dataType,
			headers: {
				Pragma: "no-cache",
			},
			success: function (resultData)
			{
				rm.ui.messages.showSuccess(settings.messages.delete_comment_successful);
				TagsAndNotes_GetComments(settings, { id: id, entityName: entityName, entityId: entityId });
			},
			error: function (data)
			{
				alert(data.xml);
			},
			cache: false
		});
	}

	return false;
}

/**
 * @author Colin Boatwright
 */
function TagsAndNotes_AddComment(settings, data)
{
	var note = $("#" + data.id + "_note");
	if (note.text() != "")
	{
		var endpoint = null;
		var isUpdate = false;
		var req = { IsPrivate: false,
						IsImportant: false,
						commentStr: note.text() };
		var entityCommentId = note.attr("entityCommentId");
		if (isNaN(parseInt(entityCommentId)))
		{
			endpoint = settings.endpoint.service + "/" + settings.endpoint.createComment;
			req.entityName = data.entityName;
			req.entityId = data.entityId;
		}
		else
		{
			endpoint = settings.endpoint.service + "/" + settings.endpoint.updateComment;
			req.entityCommentId = entityCommentId;
			isUpdate = true;
		}

		$.ajax({
			url: endpoint,
			type: 'POST',
			data: JSON.stringify(req),
			contentType: 'application/json; charset=utf-8',
			dataType: 'text',
			headers: {
				Pragma: "no-cache",
			},
			success: function (resultData)
			{
				rm.ui.messages.showSuccess(isUpdate ? settings.messages.update_comment_successful : settings.messages.create_comment_successful);
				note.html('');
				note.attr("entityCommentId", "");
				TagsAndNotes_GetComments(settings, data);
			},
			error: function (errMsg)
			{
				var d = $.parseJSON(errMsg.responseText);
				alert(d.Message);
			},
			cache: false
		});
	}
}