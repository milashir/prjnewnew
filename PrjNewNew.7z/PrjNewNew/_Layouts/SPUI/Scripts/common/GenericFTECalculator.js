﻿/// <reference path="rmhelper.js" />
var genericCalculator = {
	multiEditMode: false,
	getStageCount: function () { return $("[id$=GenericStageCount]").val(); },
	getRequestStopDateFromUi: function () { alert("Caller must override function genericCalculator.getRequestStopDateFromUi()"); },
	renderCalculatorForMultiEdit: function (resourceId, stageCount) {
		var stageData = {
			GenericInitiateCalculatorList: new Array(),
			GenericInitiateCalcTimestamp: new Array()
		};

		for (var i = 0; i < stageCount; i++) {
			stageData.GenericInitiateCalculatorList.push({
				Id: i,
				FromMilestoneId: "",
				ToMilestoneId: "",
				FromMilestoneType: "",
				ToMilestoneType: "",
				FromMilestoneConnected: "",
				ToMilestoneConnected: "",
				FromMilestoneDate: "",
				ToMilestoneDate: "",
				weeklyHours: "",
				FTE: ""
			});

			stageData.GenericInitiateCalcTimestamp.push({
				FromMilestoneTimestamp: "",
				ToMilestoneTimestamp: "",
				RequestCalculatorTimestamp: ""
			});

		}
		genericCalculator.showStageRowsOnUi(resourceId, stageData);
		genericCalculator.reloadAllStartMilestones(stageData);
	},
	renderCalculatorByRequestId: function (requestId, resourceId, makeAsyncCall, setDefaultMilestoneDates) {
		$.ajax({
			url: rm.ajax.requestSvcUrl + "GetGenericInitiateCalculatorbyRequest?requestId=" + ((requestId != null) ? requestId : 0),
			cache: false,
			async: makeAsyncCall,
			success: function (data) {
				$("#isGenericDirtyCalculator").val('False');
				calculatorData = data;
				genericCalculator.showStageRowsOnUi(resourceId, data);
				genericCalculator.reloadAllStartMilestones(data);
				$.GenericFTECalculator.SetManualMilestone();
				genericCalculator.showAdhocRowsOnUi(data);

				if ($.GenericFTECalculator.OnCalculatorRenderComplete) {
					$.GenericFTECalculator.OnCalculatorRenderComplete(data.RegionId, data.CountryId);
				}

				genericCalculator.postRenderProcessing();
				genericCalculator.setDefaultMilestones(setDefaultMilestoneDates);
			},
			error: function (errmsg) {
				rm.ui.messages.addError(Resources.FailedToRenderInitiateCalculator);
			}
		});
	},
	renderDefaultGenericCalculatorByResourceTypeId: function (resourceId, makeAsyncCall, setDefaultMilestoneDates) {
		$.ajax({
			url: rm.ajax.requestSvcUrl + "GetDefaultGenericCalculatorsByResourceTypeId?resourceTypeId=" + ((resourceId != null) ? resourceId : 0) + "&countryId=" + $.GenericFTECalculator._countryId,
			cache: false,
			async: makeAsyncCall,
			success: function (data) {
				$("#isGenericDirtyCalculator").val('False');
				calculatorData = data;
				genericCalculator.showStageRowsOnUi(resourceId, data);
				genericCalculator.reloadAllStartMilestones(data);

				if ($.GenericFTECalculator.OnCalculatorRenderComplete) {
					$.GenericFTECalculator.OnCalculatorRenderComplete(data.RegionId, data.CountryId);
				}

				genericCalculator.postRenderProcessing();
				genericCalculator.setCalculatorsDefaultStages();
			},
			error: function (errmsg) {
				rm.ui.messages.addError(Resources.FailedToRenderInitiateCalculator);
			}
		});
	},
	showAdhocRowsOnUi: function (data) {
		if (data.adhocInitiateCalculatorList != null) {
			for (var i = 0; i < data.adhocInitiateCalculatorList.length; i++) {
				var allowEdit = true;
				var disabledString = "";
				if ($.GenericFTECalculator.isRequestHardOrSoftBooked && !rm.date.isQDateDateGreaterOrEqualToToday(data.adhocInitiateCalculatorList[i].EndDate)) {
					allowEdit = false;
					disabledString = " disabled='disabled' ";
				}
				var addAdhocRow = "<tr style='line-height:24px;'>" +
					"<td style='visibility:hidden; width:10px'>" +
					"     <input type='hidden' id='hdnExplanation_" + data.adhocInitiateCalculatorList[i].Id + "' value='" + escape(data.adhocInitiateCalculatorList[i].Comments) + "' actualValue='" + escape(data.adhocInitiateCalculatorList[i].Comments) + "'/>" +
					"     <input type='hidden' id='hdnAdhocCalculatorTimestamp_" + data.adhocInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId + "' value='" + data.AdhocInitiateCalcTimestamp[i].RequestCalculatorTimestamp + "'/>" +
					"     <input type='hidden' id='hdnAdhocCalculatorId_" + data.adhocInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId + "' value='" + data.AdhocInitiateCalcTimestamp[i].RequestCalculatorId + "'/>" +
					"</td>" +
					"<td style='width: 70px; text-align:left;'>" +
					"    <img id='imgDelete_" + data.adhocInitiateCalculatorList[i].Id + "' adHockRowId='" + data.adhocInitiateCalculatorList[i].Id + "' src='/_layouts/SPUI/images/closeSmall.png' style='margin: 2px 0 0 10px;' alt='' class='imgDeleteGenereicAdhoc'" + ($.GenericFTECalculator.AllowEditing ? "" : "disabled='disabled'") + "  originalStartDate='" + data.adhocInitiateCalculatorList[i].StartDate + "'/>" +
					"</td>" +
					"<td style='width: 140px;'>" +
					"    <span id = 'lblStartDate_" + data.adhocInitiateCalculatorList[i].Id + "' actualValue='" + data.adhocInitiateCalculatorList[i].StartDate + "'>" + $.GenericFTECalculator.getAdhocFrequencyDateLink(data.adhocInitiateCalculatorList[i].StartDate, allowEdit) + "</span>" +
					"</td>" +
					"<td style='width: 160px;'>" +
					"    <span id = 'lblEndDate_" + data.adhocInitiateCalculatorList[i].Id + "' actualValue='" + data.adhocInitiateCalculatorList[i].EndDate + "'>" + $.GenericFTECalculator.getAdhocFrequencyDateLink(data.adhocInitiateCalculatorList[i].EndDate, allowEdit) + "</span>" +
					"</td>" +
					"<td style='text-align:center; width: 90px;'>" +
					"    <input type='text' id='txtWeeklyHours_" + data.adhocInitiateCalculatorList[i].Id + "' value='" + data.adhocInitiateCalculatorList[i].WeeklyHours + "' actualValue='" + data.adhocInitiateCalculatorList[i].WeeklyHours + "'" + $.GenericFTECalculator.getInputAttributesForWeeklyHours() + disabledString + " from='0' to='9999.99' formating='4,2' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px;' />" +
					"</td>" +
					"<td style='text-align:center; width: 90px;'>" +
					"    <input type='text' id='txtFTE_" + data.adhocInitiateCalculatorList[i].Id + "' value='" + data.adhocInitiateCalculatorList[i].FTE + "' actualValue='" + data.adhocInitiateCalculatorList[i].FTE + "'" + $.GenericFTECalculator.getInputAttributesForFte() + disabledString + " from='0' to='999.999' formating='3,3' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px;' />" +
					"</td>" +
					"<td style='width: 70px; text-align:left;'>" +
					"    <img id='imgInfo_" + data.adhocInitiateCalculatorList[i].Id + "'  src='/_layouts/SPUI/images/searchIcon.png' style='margin: 2px 0 0 10px;' adHockRowId='0" + data.adhocInitiateCalculatorList[i].Id + "' class='imgInfo' />" +
					"</td>" +
					"</tr>";

				$("#GenericAdHocRow").append(addAdhocRow);
				rm.qtip.showInfo("#imgInfo_" + data.adhocInitiateCalculatorList[i].Id, data.adhocInitiateCalculatorList[i].Comments);

			}
		}

		if (data.adhocInitiateCalculatorList.length > 0 || data.GenericInitiateCalculatorList.length > 0) {
			$(".GenericFTE_Calculator").show();
			$.GenericFTECalculator._interimFrequencyEnabled = true;
		}
	},
	postRenderProcessing: function () {
		setTimeout(function () {
			$.GenericFTECalculator.enableDisableAddButton();
			$.GenericFTECalculator.AfterCalculatorDraw();
		}, 200);
		setTimeout(function () { genericCalculator.bindDirtyForCalculator(); rm.ui.ribbon.delayedRefresh(); }, 200);
	},
	showStageRowsOnUi: function (resourceId, data) {
		var weeklyHours;
		var FTE;
		var Id;
		var FromMilestoneId;
		var ToMilestoneId;
		var FromMilestoneConnected;
		var ToMilestoneConnected;
		var FromMilestoneType;
		var ToMilestoneType;
		var FromMilestoneDate;
		var ToMilestoneDate;

		for (var i = 0; i < data.GenericInitiateCalculatorList.length; i++) {

			$.GenericFTECalculator._newGenericRowID++;
			Id = data.GenericInitiateCalculatorList[i].Id;
			FromMilestoneId = data.GenericInitiateCalculatorList[i].FromMilestoneId;
			ToMilestoneId = data.GenericInitiateCalculatorList[i].ToMilestoneId;
			FromMilestoneType = data.GenericInitiateCalculatorList[i].FromMilestoneType;
			ToMilestoneType = data.GenericInitiateCalculatorList[i].ToMilestoneType;
			FromMilestoneConnected = data.GenericInitiateCalculatorList[i].FromMilestoneConnected;
			ToMilestoneConnected = data.GenericInitiateCalculatorList[i].ToMilestoneConnected;
			FromMilestoneDate = data.GenericInitiateCalculatorList[i].FromMilestoneDate;
			ToMilestoneDate = data.GenericInitiateCalculatorList[i].ToMilestoneDate;
			weeklyHours = data.GenericInitiateCalculatorList[i].WeeklyHours;
			FTE = data.GenericInitiateCalculatorList[i].FTE;

			var displayImage = "";

			if (ResourceTypeName.Global_RSUL == resourceId) {
				$("#uStatus").empty();
				displayImage = "style='visibility:hidden'";
			}
			else {
				$("#uStatus").html("Status");
				displayImage = "";
			}

			$.GenericFTECalculator.addNewRowToGeneric(weeklyHours, FTE, Id, FromMilestoneId, ToMilestoneId, FromMilestoneConnected, ToMilestoneConnected, FromMilestoneType,
				ToMilestoneType, FromMilestoneDate, ToMilestoneDate, data.GenericInitiateCalcTimestamp[i].FromMilestoneTimestamp, data.GenericInitiateCalcTimestamp[i].ToMilestoneTimestamp, data.GenericInitiateCalcTimestamp[i].RequestCalculatorTimestamp, false, i);
		}
	},
	reloadAllStartMilestones: function (data) {
		//Start:Reload the start milestone once the user delete any milestone stage
		$("#GenericFTETable tr").each(function (index, element) {
			if (index > 1) {
				var selectedValue = $("#" + $(this).find(".fromMilestoneStartDate").attr('id')).val();
				$.GenericFTECalculator.ReloadTheMilestone($(this).find(".fromMilestoneStartDate"), LocalData, selectedValue);
			}
		});
		//End:Reload the start milestone once the user delete any milestone stage
	},
	setDefaultMilestones: function (setDefaultMilestoneDates) {
		if (setDefaultMilestoneDates == true) {
			if (null != LocalData) {
				$.grep(LocalData, function (el) {
					if (el.ProjectMilestoneId == $.GenericFTECalculator._DefaultFromMilestoneId && el.MilestoneType == "P") {
						$(".fromMilestoneStartDate").val(el.Id);
						$(".fromMilestoneStartDate").change();
					}
					if (el.ProjectMilestoneId == $.GenericFTECalculator._DefaultToMilestoneId && el.MilestoneType == "P") {
						$(".toMilestoneEndDate").val(el.Id);
						$(".toMilestoneEndDate").change();
					};
				});
			}
		}
	},
	setCalculatorsDefaultStages: function () {
		$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
			var fromMilestoneId = $(ele).find('[id^=hdnFromMilestoneId]').val();
			var toMilestoneId = $(ele).find('[id^=hdnToMilestoneId]').val();

			if (null != LocalData) {
				$.grep(LocalData, function (el) {
					if (el.ProjectMilestoneId == fromMilestoneId && el.MilestoneType == "P") {
						$(ele).find(".fromMilestoneStartDate").val(el.Id);
						$(ele).find(".fromMilestoneStartDate").change();
					}
					if (el.ProjectMilestoneId == toMilestoneId && el.MilestoneType == "P") {
						$(ele).find(".toMilestoneEndDate").val(el.Id);
						$(ele).find(".toMilestoneEndDate").change();
					};
				});
			}
		});
	},
	getControlValueOrNullIfBlank: function (parentElement, elementSelector) {
		var val = $(parentElement).find(elementSelector).val();
		return (val == "" || val == "null") ? null : val;
	},
	getControlAttributeValueOrDefaultIfBlank: function (parentElement, elementSelector, attributeName, defaultValue) {
		var val = $(parentElement).find(elementSelector).attr(attributeName);
		return val == "" ? defaultValue : val;
	},
	multieditSaveDone: function () {
		$("[id$=GenericStageCount]").val($("#GenericFTECalculator tr").removeAttr("isNew").length);
		$(".clsGenericWeeklyhours,.clsGenericFTE").attr("allowBlank", "true");
	},
	isCurrentAdhocDateBeyondRequestStopDate: function () {
		var areDatesBeyondRequestStop = false;
		var requestStopQDateString = genericCalculator.getRequestStopDateFromUi();

		if (rm.date.isValidDate(requestStopQDateString, false)) {
			var requestStopDate = rm.date.getDateFromQDateString(requestStopQDateString);

			var stopDate = rm.date.getDateFromQDateString($("#d_endDate").val());
			if (stopDate > requestStopDate) {
				areDatesBeyondRequestStop = true;
				rm.validation.addError($("#d_endDate"), Resources.RequestStopDateBeforeAdhocStop.replace("{0}", requestStopQDateString));
			}
		}
		return areDatesBeyondRequestStop;
	},
	areAdhocDatesBeyondRequestStopDate: function () {
		var areDatesBeyondRequestStop = false;
		var adhockTableRows = $("#GenericAdHocRow tr");
		if (adhockTableRows.length > 0) {
			var requestStopQDateString = genericCalculator.getRequestStopDateFromUi();
			if (rm.date.isValidDate(requestStopQDateString, false)) {
				var requestStopDate = rm.date.getDateFromQDateString(requestStopQDateString);

				$.each(adhockTableRows, function (index, ele) {
					var tableRow = $(ele);
					var currentAdhocStopDate = rm.date.getDateFromQDateString(tableRow.find("[id^=lblEndDate] a").html());
					if (currentAdhocStopDate > requestStopDate) {
						rm.validation.addError(tableRow.find("[id^=lblEndDate] a"), Resources.RequestStopDateBeforeAdhocStop.replace("{0}", requestStopQDateString));
						areDatesBeyondRequestStop = true;
					}
					else { rm.validation.clearError(tableRow.find('[id^=lblEndDate] a')); }
				});
			}
		}
		return areDatesBeyondRequestStop;
	},
	clearAdhocStopDateError: function () {
		var adhockTableRows = $("#GenericAdHocRow tr");
		$.each(adhockTableRows, function (index, ele) {
			rm.validation.clearError($(ele).find('[id^=lblEndDate]'));
			rm.validation.clearError($(ele).find('[id^=lblEndDate] a'));
		});
	},
	jsonSelectorForDirtyForm: function () { return { items: [{ selector: "#GenericQIP_Calculator input:text:not([readonly]),#GenericQIP_Calculator select:visible,#GenericQIP_Calculator textarea:visible,#GenericQIP_Calculator input:radio:visible", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },
	bindDirtyForCalculator: function () {
		$.formStatus.clearDirty(genericCalculator.jsonSelectorForDirtyForm());
	},
	getCountryIdForFteCalculation: function () { alert("Caller must override function genericCalculator.getCountryIdForFteCalculation()"); },
	getJobRoleIdForFteCalculation: function () { alert("Caller must override function genericCalculator.getJobRoleIdForFteCalculation()"); }
};

$.GenericFTECalculator = {
	isRequestHardOrSoftBooked: false,
	DialogOkClickHandler: function () { alert("You must assign function to $.GenericFTECalculator.DialogOkClickHandler to callback final submit method."); },
	OnAdhocRowRemoveHandler: function () { },
	OnCalculatorRenderComplete: function (regionId, countryId) { },
	InterimFrequencyOkClickHandler: function (startDate, stopDate) { },
	OnConnectImageClick: function () { },
	OnDeleteAdhocClick: function () { },
	OnCalculatorEdit: function () { },
	AfterCalculatorDraw: function () { },
	_DefaultToMilestoneId: 0,
	_DefaultFromMilestoneId: 0,
	//AllowDeletingAdhocRowsWithStartDateInPast: false,
	AllowEditing: true,
	StartDateSelector: "#txtStartDate",
	StopDateSelector: "#txtStopDate",
	_resourceTypeId: -1,
	_countryId: -1,
	_resourceId: -1,
	_PageManager: "",
	_PageManagerID: -1,
	_newRowID: 0,
	_newGenericRowID: 0,
	_genericRowsValues: "",
	_adHocValues: "",
	_genericRowTimestampValues: "",
	_adHocTimestampValues: "",
	_interimFrequencyEnabled: false,
	_fireChangeEvent: true,
	_deletedList: new Array(),
	_deletedOldAdhocList: new Array(),
	_GenericRowDeletedList: new Array(),
	_GenericRowOldDeletedList: new Array(),
	_editAdhocId: "",
	resourceTypeSelector: "#ddlResourceType",
	countrySelector: "#ddlCountry",
	startDateSelector: "#txtStartDate",
	stopDateSelector: "#txtStopDate",
	fteSelector: "#generic_small_Calc_TxtFTE",
	_fte: 0,
	_ProjectID: -1,
	DeletedMilestones: [],
	_enableSaveButton: false,

	isInterimFrequencyButtonEnabled: function () {
		return $.GenericFTECalculator._interimFrequencyEnabled;
	},

	InterimFrequency: function () {
		$.GenericFTECalculator.OpenAddAdHocDialog("New");
	},

	MilestoneFrequency: function () {
		if ($.GenericFTECalculator.saveCalculator()) {
			$.GenericFTECalculator.AddNewGenericRow();

			$.GenericFTECalculator.rebindStage();
		}
	},
	EditInterimFrequency: function (obj) {
		$.GenericFTECalculator.OpenAddAdHocDialog(obj);
	},

	OpenAddAdHocDialog: function (obj) {
		var startDate = "";
		var endDate = "";
		var comments = "";
		var edit = false;
		if (obj != "New") {
			startDate = $(obj.parentNode.parentNode.parentNode).find('[id^=lblStartDate]').find("a").html();
			endDate = $(obj.parentNode.parentNode.parentNode).find('[id^=lblEndDate]').find("a").html();
			comments = unescape($(obj.parentNode.parentNode.parentNode).find('[id^=hdnExplanation]').val()); //.replace(/'/g, "&#39;");
			edit = true;
			$.GenericFTECalculator._editAdhocId = "#" + $(obj.parentNode).attr("id");
		}

		var d = "<div id='fteCalculator' class='monitoringCalculatorPaddings'>" +
			"<form id='frmDialog'>" +
			"<table class='styleWidthNinety'>" +
			"<tr><td>Start Date <span class='styleColorRed'>*</span></td><td><input type = 'text' id='d_startDate' value='" + startDate + "' originalValue='" + startDate + "' /></td></tr>" +
			"<tr><td>Stop Date <span class='styleColorRed'>*</span></td><td><input type = 'text' id='d_endDate' value='" + endDate + "' /></td></tr>" +
			"<tr><td>Explanation <span class='styleColorRed'>*</span></td><td class='monitoringCalculatorAdHocExplanationHeight'><textarea id='c_comments' style='width:140px;height:45px;' maxLength='255' value='" + comments + "' ></textarea></td></tr>" +
			"</table></form></div>";

		$("#divDialog").html(d);

		setTimeout(function () {
			$("#d_startDate").qDatepicker().change(function () {
				if (rm.date.isValidDate($("#d_endDate").val(), false)) {
					rm.validation.clearError($("#d_endDate"));
				}
			});

			$("#d_endDate").qDatepicker().change(function () {
				if (rm.date.isValidDate($("#d_startDate").val(), false)) {
					rm.validation.clearError($("#d_startDate"));
				}
			});

			$("#c_comments").change(function () {
				if ($.trim($("#c_comments").val()).length > 0) {
					rm.validation.clearError($("#c_comments"));
				}
			});

			$("#d_startDate").val(startDate);
			$("#d_endDate").val(endDate);
			$("#c_comments").val(comments);
		}, 10);

		var btnArray = [{ text: "OK", click: function () { $.GenericFTECalculator.onAdhocDialogOkClick.apply(this, [edit]); } }, rm.ui.dialog.standardButtons.cancel];
		rm.ui.dialog.showModalWithButtons($("#divDialog"), "Add Ad-hoc Interim Frequency", "", false, 370, 220, btnArray);
	},

	AreDatesOverlapping: function () {
		var datesOverlap = false;
		var startDate = rm.date.getDateFromQDateString($("#d_startDate").val());
		var stopDate = rm.date.getDateFromQDateString($("#d_endDate").val());
		var adhockTableRows = $("#GenericAdHocRow tr");
		$.each(adhockTableRows, function (index, ele) {
			var tableRow = $(ele);
			var startDateLblId = "#" + tableRow.find("[id^=lblStartDate]").attr("id");
			var stopDateLblId = "#" + tableRow.find("[id^=lblEndDate]").attr("id");
			var existingStartDate = rm.date.getDateFromQDateString(tableRow.find("[id^=lblStartDate] a").html());
			var existingStopDate = rm.date.getDateFromQDateString(tableRow.find("[id^=lblEndDate] a").html());

			if ($.GenericFTECalculator._editAdhocId != startDateLblId
				&& $.GenericFTECalculator._editAdhocId != stopDateLblId
				&& (
					(existingStartDate <= startDate && existingStopDate >= startDate)
					|| (existingStartDate <= stopDate && existingStopDate >= stopDate)
					|| (startDate <= existingStartDate && stopDate >= existingStartDate)
					|| (startDate <= existingStopDate && stopDate >= existingStopDate)
				)
			) {
				datesOverlap = true;
				return false;
			}
		});

		return datesOverlap;
	},
	onAdhocDialogOkClick: function (isEdit) {
		var isDatevalid = $.GenericFTECalculator.isvalidDate($("#d_startDate").val(), $("#d_endDate").val());
		var isCommentValid = $.GenericFTECalculator.validatecomments($("#c_comments").val());
		if (isDatevalid && isCommentValid) {
			if ($("#d_startDate").attr("originalValue") != $("#d_startDate").val() && rm.date.isQDateDateInPast($("#d_startDate").val())) {
				rm.validation.addError("#d_startDate", Resources.StartDateInPast);
				return false;
			}
			else if ($.GenericFTECalculator.AreDatesOverlapping()) {
				alert(Resources.OverlapingAdhocFrequencyDates);
				return false;
			}
			else if (genericCalculator.isCurrentAdhocDateBeyondRequestStopDate()) {
				return false;
			}
			else {
				if (isEdit) {
					$.GenericFTECalculator.UpdateAdHoc();
				}
				else {
					$.GenericFTECalculator.AddNewAdHoc();
				}

				//Call the ok click handler and reset it back to empty function. This is added so that we can call back a function when user is changing the start/stop date of initiate request.
				$.GenericFTECalculator.InterimFrequencyOkClickHandler($("#d_startDate").val(), $("#d_endDate").val());

				$("#d_startDate").val("");
				$("#d_endDate").val("");
				$("#c_comments").val("");
				$.GenericFTECalculator._editAdhocId = "";
				setTimeout(function () { $.GenericFTECalculator.OnCalculatorEdit(); }, 10);
			}
		}
		else {
			return false;
		}
		$(this).dialog("close");
	},

	UpdateAdHoc: function () {
		var adhocComment = $("#c_comments").val();
		rm.validation.clearError($($($.GenericFTECalculator._editAdhocId)[0].parentNode.parentNode).find('[id^=lblEndDate] a'));
		rm.validation.clearError($($($.GenericFTECalculator._editAdhocId)[0].parentNode.parentNode).find('[id^=lblEndDate]'));
		$($($.GenericFTECalculator._editAdhocId)[0].parentNode.parentNode).find('[id^=lblStartDate]').find("a").html($("#d_startDate").val());
		$($($.GenericFTECalculator._editAdhocId)[0].parentNode.parentNode).find('[id^=lblEndDate]').find("a").html($("#d_endDate").val());
		$($($.GenericFTECalculator._editAdhocId)[0].parentNode.parentNode).find('[id^=hdnExplanation]').val($("#c_comments").val());
		rm.qtip.showInfo($($.GenericFTECalculator._editAdhocId).closest("tr").find("img.imgInfo"), adhocComment);
		$("#isGenericDirtyCalculator").val('True')
		$.Calculator_editAdhocId = "";
		rm.ui.ribbon.delayedRefresh();
	},

	//AB Add generic calculator
	AddFirstGenericRow: function (ProjectId, requestId, countryId, resourceTypeOrganizationId, resourceTypeId) {
		var postData = {
			projectId: ProjectId,
			getActiveOnly: true,
			requestId: requestId == null ? 0 : requestId,
			countryId: countryId,
			resourceTypeOrganizationId: resourceTypeOrganizationId,
			resourceTypeId: resourceTypeId
		};

		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.projectSvcUrl + "GetAllMilestonesByProjectId",
			dataType: "json",
			async: false,
			data: JSON.stringify(postData),
			success: function (data) { LocalData = data; },
			error: function (errmsg) { }
		});
	},

	HandleSaveButton: function () {
		if ($("[id$=AddingNewRequest]").val() == "false") {
			editRequest.setPageIsDirty();
			rm.ui.ribbon.delayedRefresh();
		}
	},

	RepopulateMilestoneDataForCountry: function (ProjectId, requestId, countryId, resourceTypeOrganizationId, resourceTypeId) {
		var postData = {
			projectId: ProjectId,
			getActiveOnly: true,
			requestId: requestId == null ? 0 : requestId,
			countryId: countryId,
			resourceTypeOrganizationId: resourceTypeOrganizationId,
			resourceTypeId: resourceTypeId
		};

		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.projectSvcUrl + "GetAllMilestonesByProjectId",
			dataType: "json",
			async: false,
			data: JSON.stringify(postData),
			success: function (data) {
				oldLocalData = LocalData;
				LocalData = data;
			},
			error: function (errmsg) {
			}
		});
	},

	AddNewGenericRow: function () {
		$.GenericFTECalculator._newGenericRowID++;
		var currentDateString = $("#GenericFTECalculator tr:last").find('[id^=dtEnd]').val();
		var currentDate = rm.date.getDateFromQDateString(currentDateString);
		if (currentDate != null) {
			currentDate.setDate(currentDate.getDate() + 1);
		}

		var MilestoneId = $("#GenericFTECalculator tr:last").find('[id^=milestone_end]').val();
		var MilestoneType = $("#GenericFTECalculator tr:last").find('[id^=hdnToMilestoneType]').val();
		var MilestoneConnected = $("#GenericFTECalculator tr:last").find('[id^=Image_start]').attr('connectStatus');

		$.GenericFTECalculator.addNewRowToGeneric(null, null, 0, -1, -1, 0, 0, null, null, null, null, null, null, null, true, -1);
		$.GenericFTECalculator.ReloadTheMilestone("#milestone_start_" + $.GenericFTECalculator._newGenericRowID, LocalData, -1);
		$.GenericFTECalculator.Fill("#milestone_end_" + $.GenericFTECalculator._newGenericRowID, LocalData, -1, null);
		$.GenericFTECalculator.ChangeNextMilestoneDateAndVal(rm.date.getQDateStringFromDate(currentDate), MilestoneId, MilestoneType, MilestoneConnected);
	},

	//AB Change Next milestone Date and Val based on previoues Milestone Stope Date
	ChangeNextMilestoneDateAndVal: function (NextDate, MilestoneId, MilestoneType, MilestoneConnected) {
		$("#GenericFTECalculator tr:last").find('[id^=dtStart]').val(NextDate);
		$("#GenericFTECalculator tr:last").find('[id^=milestone_start]').val(MilestoneId);

		$.each(LocalData, function (index, ele) {
			if (ele.Id == MilestoneId) {
				$("#GenericFTECalculator tr:last").find('[id^=hdnFromMilestoneTimestamp]').val(ele.MilestoneLastModifiedOn);
				$("#GenericFTECalculator tr:last").find('[id^=hdnFromMilestoneId]').val(ele.ProjectMilestoneId);
				$("#GenericFTECalculator tr:last").find('[id^=hdnFromMilestoneType]').val(ele.MilestoneType);
				$("#GenericFTECalculator tr:last").find('[id^=Image_start]').attr('connectStatus', MilestoneConnected);

				if (ele.MilestoneType == "P" || ele.MilestoneType == "S" || ele.MilestoneType == "O") {
					$("#GenericFTECalculator tr:last").find('[id^=Image_start]').attr('src', '/_layouts/SPUI/images/ppmUnLinkIcon.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
				}
				else if (ele.MilestoneType == "C") {
					$("#GenericFTECalculator tr:last").find('[id^=Image_start]').attr('src', '/_layouts/SPUI/images/cmReconnect.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
				}
				else {
					$("#GenericFTECalculator tr:last").find('[id^=Image_start]').hide();
				}
			}
		});
	},

	//Start: ReloadTheMilestone - Method to reload the start milestone name with grayed out milestone name
	ReloadTheMilestone: function (selector, data, selected) {
		var startMilestoneArray = $.GenericFTECalculator.GetSelectedMilestones();
		$(selector).empty().append($("<option>").val("-1").html("--Select--"));
		$.each(data, function (index, element) {
			if (element.Id == selected) {
				$(selector).append($("<option selected>").val(element.Id).html(element.MilestoneName));
			}
			else {
				var isSelected = false;
				for (var i = 0; i < startMilestoneArray.length; i++) {
					if (element.Id == startMilestoneArray[i] && element.Id != selected && element.Id != 1) {
						isSelected = true;
					}
				}
				if (isSelected) {
					$(selector).append($("<option disabled='disabled'>").val(element.Id).html(element.MilestoneName));
				}
				else {
					$(selector).append($("<option>").val(element.Id).html(element.MilestoneName));
				}
			}

			if (!element.IsActive) {
				$(selector).find("option[value ='" + element.Id + "']").attr("disabled", "disabled");
			}
		});
	},

	GetSelectedMilestones: function () {

		var startMilestoneArray = new Array();
		$("#GenericFTETable tr").each(function (index, element) {
			if (index > 1) {
				var startMilestoneelemet = $(this).find(".fromMilestoneStartDate").attr('id');
				startMilestoneArray.push($("#" + startMilestoneelemet).val());
			}
		});
		return startMilestoneArray;
	},

	SetManualMilestone: function () {
		$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
			var satrtMilestone = $(ele).find(".fromMilestoneStartDate").attr('id');
			var endMilestone = $(ele).find(".toMilestoneEndDate").attr('id');
			var fromMilestoneId = $(ele).find('[id^=hdnFromMilestoneId]').val();
			var toMilestoneId = $(ele).find('[id^=hdnToMilestoneId]').val();

			var manualDateValue = 1;
			if ($("#" + satrtMilestone).val() == "-1" && fromMilestoneId != "-1") {
				$.GenericFTECalculator.DeletedMilestones.push(fromMilestoneId);
				$("#" + satrtMilestone).find("option[value='" + manualDateValue + "']").attr("selected", "selected");
				$(ele).find('[id^=hdnFromMilestoneId]').val("0");
				$(ele).find('[id^=hdnFromMilestoneType]').val("M");
				$(ele).find('[id^=hdnFromMilestoneTimestamp]').val("null");
				$(ele).find('[id^=Image_start]').hide();
			}
			if ($("#" + endMilestone).val() == "-1" && toMilestoneId != "-1") {
				$.GenericFTECalculator.DeletedMilestones.push(toMilestoneId);
				$("#" + endMilestone).find("option[value='" + manualDateValue + "']").attr("selected", "selected");
				$(ele).find('[id^=hdnToMilestoneId]').val("0");
				$(ele).find('[id^=hdnToMilestoneType]').val("M");
				$(ele).find('[id^=hdnToMilestoneTimestamp]').val("null");
				$(ele).find('[id^=Image_end]').hide();
			}
		});
	},

	Fill: function (selector, data, selected, MilestoneType) {
		$(selector).empty().append($("<option>").val("-1").html("--Select--"));
		$.each(data, function (index, element) {
			if (element.ProjectMilestoneId == selected && element.MilestoneType == MilestoneType) {
				$(selector).append($("<option selected>").val(element.Id).html(element.MilestoneName));
			}
			else {
				$(selector).append($("<option>").val(element.Id).html(element.MilestoneName));
			}

			if (!element.IsActive) {
				$(selector).find("option[value ='" + element.Id + "']").attr("disabled", "disabled");
			}
		});
		$("#Image_start_" + $.GenericFTECalculator._newGenericRowID).hide();
		$("#Image_end_" + $.GenericFTECalculator._newGenericRowID).hide();
	},

	addNewRowToGeneric: function (weeklyHours, FTE, GenericInitiateCalculatorId, FromMilestoneId, ToMilestoneId,
		FromMilestoneConnected, ToMilestoneConnected, FromMilestoneType, ToMilestoneType, FromMilestoneDate, ToMilestoneDate, FromMilestoneTimestamp, ToMilestoneTimestamp, RequestCalculatorTimestamp, isNewStage, rowIndex) {
		var allowBlankAttr = (genericCalculator.multiEditMode && !isNewStage) ? " allowBlank='true' " : "";
		var allowBlankAttrForStatrDate = genericCalculator.multiEditMode ? " allowBlank='true' " : "";
		var isNewAttribute = isNewStage ? "isNew='true'" : "";
		var rowIndexAttr = " rowIndex=" + rowIndex + " ";

		var addStaticRow = "<tr class='spaceUnder' " + isNewAttribute + ">" +
			"<td style='width: 6%;text-align:center;vertical-align:top;>" +
			" <label  class='Stage' id='stageNumber_" + $.GenericFTECalculator._newGenericRowID + "' >" + $.GenericFTECalculator._newGenericRowID + "</label>" +
			"</td>" +
			"<td style='width: 35%;' class='class_milestoneStart'>" +
			"    <select " + allowBlankAttrForStatrDate + " id = 'milestone_start_" + $.GenericFTECalculator._newGenericRowID + "' style='width:205px;' class='fromMilestoneStartDate' data-value='" + $.GenericFTECalculator._newGenericRowID + " '/>" +
			"<br>" +
			"    <input " + allowBlankAttrForStatrDate + " size='12' type='text' class='GenericStartDatePicker genericWeeklyHoursFTE' id='dtStart_" + $.GenericFTECalculator._newGenericRowID + "' data-value='" + $.GenericFTECalculator._newGenericRowID + " '/>" +
			"<img id='Image_start_" + $.GenericFTECalculator._newGenericRowID + "' connectStatusChanged='0' connectStatus='" + FromMilestoneConnected + "' style='visibility: false' class='imgStartMilestone' data-value='" + $.GenericFTECalculator._newGenericRowID + " '/>" +

			"</td>" +
			"<td style='width: 35%;' class='class_milestoneEnd'>" +
			"    <select " + allowBlankAttr + " id = 'milestone_end_" + $.GenericFTECalculator._newGenericRowID + "' style='width:205px;' class='toMilestoneEndDate' data-value='" + $.GenericFTECalculator._newGenericRowID + " '/>" +
			"<br>" +
			"    <input " + allowBlankAttr + " size='12' type='text' class='GenericEndDatePicker genericWeeklyHoursFTE' id='dtEnd_" + $.GenericFTECalculator._newGenericRowID + "' data-value='" + $.GenericFTECalculator._newGenericRowID + " '>" +
			"<img id='Image_end_" + $.GenericFTECalculator._newGenericRowID + "' connectStatusChanged='0' connectStatus='" + ToMilestoneConnected + "' class='imgEndMilestone' data-value='" + $.GenericFTECalculator._newGenericRowID + " ' />" +
			"</td>" +
			"<td style='text-align:center;vertical-align:top; width: 10%;'>" +
			" <input type='text' " + allowBlankAttr + " id='txtWeeklyHours_New_" + $.GenericFTECalculator._newGenericRowID + "' actualValue= '" + (weeklyHours == null ? "" : weeklyHours) + "' value= '" + (weeklyHours == null ? "" : weeklyHours) + "' class='clsGenericWeeklyhours validateRange' from='0' to='9999.99' formating='4,2' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px; padding-left: 2px;' />" +
			"</td>" +
			"<td style='text-align:center;vertical-align:top; width: 10%;'>" +
			"    <input type='text' " + allowBlankAttr + " id='txtFTE_New_" + $.GenericFTECalculator._newGenericRowID + "' actualValue='" + (FTE == null ? "" : FTE) + "' value='" + (FTE == null ? "" : FTE) + "' class='clsGenericFTE validateRange' from='0' to='999.999' formating='3,3' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px; padding-left: 2px;' />" +
			"</td>" +
			" <td style='width: 4%; vertical-align:top; text-align:left;'>" +
			"<img id='imgDelete_New" + $.GenericFTECalculator._newGenericRowID + "'" + rowIndexAttr + " genericRowId='" + GenericInitiateCalculatorId + "' src='/_layouts/SPUI/images/closeSmall.png' style= 'margin: 2px 0 0 10px;' alt='' class='imgDeleteGenericRow' />" +

			"   <input type='hidden' id='hdnFromMilestoneId_" + $.GenericFTECalculator._newGenericRowID + "' value='" + FromMilestoneId + "'/>" +
			"   <input type='hidden' id='hdnToMilestoneId_" + $.GenericFTECalculator._newGenericRowID + "' value='" + ToMilestoneId + "'/>" +
			"   <input type='hidden' id='hdnRequestCalculatorTimestamp_" + $.GenericFTECalculator._newGenericRowID + "' value='" + RequestCalculatorTimestamp + "'/>" +
			"   <input type='hidden' id='hdnGenericInitiateCalculatorId_" + $.GenericFTECalculator._newGenericRowID + "' value='" + GenericInitiateCalculatorId + "'/>" +
			"   <input type='hidden' id='hdnFromMilestoneType_" + $.GenericFTECalculator._newGenericRowID + "' value='" + FromMilestoneType + "'/>" +
			"   <input type='hidden' id='hdnToMilestoneType_" + $.GenericFTECalculator._newGenericRowID + "' value='" + ToMilestoneType + "'/>" +
			"   <input type='hidden' id='hdnFromMilestoneTimestamp_" + $.GenericFTECalculator._newGenericRowID + "' value='" + FromMilestoneTimestamp + "'/>" +
			"   <input type='hidden' id='hdnToMilestoneTimestamp_" + $.GenericFTECalculator._newGenericRowID + "' value='" + ToMilestoneTimestamp + "'/>" +
			"   <input type='hidden' id='hdnFromMilestoneDate_" + $.GenericFTECalculator._newGenericRowID + "' value='" + FromMilestoneDate + "'/>" +

			"</td>"
		"</tr>";

		$("#GenericFTECalculator").append(addStaticRow);
		$.GenericFTECalculator.Fill("#milestone_start_" + $.GenericFTECalculator._newGenericRowID, LocalData, FromMilestoneId, FromMilestoneType);
		$.GenericFTECalculator.Fill("#milestone_end_" + $.GenericFTECalculator._newGenericRowID, LocalData, ToMilestoneId, ToMilestoneType);
		if (GenericInitiateCalculatorId != 0) {
			$("#dtStart_" + $.GenericFTECalculator._newGenericRowID).val(FromMilestoneDate);
			$("#dtEnd_" + $.GenericFTECalculator._newGenericRowID).val(ToMilestoneDate);
			$.GenericFTECalculator.LoadMilestoneImages(FromMilestoneType, FromMilestoneConnected, "#Image_start_" + $.GenericFTECalculator._newGenericRowID);
			$.GenericFTECalculator.LoadMilestoneImages(ToMilestoneType, ToMilestoneConnected, "#Image_end_" + $.GenericFTECalculator._newGenericRowID);
		}

		if ($.GenericFTECalculator._newGenericRowID == "1") {
			$(".GenericStartDatePicker").qDatepicker();
			$(".GenericEndDatePicker").qDatepicker();
		}
		else {
			$(".GenericEndDatePicker").qDatepicker();
			$("#milestone_start_" + $.GenericFTECalculator._newGenericRowID).attr("disabled", "disabled");
			$("#dtStart_" + $.GenericFTECalculator._newGenericRowID).addClass("MilestonefieldsetLabelWIdth disabledinput").attr("readonly", true);
			$("#Image_start_" + $.GenericFTECalculator._newGenericRowID).hide();
		}

		if (isNewStage) {
			$("#isGenericDirtyCalculator").val('True');
		}

		setTimeout(function () { rm.ui.ribbon.refresh(); }, 200);
	},
	BindDatePicker: function () {
		{
			for (var i = 0; i < $.GenericFTECalculator._newGenericRowID; i++) {
				$("#dtStart_" + i).qDatepicker().change(function () {
					if (rm.date.isValidDate($("#dtStart_" + i).val(), false)) {
						rm.validation.clearError($("#dtStart_" + i));
					}
				});

				$("#dtEnd_" + i).qDatepicker().change(function () {
					if (rm.date.isValidDate($("#dtEnd_" + i).val(), false)) {
						rm.validation.clearError($("#dtEnd_" + i));
					}
				});
			}
		}
	},
	rebindStage: function () {
		$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
			index++;
			$(this).find("[id^=stageNumber]").text(index);
		});
	},
	Checkdates: function (dateId, selector, Image, Counter) {
		$(Image + Counter).show();
		if (null != LocalData) {
			$.each(LocalData, function (inex, ele) {
				if (ele.Id == dateId) {
					if (ele.MilestoneDate != null) {
						$(selector + Counter).val(ele.MilestoneDate);
						$(selector + Counter).attr("disabled", false);
						$(selector + Counter).qDatepicker({ 'allowBlank': genericCalculator.multiEditMode, 'validate': true });
					}
					return false;
				}
			});
			if (dateId == -1) {
				$(selector + Counter).val('');
				$(Image + Counter).hide();
				$(selector + Counter).attr("disabled", true);
			}
		}
	},

	CheckImageForCountryMilestone: function (PrevDate, MilestoneNew, Selector, IsStart) {
		//Check Connected/Disconnected Image
		if (!IsStart) {
			$('#' + Selector).show();
		}
		if (MilestoneNew[0].MilestoneType == "P" || MilestoneNew[0].MilestoneType == "S" || MilestoneNew[0].MilestoneType == "O") {
			if (PrevDate == MilestoneNew[0].ConnectedDate) {
				$('#' + Selector).attr('src', '/_layouts/SPUI/images/ppmLinkIcon.png');
			}
			else {
				$('#' + Selector).attr('src', '/_layouts/SPUI/images/ppmUnLinkIcon.png');
			}
		}
		else if (MilestoneNew[0].MilestoneType == "C") {
			if (PrevDate == MilestoneNew[0].ConnectedDate) {
				$('#' + Selector).attr('src', '/_layouts/SPUI/images/cmConnected.png');
			}
			else {
				$('#' + Selector).attr('src', '/_layouts/SPUI/images/cmReconnect.png');
			}
		}
		else {
			$('#' + Selector).hide();
		}
	},
	CheckImages: function (DropdownVal, textBoxId, ImageId, counter) {
		$(ImageId + counter).attr("visible", true);
		$.each(LocalData, function (inex, ele) {
			if (ele.Id == DropdownVal) {
				if (ele.MilestoneType == "P" || ele.MilestoneType == "S" || ele.MilestoneType == "O") {
					if (ele.ConnectedDate == $(textBoxId + counter).val()) {
						$(ImageId + counter).attr('src', '/_layouts/SPUI/images/ppmLinkIcon.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
					}
					else {
						$(ImageId + counter).attr('src', '/_layouts/SPUI/images/ppmUnLinkIcon.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
					}
				}
				if (ele.MilestoneType == "C") {
					if (ele.ConnectedDate == $(textBoxId + counter).val()) {
						$(ImageId + counter).attr('src', '/_layouts/SPUI/images/cmConnected.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
					}
					else {
						$(ImageId + counter).attr('src', '/_layouts/SPUI/images/cmReconnect.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
					}
				}
			}
		});
	},
	MilestoneChangeImages: function (DropdownVal, isFromMilestone, counter) {
		var imageId;
		var milestoneIdControl;
		var milestoneTypeControl;
		var fromMilestoneTimestampControl;
		if (isFromMilestone) {
			imageId = "#Image_start_" + counter;
			milestoneIdControl = "#hdnFromMilestoneId_" + counter;
			milestoneTypeControl = "#hdnFromMilestoneType_" + counter;
			fromMilestoneTimestampControl = "#hdnFromMilestoneTimestamp_" + counter;
		}
		else {
			imageId = "#Image_end_" + counter;
			milestoneIdControl = "#hdnToMilestoneId_" + counter;
			milestoneTypeControl = "#hdnToMilestoneType_" + counter;
			fromMilestoneTimestampControl = "#hdnToMilestoneTimestamp_" + counter;
		}
		$.each(LocalData, function (inex, ele) {
			if (ele.Id == DropdownVal) {
				$(imageId).show();
				$(milestoneIdControl).val(ele.ProjectMilestoneId);
				$(milestoneTypeControl).val(ele.MilestoneType);
				$(fromMilestoneTimestampControl).val(ele.MilestoneLastModifiedOn);
				if (ele.MilestoneType == "P" || ele.MilestoneType == "S" || ele.MilestoneType == "O") {
					if (ele.IsConnected == 1) {
						$(imageId).attr('src', '/_layouts/SPUI/images/ppmLinkIcon.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
					}
					else {
						$(imageId).attr('src', '/_layouts/SPUI/images/ppmUnLinkIcon.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
					}
				}
				else if (ele.MilestoneType == "C") {
					if (ele.IsConnected == 1) {
						$(imageId).attr('src', '/_layouts/SPUI/images/cmConnected.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);;
					}
					else {
						$(imageId).attr('src', '/_layouts/SPUI/images/cmReconnect.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
					}
				}
				else {
					$(imageId).hide();
				}
			}
		}
		);
	},

	LoadMilestoneImages: function (MilestoneType, IsConnected, selector) {
		$(selector).show();
		if (MilestoneType == "P" || MilestoneType == "S" || MilestoneType == "O") {
			if (IsConnected == 1) {
				$(selector).attr('src', '/_layouts/SPUI/images/ppmLinkIcon.png');
			}
			else {
				$(selector).attr('src', '/_layouts/SPUI/images/ppmUnLinkIcon.png');
			}
		}
		else if (MilestoneType == "C") {
			if (IsConnected == 1) {
				$(selector).attr('src', '/_layouts/SPUI/images/cmConnected.png');
			}
			else {
				$(selector).attr('src', '/_layouts/SPUI/images/cmReconnect.png');
			}
		}
		else {
			$(selector).hide();
		}
	},

	AddNewAdHoc: function () {
		$.GenericFTECalculator._newRowID++;
		var adhocComment = $("#c_comments").val();
		var addAdhocRow = "<tr style='line-height:24px;'>" +
			"<td style='visibility:hidden; width:10px'>" +
			"     <input type='hidden' id='hdnExplanation_" + $.GenericFTECalculator._newRowID + "' value='" + escape(adhocComment) + "'/>" +
			"</td>" +
			" <td style='width: 70px; text-align:left;'>" +
			"     <img id='imgDelete_New" + $.GenericFTECalculator._newRowID + "' adHockRowId='New" + $.GenericFTECalculator._newRowID + "' src='/_layouts/SPUI/images/closeSmall.png' style= 'margin: 2px 0 0 10px;' alt='' class='imgDeleteGenereicAdhoc' originalStartDate='" + $("#d_startDate").val() + "' />" +
			"</td>" +
			"<td style='width: 140px;text-align: left;'>" +
			"    <span id = 'lblStartDate_New_" + $.GenericFTECalculator._newRowID + "'><a class='adhocDate' style='text-decoration: underline;' href='JavaScript://' onClick='$.GenericFTECalculator.EditInterimFrequency(this); return false;'>" + $("#d_startDate").val() + "</a></span>" +
			"</td>" +
			"<td style='width: 160px;text-align: left;'>" +
			"    <span id = 'lblEndDate_New_" + $.GenericFTECalculator._newRowID + "'><a class='adhocDate' style='text-decoration: underline;' href='JavaScript://' onClick='$.GenericFTECalculator.EditInterimFrequency(this); return false;'>" + $("#d_endDate").val() + "</a></span>" +
			"</td>" +
			"<td style='text-align:center; width: 90px;'>" +
			"    <input type='text' id='txtWeeklyHours_New_" + $.GenericFTECalculator._newRowID + "' value='' class='clsGenericWeeklyhoursAdHoc validateRange' from='0' to='9999.99' formating='4,2' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px; padding-left: 2px;' />" +
			"</td>" +
			"<td style='text-align:center; width: 90px;'>" +
			"    <input type='text' id='txtFTE_New_" + $.GenericFTECalculator._newRowID + "' value='' class='clsGenericFTEAdHoc validateRange' from='0' to='999.999' formating='3,3' isChanged='false' style='width: 50px; height: 20px; border: 1px solid #ABADB3; padding-left: 2px; padding-left: 2px;' />" +
			"</td>" +
			"<td style='width: 70px; text-align:left;'>" +
			"    <img id='imgInfo_New_" + $.GenericFTECalculator._newRowID + "' adHockRowId='New_" + $.GenericFTECalculator._newRowID + "' src='/_layouts/SPUI/images/searchIcon.png' style= 'margin: 2px 0 0 10px;' alt='' class='imgInfo' />" +
			"</td>" +
			"</tr>";

		$("#GenericAdHocRow").append(addAdhocRow);
		$("#isGenericDirtyCalculator").val('True');

		setTimeout(function () {
			rm.qtip.showInfo("#imgInfo_New_" + $.GenericFTECalculator._newRowID, adhocComment);
			rm.validation.clearError($(".toMilestoneEndDate"));
		}, 200);

	},

	ClearCalculatorDirty: function () { $("#isGenericDirtyCalculator").val('False'); },

	ClearCalculator: function () {
		$("#GenericAdHocRow").empty();
		$("#GenericFTECalculator").empty();
		$("#generic_small_Calc_TxtFTE").val("");
		$("#generic_small_Calc_SpanTotalHours").empty();
		rm.validation.clearError($("#generic_small_Calc_TxtFTE"));
	},
	DeleteGenericRow: function (obj) {
		var genericCalculatorRow = $(obj).parent().parent();
		var isNewGenericCalculatorRow = genericCalculatorRow.attr("isnew") == "true";
		var isFirstRow = genericCalculatorRow.index() == 0;

		$.GenericFTECalculator.isRequestHardOrSoftBooked = true; //TODO: remove when ready
		if (!isNewGenericCalculatorRow) {
			$.GenericFTECalculator._GenericRowDeletedList.push({
				genericCalculatorId: $(obj).attr("genericRowId"),
				genericCalculatorRowIndex: $(obj).attr("rowIndexAttr")
			});
			$("#isGenericDirtyCalculator").val('True');
		}

		if (isFirstRow) {
			genericCalculatorRow.parent().find("tr:nth-child(2) [id^=dtStart]").removeAttr("allowBlank");
		}

		genericCalculatorRow.remove();

	},
	DeleteAllGenericRow: function () {
		$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
			var isNewGenericCalculatorRow = $(ele).attr("isnew") == "true";
			if (!isNewGenericCalculatorRow) {
				$.GenericFTECalculator._GenericRowOldDeletedList.push({
					genericCalculatorId: $(ele).find('[id^=imgDelete_New]').attr('genericRowId')
				});
			}
		});
	},
	DeleteAdHocRow: function (obj) {
		var adhocRow = $(obj).parent().parent();
		var isNewAdhocRow = ($(obj).attr("adHockRowId").indexOf('New') != -1);
		if (!isNewAdhocRow) {
			$.GenericFTECalculator._deletedList.push({ FTETAdHocId: $(obj).attr("adHockRowId") });

			$("#isGenericDirtyCalculator").val('True');
		}

		adhocRow.remove();
		$.GenericFTECalculator.OnAdhocRowRemoveHandler();
		rm.ui.ribbon.delayedRefresh();

	},

	DeleteAllAdHocRow: function () {
		$.each($("#GenericAdHocRow").find("tr"), function (index, ele) {
			if ($(ele).find('[id^=imgDelete]').attr('adHockRowId').indexOf('New') == -1) {
				$.GenericFTECalculator._deletedOldAdhocList.push({
					FTETAdHocId: $(ele).find('[id^=imgDelete]').attr('adHockRowId')
				});
			}
		});
	},

	getInputAttributesForWeeklyHours: function () {
		return $.GenericFTECalculator.AllowEditing ? "class='clsGenericWeeklyhoursAdHoc validateRange'" : " readonly='readonly' class='clsGenericWeeklyhoursAdHoc validateRange grayed' ";
	},

	getInputAttributesForFte: function () {
		return $.GenericFTECalculator.AllowEditing ? " class='clsGenericFTEAdHoc validateRange' " : " readonly='readonly' class='clsGenericFTEAdHoc validateRange grayed' ";
	},

	getAdhocFrequencyDateLink: function (displayValue, allowEdit) {
		if (allowEdit) {
			return $.GenericFTECalculator.AllowEditing ? "<a class='adhocDate' style='text-decoration: underline;' href='JavaScript://' onClick='$.GenericFTECalculator.EditInterimFrequency(this); return false;'>" + displayValue + "</a>" : displayValue;
		}
		else {
			return $.GenericFTECalculator.AllowEditing ? "<a class='adhocDate' style='text-decoration: underline;' href='JavaScript://' onClick='alert(Resources.AdhocEditDisabled); return false;'>" + displayValue + "</a>" : displayValue;
		}
	},

	UpdatedConnedtedValues: function (requestId, projectId, resourceId, countryId) {
		var url = "";
		if (requestId != null) {
			url = rm.ajax.requestSvcUrl + "GetInitiateCalculatorbyRequest?requestId=" + requestId; // Request already saved.
		}
		else {
			url = rm.ajax.requestSvcUrl + "RenderInitiateCalculator?projectId=" + projectId + "&resourceId=" + resourceId + "&countryId=" + countryId; // New Request.
		}

		$.ajax({
			url: url,
			cache: false,
			success: function (data) {
				if (data.staticInitiateCalculatorList) {
					for (var i = 0; i < data.staticInitiateCalculatorList.length; i++) {
						$("#txtWeeklyHours_" + data.staticInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId).attr("qipValue", data.staticInitiateCalculatorList[i].QipWeeklyHours);
						$("#txtFTE_" + data.staticInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId).attr("qipValue", data.staticInitiateCalculatorList[i].QipFTE);

						$("#hdnRequestCalculatorTimestamp_" + data.staticInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].RequestCalculatorTimestamp);
						$("#hdnRequestCalculatorId_" + data.staticInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].RequestCalculatorId);
						$("#hdnCountryTimestamp_" + data.staticInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].CountryTimestamp);
						$("#hdnCountryCalculatorId_" + data.staticInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].CountryCalculatorId);
						$("#hdnFTETypeId_" + data.staticInitiateCalculatorList[i].FTETypeFTEMilestoneTypeId).val(data.StaticInitiateCalcTimestamp[i].FteTypeId);
					}
				}
			},
			error: function () { rm.ui.messages.addError(Resources.FailedToGetQipData); }
		});
	},

	renderCalculator: function (requestId, projectId, resourceId, countryId, calculatorTitle, makeAsyncCall, resourceTypeOrganizationId) {
		if (!genericCalculator.multiEditMode) {
			$("#genericAdhocContainer").removeClass("hideMe");
		}
		$.GenericFTECalculator._newGenericRowID = 0;
		$("#GenericSmallCalculatorTitle").html(calculatorTitle);
		$.GenericFTECalculator._deletedList.length = 0;
		var setDefaultMilestoneDates = false;

		if ($('#GenericFTECalculator tr').length == 0) {
			$.GenericFTECalculator.AddFirstGenericRow(projectId, requestId, countryId, resourceTypeOrganizationId, $.GenericFTECalculator._resourceId);
			if (requestId == null) {
				setDefaultMilestoneDates = true;
			}
		}

		$.each($('#GenericFTECalculator').children(), function (i) {
			$(this).remove();
		});

		$.each($('#GenericAdHocRow').children(), function (i) {
			$(this).remove();
		});

		$(".FTE_Calculator").hide();
		$.GenericFTECalculator._interimFrequencyEnabled = false;
		if (genericCalculator.multiEditMode) {
			genericCalculator.renderCalculatorForMultiEdit(resourceId, genericCalculator.getStageCount());
		}
		else {
			if (requestId != 0 && requestId != null) {
				genericCalculator.renderCalculatorByRequestId(requestId, resourceId, makeAsyncCall, setDefaultMilestoneDates);
			} else {
				genericCalculator.renderDefaultGenericCalculatorByResourceTypeId(resourceId, makeAsyncCall, setDefaultMilestoneDates);
			}
		}
	},

	disconnectAll: function () {
		$(".imgConnected").attr('src', '/_layouts/SPUI/images/qipDisconnected.png').addClass('imgReconnect').removeClass('imgConnected').attr("connectStatus", 0).attr("connectStatusChanged", 1);
	},
	RecalculateFTEValues: function () {
		$.each($(".clsGenericWeeklyhours"), function (index, ele) {
			$.GenericFTECalculator.CalculateWeeklyHourFTE($(ele), "WH", true);
		});

		$.each($(".clsGenericWeeklyhoursAdHoc"), function (index, ele) {
			$.GenericFTECalculator.CalculateWeeklyHourFTE($(ele), "WH", true);
		});
		$.GenericFTECalculator._fireChangeEvent = true;
	},
	//GS:Code Review-Since there is no functionality implemented in this method we need to remove this method
	IsPromptRequiredForConnectDisconnectStatus: function () { return false; },
	//GS:Code Review-This method will not be called from anywhere so we need to remove this method
	ShowConnectDisconnectChoiceDialog: function (addingNewRequest) {
		var confirmationTable = "<div class='instructionalText'>" + Resources.QuipValuesMatchInstructionalText + "</div>";
		confirmationTable += "<table id='dialogTable' class='dialogTableConfirmConnect' border='1'><tr style='font-weight:600; line-height: 24px;'><td>Stage</td><td>Milestones</td><td>Weekly hours</td><td>FTE</td><td>Connect To budget</td><td>Keep Disconnected</td></tr>";
		confirmationTable += "</table> <div class='dialogTableConfirmConnectButtons'><input type='button' id='btnOk_connectDisconnect' value='OK' class='button q_calculatorButtonSave btnOklChangeProject'><input type='button' id='btnCancel_connectDisconnect' class='button btnCancelChangeProject' value='Cancel'> </div>";

		var container = $("#connectDisconnectDialog");
		if (container.length == 0) {
			container = $("<div id='connectDisconnectDialog' />");
			$('body').append(container);
		}
		container.html(confirmationTable).dialog({
			modal: true,
			cache: false,
			closeOnEscape: false,
			title: "Confirm connect status",
			resizable: false,
			width: 620,
			height: 400,
			open: function () {
				$('.ui-dialog-titlebar-close').unbind('click');
				$("#btnCancel_connectDisconnect,.ui-dialog-titlebar-close").click(function () {
					if (confirm(Resources.ConfirmOnConnectDisconnectDialogCancel)) {
						container.html("").dialog('close');
					}
				});

				$("#btnOk_connectDisconnect").click(function () {
					var errorFound = false;
					var tableRows = $("#dialogTable tr[calculatorRow='true']");
					$.each(tableRows, function (index, ele) {
						checkedRadio = $(ele).find("[type=radio]:checked");
						if (checkedRadio.length == 0) {
							alert("Please select the option to connect or disconnect and click OK again.");
							errorFound = true;
							return false;
						}
						else {
							$("#imgStatic_" + $(ele).attr("fteTypeFTEMileStoneTypeId")).attr('connectStatus', checkedRadio.val());
						}
					});

					if (!errorFound) {
						$.GenericFTECalculator.save(addingNewRequest);
						$.GenericFTECalculator.DialogOkClickHandler();
						container.html("").dialog('close');
					}
				});
			}
		});
	},

	IsValid: function () {
		var isNewRequest = $("[id$=AddingNewRequest]").val();
		var isValid = true;
		var allInputs = genericCalculator.multiEditMode ? $("#GenericQIP_Calculator tr:not([isNew=true]) .validateRange:visible") : $("#GenericQIP_Calculator .validateRange:visible");
		$.each(allInputs, function () {
			if (!$.q.rangeValidate($(this))) { isValid = false; }
		});
		//Clear the error message 
		$.GenericFTECalculator.ClearErrorMessage();
		//GS:Code Review-When iterate over stages please refer tBody id instead refering table Id and skipping first row
		$("#GenericFTETable tr").each(function (index, element) {
			if (index > 1) {
				var fte = $(this).find(".clsGenericFTE");
				var weeklyHours = $(this).find(".clsGenericWeeklyhours");

				//In multiedit mode either FTE or WeeklyHours are required, Clear error from FTE if WeeklyHours are entered and vice-versa
				if (genericCalculator.multiEditMode) {
					if ($(fte).val() == "" && $(weeklyHours).val() == "") {
						if (!$.q.rangeValidate($(fte))) { isValid = false; }
						if (!$.q.rangeValidate($(weeklyHours))) { isValid = false; }
					}
					else {
						if ($(fte).val() != "") {
							if (!$.q.rangeValidate($(fte))) { isValid = false; }
							rm.validation.clearError($(weeklyHours));
						}
						if ($(weeklyHours).val() != "") {
							if (!$.q.rangeValidate($(weeklyHours))) { isValid = false; }
							rm.validation.clearError($(fte));
						}
					}
				}

				var milestoneStartDate = $(this).find(".class_milestoneStart input[type=text]");
				var milestoneEndDate = $(this).find(".class_milestoneEnd input[type=text]");
				var startDate = rm.date.getDateFromQDateString(milestoneStartDate.val());
				var stopDate = rm.date.getDateFromQDateString(milestoneEndDate.val());

				var isStopDateValid = rm.date.isValidDate(milestoneEndDate.val(), genericCalculator.multiEditMode);
				var isStartDateValid = rm.date.isValidDate(milestoneStartDate.val(), genericCalculator.multiEditMode);
				//Drop down list(milestone name)
				var milestoneStartId = $(this).find(".fromMilestoneStartDate");
				var milestoneEndId = $(this).find(".toMilestoneEndDate");
				//Validate the milestone name 
				if ($(milestoneStartId).val() == "-1" && $(milestoneStartId).attr("allowBlank") != "true") {
					rm.validation.addError($(milestoneStartId), Resources.SelectMilestone);//to be moved to Resource
					isValid = false;
				}
				if ($(milestoneEndId).val() == "-1" && $(milestoneEndId).attr("allowBlank") != "true") {
					rm.validation.addError($(milestoneEndId), Resources.SelectMilestone);//to be moved to Resource                   
					isValid = false;
				}

				//Start: validating start date
				if ($.trim(milestoneStartDate.val()) == "" && $(milestoneStartDate).attr("allowBlank") != "true") {
					rm.validation.addError("#" + $(milestoneStartDate).attr('id'), Resources.StartDateIsBlank);
					isValid = false;
				}
				else {
					if (!isStartDateValid) {
						rm.validation.addError("#" + $(milestoneStartDate).attr('id'), Resources.InvalidDateFormat);
						isValid = false;
					}
				}

				//AB start date cant be from past
				//GS:Changes done as it will not work in modify request page
				var fromMilestoneDate;
				var validateDateInPast = true;
				if (isNewRequest == "false") {
					fromMilestoneDate = $(element).find('[id^=hdnFromMilestoneDate]').val();
					if (milestoneStartDate.val() == fromMilestoneDate) { validateDateInPast = false; }
				}

				if (validateDateInPast == true && isStartDateValid && rm.date.isQDateDateInPast(milestoneStartDate.val()) && $(milestoneStartDate).attr("allowBlank") != "true") {
					rm.validation.addError("#" + $(milestoneStartDate).attr('id'), Resources.StartDateInPast);
					isValid = false;
				}
				//End: validating the start date

				//Start: validating the end date
				if ($.trim(milestoneEndDate.val()) == "" && $(milestoneEndDate).attr("allowBlank") != "true") {
					rm.validation.addError("#" + $(milestoneEndDate).attr('id'), Resources.StopDateIsBlank);
					isValid = false;
				}
				else {
					if (!isStopDateValid) {
						rm.validation.addError("#" + $(milestoneEndDate).attr('id'), Resources.InvalidDateFormat);
						isValid = false;
					}
				}
				//End: validating the end date

				//if in multi edit mode, validate start and stop dates against each other only if both are present
				if (!genericCalculator.multiEditMode || (genericCalculator.multiEditMode && milestoneStartDate.val() != "" && milestoneEndDate.val() != "")) {
					//Start: validate start date and end date
					if (startDate > stopDate && isStartDateValid && isStopDateValid) {
						rm.validation.addError("#" + $(milestoneStartDate).attr('id'), Resources.StartDateGreaterThanStopDate);
						rm.validation.addError("#" + $(milestoneEndDate).attr('id'), Resources.StopDateLessThanStartDate);
						isValid = false;
					}
				}

				//Start: Validate overlapping
				if (index > 2) {
					//GS:Code Review-User jquery closet,first,next,previous,last to validate gaps and overlpas between stages
					var endDateArray = $.GenericFTECalculator.GetAllStartOrEndDateElement(false);
					var StartDateArray = $.GenericFTECalculator.GetAllStartOrEndDateElement(true);
					var msg = "You have entered dates that overlaps with another current stage in the FTE calculator. Please review and modify the dates accordingly";
					var errorMsg = "You can't have any spaces in dates between milestones"
					for (var i = 0; i < index - 2; i++) {
						var dateToCompareStr = endDateArray[i].val();
						var startDateStr = StartDateArray[i + 1].val();

						if (dateToCompareStr != "" && startDateStr != "" && !genericCalculator.multiEditMode) {
							var dateToCompare = rm.date.getDateFromQDateString(dateToCompareStr);
							var startDate = rm.date.getDateFromQDateString(startDateStr);

							if (startDate <= dateToCompare && isStartDateValid) {
								rm.validation.addError("#" + $(milestoneStartDate).attr('id'), msg);
								isValid = false;
							}

							//AB
							//We should also not allow any spaces in dates between milestones. We will need to add validation into the calculator to enforce this. 
							var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds                       
							var diffDays = Math.round(Math.abs((startDate.getTime() - dateToCompare.getTime()) / (oneDay)));

							if (diffDays > 1 && isStartDateValid) {
								rm.validation.addError("#" + $(milestoneStartDate).attr('id'), errorMsg);
								isValid = false;
							}
							//end date > previous stage end date
							if (stopDate < dateToCompare && isStopDateValid) {
								rm.validation.addError("#" + $(milestoneEndDate).attr('id'), msg);
								isValid = false;
							}
						}
					}
				}
				//End validate overlapping
			}
		});
		if (genericCalculator.areAdhocDatesBeyondRequestStopDate()) {
			isValid = false;
		}
		return isValid;
	},
	saveCalculator: function () {
		return $.GenericFTECalculator.IsValid();
	},
	ClearErrorMessage: function () {
		rm.validation.clearError($(".fromMilestoneStartDate"));
		rm.validation.clearError($(".toMilestoneEndDate"));
		$("#GenericFTETable tr").each(function (index, element) {
			if (index > 1) {
				var milestoneStartDate = $(this).find(".class_milestoneStart input[type=text]");
				var milestoneEndDate = $(this).find(".class_milestoneEnd input[type=text]");
				rm.validation.clearError($(milestoneStartDate));
				rm.validation.clearError($(milestoneEndDate));
			}
		});
	},
	GetAllStartOrEndDateElement: function (isStartDate) {
		var startDateArray = new Array();
		var endDateArray = new Array();
		$("#GenericFTETable tr").each(function (index, element) {
			if (index > 1) {
				var milestoneStartDate = $(this).find(".class_milestoneStart input[type=text]");
				var milestoneEndDate = $(this).find(".class_milestoneEnd input[type=text]");
				startDateArray.push(milestoneStartDate);
				endDateArray.push(milestoneEndDate);
			}
		});

		if (isStartDate) {
			return startDateArray;
		}
		else {
			return endDateArray;
		}
	},
	GetAllCustomMilestoneIds: function () {
		var customMilestoneIds = new Array();
		var milestoneId;
		var milestoneType;
		var milestoneStatus;
		var milestoneDate;
		var isMilestoneDateNew = false;
		$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
			{
				milestoneType = $(ele).find('[id^=hdnFromMilestoneType]').val();
				if (milestoneType == "C") {
					milestoneId = $(ele).find('[id^=hdnFromMilestoneId]').val();
					milestoneStatus = $(ele).find("option[value ='" + $(ele).find('[id^=milestone_start]').val() + "']").attr("disabled");
					milestoneDate = rm.date.getDateFromQDateString($(ele).find('[id^=dtStart]').val())
					isMilestoneDateNew = milestoneDate >= new Date();

					if (milestoneStatus != "disabled" || isMilestoneDateNew == true)
						customMilestoneIds.push(milestoneId);
				}
				milestoneType = $(ele).find('[id^=hdnToMilestoneType]').val();
				if (milestoneType == "C") {
					milestoneId = $(ele).find('[id^=hdnToMilestoneId]').val();
					milestoneStatus = $(ele).find("option[value ='" + $(ele).find('[id^=milestone_end]').val() + "']").attr("disabled")
					milestoneDate = rm.date.getDateFromQDateString($(ele).find('[id^=dtEnd]').val())
					isMilestoneDateNew = milestoneDate >= new Date();

					if (milestoneStatus != "disabled" || isMilestoneDateNew == true)
						customMilestoneIds.push(milestoneId);
				}
			}
		});
		return customMilestoneIds.join(",");
	},

	IsValidCalculator: function () {
		var isValid = true;

		if ($($.GenericFTECalculator.resourceTypeSelector).val() != -1 &&
			$($.GenericFTECalculator.countrySelector).val() != -1 &&
			$.trim($($.GenericFTECalculator.startDateSelector).val()) != "" &&
			$.trim($($.GenericFTECalculator.stopDateSelector).val()) != "" &&
			$.trim($($.GenericFTECalculator.fteSelector).val()) != ""
		) {

			var isStartDateValid = rm.date.isValidDate($($.GenericFTECalculator.startDateSelector).val(), false);
			var isStopDateValid = rm.date.isValidDate($($.GenericFTECalculator.stopDateSelector).val(), false);

			if (isStartDateValid && isStopDateValid) {
				var startDate = rm.date.getDateFromQDateString($($.GenericFTECalculator.startDateSelector).val());
				var stopDate = rm.date.getDateFromQDateString($($.GenericFTECalculator.stopDateSelector).val());

				if (startDate > stopDate) {
					rm.validation.addError($.GenericFTECalculator.startDateSelector, Resources.StartDateGreaterThanStopDate);
					rm.validation.addError($.GenericFTECalculator.stopDateSelector, Resources.StopDateLessThanStartDate);
					isValid = false;
				}
				else if (!$.q.rangeValidate($($.GenericFTECalculator.fteSelector))) {
					$("#generic_small_Calc_SpanTotalHours").empty();
					$.GenericFTECalculator._totalHours = "";
					$.GenericFTECalculator._fte = "";
					isValid = false;
				}
				else {
					$.q.formatText($("#generic_small_Calc_TxtFTE").get(0));
					$.GenericFTECalculator._totalHours = $("#generic_small_Calc_SpanTotalHours").html();
					$.GenericFTECalculator._fte = $("#generic_small_Calc_TxtFTE").html();
				}
			}
			else {
				isValid = false;
			}
		}
		else {
			isValid = false;
		}

		return isValid;
	},

	save: function (addingNewRequest) {
		if (!$(this).hasClass("q_validation_error")) {
			var staticValues = new Array();
			var adHocValues = new Array();
			var staticTimestampValues = new Array();
			var adHocTimestampValues = new Array();


			$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
				var isUpdated = "";
				var isNewGenericCalculatorRow = $(ele).attr("isnew") == "true";

				if (addingNewRequest || isNewGenericCalculatorRow) {
					isUpdated = DMLOperation_E.Insert;
				}
				else {
					isUpdated = DMLOperation_E.Update;
				}

				var fromMilestoneTimestamp = genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnFromMilestoneTimestamp]');
				var fromMilestoneId = genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnFromMilestoneId]');
				var fromMilestoneType = genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnFromMilestoneType]');
				var toMilestoneTimestamp = genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnToMilestoneTimestamp]');
				var toMilestoneId = genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnToMilestoneId]');
				var toMilestoneType = genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnToMilestoneType]');
				var requestCalculatorTimestamp = genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnRequestCalculatorTimestamp]');
				var requestCalculatorId = genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnGenericInitiateCalculatorId]');

				staticTimestampValues.push({
					FromMilestoneTimestamp: fromMilestoneTimestamp == "null" || fromMilestoneTimestamp == "" ? null : fromMilestoneTimestamp,
					ToMilestoneTimestamp: toMilestoneTimestamp == "null" || toMilestoneTimestamp == "" ? null : toMilestoneTimestamp,
					FromMilestoneId: fromMilestoneId == "null" || fromMilestoneId == "" ? null : fromMilestoneId,
					ToMilestoneId: toMilestoneId == "null" || toMilestoneId == "" ? null : toMilestoneId,
					FromMilestoneType: fromMilestoneType == "null" || fromMilestoneType == "" ? null : fromMilestoneType,
					ToMilestoneType: toMilestoneType == "null" || toMilestoneType == "" ? null : toMilestoneType,
					RequestCalculatorTimestamp: requestCalculatorTimestamp == "null" || requestCalculatorTimestamp == "" ? null : requestCalculatorTimestamp,
					RequestCalculatorId: requestCalculatorId == "null" || requestCalculatorId == "" ? null : requestCalculatorId
				});

				if (isUpdated != "") {
					staticValues.push({
						Id: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnGenericInitiateCalculatorId]'),
						FromMilestoneId: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnFromMilestoneId]'),
						ToMilestoneId: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnToMilestoneId]'),
						FromMilestoneConnected: genericCalculator.getControlAttributeValueOrDefaultIfBlank(ele, '[id^=Image_start]', 'connectStatus', false),
						ToMilestoneConnected: genericCalculator.getControlAttributeValueOrDefaultIfBlank(ele, '[id^=Image_end]', 'connectStatus', false),
						FromMilestoneType: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnFromMilestoneType]'),
						ToMilestoneType: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=hdnToMilestoneType]'),
						FromMilestoneDate: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=dtStart]'),
						ToMilestoneDate: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=dtEnd]'),
						WeeklyHours: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=txtWeeklyHours_New]'),
						FTE: genericCalculator.getControlValueOrNullIfBlank(ele, '[id^=txtFTE_New]'),
						DMLOperation: isUpdated
					});
				}
			});
			if (!addingNewRequest) {
				$.each($.GenericFTECalculator._GenericRowDeletedList, function (index, ele) {
					staticValues.push({
						Id: ele.genericCalculatorId,
						FromMilestoneId: -1,
						ToMilestoneId: -1,
						FromMilestoneConnected: 0,
						ToMilestoneConnected: 0,
						FromMilestoneType: null,
						ToMilestoneType: null,
						FromMilestoneDate: Date(),
						ToMilestoneDate: Date(),
						WeeklyHours: 0,
						FTE: 0,
						DMLOperation: DMLOperation_E.Delete,
						DeletedCalculatorRowIndexOnUi: ele.genericCalculatorRowIndex
					});
				});
			}

			if (!addingNewRequest) {
				$.each($.GenericFTECalculator._GenericRowOldDeletedList, function (index, ele) {
					staticValues.push({
						Id: ele.genericCalculatorId,
						FromMilestoneId: -1,
						ToMilestoneId: -1,
						FromMilestoneConnected: 0,
						ToMilestoneConnected: 0,
						FromMilestoneType: null,
						ToMilestoneType: null,
						FromMilestoneDate: Date(),
						ToMilestoneDate: Date(),
						WeeklyHours: 0,
						FTE: 0,
						DMLOperation: DMLOperation_E.Delete
					});
				});
			}

			$.each($("#GenericAdHocRow").find("tr"), function (index, ele) {
				var isUpdated = "";
				if (addingNewRequest || $(ele).find('[id^=imgDelete]').attr('adHockRowId').indexOf('New') != -1) {
					isUpdated = DMLOperation_E.Insert; // "Insert";
				}
				else if (($(ele).find('[id^=txtWeeklyHours]').val() != $(ele).find('[id^=txtWeeklyHours]').attr("actualValue")) ||
					($(ele).find('[id^=txtFTE]').val() != $(ele).find('[id^=txtFTE]').attr("actualValue")) ||
					($(ele).find('[id^=lblStartDate]').find("a").html() != $(ele).find('[id^=lblStartDate]').find("a").attr("actualValue")) ||
					($(ele).find('[id^=lblEndDate]').find("a").html() != $(ele).find('[id^=lblEndDate]').find("a").attr("actualValue")) ||
					(unescape($(ele).find('[id^=hdnExplanation]').val()) != unescape($(ele).find('[id^=hdnExplanation]').attr("actualValue")))) {
					isUpdated = DMLOperation_E.Update; //"Update";
				}

				if (isUpdated != DMLOperation_E.Insert) {
					var requestCalculatorTimestamp = $(ele).find('[id^=hdnAdhocCalculatorTimestamp]').val();
					var requestCalculatorId = $(ele).find('[id^=hdnAdhocCalculatorId]').val();

					adHocTimestampValues.push({
						CountryTimestamp: null,
						CountryCalculatorId: null,
						RequestCalculatorTimestamp: requestCalculatorTimestamp == "null" || requestCalculatorTimestamp == "" ? null : requestCalculatorTimestamp,
						RequestCalculatorId: requestCalculatorId == "null" || requestCalculatorId == "" ? null : requestCalculatorId
					});
				}

				if (isUpdated != "") {
					adHocValues.push({
						FTETypeId: $(ele).find('[id^=imgDelete]').attr('adHockRowId').replace("New", ""),
						WeeklyHours: $(ele).find('[id^=txtWeeklyHours]').val(),
						FTE: $(ele).find('[id^=txtFTE]').val(),
						Comments: unescape($(ele).find('[id^=hdnExplanation]').val()),
						StartDate: $(ele).find('[id^=lblStartDate]').find("a").html(),
						EndDate: $(ele).find('[id^=lblEndDate]').find("a").html(),
						DMLOperation: isUpdated
					});
				}
			});

			$.each($.GenericFTECalculator._deletedList, function (index, ele) {
				adHocValues.push({
					FTETypeId: ele.FTETAdHocId,
					WeeklyHours: 0,
					FTE: 0,
					Comments: "",
					StartDate: Date(),
					EndDate: Date(),
					DMLOperation: DMLOperation_E.Delete//"Delete"
				});
			});

			if (!addingNewRequest) {
				$.each($.GenericFTECalculator._deletedOldAdhocList, function (index, ele) {
					adHocValues.push({
						FTETypeId: ele.FTETAdHocId,
						WeeklyHours: 0,
						FTE: 0,
						Comments: "",
						StartDate: Date(),
						EndDate: Date(),
						DMLOperation: DMLOperation_E.Delete//"Delete"
					});
				});
			}

			if (PostBackForm()) {
				$('[id$=FTECalculatorStatic]').val(JSON.stringify(staticValues));
				$('[id$=FTECalculatorAdhoc]').val(JSON.stringify(adHocValues));
			}
			else {
				$.GenericFTECalculator._genericRowsValues = staticValues;
				$.GenericFTECalculator._adHocValues = adHocValues;
				$.GenericFTECalculator._genericRowTimestampValues = staticTimestampValues;
				$.GenericFTECalculator._adHocTimestampValues = adHocTimestampValues;
			}
		}
		$.GenericFTECalculator._GenericRowOldDeletedList.length = 0;
		$.GenericFTECalculator._deletedOldAdhocList.length = 0;
	},
	SetStartDateAndEndDateBasedOnMilestones: function () {
		var startDateArray = $.GenericFTECalculator.GetAllStartOrEndDateElement(true);
		var endDateArray = $.GenericFTECalculator.GetAllStartOrEndDateElement(false);
		var isNewRequest = $("[id$=AddingNewRequest]").val();
		if (startDateArray.length > 0 || endDateArray.length > 0) {
			var StartMilestoneDate = rm.date.getDateFromQDateString(startDateArray[0].val());
			var EndMilestoneDate = rm.date.getDateFromQDateString(endDateArray[endDateArray.length - 1].val());
			// if (IsStart) {
			$("[id$=txtStartDate]").val(startDateArray[0].val());
			$("[id$=txtStopDate]").val(endDateArray[endDateArray.length - 1].val());
			if (isNewRequest == "false") {
				editRequest.calculateNeedByDate();
			}
			if (startDateArray[0].val() != "") {
				rm.validation.clearError($("[id$=txtStartDate]"));
			}
		}
	},
	//Ab to set Milestone start and End Date
	SetStartAndEndMilestonesBasedOnDates: function (IsStart) {
		var length = $('#GenericFTETable tbody tr').length;
		$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
			if (IsStart) {
				if (index == 0) {
					if ($(ele).find(".class_milestoneStart option:selected").val() != -1) {
						var milestoneStartDate = $(ele).find(".class_milestoneStart input[type=text]");
						milestoneStartDate.val($("[id$=txtStartDate]").val());
						var fromMilestoneId = $(ele).find('[id^=hdnFromMilestoneId]').val();
						var fromMilestoneType = $(ele).find('[id^=hdnFromMilestoneType]').val();

						$.each(LocalData, function (index, element) {
							if (element.ProjectMilestoneId == fromMilestoneId && element.MilestoneType == fromMilestoneType) {

								if (element.ConnectedDate == $("[id$=txtStartDate]").val()) {
									if (element.MilestoneType == "P") {
										$(ele).find('[id^=Image_start]').attr('src', '/_layouts/SPUI/images/PPMLinkIcon.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
									}
									else if (element.MilestoneType == "C") {
										$(ele).find('[id^=Image_start]').attr('src', '/_layouts/SPUI/images/cmConnected.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
									}
								}
								else {
									if (element.MilestoneType == "P") {
										$(ele).find('[id^=Image_start]').attr('src', '/_layouts/SPUI/images/ppmUnLinkIcon.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
									}
									else if (element.MilestoneType == "C") {
										$(ele).find('[id^=Image_start]').attr('src', '/_layouts/SPUI/images/cmReconnect.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
									}
								}
							}
						});
					}
				}
			}
			else {
				if (index == length - 1) {

					if ($(ele).find(".class_toMilestoneEndDate option:selected").val() != -1) {
						var milestoneEndDate = $(ele).find(".class_milestoneEnd input[type=text]");
						milestoneEndDate.val($("[id$=txtStopDate]").val());

						var toMilestoneId = $(ele).find('[id^=hdnToMilestoneId]').val();
						var toMilestoneType = $(ele).find('[id^=hdnToMilestoneType]').val();

						$.each(LocalData, function (index, element) {
							if (element.ProjectMilestoneId == toMilestoneId && element.MilestoneType == toMilestoneType) {

								if (element.ConnectedDate == $("[id$=txtStopDate]").val()) {
									if (element.MilestoneType == "P") {
										$(ele).find('[id^=Image_end]').attr('src', '/_layouts/SPUI/images/PPMLinkIcon.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
									}
									else if (element.MilestoneType == "C") {
										$(ele).find('[id^=Image_end]').attr('src', '/_layouts/SPUI/images/cmConnected.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
									}
								}
								else {
									if (element.MilestoneType == "P") {
										$(ele).find('[id^=Image_end]').attr('src', '/_layouts/SPUI/images/ppmUnLinkIcon.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
									}
									else if (element.MilestoneType == "C") {
										$(ele).find('[id^=Image_end]').attr('src', '/_layouts/SPUI/images/cmReconnect.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
									}
								}
							}
						});

					}
				}
			}
		});
	},

	UpdateNextSatge: function (prev, rowToBeupdated) {
		var PrevDate;
		var CurrentDate;
		var Nextdate;

		PrevDate = $(prev).find('[id^=dtEnd]').val();
		CurrentDate = rm.date.getDateFromQDateString(PrevDate);
		if (null != CurrentDate) {
			Nextdate = CurrentDate.setDate(CurrentDate.getDate() + 1);
		}

		$(rowToBeupdated).find('[id^=dtStart]').val(rm.date.getQDateStringFromDate(CurrentDate));
	},
	ChangeNextMilestoneDateOnImageClick: function (Next, NextDate) {
		var CurrentDate = rm.date.getDateFromQDateString(NextDate);
		if (NextDate != "") {
			var Nextdate = CurrentDate.setDate(CurrentDate.getDate() + 1);
			$(Next).find('[id^=dtStart]').val(rm.date.getQDateStringFromDate(CurrentDate));
		}
		else {
			$(Next).find('[id^=dtStart]').val(rm.date.getQDateStringFromDate(NextDate));
		}
	},
	SetNextMilestoneValues: function (Next, MilestoneEndId, NextDate) {
		var CurrentDate = rm.date.getDateFromQDateString(NextDate);
		if (NextDate != "") {
			var Nextdate = CurrentDate.setDate(CurrentDate.getDate() + 1);
			$(Next).find('[id^=dtStart]').val(rm.date.getQDateStringFromDate(CurrentDate));
		}
		else {
			$(Next).find('[id^=dtStart]').val(rm.date.getQDateStringFromDate(NextDate));
		}

		$(Next).find('[id^=milestone_start]').val(MilestoneEndId);
		$.each(LocalData, function (index, ele) {
			if (ele.Id == MilestoneEndId) {
				$(Next).find('[id^=hdnFromMilestoneTimestamp]').val(ele.MilestoneLastModifiedOn);
				$(Next).find('[id^=hdnFromMilestoneId]').val(ele.ProjectMilestoneId);
				$(Next).find('[id^=hdnFromMilestoneType]').val(ele.MilestoneType);

				if (ele.MilestoneType == "P" || ele.MilestoneType == "S" || ele.MilestoneType == "O") {
					$(Next).find('[id^=Image_start]').attr('src', '/_layouts/SPUI/images/ppmUnLinkIcon.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
				}
				else if (ele.MilestoneType == "C") {
					$(Next).find('[id^=Image_start]').attr('src', '/_layouts/SPUI/images/cmReconnect.png').attr("connectStatus", 0).attr("connectStatusChanged", 1);
				}
				else {
					$(Next).find('[id^=Image_start]').hide();
				}
				return false;
			}
		});
	},
	CalculateWeeklyHoursOrFteOnRibbonClick: function () {
		if (!genericCalculator.multiEditMode) {
			var weeklyHours = $(".clsGenericWeeklyhours");
			$.each(weeklyHours, function (index, ele) {
				$.GenericFTECalculator.WeeklyHourChangeHandler(ele);
			});

			var adhocWeeklyHours = $(".clsGenericWeeklyhoursAdHoc");
			$.each(adhocWeeklyHours, function (index, ele) {
				$.GenericFTECalculator.AdhocWeeklyHourChangeHandler(ele);
			});

			var fte = $(".clsGenericFTE");
			$.each(fte, function (index, ele) {
				$.GenericFTECalculator.FteChangeHandler(ele);
			});

			var adhocFte = $(".clsGenericFTEAdHoc");
			$.each(adhocFte, function (index, ele) {
				$.GenericFTECalculator.AdhocFteChangeHandler(ele);
			});
		}
	},

	WeeklyHourChangeHandler: function (element) {
		$.q.formatText(element);

		if ($.GenericFTECalculator._fireChangeEvent) {
			if (eval($(element).attr('isChanged')) && !$(element).hasClass("q_validation_error")) {
				$.GenericFTECalculator.CalculateWeeklyHourFTE(element, "WH", true);
			}
		}

		$.GenericFTECalculator._fireChangeEvent = true;
	},

	AdhocWeeklyHourChangeHandler: function (element) {
		$.q.formatText(element);

		if ($.GenericFTECalculator._fireChangeEvent) {
			if (eval($(element).attr('isChanged')) && !$(element).hasClass("q_validation_error")) {
				$.GenericFTECalculator.CalculateWeeklyHourFTE(element, "WH", false);
			}
		}

		$.GenericFTECalculator._fireChangeEvent = true;
	},

	FteChangeHandler: function (element) {
		$.q.formatText(element);

		if ($.GenericFTECalculator._fireChangeEvent) {
			if (eval($(element).attr('isChanged')) && !$(element).hasClass("q_validation_error")) {
				$.GenericFTECalculator.CalculateWeeklyHourFTE(element, "FTE", true);
			}
		}

		$.GenericFTECalculator._fireChangeEvent = true;
	},

	AdhocFteChangeHandler: function (element) {
		$.q.formatText(element);

		if ($.GenericFTECalculator._fireChangeEvent) {
			if (eval($(element).attr('isChanged')) && !$(element).hasClass("q_validation_error")) {
				$.GenericFTECalculator.CalculateWeeklyHourFTE(element, "FTE", false);
			}
		}

		$.GenericFTECalculator._fireChangeEvent = true;
	},

	CalculateWeeklyHourFTE: function (modifiedWeeklyHoursFTE, type, evaluateConnectStatus) {
		if ($.GenericFTECalculator._countryId == -1) {
			return false;
		}
		if (genericCalculator.multiEditMode) {
			return false;
		}

		if ($(modifiedWeeklyHoursFTE).val() != "") {
			$.ajax({
				url: rm.ajax.requestSvcUrl + "CalculateWeeklyHourFTE?countryId=" + genericCalculator.getCountryIdForFteCalculation() + "&resourceId=" + $.GenericFTECalculator._resourceId + "&modifiedWeeklyHoursFTE=" + $(modifiedWeeklyHoursFTE).val() + "&type=" + type + "&jobRoleId=" + genericCalculator.getJobRoleIdForFteCalculation(),
				cache: false,
				async: false,
				success: function (data) {
					$.GenericFTECalculator._fireChangeEvent = false;
					$(modifiedWeeklyHoursFTE).parent().parent().find("input").attr('isChanged', 'false');

					if (type == "WH") {
						var element = $(modifiedWeeklyHoursFTE).parent().next().find("input");
						element.val(data).removeClass("q_validation_error").attr("title", "");
						$.q.rangeValidate(element[0]);
						if (element.hasClass("q_validation_error")) {
							element.attr("title", "The value entered is not within expected range for FTE.  Correct range is:" + element.attr("from") + "-" + element.attr("to"));
						}
					}
					else {
						var element = $(modifiedWeeklyHoursFTE).parent().prev().find("input");
						element.val(data).removeClass("q_validation_error").attr("title", "");
						$.q.rangeValidate(element[0]);
						if (element.hasClass("q_validation_error")) {
							element.attr("title", "The value entered is not within expected range for weekly Hours. Correct range is:" + element.attr("from") + "-" + element.attr("to"));
						}
					}
				},
				error: function (errmsg) {
					rm.ui.messages.addError(Resources.FailedToCalculateWeeklyHourFTE);
				}
			});
		}
	},

	isvalidDate: function (date1, date2) {
		var isValid = true;

		if (!rm.date.isValidDate(date1, false)) {
			isValid = false;
		}

		if (!rm.date.isValidDate(date2, false)) {
			isValid = false;
		}

		if (rm.date.getDateFromQDateString($(":input[id$=d_startDate]").val()) > rm.date.getDateFromQDateString($(":input[id$=d_endDate]").val())) {
			rm.validation.addError("#d_startDate", Resources.StartDateGreaterThanStopDate);
			rm.validation.addError("#d_endDate", Resources.StopDateLessThanStartDate);
			isValid = false;
		}

		return isValid;
	},

	validatecomments: function (comments) {
		if ($.trim(comments).length === 0) {
			rm.validation.addError("#c_comments", "The Explanation is required.");
			return false;
		}
		else {
			return true;
		}
	},

	enableDisableAddButton: function () {
		if ($.GenericFTECalculator.AllowEditing) {
			$("#btnGenericAdd").removeAttr("disabled");
		}
		else {
			$("#btnGenericAdd").attr("disabled", "disabled");
		}
	},

	SetCalculatorValues: function (FTE, totalHours) {
		$("#generic_small_Calc_TxtFTE").val(FTE);
		$("#generic_small_Calc_SpanTotalHours").html(totalHours);
	},

	GetValues: function () {
		return (
			{
				FTE: $.trim($("#generic_small_Calc_TxtFTE").val()) != "" ? $("#generic_small_Calc_TxtFTE").val() : "0",
				TotalHours: $("#generic_small_Calc_SpanTotalHours").html() != "" ? $("#generic_small_Calc_SpanTotalHours").html() : "0"
			});
	},

	disconnectDatesOnCountryChangeAndRepopulateMilestoneDropdownLists: function () {
		$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {

			//Find out start milestone currently selected in UI 
			var startMilestoneOld = $.grep(oldLocalData, function (el) {
				return el.Id == $(ele).find('[id^=milestone_start]').val();
			});

			//Find out stop milestone currently selected in UI 
			var stopMilestoneOld = $.grep(oldLocalData, function (el) {
				return el.Id == $(ele).find('[id^=milestone_end]').val();
			});

			// Fill FromMilestone picklist
			if (startMilestoneOld.length > 0) {
				// Select new milestone id from new localdata
				var startMilestoneNew = $.grep(LocalData, function (el) {
					return el.ProjectMilestoneId == startMilestoneOld[0].ProjectMilestoneId && el.MilestoneType == startMilestoneOld[0].MilestoneType;
				});

				if (startMilestoneNew.length > 0) {
					// Old milestone reset
					$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, startMilestoneNew[0].ProjectMilestoneId, startMilestoneNew[0].MilestoneType);
					$.GenericFTECalculator.CheckImageForCountryMilestone($(ele).find('[id^=dtStart_]').val(), startMilestoneNew, $(ele).find('[id^=Image_start_]').attr('id'), true);
				}
				else {
					// Manual milestone set
					$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, 0, "M");
					$('#' + $(ele).find('[id^=Image_start_]').attr('id')).hide();
				}
			}
			else {
				if ($(ele).find('[id^=milestone_start]').val() != -1)//Sham:QRPM-4736 FIX check for dropdown value if it is not selected skip this part
				{
					$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, 0, "M");
					$('#' + $(ele).find('[id^=Image_start_]').attr('id')).hide();
				}
			}

			// Fill ToMilestone picklist
			if (stopMilestoneOld.length > 0) {
				// Select new milestone id from new localdata
				var stopMilestoneNew = $.grep(LocalData, function (el) {
					return el.ProjectMilestoneId == stopMilestoneOld[0].ProjectMilestoneId && el.MilestoneType == stopMilestoneOld[0].MilestoneType;
				});

				if (stopMilestoneNew.length > 0) {
					// Old milestone reset
					$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, stopMilestoneNew[0].ProjectMilestoneId, stopMilestoneNew[0].MilestoneType);

					$.GenericFTECalculator.CheckImageForCountryMilestone($(ele).find('[id^=dtEnd_]').val(), stopMilestoneNew, $(ele).find('[id^=Image_end_]').attr('id'), false);
				}
				else {
					// Manual milestone set
					$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, 0, "M");
					$('#' + $(ele).find('[id^=Image_end_]').attr('id')).hide();

				}
			}
			else {
				if ($(ele).find('[id^=milestone_end]').val() != -1)//Sham:QRPM-4736 FIX check for dropdown value if it is not selected skip this part
				{
					$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, 0, "M");
					$('#' + $(ele).find('[id^=Image_end_]').attr('id')).hide();
				}
			}
		});
	}
}

$(document).delegate(".GenericStartDatePicker", 'change', function () {
	var Counter = this.getAttribute("data-value");
	var MilestoneStartId = $("#milestone_start_" + Counter).val();
	$.GenericFTECalculator.CheckImages(MilestoneStartId, "#dtStart_", "#Image_start_", Counter);
	$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(true);
	rm.ui.ribbon.delayedRefresh();
});

$(document).delegate(".GenericEndDatePicker", 'change', function () {
	var Counter = this.getAttribute("data-value");
	var MilestoneEndId = $("#milestone_end_" + Counter).val();
	var row = $(this).closest('tr');
	var next = row.next();

	$.GenericFTECalculator.CheckImages(MilestoneEndId, "#dtEnd_", "#Image_end_", Counter);
	var Nextdate = $("#dtEnd_" + Counter).val();
	$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(false);
	if (next.length > 0) {
		$.GenericFTECalculator.SetNextMilestoneValues(next, MilestoneEndId, Nextdate);
	}
	rm.ui.ribbon.delayedRefresh();
});


$(document).delegate(".fromMilestoneStartDate", 'change', function () {
	var Counter = this.getAttribute("data-value");
	var MilestoneStartId = $("#milestone_start_" + Counter).val();
	var selector = $("#milestone_start_" + Counter);

	$.GenericFTECalculator.Checkdates(MilestoneStartId, "#dtStart_", "#Image_start_", Counter);
	$.GenericFTECalculator.MilestoneChangeImages(MilestoneStartId, true, Counter);
	$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(true);
	rm.ui.ribbon.delayedRefresh();
});

$(document).delegate(".toMilestoneEndDate", 'change', function () {
	var Counter = this.getAttribute("data-value");
	var MilestoneEndId = $("#milestone_end_" + Counter).val();

	var row = $(this).closest('tr');
	var next = row.next();
	$.GenericFTECalculator.Checkdates(MilestoneEndId, "#dtEnd_", "#Image_end_", Counter);

	$.GenericFTECalculator.MilestoneChangeImages(MilestoneEndId, false, Counter);
	$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(false);

	if (next.length > 0) {
		var Nextdate = $("#dtEnd_" + Counter).val();
		$.GenericFTECalculator.SetNextMilestoneValues(next, MilestoneEndId, Nextdate);
	}
	rm.ui.ribbon.delayedRefresh();
});

$(document).delegate(".clsGenericWeeklyhours,.clsGenericFTE,.clsGenericWeeklyhoursAdHoc,.clsGenericFTEAdHoc", 'keydown paste cut', function (e) {
	//Allow ajax call on keys 0 to 9, ., backspace and delete
	if ((e.type == "keydown" && ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode == 190 || e.keyCode == 8 || e.keyCode == 46)) ||
		e.type != "keydown") {
		$("#isGenericDirtyCalculator").val('True');
		$(this).attr('isChanged', 'true');
		$(this).parent().parent().find('[id^=txtFTE]').attr('iconClicked', "false");
		setTimeout(function () { $.GenericFTECalculator.OnCalculatorEdit(); }, 10);
	}

	if (genericCalculator.multiEditMode) {
		if ($(this).hasClass("clsGenericWeeklyhours")) {
			//manual change detected on keys 0 to 9 period, backspace and delete
			if (!$.q.isNonPrintableKey(e.keyCode)) {
				var element = $(e.currentTarget).closest("tr").find(".clsGenericFTE").val("");
				rm.validation.clearError(element);
			}
		}

		if ($(this).hasClass("clsGenericFTE")) {
			if (!$.q.isNonPrintableKey(e.keyCode)) {
				var element = $(e.currentTarget).closest("tr").find(".clsGenericWeeklyhours").val("");
				rm.validation.clearError(element);
			}
		}
	}
});

if (!genericCalculator.multiEditMode) {
	$(document).delegate(".clsGenericWeeklyhours", 'change', function () {
		var element = this;
		//Wait for updated value of isChanged attribute to be available in the dom
		setTimeout(function () {
			$.GenericFTECalculator.WeeklyHourChangeHandler(element);
		}, 10);
	});

	$(document).delegate(".clsGenericFTE", 'change', function () {
		var element = this;
		//Wait for updated value of isChanged attribute to be available in the dom
		setTimeout(function () {
			$.GenericFTECalculator.FteChangeHandler(element);
		}, 10);
	});

	$(document).delegate(".clsGenericFTEAdHoc", 'change', function () {
		var element = this;
		//Wait for updated value of isChanged attribute to be available in the dom
		setTimeout(function () {
			$.GenericFTECalculator.AdhocFteChangeHandler(element);
		}, 10);
	});

	$(document).delegate(".clsGenericWeeklyhoursAdHoc", 'change', function () {
		var element = this;
		//Wait for updated value of isChanged attribute to be available in the dom
		setTimeout(function () {
			$.GenericFTECalculator.AdhocWeeklyHourChangeHandler(element);
		}, 10);
	});
}
$(document).delegate(".imgDeleteGenereicAdhoc", 'click', function () {
	if (confirm('Are you sure you want to delete this frequency?')) {
		$.GenericFTECalculator.DeleteAdHocRow(this);
		$.GenericFTECalculator._enableSaveButton = true;
		$("#isGenericDirtyCalculator").val('True');
		setTimeout(function () { $.GenericFTECalculator.OnDeleteAdhocClick(); }, 10);
	}
	else {
		$.GenericFTECalculator._enableSaveButton = false;
	}
});

$(document).delegate(".imgDeleteGenericRow", 'click', function () {
	$.GenericFTECalculator._enableSaveButton = false;
	if ($('#GenericFTETable tbody tr').length > 1) {
		if (confirm('Are you sure you want to delete this frequency?')) {
			var row = $(this).closest('tr');
			var prev = row.prev();
			var next = row.next();
			$.GenericFTECalculator.DeleteGenericRow(this);

			$("#isGenericDirtyCalculator").val('True');
			setTimeout(function () { $.GenericFTECalculator.OnDeleteAdhocClick(); $.GenericFTECalculator.rebindStage(); }, 10);
			//RMK Added
			//Start:Reload the start milestone once the user delete any milestone stage
			$("#GenericFTETable  tbody tr").each(function (index, element) {
				var selectedValue = $("#" + $(this).find(".fromMilestoneStartDate").attr('id')).val();
				$.GenericFTECalculator.ReloadTheMilestone($(this).find(".fromMilestoneStartDate"), LocalData, selectedValue);
			});
			//  $.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones();
			$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones();

			//AB enable all the controls if this is first Row
			$("#GenericFTECalculator tr:first").find('[id^=dtStart]').attr("readonly", false).qDatepicker().removeClass('MilestonefieldsetLabelWIdth disabledinput');
			$("#GenericFTECalculator tr:first").find('[id^=milestone_start]').attr("disabled", false);
			var milestoneType = $("#GenericFTECalculator tr:first").find('[id^=hdnFromMilestoneType]').val();
			if (milestoneType != "M") {
				$("#GenericFTECalculator tr:first").find('[id^=Image_start]').show();
			}

			//Update next Stage
			if (prev.length > 0) {
				$.GenericFTECalculator.UpdateNextSatge(prev, next);
			}
			$.GenericFTECalculator._enableSaveButton = true;
		}
	}
	else {
		$.GenericFTECalculator._enableSaveButton = false;
		alert("Stage cannot be deleted.");
	}
});

$(document).delegate(".imgEndMilestone", 'click', function () {
	var Counter = this.getAttribute("data-value");
	var MilestoneEndId = $("#milestone_end_" + Counter).val();
	var MilestoneEndImg = $("#Image_end_" + Counter).attr('src');

	if (MilestoneEndImg == "/_layouts/SPUI/images/ppmUnLinkIcon.png" || MilestoneEndImg == "/_layouts/SPUI/images/cmReconnect.png") {
		$.each(LocalData, function (inex, ele) {
			if (MilestoneEndId == ele.Id) {
				$("#dtEnd_" + Counter).val(ele.ConnectedDate);
				if (ele.MilestoneType == "P" || ele.MilestoneType == "S" || ele.MilestoneType == "O") {

					$("#Image_end_" + Counter).attr('src', '/_layouts/SPUI/images/ppmLinkIcon.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
				}
				else {
					$("#Image_end_" + Counter).attr('src', '/_layouts/SPUI/images/cmConnected.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
				}
				return false;
			}
		});

		var row = $(this).closest('tr');
		var next = row.next();
		var Nextdate = $("#dtEnd_" + Counter).val();
		if (next.length > 0) {
			$.GenericFTECalculator.ChangeNextMilestoneDateOnImageClick(next, Nextdate);
		}
		$.GenericFTECalculator.HandleSaveButton();
	}

	var row = $(this).closest('tr');
	var next = row.next();
	if (next.length <= 0) {
		// TL: Fix for QRPM-4507
		$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(false);
	}
});

$(document).delegate(".imgStartMilestone", 'click', function () {
	var Counter = this.getAttribute("data-value");
	var MilestoneStartId = $("#milestone_start_" + Counter).val();
	var MilestoneStartImg = $("#Image_start_" + Counter).attr('src');

	if (MilestoneStartImg == "/_layouts/SPUI/images/ppmUnLinkIcon.png" || MilestoneStartImg == "/_layouts/SPUI/images/cmReconnect.png") {
		$.each(LocalData, function (inex, ele) {
			if (MilestoneStartId == ele.Id) {
				$("#dtStart_" + Counter).val(ele.ConnectedDate);
				if (ele.MilestoneType == "P" || ele.MilestoneType == "S" || ele.MilestoneType == "O") {
					$("#Image_start_" + Counter).attr('src', '/_layouts/SPUI/images/ppmLinkIcon.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
				}
				else {
					$("#Image_start_" + Counter).attr('src', '/_layouts/SPUI/images/cmConnected.png').attr("connectStatus", 1).attr("connectStatusChanged", 1);
				}
				return false;
			}
		});
	}

	var row = $(this).closest('tr');
	var prev = row.prev();
	if (prev.length <= 0) {
		// TL: Fix for QRPM-4507
		$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(true);
	}
	$.GenericFTECalculator.HandleSaveButton();
});


$(document).ready(function () {
	var styleConfig = { width: '250px' };
	var stylePosition = { my: 'bottom center', at: 'top center' };
	var LocalData;
	var oldLocalData;
	var OriginalStartDate;
	rm.qtip.showInfo(".fteAdHocHover", "Creating an Ad-hoc Interim frequency <b><u>replaces</u></b> the FTE allocation during the date range for Ad-hoc.", {}, {}, stylePosition, styleConfig, {});
});

$(document).on("change", ".fromMilestoneStartDate", function (event) {
	var selectedId = $(this).attr('id');
	if ($("#" + selectedId).val() != "-1") {
		rm.validation.clearError($(this));
	}
	//var selectedValue = $("#" + selectedId).val();
	$("#GenericFTETable tbody tr").each(function (index, element) {
		if ($(this).find(".fromMilestoneStartDate").attr('id') != selectedId) {
			var selectedValue = $("#" + $(this).find(".fromMilestoneStartDate").attr('id')).val();
			$.GenericFTECalculator.ReloadTheMilestone($(this).find(".fromMilestoneStartDate"), LocalData, selectedValue);
		}
		else {
			var milestoneStartDate = $(this).find(".class_milestoneStart input[type=text]");
			rm.validation.clearError($(milestoneStartDate));
		}
	});
});

$(document).on("change", ".toMilestoneEndDate", function (event) {
	var selectedId = $(this).attr('id');
	if ($("#" + selectedId).val() != "-1") {
		rm.validation.clearError($(this));
	}
	var milestoneEndDate = $(this).parent('td').parent('tr').find(".class_milestoneEnd input[type=text]");
	rm.validation.clearError($(milestoneEndDate));
});
