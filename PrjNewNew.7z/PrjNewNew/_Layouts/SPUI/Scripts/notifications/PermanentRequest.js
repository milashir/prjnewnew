﻿/// <reference path="../common/rmhelper.js" />
$(document).ready(function () {
	$(monrNs.EditMultipleRequests.ModifyRequestsRibbonControlId).hide();
	monrNs.buildGrid(GetRmPageLinkId());
	window.onbeforeunload = function () {
		if (rm.grid.hasRowsInEditMode(monrNs.gridSelector)) {
			return "Are you sure you want to leave without saving your changes?";
		}
	};
	rm.grid.bindEventsToResizeGrid(monrNs.gridSelector);
	$("#MonitoringRequest").addClass("left-static-selected-menu");

});

var monrNs = {
	gridSelector: "#list",
	frozenColumnAlreadyBound: false,
	isCancelEnabled: function () { return rm.grid.hasRowsInEditMode(monrNs.gridSelector); },
	isSaveEnabled: function () { return rm.grid.hasRowsInEditMode(monrNs.gridSelector); },
	isSubmitEnabled: function () { return rm.grid.hasRowsSelected(monrNs.gridSelector); },
	EditSelectedRow: function (rmPageLinkId) {
		var selectedrows = rm.grid.getSelectedIdArray(monrNs.gridSelector);
		if (selectedrows.length > 1) {
			alert("Can only edit one request at a time.");
			return false;
		}

		if (selectedrows.length == 0) {
			alert("No request selected.");
			return false;
		}

		var gridState = { searchCriteria: $(monrNs.gridSelector).getGridParam("postData") };
		gridState.requestId = selectedrows[0];
		gridState.requestGroup = RequestGroup_E.NewMonitoring;

		if (rm.serviceCalls.isRequestValid(selectedrows[0], true, RmPageLink_E.MonitoringRequests)) {
			$.cookie("permanentSearchCriteria", JSON.stringify(gridState), { path: "/" });
			try {
				document.location.href = "/_layouts/SPUI/Requests/EditRequestNew.aspx?source=submitted&requestId=" + selectedrows[0] + "&rmPageLink=" + rmPageLinkId;
			}
			catch (ex) { /*ignore*/ }
		}
	},

	SubmitGrid: function () {
		var selectedrows = rm.grid.getSelectedIdArray(monrNs.gridSelector);
		if (selectedrows.length == 0) {
			rm.ui.messages.addError(Resources.SelectRowToSubmit);
			return false;
		}

		var postData = { requestIds: selectedrows };

		//rm.grid.hideMessageColumn(monrNs.gridSelector, "Message");
		$.rm.Ajax_Request("SubmitRequests", postData, function (data) {
			var isSuccess = true;
			$.each(data, function (index, request) {
				if (request.IsSuccessful) {
					rm.grid.removeRow(monrNs.gridSelector, request.EntityId);
				}
				else {
					isSuccess = false;
					rm.grid.showErrorIconInMessageColumn(monrNs.gridSelector, request.EntityId, "Message", request.Message);
				}
			});

			rm.serviceCalls.getRequestCounts();
			if (isSuccess) {
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showSuccess(Resources.RequestSubmittedSuccessfully);
			}
			else {
				rm.ui.messages.addError(Resources.FailedToSubmitRequest);
			}
			rm.ui.ribbon.delayedRefresh();
		});
	},

	SaveGrid: function () {
		rm.ui.messages.clearAllMessages();

		var rowsToSave = [];
		var rowsInEditMode = rm.grid.getRowsInEditMode(monrNs.gridSelector);

		$.each(rowsInEditMode, function (index, editedRow) {
			var startDate = $(rm.grid.getControlFromEditRow(monrNs.gridSelector, editedRow.id, "StartDate"));
			var stopDate = $(rm.grid.getControlFromEditRow(monrNs.gridSelector, editedRow.id, "StopDate"));
			var imDate = $(rm.grid.getControlFromEditRow(monrNs.gridSelector, editedRow.id, "IMDate"));
			var craDate = $(rm.grid.getControlFromEditRow(monrNs.gridSelector, editedRow.id, "CRADate"));

			if (rm.date.isValidDate(startDate.val(), true) &&
					rm.date.isValidDate(stopDate.val(), true) &&
					rm.date.isValidDate(imDate.val(), true) &&
					rm.date.isValidDate(craDate.val(), true)) {
				rowsToSave.push(rm.grid.getUpdatedRowDataById(monrNs.gridSelector, editedRow.id));
			}
			else {
				rm.ui.messages.addError("Please fix the errors and click Save again. Page will attempt to save the records with valid data.");
			}
		});

		if (rowsToSave.length > 0) {
			monrNs.saveRequests(rowsToSave, rowsInEditMode.length);
		}
	},
	saveSingleRequest: function (gridSelector, rowId) {
		rm.ui.messages.clearAllMessages();
		var startDate = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "StartDate"));
		var stopDate = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "StopDate"));
		var imDate = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "IMDate"));
		var craDate = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "CRADate"));

		if (rm.date.isValidDate(startDate.val(), true) &&
				rm.date.isValidDate(stopDate.val(), true) &&
				rm.date.isValidDate(imDate.val(), true) &&
				rm.date.isValidDate(craDate.val(), true)) {
			var rowToSave = rm.grid.getUpdatedRowDataById(gridSelector, rowId);
			monrNs.saveRequests([rowToSave], 1);
		}
		else {
			rm.ui.messages.addError("Please fix the errors and click Save again.");
		}
	},
	saveRequests: function (rowsToSave, totalRowsInEditMode) {
		if (rowsToSave.length > 0) {
			rm.ajax.requestSvcAsyncPost("UpdateMonitoringRequestStartStopDates", { requestDataList: rowsToSave }, function (serviceResponse) {
				var successCount = 0;
				$.each(serviceResponse.EntityStatus, function (index, response) {
					if (response.IsSuccessful) {
						successCount++;
						rm.grid.cancelRowEditMode(monrNs.gridSelector, response.EntityId);
						//Give it a split second so the row can go back to read-only mode
						setTimeout(function () {
							var rowData = rm.grid.rowData.getById(monrNs.gridSelector, response.EntityId);

							rowData.StartDate = response.Output.StartDate;
							rowData.StopDate = response.Output.StopDate;
							rowData.CRADate = response.Output.CRADate;
							rowData.IMDate = response.Output.IMDate;
							rowData.NeedByDate = response.Output.NeedByDate;

							rowData.StartDateStatus.connected = response.Output.StartDateStatus;
							rowData.StopDateStatus.connected = response.Output.StopDateStatus;
							rowData.CRADateStatus.connected = response.Output.CRADateStatus;
							rowData.IMDateStatus.connected = response.Output.IMDateStatus;

							$(monrNs.gridSelector).setCell(response.EntityId, "StartDate", response.Output.StartDate, "", "", true);
							$(monrNs.gridSelector).setCell(response.EntityId, "StopDate", response.Output.StopDate, "", "", true);
							$(monrNs.gridSelector).setCell(response.EntityId, "CRADate", response.Output.StopDate, "", "", true);
							$(monrNs.gridSelector).setCell(response.EntityId, "IMDate", response.Output.StopDate, "", "", true);
							$(monrNs.gridSelector).setCell(response.EntityId, "NeedByDate", response.Output.StopDate, "", "", true);

							rm.grid.cancelRowEditMode(monrNs.gridSelector, response.EntityId);
							rm.grid.clearSingleGridRowError(monrNs.gridSelector, "Message", response.EntityId)

							rm.ui.ribbon.refresh();
						}, 50);
					} else {
						rm.validation.processErrorMessages(response.Errors, monrNs.gridSelector, "IconColumn");
					}
				});

				if (successCount === 0) {
					rm.ui.messages.addError("Errors found.  Nothing saved.");
				}
				else if (rowsToSave.length === successCount) {
					if (rowsToSave.length !== totalRowsInEditMode) {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showWarningWithCloseButton("Data saved with some errors found.");
					}
					else {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showSuccess(Resources.AllDataSavedSuccessfully);
					}
				}
				else {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showWarningWithCloseButton("Data saved with some errors found.");
				}
			});
		}
	},
	//Cancel editing for the entire grid.  Restores last saved values.
	CancelGrid: function () {
		rm.grid.cancelGridEditMode(monrNs.gridSelector);
		rm.ui.ribbon.delayedRefresh();
	},

	DeleteSelectedRowEnabled: function () {
		return rm.grid.hasRowsSelected(monrNs.gridSelector);
	},

	DeleteSubmittedRequests: function () {
		var selectedrows = rm.grid.getSelectedIdArray(monrNs.gridSelector);
		if (selectedrows.length == 0) {
			alert("No request selected.");
			return false;
		}
		else {
			if (confirm(Resources.DeleteRequestConfirm)) {
				rm.grid.hideMessageColumn(monrNs.gridSelector, "Message");
				var postData = { requestIds: selectedrows };

				$.rm.Ajax_Request("DeleteSubmittedRequests", postData, function (data) {
					var isSuccess = true;
					$.each(data, function (index, request) {
						if (request.IsSuccessful) {
							rm.grid.removeRow(monrNs.gridSelector, request.EntityId);
						}
						else {
							isSuccess = false;
							rm.grid.showErrorIconInMessageColumn('#list', request.EntityId, 'Message', request.Message);
						}
					});

					rm.ui.ribbon.refresh();
					$.q.RebindQtip(monrNs.gridSelector);
					rm.serviceCalls.getRequestCounts();

					if (isSuccess) {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showSuccess('Request(s) removed successfully.');
					}
					else {
						rm.ui.messages.addError('Failed to remove one or more requests. Hover over error indicator for more details.');
					}
				});
			}
		}
	},

	bindLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn("#list_IconColumn", "Request Status Indicator.");
		rm.qtip.showInfoOnGridColumn("#list_Notes", "Use to add or view comments about the project and/or request.");
		rm.qtip.showInfoOnGridColumn("#list_FTE", "Provides the details of the hours allocated for a request, taking into account the frequency of the visit, prep time, etc.");
		rm.qtip.showInfoOnGridColumn("#list_NeedByDate", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn("#list_IMDate", "Investigator Meeting Date.");
		rm.qtip.showInfoOnGridColumn("#list_CRADate", "CRA Training Date.");
		rm.qtip.showInfoOnGridColumn("#list_StartDate", "The date when the work begins for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#list_StopDate", "The date when the work ends for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#list_Country", "May be the preferred resource location or the country where the study is taking place.");
		rm.qtip.showInfoOnGridColumn("#list_Program", "Program.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectCode", "Project Code.");
		rm.qtip.showInfoOnGridColumn("#list_Protocol", "Protocol.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectDteType", "RBM Project");
		rm.qtip.showInfoOnGridColumn("#list_SiteStatus", "The site status from CTMS/InnTrax.");
		rm.qtip.showInfoOnGridColumn("#list_SponsorSiteName", "Sponsor Site ID.");
		rm.qtip.showInfoOnGridColumn("#list_PrincipalInvestigator", "Pincipal Investigator.");
		rm.qtip.showInfoOnGridColumn("#list_Location", "Location of the site.");
		rm.qtip.showInfoOnGridColumn("#list_ResourceType", "Resource Request Type.");
	},

	EditMultipleRequests: {
		ModifyRequestRibbonControlId: '#Ribbon_MonitoringRequestRibbon_GridActions_EditSingleRow',
		ModifyRequestsRibbonControlId: '#Ribbon_MonitoringRequestRibbon_GridActions_EditMultipleRow'
	},

	ModifySingleRowEnabled: function () {
		$(monrNs.EditMultipleRequests.ModifyRequestRibbonControlId).hide();
		return rm.grid.hasSingleRowSelected(monrNs.gridSelector);
	},

	ModifyMultipleRowsEnabled: function () {
		return $.rm.requestCommon.ModifyMultipleRowsEnabled(monrNs.gridSelector, monrNs.EditMultipleRequests.ModifyRequestRibbonControlId, monrNs.EditMultipleRequests.ModifyRequestsRibbonControlId);
	},

	ModifySingleRequest: function () {
		var selectedrows = rm.grid.getSelectedIdArray(monrNs.gridSelector);
		HandleCalculatorIconClick(selectedrows[0]);
	},

	ModifyMultipleRequests: function () {
		$.rm.requestCommon.ModifyMultipleRequests(GetRmPageLinkId(), monrNs.gridSelector, "permanentSearchCriteria");
	},

	getMandatoryColumns: function () {
		return [
			rm.grid.standardColumns.getMessageColumn(),
			{
				name: '', label: '', index: 'actions',
				formatter: 'actions', editable: false, sortable: false, resizable: false,
				fixed: true, width: 50, search: false, frozen: true,
				formatoptions: {
					keys: true, editbutton: false, delbutton: false,
					afterRestore: function (rowid) {
						rm.ui.ribbon.delayedRefresh();
						rm.grid.scrollTableBodyToFixAlignmentIssue(monrNs.gridSelector);
					}
				}
			}
		];
	},
	getFullColumnModelList: function () {
		return [
					{ name: 'IconColumn', index: 'IconColumn', label: 'Request Status <br />Indicator', width: 130, search: true, sortable: false, hidden: false, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.iconSearch_MonitoringRequests } },
					rm.grid.standardColumns.getNotesColumn(),
					rm.grid.standardColumns.getFteColumn(true),
					{ name: 'NeedByDate', index: 'NeedByDate', label: 'Need By<br/> Date', width: 140, align: 'right', searchoptions: { attr: { maxlength: 11 } } },
					rm.grid.standardColumns.getEditableDateColumn('IMDate', 'IMDate', 'IM Date'),
					rm.grid.standardColumns.getEditableDateColumn('CRADate', 'CRADate', 'CRA Training <br />Date'),
					rm.grid.standardColumns.getEditableDateColumn('StartDate', 'StartDate', 'Start Date'),
					rm.grid.standardColumns.getEditableDateColumn('StopDate', 'StopDate', 'Stop Date'),
					{ name: 'Region', index: 'Region', label: 'Region', width: 150, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 11 } } },
					{ name: 'Country', index: 'Country', label: 'Country', width: 70, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Program', index: 'Program', label: 'Program', width: 90, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Customer', index: 'Customer', label: 'Customer', width: 70, search: true, sortable: false, searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project<br/>Code', width: 70, searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'ProjectDteType', index: 'ProjectDteType', label: 'RBM Project', width: 80, classes: 'ui-ellipsis', stype: 'select', searchoptions: { value: rm.grid.filterOptions.dteType } },
					{ name: 'SiteStatus', index: 'SiteStatus', label: 'Site Status', width: 110, searchoptions: { attr: { maxlength: 100 } } },
					{ name: 'SponsorSiteName', index: 'SponsorSiteName', label: 'Sponsor<br/>Site ID', width: 50, searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'PrincipalInvestigator', index: 'PrincipalInvestigator', label: 'PI', width: 75, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'Location', index: 'Location', label: 'Location', width: 90, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'ResourceType', index: 'ResourceType', label: 'Resource<br />Request Type', width: 165, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
					{ name: 'CreatedOn', index: 'CreatedOn', label: 'Created On', classes: 'ui-ellipsis', width: 90 },
					{ name: 'PrimaryCpm', index: 'PrimaryCpm', label: 'CPM/Project Lead', classes: 'ui-ellipsis', width: 180 },
					{ name: 'PrimaryCl', index: 'PrimaryCl', label: 'Primary Clinical Lead', classes: 'ui-ellipsis', width: 180 },
					{ name: 'RequestIdForFilter', index: 'RequestIdForFilter', label: 'RequestId', width: 70 }
		];
	},
	freezeColumnsAndBindInfo: function () {
		if (!monrNs.frozenColumnAlreadyBound) {
			monrNs.frozenColumnAlreadyBound = true;
			//freezing columns involve rebuilding the grid. Once grid is rebuilt, we need to rebing the information qtip.
			rm.grid.delayedRebindFrozenColumns(monrNs.gridSelector);
			setTimeout(monrNs.bindLabelQtip, 100);
		}
		rm.grid.scrollTableBodyToFixAlignmentIssue(monrNs.gridSelector);
	},
	buildGrid: function (rmPageLinkId) {
		var handleUserPreferencesResponse = function (userColumnPreferences) {
			userColumnPreferences.UiColumnConfiguration = monrNs.getFullColumnModelList();
			var columnModel = rm.grid.getFinalColumnModelFromFullColumnListAndUserColumnPreferences(monrNs.getFullColumnModelList(), userColumnPreferences, monrNs.getMandatoryColumns());
			monrNs.buildDynamicGrid(rmPageLinkId, columnModel, userColumnPreferences);
		};
		rm.serviceCalls.getRmUserDataGridColumnPreferences(DataGrid.UnsubmittedMonitoringRequests, handleUserPreferencesResponse)
	},
	buildDynamicGrid: function (rmPageLinkId, columnModel, userColumnPreferences) {
		var cookieData;
		var gridPost;
		var requestId;
		var cookievalue = $.cookie("permanentSearchCriteria");

		if (cookievalue != null) {
			cookieData = $.parseJSON(cookievalue);
			gridPost = cookieData.searchCriteria;
			gridPost.requestId = cookieData.requestId;
			$.cookie("permanentSearchCriteria", null, { path: "/" });
			//Set values in filter textboxes
			setTimeout(function () {
				for (property in gridPost) {
					$("#gs_" + property).val(gridPost[property]);
				}
			}, 200);

		}
		else {
			gridPost = {
				sidx: "Region",
				sord: "asc"
			};
		}

		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.exportParameters = { rmPageLink: rmPageLinkId, dataGridId: DataGrid.UnsubmittedMonitoringRequests };
		gridToolsConfig.manageColumnsParameters = userColumnPreferences;
		rm.grid.showGridTools(monrNs.gridSelector, gridToolsConfig);

		$(monrNs.gridSelector).jqGrid({
		    url: rm.ajax.requestSvcUrl + "GetUnsubmittedPermanentRequests",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(true),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },  //MR: for saving a row
			postData: gridPost,  //MR: for loading the grid
			jsonReader: rm.grid.getJqGridJsonReader(),
			loadonce: false,
			multiselect: true,
			autowidth: true,
			shrinkToFit: false,
			height: (window.screen.height - 440),
			forceFit: true,
			pager: '#listPager',
			colModel: columnModel,
			viewrecords: true,
			viewsortcols: [true, 'vertical', true],
			sortname: gridPost.sidx,
			sortorder: gridPost.sord,
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("list"); },
			ondblClickRow: function (id) {
				var areAllEditableColumnsPresent = rm.grid.areAllEditableColumnsPresent(monrNs.getFullColumnModelList(), columnModel, true);

				if (areAllEditableColumnsPresent && rm.serviceCalls.isRequestValid(id, true, RmPageLink_E.MonitoringRequests)) {
					rm.grid.editRow(monrNs.gridSelector, id);
					rm.grid.attachCustomSaveHandler(monrNs.gridSelector, id, monrNs.saveSingleRequest);
					rm.ui.ribbon.delayedRefresh();
				}
			},
			//Prevent grid from selecting a row when clicked on anywhere else in the row other than checkbox
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			onSelectRow: function (id) {
				rm.ui.ribbon.refresh();
			},
			onSelectAll: function (rowIdxArray, status) {
				rm.ui.ribbon.refresh();
			},
			serializeRowData: function (postData) {
				return JSON.stringify({
					id: postData.id,
					IMDate: postData.IMDate,
					CRADate: postData.CRADate,
					StartDate: postData.StartDate,
					StopDate: postData.StopDate
				});

				return JSON.stringify(postData);
			},
			serializeGridData: function (postData) {
				var data = { RmPageLink: rmPageLinkId };

				return rm.grid.serializeGridData(postData, data);
			},
			gridComplete: function () { monrNs.freezeColumnsAndBindInfo(); },
			loadComplete: function (data) {
				rm.grid.addTitlesOnIconColumn();
				var failedRequestIds = $.parseJSON($.cookie("multiEditFailedIds"), { path: "/" });
				if (failedRequestIds && failedRequestIds.length > 0) {
					$.each(failedRequestIds, function (index, id) { jQuery(monrNs.gridSelector).jqGrid('setSelection', id); });
				}
				$.cookie("multiEditFailedIds", null, { path: "/" });

				rm.grid.rowData.attachAllRowsData(monrNs.gridSelector, data);
				rm.ui.notes.bindNotesIconClick();
				if (gridPost && gridPost.requestId) {
					jQuery(monrNs.gridSelector).jqGrid('setSelection', gridPost.requestId);
					delete gridPost.requestId;
					delete $(monrNs.gridSelector).getGridParam("postData").requestId;
					$(monrNs.gridSelector).setGridParam({ postData: gridPost });
				}
				rm.ui.ribbon.refresh();
			},
			resizeStop: function (newWidth, columnIndex) {
				//Becasue grid allows multiselect, it adds a checkbox column as a first column. To find out the column index in the colModel, subtract 1.
				//Not required for grids that don't show checkbox column
				columnIndex -= 1;
				var dataGridColumnId = rm.grid.getDataGridColumnIdFromColIndexColModelAndUserPref(columnIndex, columnModel, userColumnPreferences);
				rm.grid.saveDataGridColumnWidthPreference(newWidth, DataGrid.UnsubmittedMonitoringRequests, dataGridColumnId, monrNs.gridSelector);
			}
		});
		$(monrNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	}
};

HandleCalculatorIconClick = function (requestId) {
	rm.grid.uncheckAllGridRows(monrNs.gridSelector);
	rm.grid.checkRowById(monrNs.gridSelector, requestId);

	setTimeout(function () { monrNs.EditSelectedRow(GetRmPageLinkId()); }, 20);
};

function ConnectMeToCountryOnSuccess(response, rowId, column) {
	var d = $.parseJSON(response);
	if (d.IsSuccessful) {
		var rowJson = rm.grid.rowData.getById(monrNs.gridSelector, rowId);
		rowJson[column + "Status"].connected = GetStatusFromStatusString(d.DateStatus);
		$(monrNs.gridSelector).setCell(rowId, column, d.QDate, "", "", true);
		if (d.NeedByDate != null) {
			$(monrNs.gridSelector).setCell(rowId, "NeedByDate", d.NeedByDate, "", "", true);
		}
	}
	else { alert(d.Message); }
}

function ConnectMeToCountryOnError(errMsg) { alert(errMsg); }