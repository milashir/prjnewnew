﻿/// <reference path="../common/rmHelper.js" />

// initialize application on page load
$.ajaxSetup({
	type: "Post",
	contentType: "application/json; charset=utf-8",
	dataType: "json",
	cache: false,
	error: function (errMsg) { }
});

$(document).ajaxStop(function () { rm.ui.unblock(); });
$(document).ajaxStart(function () { rm.ui.block(); rm.ui.ribbon.refresh(); });


$(function () {
	rm.qtip.showInfo("#infoIconforMultiProjectSelection", "Use Ctrl-V to paste a 'Project Code - Protocol Number' comma-separated list into the field,<br/> and press Enter. Then select the 'Add Project to Preferences' button.");
	rm.qtip.showInfo("[id$=_DashboardCount", "Display all report row counts, where available.");
	$("#Dashboard").addClass("left-static-selected-menu");

	ko.bindingHandlers.datepicker = {
		init: function (element, valueAccessor, allBindingsAccessor) {
			//initialize datepicker with some optional options
			var options = allBindingsAccessor().datepickerOptions || {};
			$(element).qDatepicker(options);
			//handle the field changing
			ko.utils.registerEventHandler(element, "change", function () {
				var observable = valueAccessor();
				observable(rm.date.getQDateStringFromDate($(element).datepicker("getDate")));
			});
			//handle disposal (if KO removes by the template binding)
			ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
				$(element).datepicker("destroy");
			});
		},
		update: function (element, valueAccessor) {
			var value = ko.utils.unwrapObservable(valueAccessor()),
			current = $(element).val();
			if (value != current) {
				$(element).val(value);
			}
		}
	};

	vm.Init();

	ko.applyBindings(vm);
});

//define the viewModel
var ViewModel = function () {
	// Data
	var self = this;

	// Functions to get data from server
	self.Init = function () {
		self.GetRmUserProfile();
		self.GetReportMatrix();
	};

	self.ReadonlyUserPreferences = function () {
		var userPreference = "";
		var userPreferences = "";

		$.each(ko.toJS(self.allRole), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = "<b>Role:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.allResourceOrg), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Project Organizational Units:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.allProfileResourceOrg), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Resource Organizational Units:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.DTEDetails), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Show RBM Projects only</b>" + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.allProject), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Project:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.pRegions), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Region:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.pCountries), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Country:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.pCountryRegions), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Country Region:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.allResourceType), function (index, item) {
			userPreference = userPreference + ", " + item.Name;
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Resource Type:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		$.each(ko.toJS(self.ProfileMetricDurationList), function (index, item) {
			if (item.MetricDurationId != undefined) {
				$.each(ko.toJS(self.allMetricDurations), function (indexDurations, itemDurations) {
					if (item.MetricDurationId == itemDurations.Id) {
						userPreference = userPreference + ", " + item.Name + ":" + itemDurations.Name;
						return;
					}
				});
			}
		});
		if (userPreference != "") {
			userPreferences = userPreferences + "<b>Report Period:</b>" + userPreference.replace(",", "") + "; ";
			userPreference = "";
		}

		var workflowPreferenceCnt = 0;
		var projectPreferenceCnt = 0;
		var managerPreferenceCnt = 0;
		$.each(ko.toJS(self.allDashboardReportShowCount), function (index, item) {
			if (item.DashboardContainerId == 1 && item.ShowCount)
				workflowPreferenceCnt++;

			if (item.DashboardContainerId == 2 && item.ShowCount)
				projectPreferenceCnt++;

			if (item.DashboardContainerId == 3 && item.ShowCount)
				managerPreferenceCnt++;
		});

		if (workflowPreferenceCnt > 0 || projectPreferenceCnt > 0 || managerPreferenceCnt > 0) {
			userPreferences = userPreferences + "<b>Dashboard Report Counts Displayed:</b> Request Workflow=" + workflowPreferenceCnt + "; Project=" + projectPreferenceCnt +
				"; Manager=" + managerPreferenceCnt + ";";
		}

		$("#spanUserPreferences").html(userPreferences);
	};

	self.GetPreferences = function () {
		self.GetMasterValuesForProfile();
	};

	self.allMetricDates = ko.observableArray([]);
	self.allMetricDurations = [];
	self.ProfileMetricDurationList = ko.observableArray([]);
	self.ProfileMetricDurationOriginalList = ko.observableArray([]);
	self.AllowedRegionCountryList = [];
	self.AllowedCountryRegionList = [];
	self.AllowedResopurceOrganizationAndProjectList = [];
	self.allowedResourceOrganizationalUnitsList = ko.observableArray([]);
	self.ProfileResourceOrganizationList = [];
	self.ProfileProjectList = [];
	self.DTEDetails = ko.observableArray([]);
	self.OnlyDTEProjectIds = [];
	self.DashboardMetricWorkflow = ko.observableArray([]);
	self.DashboardMetricProject = ko.observableArray([]);
	self.DashboardMetricLineManager = ko.observableArray([]);
	self.MetricShowCountOrginalList = [];
	self.SelectedMetricWorkflow = ko.observableArray([]);
	self.showCountByUserPreferences = true;

	self.GetMasterValuesForProfile = function () {
		$.ajax({
		    url: rm.ajax.dashboardSvcUrl + "GetMasterValuesForProfile",
			data: {},
			success: function (result) {
				self.roles(result.AllowedRoleList);
				self.resourceOrganizations(result.AllowedResopurceOrganizationAndProjectList);
				self.allowedResourceOrganizationalUnitsList(result.AllowedResourceOrganizationalUnitsList);
				self.resourceTypes(result.AllowedResopurceTypeList);
				self.OnlyDTEProjectIds = result.OnlyDTEProjectIds;
				//Set Location Start
				var arrRegion = [], arrCountry = [], arrCountryRegion = [];
				var arrR = result.AllowedRegionCountryList;
				var len = arrR.length, item = null;
				for (var i = 0; i < len; i++) {
					item = arrR[i];
					arrRegion.push({ Id: item.Id, Name: item.Name });
				}

				//Set Region Dropdownlist
				self.regions(arrRegion);

				//Set Region Section Visibility
				if (arrRegion.length === 0) {
					self.shouldShowRegion(false);
				}
				else {
					self.shouldShowRegion(true);
				}

				//Set Location End

				self.AllowedRegionCountryList = arrR;
				self.AllowedCountryRegionList = result.AllowedCountryRegionList;
				self.AllowedResopurceOrganizationAndProjectList = result.AllowedResopurceOrganizationAndProjectList;

				self.setLocationProfile();
				//set DTE flag
				//self.DTEDetails(result.DTE);

				self.UpdateProjectSmartSearchList(self.ProfileResourceOrganizationList);
			}
		});
	};

	self.setCountryProfileList = function () {
		self.allCountry(self.pCountries);
		self.setCountryRegionProfileList();
	};

	self.setCountryRegionProfileList = function () {
		self.allCountryRegion(self.pCountryRegions);
	};

	self.setLocationProfile = function () {
		self.allRegion(self.pRegions);
		self.resetCountryDropDownList();
		self.resetCountryRegionDropDownList();
		self.setCountryProfileList();
	};

	self.resetRmUserProfile = function () {
		self.selectedRole(null);
		self.selectedResourceOrganization(null);
		self.selectedProject(null);
		self.selectedProfileResourceOrganization(null);
		self.selectedTherapeuticArea(null);
		self.selectedRegion(null);
		self.selectedCountry(null);
		self.selectedCountryRegion(null);
		self.selectedResourceType(null);

		//Clear the ProjectCodes from the List
		//Also reset the variable which stores the not added Project Codes list
		self.clearList();
		dashboardNs.invalidEntry = "";
		$("#inValidProjectCodes").empty();


		//For clearing report period
		self.ProfileMetricDurationList.removeAll();
		self.BuildProfileMetricDurationsArray(self.ProfileMetricDurationOriginalList());

		//For clearing report counts
		self.DashboardMetricWorkflow.removeAll();
		self.DashboardMetricProject.removeAll();
		self.DashboardMetricLineManager.removeAll();
		self.SelectedMetricWorkflow.removeAll();
		self.BuildDashboardMetricShowCountArray(self.MetricShowCountOrginalList);

	};

	self.GetRmUserProfile = function () {
		$.ajax({
		    url: rm.ajax.dashboardSvcUrl + "GetRmUserProfile",
			data: {},
			success: function (result) {
				self.ProfileResourceOrganizationList = result.ResourceOrganizations;
				self.ProfileProjectList = result.Projects;

				self.allResourceType(result.ResourceRequestTypes);
				self.allResourceOrg(result.ResourceOrganizations);
				self.allProfileResourceOrg(result.ProfileResourceOrganizations);
				self.allDashboardReportShowCount(result.MetricShowCountList);
				self.allRole(result.Roles);

				self.pRegions = result.Regions;
				self.pCountries = result.Countries;
				self.pCountryRegions = result.CountryRegions;

				//self.setLocationProfile();

				self.allProject(result.Projects);
				//self.UpdateProjectSmartSearchList(result.ResourceOrganizations);

				self.BuildAllMetricDatesObservableArray(result);

				self.allMetricDurations = result.DashboardMetricDurations;

				self.BuildProfileMetricDurationsArray(result.ProfileMetricDurations);
				self.ProfileMetricDurationOriginalList(result.ProfileMetricDurations);

				self.BuildDashboardMetricShowCountArray(result.MetricShowCountList);
				self.MetricShowCountOrginalList = result.MetricShowCountList;

				//add DTE
				self.DTEDetails(result.DTE);
				self.ReadonlyUserPreferences();

			}
		});
	};

	self.BuildProfileMetricDurationsArray = function (ProfileMetricDurations) {
		$.each(ProfileMetricDurations, function (index, item) {
			self.ProfileMetricDurationList.push({ RmUserProfileMetricDurationId: item.RmUserProfileMetricDurationId, Name: item.Name, MetricDurationId: item.MetricDurationId, DurationList: ko.observableArray(self.allMetricDurations), DashboardMetricId: item.DashboardMetricId });
		});
	};

	self.BuildDashboardMetricShowCountArray = function (DashboardMetricShowCount) {
		var workflowConfigured = "";
		$.each(DashboardMetricShowCount, function (index, item) {
			if (item.DashboardContainerId == 1) {
				self.DashboardMetricWorkflow.push({ DashboardMetricId: item.DashboardMetricId, ShowCount: item.ShowCount, MetricName: item.MetricName });
			}
			if (item.DashboardContainerId == 2) {
				self.DashboardMetricProject.push({ DashboardMetricId: item.DashboardMetricId, ShowCount: item.ShowCount, MetricName: item.MetricName });
			}
			if (item.DashboardContainerId == 3) {
				self.DashboardMetricLineManager.push({ DashboardMetricId: item.DashboardMetricId, ShowCount: item.ShowCount, MetricName: item.MetricName });
			}
			if (item.ShowCount) {
				workflowConfigured = workflowConfigured == "" ? item.DashboardMetricId : workflowConfigured + "," + item.DashboardMetricId;
			}
		});
		if (String(workflowConfigured).length > 0)
			self.SelectedMetricWorkflow(String(workflowConfigured).split(','));
	};

	self.BuildAllMetricDatesObservableArray = function (result) {
		var arrayWithObservableChild = [];
		var currentDateObject;
		for (var index = 0, length = result.ProfileMetricDates.length; index < length; index++) {
			currentDateObject = result.ProfileMetricDates[index];
			arrayWithObservableChild.push({ Id: currentDateObject.Id, Name: currentDateObject.Name + ":", RmUserProfileMetricDateId: currentDateObject.RmUserProfileMetricDateId, FromDate: ko.observable(currentDateObject.FromDate) });
		}

		self.allMetricDates(arrayWithObservableChild);

	};

	self.RemoveProjectsFromProfileThatDoNotBelongToAddedOrganization = function (addedOrgUnitId) {
		var originalProfileProjectLength = self.ProfileProjectList.length;
		var currentOrgUnit;
		var currentProfileProject;
		var currentAllowedProject;
		var matchFound = false;
		for (var allowedOrgIndex = 0, allowedOrgLength = self.AllowedResopurceOrganizationAndProjectList.length; allowedOrgIndex < allowedOrgLength; allowedOrgIndex++) {
			currentOrgUnit = self.AllowedResopurceOrganizationAndProjectList[allowedOrgIndex];
			if (currentOrgUnit.Id == addedOrgUnitId) {
				for (var profileProjectIndex = originalProfileProjectLength - 1; profileProjectIndex >= 0; profileProjectIndex--) {
					currentProfileProject = self.ProfileProjectList[profileProjectIndex];
					matchFound = false;
					for (var allowedProjectIndex = 0, allowedProjectLenght = currentOrgUnit.ProjectList.length; allowedProjectIndex < allowedProjectLenght; allowedProjectIndex++) {
						currentAllowedProject = currentOrgUnit.ProjectList[allowedProjectIndex];
						if (parseInt(currentProfileProject.Id) == currentAllowedProject.Id) {
							matchFound = true;
						}
					}
					if (!matchFound) {
						self.ProfileProjectList.splice(profileProjectIndex, 1);
						matchFound = false;
					}
				}
				break;
			}
		}

		if (originalProfileProjectLength != self.ProfileProjectList.length) {
			self.allProject(self.ProfileProjectList);
		}
	};

	self.RemoveProjectsFromProfileForDeletedOrganization = function (removedOrgUnitId) {
		var originalProfileProjectLength = self.ProfileProjectList.length;
		var currentOrgUnit;
		var currentProfileProject;
		var currentAllowedProject;
		for (var allowedOrgIndex = 0, allowedOrgLength = self.AllowedResopurceOrganizationAndProjectList.length; allowedOrgIndex < allowedOrgLength; allowedOrgIndex++) {
			currentOrgUnit = self.AllowedResopurceOrganizationAndProjectList[allowedOrgIndex];
			if (currentOrgUnit.Id == removedOrgUnitId) {
				for (var profileProjectIndex = originalProfileProjectLength - 1; profileProjectIndex >= 0; profileProjectIndex--) {
					currentProfileProject = self.ProfileProjectList[profileProjectIndex];
					for (var allowedProjectIndex = 0, allowedProjectLenght = currentOrgUnit.ProjectList.length; allowedProjectIndex < allowedProjectLenght; allowedProjectIndex++) {
						currentAllowedProject = currentOrgUnit.ProjectList[allowedProjectIndex];
						if (parseInt(currentProfileProject.Id) == currentAllowedProject.Id) {
							self.ProfileProjectList.splice(profileProjectIndex, 1);
							break;
						}
					}
				}
				break;
			}
		}
		if (originalProfileProjectLength != self.ProfileProjectList.length) {
			self.allProject(self.ProfileProjectList);
		}
	};

	self.RemoveProjectsFromProfileThatDoNotBelongToDTE = function () {
		var originalProfileProjectLength = self.ProfileProjectList.length;
		var currentOrgUnit;
		var currentProfileProject;
		var currentAllowedProject;
		var matchFound = false;
		for (var allowedOrgIndex = 0, allowedOrgLength = self.AllowedResopurceOrganizationAndProjectList.length; allowedOrgIndex < allowedOrgLength; allowedOrgIndex++) {
			currentOrgUnit = self.AllowedResopurceOrganizationAndProjectList[allowedOrgIndex];
			for (var profileProjectIndex = originalProfileProjectLength - 1; profileProjectIndex >= 0; profileProjectIndex--) {
				matchFound = false;
				currentProfileProject = self.ProfileProjectList[profileProjectIndex];
				if (currentProfileProject.IsDTE) {
					matchFound = true;
				}
				if (!matchFound) {
					self.ProfileProjectList.splice(profileProjectIndex, 1);
					matchFound = false;
				}
			}
			break;
		}

		if (originalProfileProjectLength != self.ProfileProjectList.length) {
			self.allProject(self.ProfileProjectList);
		}
	};

	self.SortByName = function (array) {
		if (array) {
			array.sort(function (m1, p1) {
				var m = ('' + m1.Name).toLowerCase(),
						p = ('' + p1.Name).toLowerCase();

				if (m > p) return 1;
				if (m < p) return -1;
				return 0;
			});
		}
	};

	self.UpdateProjectSmartSearchList = function (profileOrgList) {
		var arrProjects = new Array();
		var profileOrgLength = profileOrgList.length;

		if (profileOrgLength == 0 && self.DTEDetails().length == 0) {
			$.each(self.AllowedResopurceOrganizationAndProjectList, function (index, item) {
				$.merge(arrProjects, item.ProjectList)
			});
		}
		else if (profileOrgLength == 0 && self.DTEDetails().length != 0) {
			var currentOrgWithDTE;
			$.each(self.AllowedResopurceOrganizationAndProjectList, function (index, item) {
				currentOrgWithDTE = item.ProjectList;
				currentOrgWithDTE = $.grep(item.ProjectList, function (item) {
					return item.IsDTE === true;
				});
				$.merge(arrProjects, currentOrgWithDTE)
			});
		}
		else {
			var currentOrg;
			//Add projects associated with organizations present in profile
			for (var profileOrgIndex = 0; profileOrgIndex < profileOrgLength; profileOrgIndex++) {
				for (var allowedOrgIndex = 0, allowedOrgLength = self.AllowedResopurceOrganizationAndProjectList.length; allowedOrgIndex < allowedOrgLength; allowedOrgIndex++) {
					currentOrg = self.AllowedResopurceOrganizationAndProjectList[allowedOrgIndex];
					if (currentOrg.Id == profileOrgList[profileOrgIndex].Id) {
						//check if dte is applied and filter
						if (self.DTEDetails().length != 0) {
							var filteredDTE = $.grep(currentOrg.ProjectList, function (item) {
								return item.IsDTE === true;
							});
						}
						if (filteredDTE) {
							$.merge(arrProjects, filteredDTE)
						}
						else {
							$.merge(arrProjects, currentOrg.ProjectList)
						}
						break;
					}
				}
			}
		}

		self.SortByName(arrProjects);

		self.AllProjectData = arrProjects;
		//Empty it every time
		var allProjectCodes = [];
		$.each(self.AllProjectData, function (i, obj) {
			allProjectCodes.push($.trim(obj.Name));
		});
		dashboardNs.bindTagToProjectTextArea(allProjectCodes);

		//	vm.projects(arrProjects);
	};

	// Visible Setting
	//Dashboard Preferences
	self.shouldShowPreferences = ko.observable(false);
	self.switchShouldShowPreferences = function () {
		self.shouldShowPreferences(!self.shouldShowPreferences());
	};

	self.shouldShowRegion = ko.observable(false);

	/* Selected Profile Start */
	//Visibility Setting 
	self.shouldShowselectedProfile = ko.observable(false);
	self.switchShouldShowselectedProfile = function () {
		self.shouldShowselectedProfile(!self.shouldShowselectedProfile());
		if (self.shouldShowselectedProfile()) {
			$("#divSelectedProfile").attr("style", "height:20%;");
		}
		else {
			$("#divSelectedProfile").attr("style", "height:4%;");
		}
	};
	/* Selected Profile end */


	/* Duration Section Start */
	//Visibility Setting 
	self.shouldShowMetricDuration = ko.observable(false);
	self.switchShouldShowMetricDuration = function () {
		self.shouldShowMetricDuration(!self.shouldShowMetricDuration());
	};
	/* Duration Section end */

	/* Report Counts Section Start */
	//Visibility Setting 
	self.shouldShowReportCounts = ko.observable(false);
	self.switchShouldShowReportCounts = function () {
		self.shouldShowReportCounts(!self.shouldShowReportCounts());
	};
	/* Report Counts Section end */

	/* Role Section Start */
	//Visibility Setting
	self.shouldShowRole = ko.observable(false);
	self.switchShouldShowRole = function () {
		self.shouldShowRole(!self.shouldShowRole());
	};

	//Role Selection
	self.roles = ko.observableArray();
	self.selectedRole = ko.observable();

	self.msgRole = ko.observable();

	//Role Profile
	self.allRole = ko.observableArray([]);

	self.removeRole = function () {
		self.allRole.remove(this);
		self.RemoveItemFromProfile(this.Id, "SharePointRole");
		dashboardNs.isUserPreferenceChanged = true;
		//Display message after the item was deleted the user's profile.
		var strMsg = 'The Role [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgRole(strMsg);
		$("#msgRole").show().delay(5000).fadeOut();
	};

	self.addRole = function () {
		var isExistedInProfile = false;
		if ($("#optionRole option:selected").val() === '') return;
		var arrlRoleList = jQuery.parseJSON(ko.toJSON(self.allRole));
		for (var i in arrlRoleList) {
			if (parseInt(arrlRoleList[i].Id) === parseInt($("#optionRole option:selected").val())) {
				isExistedInProfile = true;
			}
		}

		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.allRole.push({ Id: $("#optionRole option:selected").val(), Name: $("#optionRole option:selected").text() });
			//self.UpdateRole();
			self.AddItemToProfile($("#optionRole option:selected").val(), "SharePointRole");
			//Display message after the new project was added to the user's profile.
			var strMsg = 'The new Role [' + $("#optionRole option:selected").text() + '] has been successfully added to your preferences.';
			self.msgRole(strMsg);
			$("#msgRole").show().delay(5000).fadeOut();
			$("#optionRole").val('');
		}
	};

	/* Role Section End */

	//Resource Organization Preference
	self.shouldShowResourceOrg = ko.observable(false);
	self.switchShouldShowResourceOrg = function () {
		self.shouldShowResourceOrg(!self.shouldShowResourceOrg());
	};

	//Profile Resource Organization Preference
	self.shouldShowProfileResourceOrg = ko.observable(false);
	self.switchShouldShowProfileResourceOrg = function () {
		self.shouldShowProfileResourceOrg(!self.shouldShowProfileResourceOrg());
	};

	//Area Preference
	self.shouldShowArea = ko.observable(false);
	self.switchShouldShowArea = function () {
		self.shouldShowArea(!self.shouldShowArea());
	};

	//Date Preference
	self.shouldShowDate = ko.observable(false);
	self.switchShouldShowDate = function () {
		self.shouldShowDate(!self.shouldShowDate());
	};

	/* From Date Section Start */
	//self.myDate = ko.observable(new Date());
	self.myDate = ko.observable();

	self.msgMetricDates = ko.observable();

	self.SetFromDate = function (strDate) {
		var pDate;
		if (strDate != '') {
			pDate = rm.date.getDateFromQDateString(strDate.substring(0, 10));
		}
		else {
			//pDate = new Date();
			pDate = '';
		}
		self.myDate(pDate);
	};

	self.saveFromDates = function () {
		if (self.ValidateFromDates()) {
			self.UpdateDatesInProfile();
		}
	};

	self.ValidateFromDates = function () {
		var isValid = true;
		var fromDates = $(".validateDate");

		$.each(fromDates, function () {
			if (!rm.date.isValidDate($(this).val(), true)) {
				rm.validation.addError(this, "Invalid Date format. (dd-MMM-yyyy)");
				isValid = false;
			}
			if (rm.date.getDateFromQDateString($(this).val()) > rm.date.today()) {
				rm.validation.addError(this, Resources.FromDateGreaterThanTodaysDate);
				isValid = false;
			}
		});
		return isValid;
	}

	self.UpdateDatesInProfile = function () {
		var postData = { rmUserProfileMetricDate: $.parseJSON(ko.toJSON(self.allMetricDates())) };
		var metricDate;
		for (var index = postData.rmUserProfileMetricDate.length - 1; index >= 0; index--) {
			metricDate = postData.rmUserProfileMetricDate[index];
			if (metricDate.FromDate == "" && (metricDate.RmUserProfileMetricDateId == null || metricDate.RmUserProfileMetricDateId == "")) {
				postData.rmUserProfileMetricDate.splice(index, 1);
			}
		}

		$.ajax({
			type: "Post",
			contentType: "application/json; charset=utf-8",
			dataType: "json",
			url: rm.ajax.dashboardSvcUrl + "UpdateDatesInProfile",
			data: JSON.stringify(postData),
			success: function (data) {
				var observableArrayData = $.parseJSON(ko.toJSON(self.allMetricDates()));
				var currentDateObject;

				for (var index = 0, length = data.length; index < length; index++) {
					currentDateObject = data[index];

					for (var indexToUpdate = 0, innerLength = observableArrayData.length; indexToUpdate < innerLength; indexToUpdate++) {
						if (observableArrayData[indexToUpdate].Id == currentDateObject.Id) {
							self.allMetricDates.replace(self.allMetricDates()[indexToUpdate], { Id: currentDateObject.Id, Name: currentDateObject.Name, RmUserProfileMetricDateId: currentDateObject.RmUserProfileMetricDateId, FromDate: ko.observable(currentDateObject.FromDate) });
							break;
						}
					}
				}

				var strMsg = 'The From Date(s) have been successfully updated to your preferences.';
				self.msgMetricDates(strMsg);
				$("#msgMetricDates").show().delay(5000).fadeOut();
			},
			error: function (errMsg) { }
		});
	}

	/* From Date Section End */

	/* From Duration Section Start */
	self.msgMetricDurations = ko.observable();

	self.msgMetricReportCounts = ko.observable();

	self.saveDurations = function () {
		self.UpdateDurationsInProfile(this);
	};

	self.UpdateDurationsInProfile = function (obj) {
		var jData = $.parseJSON(ko.toJSON(vm.ProfileMetricDurationList()));
		var metricDuration;
		for (var index = jData.length - 1; index >= 0; index--) {
			metricDuration = jData[index];
			if (metricDuration.DashboardMetricId != obj.DashboardMetricId || (metricDuration.MetricDurationId == undefined && (metricDuration.RmUserProfileMetricDurationId == null || metricDuration.RmUserProfileMetricDurationId == 0))) {
				jData.splice(index, 1);
			}
		}

		var postData = { rmUserProfileMetricDuration: jData };
		$.ajax({
			type: "Post",
			contentType: "application/json; charset=utf-8",
			dataType: "json",
			url: rm.ajax.dashboardSvcUrl + "UpdateDurationsInProfile",
			data: JSON.stringify(postData),
			success: function (data) {
				var observableArrayDuration = $.parseJSON(ko.toJSON(self.ProfileMetricDurationList()));
				var currentDurationObject;

				for (var index = 0, length = data.length; index < length; index++) {
					currentDurationObject = data[index];

					for (var indexToUpdate = 0, innerLength = observableArrayDuration.length; indexToUpdate < innerLength; indexToUpdate++) {
						if (observableArrayDuration[indexToUpdate].DashboardMetricId == currentDurationObject.DashboardMetricId) {
							self.ProfileMetricDurationList.replace(self.ProfileMetricDurationList()[indexToUpdate], { RmUserProfileMetricDurationId: currentDurationObject.RmUserProfileMetricDurationId, Name: currentDurationObject.Name, MetricDurationId: currentDurationObject.MetricDurationId, DurationList: ko.observableArray(self.allMetricDurations), DashboardMetricId: currentDurationObject.DashboardMetricId });
							break;
						}
					}
				}
				dashboardNs.isUserPreferenceChanged = true;
				var strMsg = 'Duration(s) have been successfully updated to your preferences.';
				self.msgMetricDurations(strMsg);
				$("#msgMetricDurations").show().delay(5000).fadeOut();
			},
			error: function (errMsg) { }
		});
	}

	self.SaveDashboardReportCounts = function () {
		var postData = {
			dashboardReportCounts: vm.SelectedMetricWorkflow()
		}

		$.ajax({
			type: "Post",
			contentType: "application/json; charset=utf-8",
			dataType: "json",
			url: rm.ajax.dashboardSvcUrl + "SaveDashboardReportCountsInProfile",
			data: JSON.stringify(postData),
			success: function (data) {
				self.msgMetricReportCounts(Resources.DashboardReportCountSaveSuccessMsg);
				$("#msgMetricReportCounts").show().delay(5000).fadeOut();
			},
			error: function (errMsg) { }
		});
		dashboardNs.isUserPreferenceChanged = true;
	};

	self.WorkflowReportCountValidation = function () {
		if ($("input[name='SelectedMetricWorkflow']:checked:enabled").length > 5) {
			alert(Resources.DashboardMetricShowCountMaxCheckedError);
			vm.SelectedMetricWorkflow.pop();
			return false;
		}
		return true;
	};

	self.LineManagerReportCountValidation = function () {
		if ($("input[name='SelectedMetricLineManager']:checked:enabled").length > 5) {
			alert(Resources.DashboardMetricShowCountMaxCheckedError);
			vm.SelectedMetricWorkflow.pop();
			return false;
		}
		return true;
	};

	self.ProjectReportCountValidation = function () {
		if ($("input[name='SelectedMetricProject']:checked:enabled").length > 5) {
			alert(Resources.DashboardMetricShowCountMaxCheckedError);
			vm.SelectedMetricWorkflow.pop();
			return false;
		}
		return true;
	};

	/* From Duration Section End */

	/* Metrix Report Section Start*/
	self.lblRequestWorkflow = ko.observable();
	self.lblProject = ko.observable();
	self.lblLineManager = ko.observable();
	self.lblOversight = ko.observable();
	self.requestWorkflow = ko.observableArray([]);
	self.reportProject = ko.observableArray([]);
	self.reportLineManager = ko.observableArray([]);
	self.reportOversight = ko.observableArray([]);
	/* Metrix Report Section End*/


	self.showReportDetail = function () {
		var stripNumbers = /(\(\d*\))/g;
		var reportNameOnly = this.reportName.replace(stripNumbers, '');
		_gaq.push(['_trackEvent', 'Dashboards-' + reportNameOnly, dashboardNs.userIdAndRoles()]);
		dashboardNs.selectedReport = reportNameOnly;
		dashboardNs.ShowDataInGrid(this.Id, this.reportName);
	};

	OpenReport = function (reportUrl) {
		window.open(reportUrl, '_blank');
	};

	OpenMultipalReportLinkDialog = function (containerId, metricId, metricName) {
		var reportLinkDialog = $("#div-ReportLink");
		reportLinkDialog.hide();
		reportLinkDialog.html("");
		reportLinkDialog.append("</br>");
		var ul = $("<ul style='list-style-type: none;margin-left:10px;'/>");

		$.each(self.DashboardMetricData.Containers, function (containerIndex, container) {
			if (container.Id == containerId) {
				$.each(container.Metrics, function (metricIndex, metric) {
					if (metric.Id == metricId) {
						$.each(metric.JumpToLinks, function (linkIndex, jumpToLink) {
							ul.append("<li><a href=\"javascript:OpenReport('" + jumpToLink.LinkUrl + "');\">" + jumpToLink.LinkText + "</a></li></br>");
						});
						return false;
					}
				});
				return false;
			}
		});

		reportLinkDialog.append(ul);
		var documentHeight = $(document).height();
		//var dialogHeight = documentHeight > 600 ? 300 : documentHeight - 660;

		reportLinkDialog.dialog({
			modal: true,
			title: metricName,
			width: 400,
			height: 300, // dialogHeight,
			resizable: false
		});
	};

	self.DashboardMetricData = [];
	self.GetReportMatrix = function () {
		var vm = this;

		var selItem = {};
		selItem.qId = $("[id*=qId]").val();

		var jsonData = ko.toJSON(selItem);
		$.ajax({
			type: "Post",
			contentType: "application/json; charset=utf-8",
			dataType: "json",
			url: rm.ajax.dashboardSvcUrl + "GetDashBoardData",
			data: JSON.stringify(self.showCountByUserPreferences),
			success: function (result) {
				self.DashboardMetricData = result;

				var tooltip = [];
				var arrRequestWorkflow = [];
				var arrReportProject = [];
				var arrReportLineManager = [];
				var arrReportOversight = [];
				var flag = "";
				var count = "";
				var ShowLinkIcon = "";
				var iMetric;
				for (var j = 0, lenC = result.Containers.length; j < lenC; j++) {
					switch (j) {
						case 0:
							self.lblRequestWorkflow(result.Containers[j].ContainerName);
							break;
						case 1:
							self.lblProject(result.Containers[j].ContainerName);
							break;
						case 2:
							self.lblLineManager(result.Containers[j].ContainerName);
							break;
						case 3:
							self.lblOversight(result.Containers[j].ContainerName);
							break;
					}
					for (var i = 0, len = result.Containers[j].Metrics.length; i < len; i++) {
						iMetric = result.Containers[j].Metrics[i];
						flag = "";
						count = " (" + iMetric.Count + ")";
						if (iMetric.ShowIndicatorInstedOfCount) {
							if (iMetric.Count > 0) {
								flag = "<img src='../images/exclamation.png' class='ImgMetric'>";
							}
							count = "";
						}

						ShowLinkIcon = "";
						if (iMetric.ShowLinkIcon) {
							if (iMetric.SingleReport) {
								ShowLinkIcon = '<img src="../images/externalLinkIcon.png" onclick="OpenReport(\'' + iMetric.JumpToLinks[0].LinkUrl + '\');" class="ImgMetric">';
							}
							else {
								ShowLinkIcon = '<img src="../images/externalLinkIcon.png" onclick="OpenMultipalReportLinkDialog(' + result.Containers[j].Id + ',' + iMetric.Id + ',\'' + iMetric.MetricName + '\');" class="ImgMetric">';
							}
						}

						if (iMetric.Tooltip != "") {
							tooltip.push({ Id: iMetric.Id, Tooltip: iMetric.Tooltip });
						}

						var metricLink = { Id: iMetric.Id, reportName: iMetric.MetricName + count, showLinkIcon: flag + ShowLinkIcon };
						switch (j) {
							case 0:
								arrRequestWorkflow.push(metricLink);
								break;
							case 1:
								arrReportProject.push(metricLink);
								break;
							case 2:
								arrReportLineManager.push(metricLink);
								break;
							case 3:
								arrReportOversight.push(metricLink);
								break;
						}
					}
				}
				self.requestWorkflow(arrRequestWorkflow);
				self.reportProject(arrReportProject);
				self.reportLineManager(arrReportLineManager);
				self.reportOversight(arrReportOversight);

				dashboardNs.bindLabelQtip(tooltip);

			},
			error: function (errMsg) {
			}
		});

	};

	/* Metric dates*/
	//Visibility Setting
	self.shouldShowMetricDates = ko.observable(false);
	self.switchShouldShowMetricDates = function () {
		self.shouldShowMetricDates(!self.shouldShowMetricDates());
	};

	/* Resource Type Section Start */
	//Visibility Setting
	self.shouldShowResourceType = ko.observable(false);
	self.switchShouldShowResourceType = function () {
		self.shouldShowResourceType(!self.shouldShowResourceType());
	};

	//Resource Type Selection
	self.resourceTypes = ko.observableArray();
	self.selectedResourceType = ko.observable();

	self.msgResourceType = ko.observable();

	//Resource Type Profile

	self.allResourceType = ko.observableArray([]);

	self.removeResourceType = function () {
		dashboardNs.isUserPreferenceChanged = true;
		self.allResourceType.remove(this);
		self.RemoveItemFromProfile(this.Id, "ResourceType");

		//Display message after the item was deleted the user's profile.
		var strMsg = 'The Resource Type [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgResourceType(strMsg);
		$("#msgResourceType").show().delay(5000).fadeOut();
	};

	self.addResourceType = function () {
		var isExistedInProfile = false;
		if ($("#optionResourceType option:selected").val() === '') return;
		var arrlResourceTypeList = jQuery.parseJSON(ko.toJSON(self.allResourceType));
		for (var i in arrlResourceTypeList) {
			if (parseInt(arrlResourceTypeList[i].Id) === parseInt($("#optionResourceType option:selected").val())) {
				isExistedInProfile = true;
			}
		}

		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.allResourceType.push({ Id: $("#optionResourceType option:selected").val(), Name: $("#optionResourceType option:selected").text() });
			//self.UpdateResourceType();
			self.AddItemToProfile($("#optionResourceType option:selected").val(), "ResourceType");
			//Display message after the new project was added to the user's profile.
			var strMsg = 'The new Resource Type [' + $("#optionResourceType option:selected").text() + '] has been successfully added to your preferences.';
			self.msgResourceType(strMsg);
			$("#msgResourceType").show().delay(5000).fadeOut();
			$("#optionResourceType").val('');
		}
	};

	/* Resource Type Section End */

	//Method to Remove Multiple Projects from the Profile


	//End of Method to Remove Multiple Projects from the Profile

	//Method to add Multiple Projects to the User Preference
	self.AddProjectsToPreference = function (projectIds) {
		var postData = {
			projectIds: projectIds
		}
		$.ajax({
			type: "Post",
			contentType: "application/json; charset=utf-8",
			dataType: "json",
			url: rm.ajax.dashboardSvcUrl + "AddProjectsToProfile",
			data: JSON.stringify(postData),
			success: function (data) {
				$("#projectCodesList").tagit('removeAll');
				$("#inValidProjectCodes").empty();
				var strMsg = 'The Project(s) has been successfully added to your preferences.';
				self.msgProject(strMsg);
				$("#msgProjectAdded").show().delay(5000).fadeOut();
			},
			error: function (errMsg) {
			}
		});
		dashboardNs.isUserPreferenceChanged = true;
	};
	//End of Method


	/* Common Method: Add Item to Profile */

	self.AddItemToProfile = function (propertyId, propertyName) {
		var selItem = {};
		selItem.propertyId = propertyId;
		selItem.propertyName = propertyName;
		selItem.qId = $("[id*=qId]").val();

		var jsonData = ko.toJSON(selItem);
		$.ajax({
			type: "post",
			url: rm.ajax.dashboardSvcUrl + "AddItemToProfile",
			data: jsonData,
			success: function (data) { },
			error: function (errMsg) { }
		});
	};

	/* Common Method: Remove Itme from Profile */
	self.RemoveItemFromProfile = function (propertyId, propertyName) {
		var selItem = {};
		selItem.propertyId = propertyId;
		selItem.propertyName = propertyName;
		selItem.qId = $("[id*=qId]").val();

		var jsonData = ko.toJSON(selItem);

		$.ajax({
			type: "post",
			url: rm.ajax.dashboardSvcUrl + "RemoveItemFromProfile",
			data: jsonData,
			success: function (data) {
				//self.GetReportMatrix();
			},
			error: function (errMsg) { }
		});
	};

	/* Resource Organization Start */
	self.allResourceOrg = ko.observableArray([]);

	self.msgOrganization = ko.observable();
	self.removeResourceOrg = function () {
		self.allResourceOrg.remove(this);
		self.UpdateProjectSmartSearchList(self.ProfileResourceOrganizationList);
		self.RemoveProjectsFromProfileForDeletedOrganization(this.Id);

		self.RemoveItemFromProfile(this.Id, "Organization");
		dashboardNs.isUserPreferenceChanged = true;
		//Display message after the item was deleted the user's profile.
		var strMsg = 'The Organization [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgOrganization(strMsg);
		$("#msgOrganization").show().delay(5000).fadeOut();
	};

	self.addResourceOrg = function () {
		var isExistedInProfile = false;
		var selectedOrganizationId = $("#optionResourceOrg option:selected").val();
		var selectedOrganizationText = $("#optionResourceOrg option:selected").text();
		if (selectedOrganizationId === '') return;
		var arrOrganizationList = jQuery.parseJSON(ko.toJSON(self.allResourceOrg));
		for (var i in arrOrganizationList) {
			if (parseInt(arrOrganizationList[i].Id) === parseInt(selectedOrganizationId)) {
				isExistedInProfile = true;
			}
		}

		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.allResourceOrg.push({ Id: selectedOrganizationId, Name: selectedOrganizationText });
			self.AddItemToProfile(selectedOrganizationId, "Organization");

			if (self.ProfileResourceOrganizationList.length == 1) {
				self.RemoveProjectsFromProfileThatDoNotBelongToAddedOrganization(selectedOrganizationId);//maintain projects in profile if added organization has this proj.
			}
			//filter project dropdown when organization is added to pref.
			self.UpdateProjectSmartSearchList(self.ProfileResourceOrganizationList);

			//Display message after the new project was added to the user's profile.
			var strMsg = 'The Organization [' + selectedOrganizationText + '] has been successfully added to your preferences.';
			self.msgOrganization(strMsg);
			$("#msgOrganization").show().delay(5000).fadeOut();
			$("#optionResourceOrg").val('');
		}
	};
	/* Resource Organization End */

	/* Profile Resource Organization Start */
	self.allProfileResourceOrg = ko.observableArray([]);

	self.allDashboardReportShowCount = ko.observableArray([]);

	self.msgResourceOrganization = ko.observable();
	self.removeProfileResourceOrg = function () {
		dashboardNs.isUserPreferenceChanged = true;
		self.allProfileResourceOrg.remove(this);
		//self.UpdateProjectSmartSearchList(self.ProfileResourceOrganizationList);
		//self.RemoveProjectsFromProfileForDeletedOrganization(this.Id);

		self.RemoveItemFromProfile(this.Id, "ResourceOrganization");

		//Display message after the item was deleted the user's profile.
		var strMsg = 'The Organization [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgResourceOrganization(strMsg);
		$("#msgResourceOrganization").show().delay(5000).fadeOut();
	};

	self.addProfileResourceOrg = function () {
		var isExistedInProfile = false;
		var selectedOrganizationId = $("#optionProfileResourceOrg option:selected").val();
		var selectedOrganizationText = $("#optionProfileResourceOrg option:selected").text();
		if (selectedOrganizationId === '') return;
		var arrOrganizationList = jQuery.parseJSON(ko.toJSON(self.allProfileResourceOrg));
		for (var i in arrOrganizationList) {
			if (parseInt(arrOrganizationList[i].Id) === parseInt(selectedOrganizationId)) {
				isExistedInProfile = true;
			}
		}

		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.allProfileResourceOrg.push({ Id: selectedOrganizationId, Name: selectedOrganizationText });
			self.AddItemToProfile(selectedOrganizationId, "ResourceOrganization");

			//if (self.ProfileResourceOrganizationList.length == 1)
			//{
			//	self.RemoveProjectsFromProfileThatDoNotBelongToAddedOrganization(selectedOrganizationId);//maintain projects in profile if added organization has this proj.
			//}
			//filter project dropdown when organization is added to pref.
			//self.UpdateProjectSmartSearchList(self.ProfileResourceOrganizationList);

			//Display message after the new project was added to the user's profile.
			var strMsg = 'The Organization [' + selectedOrganizationText + '] has been successfully added to your preferences.';
			self.msgResourceOrganization(strMsg);
			$("#msgResourceOrganization").show().delay(5000).fadeOut();
			$("#optionProfileResourceOrg").val('');
		}
	};
	/* Profile Resource Organization End */

	/*DTE section*/
	self.addDTE = function () {
		var isExistedInProfile = false;
		var DTEvalue = jQuery.parseJSON(ko.toJSON(self.DTEDetails));
		if (DTEvalue.length != 0) {
			isExistedInProfile = true;
		}
		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.DTEDetails.push({ Id: "1"/*dummy*/, Name: "Show RBM Projects only" });
			self.AddItemToProfile(1, "DTE");

			self.RemoveProjectsFromProfileThatDoNotBelongToDTE();

			var len = self.DTEDetails().length;
			//filter the proj dropdown here to show only dte
			self.UpdateProjectSmartSearchList(self.ProfileResourceOrganizationList);

			var strMsg = 'The [RBM] has been successfully added to your preferences.';
			self.msgProject(strMsg);
			$("#msgProjectAdded").show().delay(5000).fadeOut();
		}
	};

	self.removeDTE = function () {
		dashboardNs.isUserPreferenceChanged = true;
		self.DTEDetails.remove(this);
		self.RemoveItemFromProfile(0, "DTE");
		var len = self.DTEDetails().length;
		//adjust the project dropdown back again to show dte and non dte
		self.UpdateProjectSmartSearchList(self.ProfileResourceOrganizationList);
		var strMsg = 'The [RBM] has been successfully deleted from your preferences.';
		self.msgProject(strMsg);
		$("#msgProjectAdded").show().delay(5000).fadeOut();
	};
	/* Project Section Start */
	//Visibility Setting
	self.shouldShowProject = ko.observable(false);
	self.switchShouldShowProject = function () {
		self.shouldShowProject(!self.shouldShowProject());
	};

	//Project Selection
	self.projects = ko.observableArray();
	self.selectedProject = ko.observable();

	//Project Profile
	self.allProject = ko.observableArray([]);

	self.removeProject = function () {
		dashboardNs.isUserPreferenceChanged = true;
		self.allProject.remove(this);
		self.RemoveItemFromProfile(this.Id, "Project");
		var strMsg = 'The Project [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgProject(strMsg);
		$("#msgProjectAdded").show().delay(5000).fadeOut();
	};

	self.msgProject = ko.observable();

	self.clearList = function () {
		$("#projectCodesList").tagit('removeAll');
		$("#inValidProjectCodes").empty();
	},

	self.removeAllProjects = function () {
		var alreadyInUserPreferenceProjectIds = [];
		var arrProjectList = jQuery.parseJSON(ko.toJSON(self.allProject)); //Get all projects already in the Preference List.
		if (arrProjectList.join() != "") {
			$.each(arrProjectList, function (i, obj) {
				alreadyInUserPreferenceProjectIds.push(obj.Id);
			});
			var postData = {
				projectIds: alreadyInUserPreferenceProjectIds
			}
			$.ajax({
				type: "Post",
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				url: rm.ajax.dashboardSvcUrl + "RemoveAllProjects",
				data: JSON.stringify(postData),
				success: function (data) {
					var strMsg = 'All the Project(s) has been successfully deleted from your preferences.';
					self.msgProject(strMsg);
					$("#msgProjectAdded").show().delay(5000).fadeOut();
					self.allProject.removeAll();
					$("#inValidProjectCodes").empty();
				},
				error: function (errMsg) {
					alert("Error saving data to Server :" + errMsg);
				}
			});
			dashboardNs.isUserPreferenceChanged = true;
		}
	},

	self.addProject = function () {
		var isExistedInProfile = false;
		self.projectsList = []; //This contains the seletected projectList

		var alreadyInUserPreferenceProjectIds = [];
		var arrProjectList = jQuery.parseJSON(ko.toJSON(self.allProject)); //Get all projects already in the Preference List.
		$.each(arrProjectList, function (i, obj) {
			alreadyInUserPreferenceProjectIds.push(JSON.parse(obj.Id));
		});
		var DTEProjList = jQuery.parseJSON(ko.toJSON(self.OnlyDTEProjectIds));



		//Here Need to change the implementation to get the input from the Tag-It plugin field.
		var projectCodeList = $("#projectCodesList").val();
		if ($("#projectCodesList").val() === '') return;

		//Lookup to get the Project Id for the ProjectCode
		$.each(projectCodeList.split(','),
					function (idx, taglabel) {
						var Id = $.map(self.AllProjectData, function (element, index) { if ($.trim(element.Name) == taglabel) return element.Id }).join();
						if (Id != "") {
							var isDTE = false;
							//Using parse Json to again remove the double quotes from the stringified element.
							var exists = $.inArray(JSON.parse(Id), alreadyInUserPreferenceProjectIds);
							if ((exists < 0)) {
								if ($.inArray(jQuery.parseJSON(Id), DTEProjList) >= 0) {
									isDTE = true;
								}
								self.projectsList.push(Id);
								self.allProject.push({ Id: Id, Name: taglabel, IsDTE: isDTE });
							}
						}
					});

		//Send the data to the Service to Add the ProjectDetails
		if (self.projectsList.join() != "") {
			self.AddProjectsToPreference(self.projectsList);
		}
		else {
			$("#projectCodesList").tagit('removeAll');
			$("#inValidProjectCodes").empty();
		}
	};

	/* Project Section End */

	/* TherapeuticArea Section Start */

	//TherapeuticArea Visiable Setting

	//TherapeuticArea Selection
	self.therapeuticAreas = ko.observableArray();
	self.selectedTherapeuticArea = ko.observable();

	self.GetTherapeuticAreas = function () {
		var vm = this;

		$.ajax({
			type: "Get",
			contentType: "application/json; charset=utf-8",
			dataType: "json",
			url: rm.ajax.utilitySvcUrl + "OneClick/GetTherapeuticAreas",
			data: {},
			success: function (result) {
				var arrTherapeuticAreas = $.map(result, function (item) { return { Id: item.Id, Name: item.Name } });
				vm.therapeuticAreas(arrTherapeuticAreas);
			},
			error: function (errMsg) { }
		});
	};

	self.selectedTherapeuticArea.subscribe(function (selectedValue) { });

	self.shouldShowTherapeuticArea = ko.observable(false);
	self.switchShouldShowTherapeuticArea = function () {
		self.shouldShowTherapeuticArea(!self.shouldShowTherapeuticArea());
	};

	self.allTherapeuticArea = ko.observableArray([]);

	self.removeTherapeuticArea = function () {
		dashboardNs.isUserPreferenceChanged = true;
		self.allTherapeuticArea.remove(this);
		self.RemoveItemFromProfile(this.Id, "TherapeuticArea");
		//Display message after the item was deleted the user's profile.
		var strMsg = 'The Therapeutic Area [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgTherapeuticArea(strMsg);
		$("#msgTherapeuticArea").show().delay(5000).fadeOut();
	};

	self.msgTherapeuticArea = ko.observable();
	self.addTherapeuticArea = function () {
		var isExistedInProfile = false;

		var arrTherapeuticAreaList = jQuery.parseJSON(ko.toJSON(self.allTherapeuticArea));
		if ($("#optionTherapeuticArea option:selected").val() === '') return;
		for (var i in arrTherapeuticAreaList) {
			if (parseInt(arrTherapeuticAreaList[i].Id) === parseInt($("#optionTherapeuticArea option:selected").val())) {
				isExistedInProfile = true;
			}
		}

		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.allTherapeuticArea.push({ Id: $("#optionTherapeuticArea option:selected").val(), Name: $("#optionTherapeuticArea option:selected").text() });
			self.AddItemToProfile($("#optionTherapeuticArea option:selected").val(), "TherapeuticArea");

			//Display message after the new project was added to the user's profile.
			var strMsg = 'The Therapeutic Area [' + $("#optionTherapeuticArea option:selected").text() + '] has been successfully added to your preferences.';
			self.msgTherapeuticArea(strMsg);
			$("#msgTherapeuticArea").show().delay(5000).fadeOut();
			$("#optionTherapeuticArea").val('');
		}
	};

	/* TherapeuticArea Section End */

	//Resource Organization
	//self.resourceOrganizations = ko.observableArray(arrResourceOrganizations);
	self.resourceOrganizations = ko.observableArray();
	self.selectedResourceOrganization = ko.observable();
	self.selectedProfileResourceOrganization = ko.observable();
	//Location Profile Array Start
	self.pRegions = [];
	self.pCountries = [];
	self.pCountryRegions = [];
	//Loction Profile Array End

	/* Region Section Start */
	self.msgRegion = ko.observable();
	self.regions = ko.observableArray();
	self.selectedRegion = ko.observable();
	self.allRegion = ko.observableArray([]);

	self.AllProjectData = [];



	self.removeRegion = function () {
		dashboardNs.isUserPreferenceChanged = true;
		self.allRegion.remove(this);

		self.RemoveItemFromProfile(this.Id, "Region");

		//Display message after the item was deleted the user's profile.
		var strMsg = 'The Region [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgRegion(strMsg);
		$("#msgRegion").show().delay(5000).fadeOut();


		self.setPCountry();
		self.setPCountryRegion();
		self.setCountryProfileList();

		self.resetCountryDropDownList();
		self.resetCountryRegionDropDownList();
	};

	self.addRegion = function () {
		var isExistedInProfile = false;
		//var arrRegionList = jQuery.parseJSON(ko.toJSON(self.allRegion));
		var arrRegionList = self.pRegions;
		if ($("#optionRegion option:selected").val() === '') return;
		for (var i in arrRegionList) {
			if (parseInt(arrRegionList[i].Id) === parseInt($("#optionRegion option:selected").val())) {
				isExistedInProfile = true;
			}
		}

		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.allRegion.push({ Id: parseInt($("#optionRegion option:selected").val()), Name: $("#optionRegion option:selected").text() });
			self.AddItemToProfile($("#optionRegion option:selected").val(), "Region");

			//Display message after the new project was added to the user's profile.
			var strMsg = 'The Region [' + $("#optionRegion option:selected").text() + '] has been successfully added to your preferences.';
			self.msgRegion(strMsg);
			$("#msgRegion").show().delay(5000).fadeOut();

			//self.pRegions.push({ Id:parseInt($("#optionRegion option:selected").val()), Name: $("#optionRegion option:selected").text() });
			self.resetCountryDropDownList();
			$("#optionRegion").val('');
		}
	};

	self.resetCountryDropDownList = function () {
		var arrCountries = [], item = {}, regionName = null, countryName = null;
		var arrRegionList = self.pRegions;
		for (var i in arrRegionList) {
			regionName = arrRegionList[i].Name;
			for (var j = 0, len = self.AllowedRegionCountryList.length; j < len; j++) {
				if (arrRegionList[i].Id === self.AllowedRegionCountryList[j].Id) {
					for (var k = 0, klen = self.AllowedRegionCountryList[j].Countries.length; k < klen; k++) {
						item = self.AllowedRegionCountryList[j].Countries[k];
						arrCountries.push({ Id: item.Id, Name: regionName + ' - ' + item.Name });
					}
				}
			}
		}
		self.countries(arrCountries);
	};

	self.resetCountryRegionDropDownList = function () {
		var arrCountryRegions = [], item = {}, regionName = null, countryName = null;
		var arrCountryList = self.pCountries;

		for (var i in arrCountryList) {
			for (var j = 0, len = self.AllowedCountryRegionList.length; j < len; j++) {
				item = self.AllowedCountryRegionList[j];
				if (arrCountryList[i].Id === item.CountryId) {
					arrCountryRegions.push({ Id: item.CountryRegionId, Name: item.CountryName + ' - ' + item.CountryRegionName });
				}
			}
		}
		self.countryRegions(arrCountryRegions);
	};

	self.selectedRegion.subscribe(function (selectedValue) { });

	/* Region Section End */

	/* Country Section Start */
	self.msgCountry = ko.observable();
	self.countries = ko.observableArray();
	self.selectedCountry = ko.observable();
	self.allCountry = ko.observableArray([]);

	self.addCountry = function () {
		var isExistedInProfile = false;

		//var arrCountryList = jQuery.parseJSON(ko.toJSON(self.allCountry));
		var arrCountryList = self.pCountries;
		if ($("#optionCountry option:selected").val() === '') return;
		for (var i in arrCountryList) {
			if (parseInt(arrCountryList[i].Id) === parseInt($("#optionCountry option:selected").val())) {
				isExistedInProfile = true;
			}
		}

		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.allCountry.push({ Id: parseInt($("#optionCountry option:selected").val()), Name: $("#optionCountry option:selected").text() });
			self.AddItemToProfile($("#optionCountry option:selected").val(), "Country");

			//Display message after the new project was added to the user's profile.
			var strMsg = 'The Country [' + $("#optionCountry option:selected").text() + '] has been successfully added to your preferences.';
			self.msgCountry(strMsg);
			$("#msgCountry").show().delay(5000).fadeOut();

			self.resetCountryRegionDropDownList();
			$("#optionCountry").val('');
		}
	};

	self.removeCountry = function () {
		dashboardNs.isUserPreferenceChanged = true;
		self.allCountry.remove(this);
		self.RemoveItemFromProfile(this.Id, "Country");

		//Display message after the item was deleted the user's profile.
		var strMsg = 'The Country [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgCountry(strMsg);
		$("#msgCountry").show().delay(5000).fadeOut();

		self.resetCountryRegionDropDownList();
		self.setPCountryRegion();
		self.setCountryRegionProfileList();
	};

	self.setPCountry = function () {
		var arrTemp = [], item = {}, regionId;
		var arrPRegion = self.pRegions;
		var arrPCountry = self.pCountries;

		for (var i = 0, len = arrPCountry.length; i < len; i++) {
			item = arrPCountry[i];
			regionId = self.getRegionIdByCountryId(item.Id);
			for (var j = 0, jLen = arrPRegion.length; j < jLen; j++) {
				if (regionId === arrPRegion[j].Id) {
					arrTemp.push(item);
					break;
				}
			}
		}
		self.pCountries = arrTemp;
	};

	self.setPCountryRegion = function () {
		var arrTemp = [], item = {}, countryId;
		var arrPCountry = self.pCountries;
		var arrPCountryRegions = self.pCountryRegions;

		for (var i = 0, len = arrPCountryRegions.length; i < len; i++) {
			item = arrPCountryRegions[i];

			countryId = self.getCountryIdByCountryRegionId(item.Id);
			for (var j = 0, jLen = arrPCountry.length; j < jLen; j++) {
				if (countryId === arrPCountry[j].Id) {
					arrTemp.push(item);
					break;
				}
			}
		}
		self.pCountryRegions = arrTemp;
	};

	self.getRegionIdByCountryId = function (countryId) {
		var regionId, item = {}, kitem = {}, isFound = false;
		var arrRegion = self.AllowedRegionCountryList;
		for (var i = 0, len = arrRegion.length; i < len; i++) {
			item = arrRegion[i];

			for (var k = 0, klen = item.Countries.length; k < klen; k++) {
				kitem = item.Countries[k];
				if (countryId === kitem.Id) {
					regionId = item.Id;
					isFound = true;
					break;
				}
			}

			if (isFound) break;

		}

		return regionId;
	};

	self.getCountryIdByCountryRegionId = function (countryRegionId) {
		var countryId = -1, item = {};
		var arrCountryRegion = self.AllowedCountryRegionList;
		for (var i = 0, len = arrCountryRegion.length; i < len; i++) {
			item = arrCountryRegion[i];
			if (countryRegionId === item.CountryRegionId) {
				countryId = item.CountryId;
				break;
			}
		}
		return countryId;
	};

	self.selectedCountry.subscribe(function (selectedValue) { });

	/* Country Section End */

	/* CountryRegion Section Start */
	self.msgCountryRegion = ko.observable();
	self.countryRegions = ko.observableArray();
	self.allCountryRegion = ko.observableArray([]);
	self.selectedCountryRegion = ko.observable();

	self.addCountryRegion = function () {
		var isExistedInProfile = false;

		var arrCountryRegionList = jQuery.parseJSON(ko.toJSON(self.allCountryRegion));
		if ($("#optionCountryRegion option:selected").val() === '') return;
		for (var i in arrCountryRegionList) {
			if (parseInt(arrCountryRegionList[i].Id) === parseInt($("#optionCountryRegion option:selected").val())) {
				isExistedInProfile = true;
			}
		}

		if (!isExistedInProfile) {
			dashboardNs.isUserPreferenceChanged = true;
			self.allCountryRegion.push({ Id: parseInt($("#optionCountryRegion option:selected").val()), Name: $("#optionCountryRegion option:selected").text() });
			self.AddItemToProfile($("#optionCountryRegion option:selected").val(), "CountryRegion");
			//Display message after the new project was added to the user's profile.
			var strMsg = 'The Country Region [' + $("#optionCountryRegion option:selected").text() + '] has been successfully added to your preferences.';
			self.msgCountryRegion(strMsg);
			$("#msgCountryRegion").show().delay(5000).fadeOut();
			$("#optionCountryRegion").val('');
		}
	};

	self.removeCountryRegion = function () {
		dashboardNs.isUserPreferenceChanged = true;
		self.allCountryRegion.remove(this);
		self.RemoveItemFromProfile(this.Id, "CountryRegion");
		//Display message after the item was deleted the user's profile.
		var strMsg = 'The Country Region [' + this.Name + '] has been successfully deleted from your preferences.';
		self.msgCountryRegion(strMsg);
		$("#msgCountryRegion").show().delay(5000).fadeOut();

	};

	self.selectedCountryRegion.subscribe(function (selectedValue) { });

	/* CountryRegion Section End */

	/* Organization Section Start */

	self.selectedResourceOrganization.subscribe(function (selectedValue) { });
	self.selectedProfileResourceOrganization.subscribe(function (selectedValue) { });

	/* Organization Section End */
};

var dashboardNs = {
	gridJsonResponse: null,
	invalidEntry: "",
	isUserPreferenceChanged: false,
	gridId: "list",
	gridSelector: "#list",
	selectedReport: '',
	userIdAndRoles: function () {
		var rmUserid = $("[id*=hdnRmUserid]").val();
		var userRoles = $("[id*=userRoles]").val();
		return rmUserid + " " + userRoles;
	},

	checkValidationRules: function (metricId) {
		var response = this;
		$.rm.Ajax_DashboardSynchronous("CheckValidationRulesByMetricId", { metricTypeId: metricId }, function (data) {
			response = data;
		});

		return response;
	},

	ShowDataInGrid: function (metricId, reportName) {
		$(dashboardNs.gridSelector).jqGrid('GridUnload');

		var validationResponse = dashboardNs.checkValidationRules(metricId);
		if (validationResponse.HasError) {
			$("#selectedReport").html("");
			dashboardNs.isExportToExcelEnabled = false;
			rm.ui.ribbon.refresh();
			rmCommon.showDialogWithButtons("Validation Error", validationResponse.ConcatenatedErrorMessages, null, [{ text: "Cancel", click: function () { $(this).dialog("close"); } }, { text: "Open User Preferences", click: function () { dashboardNs.EditPreferences(); $(this).dialog("close"); } }]);
		}
		else {
			$("#selectedReport").html(reportName);
			$.ajax({
			    url: rm.ajax.dashboardSvcUrl + "GetGRidConfigByMetricId",
				data: JSON.stringify({ metricId: metricId }),
				contentType: 'application/json; charset=utf-8',
				cache: false,
				dataType: "json",
				type: "POST",
				success: function (data) {
					dashboardNs.InitializeGrid(metricId, data.GridColumnConfig);
					rm.grid.resizeGrid(dashboardNs.gridSelector, $(window).width() - 196);
				}
			});
		}
	},

	InitializeGrid: function (metricId, columnConfiguration) {
		$(dashboardNs.gridSelector).jqGrid({
			datatype: function (postdata) {
				postdata.metricId = metricId;

				$.ajax({
				    url: rm.ajax.dashboardSvcUrl + "GetMetricResult",
					data: JSON.stringify({ metricId: metricId }),
					contentType: 'application/json; charset=utf-8',
					cache: false,
					dataType: "json",
					type: "POST",
					success: function (jsonData) {
						var response = {
							Records: $.parseJSON(jsonData.RecordsJson),
							TotalPages: jsonData.TotalPages,
							CurrentPageNumber: jsonData.CurrentPageNumber,
							RecordCount: jsonData.RecordCount
						};

						dashboardNs.gridJsonResponse = response;
						dashboardNs.isExportToExcelEnabled = jsonData.RecordCount != 0;
						dashboardNs.MetricId = metricId;
						rm.ui.ribbon.refresh();

						$(dashboardNs.gridSelector)[0].addJSONData(response);
						setTimeout(function () {
							if (jsonData.DisableSort) {
								$(".ui-jqgrid-sortable").removeClass("ui-jqgrid-sortable").click(function () { alert(jsonData.SortingDisabledMessage); });
							}
							rm.grid.setHeaderRowHeightDoubleLine(dashboardNs.gridId);
							$(dashboardNs.gridSelector).setGridParam({ datatype: "local" });

							$.each(columnConfiguration, function (index, element) {
								if (element.qtip != null && element.qtip != "") {
									rm.qtip.showInfo("#list_" + element.index, element.qtip, { width: '200' }, { my: 'bottom center', at: 'top center' });
								}
							});

							$.each($(".qitpOnHover"), function (index, element) {
								var me = $(element);
								me.parent().qtip({
									content: me.html(),
									style: { width: '350px' },
									position: {
										my: 'bottom left',
										at: 'top right',
										viewport: $(window)
									}
								});
							});
						}, 10);
					},
					error: function () {
						dashboardNs.isExportToExcelEnabled = false;
						rm.ui.ribbon.refresh();
					}
				});
			},
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			//postData: gridPost,
			loadonce: true,
			pager: '#listPager',
			autowidth: true,
			shrinkToFit: false,
			height: (window.screen.height - 480),
			multiselect: false,
			colModel: columnConfiguration,
			multipleSearch: false,
			//Grouping options
			grouping: false,
			gridComplete: function () {
				if (dashboardNs.gridJsonResponse != null) {
					$.each(dashboardNs.gridJsonResponse.Records, function (index, dataRow) {
						if (dataRow.DataRowClass != null && dataRow.DataRowClass != "") {
							$("tr#" + dataRow.id).addClass(dataRow.DataRowClass);
						}
					});
				}
			},
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			serializeRowData: function (postData) { return JSON.stringify(postData); },
			serializeGridData: function (postData) {
				var data = { ReqGroup: requestGroupId };
				return rm.grid.serializeGridData(postData, data);
			}
		});
	},

	bindTagToProjectTextArea: function (bindArray) {
		//Binding Tag Plugin 
		var enteredMultipleValues = false;
		$('#projectCodesList').tagit({
			allowSpaces: true,
			availableTags: bindArray,
			allowNewTags: false,
			triggerKeys: ['enter', 'comma', 'tab'],
			preprocessTag: function (val) {
				if (!val) {
					return '';
				}

				var values = val.split(",");
				if (values.length > 1) {
					enteredMultipleValues = true;
					for (var i = 0; i < values.length; i++) {
						$('#projectCodesList').tagit("createTag", values[i]);
						if (i == values.length - 1) {
							if (dashboardNs.invalidEntry != "") {
								$("#inValidProjectCodes").empty().append("These Project Code(s) were not added. :" + dashboardNs.invalidEntry.slice(2));
								dashboardNs.invalidEntry = "";
								enteredMultipleValues = false;
							}
						}
					}
					return '';
				} else {
					$("#inValidProjectCodes").empty();
					return val;
				}
			},
			afterTagAdded: function (event, ui) {
				var allTags = $(this).tagit("assignedTags");
				for (i = 0; i <= allTags.length - 1; i++) {
					var tag = allTags[i];
					var exists = $.inArray(tag, bindArray);
					if (exists < 0) {
						if (enteredMultipleValues) {
							dashboardNs.invalidEntry = dashboardNs.invalidEntry + " , " + tag;
						}
						$(this).tagit("removeTagByLabel", tag);
						return false;
					}
				}
			}
		});
	},


	EditPreferences: function () {
		var dpProfile = $("#div-profile");
		dpProfile.hide();

		var documentHeight = $(document).height();
		var dialogHeight = documentHeight > 600 ? 600 : documentHeight - 50;
		$("#divProfileContainer").css({ height: dialogHeight - 100 });
		vm.GetPreferences();

		dpProfile.dialog({
			modal: true,
			width: 830,
			height: dialogHeight,
			resizable: false,
			buttons: {
				Ok: function () {
					$(this).dialog("close");
					if (dashboardNs.isUserPreferenceChanged) {
						RefreshPage();
					} else {
						vm.resetRmUserProfile();
					}
				}
			},
			close: function () {
				if (dashboardNs.isUserPreferenceChanged) {
					RefreshPage();
				} else {
					vm.resetRmUserProfile();
				}
			}
		});
	},

	ExportToExcel: function () {
		window.location = "/ViewAttachment.ashx?ID=1&metricId=" + dashboardNs.MetricId;
		_gaq.push(['_trackEvent', 'DashboardExport-' + dashboardNs.selectedReport, dashboardNs.userIdAndRoles()]);
	},

	isExportToExcelEnabled: false,

	ExportToExcelEnabled: function () {
		return dashboardNs.isExportToExcelEnabled;
	},
	// qTipfor dashboard hover overs
	bindLabelQtip: function (tooltip) {
		$.each(tooltip, function (index, item) {
			rm.qtip.showInfo("." + item.Id, item.Tooltip, { width: '300px' }, { my: 'bottom center', at: 'top center' });
		});
	},

	ShowCountForAllReports: function () {
		vm.showCountByUserPreferences = false;
		vm.GetReportMatrix();
	}
};
var vm = new ViewModel();