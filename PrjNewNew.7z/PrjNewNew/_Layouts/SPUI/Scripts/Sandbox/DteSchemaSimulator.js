﻿/// <reference path="../common/rmhelper.js" />
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });

	dteSimNs.init();
	rm.ui.ribbon.delayedRefresh();
});

var dteSimNs = {
	dteSchemaContainerSelector: "#dteSchemaContainer",
	txtNumberOfSitesSelector: "#txtNumberOfSites",
	lblFsiCovWeeksSelector: "[id$=lblFsiCovWeeks]",
	txtFsiDateSelector: "#txtFsiDate",
	txtCovDateSelector: "#txtCovDate",
	siteMonitoringTierRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.tierRow",
	siteMonitoringTotalRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.tierTotalRow",
	siteMonitoringBudgetRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.budgetRow",
	siteMonitoringBufferRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.bufferRow",
	siteMonitoringBufferVisitsRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.bufferVisitsRow",
	siteMonitoringActualBufferRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.actualBufferRow",
	pharmacyTierRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.tierRow",
	pharmacyTotalRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.tierTotalRow",
	pharmacyBudgetRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.budgetRow",
	pharmacyBufferRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.bufferRow",
	pharmacyBufferVisitsRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.bufferVisitsRow",
	pharmacyActualBufferRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.actualBufferRow",
	siteMonitoringTableSelector: "#dteSiteMonitoringSchema",
	siteMonitoringBufferTableSelector: "#dteSiteMonitoringBufferTable",
	pharmacyTableSelector: "#dtePharmacyMonitoringSchema",
	pharmacyBufferTableSelector: "#dtePharmacyMonitoringBufferTable",
	isPharmacyEnabledSelector: "#cbIsPharmacyEnabled",
	txtRvOsRatioSelector: "#txtRvOsRatio",
	divRvAsOsEquivalentSelector: "#divRvasOsEquivalent",
	divRevisedOsTargetSelector: "#divRevisedOsTarget",
	targetSitePercentageSelector: "[name=TargetSitePercentage]",
	cbTierEnabledSelector: "[name=cbTierEnabled]",
	tierNameSelector: "[placeholderKey=TierName]",
	tierCycleSelector: "[name=TierCycle]",
	onSiteVisitRatioSelector: "[name=OnSiteVisitRatio]",
	remoteVisitRatioSelector: "[name=RemoteVisitRatio]",
	contactFrequencyWeeksSelector: "[placeholderKey=ContactFrequencyWeeks]",
	clearForDisabledTiersSelector: "[clearForDisabledTiers=1]",
	sivCovVisitCountSelector: "[placeholderkey=SivCovVisitCount]",
	onsiteVisitCountSelector: "[placeholderkey=OnsiteImvVisitCount]",
	remoteVisitCountSelector: "[placeholderkey=RemoteVisitCount]",
	totalVisitCountSelector: "[placeholderkey=TotalVisitCount]",
	getTotalPharmacyTargetSitePctSelector: function () { return dteSimNs.pharmacyTableSelector + " [placeholderKey=TotalPharmacyTargetSitePct]"; },
	totalPharmacyProjectedNumberOfSitesSelector: "[placeholderKey=TotalPharmacyProjectedNumberOfSites]",
	getTotalOnsiteTargetSitePctSelector: function () { return dteSimNs.siteMonitoringTableSelector + " [placeholderKey=TotalOnsiteTargetSitePct]"; },
	totalOnsiteProjectedNumberOfSitesSelector: "[placeholderKey=TotalOnsiteProjectedNumberOfSites]",
	txtProjectedInitiatedSiteSelector: "#txtProjectedInitiatedSite",
	projectedNumberOfSitesSelector: "[placeholderKey=ProjectedNumberOfSites]",
	onsiteVisitFrequencySelector: "[placeholderKey=OnsiteVisitFrequency]",
	removeVisitFrequencySelector: "[placeholderKey=RemoveVisitFrequency]",
	getSiteMonitoringBudgetedSivCovVisitCountSelector: function () { return dteSimNs.siteMonitoringTableSelector + " [placeholderkey=siteMonitoringBudgetedSivCovVisitCount]"; },
	getSiteMonitoringBudgetedOnsiteImvVisitCountSelector: function () { return dteSimNs.siteMonitoringTableSelector + " [placeholderkey=siteMonitoringBudgetedOnsiteImvVisitCount]"; },
	getSiteMonitoringBudgetedRemoteVisitCountSelector: function () { return dteSimNs.siteMonitoringTableSelector + " [placeholderkey=siteMonitoringBudgetedRemoteVisitCount]"; },
	getSiteMonitoringBufferSelector: function () { return dteSimNs.siteMonitoringBufferTableSelector + " [placeholderkey=SiteMonitoringBuffer]"; },
	getSiteMonitoringTargetNumberOfBufferVisitsSelector: function () { return dteSimNs.siteMonitoringBufferTableSelector + " [placeholderkey=SiteMonitoringTargetNumberOfBufferVisits]"; },
	getSiteMonitoringActualBufferSelector: function () { return dteSimNs.siteMonitoringBufferTableSelector + " [placeholderkey=SiteMonitoringActualBuffer]"; },
	getTotalOnsiteOnsiteVisitCountSelector: function () { return dteSimNs.siteMonitoringTableSelector + " [placeholderkey=TotalOnsiteOnsiteImvVisitCount]"; },
	getGrandTotalPharmacyVisitCountSelector: function () { return dteSimNs.pharmacyTableSelector + " [placeholderkey=GrandTotalPharmacyVisitCount]"; },
	getPharmacyBudgetedSivCovVisitCountSelector: function () { return dteSimNs.pharmacyTableSelector + " [placeholderKey=pharmacyBudgetedSivCovVisitCountSelect]"; },
	getPharmacyBudgetedOnsiteImvVisitCountSelector: function () { return dteSimNs.pharmacyTableSelector + " [placeholderKey=pharmacyBudgetedOnsiteImvVisitCountSelect]"; },
	getPharmacyBufferSelector: function () { return dteSimNs.pharmacyBufferTableSelector + " [placeholderKey=PharmacyBuffer]"; },
	getPharmacyTargetNumberOfBufferVisitsSelector: function () { return dteSimNs.pharmacyBufferTableSelector + " [placeholderKey=PharmacyTargetNumberOfBufferVisits]"; },
	getPharmacyActualBufferSelector: function () { return dteSimNs.pharmacyBufferTableSelector + " [placeholderKey=PharmacyActualBuffer]"; },
	getSiteMonitoringTierRowCollectionSelector: function () { return dteSimNs.siteMonitoringTableSelector + " tr.tierRow"; },
	getPharmacyTierRowCollectionSelector: function () { return dteSimNs.pharmacyTableSelector + " tr.tierRow"; },
	getProjectedInitiatedSiteCount: function () { return parseInt($(dteSimNs.txtProjectedInitiatedSiteSelector).val()); },
	isLoadPharmacyGlobalTierProportionsActive: function () { return dteSimNs.isPharmacySchemaEnabled() && dteSimNs.atLeastOneTierEnabled(dteSimNs.pharmacyTableSelector); },
	isLoadSiteMonGlobalTierProportionsActive: function () { return dteSimNs.atLeastOneTierEnabled(dteSimNs.siteMonitoringTableSelector); },
	atLeastOneTierEnabled: function (targetTableSelector) { return $(targetTableSelector + " tr.tierRow input[name=cbTierEnabled]:checked").length > 0; },
	loadSiteMonGlobalTierProportions: function () { dteSimNs.getGlobalTierPropertions(false); },
	loadPharmacyGlobalTierProportions: function () { dteSimNs.getGlobalTierPropertions(true); },
	getGlobalTierPropertions: function (isPharmacy) {
		var buttonArr = [
			{
				text: "Confirm", click: function () {
					var confirmDialog = $(this);
					rm.ajax.projectSvcAsyncPost("GetGloblSiteTierProportions", { isPharmacy: isPharmacy }, function (serviceResponse) {
						confirmDialog.dialog("close");
						dteSimNs.showSiteProportionVlauesInTierRows((isPharmacy ? dteSimNs.pharmacyTableSelector : dteSimNs.siteMonitoringTableSelector), serviceResponse);
					});
				}
			},
			rm.ui.dialog.standardButtons.cancel];
		var onOpen = function () {
			$("#divConfirmGlobalProportion").siblings(".ui-dialog-buttonpane").find("button:nth-child(2)").focus();
		};
		rm.ui.dialog.showModalWithButtonsAndCloseHandler("#divConfirmGlobalProportion", "Confirm Load Global Tier Proportions", "", false, 500, 150, buttonArr, null, onOpen);
	},
	showSiteProportionVlauesInTierRows: function (targetTableSelector, tierProportionList) {
		if (tierProportionList != null && tierProportionList.length > 0) {
			var pctTotal = 0;
			var hasDisabledTier = false;
			$.each(tierProportionList, function (index, tierPoportion) {
				if ($(targetTableSelector + " tr.tierRow[tiername=" + tierPoportion.TierId + "] input[name=cbTierEnabled]").is(":checked")) {
					pctTotal += tierPoportion.TargetPercentage;
					if (!hasDisabledTier && index == 5 && pctTotal != 100) {
						tierPoportion.TargetPercentage += 100 - pctTotal;
					}
					rm.validation.clearError($(targetTableSelector + " tr.tierRow[tiername=" + tierPoportion.TierId + "] [name=TargetSitePercentage]").val(tierPoportion.TargetPercentage.toFixed(1)));
				}
				else { hasDisabledTier = true; }
			});

			setTimeout(function () {
				dteSimNs.updateSiteCount();
				setTimeout(function () { dteSimNs.recomputeVisitCount(dteSimNs.getTierConfigForAllValidTiers()); }, 20);
			}, 20);
		}
	},

	init: function () {
		rm.runtimeValues.helpPageUrl = "rbmSchemaSimulator.aspx";
		dteSimNs.bindHelpTextHover();
		dteSimNs.bindEventHandlers();
		dteSimNs.showDteSchema();

		$(dteSimNs.txtFsiDateSelector).qDatepicker();
		$(dteSimNs.txtCovDateSelector).qDatepicker();
	},
	bindHelpTextHover: function () {
		rm.qtip.showInfo("#infoSmEnabled", "Enable the Tiers that you intend to use.");
		rm.qtip.showInfo("#infoSmTierCycle", "The duration, in weeks, of the repeating pattern of alternating On-Site and Remote Visits.");
		rm.qtip.showInfo("#infoSmOnsiteVisitRatio", "The number of On-Site Visits within each repeating Tier Cycle.<br/>Enter 0-52.<br/>QRPM:RM always projects an On-Site Visit on the first day of each Frequency in the Requests.");
		rm.qtip.showInfo("#infoSmRemoteVisitRatio", "The number of Remote Visits within each repeating Tier Cycle.<br/>Enter 0-52. Enter zero if no Remote Visits are planned.");
		rm.qtip.showInfo("#infoSmContactFrequency", "The average interval between visits to a Site using this Tier (whether On-Site or Remote)");
		rm.qtip.showInfo("#infoSmProjectedNumberOfSite", "Number of Sites in this Tier");
		rm.qtip.showInfo("#infoSmOnsiteFrequency", "On-Site Visit Frequency in weeks, derived from 'Tier Cycle (weeks)' repeat cycle, and the OS:RV ratio");
		rm.qtip.showInfo("#infoSmRemoteFrequency", "Remote Visit Frequency in weeks, derived from 'Tier Cycle (weeks)' repeat cycle, and the OS:RV ratio");
		rm.qtip.showInfo("#infoSmProjectedSivCovVisitCount", "SIV + COV Visit numbers are computed in this column using a simple algorithm based on the number of projected sites.");
		rm.qtip.showInfo("#infoSmProjectedOnsiteImvVisitCount", "On-Site IMV Visit numbers are computed in this column using a simple algorithm based on the entered visit frequencies, and \"First Subject Randomized-Last Site Closed Duration (weeks)\" monitoring period (shown top right.)");
		rm.qtip.showInfo("#infoSmProjectedRemoteVisitCount", "Remote Visit numbers are computed in this column using a simple algorithm based on the entered visit frequencies, and \"First Subject Randomized-Last Site Closed Duration (weeks)\" monitoring period (shown top right.)");
		rm.qtip.showInfo("#infoSmProjectedTotalVisitCount", "Total Visit numbers are computed in this column using a simple algorithm based on the entered visit frequencies, \"First Subject Randomized-Last Site Closed Duration (weeks)\" monitoring period (shown top right.)");

		rm.qtip.showInfo("#infoPmEnabled", "Enable the Tiers that you intend to use.");
		rm.qtip.showInfo("#infoPmOnsiteVisitFrequency", "Enter the planned Pharmacy OS Visit Frequency in weeks");
		rm.qtip.showInfo("#infoPmProjectedSiteCount", "Number of Sites in this Tier");
		rm.qtip.showInfo("#infoPmSivCovVisitCount", "Number of projected SIV + COV Visits for Pharmacy sites");
		rm.qtip.showInfo("#infoPmProjectedVisitCount", "Number of projected On-Site Visits in the entire Pharmacy period");

		rm.qtip.showInfo("[id$=_LoadDsmGtp]", "Load the average tier percentages used across all RBM project sites for RBM Site Monitoring.");
		rm.qtip.showInfo("[id$=_LoadDpmGtp]", "Load the average tier percentages used across all RBM project sites for RBM Pharmacy Monitoring.");

		dteSimNs.showTargetSitePercentageDefault();
	},
	bindEventHandlers: function () {
		$(dteSimNs.isPharmacyEnabledSelector).click(dteSimNs.enableDisablePharmacySchema);
		$(dteSimNs.txtRvOsRatioSelector).bind("blur change", dteSimNs.handleRvOsRatioChange);
		$(dteSimNs.txtProjectedInitiatedSiteSelector).bind("keyup keydown paste cut drop", function (e) {
			if (rm.utilities.isNonControlCharacter(e.which)) {
				setTimeout(function () {
					dteSimNs.updateSiteCount();
					setTimeout(function () { dteSimNs.recomputeVisitCount(dteSimNs.getTierConfigForAllValidTiers()); }, 20);
				}, 20);
			}
		});
		$(dteSimNs.txtFsiDateSelector + "," + dteSimNs.txtCovDateSelector).change(function () { setTimeout(dteSimNs.handleDateChange, 20); });
	},
	showDteSchema: function (projectId) {
		rm.ajax.projectSvcAsyncPost("GetDteSchemaForSimulation", {}, function (serviceResponse) {
			if (!serviceResponse.IsSuccessful) {
				rm.ui.dialog.showServiceErrorModal("Service Error", serviceResponse.Message);
			}

			var data = serviceResponse.AdditionalData;
			if (data.SchemaLevel != '') {
				$(dteSimNs.getSiteMonitoringTierRowCollectionSelector()).remove();
				$(dteSimNs.siteMonitoringTableSelector + " tr.tierTotalRow").remove();
				$(dteSimNs.siteMonitoringTableSelector + " tr.budgetRow").remove();

				$(dteSimNs.getPharmacyTierRowCollectionSelector()).remove();
				$(dteSimNs.pharmacyTableSelector + " tr.tierTotalRow").remove();
				$(dteSimNs.pharmacyTableSelector + " tr.budgetRow").remove();

				dteSimNs.handleSiteMonitoringResponse(data.SiteMonitoringSchemaDetails);
				dteSimNs.handlePharmacyResponse(data.PharmacySchemaDetails);

				setTimeout(function () {
					$(dteSimNs.getSiteMonitoringBudgetedOnsiteImvVisitCountSelector()).change(dteSimNs.handleOnsiteBufferOrBudgetChange);
					$(dteSimNs.getPharmacyBudgetedOnsiteImvVisitCountSelector()).change(dteSimNs.handlePharmacyBufferOrBudgetChange);

					$(dteSimNs.getPharmacyBufferSelector()).bind("change", dteSimNs.calculateBufferVisitsCount);
					$(dteSimNs.getSiteMonitoringBufferSelector()).bind("change", dteSimNs.calculateBufferVisitsCount);

					$(dteSimNs.getJsonObjectForDirtyCheck().items[0].selector).bind("click blur keyup", rm.ui.ribbon.refresh);
					dteSimNs.updateTableTotals(dteSimNs.siteMonitoringTableSelector);
					dteSimNs.updateTableTotals(dteSimNs.pharmacyTableSelector);
					$.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, dteSimNs.getJsonObjectForDirtyCheck());

					rm.qtip.showInfo("#infoSmBuffer", "Enter desired buffer for triggered visits. 10% of Budgeted On-Site Interim Monitoring Visits is typical");
					rm.qtip.showInfo("#infoSmBudget", "Sourced from budget<br/>Update to the most recent budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
					rm.qtip.showInfo("#infoSmBufferTargetVisitCount", "% Buffer x Budget x 100. The number of visits to reserve in the buffer for unprojected visits (including, e.g. CTMS-Triggered visits)");
					rm.qtip.showInfo("#infoSmActualBuffer", "Budgeted Visits - Projected Visits. <br/>Red if over-budget. <br/>NB: That this calculation ignores 'Target # Visits for Buffer' for unprojected visits");

					rm.qtip.showInfo("#infoSmPastOsVisits", "Past CTMS On-Site Visits");
					rm.qtip.showInfo("#infoSmPlannedOsVisits", "Planned CTMS On-Site Visits");
					rm.qtip.showInfo("#infoSmTotalOsVisits", "Total CTMS On-Site Visits");
					rm.qtip.showInfo("#infoPmPastOsVisits", "Past CTMS On-Site Visits");
					rm.qtip.showInfo("#infoPmPlannedOsVisits", "Planned CTMS On-Site Visits");
					rm.qtip.showInfo("#infoPmTotalOsVisits", "Total CTMS On-Site Visits");

					rm.qtip.showInfo("#infoPmBuffer", "Enter desired buffer for triggered visits. 2% of Budgeted Pharmacy Visits is typical");
					rm.qtip.showInfo("#infoPmBudget", "Sourced from Budget<br/>Update to the most recent Budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
					rm.qtip.showInfo("#infPmBufferTargetVisitCount", "% Buffer x Budget x 100. The number of visits to reserve in the buffer for unprojected visits (including, e.g. CTMS-Triggered visits)");
					rm.qtip.showInfo("#infoPmActualBuffer", "Budgeted Visits - Projected Visits. <br/>Red if over-budget. <br/>NB: This calculation ignores 'Target # Visits for Buffer' for unprojected visits");

				}, 20);
				dteSimNs.dteSchemaLoadComplete = true;
				rm.ui.ribbon.delayedRefresh();
			}
			else {
				dteSimNs._isVisitSchemaUndefined = true;
				$(dteSimNs.dteSchemaContainerSelector).hide();
			}
			$(dteSimNs.getSiteMonitoringTierRowCollectionSelector() + " input.validateRange," + dteSimNs.getPharmacyTierRowCollectionSelector() + " input.validateRange").attr('oldtitle', null);
		});
	},
	areMilestonesValid: function () {
		var fsiMilestoneString = $(dteSimNs.txtFsiDateSelector).val();
		var covMilestoneString = $(dteSimNs.txtCovDateSelector).val();
		var isValid = true;

		if (rm.date.isValidDate($(dteSimNs.txtFsiDateSelector).val(), false)) {
			rm.validation.clearError(dteSimNs.txtFsiDateSelector);
		}
		else {
			rm.validation.addError(dteSimNs.txtFsiDateSelector, "First Subject Randomized date cannot be blank");
			isValid = false;
		}

		if (rm.date.isValidDate($(dteSimNs.txtCovDateSelector).val(), false)) {
			rm.validation.clearError(dteSimNs.txtCovDateSelector);
		}
		else {
			rm.validation.addError(dteSimNs.txtCovDateSelector, "Last Site Closed date cannot be blank");
			isValid = false;
		}

		if (isValid) {
			if (rm.date.qDateDiffDays(fsiMilestoneString, covMilestoneString) > 0) {
				rm.validation.clearError(dteSimNs.txtFsiDateSelector);
				rm.validation.clearError(dteSimNs.txtCovDateSelector);
			}
			else {
				rm.validation.addError(dteSimNs.txtFsiDateSelector, "First Subject Randomized date must be less than Last Site Closed date.");
				rm.validation.addError(dteSimNs.txtCovDateSelector, "Last Site Closed date must be greater than First Subject Randomized date");
				isValid = false;
			}
		}
		return isValid;
	},
	handleDateChange: function () {
		dteSimNs.calculateFsiCovWeeks();
		dteSimNs.recomputeVisitCount(dteSimNs.getTierConfigForAllValidTiers());
	},
	getTierConfigForAllValidTiers: function () {
		var rowDataList = [];

		//Collect data from each active tier row. Data is collected only when all values in a row are valid.
		$.each($(".tierRow:visible"), function (index, row) {
			if ($(row).find("input[type=checkbox]").is(":checked")) {
				var singleRowData = dteSimNs.getTierRowDataForVisitCount($(row));
				if (singleRowData != null) {
					rowDataList.push(singleRowData);
				}
			}
		});
		return rowDataList;
	},
	isGlobalDataValid: function () {
		var isValid = rm.validation.range.validate($(dteSimNs.txtProjectedInitiatedSiteSelector));
		isValid = dteSimNs.areMilestonesValid() && isValid;
		return isValid;
	},
	recomputeVisitCount: function (rowDataList) {
		if (rowDataList.length > 0 && dteSimNs.isGlobalDataValid()) {

			var postData = {
				tierConfigList: rowDataList,
				projectedInitiatedSiteCount: $(dteSimNs.txtProjectedInitiatedSiteSelector).val(),
				fsiMilestone: $(dteSimNs.txtFsiDateSelector).val(),
				covMilestone: $(dteSimNs.txtCovDateSelector).val(),
				sivFirstImvWeeks: 0//$(dteSimNs.txtSivFsiWeeksSelector).val()
			};

			rm.ajax.projectSvcAsyncPost("GetDteSiteVisitCountForSimulation", postData, function (serviceResponse) {
				if (serviceResponse.IsSuccessful) {
					//Show visit counts in corresponding tier rows
					$.each(serviceResponse.AdditionalData, function (index, visitCountDetails) {
						var tblSelector = visitCountDetails.IsPharmacy ? dteSimNs.pharmacyTableSelector : dteSimNs.siteMonitoringTableSelector;
						tierRow = $(tblSelector + " tr[TierName=" + visitCountDetails.TierName + "]");

						tierRow.find(dteSimNs.sivCovVisitCountSelector).text(Math.round(visitCountDetails.SivVisitCount + visitCountDetails.CovVisitCount));
						tierRow.find(dteSimNs.onsiteVisitCountSelector).text(Math.round(visitCountDetails.OnsiteImvVisitCount));
						tierRow.find(dteSimNs.remoteVisitCountSelector).text(Math.round(visitCountDetails.RemoteVisitCount));
						tierRow.find(dteSimNs.totalVisitCountSelector).text(Math.round((visitCountDetails.SivVisitCount + visitCountDetails.CovVisitCount + visitCountDetails.OnsiteImvVisitCount + visitCountDetails.RemoteVisitCount)));
					});

					//Update table totals
					setTimeout(function () {
						dteSimNs.updateTableTotals(dteSimNs.siteMonitoringTableSelector);
						dteSimNs.updateTableTotals(dteSimNs.pharmacyTableSelector);
					}, 20);
				} else {
					rm.ui.dialog.showServiceErrorModal("Service Error", serviceResponse.Message);
				}
			});
			dteSimNs.showVisitPatternGraphData();
		}
	},
	showHideSitePercentageError: function (totalSitePctSelector) {
		$(totalSitePctSelector).parent().find("div.pctError").remove();
		if (!dteSimNs.sitePercentageAddsTo100(totalSitePctSelector)) {
			var errorIcon = $("<div>", { class: "pctError iconFteError iconStatus", css: { marginLeft: 10, verticalAlign: "text-bottom" } });
			$(totalSitePctSelector).parent().append(errorIcon);
			setTimeout(function () { rm.qtip.showInfo(errorIcon, "Total Target Site Percentage should be 100."); }, 20);
		}
	},
	getTierRowDataForVisitCount: function (tierRow) {
		var schemaTable = tierRow.closest("table");
		var isPharmacySchema = schemaTable.attr("isPharmacySchema") === "1";

		var validValuesEntered = rm.validation.range.validate(tierRow.find(dteSimNs.tierCycleSelector));
		if (!isPharmacySchema) {
			validValuesEntered = validValuesEntered &&
													 rm.validation.range.validate(tierRow.find(dteSimNs.onSiteVisitRatioSelector)) &&
													 rm.validation.range.validate(tierRow.find(dteSimNs.remoteVisitRatioSelector)) &&
													 rm.validation.range.validate(tierRow.find(dteSimNs.targetSitePercentageSelector));
		}
		var tierCycle = tierRow.find(dteSimNs.tierCycleSelector).val();
		var onsiteVisitRatio = isPharmacySchema ? 1 : tierRow.find(dteSimNs.onSiteVisitRatioSelector).val();
		var remoteVisitRatio = isPharmacySchema ? 0 : tierRow.find(dteSimNs.remoteVisitRatioSelector).val();
		var targetSitePercentage = tierRow.find(dteSimNs.targetSitePercentageSelector).val();

		if (validValuesEntered && tierCycle > 0 && onsiteVisitRatio > 0 && remoteVisitRatio >= 0 && targetSitePercentage >= 0) {
			return {
				TierName: tierRow.attr("tiername"),
				TierCycle: tierCycle,
				OnSiteVisitRatio: onsiteVisitRatio,
				RemoteVisitRatio: remoteVisitRatio,
				TargetSitePercentage: targetSitePercentage,
				IsPharmacy: isPharmacySchema
			};
		}
		return null;
	},
	calculateFsiCovWeeks: function () {
		var fsiMilestoneString = $(dteSimNs.txtFsiDateSelector).val();
		var covMilestoneString = $(dteSimNs.txtCovDateSelector).val();
		if (rm.date.isValidDate(fsiMilestoneString, false) && rm.date.isValidDate(covMilestoneString, false)) {
			$(dteSimNs.lblFsiCovWeeksSelector).text(Math.round(rm.date.qDateDiffWeeks(fsiMilestoneString, covMilestoneString)));
		}
		else { $(dteSimNs.lblFsiCovWeeksSelector).text(""); }
	},
	showTargetSitePercentageDefault: function () {
		var sitePercentageToolTip = "The percentage of sites which are intended to fall into each Tier. Each Tier will have different visit patterns, so varying this percentage will affect whether the total projected visits exceed the Project's total budgeted visits.<br/>The business expectation of the average Target Site Percentage distribution between Tiers for all our Projects is:<br/><br/>";

		rm.ajax.utilitySvcAsyncGet("GetTargetSitePercentageDefault", {}, function (serviceResponse) {
			rm.qtip.showInfo("#infoSmSitePercentage", sitePercentageToolTip + dteSimNs.getDefaultValueTable(serviceResponse.OnsiteDefaults));
			rm.qtip.showInfo("#infoPmSitePercentage", sitePercentageToolTip + dteSimNs.getDefaultValueTable(serviceResponse.PharmacyDefaults));
		});
	},
	getDefaultValueTable: function (defaultValueList) {
		var tableHtml = "<table border='1' class='table-milestone'><tr><th>Tier</th><th>Typical Site Percentage</th></tr>";

		if (defaultValueList != null) {
			$.each(defaultValueList, function (index, defaultValue) {
				tableHtml += "<tr><td>" + defaultValue.Tier + "</td><td>" + defaultValue.Percentage + "</td></tr>"
			});
		}
		return tableHtml += "</table>";
	},

	isPageDirty: function () { return $.formStatus.isDirty(dteSimNs.getJsonObjectForDirtyCheck()); },
	isSchemaRefreshRequired: function () { return $.formStatus.isDirty(dteSimNs.getDirtyCheckSelectorForSchemaRefresh()); },
	getDirtyCheckSelectorForSchemaRefresh: function () {
		return {
			items:
				[{
					selector: dteSimNs.getSiteMonitoringTierRowCollectionSelector() + " input," + dteSimNs.getPharmacyTierRowCollectionSelector() + " input, " + dteSimNs.isPharmacyEnabledSelector,
					dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort
				}]
		};
	},
	getJsonObjectForDirtyCheck: function () {
		return {
			items:
				[{
					selector: dteSimNs.getDirtyCheckSelectorForSchemaRefresh().items[0].selector + ",.budgetRow input[type=text],.bufferRow input[type=text]",
					dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort
				}]
		};
	},
	sitePercentageAddsTo100: function (totalSitePercentSelector) { return parseFloat($(totalSitePercentSelector).text()) == 100; },

	isPharmacySchemaEnabled: function () { return $(dteSimNs.isPharmacyEnabledSelector).is(":checked"); },
	getSiteMonitoringOnsiteVisitBuffer: function () { return $(dteSimNs.getSiteMonitoringBufferSelector()).val(); },
	getPharmacyOnsiteVisitBuffer: function () { return dteSimNs.isPharmacySchemaEnabled() ? $(dteSimNs.getPharmacyBufferSelector()).val() : null; },

	updateSiteCount: function () {
		$.each($(".tierRow:visible"), function (index, row) {
			if ($(row).find("input[type=checkbox]").is(":checked")) { dteSimNs.calculateAndShowProjectedNumberOfSites($(row)); }
		})
		setTimeout(function () {
			dteSimNs.updateTableTotals(dteSimNs.siteMonitoringTableSelector);
			dteSimNs.updateTableTotals(dteSimNs.pharmacyTableSelector);
		}, 20);
	},
	handleRvOsRatioChange: function (eventArgs) {
		if ($(this).val() !== "" && rm.validation.range.validate($(this))) {
			var remoteToOnsiteRatio = parseFloat($(dteSimNs.txtRvOsRatioSelector).val());
			var totalRemoteVisits = parseInt($("td[placeholderkey=TotalOnsiteRemoteVisitCount]").text());
			var rvAsOsEquivalent = Math.round(totalRemoteVisits / remoteToOnsiteRatio);

			var totalOnsiteVisitBudgetText = $(dteSimNs.getSiteMonitoringBudgetedOnsiteImvVisitCountSelector()).text();

			$(dteSimNs.divRvAsOsEquivalentSelector).text(rvAsOsEquivalent);
			if ($.isNumeric(totalOnsiteVisitBudgetText)) {
				$(dteSimNs.divRevisedOsTargetSelector).text(parseInt(totalOnsiteVisitBudgetText) - rvAsOsEquivalent);
			}
			else { $(dteSimNs.divRevisedOsTargetSelector).text(""); }
		}
		else {
			$(dteSimNs.divRvAsOsEquivalentSelector).text("");
			$(dteSimNs.divRevisedOsTargetSelector).text("");
		}
	},
	updateVisitCount: function (eventArgs) {
		var tierRow = $(eventArgs.target).closest("tr");
		var singleRowData = dteSimNs.getTierRowDataForVisitCount(tierRow);
		if (singleRowData != null) {
			dteSimNs.recomputeVisitCount([singleRowData]);
		}
	},
	updateOnsiteFrequency: function (eventArgs) {
		var tierRow = $(eventArgs.target).closest("tr");
		var tierCycle = tierRow.find(dteSimNs.tierCycleSelector).val();
		var onsiteVisitRatio = tierRow.find(dteSimNs.onSiteVisitRatioSelector).val();

		if ($.isNumeric(tierCycle) && $.isNumeric(onsiteVisitRatio) && parseInt(onsiteVisitRatio) > 0) {
			tierRow.find(dteSimNs.onsiteVisitFrequencySelector).text((parseInt(tierCycle) / parseInt(onsiteVisitRatio)).toFixed(2) / 1);
		}
	},
	updateRemoteFrequency: function (eventArgs) {
		var tierRow = $(eventArgs.target).closest("tr");
		var tierCycle = tierRow.find(dteSimNs.tierCycleSelector).val();
		var remoteVisitRatio = tierRow.find(dteSimNs.remoteVisitRatioSelector).val();

		if ($.isNumeric(tierCycle) && $.isNumeric(remoteVisitRatio) && parseInt(remoteVisitRatio) > 0) {
			tierRow.find(dteSimNs.removeVisitFrequencySelector).text((parseInt(tierCycle) / parseInt(remoteVisitRatio)).toFixed(2) / 1);
		} else {
			tierRow.find(dteSimNs.removeVisitFrequencySelector).text("");
		}
	},
	updateContactFrequency: function (eventArgs) {
		var tierRow = $(eventArgs.target).closest("tr");
		var tierCycle = tierRow.find(dteSimNs.tierCycleSelector).val();
		var onsiteVisitRatio = tierRow.find(dteSimNs.onSiteVisitRatioSelector).val();
		var remoteVisitRatio = tierRow.find(dteSimNs.remoteVisitRatioSelector).val();

		if ($.isNumeric(tierCycle) && $.isNumeric(remoteVisitRatio) && $.isNumeric(onsiteVisitRatio)
				&& tierCycle > 0 && onsiteVisitRatio > 0 && remoteVisitRatio >= 0
				&& (parseInt(onsiteVisitRatio) + parseInt(remoteVisitRatio)) > 0) {
			tierRow.find(dteSimNs.contactFrequencyWeeksSelector).text((parseInt(tierCycle) / (parseInt(onsiteVisitRatio) + parseInt(remoteVisitRatio))).toFixed(2) / 1);
		}
	},
	calculateAndShowProjectedNumberOfSites: function (sourceTierRow) {
		projectedNumberOfSites = dteSimNs.calculateProjectedSiteCount(sourceTierRow.find(dteSimNs.targetSitePercentageSelector).val(), dteSimNs.getProjectedInitiatedSiteCount());
		if ($.isNumeric(projectedNumberOfSites) && projectedNumberOfSites >= 0) {
			sourceTierRow.find(dteSimNs.projectedNumberOfSitesSelector).attr("rawValue", projectedNumberOfSites).text(projectedNumberOfSites.toFixed(0));
		} else { sourceTierRow.find(dteSimNs.projectedNumberOfSitesSelector).text("").attr("rawValue", ""); }
	},
	updateTableTotals: function (targetTableSelector) {
		var numberOfSigmaGroups = 10;
		for (var groupIndex = 0; groupIndex < numberOfSigmaGroups; groupIndex++) {
			var sigmaColumnSelector = targetTableSelector + " [sigmacolumn=1][sigmagroup=" + groupIndex + "]";
			var sigmaAnswerColumnSelector = targetTableSelector + " [sigmaAnswercolumn=1][sigmagroup=" + groupIndex + "]";
			var columnTotal = 0;
			var nonNumericValueFound = false;

			$(sigmaColumnSelector).each(function (index, column) {
				var columnObj = $(column);
				var valueForSigma = "";
				if (columnObj.attr("includeDisabledTier") === "1" || columnObj.parent().find(dteSimNs.cbTierEnabledSelector).is(":checked")) {
					var rawValue = columnObj.attr("rawValue");
					if (rawValue == null || rawValue === "") { rawValue = columnObj.text(); }
					var textBox = columnObj.find("input[type=text]");

					if (textBox.length > 0) { valueForSigma = textBox.val(); }
					else { valueForSigma = rawValue; }

					if (valueForSigma !== "") {
						if ($.isNumeric(valueForSigma)) {
							columnTotal += parseFloat(valueForSigma);
						} else {
							nonNumericValueFound = true;
						}
					}
				}
			});

			if (nonNumericValueFound) {
				$(sigmaAnswerColumnSelector).text("");
			}
			else {
				var isDecimal = $(sigmaAnswerColumnSelector).attr("isDecimal") === "1";
				var digitsAfterDecinmal = isDecimal ? $(sigmaAnswerColumnSelector).attr("digitsAfterDecinmal") : 0;
				$(sigmaAnswerColumnSelector).text(columnTotal.toFixed(digitsAfterDecinmal));
			}
		}

		dteSimNs.showHideSitePercentageError(dteSimNs.getTotalOnsiteTargetSitePctSelector());
		if (dteSimNs.isPharmacySchemaEnabled()) {
			dteSimNs.showHideSitePercentageError(dteSimNs.getTotalPharmacyTargetSitePctSelector());
		}

		setTimeout(dteSimNs.calculateBufferVisitsCount, 10);
	},
	validateOnsiteAndRemoteVisitRatio: function (eventArgs) {
		var isValid = true;
		var tierRow = $(eventArgs.target).closest("tr");
		var onsiteVisitRatioControl = tierRow.find(dteSimNs.onSiteVisitRatioSelector);
		var remoteVisitRatioControl = tierRow.find(dteSimNs.remoteVisitRatioSelector);

		if ($.q.rangeValidate(onsiteVisitRatioControl) && $.q.rangeValidate(remoteVisitRatioControl)) {
			var onsiteVisitRatio = onsiteVisitRatioControl.val();
			var remoteVisitRatio = remoteVisitRatioControl.val();

			if (remoteVisitRatio == 0 && onsiteVisitRatio > 1) {
				rm.validation.addError(onsiteVisitRatioControl, Resources.OnsiteVisitRatioErrorOnCell.replace("{0}", 1));
				rm.validation.addError(remoteVisitRatioControl, Resources.RemoteVisitRatioErrorOnCell);
				isValid = false;
			}
			else {
				rm.validation.clearError(remoteVisitRatioControl);
				if (onsiteVisitRatio != 0) { rm.validation.clearError(onsiteVisitRatioControl); }
			}
		}
		return isValid;
	},

	enableDisablePharmacySchema: function () {
		if ($(this).is(":checked")) {
			$(dteSimNs.getPharmacyTierRowCollectionSelector()).find('input[type=checkbox]').prop("disabled", false);
			$(dteSimNs.getPharmacyBufferSelector()).prop("disabled", false);

		}
		else {
			$(dteSimNs.getPharmacyTierRowCollectionSelector()).find('input').prop("disabled", true).prop("checked", false).val("");
			$(dteSimNs.getTotalPharmacyTargetSitePctSelector()).text("");
			$(dteSimNs.getPharmacyTargetNumberOfBufferVisitsSelector()).text("");
			$(dteSimNs.getPharmacyActualBufferSelector()).text("").removeClass("overBudget");
			$(dteSimNs.getPharmacyBufferSelector()).val("");
			$(dteSimNs.getPharmacyBudgetedOnsiteImvVisitCountSelector()).val("");
			rm.validation.clearError(dteSimNs.getPharmacyBufferSelector());
			dteSimNs.clearCompletePharmacyVisitPattern();
		}
		dteSimNs.handlePharmacySchemaVisibility();
	},
	enableDisableTierRow: function (checkBox, sourcTableSelector, isPharmacy) {
		var jqCheckBox = $(checkBox);
		if (jqCheckBox.is(":checked")) {
			jqCheckBox.closest("tr").find('input[disabled]').prop("disabled", false);
		}
		else {
			rm.validation.clearError(jqCheckBox.closest("tr").find('input[type=text]').prop("disabled", true).prop("checked", false).val(""));
			jqCheckBox.closest("tr").find(dteSimNs.clearForDisabledTiersSelector).text("").removeAttr("rawValue");
			var tierId = parseInt(jqCheckBox.closest("tr").attr("tiername"));
			dteSimNs.clearVisitPatternRow(isPharmacy, tierId);
		}
		setTimeout(function () { dteSimNs.updateTableTotals(sourcTableSelector); }, 20);
	},
	getSiteMonitoringBudgetRow: function () { return $(dteSimNs.siteMonitoringBudgetRowTemplateSelector).clone(); },
	getSiteMonitoringSchemaFooterRow: function () {
		return $(dteSimNs.siteMonitoringTotalRowTemplateSelector).clone();
	},
	calculateProjectedSiteCount: function (targetSitePercent, projectedInitiatedSiteCount) { return projectedInitiatedSiteCount * targetSitePercent / 100; },
	handleSiteMonitoringResponse: function (siteMonitoringConfiguration) {
		if (siteMonitoringConfiguration.TierList.length > 0) {
			$.each(siteMonitoringConfiguration.TierList, function (index, tierRow) {
				dteSimNs.addOnsiteTierRowToSchemaTable(tierRow)
			});

			$(dteSimNs.siteMonitoringTableSelector).append(dteSimNs.getSiteMonitoringSchemaFooterRow());
			$(dteSimNs.siteMonitoringTableSelector).append(dteSimNs.getSiteMonitoringBudgetRow());

			setTimeout(function () {
				$(dteSimNs.getSiteMonitoringBudgetedSivCovVisitCountSelector()).text(siteMonitoringConfiguration.Budget.SivVisitCount + siteMonitoringConfiguration.Budget.CovVisitCount);
				$(dteSimNs.getSiteMonitoringBudgetedOnsiteImvVisitCountSelector()).text(siteMonitoringConfiguration.Budget.OnsiteImvVisitCount);
				$(dteSimNs.getSiteMonitoringBudgetedRemoteVisitCountSelector()).text(siteMonitoringConfiguration.Budget.RemoteVisitCount);
				$(dteSimNs.getSiteMonitoringBufferSelector()).val(siteMonitoringConfiguration.Budget.OnsiteVisitBuffer);
			}, 10);
		}
		else {
			$("#DteVisitSchemaLevel").text('No results to display.');
			$(dteSimNs.siteMonitoringTableSelector).parent().hide();
		}
	},
	addOnsiteTierRowToSchemaTable: function (tierRow) {
		var newRow = $(dteSimNs.siteMonitoringTierRowTemplateSelector).clone();

		if (tierRow.IsTierEnabled) {
			var projectedNumberOfSites = dteSimNs.calculateProjectedSiteCount(tierRow.TargetSitePercentage, dteSimNs.getProjectedInitiatedSiteCount());
			newRow.find(dteSimNs.projectedNumberOfSitesSelector).text(projectedNumberOfSites.toFixed(0)).attr("rawValue", projectedNumberOfSites);
			newRow.find(dteSimNs.onsiteVisitFrequencySelector).text((tierRow.TierCycle / tierRow.OnSiteVisitRatio).toFixed(2) / 1);
			newRow.find(dteSimNs.removeVisitFrequencySelector).text((tierRow.RemoteVisitRatio === 0) ? "" : (tierRow.TierCycle / tierRow.RemoteVisitRatio).toFixed(2) / 1);
			newRow.find(dteSimNs.sivCovVisitCountSelector).text(tierRow.SivVisitCount + tierRow.CovVisitCount);
			newRow.find(dteSimNs.onsiteVisitCountSelector).text(tierRow.OnsiteImvVisitCount);
			newRow.find(dteSimNs.remoteVisitCountSelector).text(tierRow.RemoteVisitCount);
			newRow.find(dteSimNs.totalVisitCountSelector).text(tierRow.SivVisitCount + tierRow.CovVisitCount + tierRow.OnsiteImvVisitCount + tierRow.RemoteVisitCount);
		}

		newRow.attr("TierName", tierRow.TierName);
		newRow.find(dteSimNs.tierNameSelector).text(tierRow.TierName);

		newRow.find(dteSimNs.cbTierEnabledSelector).prop("checked", tierRow.IsTierEnabled).click(function () {
			dteSimNs.enableDisableTierRow(this, dteSimNs.siteMonitoringTableSelector, false);
		});

		newRow.find(dteSimNs.targetSitePercentageSelector).val(tierRow.TargetSitePercentage).bind("keyup keydown paste cut drop", function () {
			dteSimNs.calculateAndShowProjectedNumberOfSites($(this).closest("tr"));
			setTimeout(function () { dteSimNs.updateTableTotals(dteSimNs.siteMonitoringTableSelector); }, 20);
		});

		newRow.find(dteSimNs.tierCycleSelector).val(tierRow.TierCycle).bind("blur change", function (eventArgs) {
			dteSimNs.updateContactFrequency(eventArgs);
			dteSimNs.updateOnsiteFrequency(eventArgs);
			dteSimNs.updateRemoteFrequency(eventArgs);
		});

		newRow.find(dteSimNs.onSiteVisitRatioSelector).val(tierRow.OnSiteVisitRatio).bind("blur change", function (eventArgs) {
			dteSimNs.updateContactFrequency(eventArgs);
			dteSimNs.updateOnsiteFrequency(eventArgs);
			dteSimNs.validateOnsiteAndRemoteVisitRatio(eventArgs);
		});

		newRow.find(dteSimNs.remoteVisitRatioSelector).val(tierRow.RemoteVisitRatio).bind("blur change", function (eventArgs) {
			dteSimNs.updateContactFrequency(eventArgs);
			dteSimNs.updateRemoteFrequency(eventArgs);
			dteSimNs.validateOnsiteAndRemoteVisitRatio(eventArgs);
		});

		newRow.find("input[type=text]").bind("change", dteSimNs.updateVisitCount);
		if (tierRow.ContactFrequencyWeeks != null) { newRow.find(dteSimNs.contactFrequencyWeeksSelector).text(tierRow.ContactFrequencyWeeks.toFixed(2) / 1); }

		$(dteSimNs.siteMonitoringTableSelector).append(newRow);
	},
	handlePharmacyResponse: function (pharmacyConfiguration) {
		var atLeastOnePharmacyTierActive = false;
		if (pharmacyConfiguration.TierList.length > 0) {
			$.each(pharmacyConfiguration.TierList, function (index, tierRow) {
				dteSimNs.addPharmacyTierRowToSchemaTable(tierRow);
				if (tierRow.IsTierEnabled) { atLeastOnePharmacyTierActive = true; }
			});
			$(dteSimNs.pharmacyTableSelector).append(dteSimNs.getPharmacyMonitoringSchemaFooterRow());
			$(dteSimNs.pharmacyTableSelector).append(dteSimNs.getPharmacyMonitoringBudgetRow());

			$(dteSimNs.isPharmacyEnabledSelector).prop("checked", atLeastOnePharmacyTierActive);

			setTimeout(function () {
				$(dteSimNs.getPharmacyBudgetedSivCovVisitCountSelector()).text(pharmacyConfiguration.Budget.SivVisitCount + pharmacyConfiguration.Budget.CovVisitCount);
				$(dteSimNs.getPharmacyBudgetedOnsiteImvVisitCountSelector()).text(pharmacyConfiguration.Budget.OnsiteImvVisitCount);
				$(dteSimNs.getPharmacyBufferSelector()).val(pharmacyConfiguration.Budget.OnsiteVisitBuffer);
			}, 10);
			setTimeout(dteSimNs.handlePharmacySchemaVisibility, 10);

		} else {
			$("#DteVisitSchemaLevel").text('No results to display.');
			$(dteSimNs.pharmacyTableSelector).parent().hide();
		}
	},
	addPharmacyTierRowToSchemaTable: function (tierRow) {
		var newRow = $(dteSimNs.pharmacyTierRowTemplateSelector).clone();
		if (tierRow.IsTierEnabled) {
			var projectedNumberOfSites = dteSimNs.calculateProjectedSiteCount(tierRow.TargetSitePercentage, dteSimNs.getProjectedInitiatedSiteCount());
			newRow.find(dteSimNs.projectedNumberOfSitesSelector).text(projectedNumberOfSites.toFixed(0)).attr("rawValue", projectedNumberOfSites);
			newRow.find(dteSimNs.onsiteVisitCountSelector).text(tierRow.OnsiteImvVisitCount);
			newRow.find(dteSimNs.sivCovVisitCountSelector).text(tierRow.SivVisitCount + tierRow.CovVisitCount);
		}
		newRow.attr("TierName", tierRow.TierName);
		newRow.find(dteSimNs.tierNameSelector).text(tierRow.TierName);
		newRow.find(dteSimNs.tierCycleSelector).val(tierRow.TierCycle);

		newRow.find(dteSimNs.cbTierEnabledSelector).prop("checked", tierRow.IsTierInUse || tierRow.IsTierEnabled).attr("allowUncheck", !tierRow.IsTierInUse).click(function () {
			dteSimNs.enableDisableTierRow(this, dteSimNs.pharmacyTableSelector, true);
		});

		newRow.find(dteSimNs.targetSitePercentageSelector).val(tierRow.TargetSitePercentage).bind("keyup paste cut drop", function () {
			dteSimNs.calculateAndShowProjectedNumberOfSites($(this).closest("tr"));
			setTimeout(function () { dteSimNs.updateTableTotals(dteSimNs.pharmacyTableSelector); }, 20);
		});


		newRow.find("input[type=text]").bind("change", dteSimNs.updateVisitCount);
		$(dteSimNs.pharmacyTableSelector).append(newRow);
	},
	getPharmacyMonitoringBudgetRow: function () { return $(dteSimNs.pharmacyBudgetRowTemplateSelector).clone(); },
	getPharmacyMonitoringSchemaFooterRow: function () {
		return $(dteSimNs.pharmacyTotalRowTemplateSelector).clone();
	},
	handlePharmacySchemaVisibility: function () {
		var rowSelector = dteSimNs.pharmacyTableSelector + " tr.pharmacyRow";
		rm.validation.clearError(dteSimNs.getPharmacyTierRowCollectionSelector() + " input.validateRange");
		if ($(dteSimNs.isPharmacyEnabledSelector).is(":checked")) {
			$(rowSelector).show();
			$(dteSimNs.pharmacyBufferTableSelector).show();
		}
		else {
			$(dteSimNs.pharmacyBufferTableSelector).hide();
			$(rowSelector).hide();
			$(rowSelector).find(dteSimNs.clearForDisabledTiersSelector).text("").removeAttr("rawValue");
			$(".tierTotalRow.pharmacyRow [sigmaAnswercolumn=1]").text("");
		}
	},
	handleOnsiteBufferOrBudgetChange: function () {
		dteSimNs.calculateBufferVisitsCountHelper($(dteSimNs.getTotalOnsiteOnsiteVisitCountSelector()),
																						 $(dteSimNs.getSiteMonitoringBudgetedOnsiteImvVisitCountSelector()),
																						 $(dteSimNs.getSiteMonitoringBufferSelector()),
																						 $(dteSimNs.getSiteMonitoringTargetNumberOfBufferVisitsSelector()),
																						 $(dteSimNs.getSiteMonitoringActualBufferSelector()));
	},
	handlePharmacyBufferOrBudgetChange: function () {
		dteSimNs.calculateBufferVisitsCountHelper($(dteSimNs.getGrandTotalPharmacyVisitCountSelector()),
																							 $(dteSimNs.getPharmacyBudgetedOnsiteImvVisitCountSelector()),
																							 $(dteSimNs.getPharmacyBufferSelector()),
																							 $(dteSimNs.getPharmacyTargetNumberOfBufferVisitsSelector()),
																							 $(dteSimNs.getPharmacyActualBufferSelector()));
	},
	calculateBufferVisitsCount: function () {
		dteSimNs.handleOnsiteBufferOrBudgetChange();
		dteSimNs.handlePharmacyBufferOrBudgetChange();
	},
	calculateBufferVisitsCountHelper: function (projectedTotalVisitsControl, budgetedVisitsControl, bufferControl, bufferVisitCountControl, actualBufferControl) {
		var projectedTotalVisits = projectedTotalVisitsControl.text();
		var budgetedVisits = budgetedVisitsControl.val();
		var buffer = bufferControl.val();

		if ($.isNumeric(budgetedVisits)) {
			if ($.isNumeric(buffer)) {
				bufferVisitCountControl.text(Math.round(parseInt(budgetedVisits) * parseInt(buffer) / 100));
			}
			else { bufferVisitCountControl.text(""); }

			if ($.isNumeric(projectedTotalVisits)) {
				var actualBuffer = parseInt(budgetedVisits) - parseInt(projectedTotalVisits);
				actualBufferControl.text(actualBuffer);
				if (actualBuffer <= 0) { actualBufferControl.addClass("overBudget"); }
				else { actualBufferControl.removeClass("overBudget"); }
			}
			else { actualBufferControl.text(""); }
		} else {
			bufferVisitCountControl.text("");
			actualBufferControl.text("");
		}
	},

	showVisitPatternGraphData: function () {
		var postData = dteSimNs.getPostDataForVisitPattern();
		if (postData != null && postData.visitPatternInputData != null && postData.visitPatternInputData.length > 0) {
			rm.ajax.projectSvcAsyncPost("GenerateVisitPatternTableForSimulation", dteSimNs.getPostDataForVisitPattern(), function (data) { $("[id$=staticGraphData]").html(data.Body); });
		}
	},
	getPostDataForVisitPattern: function () {
		var tierList = [];
		var tierConfigList = dteSimNs.getTierConfigForAllValidTiers();

		$.each(tierConfigList, function (index, tierConfig) {
			tierList.push({
				CalculatorTypeId: tierConfig.IsPharmacy ? CalculatorGroup_E.DTEPharmacyCalculator : CalculatorGroup_E.DTEMonitoringCalculator,
				VisitSchemaLevelId: 4,
				TierId: tierConfig.TierName,
				TierCycle: tierConfig.TierCycle,
				TargetPercentage: tierConfig.TargetSitePercentage,
				OnSiteVisitRatio: tierConfig.OnSiteVisitRatio,
				RemoteVisitRatio: tierConfig.RemoteVisitRatio
			});
		});
		return { visitPatternInputData: tierList };
	},
	clearCompletePharmacyVisitPattern: function () {
		for (var tierId = 1; tierId <= 6; tierId++) {
			dteSimNs.clearVisitPatternRow(true, tierId);
		}
	},
	clearVisitPatternRow: function (isPharmacy, tierId) {
		var rowBaseAddress = 3 + (isPharmacy ? 10 : 0);
		var rowAddress = rowBaseAddress + tierId;
		$("[id$=staticGraphData] tr:nth-child(" + rowAddress + ") td:gt(0)").removeClass("noVisitCell osRemoteVisitCell osVisitCell remoteVisitCell").html("<b>&nbsp;</b>").addClass("disabledVisitCell");
	}
};
