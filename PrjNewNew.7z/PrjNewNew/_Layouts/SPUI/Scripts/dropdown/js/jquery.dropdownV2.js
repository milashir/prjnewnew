/**
* DropDown jQuery Plugin v1.2
* 
* Created by Andrew Timney, http://www.andytimney.com
* Modified by SD 
*
*/

(function ($) {

	var methods = {
		init: function (settings) {
			var defaultSettings = {
				items: [],
				ContainerId: "",
				DataKey: "",
				DropDownDivId: "",
				DisplayTextMaxLength: 40,
				image: '/_layouts/SPUI/Scripts/dropdown/images/checkbox.png',
				checkedImage: '/_layouts/SPUI/Scripts/dropdown/images/checked.png',
				optionClickHandler: function () { },
				className: 'dropDownMenu',
				optionClassName: 'optionCheckbox',
				itemClick: function (key, value, isChecked, itemsCollection) { },
				onCollapse: function (itemsCollection) { },
				css: {}
			};

			var mySettings = $.extend(defaultSettings, settings || {});

			var preloadedImage1 = $('<img />').attr('src', mySettings.checkedImage);
			var preloadedImage2 = $('<img />').attr('src', mySettings.image);

			var controlClassName = mySettings.className;
			var controlId = mySettings.className + "_" + this.attr("id");
			var controlIdSelector = "#" + controlId;
			var containerSelector = "#" + mySettings.ContainerId;

			mySettings.DropDownDivId = controlId;

			var optionClassName = mySettings.optionClassName + "_" + this.attr("id");
			var optionClassSelector = "." + controlClassName;

			$(optionClassSelector).unbind('click');
			$(document).unbind('click', $.fn.HideMultiSelectDropdown).click($.fn.HideMultiSelectDropdown);
			$(containerSelector).data("DropDownSettings", mySettings).data(mySettings.DataKey, mySettings.items);

			return this.each(function (i) {
				var button = jQuery(this);
				$(button).unbind('click');
				$.fn.dropdownV2("setDropdownDisplayText", mySettings.items, mySettings.DisplayTextMaxLength, containerSelector);
				$(containerSelector).data("Settings", mySettings);

				$(button).click(function (e) {
					$.fn.HideMultiSelectDropdown(null, mySettings.ContainerId);
					//$("[id!=" + controlId + "][class~=dropDownMenu]").remove()
					if ($(controlIdSelector).size() > 0) {
						$(controlIdSelector).remove();
						mySettings.onCollapse(mySettings.items);
					} else {
						if (mySettings.items && mySettings.items.length) {
							$('<div class="' + controlClassName + '" id="' + controlId + '"></div>').css(mySettings.css).appendTo(containerSelector);
							$(containerSelector).data(mySettings.DataKey, mySettings.items);
							$.each(mySettings.items, function (i, item) {
								var image = mySettings.image;
								if (item.isChecked)
									image = mySettings.checkedImage;
								$('<div class="' + optionClassName + '" id="' + item.key + '" ><img src="' + image + '" alt=" " class="multiSelectCheckBox" />' + item.value + '</div>')
                                .click(function (e) {
                                	var img = $(this).children('img:first');
                                	var isChecked = false;
                                	if (img.attr('src') === mySettings.checkedImage) {
                                		img.attr('src', mySettings.image);
                                	} else {
                                		img.attr('src', mySettings.checkedImage);
                                		isChecked = true;
                                	}
                                	mySettings.itemClick($(this).attr('id'), $(this).text(), isChecked, mySettings.items);
                                	var tmp = $(this).attr('id');
                                	$.each(mySettings.items, function (k, v) {
                                		if (tmp == v.key) v.isChecked = isChecked;
                                	});

                                	$(containerSelector).data(mySettings.DataKey, mySettings.items);
                                	var checkedItemCount = $.fn.dropdownV2("setDropdownDisplayText", mySettings.items, mySettings.DisplayTextMaxLength, containerSelector);
                                	e.stopPropagation(); // to prevent event from bubbling up
                                	$(controlIdSelector).trigger("ItemCheckChanged", [isChecked, checkedItemCount]);
                                	e.preventDefault();
                                })
                                .appendTo(controlIdSelector);
							});
							$(controlIdSelector).show();
						}

						if (mySettings.items && mySettings.items.length > 15) {
							$(controlIdSelector).addClass("multiselectDropDownHeight");
						}
						else {
							$(controlIdSelector).removeClass("multiselectDropDownHeight");
						}
					}
					e.stopPropagation(); // to prevent event from bubbling up
					e.preventDefault();
				});
			});
		},

		setDropdownDisplayText: function (itemArray, displayStringMaxLength, dropdownContainerSelector) {
			var titleString = "";
			var checkedItemCount = 0;
			if (itemArray) {
				$.each(itemArray, function (k, v) {
					if (v.isChecked) {
						titleString += ", " + v.value;
						checkedItemCount++;
					}
				});

				titleString = titleString.replace(", ", "");
			}
			var htmlString = (titleString.length > displayStringMaxLength) ? titleString.substring(0, displayStringMaxLength - 3) + "..." : titleString;
			if (htmlString == "") {
				htmlString = "-- Select all that apply --";
			}
			$(dropdownContainerSelector + " > a > span, " + dropdownContainerSelector + " > a > div").attr("title", titleString).html(htmlString);
			return checkedItemCount;
		},

		isDirty: function (containerId) {
			var isDirty = false;
			var container = $("#" + containerId);
			var settings = container.data("Settings");
			if (settings) {
				var itemsCollection = container.data(settings.DataKey);
				if (itemsCollection) {
					$.each(itemsCollection, function (k, v) {
						if (v.isChecked != v.wasOriginallyChecked) {
							isDirty = true;
							return false;
						}
					});
				}
			}
			return isDirty;
		},

		getSelectedValues: function () {
			var selectedItems = new Array();
			var settings = this.data("Settings");
			if (settings) {
				var data = this.data(settings.DataKey);
				if (data) {
					$.each(data, function (index, item) {
						if (item.isChecked != item.wasOriginallyChecked) {
							selectedItems.push($.extend(item, { dmlOperation: item.isChecked ? DMLOperation_E.Insert : DMLOperation_E.Delete }));
							//	{
							//	key: item.key,
							//	//value: item.value, no need to send text vaues. Uncomment for debugging
							//	isChecked: item.isChecked,
							//	dmlOperation: item.isChecked ? DMLOperation_E.Insert : DMLOperation_E.Delete,
							//	regionId: item.regionId ? item.regionId : null
							//});
						}
					});
				}
			}

			return selectedItems;
		},

		selectItemsByIdArray: function (idsToSelect) {
			var itemCollection = null;
			if (Array.isArray(idsToSelect)) {
				var settings = this.data("Settings");
				var containerSelector = "#" + settings.ContainerId;
				var controlId = settings.className + "_" + this.attr("id");
				var controlIdSelector = "#" + controlId;

				if (settings) {
					var isChecked = false;
					itemCollection = settings.items;
					for (var index = 0; index < idsToSelect.length; index++) {
						var matchingItem = settings.items.find(function (item) { return item.key == idsToSelect[index].key; });
						if (matchingItem) {
							matchingItem.isChecked = true;
							isChecked = true;
						}
					}
					var checkedItemCount = $.fn.dropdownV2("setDropdownDisplayText", settings.items, settings.DisplayTextMaxLength, containerSelector);
					$(controlIdSelector).trigger("ItemCheckChanged", [isChecked, checkedItemCount]);
				}
			}
			return itemCollection;
		}
	}

	$.fn.HideMultiSelectDropdown = function (event, controlId) {
		$.each($(".dropDownMenu"), function (index, ele) {
			var element = $(ele).parent();
			if (element.attr("id") != controlId) {
				var settings = element.data("DropDownSettings");
				if (settings && settings.onCollapse) {
					settings.onCollapse(element.data(settings.DataKey));
				}
				$("#" + settings.DropDownDivId).remove();
			}
		});

	};
	//Public access method that takes either a method + parameters or just the options to init the plugin
	$.fn.dropdownV2 = function (method) {
		if (methods[method]) {
			//Call one of the methods
			return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
		} else if (typeof method === 'object' || !method) {
			//Initialize the plugin
			return methods.init.apply(this, arguments);
		} else {
			$.error('Method ' + method + ' does not exist on jQuery.dropdownV2');
		}
	};
})(jQuery);