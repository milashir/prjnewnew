/*
 * DropDown Tests
 * What do I want to test
 * 1. That the dropdown displays
 */
module('DropDown');

var $testDiv;

test('DropDown does not display when plugin activated', function(){
	
	$testDiv = $('#qunit-fixture');
	
	$testDiv.dropdown();
	
	ok(!$('.dropDownMenu').length, 'DropDown menu should not display when not activated');
	
	$testDiv.unbind('click');
});

test('DropDown displays on click event', function(){
	
	$testDiv = $('#qunit-fixture');
	
	$testDiv.dropdown({
		items : [{ key:'1', value:'Option 1', isChecked: true }]
	});
	$testDiv.trigger('click');
	
	ok($('.dropDownMenu').length, 'DropDown menu should display');
		
	$('.dropDownMenu').remove();
	$testDiv.unbind('click');
});

test('DropDown should not display when no items', function(){
	
	$testDiv = $('#qunit-fixture');
	
	$testDiv.dropdown();
	$testDiv.trigger('click');
	
	ok(!$('.dropDownMenu').length, 'DropDown menu should not display when no items');
		
	$('.dropDownMenu').remove();
	$testDiv.unbind('click');
});

test('DropDown is removed on second click', function(){
	
	$testDiv = $('#qunit-fixture');
	
	$testDiv.dropdown({
		items : [{ key:'1', value:'Option 1', isChecked: true }]
	});
	$testDiv.trigger('click');

	ok($('.dropDownMenu').length, 'DropDown menu should display');
	
	$testDiv.trigger('click');
	
	ok(!$('.dropDownMenu').length, 'DropDown menu should be removed');
	
	$testDiv.unbind('click');
});

module('Options');

test('Options are shown when drop down displayed', function(){
	
	$testDiv = $('#qunit-fixture');
	
	$testDiv.dropdown({
		items : [{ key:'1', value:'Option 1', isChecked: true }]
	});
	$testDiv.trigger('click');
	
	ok($('.optionCheckbox').length, 'Option should display when dropdown activated');
	
	$('.dropDownMenu').remove();
	$testDiv.unbind('click');
});

test('Correct number of options displayed', function(){
	
	$testDiv = $('#qunit-fixture');
	
	$testDiv.dropdown({
		items : [{ key:'1', value:'Option 1', isChecked: true }, { key:'2', value:'Option 2', isChecked: true }]
	});
	$testDiv.trigger('click');
	
	equals(2, $('.optionCheckbox').length, '2 options should be shown');
	
	$('.dropDownMenu').remove();
	$testDiv.unbind('click');
});

test('Options shown in correct order', function(){
	
	$testDiv = $('#qunit-fixture');
	
	$testDiv.dropdown({
		items : [{ key:'1', value:'Option 1', isChecked: false }, { key:'2', value:'Option 2', isChecked: true }]
	});
	$testDiv.trigger('click');
	
	var $option = $('.optionCheckbox').eq(1);
	var $img = $option.children('img:first');
	
	equals('2', $option.attr('id'), 'Id should match item key');
	
	$('.dropDownMenu').remove();
	$testDiv.unbind('click');
});

test('All options attr are correct', function(){
	
	$testDiv = $('#qunit-fixture');
	
	$testDiv.dropdown({
		items : [{ key:'1', value:'Option 1', isChecked: false }, { key:'2', value:'Option 2', isChecked: true }]
	});
	$testDiv.trigger('click');
	
	var $option = $('.optionCheckbox').eq(1);
	var $img = $option.children('img:first');
	
	equals('Option 2', $option.text(), 'Text should match item value');
	equals('/_layouts/SPUI/Scripts/dropdown/images/checked.png', $img.attr('src'), 'Image src should be checked image');
	
	$('.dropDownMenu').remove();
	$testDiv.unbind('click');
});

test('Option was checked/unchecked', function(){
	
	$testDiv = $('#qunit-fixture');
	
	var Key, Value, IsChecked;
	
	$testDiv.dropdown({
		items : [{ key:'1', value:'Option 1', isChecked: false }, { key:'2', value:'Option 2', isChecked: true }],
		itemClick : function(key, value, isChecked){
			Key = key;
			Value = value;
			IsChecked = isChecked;
		}
	});
	
	$testDiv.trigger('click');
	
	var $option = $('.optionCheckbox').eq(0);
	$option.trigger('click');
	
	equals('1', Key, 'Key should match');
	equals('Option 1', Value, 'Value should match');
	equals(true, IsChecked, 'isChecked should match');
	
	$option.trigger('click');
	
	equals(false, IsChecked, 'isChecked should match');
	
	$('.dropDownMenu').remove();
	$testDiv.unbind('click');
});
