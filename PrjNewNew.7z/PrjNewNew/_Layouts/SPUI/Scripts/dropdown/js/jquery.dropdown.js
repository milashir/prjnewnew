/**
 * DropDown jQuery Plugin v1.2
 * 
 * Created by Andrew Timney, http://www.andytimney.com
 * 
 *
 */

jQuery(function ()
{
	jQuery.fn.dropdown = function (options)
	{
		var opts = jQuery.extend({}, jQuery.fn.dropdown.defaults, options);

		var img = new Image();
		img.src = opts.image;
		img.src = opts.checkedImage;

		jQuery('.' + opts.optionClassName + opts.controlId).unbind('click');
		//jQuery('.' + opts.optionClassName + opts.controlId).die('click');

		return this.each(function (i)
		{
			var button = jQuery(this);
			jQuery(button).unbind('click');
			jQuery(button).click(function (e)
			{
				var offset = jQuery(this).parent().offset();
				var top = offset.top + opts.positionOffset;

				if (jQuery('.' + opts.className + opts.controlId).size() > 0)
				{
					jQuery('.' + opts.className + opts.controlId).remove();
				} else
				{
					if (opts.items.length)
					{
						//jQuery('.' + opts.optionClassName + opts.controlId).die('click');
						//jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: top, left: offset.left }).appendTo('.initiateFieldAssignedRegionList');
						jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: 200, left: 190 }).appendTo('.initiateFieldAssignedRegionList');

						jQuery.each(opts.items, function (i, item)
						{
							var image = opts.image;
							if (item.isChecked)
								image = opts.checkedImage;
							jQuery('<div class="' + opts.optionClassName + opts.controlId + '" id="' + item.key + '" ><img src="' + image + '" alt="checkbox" />' + item.value + '</div>')
									.click(function ()
									{
										var img = jQuery(this).children('img:first');
										var isChecked = false;
										if (img.attr('src') === opts.checkedImage)
										{
											img.attr('src', opts.image);
										} else
										{
											img.attr('src', opts.checkedImage);
											isChecked = true;
											rm.validation.clearError($("#span" + opts.controlId));
											rm.qtip.clear("#span" + opts.controlId);
										}
										opts.itemClick(jQuery(this).attr('id'), jQuery(this).text(), isChecked);
										var tmp = jQuery(this).attr('id');
										jQuery.each(opts.items, function (k, v)
										{
											if (tmp == v.key) v.isChecked = isChecked;
										});
										e.preventDefault();
										e.stopPropagation(); // to prevent event from bubbling up
									})
									.appendTo('.' + opts.className + opts.controlId);
						});
						jQuery('.' + opts.className + opts.controlId).show();
					}
					//AI: to set scroll bar if there are more than 15 items.
					if (opts.items.length > 15)
					{
						jQuery('.' + opts.className + opts.controlId).addClass("multiselectHeight");
					}
					else
					{
						jQuery('.' + opts.className + opts.controlId).removeClass("multiselectHeight");
					}
				}
				e.stopPropagation(); // to prevent event from bubbling up
				e.preventDefault();
			});
		});
	};

	jQuery.fn.dropdown.defaults = {
		items: [],
		image: '/_layouts/SPUI/Scripts/dropdown/images/checkbox.png',
		checkedImage: '/_layouts/SPUI/Scripts/dropdown/images/checked.png',
		positionOffset: 20,
		className: 'dropDownMenu',
		optionClassName: 'optionCheckbox',
		controlId: "id",
		itemClick: function (key, value, isChecked) { }
	};

	jQuery.fn.dropdownCountry = function (options)
	{

		var opts = jQuery.extend({}, jQuery.fn.dropdownCountry.defaults, options);

		var img = new Image();
		img.src = opts.image;
		img.src = opts.checkedImage;
		jQuery('.' + opts.optionClassName + opts.controlId).unbind('click');
		//jQuery('.' + opts.optionClassName + opts.controlId).die('click');

		return this.each(function (i)
		{
			var button = jQuery(this);
			jQuery(button).unbind('click');
			jQuery(button).click(function (e)
			{
				var offset = jQuery(this).parent().offset();
				var top = offset.top + opts.positionOffset;

				//if (jQuery('.' + opts.className + opts.controlId).size() > 0)
				//{
				//  jQuery('.' + opts.className + opts.controlId).remove();
				//} else
				//{
				jQuery('.' + opts.className + opts.controlId).remove();
				if (opts.items.length)
				{
					//jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: top, left: offset.left }).appendTo('body');
					jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: 225, left: 190 }).appendTo('.initiateFieldAssignedRegionList');

					jQuery.each(opts.items, function (i, item)
					{
						var image = opts.image;
						if (item.isChecked)
							image = opts.checkedImage;
						jQuery('<div class="' + opts.optionClassName + opts.controlId + '" id="' + item.key + '" region="' + item.regionId + '"><img src="' + image + '" alt="checkbox" />' + item.value + '</div>')
										.click(function ()
										{
											var img = jQuery(this).children('img:first');
											var isChecked = false;
											if (img.attr('src') === opts.checkedImage)
											{
												img.attr('src', opts.image);
											} else
											{
												img.attr('src', opts.checkedImage);
												isChecked = true;
												rm.validation.clearError($("#span" + opts.controlId));
												rm.qtip.clear("#span" + opts.controlId);
											}
											opts.itemClick(jQuery(this).attr('id'), jQuery(this).text(), isChecked, item.regionId);
											var tmp = jQuery(this).attr('id');
											jQuery.each(opts.items, function (k, v)
											{
												if (tmp == v.key) v.isChecked = isChecked;
											});

											e.preventDefault();
											e.stopPropagation(); // to prevent event from bubbling up
										})
										.appendTo('.' + opts.className + opts.controlId);
					});

					// set check box if already country already selected.
					var arrarCountry = $.InitiateRequest._countryIds.split('|');
					for (var i = 0; i < arrarCountry.length; i++)
					{
						jQuery.each(opts.items, function (j, item)
						{
							var img = jQuery("#" + item.key).children('img:first');
							if (item.key == arrarCountry[i])
							{
								item.isChecked = true;
								img.attr('src', opts.checkedImage);
								return;
							}
							//else
							//{
							//  item.isChecked = false;
							//  img.attr('src', opts.image);
							//}
						});
					}

					//                    // set title & display all contry saperated by comma
					//                    var displayCountryList = "";
					//                    jQuery.each(opts.items, function (j, item)
					//                    {
					//                        if (item.isChecked)
					//                        {
					//                            if (displayCountryList != "")
					//                            {
					//                                displayCountryList += ", ";
					//                            }

					//                            displayCountryList += item.value;
					//                        }
					//                    });

					//                    if (displayCountryList == "")
					//                    {
					//                        displayCountryList = "--Select--";
					//                    }
					//                    
					//                    $("#spanAssignedCountryList").html(displayCountryList);
					//                    $("#spanAssignedCountryList").attr("title", displayCountryList);

					jQuery('.' + opts.className + opts.controlId).show();
				}
				//AI: to set scroll bar if there are more than 15 items.
				if (opts.items.length > 15)
				{
					jQuery('.' + opts.className + opts.controlId).addClass("multiselectHeight");
				}
				else
				{
					jQuery('.' + opts.className + opts.controlId).removeClass("multiselectHeight");
				}
				//} // end else
				e.stopPropagation(); // to prevent event from bubbling up
				e.preventDefault();
			});
		});
	};

	jQuery.fn.dropdownCountry.defaults = {
		items: [],
		image: '/_layouts/SPUI/Scripts/dropdown/images/checkbox.png',
		checkedImage: '/_layouts/SPUI/Scripts/dropdown/images/checked.png',
		positionOffset: 20,
		className: 'dropDownMenu',
		optionClassName: 'optionCheckbox',
		controlId: "id",
		itemClick: function (key, value, isChecked, regionId) { }
	};

	//Added by Shamanth:dont use above function as it is dependent on some hardcoded variables :: create your own func's
	jQuery.fn.uRegionList = function (options)
	{
		var opts = jQuery.extend({}, jQuery.fn.uRegionList.defaults, options);

		var img = new Image();
		img.src = opts.image;
		img.src = opts.checkedImage;

		jQuery('.' + opts.optionClassName + opts.controlId).unbind('click');
		//jQuery('.' + opts.optionClassName + opts.controlId).die('click');

		return this.each(function (i)
		{
			var button = jQuery(this);
			jQuery(button).unbind('click');
			jQuery(button).click(function (e)
			{
				var offset = jQuery(this).parent().offset();
				var top = offset.top + opts.positionOffset;

				if (jQuery('.' + opts.className + opts.controlId).size() > 0)
				{
					jQuery('.' + opts.className + opts.controlId).remove();
				} else
				{
					if (opts.items.length)
					{
						//jQuery('.' + opts.optionClassName + opts.controlId).die('click');
						//jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: top, left: offset.left }).appendTo('.initiateFieldAssignedRegionList');
						jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: 200, left: 190 }).appendTo('.initiateFieldAssignedRegionList');

						jQuery.each(opts.items, function (i, item)
						{
							var image = opts.image;
							if (item.isChecked)
								image = opts.checkedImage;
							jQuery('<div class="' + opts.optionClassName + opts.controlId + '" id="' + item.key + '" ><img src="' + image + '" alt="checkbox" />' + item.value + '</div>')
									.click(function ()
									{
										var img = jQuery(this).children('img:first');
										var isChecked = false;
										if (img.attr('src') === opts.checkedImage)
										{
											img.attr('src', opts.image);
										} else
										{
											img.attr('src', opts.checkedImage);
											isChecked = true;
											rm.validation.clearError($("#span" + opts.controlId));
											rm.qtip.clear("#span" + opts.controlId);
										}
										opts.itemClick(jQuery(this).attr('id'), jQuery(this).text(), isChecked);
										var tmp = jQuery(this).attr('id');
										jQuery.each(opts.items, function (k, v)
										{
											if (tmp == v.key) v.isChecked = isChecked;
										});
										e.preventDefault();
										e.stopPropagation(); // to prevent event from bubbling up
									})
									.appendTo('.' + opts.className + opts.controlId);
						});
						jQuery('.' + opts.className + opts.controlId).show();
					}
					//AI: to set scroll bar if there are more than 15 items.
					if (opts.items.length > 15)
					{
						jQuery('.' + opts.className + opts.controlId).addClass("multiselectHeight");
					}
					else
					{
						jQuery('.' + opts.className + opts.controlId).removeClass("multiselectHeight");
					}
				}
				e.stopPropagation(); // to prevent event from bubbling up
				e.preventDefault();
			});
		});
	};

	jQuery.fn.uRegionList.defaults = {
		items: [],
		image: '/_layouts/SPUI/Scripts/dropdown/images/checkbox.png',
		checkedImage: '/_layouts/SPUI/Scripts/dropdown/images/checked.png',
		positionOffset: 20,
		className: 'dropDownMenu',
		optionClassName: 'optionCheckbox',
		controlId: "id",
		itemClick: function (key, value, isChecked) { }
	};

	jQuery.fn.uCountryList = function (options)
	{

		var opts = jQuery.extend({}, jQuery.fn.uCountryList.defaults, options);

		var img = new Image();
		img.src = opts.image;
		img.src = opts.checkedImage;
		jQuery('.' + opts.optionClassName + opts.controlId).unbind('click');
		//jQuery('.' + opts.optionClassName + opts.controlId).die('click');

		return this.each(function (i)
		{
			var button = jQuery(this);
			jQuery(button).unbind('click');
			jQuery(button).click(function (e)
			{
				var offset = jQuery(this).parent().offset();
				var top = offset.top + opts.positionOffset;

				//if (jQuery('.' + opts.className + opts.controlId).size() > 0)
				//{
				//  jQuery('.' + opts.className + opts.controlId).remove();
				//} else
				//{
				jQuery('.' + opts.className + opts.controlId).remove();
				if (opts.items.length)
				{
					//jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: top, left: offset.left }).appendTo('body');
					jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: 225, left: 190 }).appendTo('.initiateFieldAssignedCountryList');

					jQuery.each(opts.items, function (i, item)
					{
						var image = opts.image;
						if (item.isChecked)
							image = opts.checkedImage;
						jQuery('<div class="' + opts.optionClassName + opts.controlId + '" id="' + item.key + '" region="' + item.regionId + '"><img src="' + image + '" alt="checkbox" />' + item.value + '</div>')
										.click(function ()
										{
											var img = jQuery(this).children('img:first');
											var isChecked = false;
											if (img.attr('src') === opts.checkedImage)
											{
												img.attr('src', opts.image);
											} else
											{
												img.attr('src', opts.checkedImage);
												isChecked = true;
												rm.validation.clearError($("#span" + opts.controlId));
												rm.qtip.clear("#span" + opts.controlId);
											}
											opts.itemClick(jQuery(this).attr('id'), jQuery(this).text(), isChecked, item.regionId, item.subregionId);
											var tmp = jQuery(this).attr('id');
											jQuery.each(opts.items, function (k, v)
											{
												if (tmp == v.key) v.isChecked = isChecked;
											});

											e.preventDefault();
											e.stopPropagation(); // to prevent event from bubbling up
										})
										.appendTo('.' + opts.className + opts.controlId);
					});

					// set check box if already country already selected.
					var arrarCountry = $.Utilization._countryIds.split('|');
					for (var i = 0; i < arrarCountry.length; i++)
					{
						jQuery.each(opts.items, function (j, item)
						{
							var img = jQuery("#" + item.key).children('img:first');
							if (item.key == arrarCountry[i])
							{
								item.isChecked = true;
								img.attr('src', opts.checkedImage);
								return;
							}
							//else
							//{
							//  item.isChecked = false;
							//  img.attr('src', opts.image);
							//}
						});
					}
					//$("#spanAssignedCountryList").attr("title", displayCountryList);
					jQuery('.' + opts.className + opts.controlId).show();
				}
				//AI: to set scroll bar if there are more than 15 items.
				if (opts.items.length > 15)
				{
					jQuery('.' + opts.className + opts.controlId).addClass("multiselectHeight");
				}
				else
				{
					jQuery('.' + opts.className + opts.controlId).removeClass("multiselectHeight");
				}
				//} // end else
				e.stopPropagation(); // to prevent event from bubbling up
				e.preventDefault();
			});
		});
	};

	jQuery.fn.uCountryList.defaults = {
		items: [],
		image: '/_layouts/SPUI/Scripts/dropdown/images/checkbox.png',
		checkedImage: '/_layouts/SPUI/Scripts/dropdown/images/checked.png',
		positionOffset: 20,
		className: 'dropDownMenu',
		optionClassName: 'optionCheckbox',
		controlId: "id",
		itemClick: function (key, value, isChecked, regionId, subregionId) { }
	};

	jQuery.fn.uSubregionList = function (options)
	{

		var opts = jQuery.extend({}, jQuery.fn.uSubregionList.defaults, options);

		var img = new Image();
		img.src = opts.image;
		img.src = opts.checkedImage;
		jQuery('.' + opts.optionClassName + opts.controlId).unbind('click');

		return this.each(function (i)
		{
			var button = jQuery(this);
			jQuery(button).unbind('click');
			jQuery(button).click(function (e)
			{
				var offset = jQuery(this).parent().offset();
				var top = offset.top + opts.positionOffset;

				if (jQuery('.' + opts.className + opts.controlId).size() > 0)
				{
					jQuery('.' + opts.className + opts.controlId).remove();
				} else
				{
					if (opts.items.length)
					{
						jQuery('<div class="' + opts.className + opts.controlId + '"></div>').css({ top: 225, left: 190 }).appendTo('.initiateFieldAssignedSubregionList');

						jQuery.each(opts.items, function (i, item)
						{
							var image = opts.image;
							if (item.isChecked)
								image = opts.checkedImage;
							jQuery('<div class="' + opts.optionClassName + opts.controlId + '" id="' + item.key + '" region="' + item.regionId + '"><img src="' + image + '" alt="checkbox" />' + item.value + '</div>')
											.click(function ()
											{
												var img = jQuery(this).children('img:first');
												var isChecked = false;
												if (img.attr('src') === opts.checkedImage)
												{
													img.attr('src', opts.image);
												} else
												{
													img.attr('src', opts.checkedImage);
													isChecked = true;
													rm.validation.clearError($("#span" + opts.controlId));
													rm.qtip.clear("#span" + opts.controlId);
												}
												opts.itemClick(jQuery(this).attr('id'), jQuery(this).text(), isChecked, item.regionId);
												var tmp = jQuery(this).attr('id');
												jQuery.each(opts.items, function (k, v)
												{
													if (tmp == v.key) v.isChecked = isChecked;
												});

												e.preventDefault();
												e.stopPropagation(); // to prevent event from bubbling up
											})
											.appendTo('.' + opts.className + opts.controlId);
						});

						//set check box if already subregion selected.
						var arrarCountry = $.Utilization._subRegionIds.split('|');
						for (var i = 0; i < arrarCountry.length; i++)
						{
							jQuery.each(opts.items, function (j, item)
							{
								var img = jQuery("#" + item.key).children('img:first');
								if (item.key == arrarCountry[i])
								{
									item.isChecked = true;
									img.attr('src', opts.checkedImage);
									return;
								}
							});
						}
						jQuery('.' + opts.className + opts.controlId).show();
					}
					//AI: to set scroll bar if there are more than 15 items.
					if (opts.items.length > 15)
					{
						jQuery('.' + opts.className + opts.controlId).addClass("multiselectHeight");
					}
					else
					{
						jQuery('.' + opts.className + opts.controlId).removeClass("multiselectHeight");
					}
				}
				e.stopPropagation(); // to prevent event from bubbling up
				e.preventDefault();
			});
		});
	};

	jQuery.fn.uSubregionList.defaults = {
		items: [],
		image: '/_layouts/SPUI/Scripts/dropdown/images/checkbox.png',
		checkedImage: '/_layouts/SPUI/Scripts/dropdown/images/checked.png',
		positionOffset: 20,
		className: 'dropDownMenu',
		optionClassName: 'optionCheckbox',
		controlId: "id",
		itemClick: function (key, value, isChecked, regionId) { }
	};
});