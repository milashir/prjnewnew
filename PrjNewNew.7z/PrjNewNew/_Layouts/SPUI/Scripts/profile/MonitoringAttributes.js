﻿/// <reference path="../common/rmhelper.js" />
$(document).ready(function () {
	if (!maNs.isProjectSelected()) { return false; }

	if ($("[id$=UndefinedSchemaProject]").val() == "1") {
		rm.ui.messages.addError('The Visit Schema is undefined for project ' + maNs.getProjectName() + '. Please update the Visit Schema for this project in QRPM: PPM.');
		return false;
	}
	if ($("[id$=UndefinedDTEProjectFlag]").val() == "1") {
		rm.ui.messages.addError('The RBM flag is undefined for project ' + maNs.getProjectName() + ' - ' + GetCurrentProjectCodeProtocolNumber() + '. Please update the \'Is this a RBM Study\' field from the PPM/Project Background Page');
		return false;
	}
	$("#tblMaSummary").show();
	maNs.handleTotalProjectedIntiatedSitesErrorVisibility($("td[id$=TotalBudgetedSites]").text() * 1, $("td[id$=TotalProjectedInitiatedSites]").text() * 1);

	maNs.buildGrid();
	//$("#gview_list .ui-jqgrid-htable tr:nth(0) th").resize(maNs.alignSummaryTableColumns);
	window.onbeforeunload = function () {
		if (maNs.hasRowsInEditMode()) {
			return confirm("Are you sure you want to leave without saving your changes?");
		}
	};
	rm.grid.bindEventsToResizeGrid("#list");
	//handle qip refresh complete event to show latest qip version on UI
	$(document).on(rm.events.onBudgetRefreshComplete, function (event, latestQipVersion) {
		$("[id$=lblQipVersion]").text(latestQipVersion);
		rm.grid.reloadGrid(maNs.gridSelector);
		maNs.updateSummaryRow();
	});
	maNs.showNonRbmToRbmConversionWarning();
});

var maNs = {
	gridSelector: "#list",
	frozenColumnAlreadyBound: false,
	columnModelUsedByGrid: null,
	cookieName: "monitoringAttributesSearchCriteria",
	getProjectName: function () { return GetCurrentProjectName(); },
	isProjectSelected: function () { return maNs.getProjectName() != ""; },
	getProjectId: function () { return $("[id$=hdnProjectId]").val(); },
	handleFteIconClick: function () {
		maNs.openEditAttributePage($(this).attr("entityId"));
	},
	modifySingleAttribute: function () {
		if (rm.grid.hasSingleRowSelected(maNs.gridSelector)) {
			maNs.openEditAttributePage(rm.grid.getSelectedIdArray(maNs.gridSelector)[0]);
		}
	},
	openEditAttributePage: function (attributeId) {
		if (maNs.allowEdit()) {
			rm.grid.rememberGridFilterCriteria(maNs.gridSelector, maNs.cookieName);
			document.location.href = "/_layouts/SPUI/Calculator/EditCalculator.aspx?source=monattr&entityId=" + attributeId;
		}
	},
	getFteIconColumnDefinitionForGrid: function () {
		return {
			name: 'FTE', index: 'FTE', label: 'FTE', sortable: false, align: 'center', width: 35, search: false, formatter: function (cellValue, options, rowObject) {
				return "<img class= 'fteIcon' src='/_layouts/SPUI/images/CalculatorIcon.gif' title='Country Monitoring FTE Calculator' entityId=" + options.rowId + (maNs.allowEdit() ? " style='cursor: pointer;' " : "") + " />";
			}
		};
	},
	allowEdit: function () { return $("[id$=hdnAllowEdit]").val() === "1"; },
	showNonRbmToRbmConversionWarning: function () {
		if ($("[id$=hdnIsRbmProjectManagedAsNonRbmInRm]").val() === "1") { rm.ui.messages.showWarningWithCloseButton(Resources.NonRbmToRbmConversion); }
	},
	hasRowsInEditMode: function () { return rm.grid.hasRowsInEditMode(maNs.gridSelector); },
	isCancelEnabled: function () { return maNs.hasRowsInEditMode(); },
	isSaveEnabled: function () { return maNs.hasRowsInEditMode(); },
	editMultipleAttributes: {
		modifyAttributeRibbonControlId: '#Ribbon_ProjectSummaryRibbon_GridActions_EditSingleRow',
		modifyAttributesRibbonControlId: '#Ribbon_ProjectSummaryRibbon_GridActions_EditMultipleRow'
	},
	isModifySingleAttributeEnabled: function () {
		if (!rm.grid.hasRowsSelected(maNs.gridSelector)) {
			$(maNs.editMultipleAttributes.modifyAttributesRibbonControlId).hide();
			$(maNs.editMultipleAttributes.modifyAttributeRibbonControlId).show();
		}
		return rm.grid.hasSingleRowSelected(maNs.gridSelector);
	},
	isModifyMultipleAttributesEnabled: function () {
		var selectedrows = rm.grid.getSelectedIdArray(maNs.gridSelector);
		var isEnabled = true;
		if (selectedrows && selectedrows.length > 1) {
			$(maNs.editMultipleAttributes.modifyAttributesRibbonControlId).show();
			$(maNs.editMultipleAttributes.modifyAttributeRibbonControlId).hide();

			for (var i = 0; i < selectedrows.length; i++) {
				var rowJson = rm.grid.rowData.getById(maNs.gridSelector, selectedrows[i]);
				if (rowJson.Country == rmConstants.JapanCountryName) {
					isEnabled = false;
					break;
				}
			}
		}
		else {
			$(maNs.editMultipleAttributes.modifyAttributesRibbonControlId).hide();
			$(maNs.editMultipleAttributes.modifyAttributeRibbonControlId).show();
			isEnabled = false;
		}

		return isEnabled;
	},
	freezeColumnsAndBindInfo: function () {
		if (!maNs.frozenColumnAlreadyBound) {
			maNs.frozenColumnAlreadyBound = true;
			//freezing columns involve rebuilding the grid. Once grid is rebuilt, we need to rebing the information qtip.
			rm.grid.delayedRebindFrozenColumns(maNs.gridSelector);
			setTimeout(maNs.bindLabelQtip, 100);
		}
		rm.grid.scrollTableBodyToFixAlignmentIssue(maNs.gridSelector);
	},
	copyBudgetedSitesToProjectedInitiatedSites: function () {
		var btnOk = { text: "Continue", click: function () { $(this).dialog("close"); maNs.copyBudgetedSitesToProjectedInitiatedSitesAjaxCall(); } }
		rm.ui.dialog.showModalWithButtonsAndCloseHandler("#divCopySitesConfirmDialog", "Copy 'Budgeted Sites' to 'Projected Initiated Sites'", "", false, 500, 300, [btnOk, rm.ui.dialog.standardButtons.cancel], null, function () {
			setTimeout(function () { $(document).find('.ui-dialog-buttonpane button:eq(1)').focus(); }, 10);
		});
	},
	copyBudgetedSitesToProjectedInitiatedSitesAjaxCall: function () {
		rm.ajax.attributeSvcSyncPost("CopyBudgetedSitesToProjectedInitiatedSites", { projectId: maNs.getProjectId() }, function () {
			rm.grid.reloadGrid(maNs.gridSelector);
		});
	},
	isCopyBudgetedSitesToProjectedInitiatedSitesEnabled: function () { return true; },
	modifyMultipleAttributes: function () {
		rm.grid.rememberGridFilterCriteria(maNs.gridSelector, maNs.cookieName);

		$("#selectedEntityIds").val(rm.grid.getSelectedIds(maNs.gridSelector));
		var action = "/_layouts/SPUI/Calculator/RedirectToEditMultipleCalculators.aspx?source=monattr";
		$("#aspnetForm").attr("action", action);
		$("#aspnetForm").submit();
	},
	saveGrid: function () {
		rm.ui.messages.clearAllMessages();

		var rowsToSave = [];
		var rowsInEditMode = rm.grid.getRowsInEditMode(maNs.gridSelector);

		$.each(rowsInEditMode, function (index, editedRow) {
			var projInitSites = $(rm.grid.getControlFromEditRow(maNs.gridSelector, editedRow.id, "ProjectedInitiatedSites"));
			var craDate = $(rm.grid.getControlFromEditRow(maNs.gridSelector, editedRow.id, "CRADate"));
			var imDate = $(rm.grid.getControlFromEditRow(maNs.gridSelector, editedRow.id, "IMDate"));


			var qipBudgetedSites = $(rm.grid.getControlFromEditRow(maNs.gridSelector, editedRow.id, "QipBudgetedSites"));
			var qipBudgetedOnsiteImvVisitCount = $(rm.grid.getControlFromEditRow(maNs.gridSelector, editedRow.id, "QipBudgetedOnsiteImvVisitCount"));
			var qipBudgetedRemoteVisitCount = $(rm.grid.getControlFromEditRow(maNs.gridSelector, editedRow.id, "QipBudgetedRemoteVisitCount"));
			var qipBudgetedPharmacyVisitCount = $(rm.grid.getControlFromEditRow(maNs.gridSelector, editedRow.id, "QipBudgetedPharmacyVisitCount"));

			//if (rm.validation.range.validate(projInitSites) && rm.date.isValidDate(imDate.val(), true) && rm.date.isValidDate(craDate.val(), true)) {
			if (rm.date.isValidDate(imDate.val(), true) &&
				rm.date.isValidDate(craDate.val(), true) &&
				rm.validation.range.validate(qipBudgetedSites) &&
				rm.validation.range.validate(qipBudgetedOnsiteImvVisitCount) &&
				rm.validation.range.validate(qipBudgetedRemoteVisitCount) &&
				rm.validation.range.validate(qipBudgetedPharmacyVisitCount)) {
				rowsToSave.push(rm.grid.getUpdatedRowDataById(maNs.gridSelector, editedRow.id));
			}
			else {
				rm.ui.messages.showError("Please fix the errors and click Save again. Page will attempt to save the records with valid data.");
			}
		});

		if (rowsToSave.length > 0) {
			maNs.saveData(rowsToSave, rowsInEditMode.length);
		}
	},
	saveSingleAttribute: function (gridSelector, rowId) {
		rm.ui.messages.clearAllMessages();
		//var projInitSites = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "ProjectedInitiatedSites"));
		var craDate = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "CRADate"));
		var imDate = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "IMDate"));

		var qipBudgetedSites = $(rm.grid.getControlFromEditRow(maNs.gridSelector, rowId, "QipBudgetedSites"));
		var qipBudgetedOnsiteImvVisitCount = $(rm.grid.getControlFromEditRow(maNs.gridSelector, rowId, "QipBudgetedOnsiteImvVisitCount"));
		var qipBudgetedRemoteVisitCount = $(rm.grid.getControlFromEditRow(maNs.gridSelector, rowId, "QipBudgetedRemoteVisitCount"));
		var qipBudgetedPharmacyVisitCount = $(rm.grid.getControlFromEditRow(maNs.gridSelector, rowId, "QipBudgetedPharmacyVisitCount"));
		var budgetedBoosterVisitCount = $(rm.grid.getControlFromEditRow(maNs.gridSelector, rowId, "BudgetedBoosterVisitCount"));


		//if (rm.validation.range.validate(projInitSites) && rm.date.isValidDate(imDate.val(), true) && rm.date.isValidDate(craDate.val(), true)) {
		if (rm.date.isValidDate(imDate.val(), true) &&
			rm.date.isValidDate(craDate.val(), true) &&
			rm.validation.range.validate(qipBudgetedSites) &&
			rm.validation.range.validate(qipBudgetedOnsiteImvVisitCount) &&
			rm.validation.range.validate(qipBudgetedRemoteVisitCount) &&
			rm.validation.range.validate(qipBudgetedPharmacyVisitCount) &&
			rm.validation.range.validate(budgetedBoosterVisitCount)) {
			var rowToSave = rm.grid.getUpdatedRowDataById(gridSelector, rowId);
			maNs.saveData([rowToSave], 1);
		}
		else {
			rm.ui.messages.addError("Please fix the errors and click Save again.");
		}
	},
	saveData: function (rowsToSave, totalRowsInEditMode) {
		if (rowsToSave.length > 0) {
			rm.ajax.attributeSvcAsyncPost("SaveMonitoringAttributes", { projectId: maNs.getProjectId(), monAttributeDataList: rowsToSave }, function (serviceResponse) {
				var successCount = 0;
				$.each(serviceResponse.EntityStatus, function (index, response) {
					if (response.IsSuccessful) {
						successCount++;
						rm.grid.cancelRowEditMode(maNs.gridSelector, response.EntityId);
						//Give it a split second so the row can go back to read-only mode
						setTimeout(function () {
							//$(maNs.gridSelector).setCell(response.EntityId, "ProjectedInitiatedSites", response.Output.ProjectedInitiatedSites, "", "", true);
							//$(maNs.gridSelector).setCell(response.EntityId, "ProjectedVisits", response.Output.ProjectedVisits, "", "", true);
							var rowData = rm.grid.rowData.getById(maNs.gridSelector, response.EntityId);
							rowData.CRADate = response.Output.CraTrainingDate;
							rowData.IMDate = response.Output.ImDate;
							rowData.QipBudgetedSites.Value = response.Output.QipBudgetedSites;
							rowData.QipBudgetedSites.IsConnected = response.Output.IsQipBudgetedSitesConnected;
							rowData.QipBudgetedSivCovVisitCount = response.Output.QipBudgetedSivCovVisitCount;
							rowData.QipBudgetedOnsiteImvVisitCount.Value = response.Output.QipBudgetedOnsiteImvVisitCount;
							rowData.QipBudgetedOnsiteImvVisitCount.IsConnected = response.Output.IsQipBudgetedOnsiteImvVisitCountConnected;
							rowData.QipBudgetedPharmacyVisitCount.Value = response.Output.QipBudgetedPharmacyVisitCount;
							rowData.QipBudgetedPharmacyVisitCount.IsConnected = response.Output.IsQipBudgetedPharmacyVisitCountConnected;
							rowData.QipBudgetedRemoteVisitCount.Value = response.Output.QipBudgetedRemoteVisitCount;
							rowData.QipBudgetedRemoteVisitCount.IsConnected = response.Output.IsQipBudgetedRemoteVisitCountConnected;
							rowData.BudgetedBoosterVisitCount.Value = response.Output.BudgetedBoosterVisitCount;
							rowData.BudgetedBoosterVisitCount.IsConnected = response.Output.IsBudgetedBoosterVisitCountConnected;

							$(maNs.gridSelector).setCell(response.EntityId, "CRADate", response.Output.CraTrainingDate, "", "", true);
							$(maNs.gridSelector).setCell(response.EntityId, "IMDate", response.Output.ImDate, "", "", true);
							$(maNs.gridSelector).setCell(response.EntityId, "QipBudgetedSites", response.Output.QipBudgetedSites, "", "", true);
							$(maNs.gridSelector).setCell(response.EntityId, "QipBudgetedSivCovVisitCount", response.Output.QipBudgetedSivCovVisitCount, "", "", true);
							$(maNs.gridSelector).setCell(response.EntityId, "QipBudgetedOnsiteImvVisitCount", response.Output.QipBudgetedOnsiteImvVisitCount, "", "", true);
							$(maNs.gridSelector).setCell(response.EntityId, "QipBudgetedPharmacyVisitCount", response.Output.QipBudgetedPharmacyVisitCount, "", "", true);
							$(maNs.gridSelector).setCell(response.EntityId, "QipBudgetedRemoteVisitCount", response.Output.QipBudgetedRemoteVisitCount, "", "", true);
							$(maNs.gridSelector).setCell(response.EntityId, "BudgetedBoosterVisitCount", response.Output.BudgetedBoosterVisitCount, "", "", true);

							setTimeout(function () { maNs.showWarningInProjectedInitiatedSitesCell(response.EntityId); }, 50);
							rm.ui.ribbon.refresh();
						}, 50);
					} else {
						rm.validation.processErrorMessages(response.Errors, maNs.gridSelector, "IconColumn");
					}
				});

				maNs.updateSummaryRow();

				if (successCount === 0) {
					rm.ui.messages.showError("Errors found.  Nothing saved.");
				}
				else if (rowsToSave.length === successCount) {
					if (rowsToSave.length !== totalRowsInEditMode) {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showWarningWithCloseButton("Data saved with some errors found.");
					}
					else {
						rm.ui.messages.showSuccess(Resources.AllDataSavedSuccessfully);
					}
				}
				else {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showWarningWithCloseButton("Data saved with some errors found.");
				}
			});
		}
	},
	connectValueToQip: function (monitoringAttributeId, columnName, connectedValue, saveSuccessFunction) {
		rm.ajax.attributeSvcAsyncPost("ConnectSingleMonitoringValueToQip", { monitoringAttributeId: monitoringAttributeId, columnName: columnName, connectedValue: connectedValue }, function (serviceResponse) {
			maNs.updateSummaryRow();
			var rowData = rm.grid.rowData.getById(maNs.gridSelector, monitoringAttributeId);

			rm.ui.messages.showSuccess("Data saved successfully");
			if ($.isFunction(saveSuccessFunction)) {
				saveSuccessFunction();
				//this code must be called after the saveSuccessFunction as it depends on the connect status of QipBudgetedSites which gets updated from withing the savesuccessFunction
				if (columnName.toLowerCase() == "qipbudgetedsites") {
					rowData.QipBudgetedSivCovVisitCount = serviceResponse;
					$(maNs.gridSelector).setCell(monitoringAttributeId, "QipBudgetedSivCovVisitCount", serviceResponse, "", "", true);
				}
			}

		});
	},
	cancelGrid: function () {
		rm.ui.messages.clearAllMessages();
		rm.grid.cancelGridEditMode(maNs.gridSelector, true);
		rm.ui.ribbon.delayedRefresh();
	},
	bindLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn("#list_IconColumn", "A red triangle is displayed if the country is now Inactive in PPM, or if the country is missing from budget");
		rm.qtip.showInfoOnGridColumn("#list_Region", "Region where the monitoring is taking place.");
		rm.qtip.showInfoOnGridColumn("#list_Country", "Country where the monitoring is taking place.");
		rm.qtip.showInfoOnGridColumn("#list_QipBudgetedSites", "Total number of sites budgeted.<br/><br/>Usually sourced from budget but can be overridden in RM.<br/><br/>If budget values are available, it can be reconnected to budget by clicking the red broken chainlink icon. <br/><br/>Update to the most recent budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectedInitiatedSites", "Sourced from the 'Total Sites Open' metric in CTMS if non-zero, otherwise initially from budget on Project Award.<br/><br/>Ensure that total Projected Initiated sites across all countries does not exceed total Budgeted Sites across all countries.<br/><br/>If an excess is seen (and is required), consider creating a Change Order (CO).");
		rm.qtip.showInfoOnGridColumn("#list_ActualActiveSites", "Sourced from CTMS.<br/><br/>Includes the project's sites with the following statuses:<br/>'Closed',<br/>'Enrollment Closed',<br/>'Enrollment On-Hold',<br/>'Enrollment Open',<br/>'Essential Documents in place',<br/>'Initiated',<br/>'Prematurely Closed',<br/>'Ready for Initiation',<br/>'Regulatory Green Light',<br/>'Selected'");
		rm.qtip.showInfoOnGridColumn("#list_QipBudgetedSivCovVisitCount", "Number of Budgeted On-Site SIV + COV visits, as a computed value based only on 'Budgeted Sites'.<br/><br/>Any values for SIV + COV visits actually in budget are always ignored.<br/><br/>This number does not include Pharmacy SIV + COV Visits.<br/><br/>Always computed as:<br/>For Japan: <Budgeted Sites> x 3 (i.e. one visit per site for SIV, and two per site for COV)<br/><br/>For other Countries: <Budgeted Sites> x 2 (i.e. one visit per site for each of SIV and COV)<br/><br/>If 'Budgeted Sites' is budget-connected, the value is recomputed whenever the 'Refresh Budget Date' option is selected.");
		rm.qtip.showInfoOnGridColumn("#list_QipBudgetedOnsiteImvVisitCount", "Number of budgeted On-Site IMV visits.<br/><br/>Usually sourced from budget but can be overridden in RM.<br/><br/>Update to the most recent budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
		rm.qtip.showInfoOnGridColumn("#list_QipBudgetedRemoteVisitCount", "Number of budgeted Remote (Phone) visits.<br/><br/>Usually sourced from budget but can be overridden in RM.<br/><br/>Update to the most recent budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
		rm.qtip.showInfoOnGridColumn("#list_BudgetedBoosterVisitCount", "Number of budgeted Booster visits.<br/><br/>Always sourced from the budget.<br/><br/>Update to the most recent budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
		rm.qtip.showInfoOnGridColumn("#list_QipBudgetedPharmacyVisitCount", "Number of budgeted Pharmacy visits.<br/><br/>Usually sourced from budget but can be overridden in RM.<br/><br/>Update to the most recent budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectedSivCovVisitCount", "Number of SIV + COV Visits projected based on Total Projected Sites.<br/><br/>Includes visits for both Site and Pharmacy monitoring.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectedOnsiteImvVisitCount", "Number of On-Site visits projected, based on Total Projected Sites and the country's site Visit Frequency. For RBM projects, RBM Schema is taken into account.<br/><br/>Enables comparison of Projected Visits versus Budgeted Visits.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectedRemoteVisitCount", "Number of Remote (Phone) visits projected, based on Total Projected Sites and the country's site Visit Frequency. For RBM projects, RBM Schema is taken into account.<br/><br/>Enables comparison of Projected Visits versus Budgeted Visits.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectedPharmacyVisitCount", "Number of Pharmacy visits projected, based on Total Projected Sites and the country's site Visit Frequency. For RBM projects, RBM Schema is taken into account.<br/><br/>Enables comparison of Projected Visits versus Budgeted Visits.");
		rm.qtip.showInfoOnGridColumn("#list_FTE", "Provides details of the resource request and takes into account the country working hours and the % utilization.");
		rm.qtip.showInfoOnGridColumn("#list_CRADate", "CRA Training Date.<br/><br/>Double-click on a country row to edit.");
		rm.qtip.showInfoOnGridColumn("#list_IMDate", "Investigator Meeting Date.<br/><br/>Double-click on a country row to edit.");
		rm.qtip.showInfoOnGridColumn("#list_FirstSIVFinalCOV", "Date range between the first Site Initiation Visit (SIV) and the last site Close-Out visit (COV) Country Milestone. Derived from the PPM Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#list_Notes", "Use to add or view comments about the project and/or request.");
		rm.qtip.showInfoOnGridColumn("#list_IsActive", "Indicates whether the country is active in the Project Schedule.<br/><br/>Inactive countries appear only when their original status was active.");
		rm.qtip.showInfoOnGridColumn("#list_PresentInQip", "'Yes' if this country is present in the Project's budget");

		rm.qtip.showInfoOnGridColumn("#infoTotalQipBudgetedSites", "Total 'Budgeted Sites' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalProjectedInitiatedSited", "Total 'Projected Initiated Sites' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalActualActiveSites", "Total 'Actual Active Sites' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalBudgetedOnsiteVisits", "Total 'Budgeted On-Site IMV Visits' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalBudgetedRemoteVisits", "Total 'Budgeted Remote (Phone) Visits' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalProjectedOnsiteVisits", "Total 'Projected On-Site IMV Visits' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalProjectedRemoteVisits", "Total 'Projected Remote (Phone) Visits' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalBudgetedSivCovVisits", "Total 'Computed Budgeted SIV + COV Visits' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalBudgetedPharmacyVisits", "Total 'Budgeted Pharmacy Visits' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalProjectedSivCovVisits", "Total 'Projected SIV + COV Visits' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalProjectedPharmacyVisits", "Total 'Projected Pharmacy Visits' (for PPM-Active countries only)");
		rm.qtip.showInfoOnGridColumn("#infoTotalBudgetedBoosterVisitCount", "Total 'Budgeted Booster Visits' (for PPM-Active countries only)");
	},
	updateProjectedInitiatedSitesDisplayValue: function (rowId) {
		var message = "";
		var rowData = rm.grid.rowData.getById(maNs.gridSelector, rowId);
		//zeroProjectedSitesForActiveCountry 
		if (rowData.IsActive === "Active" && rowData.ProjectedInitiatedSites == 0) {
			message = Resources.ZeroProjectedSitesForActiveCountry + "<br/>";
		}
		//projectedSitesLessThanActualActiveSites
		if (parseInt(rowData.ProjectedInitiatedSites) < parseInt(rowData.ActualActiveSites)) {
			message += Resources.ProjectedSitesLessThanActualActiveSites + "<br/>";
		}

		var cellValue = (message === "") ? rowData.ProjectedInitiatedSites :
			rowData.ProjectedInitiatedSites + $("<div/>").append($("<img>", { class: 'imgProjectedSitesWarning', src: '/_layouts/SPUI/images/warningIcon.png', message: message, css: { cursor: "pointer", paddingLeft: "5px" } })).html();
		$(maNs.gridSelector).setCell(rowId, "ProjectedInitiatedSites", cellValue, "", "", true);

		return message !== "";
	},
	prepareProjectedInitiatedSitesForEdit: function (cellvalue, options, cell) {
		return rm.grid.standardColumns.getUnformattedCellValueForEdit(cellvalue, options, cell);
	},
	showErrorIconOnLoad: function () {
		var mygrid = $(maNs.gridSelector);
		var ids = mygrid.getDataIDs();  //all the rowids
		for (var i = 0; i < ids.length; i++) {
			var presentInQip = rm.grid.rowData.getById(maNs.gridSelector, ids[i]).PresentInQip === "Yes";
			var activeInPpm = rm.grid.rowData.getById(maNs.gridSelector, ids[i]).IsActive === "Active";

			var message = "";
			if (presentInQip && !activeInPpm) { message = Resources.PresentInQipInactiveInPpm; }
			else if (!presentInQip && activeInPpm) { message = Resources.ActiveInPpmNotPresentInQip; }

			if (message !== "") {
				var imageText = $("<div/>").append($("<img>", { class: 'imgActiveMismatch', src: '/_layouts/SPUI/images/errorIcon.png', message: message, css: { cursor: "pointer" } })).html();
				$(mygrid).setCell(ids[i], "IconColumn", imageText, "", "", true);
			}
		}
		setTimeout(function () {
			$.each($(".imgActiveMismatch"), function (index, element) {
				rm.qtip.showInfoOnGridColumn($(element), $(element).attr("message"));
			});
		}, 10);
	},
	getMandatoryColumns: function () {
		return [
			{
				name: '', label: '', index: 'actions',
				formatter: 'actions', editable: false, sortable: false, resizable: false, frozen: true,
				fixed: true, width: 50, search: false,
				formatoptions: {
					keys: true, editbutton: false, delbutton: false,
					//onEditFunction: function () { alert();},
					afterRestore: function (rowid) {
						rm.ui.ribbon.delayedRefresh();
						rm.grid.scrollTableBodyToFixAlignmentIssue(maNs.gridSelector);
					},
				}
			},
			{ name: 'IconColumn', index: 'IconColumn', label: '&nbsp;', width: 20, search: false, sortable: false, frozen: true }
		];
	},
	getFullColumnModelList: function () {
		return [
			{ name: 'Region', index: 'Region', label: 'Region', width: 95, frozen: true, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Country', index: 'Country', label: 'Country', width: 95, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			rm.grid.standardColumns.getEditableQipConnectableIntColumn("QipBudgetedSites", "QipBudgetedSites", "Budgeted<br/>Sites", 71, maNs.gridSelector, false, true, 0, 99999, "5,0", maNs.connectValueToQip, maNs.allowEdit()),
			{
				name: 'ProjectedInitiatedSites', index: 'ProjectedInitiatedSites', label: 'Projected<br />Initiated<br/>Sites', align: 'center', sorttype: 'text',
				width: 60, search: false, unformat: maNs.prepareProjectedInitiatedSitesForEdit, editable: false,
				editoptions: { class: "validateRange editable width65px", from: "0", to: "99999", formating: "5,0", }
			},
			{ name: 'ActualActiveSites', index: 'ActualActiveSites', label: 'Actual<br />Active<br/>Sites', align: 'center', sorttype: 'integer', width: 47, search: false },
			{ name: 'QipBudgetedSivCovVisitCount', index: 'QipBudgetedSivCovVisitCount', label: 'Computed<br/>Budgeted<br />SIV + <br/>COV<br/>Visits', align: 'center', sorttype: 'integer', width: 65, search: false },
			rm.grid.standardColumns.getEditableQipConnectableIntColumn("QipBudgetedOnsiteImvVisitCount", "QipBudgetedOnsiteImvVisitCount", "Budgeted<br />On-Site<br/>IMV<br/>Visits", 71, maNs.gridSelector, false, true, 0, 99999, "5,0", maNs.connectValueToQip, maNs.allowEdit()),
			rm.grid.standardColumns.getEditableQipConnectableIntColumn("QipBudgetedRemoteVisitCount", "QipBudgetedRemoteVisitCount", "Budgeted<br />Remote<br/>Visits", 71, maNs.gridSelector, false, true, 0, 99999, "5,0", maNs.connectValueToQip, maNs.allowEdit()),
			rm.grid.standardColumns.getEditableQipConnectableIntColumn("BudgetedBoosterVisitCount", "BudgetedBoosterVisitCount", "Budgeted<br />Booster<br/>Visits", 71, maNs.gridSelector, false, true, 0, 99999, "5,0", maNs.connectValueToQip, maNs.allowEdit()),
			rm.grid.standardColumns.getEditableQipConnectableIntColumn("QipBudgetedPharmacyVisitCount", "QipBudgetedPharmacyVisitCount", "Budgeted<br />Pharmacy<br/>Visits", 71, maNs.gridSelector, false, true, 0, 99999, "5,0", maNs.connectValueToQip, maNs.allowEdit()),
			{ name: 'ProjectedSivCovVisitCount', index: 'ProjectedSivCovVisitCount', label: 'Projected<br />SIV + <br/>COV<br/>Visits', align: 'center', sorttype: 'integer', width: 60, search: false },
			{ name: 'ProjectedOnsiteImvVisitCount', index: 'ProjectedOnsiteImvVisitCount', label: 'Projected<br />On-Site<br />IMV<br/>Visits', align: 'center', sorttype: 'integer', width: 66, search: false },
			{ name: 'ProjectedRemoteVisitCount', index: 'ProjectedRemoteVisitCount', label: 'Projected<br />Remote<br />Visits', align: 'center', sorttype: 'integer', width: 66, search: false },
			{ name: 'ProjectedPharmacyVisitCount', index: 'ProjectedPharmacyVisitCount', label: 'Projected<br />Pharmacy<br/>Visits', align: 'center', sorttype: 'integer', width: 65, search: false },
			maNs.getFteIconColumnDefinitionForGrid(),
			rm.grid.standardColumns.getEditableDateColumn('CRADate', 'CRADate', 'CRA Training<br/>Date'),
			rm.grid.standardColumns.getEditableDateColumn('IMDate', 'IMDate', 'Investigator<br />Meeting Date'),
			{
				name: 'FirstSIVFinalCOV', index: 'FirstSIVFinalCOV', label: 'First SIV-Final COV', width: 200, searchoptions: { attr: { maxlength: 25 } },
				formatter: function (cellvalue, options, rowObject) {
					var rowData = rowObject;
					if (!rowData.StartDate) {
						rowData = rm.grid.rowData.getById(maNs.gridSelector, options.rowId);
					}
					return rowData.StartDate + " - " + rowData.StopDate;
				}
			},
			rm.grid.standardColumns.getNotesColumn(),
			{ name: 'IsActive', index: 'IsActive', label: 'PPM<br/>Status', sortable: false, align: 'center', width: 70, search: true, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.activeInactive } },
			{ name: 'PresentInQip', index: 'PresentInQip', label: 'Present<br/>in Budget', sortable: false, align: 'center', width: 70, search: true, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.yesNo } }
		];
	},
	handleUserPreferencesResponse: function (userColumnPreferences) {
		userColumnPreferences.UiColumnConfiguration = maNs.getFullColumnModelList();
		var columnModel = rm.grid.getFinalColumnModelFromFullColumnListAndUserColumnPreferences(maNs.getFullColumnModelList(), userColumnPreferences, maNs.getMandatoryColumns());
		maNs.columnModelUsedByGrid = columnModel;
		maNs.columnModelUsedByGrid = columnModel;
		maNs.buildDynamicGrid(columnModel, userColumnPreferences);
	},
	buildGrid: function () {
		rm.serviceCalls.getRmUserDataGridColumnPreferences(DataGrid.MonitoringAttribute, maNs.handleUserPreferencesResponse);
	},
	buildDynamicGrid: function (columnModel, userColumnPreferences) {
		var gridPostData = rm.grid.getFilterCriateriaFromCookie(maNs.cookieName, null, {});
		rm.grid.applyFilterCriateriaToGrid(gridPostData);
		$.extend(gridPostData, { ProjectCode: maNs.getProjectName(), ProtocolNumber: GetCurrentProjectCodeProtocolNumber() });

		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.MonitoringAttributes, dataGridId: DataGrid.MonitoringAttribute };
		gridToolsConfig.manageColumnsParameters = userColumnPreferences;
		rm.grid.showGridTools(maNs.gridSelector, gridToolsConfig);

		$(maNs.gridSelector).jqGrid({
			url: rm.ajax.attributeSvcUrl + "GetMonitoringAttrByProjectCode",
			editurl: "",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(true),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			postData: gridPostData,
			jsonReader: rm.grid.getJqGridJsonReader(),
			loadui: "block",
			loadonce: false,
			multiselect: maNs.allowEdit(),
			autowidth: true,
			height: rm.ui.getMinPageHeight(),
			width: window.screen.width - 200,
			shrinkToFit: false,
			pager: '#listPager',
			viewrecords: true,
			colModel: columnModel,
			viewsortcols: [true, 'vertical', true],
			sortname: 'Region',
			sortorder: 'asc',
			grouping: false,
			//Prevent grid from selecting a row when clicked on anywhere else in the row other than checkbox
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			beforeRequest: function () { rm.grid.setHeaderRowHeightFiveLine("list"); },
			ondblClickRow: function (id) {
				var areAllEditableColumnsPresent = rm.grid.areAllEditableColumnsPresent(maNs.getFullColumnModelList(), maNs.columnModelUsedByGrid, true);

				if (maNs.allowEdit() && areAllEditableColumnsPresent) {
					rm.grid.editRow(maNs.gridSelector, id);
					rm.ui.ribbon.refresh();
					rm.grid.attachCustomSaveHandler(maNs.gridSelector, id, maNs.saveSingleAttribute);
				}
			},
			onSelectRow: function (id) { rm.ui.ribbon.refresh(); },
			onSelectAll: function (rowIdxArray, status) { rm.ui.ribbon.refresh(); },
			serializeRowData: function (postData) {
				var data = {
					monAttributeData: {
						Id: postData.id,
						CraTrainingDate: postData.CRADate,
						ImDate: postData.IMDate,
						ProjectedInitiatedSites: postData.ProjectedInitiatedSites
					}
				};
				return JSON.stringify(data);
			},
			serializeGridData: rm.grid.serializeGridData,
			loadComplete: function (data) {
				rm.grid.rowData.attachAllRowsData(maNs.gridSelector, data);
				maNs.showErrorIconOnLoad();
				$(".fteIcon").click(maNs.handleFteIconClick);
				rm.ui.notes.bindNotesIconClick();

				var failedIds = $.parseJSON($.cookie("multiEditFailedAttributeIds"), { path: "/" });
				if (failedIds && failedIds.length > 0) {
					$.each(failedIds, function (index, id) { jQuery(maNs.gridSelector).jqGrid('setSelection', id); });
				}
				$.cookie("multiEditFailedAttributeIds", null, { path: "/" });
			},
			gridComplete: function () {
				maNs.freezeColumnsAndBindInfo();
				setTimeout(function () { maNs.showWarningOnProjectedInitiatedSites(); }, 100);
			},
			resizeStop: function (newWidth, columnIndex) {
				//maNs.alignSummaryTableColumns();
				//Becasue grid allows multiselect, it adds a checkbox column as a first column. To find out the column index in the colModel, subtract 1.
				//Not required for grids that don't show checkbox column
				columnIndex -= 1;
				var dataGridColumnId = rm.grid.getDataGridColumnIdFromColIndexColModelAndUserPref(columnIndex, columnModel, userColumnPreferences);
				rm.grid.saveDataGridColumnWidthPreference(newWidth, DataGrid.MonitoringAttribute, dataGridColumnId, maNs.gridSelector);
			}
		});
		$(maNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},
	showWarningOnProjectedInitiatedSites: function () {
		var ids = $(maNs.gridSelector).getDataIDs();  //all the rowids
		for (var i = 0; i < ids.length; i++) { maNs.showWarningInProjectedInitiatedSitesCell(ids[i]); }
	},
	showWarningInProjectedInitiatedSitesCell: function (rowId) {
		if (maNs.updateProjectedInitiatedSitesDisplayValue(rowId)) {
			var cell = rm.grid.getHtmlCell(maNs.gridSelector, rowId, "ProjectedInitiatedSites").css(maNs.errorCss);
			var objEle = $(cell).find(".imgProjectedSitesWarning");
			rm.qtip.showInfoOnGridColumn(objEle, objEle.attr("message"));
		}
		else { rm.grid.getHtmlCell(maNs.gridSelector, rowId, "ProjectedInitiatedSites").css(maNs.noErrorCss); }
	},
	updateSummaryRow: function () {
		rm.ajax.attributeSvcAsyncPost("GetMonitoringAttributeVisitSummary", { projectId: maNs.getProjectId() }, function (serviceResponse) {
			$("td[id$=TotalActualActiveSites]").text(serviceResponse.TotalActualActiveSites);
			$("td[id$=TotalProjectedInitiatedSites]").text(serviceResponse.TotalProjectedInitiatedSites);
			$("td[id$=TotalProjectedOnsiteImvVisitCount]").text(serviceResponse.TotalProjectedOnsiteImvVisitCount);
			$("td[id$=TotalProjectedPharmacyVisitCount]").text(serviceResponse.TotalProjectedPharmacyVisitCount);
			$("td[id$=TotalProjectedRemoteVisitCount]").text(serviceResponse.TotalProjectedRemoteVisitCount);
			$("td[id$=TotalProjectedSivCovVisitCount]").text(serviceResponse.TotalProjectedSivVisitCount + serviceResponse.TotalProjectedCovVisitCount);
			$("td[id$=TotalQipBudgetedSites]").text(serviceResponse.TotalBudgetedSites);
			$("td[id$=TotalQipBudgetedSivCovVisitCount]").text(serviceResponse.TotalQipBudgetedSivVisitCount + serviceResponse.TotalQipBudgetedCovVisitCount);
			$("td[id$=TotalQipBudgetedOnsiteImvVisitCount]").text(serviceResponse.TotalQipBudgetedOnsiteImvVisitCount);
			$("td[id$=TotalQipBudgetedPharmacyVisitCount]").text(serviceResponse.TotalQipBudgetedPharmacyVisitCount);
			$("td[id$=TotalQipBudgetedRemoteVisitCount]").text(serviceResponse.TotalQipBudgetedRemoteVisitCount);
			$("td[id$=TotalBudgetedBoosterVisitCount]").text(serviceResponse.TotalBudgetedBoosterVisitCount);
			maNs.handleTotalProjectedIntiatedSitesErrorVisibility(serviceResponse.TotalBudgetedSites, serviceResponse.TotalProjectedInitiatedSites);
		});
	},
	handleTotalProjectedIntiatedSitesErrorVisibility: function (totalBudgetedSites, totalProjectedInitiatedSites) {
		if (totalBudgetedSites < totalProjectedInitiatedSites) {
			var errorIcon = rm.ui.jqControlBuilder.errorIcon({ id: "projectLevelSiteCountError", css: { paddingLeft: "10px" } });
			$("td[id$=TotalProjectedInitiatedSites]").css(maNs.errorCss).append(errorIcon);
			rm.qtip.showInfoOnGridColumn(errorIcon, Resources.TotalProjectedInitiatedSitesGreaterThenBudget);
		}
		else {
			$("td[id$=TotalProjectedInitiatedSites]").css(maNs.noErrorCss);
			$("#projectLevelSiteCountError").remove();
		}
	},
	errorCss: { backgroundColor: "#FFBBCC" },
	noErrorCss: { backgroundColor: "transparent" },
	//jqGridTableBodyDivSelector: "#gbox_list .ui-jqgrid-bdiv",
	//noScrollPositionLeft: 300,
	//setMarginLeftForSummaryTable: function () { maNs.noScrollPositionLeft = $("#gview_list .ui-jqgrid-htable tr:nth(0) th:eq(5)").position().left; },
	//scrollSyncSummaryWithGrid: function () { $("#tblMaSummary").css({ marginLeft: maNs.noScrollPositionLeft - $(maNs.jqGridTableBodyDivSelector).scrollLeft() }); },
	//alignSummaryTableColumns: function () {
	//	var columnWidths = [];
	//	$.each($("#gview_list .ui-jqgrid-htable tr:nth(0) th:gt(4)"), function () { columnWidths.push($(this).width()) });

	//	var tableWidth = 0;
	//	$.each($("#tblMaSummary tr th"), function (index, element) {
	//		var columnWidth = columnWidths[index];
	//		tableWidth += columnWidth
	//		$(element).width(columnWidth);
	//	});

	//	var offsetLeft = 25;
	//	$.each($("#gview_list .ui-jqgrid-htable tr:nth(0) th:lt(5)"), function () { offsetLeft += $(this).width(); })
	//	maNs.noScrollPositionLeft = offsetLeft;
	//	maNs.scrollSyncSummaryWithGrid();
	//	$("#tblMaSummary").width(tableWidth);
	//}
};