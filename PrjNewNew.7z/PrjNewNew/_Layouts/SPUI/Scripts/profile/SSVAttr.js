﻿///<reference path="../Requests/InitiateRequestHelper.js"/>
var ProjectName = "";
var ProtocolNumber = "";
$(document).ready(function () {
	ProjectName = GetCurrentProjectName();
	ProtocolNumber = GetCurrentProjectCodeProtocolNumber();

	if (ProjectName == "" || ProtocolNumber == "") { return false; }

	ssvAttrNs.initUi();
});

ssvAttrNs = {
	columnModelUsedByGrid: null,
	frozenColumnAlreadyBound: false,
	initUi: function () {
		ssvAttrNs.bindEvents();
		ssvAttrNs.bindDatePicker();
		ssvAttrNs.buildGrid();
		ssvAttrNs.bindValidator();
		ssvAttrNs.showNonRbmToRbmConversionWarning();
	},
	getSsvWindowChangeSendTo: function () { return $("input[name='ssvWindowChangeSendTo']:checked").val(); },
	getProjectId: function () { return $("[id$=hdnProjectId]").val(); },
	bindEvents: function () {
		$(ssvAttrNs.getJsonObjectForSsvWindowChangeDialogDirtyCheck().items[0].selector).change(ssvAttrNs.isSsvWindowChangeDialogDirty);
	},
	bindValidator: function () {
		$(ssvAttrNs.txtNewSsvStartDateSelector).bind('blur', function (event) {
			if ($.trim($(this).val()) == "") {
				rm.validation.addError($(this), Resources.StartDateIsBlank);
			}
		});

		$(ssvAttrNs.txtNewSsvStopDateSelector).bind('blur', function (event) {
			if ($.trim($(this).val()) == "") {
				rm.validation.addError($(this), Resources.StopDateIsBlank);
			}
		});
	},
	allowEdit: function () { return $("[id$=hdnAllowEdit]").val() === "1"; },
	showNonRbmToRbmConversionWarning: function () {
		if ($("[id$=hdnIsRbmProjectManagedAsNonRbmInRm]").val() === "1") { rm.ui.messages.showWarningWithCloseButton(Resources.NonRbmToRbmConversion); }
	},
	bindDatePicker: function () {
		$(ssvAttrNs.txtNewSsvStartDateSelector).qDatepicker();
		$(ssvAttrNs.txtNewSsvStopDateSelector).qDatepicker();
	},
	EditMultipleAttributes: {
		ModifyAttributeRibbonControlId: '#Ribbon_ProjectSummaryRibbon_GridActions_EditSingleRow',
		ModifyAttributesRibbonControlId: '#Ribbon_ProjectSummaryRibbon_GridActions_EditMultipleRow'
	},
	ModifySingleRowEnabled: function () {
		if ($(ssvAttrNs.gridSelector).getGridParam('selarrrow') == undefined) {
			$(ssvAttrNs.EditMultipleAttributes.ModifyAttributesRibbonControlId).hide();
			$(ssvAttrNs.EditMultipleAttributes.ModifyAttributeRibbonControlId).show();
			return false;
		} else {
			return rm.grid.hasSingleRowSelected(ssvAttrNs.gridSelector);
		}
	},
	ModifyMultipleRowsEnabled: function () {
		return ssvAttrNs.ModifyMultipleAttributesEnabled(ssvAttrNs.gridSelector, ssvAttrNs.EditMultipleAttributes.ModifyAttributeRibbonControlId, ssvAttrNs.EditMultipleAttributes.ModifyAttributesRibbonControlId);
	},
	ModifyMultipleAttributesEnabled: function (gridListControlId, modifyAttributeRibbonControlId, modifyAttributesRibbonControlId) {
		var selectedrows = $(gridListControlId).getGridParam('selarrrow');
		if (selectedrows == undefined) return false;
		var isEnabled = true;

		if (selectedrows.length > 1) {
			$(modifyAttributesRibbonControlId).show();
			$(modifyAttributeRibbonControlId).hide();
		} else {
			$(modifyAttributesRibbonControlId).hide();
			$(modifyAttributeRibbonControlId).show();
			isEnabled = false;
		}

		return isEnabled;
	},
	ModifySingleAttribute: function () {
		rm.grid.getSelectedIds((ssvAttrNs.gridSelector));
		var selectedrows = $(ssvAttrNs.gridSelector).getGridParam('selarrrow');
		ssvAttrNs.handleCalculatorIconClick(selectedrows[0]);
	},
	ModifyMultipleAttributes: function () {
		var mygrid = $(ssvAttrNs.gridSelector);
		var gridState = { searchCriteria: mygrid.getGridParam("postData") };
		$.cookie("SSVAttributesSearchCriteria", JSON.stringify(gridState));

		$("#selectedEntityIds").val(rm.grid.getSelectedIds(ssvAttrNs.gridSelector));
		var action = "/_layouts/SPUI/Calculator/RedirectToEditMultipleCalculators.aspx?source=ssvattr";
		$("#aspnetForm").attr("action", action);
		$("#aspnetForm").submit();
	},

	editSelectedRow: function () {
		var selectedrows = $(ssvAttrNs.gridSelector).getGridParam('selarrrow');
		if (selectedrows.length > 1) {
			alert("Can only edit one attribute at a time.");
			return false;
		}

		if (selectedrows.length == 0) {
			alert("No attribute selected.");
			return false;
		}

		var mygrid = $(ssvAttrNs.gridSelector);
		var gridState = { searchCriteria: mygrid.getGridParam("postData") };
		gridState.entityId = selectedrows[0];
		gridState.requestGroup = RequestGroup_E.NewMonitoring;


		$.cookie("SSVAttributesSearchCriteria", JSON.stringify(gridState), { path: "/" });
		try {
			document.location.href = "/_layouts/SPUI/Calculator/EditCalculator.aspx?entityId=" + selectedrows[0] + "&source=ssvattr";
		}
		catch (ex) {			/*ignore*/ }
	},

	bindLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn("#list_QipBudgetedSites", "Total number of sites budgeted for selection in budget.<br/><br/>Usually sourced from budget but can be overridden in RM.<br/><br/>If budget values are available, it can be reconnected to budget by clicking the red broken chainlink icon. <br/><br/>Update to the most recent budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
		rm.qtip.showInfoOnGridColumn("#list_Country", "Country where the SSV is taking place.");
		rm.qtip.showInfoOnGridColumn("#list_BudgetedSites", "Represents the 'Sites Selected (Targeted Total)' from PPM/Enter Metrics.");
		rm.qtip.showInfoOnGridColumn("#list_FTE", "Provides the details of the hours allocated for a request.");
		rm.qtip.showInfoOnGridColumn("#list_SIFSentDate", "Indicates whether CTMS ‘Document Tracking’ records record that a SIF has been sent to at least one Site in each country");
		rm.qtip.showInfoOnGridColumn("#list_ProjectedStartStopDate", "Date range between the start of  Site ID/Site Selection Visit (SSV) Country Milestone and the finish of Site ID/Site Selection Visit (SSV). Derived from the QRPM: PPM Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#list_Notes", "Use to add/view comments about the particular project/request.");
		rm.qtip.showInfoOnGridColumn("#list_IsActive", "Indicates whether the country is active in the Project Schedule.  Inactive countries appear only when their original status was active.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectedTotalSites", "Projected total number of Country sites. Defaults to budget value. Double click to edit in QRPM: RM");
		rm.qtip.showInfoOnGridColumn("#list_QipTotalSites", "Total number of Country sites derived from budget");
		rm.qtip.showInfoOnGridColumn("#list_PresentInQip", "'Yes' if this country is present in the Project's budget");
	},

	getSsvWindowChangeIconColumnDefinitionForGrid: function () {
		return {
			name: 'id', index: 'id', label: 'Request<br />to<br />Modify<br />SSV<br />Window', sortable: false, align: 'center', width: 60, search: false, formatter: function (cellvalue, options, rowObject) {
				return "<img src='/_layouts/SPUI/images/mail.png' alt='Country SSV FTE Calculator' style='cursor: pointer;' title='Request SSV Window Change' class='imgWindowChange' attributeId='" + options.rowId + "' />";
			}
		};
	},
	getCalculatorEditLink: function (rowId) { return "/_layouts/SPUI/Calculator/EditCalculator.aspx?entityId=" + rowId + "&source=ssvattr"; },
	getFteIconColumnDefinitionForGrid: function () {
		return {
			name: 'FTE', index: 'FTE', label: 'FTE', sortable: false, align: 'center', width: 50, search: false, formatter: function (cellValue, options, rowObject) {
				var editLinkStart = ssvAttrNs.allowEdit() ? "<a href='" + ssvAttrNs.getCalculatorEditLink(options.rowId) + "'>" : "";
				var editLinkEnd = ssvAttrNs.allowEdit() ? "</a>" : "";
				var style = ssvAttrNs.allowEdit() ? " style='cursor: pointer;' " : "";
				return editLinkStart + "<img src='/_layouts/SPUI/images/CalculatorIcon.gif' alt='Country SSV FTE Calculator' " + style + " title='Country SSV FTE Calculator' />" + editLinkEnd;
			}
		};
	},
	gridSelector: "#list",
	imgWindowChangeSelector: ".imgWindowChange",
	attrAttributeId: "attributeId",
	ssvWindowChangeDivSelector: "#ssvWindowChangeDiv",
	txtNewSsvStartDateSelector: "[name$=txtNewSsvStartDate]",
	txtNewSsvStopDateSelector: "[name$=txtNewSsvStopDate]",
	classHideMe: "hideMe",
	ProjectNameDisplaySelectro: "#ProjectNameDisplay",
	bindSsvWindowChangeIconClick: function () {
		$(ssvAttrNs.imgWindowChangeSelector).click(function () {
			var attributeId = $(this).attr(ssvAttrNs.attrAttributeId);
			ssvAttrNs.showSsvWindowChageDialog(attributeId);
		});
	},
	showSsvWindowChageDialog: function (attributeId) {
		var rowData = rm.grid.rowData.getById(ssvAttrNs.gridSelector, attributeId);
		var ssvWindowChageDiv = $(ssvAttrNs.ssvWindowChangeDivSelector);

		$(ssvAttrNs.txtNewSsvStartDateSelector).val(rowData.StartDate);
		$(ssvAttrNs.txtNewSsvStopDateSelector).val(rowData.StopDate);
		rm.validation.clearError($(ssvAttrNs.txtNewSsvStartDateSelector));
		rm.validation.clearError($(ssvAttrNs.txtNewSsvStopDateSelector));

		ssvWindowChageDiv.removeClass(ssvAttrNs.classHideMe).show().dialog({
			modal: true,
			cache: false,
			title: ProjectName + " - " + rowData.Country,
			resizable: false,
			width: 500,
			height: 235,
			open: function (event, ui) {
				$("#ssvWindowChangeSendToProjectOwner").prop("checked", true);
				$(this).parent().find("button.ui-dialog-titlebar-close").hide();
				setTimeout(function () {
					ssvAttrNs.bindSsvWindowChangeDialogDirty();
					rm.ui.dialog.toggleButtonEnableDisable("SSV Window", false);
				}, 10);
			},
			buttons: [{
				text: "Request SSV Window Change",
				click: function () {
					var dialog = $(this);
					if (ssvAttrNs.isSsvWindowChangeDialogValid()) {
						var postData = { ssvAttributeId: attributeId, ssvStartDate: $(ssvAttrNs.txtNewSsvStartDateSelector).val(), ssvStopDate: $(ssvAttrNs.txtNewSsvStopDateSelector).val(), sendTo: ssvAttrNs.getSsvWindowChangeSendTo() };
						$.rm.Ajax_AttributeAsync("RequestSsvWindowChange", postData, function (data) {
							if (data.ContainsValidationErrors) {
								rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
								$.validationHelper.ShowErrorMessages(data.ValidationErrors);
							}
							else {
								ssvAttrNs.clearSsvWindowChangeDialogDirty();
								rm.ui.messages.showSuccess("Email has been sent. The new SSV window dates will be available once they have been updated in PPM and successfully published to RM.");
								setTimeout(function () { dialog.dialog("close"); }, 10);
							}
						}, true);
					}
				}
			},
			{
				text: "Cancel",
				click: function () {
					$(this).dialog("close");
				}
			}],
			beforeClose: function (event, ui) {
				if (ssvAttrNs.isSsvWindowChangeDialogDirty() && !confirm(Resources.UnsavedChangesOnThePage)) {
					event.preventDefault();
					event.stopPropagation();
				}
				else {
					ssvAttrNs.clearSsvWindowChangeDialogDirty();
				}
			}
		});
	},
	isSsvWindowChangeDialogValid: function () {
		var isValid = true;
		var isStartDateValid = true;
		var startDate = $(ssvAttrNs.txtNewSsvStartDateSelector).val();
		var stoptDate = $(ssvAttrNs.txtNewSsvStopDateSelector).val();

		if (!rm.date.isValidDate(startDate)) { isValid = false; isStartDateValid = false; }

		if (rm.date.isValidDate(stoptDate, false)) {
			if (!rm.date.isQDateDateGreaterOrEqualToToday(stoptDate)) {
				rm.validation.addError(ssvAttrNs.txtNewSsvStopDateSelector, Resources.StopDateInPast);
				isValid = false;
			}
			else if (isStartDateValid && rm.date.getDateFromQDateString(startDate) > rm.date.getDateFromQDateString(stoptDate)) {
				rm.validation.addError(ssvAttrNs.txtNewSsvStartDateSelector, Resources.StartDateGreaterThanStopDate);
				rm.validation.addError(ssvAttrNs.txtNewSsvStopDateSelector, Resources.StopDateLessThanStartDate);
				isValid = false;
			}
		}
		else { isValid = false; }

		return isValid;
	},
	getJsonObjectForSsvWindowChangeDialogDirtyCheck: function () { return { items: [{ selector: ssvAttrNs.ssvWindowChangeDivSelector + " input:text", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },
	bindSsvWindowChangeDialogDirty: function () { $.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, ssvAttrNs.getJsonObjectForSsvWindowChangeDialogDirtyCheck()); },
	clearSsvWindowChangeDialogDirty: function () { ssvAttrNs.bindSsvWindowChangeDialogDirty(); },
	isSsvWindowChangeDialogDirty: function () {
		var isDirty = $.formStatus.isDirty(ssvAttrNs.getJsonObjectForSsvWindowChangeDialogDirtyCheck());
		rm.ui.dialog.toggleButtonEnableDisable("SSV Window", isDirty);
		return isDirty;
	},
	hasRowsInEditMode: function () { return rm.grid.hasRowsInEditMode(ssvAttrNs.gridSelector); },
	isCancelEnabled: function () { return ssvAttrNs.hasRowsInEditMode(); },
	isSaveEnabled: function () { return ssvAttrNs.hasRowsInEditMode(); },
	freezeColumnsAndBindInfo: function () {
		if (!ssvAttrNs.frozenColumnAlreadyBound) {
			ssvAttrNs.frozenColumnAlreadyBound = true;
			//freezing columns involve rebuilding the grid. Once grid is rebuilt, we need to rebing the information qtip.
			rm.grid.delayedRebindFrozenColumns(ssvAttrNs.gridSelector);
			setTimeout(ssvAttrNs.bindLabelQtip, 100);
		}
		rm.grid.scrollTableBodyToFixAlignmentIssue(ssvAttrNs.gridSelector);
	},
	getMandatoryColumns: function () {
		return [
			{
				name: '', label: '', index: 'actions',
				formatter: 'actions', editable: false, sortable: false, resizable: false, frozen: true,
				fixed: true, width: 50, search: false,
				formatoptions: {
					keys: true, editbutton: false, delbutton: false,
					afterRestore: function (rowid) {
						rm.ui.ribbon.delayedRefresh();
						rm.grid.scrollTableBodyToFixAlignmentIssue(ssvAttrNs.gridSelector);
					}
				}
			}
		];
	},
	getFullColumnModelList: function () {
		return [
			{ name: 'Region', index: 'Region', label: 'Region', width: 150, classes: 'ui-ellipsis' },
			{ name: 'Country', index: 'Country', label: 'Country', width: 150, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			ssvAttrNs.getFteIconColumnDefinitionForGrid(),
			rm.grid.standardColumns.getEditableQipConnectableIntColumn("QipBudgetedSites", "QipBudgetedSites", "Budgeted<br />Total #<br />of Sites", 80, ssvAttrNs.gridSelector, false, true, 0, 99999, "5,0", ssvAttrNs.connectValueToQip, ssvAttrNs.allowEdit()),
			{ name: 'ProjectedTotalSites', index: 'ProjectedTotalSites', align: "right", label: 'Projected Total <br /># of Sites', width: 110, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 4 } } },
			{
				name: 'ProjectedStartStopDate', index: 'ProjectedStartStopDate', label: 'SSV Window', width: 200, searchoptions: { attr: { maxlength: 25 } },
				formatter: function (cellvalue, options, rowObject) {
					var rowData = rowObject;
					if (!rowData.StartDate) {
						rowData = rm.grid.rowData.getById(ssvAttrNs.gridSelector, options.rowId);
					}
					if (rowData != null) {
						return rowData.StartDate + " - " + rowData.StopDate;
					}
					else { return ""; }
				}
			},
			rm.grid.standardColumns.getNotesColumn(),
			ssvAttrNs.getSsvWindowChangeIconColumnDefinitionForGrid(),
			{ name: 'IsActive', index: 'IsActive', label: 'PPM<br/>Status', sortable: true, align: 'center', width: 70, search: true, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.activeInactive } },
			{ name: 'PresentInQip', index: 'PresentInQip', label: 'Present<br/>in budget', sortable: true, align: 'center', width: 60, search: true, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.yesNo } },
			{ name: 'SIFSentDate', index: 'SIFSentDate', label: 'SIF Sent<br />Date', search: false, sort: true, editable: false, width: 80, search: true, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 10 } } },
		];
	},
	handleUserPreferencesResponse: function (userColumnPreferences) {
		userColumnPreferences.UiColumnConfiguration = ssvAttrNs.getFullColumnModelList();
		var columnModel = rm.grid.getFinalColumnModelFromFullColumnListAndUserColumnPreferences(ssvAttrNs.getFullColumnModelList(), userColumnPreferences, ssvAttrNs.getMandatoryColumns());
		ssvAttrNs.columnModelUsedByGrid = columnModel;
		ssvAttrNs.buildDynamicGrid(columnModel, userColumnPreferences);
	},
	buildGrid: function () {
		rm.serviceCalls.getRmUserDataGridColumnPreferences(DataGrid.SsvAttribute, ssvAttrNs.handleUserPreferencesResponse)
	},
	buildDynamicGrid: function (columnModel, userColumnPreferences) {
		var gridSelector = ssvAttrNs.gridSelector;
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.SSVAttributes, dataGridId: DataGrid.SsvAttribute };
		gridToolsConfig.manageColumnsParameters = userColumnPreferences;
		rm.grid.showGridTools(gridSelector, gridToolsConfig);
		$(ssvAttrNs.gridSelector).jqGrid({
			url: rm.ajax.attributeSvcUrl + "GetSSVByProjectCode",
			editurl: rm.ajax.attributeSvcUrl + "GetSSVByProjectCode",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(true),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },  //MR: for saving a row
			postData: { ProjectCode: ProjectName, ProtocolNumber: ProtocolNumber },  //MR: for loading the grid
			jsonReader: rm.grid.getJqGridJsonReader(),
			loadonce: false,
			viewrecords: true,
			multiselect: ssvAttrNs.allowEdit(),
			pager: '#listPager',
			autowidth: true,
			shrinkToFit: false,
			height: rm.ui.getMaxGridHeight() - 60,
			width: rm.ui.getMaxGridWidth(),
			colModel: columnModel,
			//Prevent grid from selecting a row when clicked on anywhere else in the row other than checkbox
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			ondblClickRow: function (id) {
				var areAllEditableColumnsPresent = rm.grid.areAllEditableColumnsPresent(ssvAttrNs.getFullColumnModelList(), ssvAttrNs.columnModelUsedByGrid, true);
				if (ssvAttrNs.allowEdit() && areAllEditableColumnsPresent) {
					rm.grid.editRow(ssvAttrNs.gridSelector, id);
					rm.ui.ribbon.refresh();
					rm.grid.attachCustomSaveHandler(ssvAttrNs.gridSelector, id, ssvAttrNs.saveSingleAttribute);
				}
			},
			viewsortcols: [true, 'vertical', true],
			sortname: 'Region',
			sortorder: 'asc',
			beforeRequest: function () { rm.grid.setHeaderRowHeightFiveLine("list"); },
			onSelectRow: function (id) { rm.ui.ribbon.refresh(); },
			onSelectAll: function (rowIdxArray, status) { rm.ui.ribbon.refresh(); },
			serializeGridData: rm.grid.serializeGridData,
			loadComplete: function (data) {
				rm.grid.rowData.attachAllRowsData(ssvAttrNs.gridSelector, data);
				rm.ui.notes.bindNotesIconClick();
				ssvAttrNs.bindSsvWindowChangeIconClick();
				rm.ui.ribbon.refresh();
			},
			gridComplete: function () { setTimeout(ssvAttrNs.bindLabelQtip, 100); },
			resizeStop: function (newWidth, columnIndex) {
				//Becasue grid allows multiselect, it adds a checkbox column as a first column. To find out the column index in the colModel, subtract 1.
				//Not required for grids that don't show checkbox column
				columnIndex -= 1;
				var dataGridColumnId = rm.grid.getDataGridColumnIdFromColIndexColModelAndUserPref(columnIndex, columnModel, userColumnPreferences);
				rm.grid.saveDataGridColumnWidthPreference(newWidth, DataGrid.SsvAttribute, dataGridColumnId, ssvAttrNs.gridSelector);
			}
		});
		$(ssvAttrNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},
	handleCalculatorIconClick: function (requestId) {
		rm.grid.uncheckAllGridRows(ssvAttrNs.gridSelector);
		rm.grid.checkRowById(ssvAttrNs.gridSelector, requestId);

		setTimeout(function () { ssvAttrNs.editSelectedRow(); }, 20);
	},


	saveGrid: function () {
		rm.ui.messages.clearAllMessages();

		var rowsToSave = [];
		var rowsInEditMode = rm.grid.getRowsInEditMode(ssvAttrNs.gridSelector);

		$.each(rowsInEditMode, function (index, editedRow) {
			var qipBudgetedSites = $(rm.grid.getControlFromEditRow(ssvAttrNs.gridSelector, editedRow.id, "QipBudgetedSites"));

			if (rm.validation.range.validate(qipBudgetedSites)) {
				rowsToSave.push(rm.grid.getUpdatedRowDataById(ssvAttrNs.gridSelector, editedRow.id));
			}
			else {
				rm.ui.messages.showError("Please fix the errors and click Save again. Page will attempt to save the records with valid data.");
			}
		});

		if (rowsToSave.length > 0) {
			ssvAttrNs.saveData(rowsToSave, rowsInEditMode.length);
		}
	},
	saveSingleAttribute: function (gridSelector, rowId) {
		rm.ui.messages.clearAllMessages();
		var qipBudgetedSites = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "QipBudgetedSites"));

		if (rm.validation.range.validate(qipBudgetedSites)) {
			var rowToSave = rm.grid.getUpdatedRowDataById(gridSelector, rowId);
			ssvAttrNs.saveData([rowToSave], 1);
		}
		else {
			rm.ui.messages.showError("Please fix the errors and click Save again.");
		}
	},
	saveData: function (rowsToSave, totalRowsInEditMode) {
		if (rowsToSave.length > 0) {
			rm.ajax.attributeSvcAsyncPost("SaveSsvAttributes", { projectId: ssvAttrNs.getProjectId(), ssvAttributeDataList: rowsToSave }, function (serviceResponse) {
				var successCount = 0;
				$.each(serviceResponse.EntityStatus, function (index, response) {
					if (response.IsSuccessful) {
						successCount++;
						rm.grid.cancelRowEditMode(ssvAttrNs.gridSelector, response.EntityId);
						//Give it a split second so the row can go back to read-only mode
						setTimeout(function () {
							var rowData = rm.grid.rowData.getById(ssvAttrNs.gridSelector, response.EntityId);
							rowData.QipBudgetedSites.Value = response.Output.QipBudgetedSites;
							rowData.QipBudgetedSites.IsConnected = response.Output.IsQipBudgetedSitesConnected;

							$(ssvAttrNs.gridSelector).setCell(response.EntityId, "QipBudgetedSites", response.Output.QipBudgetedSites, "", "", true);
							rm.ui.ribbon.refresh();
						}, 50);
					} else {
						rm.validation.processErrorMessages(response.Errors, ssvAttrNs.gridSelector, "IconColumn");
					}
				});

				if (successCount === 0) {
					rm.ui.messages.showError("Errors found.  Nothing saved.");
				}
				else if (rowsToSave.length === successCount) {
					if (rowsToSave.length !== totalRowsInEditMode) {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showWarningWithCloseButton("Data saved with some errors found.");
					}
					else {
						rm.ui.messages.showSuccess(Resources.AllDataSavedSuccessfully);
					}
				}
				else {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showWarningWithCloseButton("Data saved with some errors found.");
				}
			});
		}
	},
	connectValueToQip: function (ssvAttributeId, columnName, connectedValue, saveSuccessFunction) {
		rm.ajax.attributeSvcAsyncPost("ConnectSingleSsvValueToQip", { ssvAttributeId: ssvAttributeId, columnName: columnName, connectedValue: connectedValue }, function (serviceResponse) {
			rm.ui.messages.showSuccess("Data saved successfully");
			if ($.isFunction(saveSuccessFunction)) { saveSuccessFunction(); }
		});
	},
	cancelGrid: function () {
		rm.ui.messages.clearAllMessages();
		rm.grid.cancelGridEditMode(ssvAttrNs.gridSelector, true);
		rm.ui.ribbon.delayedRefresh();
	},
};
