﻿
/// <reference path="../common/rmhelper.js" />
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });

	rm.runtimeValues.helpPageUrl = "Site-List.aspx";
	$("#Link_ProjectSiteList").addClass("left-static-selected-menu");
	rm.grid.bindEventsToResizeGrid(siteListNs.siteListGridSelector);
	siteListNs.init();
});

var siteListNs = {
	dataNotAvailable: "Not Available",
	hdnIsDteSchemaAlreadyConfiguredSelector: "[id$=hdnIsDteSchemaAlreadyConfigured]",
	hdnAllowEditSelector: "[id$=hdnAllowEdit]",
	hdnHasUserDefinedSchemaSelector: "[id$=hdnHasUserDefinedSchema]",
	siteListGridContainerSelector: "#gbox_tblSiteListData",
	siteListGridSelector: "#tblSiteListData",
	historyGridSelector: "#tblHistoryData",
	tierChangeReasonDialogSelector: "#tierChangeReasonDialog",
	visitEstimateDialogSelector: "#visitEstimateDialog",
	tierChangehistoryDialogSelector: "#divTierChangeHistory",
	txtTierChangeOtherReasonSelector: "#txtTierChangeOtherReason",
	generalComentsDialogSelector: "#divGeneralComments",
	taGeneralCommentsSelector: "#taGeneralComments",
	chkConfirmReasonReviewSelector: "#chkConfirmReasonReview",
	divOtherCommentsSelector: "#divOtherComments",
	initialTieringRunningSelector: "#hdnInitialTieringRunning",
	siteTieringButtonSelector: "[id*=InitialSiteTieringBtn]",
	startTierReviewButtonSelector: "[id*=StartTierReviewBtn]",
	completePeriodicTierReviewButtonSelector: "[id*=CompletePeriodicTierReviewBtn]",
	siteTieringSpinnerId: "SiteTieringSpinner",
	lblLastPeriodicReviewDateSelector: "[id$=lblLastPeriodicReviewDate]",
	getSiteTieringSpinnerSelector: function () { return "#" + siteListNs.siteTieringSpinnerId; },
	acceptRecommendedTierButtonSelector: "[id*=AcceptRecommendedTierBtn]",
	acceptRecommendedTierSpinnerId: "AcceptRecommendedTierSpinner",
	getAcceptRecommendedTierSpinnerSelector: function () { return "#" + siteListNs.acceptRecommendedTierSpinnerId; },
	selectedSitePctSelector: "#selectedSitePct",
	ProjectFirstSivPassedSelector: "#ProjectFirstSivPassed",
	gridPagerNavigationSelector: "#tblPager_center",
	divReviewInstructionsSelector: "#divReviewInstructions",
	tblVisitComparisonSelector: "#tblVisitComparison",
	divMultipleSitesSelector: "#divMultipleSites",
	cbNoReviewReasonSelector: "[type=checkbox][id$=cbNoReviewReason]",
	rbNoReviewReasonSelector: "[name=rbNoReviewReason]",
	getProjectId: function () { return $("[id$=hdnProjectId]").val(); },
	isDteProject: function () { return $("[id$=isDteProject]").val() === "1"; },
	isSchemaDefinedByUser: function () { return $("[id$=isSchemaDefinedByUser]").val() === "1"; },
	showNonRbmToRbmConversionWarning: function () {
		if ($("[id$=hdnIsRbmProjectManagedAsNonRbmInRm]").val() === "1") { rm.ui.messages.showWarningWithCloseButton(Resources.NonRbmToRbmConversion); }
	},
	allowInitialTiering: function () { return $("[id$=hdnAllowInitialTiering]").val() === "1"; },
	isRequiredTierEnabledForInitialSiteTiering: function () { return $("[id$=hdnIsRequiredTierEnabledForInitialSiteTiering]").val() === "1"; },
	isInitialSiteTieringAlreadyPerformed: function () { return $("[id$=hdnIsInitialSiteTieringAlreadyPerformed]").val() === "1"; },
	isInitialSiteTieringProcessRunning: function () { return $(siteListNs.initialTieringRunningSelector).val() === "1"; },
	showIntelligenceColumn: function () { return siteListNs.isDteProject(); },
	isPerformInitialSiteTieringEnabled: function () { return siteListNs.allowInitialTiering() && !siteListNs.isInitialSiteTieringProcessRunning() && !siteListNs.isApplyRecommendedTierProcessRunning() && !siteListNs.isCancelSiteIntelligenceTierReviewEnabled() },
	loggedInUserHasEditAccess: function () { return $(siteListNs.hdnAllowEditSelector).val() === "1"; },
	_siteIntelligenceTierReviewStarted: false,
	_applyRecommendedTierProcessRunning: false,
	isSiteIntelligenceTierReviewStarted: function () { return siteListNs._siteIntelligenceTierReviewStarted; },
	isApplyRecommendedTierProcessRunning: function () { return siteListNs._applyRecommendedTierProcessRunning; },
	hdnRecommendedTierReviewProcessStartedSelector: "[id$=hdnRecommendedTierReviewProcessStarted]",
	isCompletePeriodicTierReviewEnabled: function () { return siteListNs.isDteProject(); },

	monitoringTierList: [],
	pharmacyTierList: [],
	_projectDteSchema: null, //{	SiteMonitoringSchemaDetails: { TierList:[] },PharmacySchemaDetails: { TierList:[] } }

	fullTierList: [{ Key: "", Value: "" },
	{ Key: 1, Value: "1" },
	{ Key: 2, Value: "2" },
	{ Key: 3, Value: "3" },
	{ Key: 4, Value: "4" },
	{ Key: 5, Value: "5" },
	{ Key: 6, Value: "6" }],
	init: function () {
		siteListNs.showToolTipOnInitialSiteTieringButton();
		rm.qtip.showInfoOnGridColumn(siteListNs.startTierReviewButtonSelector, "Click to begin review of Site Tiering using Site Intelligence data.<br/><br/>This process should be performed regularly by the Clinical Lead team.<br/><br/>Changes made during this process will not be applied until the 'Apply Changes' option is selected.");
		rm.qtip.showInfoOnGridColumn("#infoIconProjectedVisits", "Includes both past and future CTMS actual visits, if any");
		rm.qtip.showInfoOnGridColumn("#infoIconCtmsCompleted", "CTMS-logged actual visits in the past");
		rm.qtip.showInfoOnGridColumn("#infoIconCtmsPlanned", "CTMS-logged planned visits in the future");
		rm.qtip.showInfoOnGridColumn("#infoIconRmProjected", "RM projected visits");
		rm.qtip.showInfoOnGridColumn("#infoIconProjectedTotal", "Total visits = CTMS Completed	+ CTMS Planned & RM Projected");
		rm.qtip.showInfoOnGridColumn("#infoIconEstimatedChange", "Estimated Change in # of Interim Monitoring Visits - if Recommended Tier is applied");
		rm.qtip.showInfoOnGridColumn("#infoIconEstimatedProjected", "Estimated Projected Interim Monitoring Visits, including CTMS actual visits - if Recommended Tier is applied");
		rm.qtip.showInfoOnGridColumn(siteListNs.completePeriodicTierReviewButtonSelector, "<b>Monthlty Tier Review Completed</b><br/>Click to tag the project as having just had a full Tier Review.");
		siteListNs.startInitialSiteTieringProcessMonitoring();
		siteListNs.addSpinnerOnSiteTieringButton();
		siteListNs.startApplyRecommendedTierProcessMonitoring();
		siteListNs.addSpinnerOnApplyRecommendedTierButton();
		siteListNs.initTierChangeDialogControls();

		if (siteListNs.getProjectId() != "") {
			if (siteListNs.isDteProject()) {
				$(siteListNs.divMultipleSitesSelector).height("148px").css("marginBottom", "5px");
				siteListNs.showMonitoringVisitSummaryTable();
			}
			siteListNs.getEnabledTierListFromPoject();
			siteListNs.buildSiteListGrid();
			if (siteListNs.isDteProject() && $(siteListNs.hdnHasUserDefinedSchemaSelector).val() === "0" && $(siteListNs.hdnIsDteSchemaAlreadyConfiguredSelector).val() === "1") {
				rm.ui.messages.addWarningAsBlock(Resources.UserDefinedSchemaMsg);
			}
		}
		siteListNs.bindKeypressOnGeneralComments();
		siteListNs.bindChangeOnReasonCheckboxes();
		siteListNs.showNonRbmToRbmConversionWarning();
	},
	getDteSchemaDetails: function () {
		if (siteListNs._projectDteSchema == null) {
			rm.ajax.projectSvcSyncPost("GetActiveTierConfigurationByProjectId", { projectId: siteListNs.getProjectId() }, function (serviceResponse) { siteListNs._projectDteSchema = serviceResponse; });
		}
		return siteListNs._projectDteSchema;
	},
	bindChangeOnReasonCheckboxes: function () {
		$(".reasonCb").change(function () {
			if ($(".reasonCb:checked").length == 0) {
				rm.ui.utilities.disableJqUiControl("#btnSaveTierChangeReasonDialog");
				$(siteListNs.chkConfirmReasonReviewSelector).prop("checked", false);
			}
			else {
				rm.ui.utilities.enableJqUiControl("#btnSaveTierChangeReasonDialog");
			}
		});
	},
	bindKeypressOnGeneralComments: function () {
		$(siteListNs.taGeneralCommentsSelector).bind("keyup", function () {
			var taComments = $(this);
			if (taComments.data("oldValue") == taComments.val()) {
				rm.ui.utilities.disableJqUiControl("#btnSaveGeneralComments");
			}
			else {
				rm.ui.utilities.enableJqUiControl("#btnSaveGeneralComments");
			}
		});
	},
	initTierChangeDialogControls: function () {
		$(siteListNs.tierChangeReasonDialogSelector + " [type=checkbox][isOther=1]").click(function () {
			if ($(this).is(":checked")) {
				$(siteListNs.divOtherCommentsSelector).show();
			} else {
				rm.validation.clearError(siteListNs.txtTierChangeOtherReasonSelector);
				$(siteListNs.txtTierChangeOtherReasonSelector).val("");
				$(siteListNs.divOtherCommentsSelector).hide();
			}
		});
	},
	getEnabledTierListFromPoject: function () {
		rm.ajax.projectSvcSyncPost("GetActiveTierListByProjectId", { projectId: siteListNs.getProjectId() }, function (serviceResponse) {
			siteListNs.monitoringTierList = serviceResponse.SiteMonitoringTierList;
			siteListNs.pharmacyTierList = serviceResponse.PharmacyTierList;
		});
		var emptyItem = { Key: "", Value: "" };
		siteListNs.monitoringTierList.splice(0, 0, emptyItem);
		siteListNs.pharmacyTierList.splice(0, 0, emptyItem);
	},
	addSpinnerOnSiteTieringButton: function () { rm.ui.ribbon.addHiddenWaitSpinner(siteListNs.siteTieringButtonSelector, siteListNs.siteTieringSpinnerId); },
	showSpinnerOnSiteTieringButton: function () { $(siteListNs.getSiteTieringSpinnerSelector()).show(); },
	hideSpinnerOnSiteTieringButton: function () { $(siteListNs.getSiteTieringSpinnerSelector()).hide(); },
	startInitialSiteTieringProcessMonitoring: function () {
		//Initial site tiering can be performed only once. Therefore if it is already performed for selected project, we don't need to monitori it again.
		if (!siteListNs.isInitialSiteTieringAlreadyPerformed()) {
			rm.utilities.checkIfProcessIsRunning(siteListNs.getProjectId(), Process_E.InitialSiteTiering, EntityType.Project, siteListNs.handleProcessMonitoringResponse);
		}
	},
	handleProcessMonitoringResponse: function (serviceResponse) {
		if (serviceResponse) {
			siteListNs.showSpinnerOnSiteTieringButton();
			$(siteListNs.initialTieringRunningSelector).val("1");
			rm.ui.ribbon.delayedRefresh();
		}
		else {
			siteListNs.hideSpinnerOnSiteTieringButton();
			if ($(siteListNs.initialTieringRunningSelector).val() !== "0") {
				$("[id$=hdnAllowInitialTiering]").val("0");
				$("[id$=hdnIsInitialSiteTieringAlreadyPerformed]").val("1");
				setTimeout(siteListNs.updateToolTipOnInitialSiteTieringButton, 10);
				message = "Initial Site Tiering has been performed successfully.";
				siteListNs.reloadSiteGrid();
				rm.ui.messages.showSuccess(message);
				alert(message);
			}
			$(siteListNs.initialTieringRunningSelector).val("0");
			rm.ui.ribbon.delayedRefresh();
		}
	},
	updateToolTipOnInitialSiteTieringButton: function () {
		var tooltipMessage = siteListNs.getToolTipForInitialSiteTieringButton();
		if (tooltipMessage !== "") {
			rm.qtip.showInfo($(siteListNs.siteTieringButtonSelector), tooltipMessage);
		}
	},
	handleTierChangeHistoryLinkClick: function () {
		siteListNs.populateSiteTierChangeHistoryGrid($(this).attr("siteId"));
	},
	validateAndSaveGeneralComments: function (siteId) {
		var isSuccessful = false;
		var comments = $.trim($(siteListNs.taGeneralCommentsSelector).val());
		if (comments.length > 1024) {
			rm.ui.messages.showError("General Comments cannot exceed 1024 characters. Found " + comments.length + " characters.");
		}
		else {
			rm.ui.messages.clearError();
			rm.ajax.projectSvcSyncPost("SaveSiteGeneralComments", { siteId: siteId, comments: comments }, function (serviceResponse) {
				isSuccessful = serviceResponse.IsSuccessful;
				if (isSuccessful) {
					rm.ui.messages.showSuccess("Comments have been saved successfully.");
				}
				else {
					rm.validation.processErrorMessages(serviceResponse.Errors, "", "");
				}
			});
		}
		return isSuccessful;
	},
	handleGeneralCommentsEditClick: function () {
		var siteId = $(this).attr("siteId");
		var gridRowData = rm.grid.rowData.getById(siteListNs.siteListGridSelector, siteId);
		var siteName = gridRowData.SiteName;
		$(siteListNs.taGeneralCommentsSelector).val(gridRowData.GeneralComments).data("oldValue", gridRowData.GeneralComments);

		var btnSave = {
			id: "btnSaveGeneralComments",
			text: "Save", click: function () {
				if (siteListNs.validateAndSaveGeneralComments(siteId)) {
					$(this).dialog("close");
					var comments = $.trim($(siteListNs.taGeneralCommentsSelector).val());
					$(siteListNs.siteListGridSelector).setRowData(siteId, { GeneralComments: comments });
					gridRowData.GeneralComments = comments;
					setTimeout(function () { $("tr#" + siteId).find(".editGenComments").click(siteListNs.handleGeneralCommentsEditClick); }, 20);
				}
			}
		};

		rm.ui.dialog.showModalWithButtons(siteListNs.generalComentsDialogSelector, "Edit General Comments - " + siteName, "", false, 300, 200, [btnSave, rm.ui.dialog.standardButtons.cancel]);
		setTimeout(function () { rm.ui.utilities.disableJqUiControl("#btnSaveGeneralComments"); }, 10);
	},
	showTierChangeHistoryLink: function (cellvalue, options, rowObject) {
		return $("<div>").append($("<a>", { siteId: rowObject.id, class: "historyLink", html: "<u>View</u>", href: "javascript:void('0');" })).html();
	},
	showTierDropDown: function (cellvalue, options, rowObject) {
		var tierList = options.colModel.name == "PharmacyTier" ? siteListNs.pharmacyTierList : siteListNs.monitoringTierList;
		var calculatorTypeId;

		if (rowObject.IsPpmCountryActive == "No") {
			if (tierList.length > 1) {
				return cellvalue == "0" ? "" : cellvalue;
			}
			else { return "N/A"; }
		}

		if (options.colModel.name == "FsiLsiTier") { calculatorTypeId = CalculatorType_E.IMV_Freq1_FPI_LPI; }
		else if (options.colModel.name == "LsiLsoTier") { calculatorTypeId = CalculatorType_E.IMV_Freq2_LPI_LPO; }
		else if (options.colModel.name == "LsoCovTier") { calculatorTypeId = CalculatorType_E.LSO_COV; }
		else {
			calculatorTypeId = CalculatorType_E.PharmacyMonitoring;
			if (!rowObject.HasPharmacyCountryCalculator) { tierList = []; }
		}

		if (tierList.length > 1) {
			if (siteListNs.isSiteIntelligenceTierReviewStarted() || siteListNs.isApplyRecommendedTierProcessRunning()) {
				return cellvalue == "0" ? "" : cellvalue;
			}
			else {
				if (siteListNs.loggedInUserHasEditAccess()) {
					return $("<div>").append(siteListNs.getTierDropdownJqObject(tierList, options.rowId, options.colModel.name, calculatorTypeId, cellvalue)).html();
				}
				else { return cellvalue == "0" ? "" : cellvalue; }
			}
		}
		else { return "N/A"; }
	},
	getTierDropdownJqObject: function (tierList, siteId, frequencyName, calculatorTypeId, oldTierId) {
		var ddl = $("<select>", { class: "tierDropdown", siteId: siteId, frequencyName: frequencyName, calculatorTypeId: calculatorTypeId, oldTierId: oldTierId });
		$.each(tierList, function (index, tierInfo) {
			if (tierInfo.Key != "" || (tierInfo.Key == "" && oldTierId == "0")) {
				var option = $("<option>", { value: tierInfo.Key, text: tierInfo.Value });
				if ((tierInfo.Key == oldTierId || (tierInfo.Key == "" && oldTierId == "0"))) {
					option.attr("selected", "selected");
				}
				ddl.append(option);
			}
		})
		return ddl;
	},
	showRecommendedTier: function (cellvalue, options, rowObject) {
		var isPharmacyTier = options.colModel.name == "RecommendedPharmacyTier";
		var areTiersDefined = (isPharmacyTier && siteListNs.pharmacyTierList.length > 1 && rowObject.HasPharmacyCountryCalculator) || (!isPharmacyTier && siteListNs.monitoringTierList.length > 1);

		if (rowObject.IsPpmCountryActive == "Yes") {
			if (areTiersDefined) {
				var infoIcon = "";
				if (rowObject.IsSiteCovInPast) { infoIcon = "<div class='infoIcon covInPast' style='padding-left: 5px;' />"; }
				if (cellvalue == "0") { return infoIcon; }
				else { return cellvalue + ((rowObject.IsSiteCovInPast) ? infoIcon : siteListNs.getCheckboxHtml(isPharmacyTier, cellvalue, options, rowObject)); }
			}
			else { return "N/A"; }
		}
		else {
			return " ";
		}
	},
	isTierEnabled: function (tier, isPharmacy) {
		var isEnabled = false;
		var activeTierList = isPharmacy ? siteListNs.pharmacyTierList : siteListNs.monitoringTierList;
		if (activeTierList.length > 1) {
			$.each(activeTierList, function (index, activeTier) { if (activeTier.Key.toString() == tier) { isEnabled = true; return false; } });
		}
		return isEnabled;
	},
	getCheckboxHtml: function (isPharmacy, cellvalue, options, rowObject) {
		var showCheckbox = false;
		var tierToCheck = 0;
		if (isPharmacy) {
			showCheckbox = rowObject.RecommendedPharmacyTier != rowObject.PharmacyTier && rowObject.HasPharmacyCountryCalculator;
			tierToCheck = rowObject.RecommendedPharmacyTier;
		}
		else {
			showCheckbox = rowObject.RecommendedSiteTier != rowObject.FsiLsiTier || rowObject.RecommendedSiteTier != rowObject.LsiLsoTier || rowObject.RecommendedSiteTier != rowObject.LsoCovTier;
			tierToCheck = rowObject.RecommendedSiteTier;
		}
		if (siteListNs.isSiteIntelligenceTierReviewStarted() && showCheckbox) {
			if (siteListNs.isTierEnabled(tierToCheck, isPharmacy)) {
				return "<input type='checkbox' class='cbTier' style='margin: 0px 5px;' isPharmacy='" + (isPharmacy ? "1" : "0") + "' siteId='" + options.rowId + "'>";
			}
			else {
				return $("<div>").append($("<img>", { class: "disabledTier", src: "/_layouts/SPUI/images/errorIcon.png", css: { "padding-left": "5px" } })).html();
			}
		}
		else { return ""; }
	},
	generalCommentsFormatter: function (cellvalue, options, rowObject) {
		if (siteListNs.loggedInUserHasEditAccess()) {
			return $("<div>").append($("<img>", { siteId: options.rowId, class: "editGenComments", src: "/_layouts/SPUI/images/iconEdit.png", css: { "cursor": "pointer", "padding-right": "5px", "float": "left", "width": "15px" } })).html() + cellvalue;
		}
		else { return cellvalue; }
	},
	intelCommentsFormatter: function (cellvalue, options, rowObject) {
		var message = (!siteListNs.isInitialSiteTieringAlreadyPerformed() ? "Initial Site Tiering has not been run for this Project.<br/><br/>" : "") + "<b>Initial Site Tiering:</b><br/><div style='margin-left:5px'>";
		if (!rowObject.HasIntelligenceData) {
			message += "No Site Intelligence Data is available from previous IQVIA Project use. Sites such as this are always placed in Tier 2 by the Initial Site Tiering process.";
		}
		else if (rowObject.QaStatus === "Reviewed") {
			message += "QA Status = '" + rowObject.QaStatus + "'<br/>Enrollment Score =" + rowObject.EnrollmentScore;
			if (rowObject.EnrollmentScore == 0) {
				message += "<br/><br/>Sites with a QA Status 'Reviewed' and Enrollment Score of 0 are always placed in Tier 5 by the Initial Site Tiering process.";
			}
		}
		else {
			message += "QA Status = '" + rowObject.QaStatus + "'<br/>Enrollment Score =" + rowObject.EnrollmentScore + "<br/><br/>Sites with a QA Status other than 'Reviewed' are always placed in Tier 2 by the Initial Site Tiering process.";
		}

		message += "</div><br/><b>Site Intelligence Review:</b><br/><div style='margin-left:5px'><i>Included in recommendation calculations:</i><br/><div style='margin-left:10px'>";
		message += "Enrollment Score: " + (rowObject.CurrentEnrollmentScore == null ? siteListNs.dataNotAvailable : rowObject.CurrentEnrollmentScore) + "<br/>";
		message += "Overdue action items: " + (rowObject.OverDueActionItems == null ? siteListNs.dataNotAvailable : rowObject.OverDueActionItems) + "<br/>";
		message += "Protocol deviations: " + (rowObject.ProtocolDeviations == null ? siteListNs.dataNotAvailable : rowObject.ProtocolDeviations) + "<br/>";
		message += "Adverse events: " + (rowObject.AdverseEvents == null ? siteListNs.dataNotAvailable : rowObject.AdverseEvents) + "<br/>";
		message += "Serious adverse events: " + (rowObject.SeriousAdverseEvents == null ? siteListNs.dataNotAvailable : rowObject.SeriousAdverseEvents) + "<br/>";
		message += "Query rate: " + (rowObject.QueryRate == null ? siteListNs.dataNotAvailable : (rowObject.QueryRate * 100).toFixed(2) + "%") + "<br/>";
		message += "Screen failure rate: " + (rowObject.ScreenFailureRate == null ? siteListNs.dataNotAvailable : (rowObject.ScreenFailureRate * 100).toFixed(2) + "%") + "<br/>";
		message += "Dropout Rate: " + (rowObject.DropoutRate == null ? siteListNs.dataNotAvailable : (rowObject.DropoutRate * 100).toFixed(2) + "%") + "<br/>";
		message += "SDV Backlog Days On Site:: " + siteListNs.getDaysOnsiteFromSdvBacklogTitle(rowObject.SdvBacklogEventTitle) + "<br/>";

		message += "</div><br/><i>Not included - For information only:</i><br/><div style='margin-left:10px'>";
		message += "SDV Backlog Severity: " + ($.trim(rowObject.SdvBacklogEventSeverity) == "" ? siteListNs.dataNotAvailable : rowObject.SdvBacklogEventSeverity) + "<br/>";
		message += "SDV Backlog Date: " + ($.trim(rowObject.SdvBacklogEventReceiveDate) == "" ? siteListNs.dataNotAvailable : rowObject.SdvBacklogEventReceiveDate) + "<br/>";
		message += "SDV Backlog Title: " + ($.trim(rowObject.SdvBacklogEventTitle) == "" ? siteListNs.dataNotAvailable : rowObject.SdvBacklogEventTitle) + "<br/>";
		message += "</div></div>";
		return $("<div>").append($("<span>", { toolTipMessage: message, siteId: options.rowId, class: "intelMsg infoIcon" })).html();
	},
	renderFTEError: function (cellvalue, options, rowObject) {
		var message = "The Active Frequency cannot be determined.<br/>";
		message += "</div><br/>This may be due to one or more of the following reasons:<br/><div style='margin-left:4px'>";
		message += "1.An unexpected sequence of PPM Project<span style='margin-left:10px'> milestones<br/>";
		message += "2.Missing PPM Project milestones<br/>";
		message += "3.An unexpected sequence of PPM Country<span style='margin-left:11px'> milestones<br/>";
		message += "4.Incorrect CTMS site milestone dates<br/>";
		message += "5.Incorrect CTMS visit dates";
		message += "</div></div>";
		return (rowObject.ActiveMonFreq != 'UNKNOWN') ? rowObject.ActiveMonFreq :
			$("<div>").append($("<span>", { toolTipMessage: message, siteId: options.rowId, text: rowObject.ActiveMonFreq, class: "intelMsg" })).html();
	},
	getDaysOnsiteFromSdvBacklogTitle: function (sdvBacklogEventTitle) {
		if ($.trim(sdvBacklogEventTitle) == "") { return siteListNs.dataNotAvailable; }
		else {
			var matches = sdvBacklogEventTitle.match(/.*\/ *(.*?) *days.*/);
			return (matches.length == 2) ? matches[1] : siteListNs.dataNotAvailable;
		}
	},
	showChangeInOnsiteImvNumberOfVisits: function (cellvalue, options, rowObject) { return (rowObject.RecommendedSiteTier != rowObject.FsiLsiTier || rowObject.RecommendedSiteTier != rowObject.LsiLsoTier || rowObject.RecommendedSiteTier != rowObject.LsoCovTier) ? siteListNs.getValueOrBlankWhenCovIsInPast(rowObject.DeltaSiteMonitoringVisits, rowObject) : ""; },
	showChangeInRemoteNumberOfVisits: function (cellvalue, options, rowObject) { return (rowObject.RecommendedSiteTier != rowObject.FsiLsiTier || rowObject.RecommendedSiteTier != rowObject.LsiLsoTier || rowObject.RecommendedSiteTier != rowObject.LsoCovTier) ? siteListNs.getValueOrBlankWhenCovIsInPast(rowObject.DeltaRemoteVisits, rowObject) : ""; },
	showChangeInPharmacyNumberOfVisits: function (cellvalue, options, rowObject) { return (rowObject.HasPharmacyCountryCalculator && rowObject.RecommendedPharmacyTier != rowObject.PharmacyTier) ? siteListNs.getValueOrBlankWhenCovIsInPast(rowObject.DeltaPharmacyVisits, rowObject) : ""; },
	getValueOrBlankWhenCovIsInPast: function (value, rowObject) { return rowObject.IsSiteCovInPast ? "" : value; },

	getFullColumnModelList: function () {
		return [
			{ name: 'TieringCompletionStatus', index: 'TieringCompletionStatus', hidden: !siteListNs.isDteProject(), label: 'Tiering<br/>Completion<br/>Status', width: 75, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.completeIncomplete } },
			{ name: 'City', index: 'City', label: 'City', width: 100, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'SponsorSite', index: 'SponsorSite', label: 'Sponsor<br/>Site', width: 52, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'SiteStatus', index: 'SiteStatus', label: 'Site Status', width: 95, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.getFiltersFromDictionary(SiteStatus) } },
			{ name: 'PiName', index: 'PiName', label: 'PI Name', width: 96, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Region', index: 'Region', label: 'Region', width: 60, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Country', index: 'Country', label: 'Country', width: 60, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'IsPpmCountryActive', index: 'IsPpmCountryActive', label: 'Is Country<br/>Active<br/>in PPM', sortable: true, align: 'center', width: 70, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.yesNo } },
			{ name: 'FsiLsiTier', index: 'FsiLsiTier', hidden: !siteListNs.isDteProject(), label: 'FSI-LSI<br/>Tier', align: 'center', width: 50, formatter: siteListNs.showTierDropDown, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.getFiltersFromArray(siteListNs.monitoringTierList) } },
			{ name: 'LsiLsoTier', index: 'LsiLsoTier', hidden: !siteListNs.isDteProject(), label: 'LSI-LSO<br/>Tier', align: 'center', width: 53, formatter: siteListNs.showTierDropDown, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.getFiltersFromArray(siteListNs.monitoringTierList) } },
			{ name: 'LsoCovTier', index: 'LsoCovTier', hidden: !siteListNs.isDteProject(), label: 'LSO-COV<br/>Tier', align: 'center', width: 57, formatter: siteListNs.showTierDropDown, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.getFiltersFromArray(siteListNs.monitoringTierList) } },
			{ name: 'RecommendedSiteTier', index: 'RecommendedSiteTier', hidden: !siteListNs.isDteProject(), label: 'Recommended<br/>Site<br/>Tier', align: 'center', width: 93, formatter: siteListNs.showRecommendedTier, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.getFiltersFromArray(siteListNs.fullTierList) } },
			{ name: 'ChangeInNumberOfOnsiteImvVisits', index: 'ChangeInNumberOfOnsiteImvVisits', hidden: true, sortable: false, search: false, label: 'Estimated<br/>Change<br/>in # of<br/>Onsite<br/>IMV Visits', align: 'center', width: 65, formatter: siteListNs.showChangeInOnsiteImvNumberOfVisits, classes: 'changeInVisitTd disabledText siteChange imvChange' },
			{ name: 'ChangeInNumberOfRemoteVisits', index: 'ChangeInNumberOfRemoteVisits', hidden: true, sortable: false, search: false, label: 'Estimated<br/>Change<br/>in # of<br/>Remote<br/>Visits', align: 'center', width: 56, formatter: siteListNs.showChangeInRemoteNumberOfVisits, classes: 'changeInVisitTd disabledText siteChange remoteChange' },
			{ name: 'PharmacyTier', index: 'PharmacyTier', hidden: !siteListNs.isDteProject(), label: 'Pharmacy<br/>Tier', align: 'center', width: 67, formatter: siteListNs.showTierDropDown, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.getFiltersFromArray(siteListNs.pharmacyTierList) } },
			{ name: 'RecommendedPharmacyTier', index: 'RecommendedPharmacyTier', hidden: !siteListNs.isDteProject(), label: 'Recommended<br/>Pharmacy<br/>Tier', align: 'center', width: 93, formatter: siteListNs.showRecommendedTier, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.getFiltersFromArray(siteListNs.fullTierList) } },
			{ name: 'ChangeInNumberOfPharmacyVisits', index: 'ChangeInNumberOfPharmacyVisits', hidden: true, sortable: false, search: false, label: 'Estimated<br/>Change<br/>in # of<br/>Pharmacy<br/>Visits', align: 'center', width: 66, formatter: siteListNs.showChangeInPharmacyNumberOfVisits, classes: 'changeInVisitTd disabledText pharmacyChange' },
			{ name: 'Intel', index: 'Intel', label: 'Intel', hidden: !siteListNs.showIntelligenceColumn(), align: 'center', width: 33, sortable: false, search: false, formatter: siteListNs.intelCommentsFormatter },
			{ name: 'IsSiteActive', index: 'IsSiteActive', label: 'Is Site<br/>Active', align: 'center', width: 43, stype: 'select', searchoptions: { sopt: ['cn'], value: rm.grid.filterOptions.yesNo } },
			{ name: 'GeneralComments', index: 'GeneralComments', label: 'General<br/> Comments', width: 230, sortable: false, search: false, formatter: siteListNs.generalCommentsFormatter },
			{ name: 'TierChangeHistory', index: 'TierChangeHistory', hidden: !siteListNs.isDteProject(), label: 'Tier<br/>Change<br/>History', align: 'center', width: 60, sortable: false, search: false, formatter: siteListNs.showTierChangeHistoryLink },
			{ name: 'ActiveMonFreq', index: 'ActiveMonFreq', label: 'Active<br />Frequency', hidden: !siteListNs.isDteProject(), width: 77, formatter: siteListNs.renderFTEError, stype: 'select', searchoptions: { value: rm.grid.filterOptions.activeMonFrequency } }

		];
	},
	handleUserPreferencesResponse: function (userColumnPreferences) {
		//var columnModel = rm.grid.getColumnModelFromUserPreferences(siteListNs.getFullColumnModelList(), userColumnPreferences);
		var columnModel = rm.grid.getFinalColumnModelFromFullColumnListAndUserColumnPreferences(siteListNs.getFullColumnModelList(), userColumnPreferences);

		siteListNs.buildDynamicSiteListGrid(columnModel, userColumnPreferences);
	},
	buildSiteListGrid: function () {
		rm.serviceCalls.getRmUserDataGridColumnPreferences(DataGrid.SiteList, siteListNs.handleUserPreferencesResponse)
	},
	buildDynamicSiteListGrid: function (columnModel, userColumnPreferences) {
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ProjectSiteList, dataGridId: DataGrid.SiteList };
		gridToolsConfig.manageColumnsParameters = userColumnPreferences;
		rm.grid.showGridTools(siteListNs.siteListGridSelector, gridToolsConfig);

		var gridPostData = { ProjectId: siteListNs.getProjectId(), LoadSitesForAcceptingRecommendedTiers: false };

		$(siteListNs.siteListGridSelector).jqGrid({
			url: rm.ajax.projectSvcUrl + "GetSitesByProject",
			datatype: 'json',
			mtype: 'POST',
			postData: gridPostData,
			ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			loadonce: false,
			shrinkToFit: false,
			autowidth: true,
			height: window.screen.height - 465,
			width: window.screen.width - 216,
			forceFit: true,
			pager: '#tblPager',
			multiselect: false,
			colModel: columnModel,
			viewsortcols: [true, 'vertical', true],
			sortname: 'Country',
			sortorder: 'asc',
			gridComplete: function () {
				var tierColumnTooltip = "The Initial Site Tiering option may be used (once per project) to assign these Sites to Tiers, or you may set each Site's Tiers individually, selecting from Tiers enabled in the RBM Schema page.<br/><br/>If a Site's Initiation Visit has already occurred, you will be prompted for your reason(s) for changing the Tier.";
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_TieringCompletionStatus", "The Pharmacy column is Not Applicable to Projects where Pharmacy is not Enabled in the RBM Schema<br/><br/>If a Project is Pharmacy-Enabled, but a Country has not had its Pharmacy Monitoring FTE tab added, then that Country's Sites with a blank Pharmacy Tier display a 'Pharmacy Calculator Not Added' notice");
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_SiteStatus", "CTMS Site Status");
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_FsiLsiTier", tierColumnTooltip);
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_LsiLsoTier", tierColumnTooltip);
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_LsoCovTier", tierColumnTooltip);
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_ActiveMonFreq", "Current active visit frequency for each site");
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_PharmacyTier", tierColumnTooltip + "<br/><br/>Pharmacy Tier cannot be changed when RBM Pharmacy schema is not enabled from Project Configuration page.");
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_GeneralComments", "Click the pencil icon to edit Comments");
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_Intel", "Historical-project Site Intelligence used by the Initial Site Tiering process, and current-project Site Intelligence used to generate Recommended Site Tiers.");
				$.each($(".intelMsg"), function (index, ele) { rm.qtip.showInfo($(ele), $(ele).attr("toolTipMessage")); });
				$.each($(".covInPast"), function (index, ele) { rm.qtip.showInfo($(ele), "This Site has passed its Close Out Visit date. No visits are projected at all for such sites, so there is no Estimated Change in visits when you change their Tier"); });
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_TierChangeHistory", "Click ‘View’ to see Tier changes made to a Site after its Initiation Visit. Tier changes made prior to a Site Initiation Visit are not logged.");

				rm.qtip.showInfoOnGridColumn("#tblSiteListData_RecommendedSiteTier", "Recommended Tier for this Site.<br/><br/>Based on Site Intelligence data for this Site (which includes its enrollment on this project & its Key Risk Indicators) and on the RBM Schema's Target Site Percentages for each Tier.<br/><br/>The project team may choose not to use the Recommended Tier.");
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_RecommendedPharmacyTier", "Recommended Tier for this Site.<br/><br/>Based on Site Intelligence data for this Site (which includes its enrollment on this project & its Key Risk Indicators) and on the RBM Schema's Target Site Percentages for each Tier.<br/><br/>The project team may choose not to use the Recommended Tier.");

				rm.qtip.showInfoOnGridColumn("#tblSiteListData_ChangeInNumberOfOnsiteImvVisits", "Estimated change in # of Onsite IMV Visits are calculated from today, site FSI date  or last onsite CTMS visit, whichever is later. Current projected visits are compared to an estimate of future visits based on remaining duration and visit frequency for Recommended Tier.");
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_ChangeInNumberOfRemoteVisits", "Estimated change in # of Remote IMV Visits are calculated from today, site FSI date  or last onsite CTMS visit, whichever is later. Current projected visits are compared to an estimate of future visits based on remaining duration and visit frequency for Recommended Tier.");
				rm.qtip.showInfoOnGridColumn("#tblSiteListData_ChangeInNumberOfPharmacyVisits", "Estimated change in # of Pharmacy Visits are calculated from today, site FSI date  or last onsite CTMS visit, whichever is later. Current projected visits are compared to an estimate of future visits based on remaining duration and visit frequency for Recommended Tier.");

				rm.qtip.showInfoOnGridColumn("#tblSiteListData_IsPpmCountryActive", "When a Country's tasks are marked as Inactive in QRPM: PPM:<br/><br/>No Interim Monitoring Visits will be projected by RM for any Site in this Country.<br/><br/>RM will continue to project a Close-Out Visit in site monitoring Requests for this Country.<br/><br/>RM has automatically Terminated or Deleted all 'SSV Site Level' Requests for this Country.<br/><br/>Visits may have been been booked in CTMS for the Site.<br/><br/>The Site should be marked as [Status] = 'Closed' in CTMS to automatically Terminate its open Requests.");

				$.each($(".disabledTier"), function (index, ele) { rm.qtip.showInfo($(ele), "You are not able to accept this tier because it is not enabled in RBM Schema tab of Project Configuration page."); });
				siteListNs.bindCbTierClick();
				siteListNs.resetSummaryTable();
			},
			serializeGridData: rm.grid.serializeGridData,
			beforeRequest: function () { rm.grid.setHeaderRowHeightFiveLine("tblSiteListData"); },
			loadComplete: function (data) {
				rm.grid.rowData.attachAllRowsData(siteListNs.siteListGridSelector, data);
				$(".tierDropdown").change(siteListNs.handleTierChange).click(function () { $("tr#" + $(this).attr("siteId")).click(); });
				$(".historyLink").click(siteListNs.handleTierChangeHistoryLinkClick);
				$(".editGenComments").click(siteListNs.handleGeneralCommentsEditClick);
				if (siteListNs.isSiteIntelligenceTierReviewStarted()) {
					$(siteListNs.siteListGridSelector).jqGrid('showCol', 'ChangeInNumberOfOnsiteImvVisits');
					$(siteListNs.siteListGridSelector).jqGrid('showCol', 'ChangeInNumberOfRemoteVisits');
					$(siteListNs.siteListGridSelector).jqGrid('showCol', 'ChangeInNumberOfRemoteVisits');
					$(siteListNs.siteListGridSelector).jqGrid('showCol', 'ChangeInNumberOfPharmacyVisits');
					$(siteListNs.siteListGridSelector).jqGrid('hideCol', 'TieringCompletionStatus');
					$(siteListNs.siteListGridSelector).jqGrid('hideCol', 'IsSiteActive');
				}
				else {
					$(siteListNs.siteListGridSelector).jqGrid('hideCol', 'ChangeInNumberOfOnsiteImvVisits');
					$(siteListNs.siteListGridSelector).jqGrid('hideCol', 'ChangeInNumberOfRemoteVisits');
					$(siteListNs.siteListGridSelector).jqGrid('hideCol', 'ChangeInNumberOfPharmacyVisits');
					if (siteListNs.isDteProject()) {
						$(siteListNs.siteListGridSelector).jqGrid('showCol', 'TieringCompletionStatus');
					}
					$(siteListNs.siteListGridSelector).jqGrid('showCol', 'IsSiteActive');
				}
				$("[aria-describedby=tblSiteListData_FsiLsiTier],[aria-describedby=tblSiteListData_PharmacyTier],[aria-describedby=tblSiteListData_Intel]").css({ "border-left-width": "2px", "border-left-style": "solid", "border-left-color": "inherit" })
			},
			resizeStop: function (newWidth, columnIndex) {
				var dataGridColumnId = rm.grid.getDataGridColumnIdFromColIndexColModelAndUserPref(columnIndex, columnModel, userColumnPreferences);
				rm.grid.saveDataGridColumnWidthPreference(newWidth, DataGrid.SiteList, dataGridColumnId, siteListNs.siteListGridSelector);
			}
		});
		$(siteListNs.siteListGridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true, defaultSearch: "cn" });
	},
	handleTierChange: function () {
		var tierDropdown = $(this);
		var siteId = tierDropdown.attr("siteId");
		var calculatorTypeId = tierDropdown.attr("calculatorTypeId");
		siteListNs.showVisitEstimateDialog(siteId, calculatorTypeId, tierDropdown.attr("frequencyname"), tierDropdown.val());
	},
	getFrequencyNameAndCurrentTierFromCalculatorTypeId: function (rowData, calculatorTypeId) {
		switch (calculatorTypeId) {
			case "3": return { FrequencyName: "FSI-LSI", CurrentTier: rowData.FsiLsiTier == "0" ? siteListNs.dataNotAvailable : rowData.FsiLsiTier };
			case "4": return { FrequencyName: "LSI-LSO", CurrentTier: rowData.LsiLsoTier == "0" ? siteListNs.dataNotAvailable : rowData.LsiLsoTier };
			case "17": return { FrequencyName: "LSO-COV", CurrentTier: rowData.LsoCovTier == "0" ? siteListNs.dataNotAvailable : rowData.LsoCovTier };
			case "8": return { FrequencyName: "Pharmacy", CurrentTier: rowData.PharmacyTier == "0" ? siteListNs.dataNotAvailable : rowData.PharmacyTier };
			default: return { FrequencyName: siteListNs.dataNotAvailable, CurrentTier: siteListNs.dataNotAvailable };
		}
	},
	getRowDataPropertyNameByCalculatorTypeId: function (calculatorTypeId) {
		switch (calculatorTypeId) {
			case "3": return "FsiLsiTier";
			case "4": return "LsiLsoTier";
			case "17": return "LsoCovTier";
			case "8": return "PharmacyTier";
			default: return siteListNs.dataNotAvailable;
		}
	},
	getGetFrequencyStartStopDatesByCalculatorTypeId: function (rowData, calculatorTypeId) {
		switch (calculatorTypeId) {
			case "3": return { StartDate: rowData.SiteFsiDate, StopDate: rowData.SiteLsiDate };
			case "4": return { StartDate: rowData.SiteLsiDate, StopDate: rowData.SiteLsoDate };
			case "17": return { StartDate: rowData.SiteLsoDate, StopDate: rowData.SiteCovDate };
			case "8": return { StartDate: rowData.SiteFsiDate, StopDate: rowData.SiteCovDate };
			default: return { StartDate: null, StopDate: null };
		}
	},
	showVisitEstimateDialog: function (siteId, calculatorTypeId, frequencyName, newTier) {
		siteListNs.resetSummaryTableToZero();
		var rowData = rm.grid.rowData.getById(siteListNs.siteListGridSelector, siteId);

		var saveClicked = false;
		var closeHandler = function () {
			//unbind dialogclose doesn't work in this scenario. Hence using a variable to track if save button was clicked.
			if (!saveClicked) {
				//give split second for save to update the values before restoring value
				setTimeout(function () {
					siteListNs.handleTierChangeDialogClose(siteId, calculatorTypeId);
				}, 10);
			}
		};

		var btnSave = {
			id: "btnSaveVisitEstimateDialog",
			text: "Continue", click: function () {
				thisDialog = $(this);
				siteListNs.getTierDrowdownBySiteIdAndCalculatorTypeId(siteId, calculatorTypeId).val($("#newTierFromVisitEstimate").val());
				saveClicked = true;//unbind dialogclose doesn't work in this scenario. Hence using a variable to track if save button was clicked.
				setTimeout(function () {
					siteListNs.visitEstimateDialogOkClick(siteId, calculatorTypeId);
					thisDialog.dialog("close");
				}, 10);
			}
		};
		var frequencyNameAndTier = siteListNs.getFrequencyNameAndCurrentTierFromCalculatorTypeId(rowData, calculatorTypeId);
		$("#reviewSponsorSite").text(rowData.SponsorSite);
		$("#reviewSiteStatus").text(rowData.SiteStatus);
		$("#reviewPiName").text(rowData.PiName);
		$("#reviewRegion").text(rowData.Region);
		$("#reviewCountry").text(rowData.Country);
		$("#reviewFrequencyName").text(frequencyNameAndTier.FrequencyName);
		$("#reviewCurrentTier").text(frequencyNameAndTier.CurrentTier);
		$("#reviewRecommendedTier").text(rowData.RecommendedSiteTier == "0" ? siteListNs.dataNotAvailable : rowData.RecommendedSiteTier);

		var tierList = (calculatorTypeId == CalculatorType_E.PharmacyMonitoring) ? siteListNs.pharmacyTierList : siteListNs.monitoringTierList;
		var tierDropdown = siteListNs.getTierDropdownJqObject(tierList, siteId, frequencyName, calculatorTypeId, newTier);
		tierDropdown.attr("id", "newTierFromVisitEstimate").change(siteListNs.handleSingleSiteTierChangeEvent);
		tierDropdown.find("option[value=" + frequencyNameAndTier.CurrentTier.replace(" ", "") + "]").remove();
		siteListNs.handleSingleSiteTierChangeEvent.apply(tierDropdown);

		$("#tdNewTier").html("").append(tierDropdown);
		$("#divSingleSite").append($(siteListNs.tblVisitComparisonSelector));
		siteListNs.showHideReviewOnlyColumnsFromMonitoringVisitSummaryTable(true);

		rm.ui.dialog.showModalWithButtonsAndCloseHandler(siteListNs.visitEstimateDialogSelector, "Update Site Tier - " + siteListNs.getSiteName(siteId), "", false, 500, 470, [btnSave, rm.ui.dialog.standardButtons.cancel], closeHandler);
	},
	handleSingleSiteTierChangeEvent: function () {
		var tierDropdown = $(this);
		var visitCountChangeSummary = {
			EstimatedOnsiteImvVisitCountChange: 0,
			EstimatedRemoteVisitCountChange: 0,
			EstimatedPharmacyVisitCountChange: 0
		};

		var calculatorTypeId = tierDropdown.attr("calculatorTypeId");
		var isPharmacy = (calculatorTypeId == CalculatorType_E.PharmacyMonitoring.toString());
		var siteId = tierDropdown.attr("siteid")
		var rowData = rm.grid.rowData.getById(siteListNs.siteListGridSelector, siteId);
		var frequencyNameAndTier = siteListNs.getFrequencyNameAndCurrentTierFromCalculatorTypeId(rowData, calculatorTypeId);

		var currentTierConfig = siteListNs.getTierConfigurationByTierId(frequencyNameAndTier.CurrentTier, isPharmacy);
		var newTierConfig = siteListNs.getTierConfigurationByTierId(tierDropdown.val(), isPharmacy);
		var frequencyStartStopDate = siteListNs.getGetFrequencyStartStopDatesByCalculatorTypeId(rowData, calculatorTypeId);

		if (isPharmacy) {
			var currentVisitCount = siteListNs.getEstimatedVisitCount(currentTierConfig, false, frequencyStartStopDate.StartDate, frequencyStartStopDate.StopDate);
			var newVisitCount = siteListNs.getEstimatedVisitCount(newTierConfig, false, frequencyStartStopDate.StartDate, frequencyStartStopDate.StopDate);
			visitCountChangeSummary.EstimatedPharmacyVisitCountChange = newVisitCount - currentVisitCount;

			siteListNs.showPharmacyMonitoringVisitCountSummary(visitCountChangeSummary);
		}
		else {
			var currentVisitCount = siteListNs.getEstimatedVisitCount(currentTierConfig, false, frequencyStartStopDate.StartDate, frequencyStartStopDate.StopDate);
			var newVisitCount = siteListNs.getEstimatedVisitCount(newTierConfig, false, frequencyStartStopDate.StartDate, frequencyStartStopDate.StopDate);
			visitCountChangeSummary.EstimatedOnsiteImvVisitCountChange = newVisitCount - currentVisitCount;

			currentVisitCount = siteListNs.getEstimatedVisitCount(currentTierConfig, true, frequencyStartStopDate.StartDate, frequencyStartStopDate.StopDate);
			newVisitCount = siteListNs.getEstimatedVisitCount(newTierConfig, true, frequencyStartStopDate.StartDate, frequencyStartStopDate.StopDate);
			visitCountChangeSummary.EstimatedRemoteVisitCountChange = newVisitCount - currentVisitCount;

			siteListNs.showSiteMonitoringVisitCountSummary(visitCountChangeSummary);
		}


	},
	getTierConfigurationByTierId: function (tierId, isPharmacy) {
		var tier = null;
		var projectDteConfig = siteListNs.getDteSchemaDetails();
		var tierConfigList = isPharmacy ? projectDteConfig.PharmacySchemaDetails : projectDteConfig.SiteMonitoringSchemaDetails;
		$.each(tierConfigList.TierList, function (index, tierConfig) {
			if (tierConfig.TierName == tierId) { tier = tierConfig; }
		});
		return tier;
	},
	getEstimatedVisitCount: function (tierConfiguration, isRemoteVisit, startDate, stopDate) {
		var estimatedVisitCount = 0;

		if (tierConfiguration != null && $.trim(startDate) != "" && $.trim(stopDate) != "") {
			var startDt = eval(startDate.replace("/", "new ").replace("/", ""));
			var stopDt = eval(stopDate.replace("/", "new ").replace("/", ""));
			if (startDt < Date.now()) { startDt = Date.now(); }

			if (tierConfiguration.TierCycle > 0 && startDt < stopDt) {
				estimatedVisitCount = (((stopDt - startDt) / rm.time.getMillisecondsFromDays(7)) / tierConfiguration.TierCycle) * (isRemoteVisit ? tierConfiguration.RemoteVisitRatio : tierConfiguration.OnSiteVisitRatio);
			}
		}
		return Math.ceil(estimatedVisitCount);
	},
	visitEstimateDialogOkClick: function (siteId, calculatorTypeId) {
		var rowData = rm.grid.rowData.getById(siteListNs.siteListGridSelector, siteId);
		if (rowData.AskReasonForChange) {
			siteListNs.showTierChangeDialog(siteId, calculatorTypeId);
		}
		else {
			siteListNs.saveTierChangeWithoutChangeReason(siteId, calculatorTypeId);
			siteListNs.handleTierChangeDialogClose(siteId, calculatorTypeId);
		}
	},
	saveTierChangeWithoutChangeReason: function (siteId, calculatorTypeId) {
		siteListNs.saveTierChange({
			ProjectId: siteListNs.getProjectId(),
			SiteId: siteId,
			CalculatorTypeId: calculatorTypeId,
			TierId: siteListNs.getTierDrowdownBySiteIdAndCalculatorTypeId(siteId, calculatorTypeId).val()
		}, true, false);
	},
	getTierDrowdownBySiteIdAndCalculatorTypeId: function (siteId, calculatorTypeId) {
		return $(siteListNs.siteListGridSelector + " tr#" + siteId).find("select[calculatorTypeId=" + calculatorTypeId + "]");
	},
	handleTierChangeDialogClose: function (siteId, calculatorTypeId) {
		siteListNs.showHideReviewOnlyColumnsFromMonitoringVisitSummaryTable(false);
		$(siteListNs.divMultipleSitesSelector).append($(siteListNs.tblVisitComparisonSelector));
		siteListNs.restoreOldTierValue(siteId, calculatorTypeId);
		rm.ui.messages.clearError();
	},
	restoreOldTierValue: function (siteId, calculatorTypeId) {
		var tierDropdown = siteListNs.getTierDrowdownBySiteIdAndCalculatorTypeId(siteId, calculatorTypeId);
		tierDropdown.val(tierDropdown.attr("oldTierId"));
	},
	setTierValue: function (siteId, calculatorTypeId, tierId) {
		siteListNs.getTierDrowdownBySiteIdAndCalculatorTypeId(siteId, calculatorTypeId).val(tierId);
	},
	saveTierChange: function (postData, restoreOldValueOnError, tierChangeReasonRequired) {
		rm.ajax.projectSvcSyncPost("UpdateSingleSiteTier", { siteTierChangeInfo: postData }, function (serviceResponse) {
			if (serviceResponse.IsSuccessful) {
				siteListNs.refreshMonitoringVisitSummaryTable();
				if (tierChangeReasonRequired) {
					rm.ui.messages.showSuccess("Tier has been updated successfully");
				}
				else {
					rm.ui.messages.showSuccess("Since Site Initiation Visit has not been performed for the site, tier has been immediately saved.");
				}
				siteListNs.getTierDrowdownBySiteIdAndCalculatorTypeId(postData.SiteId, postData.CalculatorTypeId).attr("oldTierId", postData.TierId).find("option[value=]").remove();
				siteListNs.updateGridRowData(postData);
			}
			else {
				if (restoreOldValueOnError) { siteListNs.restoreOldTierValue(postData.SiteId, postData.CalculatorTypeId); }
				rm.validation.processErrorMessages(serviceResponse.Errors, siteListNs.siteListGridSelector, "");
			}
		});
	},
	updateGridRowData: function (postData) {
		//update completion status in the grid column when number of dropdowns match the number of dropdown wtih selected value other than blank
		if ($("tr#" + postData.SiteId + " .tierDropdown option[value!=]:selected").length == $("tr#" + postData.SiteId + " .tierDropdown").length) {
			$(siteListNs.siteListGridSelector).setRowData(postData.SiteId, { TieringCompletionStatus: "Complete" });
		}

		var rowData = rm.grid.rowData.getById(siteListNs.siteListGridSelector, postData.SiteId);
		var rowDataPropertyName = siteListNs.getRowDataPropertyNameByCalculatorTypeId(postData.CalculatorTypeId);
		rowData[rowDataPropertyName] = postData.TierId;
	},
	showTierChangeDialog: function (siteId, calculatorTypeId) {
		siteListNs.resetReasonDialog();

		var closeHandler = function () {
			//give split second for save to update the values before restoring value
			setTimeout(function () {
				siteListNs.handleTierChangeDialogClose(siteId, calculatorTypeId);
				rm.ui.messages.clearError();
			}, 10);
		};

		var btnSave = {
			id: "btnSaveTierChangeReasonDialog",
			text: "Save", click: function () {
				if (siteListNs.validateAndSaveReasonsForChange(siteId, calculatorTypeId)) {
					$(this).dialog("close");
				}
			}
		};

		rm.ui.dialog.showModalWithButtonsAndCloseHandler(siteListNs.tierChangeReasonDialogSelector, "Select Tier Change Reasons - " + siteListNs.getSiteName(siteId), "", false, 500, 470, [btnSave, rm.ui.dialog.standardButtons.cancel], closeHandler);
		setTimeout(function () { rm.ui.utilities.disableJqUiControl("#btnSaveTierChangeReasonDialog"); }, 10);
	},
	getSiteName: function (siteId) { return rm.grid.rowData.getById(siteListNs.siteListGridSelector, siteId).SiteName; },
	validateAndSaveReasonsForChange: function (siteId, calculatorTypeId) {
		if (siteListNs.isModalValid()) {
			var postData = {
				ProjectId: siteListNs.getProjectId(),
				SiteId: siteId,
				CalculatorTypeId: calculatorTypeId,
				TierId: siteListNs.getTierDrowdownBySiteIdAndCalculatorTypeId(siteId, calculatorTypeId).val(),
				TierChangeReasonList: siteListNs.getTierChangeReasons(),
				OtherReason: $(siteListNs.txtTierChangeOtherReasonSelector).val()
			};
			siteListNs.saveTierChange(postData, false, true);
			return true;
		}
		return false;
	},
	getCheckedReasonSelector: function () { return siteListNs.tierChangeReasonDialogSelector + " .reasonCb:checked"; },
	isModalValid: function () {
		rm.ui.messages.clearError();
		var isValid = true;
		if ($(siteListNs.getCheckedReasonSelector()).length == 0) {
			rm.ui.messages.addError("Please select at least one reason for tier change.");
			isValid = false;
		}

		if ($(".reasonCb[isOther=1]").is(":checked") && $.trim($(siteListNs.txtTierChangeOtherReasonSelector).val()) === "") {
			rm.validation.addError(siteListNs.txtTierChangeOtherReasonSelector, "Please enter 'Other Comments'.");
			isValid = false;
		} else {
			rm.validation.clearError(siteListNs.txtTierChangeOtherReasonSelector);
		}

		if (!$(siteListNs.chkConfirmReasonReviewSelector).is(":checked")) {
			rm.ui.messages.addError("Please confirm that you have reviewed and selected all applicable reasons for tier change.");
			isValid = false;
		}
		return isValid;
	},
	resetReasonDialog: function () {
		$(siteListNs.tierChangeReasonDialogSelector + " [type=checkbox]").prop("checked", false);
		$(siteListNs.divOtherCommentsSelector).hide();
		$(siteListNs.txtTierChangeOtherReasonSelector).val("");
		rm.validation.clearError(siteListNs.txtTierChangeOtherReasonSelector);
	},
	showToolTipOnInitialSiteTieringButton: function () {
		var tooltipMessage = siteListNs.getToolTipForInitialSiteTieringButton();
		if (tooltipMessage !== "") {
			rm.qtip.showInfo($(siteListNs.siteTieringButtonSelector), tooltipMessage);
		}
	},
	getToolTipForInitialSiteTieringButton: function () {
		var tooltipMessage = "";
		if (siteListNs.isDteProject()) {
			if (siteListNs.isSchemaDefinedByUser() && siteListNs.isRequiredTierEnabledForInitialSiteTiering()) {
				if (siteListNs.allowInitialTiering()) {
					tooltipMessage = "Perform Initial Site Tiering based on Site Intelligence QA Statuses and Enrollment Scores...";
				}
				else if (siteListNs.isInitialSiteTieringAlreadyPerformed()) {
					tooltipMessage = "Initial Site Tiering has already been completed for this Project";
				}
			}
			else {
				tooltipMessage = "Initial Site Tiering is not available until the 'RBM Schema' for this Project has been configured in 'Project Configuration', with Tier 2 enabled - for any QA-flagged Sites and Tier 5 enabled - for any sites with zero enrollment score";
			}
		}
		return tooltipMessage;
	},
	performInitialSiteTiering: function () {
		var okButton = { text: "Continue", click: siteListNs.siteTieringDialogOkClickHandler };
		rm.ui.dialog.showModalWithButtons("#divInitialSiteTieringDialog", "Initial Site Tiering", "", false, 530, 470, [okButton, rm.ui.dialog.standardButtons.cancel])
	},
	siteTieringDialogOkClickHandler: function () {
		siteListNs.showSpinnerOnSiteTieringButton();
		var dialogBoxHandle = $(this);

		rm.ajax.projectSvcAsyncPost("PerformInitiatSiteTiering", { projectId: siteListNs.getProjectId() }, function (serviceResponse) {
			if (serviceResponse.IsSuccessful) {
				dialogBoxHandle.dialog("close");
				$(siteListNs.initialTieringRunningSelector).val("1");
				rm.ui.ribbon.delayedRefresh();
			}
			else {
				rm.validation.processErrorMessages(serviceResponse.Errors, "", "");
			}
			siteListNs.hideSpinnerOnSiteTieringButton();
		});
	},
	getTierChangeReasons: function () {
		var tierChangeReasons = [];
		$.each($(siteListNs.getCheckedReasonSelector()), function (index, reasonCb) {
			tierChangeReasons.push($(reasonCb).val());
		});
		return tierChangeReasons;
	},
	populateSiteTierChangeHistoryGrid: function (siteId) {
		rm.ui.dialog.showModal(siteListNs.tierChangehistoryDialogSelector, "Tier Change History - " + siteListNs.getSiteName(siteId), "", false, 900, 590);
		if ($(siteListNs.historyGridSelector)[0].grid) {
			$(siteListNs.historyGridSelector).jqGrid('setGridParam', { postData: { SiteId: siteId }, datatype: "json" }).trigger('reloadGrid');
		}
		else { siteListNs.buildSiteTierChangeHistoryGrid(siteId); }
	},
	buildSiteTierChangeHistoryGrid: function (siteId) {
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showClearFilter = false;
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ProjectSiteList, HistoryList: "1" };
		rm.grid.showGridTools(siteListNs.historyGridSelector, gridToolsConfig);
		var gridPostData = { SiteId: siteId };

		$(siteListNs.historyGridSelector).jqGrid({
			url: rm.ajax.projectSvcUrl + "GetSiteTierChangeHistoryBySite",
			datatype: 'json',
			mtype: 'POST',
			postData: gridPostData,
			ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			loadonce: true,
			shrinkToFit: false,
			height: window.screen.height - 425,
			width: 850,
			forceFit: true,
			pager: '#tblHistoryPager',
			multiselect: false,
			colModel: [
				{ name: 'Frequency', index: 'Frequency', label: 'Frequency', width: 75, search: false, sortable: false },
				{ name: 'OldTierValue', index: 'OldTierValue', label: 'Previous<br/>Tier Value', width: 70, search: false, sortable: false },
				{ name: 'NewTierValue', index: 'NewTierValue', label: 'Updated<br/>Tier Value	', width: 70, search: false, sortable: false },
				{ name: 'ReasonForChange', index: 'ReasonForChange', label: 'Reason(s) for Change', width: 200, search: false, sortable: false },
				{ name: 'OtherComments', index: 'OtherComments', label: 'Other<br/>Comments', width: 90, search: false, sortable: false },
				{ name: 'ModifiedBy', index: 'ModifiedBy', label: 'Modified By<br/>Name', width: 90, search: false, sortable: false },
				{ name: 'ModifiedByQid', index: 'ModifiedByQid', label: 'Modified<br/>By QID', width: 60, search: false, sortable: false },
				{ name: 'ModifiedOn', index: 'ModifiedOn', label: 'Modified On', align: 'center', width: 150, search: false, sortable: false }
			],
			viewsortcols: [true, 'vertical', true],
			sortorder: 'asc',
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			gridComplete: function () { rm.grid.hideSearchRow("tblHistoryData"); },
			serializeGridData: rm.grid.serializeGridData,
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("tblHistoryData"); },
			loadComplete: function (data) { }
		});
		$(siteListNs.historyGridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true, defaultSearch: "cn" });
	},
	isCancelSiteIntelligenceTierReviewEnabled: function () {
		return siteListNs.isSiteIntelligenceTierReviewStarted() && !siteListNs.isApplyRecommendedTierProcessRunning();
		rm.ui.ribbon.delayedRefresh();
	},
	isStartSiteIntelligenceTierReviewEnabled: function () { return siteListNs.isDteProject() && !siteListNs.isInitialSiteTieringProcessRunning() && !siteListNs.isApplyRecommendedTierProcessRunning() && !siteListNs.isSiteIntelligenceTierReviewStarted(); },
	startSiteIntelligenceTierReview: function () {
		siteListNs._siteIntelligenceTierReviewStarted = true;
		siteListNs.showHideReviewOnlyColumnsFromMonitoringVisitSummaryTable(true);
		siteListNs.reloadSiteGrid();
		rm.ui.ribbon.delayedRefresh();
	},
	cancelSiteIntelligenceTierReview: function () {
		siteListNs._siteIntelligenceTierReviewStarted = false;
		siteListNs.showHideReviewOnlyColumnsFromMonitoringVisitSummaryTable(false);
		siteListNs.reloadSiteGrid();
		rm.ui.ribbon.delayedRefresh();
	},
	isApplyRecommendedTierChangesEnabled: function () {
		return (!siteListNs.isApplyRecommendedTierProcessRunning() && $(".cbTier:checked").length > 0);
	},
	bindCbTierClick: function () {
		$(".cbTier").click(function () {
			rm.ui.ribbon.delayedRefresh();

			var cbAccept = $(this);
			var isPharmacy = cbAccept.attr("isPharmacy") == "1";
			var changeInVisitCellClass = "td.changeInVisitTd" + (isPharmacy ? ".pharmacyChange" : ".siteChange");
			if (cbAccept.is(":checked")) {
				var gridRowData = rm.grid.rowData.getById(siteListNs.siteListGridSelector, cbAccept.attr("siteId"));

				if (isPharmacy) {
					cbAccept.closest("tr").find(changeInVisitCellClass).addClass(gridRowData.DeltaPharmacyVisits > 0 ? "redText" : "greenText").removeClass("disabledText");
				}
				else {
					cbAccept.closest("tr").find(changeInVisitCellClass + ".remoteChange").addClass(gridRowData.DeltaRemoteVisits > 0 ? "redText" : "greenText").removeClass("disabledText");
					cbAccept.closest("tr").find(changeInVisitCellClass + ".imvChange").addClass(gridRowData.DeltaSiteMonitoringVisits > 0 ? "redText" : "greenText").removeClass("disabledText");
				}
			}
			else {
				cbAccept.closest("tr").find(changeInVisitCellClass).removeClass("redText greenText").addClass("disabledText");
			}

			if (isPharmacy) { siteListNs.addRemovePharmacyVisits(); }
			else { siteListNs.addRemoveSiteMonitoringVisits(); }
		});
	},
	showMonitoringVisitSummaryTable: function () {
		siteListNs.refreshMonitoringVisitSummaryTable();
		$(siteListNs.tblVisitComparisonSelector).show();
	},
	showHideReviewOnlyColumnsFromMonitoringVisitSummaryTable: function (showColumns) {
		showColumns ? $(".showInRevieModeOnly").show() : $(".showInRevieModeOnly").hide();
	},
	refreshMonitoringVisitSummaryTable: function () {
		rm.ajax.projectSvcAsyncPost("GetProjectSiteVisitCountSummary", { projectId: siteListNs.getProjectId() }, function (serviceResponse) {
			$("[id$=_lblBudgetedOnsiteImvVisits]").text(serviceResponse.TotalQipBudgetedOnsiteImvVisitCount);
			$("[id$=_lblBudgetedRemoteImvVisits]").text(serviceResponse.TotalQipBudgetedRemoteVisitCount);
			$("[id$=_lblBudgetedPharmacyVisits]").text(serviceResponse.TotalQipBudgetedPharmacyVisitCount);
			$("[id$=_lblTotalBudgetedVisits]").text(serviceResponse.QipBudgetedVisitCountGrandTotal);

			$(siteListNs.lblCtmsActualOnsiteImvVisitCountSelector).text(serviceResponse.CtmsActualOnsiteImvVisitCount);
			$(siteListNs.lblCtmsPlannedOnsiteImvVisitCountSelector).text(serviceResponse.CtmsPlannedOnsiteImvVisitCount);
			$(siteListNs.lblRmProjectedOnsiteImvVisitCountSelector).text(serviceResponse.RmProjectedOnsiteImvVisitCount);

			$(siteListNs.lblCtmsActualRemoteImvVisitCountSelector).text(serviceResponse.CtmsActualRemoteVisitCount);
			$(siteListNs.lblCtmsPlannedRemoteVisitCountSelector).text(serviceResponse.CtmsPlannedRemoteVisitCount);
			$(siteListNs.lblRmProjectedRemoteVisitCountSelector).text(serviceResponse.RmProjectedRemoteVisitCount);

			$(siteListNs.lblCtmsActualPharmacyVisitCountSelector).text(serviceResponse.CtmsActualPharmacyVisitCount);
			$(siteListNs.lblCtmsPlannedPharmacyVisitCountSelector).text(serviceResponse.CtmsPlannedPharmacyVisitCount);
			$(siteListNs.lblRmProjectedPharmacyVisitCountSelector).text(serviceResponse.RmProjectedPharmacyVisitCount);

			$("[id$=_lblTotalCtmsActualVisits]").text(serviceResponse.CtmsActualOnsiteImvVisitCount +
				serviceResponse.CtmsActualRemoteVisitCount +
				serviceResponse.CtmsActualPharmacyVisitCount);

			$("[id$=_lblTotalCtmsPlannedVisits]").text(serviceResponse.CtmsPlannedOnsiteImvVisitCount +
				serviceResponse.CtmsPlannedRemoteVisitCount +
				serviceResponse.CtmsPlannedPharmacyVisitCount);

			$("[id$=_lblTotalRmProjectedVisits]").text(serviceResponse.RmProjectedOnsiteImvVisitCount +
				serviceResponse.RmProjectedRemoteVisitCount +
				serviceResponse.RmProjectedPharmacyVisitCount);

			$("[id$=_lblTotalOnsiteImvVisitCount").text(serviceResponse.CtmsActualOnsiteImvVisitCount +
				serviceResponse.CtmsPlannedOnsiteImvVisitCount +
				serviceResponse.RmProjectedOnsiteImvVisitCount);

			$("[id$=_lblTotalRemoteImvVisitCount").text(serviceResponse.CtmsActualRemoteVisitCount +
				serviceResponse.CtmsPlannedRemoteVisitCount +
				serviceResponse.RmProjectedRemoteVisitCount);

			$("[id$=_lblTotalPharmacyVisitCount").text(serviceResponse.CtmsActualPharmacyVisitCount +
				serviceResponse.CtmsPlannedPharmacyVisitCount +
				serviceResponse.RmProjectedPharmacyVisitCount);

			$("[id$=_lblGrandTotalProjectedVisitCount]").text(serviceResponse.CtmsActualOnsiteImvVisitCount +
				serviceResponse.CtmsActualRemoteVisitCount +
				serviceResponse.CtmsActualPharmacyVisitCount +
				serviceResponse.CtmsPlannedOnsiteImvVisitCount +
				serviceResponse.CtmsPlannedRemoteVisitCount +
				serviceResponse.CtmsPlannedPharmacyVisitCount +
				serviceResponse.RmProjectedOnsiteImvVisitCount +
				serviceResponse.RmProjectedRemoteVisitCount +
				serviceResponse.RmProjectedPharmacyVisitCount);

			$("[id$=_lblEstimatedChangeInOnsiteImvVisits]").text("0").removeClass("redText").addClass("greenText");
			$("[id$=_lblEstimatedChangeInRemoteImvVisits]").text("0").removeClass("redText").addClass("greenText");
			$("[id$=_lblEstimatedChangeInPharmacyVisits]").text("0").removeClass("redText").addClass("greenText");
			$("[id$=_lblTotalEstimatedChangeInNumberOfVisits]").text("0").removeClass("redText").addClass("greenText");

			$("[id$=_lblEstimatedProjectedOnsiteImvVisits]").text(serviceResponse.TotalProjectedOnsiteImvVisitCount);
			$("[id$=_lblEstimatedProjectedRemoteImvVisits]").text(serviceResponse.TotalProjectedRemoteVisitCount);
			$("[id$=_lblEstimatedProjectedPharmacyVisits]").text(serviceResponse.TotalProjectedPharmacyVisitCount);
			$("[id$=_lblTotalEstimatedProjectedVisits]").text(serviceResponse.ProjectedVisitCountGrandTotal);
		});
	},
	resetSummaryTableToZero: function () {
		var visitCountChangeSummary = {
			EstimatedOnsiteImvVisitCountChange: 0,
			EstimatedRemoteVisitCountChange: 0,
			EstimatedPharmacyVisitCountChange: 0
		}
		siteListNs.showSiteMonitoringVisitCountSummary(visitCountChangeSummary);
		siteListNs.showPharmacyMonitoringVisitCountSummary(visitCountChangeSummary);
	},
	resetSummaryTable: function () {
		siteListNs.addRemovePharmacyVisits();
		siteListNs.addRemoveSiteMonitoringVisits();
	},
	lblCtmsActualOnsiteImvVisitCountSelector: "[id$=lblCtmsActualOnsiteImvVisitCount]",
	lblCtmsPlannedOnsiteImvVisitCountSelector: "[id$=lblCtmsPlannedOnsiteImvVisitCount]",
	lblRmProjectedOnsiteImvVisitCountSelector: "[id$=lblRmProjectedOnsiteImvVisitCount]",
	lblEstimatedChangeInNumberOfOnsiteImvVisitsSelector: "[id$=lblEstimatedChangeInNumberOfOnsiteImvVisits]",
	lblEstimatedProjectedOnsiteImvVisitsSelector: "[id$=lblEstimatedProjectedOnsiteImvVisits]",

	lblCtmsActualRemoteImvVisitCountSelector: "[id$=lblCtmsActualRemoteImvVisitCount]",
	lblCtmsPlannedRemoteVisitCountSelector: "[id$=lblCtmsPlannedRemoteVisitCount]",
	lblRmProjectedRemoteVisitCountSelector: "[id$=lblRmProjectedRemoteVisitCount]",

	lblEstimatedChangeInNumberOfRemoteImvVisitsSelector: "[id$=lblEstimatedChangeInNumberOfRemoteImvVisits]",
	lblEstimatedProjectedRemoteImvVisitsSelector: "[id$=lblEstimatedProjectedRemoteImvVisits]",

	lblCtmsActualPharmacyVisitCountSelector: "[id$=lblCtmsActualPharmacyVisitCount]",
	lblCtmsPlannedPharmacyVisitCountSelector: "[id$=lblCtmsPlannedPharmacyVisitCount]",
	lblRmProjectedPharmacyVisitCountSelector: "[id$=lblRmProjectedPharmacyVisitCount]",
	lblEstimatedChangeInNumberOfPharmacyVisitsSelector: "[id$=lblEstimatedChangeInNumberOfPharmacyVisits]",
	lblEstimatedProjectedPharmacyVisitsSelector: "[id$=lblEstimatedProjectedPharmacyVisits]",

	lblTotalEstimatedChangeInNumberOfVisitsSelector: "[id$=lblTotalEstimatedChangeInNumberOfVisits]",
	lblTotalEstimatedProjectedVisitsSelector: "[id$=lblTotalEstimatedProjectedVisits]",
	getSelectedSiteCheckboxs: function (isPharmacy) { return $("[isPharmacy=" + (isPharmacy ? "1" : "0") + "].cbTier:checked"); },
	displayAndColorCodeValue: function (selector, value) {
		$(selector).removeClass("redText greenText").addClass(value > 0 ? "redText" : "greenText").text(value);
	},
	addRemoveSiteMonitoringVisits: function () {
		siteListNs.showSiteMonitoringVisitCountSummary(siteListNs.getSelectedVisitCountChangeSummary(false));
	},
	showSiteMonitoringVisitCountSummary: function (visitCountChangeSummary) {
		//Find out total
		var totalOnsiteImvVisitCountChange = parseInt($(siteListNs.lblCtmsActualOnsiteImvVisitCountSelector).text()) +
			parseInt($(siteListNs.lblCtmsPlannedOnsiteImvVisitCountSelector).text()) +
			parseInt($(siteListNs.lblRmProjectedOnsiteImvVisitCountSelector).text()) +
			visitCountChangeSummary.EstimatedOnsiteImvVisitCountChange;
		var totalRemoteVisitCountChange = parseInt($(siteListNs.lblCtmsActualRemoteImvVisitCountSelector).text()) +
			parseInt($(siteListNs.lblCtmsPlannedRemoteVisitCountSelector).text()) +
			parseInt($(siteListNs.lblRmProjectedRemoteVisitCountSelector).text()) +
			visitCountChangeSummary.EstimatedRemoteVisitCountChange;

		//Display Estimated chagne
		siteListNs.displayAndColorCodeValue(siteListNs.lblEstimatedChangeInNumberOfOnsiteImvVisitsSelector, visitCountChangeSummary.EstimatedOnsiteImvVisitCountChange);
		siteListNs.displayAndColorCodeValue(siteListNs.lblEstimatedChangeInNumberOfRemoteImvVisitsSelector, visitCountChangeSummary.EstimatedRemoteVisitCountChange);

		//Display estimated projected
		$(siteListNs.lblEstimatedProjectedOnsiteImvVisitsSelector).text(totalOnsiteImvVisitCountChange);
		$(siteListNs.lblEstimatedProjectedRemoteImvVisitsSelector).text(totalRemoteVisitCountChange);

		//show Total
		siteListNs.showEstimatedTotals();
	},
	addRemovePharmacyVisits: function () {
		siteListNs.showPharmacyMonitoringVisitCountSummary(siteListNs.getSelectedVisitCountChangeSummary(true));
	},
	showPharmacyMonitoringVisitCountSummary: function (visitCountChangeSummary) {
		//Find out total
		totalPharmacyVisitCountChange = parseInt($(siteListNs.lblCtmsActualPharmacyVisitCountSelector).text()) +
			parseInt($(siteListNs.lblCtmsPlannedPharmacyVisitCountSelector).text()) +
			parseInt($(siteListNs.lblRmProjectedPharmacyVisitCountSelector).text()) +
			visitCountChangeSummary.EstimatedPharmacyVisitCountChange;

		//Display Estimated chagne
		siteListNs.displayAndColorCodeValue(siteListNs.lblEstimatedChangeInNumberOfPharmacyVisitsSelector, visitCountChangeSummary.EstimatedPharmacyVisitCountChange);

		//Display estimated projected
		$(siteListNs.lblEstimatedProjectedPharmacyVisitsSelector).text(totalPharmacyVisitCountChange);

		//show Total
		siteListNs.showEstimatedTotals();
	},
	showEstimatedTotals: function () {
		var estimatedVisitCountChangeTotal = parseInt($(siteListNs.lblEstimatedChangeInNumberOfOnsiteImvVisitsSelector).text()) + parseInt($(siteListNs.lblEstimatedChangeInNumberOfRemoteImvVisitsSelector).text()) + parseInt($(siteListNs.lblEstimatedChangeInNumberOfPharmacyVisitsSelector).text());
		siteListNs.displayAndColorCodeValue(siteListNs.lblTotalEstimatedChangeInNumberOfVisitsSelector, estimatedVisitCountChangeTotal);

		var estimatedVisitCountChangeTotal = parseInt($(siteListNs.lblEstimatedProjectedOnsiteImvVisitsSelector).text()) + parseInt($(siteListNs.lblEstimatedProjectedRemoteImvVisitsSelector).text()) + parseInt($(siteListNs.lblEstimatedProjectedPharmacyVisitsSelector).text());
		$(siteListNs.lblTotalEstimatedProjectedVisitsSelector).text(estimatedVisitCountChangeTotal);
	},
	getSelectedVisitCountChangeSummary: function (isPharmacy) {
		var visitCountChangeSummary = {
			EstimatedOnsiteImvVisitCountChange: 0,
			EstimatedRemoteVisitCountChange: 0,
			EstimatedPharmacyVisitCountChange: 0
		};

		var selectedSites = siteListNs.getSelectedSiteCheckboxs(isPharmacy);
		if (selectedSites.length > 0) {
			$.each(selectedSites, function (index, chkBox) {
				var gridRowData = rm.grid.rowData.getById(siteListNs.siteListGridSelector, $(chkBox).attr("siteId"));
				if (isPharmacy) {
					visitCountChangeSummary.EstimatedPharmacyVisitCountChange += gridRowData.DeltaPharmacyVisits;
				}
				else {
					visitCountChangeSummary.EstimatedOnsiteImvVisitCountChange += gridRowData.DeltaSiteMonitoringVisits;
					visitCountChangeSummary.EstimatedRemoteVisitCountChange += gridRowData.DeltaRemoteVisits;
				}
			});
		}

		return visitCountChangeSummary;
	},
	getSitesAcceptingRecommendedTier: function (isPharmacy) {
		var siteData = []
		var selectedSites = siteListNs.getSelectedSiteCheckboxs(isPharmacy);
		if (selectedSites.length > 0) {
			$.each(selectedSites, function (index, chkBox) {
				var siteId = $(chkBox).attr("siteId");
				var gridRowData = rm.grid.rowData.getById(siteListNs.siteListGridSelector, siteId);

				var siteInfo = {
					ProjectId: siteListNs.getProjectId(),
					SiteId: siteId,
					CalculatorTypeId: (isPharmacy ? CalculatorType_E.PharmacyMonitoring : CalculatorType_E.IMV_Freq1_FPI_LPI),
					TierId: (isPharmacy ? gridRowData.RecommendedPharmacyTier : gridRowData.RecommendedSiteTier),
					TierChangeReasonList: [SiteTierChangeReason_E.Accepted_Site_Intelligence_Recommended_Tier],
					OtherReason: null
				};

				siteData.push(siteInfo);
				//Do not add LSO-COV frequency explicitly. Service combines all frequencies and sends single email. Adding LSO-COV will cause duplicate email to fire.
			});
		}

		return siteData;
	},
	getPostDataForAcceptingRecommendedTier: function () {
		var acceptedTierInfoList = [];
		if (siteListNs.isApplyRecommendedTierChangesEnabled()) {
			acceptedTierInfoList = acceptedTierInfoList.concat(siteListNs.getSitesAcceptingRecommendedTier(false));
			acceptedTierInfoList = acceptedTierInfoList.concat(siteListNs.getSitesAcceptingRecommendedTier(true));
		}

		return acceptedTierInfoList;
	},
	addSpinnerOnApplyRecommendedTierButton: function () { rm.ui.ribbon.addHiddenWaitSpinner(siteListNs.acceptRecommendedTierButtonSelector, siteListNs.acceptRecommendedTierSpinnerId); },
	showSpinnerOnApplyRecommendedTierButton: function () { $(siteListNs.getAcceptRecommendedTierSpinnerSelector()).show(); },
	hideSpinnerOnApplyRecommendedTierButton: function () { $(siteListNs.getAcceptRecommendedTierSpinnerSelector()).hide(); },

	startApplyRecommendedTierProcessMonitoring: function () {
		rm.utilities.checkIfProcessIsRunning(siteListNs.getProjectId(), Process_E.AcceptingRecommendedTier, EntityType.Project, siteListNs.handleApplyRecommendedTierProcessMonitoringResponse);
	},
	handleApplyRecommendedTierProcessMonitoringResponse: function (serviceResponse) {
		if (serviceResponse) {
			siteListNs.showSpinnerOnApplyRecommendedTierButton();
			siteListNs._applyRecommendedTierProcessRunning = true;
			rm.ui.ribbon.delayedRefresh();
		}
		else {
			siteListNs.hideSpinnerOnApplyRecommendedTierButton();
			if (siteListNs.isApplyRecommendedTierProcessRunning()) {
				siteListNs._applyRecommendedTierProcessRunning = false;
				siteListNs._siteIntelligenceTierReviewStarted = false;
				//###setTimeout(siteListNs.updateToolTipOnInitialSiteTieringButton, 10);
				siteListNs.reloadSiteGrid();
				message = "Selected recommended tiers have been applied successfully.";
				rm.ui.messages.showSuccess(message);
				alert(message);
				siteListNs.enableAllGridControls();
			}
			rm.ui.ribbon.delayedRefresh();
		}
	},
	applyRecommendedTierChanges: function () {
		rm.ui.messages.clearError();
		if (siteListNs.isApplyRecommendedTierChangesEnabled()) {
			rm.ajax.projectSvcAsyncPost("AcceptRecommendedTiers", { siteTierInfoList: siteListNs.getPostDataForAcceptingRecommendedTier(), projectCode: GetCurrentProjectName() }, function (serviceResponse) {
				if (serviceResponse.IsSuccessful) {
					rm.ui.messages.showSuccess(serviceResponse.Output);
				}
				else {
					rm.validation.processErrorMessages(serviceResponse.Errors, siteListNs.siteListGridSelector, "");
				}
			});

			//service call is async. Following code will run as soon as service call is made. We don't want to update _applyRecommendedTierProcessRunning  before service call is made.
			siteListNs._applyRecommendedTierProcessRunning = true;
			siteListNs.showSpinnerOnApplyRecommendedTierButton();
			rm.ui.ribbon.delayedRefresh();
			siteListNs.disableAllGridControls();
		}
	},
	getAllUserInterfacableControlSelector: function () { return siteListNs.siteListGridContainerSelector + " input, " + siteListNs.siteListGridContainerSelector + " select, .cbTier"; },
	disableAllGridControls: function () {
		$(siteListNs.getAllUserInterfacableControlSelector()).attr("disabled", "disabled");
		$("div.ui-jqgrid-sortable").removeClass("ui-jqgrid-sortable");
	},
	enableAllGridControls: function () {
		$(siteListNs.getAllUserInterfacableControlSelector()).removeAttr("disabled");
		$("div.gridHeaderFiveLine").addClass("ui-jqgrid-sortable");
	},
	reloadSiteGrid: function () {
		var gridParm = {
			postData: {
				ProjectId: siteListNs.getProjectId(),
				LoadSitesForAcceptingRecommendedTiers: siteListNs.isSiteIntelligenceTierReviewStarted(),
			},
			page: 1,
			rowNum: (siteListNs.isSiteIntelligenceTierReviewStarted() ? 9000 : 25)
		};

		$(siteListNs.siteListGridSelector).jqGrid('setGridParam', gridParm).trigger('reloadGrid');

		if (siteListNs.isSiteIntelligenceTierReviewStarted()) {
			$(siteListNs.gridPagerNavigationSelector).hide();
			$(siteListNs.divReviewInstructionsSelector).show();
		}
		else {
			$(".cbTier").attr("checked", false);
			$(siteListNs.gridPagerNavigationSelector).show();
			$(siteListNs.divReviewInstructionsSelector).hide();
		}
		rm.ui.ribbon.delayedRefresh();
	},
	completePeriodicTierReview: function () {
		rm.ajax.projectSvcAsyncPost("MarkPeriodicTierReviewComplete", { projectId: siteListNs.getProjectId() }, function (serviceResponse) {
			$(siteListNs.lblLastPeriodicReviewDateSelector).text(serviceResponse.LastReviewPerformedBy);
			rm.ui.messages.showSuccess("Tier Review Completion date has been successfully registered.");
		});
	},
	getReasonForNoRegularTierReview: function () {
		var reasonId = $(siteListNs.rbNoReviewReasonSelector + ":checked").val();
		return reasonId = "" ? null : reasonId;
	},
	getPostDataForRegularTierReivewChange: function (isEnabled) {
		return {
			projectId: siteListNs.getProjectId(),
			regularReviewRequired: isEnabled,
			noRegularTierReviewReasonId: (isEnabled ? null : siteListNs.getReasonForNoRegularTierReview())
		};
	},
	isRegularTierReivewRequiredEnabled: function () { return true; },
	handleRegularTierReivewRequiredCheckChangeEvent: function () {
		setTimeout(siteListNs.handleRegularTierReivewCheckChange, 20);
	},
	handleRegularTierReivewCheckChange: function () {
		if ($(siteListNs.cbNoReviewReasonSelector).is(":checked")) {
			if (confirm("Confirm change to Regular Tier Review Required.")) {
				siteListNs.updateRegularTierReviewFlag(true);
			}
			else {
				$(siteListNs.cbNoReviewReasonSelector).prop("checked", false);
			}
		}
		else {
			siteListNs.showNoReviewReasonDialog();
		}
	},
	updateRegularTierReviewFlag: function (regularReviewRequired) {
		rm.ajax.projectSvcAsyncPost("UpdateRegularTierReviewFlag", siteListNs.getPostDataForRegularTierReivewChange(regularReviewRequired), function (response) {
			if (response.IsSuccessful) {
				rm.ui.messages.showSuccess("Monthly tier review has been " + (regularReviewRequired ? "enabled" : "disabled") + " for the project " + rm.projectInContext.getProjectCode());
			}
			else {
				rm.ui.messages.addError("Please correct the errors and try again.");
				rm.validation.processErrorMessages(response.Errors, "", "");
			}
		});
	},
	showNoReviewReasonDialog: function () {
		var continueClicked = false;
		var btnContinue = {
			text: "Continue", click: function () {
				if (siteListNs.getReasonForNoRegularTierReview() != null) {
					continueClicked = true;
					siteListNs.updateRegularTierReviewFlag(false);
					$(this).dialog("close");
				}
				else {
					rm.ui.messages.addError("Reason is required when disabling monthly tier review.");
				}
			}
		};
		var onClose = function () {
			if (!continueClicked) {
				$(siteListNs.cbNoReviewReasonSelector).prop("checked", true);
			}
			$(siteListNs.rbNoReviewReasonSelector).prop("checked", false);
		};
		rm.ui.dialog.showModalWithButtonsAndCloseHandler("#divNoRegularReview", "Select a Reason", "", false, 350, 230, [btnContinue, rm.ui.dialog.standardButtons.cancel], onClose);
	}
};
