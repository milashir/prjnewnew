﻿/// <reference path="../common/rmhelper.js" />
var proposalNs = {
	isSaveProposalButtonEnabled: false,
	isCancelButtonEnabled: false,
	typeAheadBound: false,
	selectedRequestId: -1,
	projectId: -1,
	dateFieldSelectors: "#txtRFPReceivedDate,#txtProposalDueDate,#txtStratCallDate,#txtPrepCallMeetingDate,#txtBidDefenseDate,#txtExpectedStartDate",
	IsSaveProposalButtonEnabled: function () { return proposalNs.isSaveProposalButtonEnabled; },
	IsCancelButtonEnabled: function () { return proposalNs.isCancelButtonEnabled; },
	EnableDisableRibbonIconsOnProjectDirtyChange: function (isDirty) {
		if (proposalNs.projectId != -1) {
			proposalNs.isCancelButtonEnabled = isDirty;
			proposalNs.isSaveProposalButtonEnabled = isDirty;
		}
		else {
			proposalNs.isCancelButtonEnabled = false;
			proposalNs.isSaveProposalButtonEnabled = false;
		}
		rm.ui.ribbon.delayedRefresh();
	},
	HandleMultiSelectChange: function (itemCollection) {
		proposalNs.EnableDisableRibbonIconsOnProjectDirtyChange(proposalNs.IsProjectFormDirty());
	},
	HandleRegionChange: function (itemCollection) {
		proposalNs.EnableDisableRibbonIconsOnProjectDirtyChange(proposalNs.IsProjectFormDirty());
		var selectedRegionIds = "";
		if (itemCollection) {
			$.each(itemCollection, function (index, item) {
				if (item.isChecked) {
					selectedRegionIds += "," + item.key;
				}
			});
			selectedRegionIds = selectedRegionIds.replace(",", "");
		}
		if (selectedRegionIds == "") {
			proposalNs.PopulateProposedCountries(null);
		}
		else {
			rm.ajax.utilitySvcAsyncGet("GetAllCountriesByRegion", { regionIds: selectedRegionIds }, function (data) {
				var existingCountries = $("#countryDropDownContainer").data("ItemsCollection");
				//remember country states from first page load
				var countriesDuringProjectLoad = $("#countryDropDownContainer").data("InitialItemsCollection");

				var existingCountryCount = existingCountries ? existingCountries.length : 0;
				var existingCountry;
				var titleString = "";
				$.each(data, function (index, country) {
					for (var countryIndex = 0; countryIndex < existingCountryCount; countryIndex++) {
						existingCountry = existingCountries[countryIndex];
						if (existingCountry.key == country.key) {
							country.isChecked = existingCountry.isChecked;
							break;
						}
					}
				});

				var initialCountryCount = countriesDuringProjectLoad ? countriesDuringProjectLoad.length : 0;
				if (initialCountryCount > 0) {
					var initialCountry;
					var titleString = "";
					$.each(data, function (index, country) {
						for (var countryIndex = 0; countryIndex < initialCountryCount; countryIndex++) {
							initialCountry = countriesDuringProjectLoad[countryIndex];
							if (initialCountry.key == country.key) {
								country.wasOriginallyChecked = initialCountry.wasOriginallyChecked;
								break;
							}
						}
					});
				}

				proposalNs.PopulateProposedCountries(data);
			});
		}
	},
	PopulateProposedRegions: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "regionDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { proposalNs.HandleRegionChange(itemCollection); }
		};
		$("#proposalRegionHyperlink").dropdownV2(dropdownOptions);

	},
	PopulateProposedCountries: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "countryDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { proposalNs.HandleMultiSelectChange(itemCollection); }
		};
		$("#proposalCountryHyperlink").dropdownV2(dropdownOptions);
	},
	PopulateIndications: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "indicationsDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { proposalNs.HandleMultiSelectChange(itemCollection); }
		};
		$("#proposalIndicationsHyperlink").dropdownV2(dropdownOptions);
	},
	PopulateServices: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "servicesDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { proposalNs.HandleMultiSelectChange(itemCollection); }
		};
		$("#proposalServicesHyperlink").dropdownV2(dropdownOptions);

	},
	SelectOpportunityNumber: function () {
		proposalNs.ShowProposalProjectSelectionModal();
		proposalNs.ClearAllErrors();
	},
	RecentOpportunityNumbers: function () { proposalNs.ClearAllErrors(); },
	GetCheckedValues: function (selector, dataKey, isCountryDropdown) {
		var data = $(selector).data(dataKey);
		var selectedItems = new Array();
		if (data) {
			$.each(data, function (index, item) {
				if (item.isChecked != item.wasOriginallyChecked) {
					if (isCountryDropdown) {
						selectedItems.push({
							key: item.key,
							//value: item.value, no need to send text vaues. Uncomment for debugging
							isChecked: item.isChecked,
							regionId: item.regionId,
							dmlOperation: item.isChecked ? DMLOperation_E.Insert : DMLOperation_E.Delete
						});
					}
					else {
						selectedItems.push({
							key: item.key,
							//value: item.value, no need to send text vaues. Uncomment for debugging
							isChecked: item.isChecked,
							dmlOperation: item.isChecked ? DMLOperation_E.Insert : DMLOperation_E.Delete
						});
					}
				}
			});
		}

		return selectedItems;
	},
	IsItemSelected: function (selector, dataKey) {
		var data = $(selector).data(dataKey);
		var itemSelected = false;
		if (data) {
			$.each(data, function (index, item) {
				if (item.isChecked) {
					itemSelected = true;
					return false;
				}
			});
		}

		return itemSelected;
	},
	GetProjectPostData: function () {
		return {
			projectDetails: {
				ProjectId: proposalNs.projectId,
				ProjectCode: $("#txtOpportunityNumber").val(),
				ProjectCode: $("#txtProjectCode").val(),
				CustomerName: $("#txtCustomer").val(),
				Sponsor: $("#txtSponsor").val(),
				RfpReceivedDate: $("#txtRFPReceivedDate").val(),
				ProposalLead: ppNs.getSelectedUser().DisplayName,
				ProposalDueDate: $("#txtProposalDueDate").val(),
				StratCallDate: $("#txtStratCallDate").val(),
				PrepCallMeetingDate: $("#txtPrepCallMeetingDate").val(),
				ProtocolNumber: $("#txtProtocolNumber").val(),
				BidDefenseLocation: $("#txtBidDefenseLocation").val(),
				BidDefenseDate: $("#txtBidDefenseDate").val(),
				WinProbabilityId: $("[id$=ddlWinProbability]").val(),
				Budget: $("#txtBudget").val(),
				ProjectStageName: $("#txtStageName").val(),
				ProgramIdentifier: $("#txtProgramIdentifier").val(),
				TherapeuticAreaId: $("[id$=ddlTherapeuticArea]").val(),
				StudyPhaseId: $("[id$=ddlStudyPhase]").val(),
				NumberOfSites: $("#txtNumberOfSites").val(),
				NumberOfPatients: $("#NumberOfPatients").val(),
				ExpectedStartDate: $("#txtExpectedStartDate").val(),
				ProjectCountryAndRegion: {
					RegionList: proposalNs.GetCheckedValues("#regionDropDownContainer", "ItemsCollection", false),
					CountryList: proposalNs.GetCheckedValues("#countryDropDownContainer", "ItemsCollection", true)
				},
				Indications: proposalNs.GetCheckedValues("#indicationsDropDownContainer", "ItemsCollection", false),
				Services: proposalNs.GetCheckedValues("#servicesDropDownContainer", "ItemsCollection", false),
				OrganizationUnitId: $("[id$=_ddlOrganization]").val()
			}
		};
	},
	UpdateProposalForm: function () { alert("Not implemented in this release"); },
	SaveProposalForm: function () {
		if (proposalNs.IsProjectFormValid()) {
			rm.ajax.projectSvcAsyncPost("UpdateProposalProjectDetails", proposalNs.GetProjectPostData(), function (data) {
				if (data.IsSuccessful) {
					proposalNs.MapProjectValuesToControls(data, true);
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess(Resources.ProposalFormSavedSuccessfully);
					var projectCode = data.Output.ProjectCode;
					var protocol = data.Output.ProtocolNumber || "Not Available";
					rm.ui.messages.showWarningWithCloseButton(Resources.ProjectMilestoneSetupReminder.replace("{0}", projectCode).replace("{1}", protocol));
					setTimeout(function () {
						proposalNs.EnableDisableRibbonIconsOnProjectDirtyChange(proposalNs.IsProjectFormDirty());
						rm.ui.ribbon.delayedRefresh();
					}, 100);
				}
				else {
					rm.ui.messages.addError("Please fix the errors and click Save again.");
					rm.validation.processErrorMessages(data.Errors, "", "");
				}
			});
		}
	},
	CancelProposalForm: function () {
		var isDirty = proposalNs.IsProjectFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			var protocol = $("#txtProtocolNumber").data("originalValue");
			protocol = (protocol == "" || protocol == null) ? "Not%20Available" : protocol;
			document.location.href = "ProposalProjectDetails.aspx?opportunityNumber=" + $("#txtOpportunityNumber").val() + "&protocolNumber=" + protocol;

		}
	},
	IsPeoplePickerValid: function () { return ppNs.isValidUserSelected(true); },
	IsProjectFormValid: function () {
		var isValid = !rm.validation.hasControlsWithErrors();
		if ($("#txtOpportunityNumber").val() == "") {
			isValid = false;
		}

		if ($("#txtProposalDueDate").val() == "") {
			rm.validation.addError("#txtProposalDueDate", Resources.EnterProposalDueDate);
			isValid = false;
		}
		if ($("#txtExpectedStartDate").val() == "") {
			rm.validation.addError("#txtExpectedStartDate", Resources.EnterExpectedStartDate);
			isValid = false;
		}
		if (!proposalNs.IsPeoplePickerValid()) { isValid = false; }

		if ($("[id$=_ddlOrganization]").val() == "-1") {
			rm.validation.addError("[id$=_ddlOrganization]", Resources.ProjectOrganizationalUnitRequired);
			isValid = false;
		}

		if ($("[id$=_ddlTherapeuticArea]").val() == "-1") {
			rm.validation.addError("[id$=_ddlTherapeuticArea]", Resources.TherapeuticAreaRequired);
			isValid = false;
		}

		if (!proposalNs.IsItemSelected("#indicationsDropDownContainer", "ItemsCollection")) {
			rm.validation.addError("#indicationsDropDownContainer", Resources.IndicationsRequired);
			isValid = false;
		}

		return isValid;
	},
	ResetProjectForm: function () {
		proposalNs.EnableDisableRibbonIconsOnProjectDirtyChange(false);
		proposalNs.projectId = -1;
		$("div#divProposalProjectDetails input").val("");
		$("div#divProposalProjectDetails select").val("-1");
		ppNs.clearControl();//Clear people picker error
		proposalNs.PopulateProposedRegions(null);
		proposalNs.PopulateProposedCountries(null);
		proposalNs.PopulateIndications(null);
		proposalNs.PopulateServices(null);
		rm.formStatus.clearDirty(proposalNs.getJsonObjectForProjectDetails());
		proposalNs.ClearAllErrors();
	},
	ClearAllErrors: function () {
		rm.validation.clearAllErrors("#indicationsDropDownContainer div#divProposalProjectDetails input,div#divProposalProjectDetails select");
		ppNs.clearError();//Clear people picker error
		rm.validation.clearError($("#indicationsDropDownContainer"));
	},
	ShowProposalProjectSelectionModal: function () {
		$("#divOpportunity").dialog({
			modal: true,
			cache: false,
			title: "Select Opportunity Number",
			resizable: false,
			width: 300,
			height: 120,
			open: function () {
				$('.ui-dialog-titlebar-close').unbind('click');
				$("#d_cancelButton,.ui-dialog-titlebar-close").click(function () { $("#divOpportunity").dialog('close'); });
				proposalNs.SetupProjectAutoComplete($('#txtOpportunityNumderDialogTextBox').val("").focus());
			}
		});
	},
	MapProjectValuesToControls: function (data, callRefreshUi) {
		if (ProjectStage_E.Prospecting == data.ProjectStageId || ProjectStage_E.Qualification == data.ProjectStageId ||
			ProjectStage_E.Ballpark == data.ProjectStageId || ProjectStage_E.Bid_Requested == data.ProjectStageId ||
			ProjectStage_E.Proposal_Sent == data.ProjectStageId || ProjectStage_E.Verbally_Agreed == data.ProjectStageId) {
			if (callRefreshUi) {
				rm.ui.ribbon.refresh();
			}
			proposalNs.projectId = data.ProjectId;
			$("#txtOpportunityNumber").val(data.ProjectCode);
			$("#txtProjectCode").val(data.ProjectCode);
			$("#txtCustomer").val(data.CustomerName);
			$("#txtSponsor").val(data.Sponsor);
			$("#txtRFPReceivedDate").val(data.RfpReceivedDate);
			$("#txtExpectedStartDate").val(data.ExpectedStartDate);

			//Update people picker and lookup value
			ppNs.setDisplayName(data.ProposalLead);
			setTimeout(function () { ppNs.lookupUser(true); }, 10);

			$("#txtProposalType").val(data.ProposalTypeName);
			$("#txtProposalDueDate").val(data.ProposalDueDate);
			$("#txtStratCallDate").val(data.StratCallDate);
			$("#txtPrepCallMeetingDate").val(data.PrepCallMeetingDate);
			$("#txtProtocolNumber").val(data.ProtocolNumber).data("originalValue", data.ProtocolNumber);
			$("#txtBidDefenseLocation").val(data.BidDefenseLocation);
			$("#txtBidDefenseDate").val(data.BidDefenseDate);
			$("[id$=ddlWinProbability]").val(data.WinProbabilityId);
			$("#txtBudget").val(data.Budget);
			$("#txtStageName").val(data.ProjectStageName);
			$("#txtProgramIdentifier").val(data.ProgramIdentifier);
			$("[id$=ddlTherapeuticArea]").val(data.TherapeuticAreaId);
			$("[id$=ddlStudyPhase]").val(data.StudyPhaseId);
			$("#txtNumberOfSites").val(data.NumberOfSites);
			$("#NumberOfPatients").val(data.NumberOfPatients);
			$("[id$=_ddlOrganization]").val(data.OrganizationUnitId);

			proposalNs.PopulateProposedRegions(data.ProjectCountryAndRegion ? data.ProjectCountryAndRegion.RegionList : null);
			proposalNs.PopulateProposedCountries(data.ProjectCountryAndRegion ? data.ProjectCountryAndRegion.CountryList : null);
			proposalNs.PopulateIndications(data.Indications);
			proposalNs.PopulateServices(data.Services);

			$("#countryDropDownContainer").data("InitialItemsCollection", data.ProjectCountryAndRegion ? data.ProjectCountryAndRegion.CountryList : null);
			proposalNs.ClearAllErrors();
			rm.ui.messages.clearAllMessages();

			setTimeout(function () {
				rm.formStatus.clearDirty(proposalNs.getJsonObjectForProjectDetails());
				rm.ui.ribbon.delayedRefresh();
			}, 20);
		}
		else if (ProjectStage_E.Opportunity_Won_LOI_COO_Agreed == data.ProjectStageId ||
			ProjectStage_E.Opportunity_Won_Repricing == data.ProjectStageId ||
			ProjectStage_E.Signed_Contract == data.ProjectStageId ||
			ProjectStage_E.Opportunity_Closed_Lost == data.ProjectStageId ||
			ProjectStage_E.Stopped == data.ProjectStageId ||
			ProjectStage_E.Change_Cancellation_Not_Awarded == data.ProjectStageId ||
			ProjectStage_E.Change_Cancellation_Awarded == data.ProjectStageId ||
			ProjectStage_E.Ballpark_Stopped == data.ProjectStageId ||
			ProjectStage_E.Opportunity_Won == data.ProjectStageId) {
			rm.ui.messages.addError(Resources.ProposalResourcesNotAssignedItsAwarded);
			proposalNs.ResetProjectForm();
			proposalNs.disableAllControls();
		}
	},
	HandleCustomErrors: function (validationErrors, protocolNumber) {
		$.each(validationErrors, function (index, ele) {
			var arrayMessagesfordialog = new Array();
			if (ele.MessageType == MessageType_E.CustomHandling) {
				arrayMessagesfordialog.push(ele.Value);
			}

			if (arrayMessagesfordialog.length > 0) {
				var htmlMessage = "Protocol Number (" + protocolNumber + ") does not match in Salesforce CRM and Quintiles middleware." +
					"Please correct this. Then wait up to 48 hours for the changes to be available in QRPM:RM." +
					"The available Protocol Numbers in middleware are: <br/><br/>" +
					"<table class='validationTable'><tr class='headerRow'><td valign='top'>Available Protocols</td></tr>";
				$.each(arrayMessagesfordialog, function (index, message) {
					htmlMessage += "<tr><td>" + message + "</td></tr>";
				});
				htmlMessage += "</table>";
				rmCommon.showDialogWithOkButton("Protocol Mismatch", htmlMessage, null);
			}
		});
	},
	ChangeProposalProject: function (opportunityNumberProtocolNumber, callRefreshUi) {
		if (proposalNs.IsProjectFormDirty()) {
			if (!confirm("There are unsaved changes on \"Proposal Form\". " + Resources.OkToContinueCancelToStayOnCurrentPage)) {
				return false;
			}
		}

		proposalNs.ClearAllErrors();

		if (!opportunityNumberProtocolNumber || opportunityNumberProtocolNumber == "" || opportunityNumberProtocolNumber.indexOf("-") == -1) {
			alert("The Project and protocol combination selected is invalid. Please try again.");
			return false;
		}

		$("#d_cancelButton").click();

		var indexOfHyphen = opportunityNumberProtocolNumber.indexOf("-");
		var opportunityNumber = $.trim(opportunityNumberProtocolNumber.substring(0, indexOfHyphen));
		var protocolNumber = $.trim(opportunityNumberProtocolNumber.substring(indexOfHyphen + 1, opportunityNumberProtocolNumber.length));

		if (opportunityNumberProtocolNumber != "") {
			rm.ajax.projectSvcAsyncPost("GetProposalProjectDetails", { opportunityNumber: opportunityNumber, protocolNumber: protocolNumber }, function (data) {
				if (data.ContainsValidationErrors) {
					rm.validation.processErrorMessages(data.ValidationErrors);
					proposalNs.ResetProjectForm();
					proposalNs.HandleCustomErrors(data.ValidationErrors, protocolNumber);
				}
				else {
					proposalNs.enableAllControls();
					var additionalData = data.RequestExecutionStatus[0].AdditionalData;
					proposalNs.MapProjectValuesToControls(additionalData, callRefreshUi);
					setTimeout(function () { proposalNs.EnableDisableRibbonIconsOnProjectDirtyChange(false); }, 10);
				}
			});
		}
	},
	SetupProjectAutoComplete: function (TextboxObj) {
		if (proposalNs.typeAheadBound === false) {
			rm.ajax.projectSvcAsyncPost("GetProposalProjectList", {}, function (data) {
				//bind the autocomplete plugin to the search box
				TextboxObj.unbind("keypress").autocomplete({
					//source: data.split(","),
					source: data,
					matchContains: false
				}).keypress(function (e) {
					if (e.keyCode === 13) {
						proposalNs.ChangeProposalProject($(this).val(), true);
					}
				});

				//When option in list is selected, do something
				TextboxObj.unbind("autocompleteselect").bind("autocompleteselect", function (event, ui) {
					proposalNs.ChangeProposalProject(ui.item.value, true);
				});

				$("#d_okButton").unbind("click").click(function () { proposalNs.ChangeProposalProject(TextboxObj.val(), true); });

				proposalNs.typeAheadBound = true;
			},
				function () { alert('Unable to load list of proposal projects.'); });
		}
	},
	ClearRecentProposalProjectsList: function () {
		if (confirm("Clear your list of recently accessed projects?")) {
			rm.ajax.utilitySvcAsyncPost("DeleteRecentProjects", { OpportunityStatus: OpportunityStatus_E.Open }, function () { rm.utilities.reloadPage() });
		}
	},
	IsMultiselectDirty: function () {
		var isDirty = $("#proposalRegionHyperlink").dropdownV2("isDirty", "regionDropDownContainer");
		if (!isDirty) {
			isDirty = $("#proposalCountryHyperlink").dropdownV2("isDirty", "countryDropDownContainer");
			if (!isDirty) {
				isDirty = $("#proposalIndicationsHyperlink").dropdownV2("isDirty", "indicationsDropDownContainer");
				if (!isDirty) {
					isDirty = $("#proposalServicesHyperlink").dropdownV2("isDirty", "servicesDropDownContainer");
				}
			}
		}
		return isDirty;
	},
	IsProjectFormDirty: function () {
		var isDirty = rm.formStatus.isDirty(proposalNs.getJsonObjectForProjectDetails());
		if (!isDirty) {
			isDirty = proposalNs.IsMultiselectDirty();
		}
		return isDirty;
	},
	getJsonObjectForProjectDetails: function () {
		return { items: [{ selector: "#peoplePickerDirtyFlag,#divProposalProjectDetails input:text,#divProposalProjectDetails select", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},
	GetJsonObjectForEntirePage: function () {
		var selector = proposalNs.getJsonObjectForProjectDetails().items[0].selector;
		return { items: [{ selector: selector, dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},
	RefetchProjectDetails: function () {
		var url = $.url();
		if (url.param("opportunityNumber")) {
			proposalNs.ChangeProposalProject(url.param("opportunityNumber") + " - " + url.param("protocolNumber"), false);
		}
	},
	disableAllControls: function () {
		$(proposalNs.getJsonObjectForProjectDetails().items[0].selector).attr("disabled", "disabled");
		rm.ui.utilities.disableDatePicker(proposalNs.dateFieldSelectors);
		$(".multiselectDropdownContainer").attr("disabled", "disabled");
	},
	enableAllControls: function () {
		$(proposalNs.getJsonObjectForProjectDetails().items[0].selector).removeAttr("disabled");
		rm.ui.utilities.enableDatePicker(proposalNs.dateFieldSelectors);
		$(".multiselectDropdownContainer").removeAttr("disabled");
		ppNs.enable();//enable people picker
	}
};

$(document).ready(function () {
	rm.runtimeValues.helpPageUrl = "Proposal-Request.aspx";
	$("#ProposalProjectDetails").addClass("left-static-selected-menu");

	proposalNs.disableAllControls();

	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });

	rm.qtip.showInfo("#proposalFormHeader", "Select Opportunity number", {}, {}, { at: 'top left' });
	$(proposalNs.dateFieldSelectors).qDatepicker().qDatepicker("disable");

	var elements = $("input[type=text],select");


	$("[class~=validateRange]").bind('blur', function () { rm.utilities.formatTextboxText(this); });

	rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, proposalNs.GetJsonObjectForEntirePage());

	$(document).bind("keyup click", function () {
		proposalNs.EnableDisableRibbonIconsOnProjectDirtyChange(proposalNs.IsProjectFormDirty());
	});

	proposalNs.RefetchProjectDetails();
	$("[readonly=readonly]").keydown(rm.utilities.preventNavigationOnBackSpace);

	$(ppNs.divPeoplePickerSelector).on("lookupComplete.pp", function () {
		setTimeout(function () { rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, proposalNs.GetJsonObjectForEntirePage()); }, 10);
	});
	$(ppNs.divPeoplePickerSelector).on("valueChange.pp", function () {
		$("#peoplePickerDirtyFlag").val("1");
		setTimeout(function () { proposalNs.EnableDisableRibbonIconsOnProjectDirtyChange(proposalNs.IsProjectFormDirty()); }, 10);
	});
	setTimeout(function () {
		$(".hasDatepicker").bind("change", function () {
			proposalNs.EnableDisableRibbonIconsOnProjectDirtyChange(rm.formStatus.isDirty(proposalNs.getJsonObjectForProjectDetails()));
		});
	}, 200);

	$("#indicationsDropDownContainer").bind("ItemCheckChanged", function (event, isChecked, checkedItemCouont) {
		if (checkedItemCouont == 0) {
			rm.validation.addError("#indicationsDropDownContainer", Resources.IndicationsRequired);
		}
		else {
			rm.validation.clearError($("#indicationsDropDownContainer"));
		}
	});

	$("[id$=_ddlOrganization]").bind("change", function () {
		rm.validation.clearError($(this));
	})

	$("[id$=_ddlTherapeuticArea]").bind("change", function () {
		rm.validation.clearError($(this));
	})
});
