﻿/// <reference path="../common/rmhelper.js" />
rmProjNs = {
	projectId: -1,
	projectDescriptionMaxLength: 250,
	isSaveButtonEnabled: function () { return rmProjNs.isProjectFormDirty(); },
	isCancelButtonEnabled: function () { return rmProjNs.isProjectFormDirty(); },
	projectDescriptionKeyup: function () {
		$('#txtProjectDescription').keyup(function () {
			if ($.q.textCounter(this, rmProjNs.projectDescriptionMaxLength, "#lblDescLength")) {
				rm.validation.clearError($(this));
			}
			else {
				rm.validation.addError($(this), "Maximum character limit: " + rmProjNs.projectDescriptionMaxLength);
			}
		});
	},
	populateIndications: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "indicationsDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { rm.ui.ribbon.refresh(); }
		};
		$("#RMIndicationsHyperlink").dropdownV2(dropdownOptions);
	},
	getMultiselectValue: function (selector, dataKey) {
		var data = $(selector).data(dataKey);
		var selectedItems = [];
		if (data) {
			$.each(data, function (index, item) {
				if (item.isChecked != item.wasOriginallyChecked) {
					selectedItems.push({
						key: item.key,
						//value: item.value, no need to send text vaues. Uncomment for debugging
						isChecked: item.isChecked,
						dmlOperation: item.isChecked ? DMLOperation_E.Insert : DMLOperation_E.Delete
					});
				}
			});
		}
		return selectedItems;
	},
	getPostData: function () {
		return {
			projectDetails: {
				ProjectId: rmProjNs.projectId,
				CustomerName: $("#txtCustomer").val(),
				Sponsor: $("#txtSponsor").val(),
				ProjectAwardDate: $("#txtProjectAwardDate").val(),
				InitialSiteInitiationTarget: $("#txtInitialSiteDate").val(),
				NumberOfSites: $("#txtNumberOfSites").val(),
				NumberOfCountries: $("#txtNoOfCountries").val(),
				ProjectDescription: $("#txtProjectDescription").val(),
				TherapeuticAreaId: $("[id$=ddlTherapeuticArea]").val(),
				Indications: rmProjNs.getMultiselectValue("#indicationsDropDownContainer", "ItemsCollection", false),
				CompetencyBandID: $("[id$=ddlCompetencyBand]").val(),
				IsClinicalRedesignProject: $("[name=clinicalRedesignProject]:checked").val() == "1",
				DTEStudyType: $("[name=DTEStudyType]:checked").val()
			}
		};
	},
	cancelRmProject: function () {
		var isDirty = rmProjNs.isProjectFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			rm.utilities.reloadPage();
		}
	},
	saveRmProject: function () {
		$(document).trigger('click');
		var allInputs = $(".validateRange:visible");
		$.each(allInputs, function () { $.q.rangeValidate($(this)); });

		if (rmProjNs.isProjectFormValid()) {
			if (confirm(Resources.ProjectBackgroundSaveAlert)) {
				rm.ajax.projectSvcAsyncPost("UpdateRMProjectDetails", rmProjNs.getPostData(), function (serviceResponse) {
					rmProjNs.mapProjectValuesToControls(serviceResponse);
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess(Resources.RMProjectSavedSuccessfully);
					rmProjNs.showMilestoneUpdateReminder();
				});
			}
		}
		else { rm.ui.messages.addError(Resources.CorrectErrorsTryAgain); }
	},
	isProjectFormValid: function () { return $.validationHelper.IsFormValid(); },
	clearAllErrors: function () {
		rm.validation.clearAllErrors("div#divRMProjectDetails input,div#divRMProjectDetails textarea,div#divRMProjectDetails select");
	},
	mapProjectValuesToControls: function (data) {
		rmProjNs.projectId = data.ProjectId;
		$("#txtProjectCode").val(data.ProjectCode);
		$("#txtCustomer").val(data.CustomerName);
		$("#txtSponsor").val(data.Sponsor);
		$("#txtProtocolNumber").val(data.ProtocolNumber);
		$("[id$=ddlTherapeuticArea]").val(data.TherapeuticAreaId);
		$("#txtNumberOfSites").val(data.NumberOfSites);
		$("#txtProjectAwardDate").val(data.ProjectAwardDate);
		$("#txtNoOfCountries").val(data.NumberOfCountries);
		$("#txtProjectDescription").val(data.ProjectDescription);
		$("[id$=ddlCompetencyBand]").val(data.CompetencyBandID);
		$("#lblDescLength").html(rmProjNs.projectDescriptionMaxLength - $("#txtProjectDescription").val().length);
		$("#txtInitialSiteDate").val(data.InitialSiteInitiationTarget);
		rmProjNs.populateIndications(data.Indications);

		$("[name=clinicalRedesignProject][value=" + (data.IsClinicalRedesignProject ? "1" : "0") + "]").prop("checked", "checked");
		$("[name=DTEStudyType][value=" + data.DTEStudyType + "]").prop("checked", "checked");

		rmProjNs.clearAllErrors();
		rm.ui.messages.clearAllMessages();

		setTimeout(function () {
			$.formStatus.clearDirty(rmProjNs.getJsonObjectForProjectDetails());
			setTimeout(rm.ui.ribbon.refresh, 10);
		}, 20);
	},
	isMultiselectDirty: function () { return $("#RMIndicationsHyperlink").dropdownV2("isDirty", "indicationsDropDownContainer"); },
	isProjectFormDirty: function () { return $.formStatus.isDirty(rmProjNs.getJsonObjectForProjectDetails()) || rmProjNs.isMultiselectDirty(); },
	getJsonObjectForProjectDetails: function () {
		return { items: [{ selector: "#divRMProjectDetails input:text,#divRMProjectDetails textarea,#divRMProjectDetails select,#divRMProjectDetails input:radio", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},
	getJsonForEntirePage: function () {
		var selector = rmProjNs.getJsonObjectForProjectDetails().items[0].selector;
		return { items: [{ selector: selector, dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},
	showProjectDetails: function () {
		if (selectedProjectDetails.projectCode) {
			rmProjNs.reloadProjectDataFromDatabase(selectedProjectDetails.projectCode + " - " + selectedProjectDetails.protocolNumber, false);
		}
	},
	refreshProjectDataFromCrm: function () {
		if (confirm(Resources.ConfirmCrmRefresh) && selectedProjectDetails.projectCode) {
			rmProjNs.reloadProjectDataFromDatabase(selectedProjectDetails.projectCode + " - " + selectedProjectDetails.protocolNumber, true);
		}
	},
	reloadProjectDataFromDatabase: function (opportunityNumberProtocolNumber, queryCRM) {
		if (rmProjNs.isProjectFormDirty() && !confirm("There are unsaved changes on Form\". " + Resources.OkToContinueCancelToStayOnCurrentPage)) {
			return false;
		}

		rmProjNs.clearAllErrors();

		if (!opportunityNumberProtocolNumber || opportunityNumberProtocolNumber == "" || opportunityNumberProtocolNumber.indexOf("-") == -1) {
			alert("The Project and protocol combination selected is invalid. Please try again.");
			return false;
		}

		var indexOfHyphen = opportunityNumberProtocolNumber.indexOf("-");
		var opportunityNumber = $.trim(opportunityNumberProtocolNumber.substring(0, indexOfHyphen));
		var protocolNumber = $.trim(opportunityNumberProtocolNumber.substring(indexOfHyphen + 1, opportunityNumberProtocolNumber.length));

		var postData = { projectCode: opportunityNumber, protocolNumber: protocolNumber, organizationPrefix: "", queryCRM: queryCRM, autogeneratedProtocolNumber: "" };
		rm.ajax.projectSvcAsyncPost("GetRMProjectDetails", postData, function (data) {
			if (data.ContainsValidationErrors) {
				$.validationHelper.ShowErrorMessages(data.ValidationErrors);
			}
			else {
				var additionalData = data.RequestExecutionStatus[0].AdditionalData;
				rmProjNs.mapProjectValuesToControls(additionalData);

				if (queryCRM) {
					if (additionalData.CrmProjectAvailable) { rm.ui.messages.showSuccess("The project has been refreshed data from CRM"); }
					else { rm.ui.messages.showSuccess("The project is not available in CRM hence no data has been refreshed"); }
				}
				setTimeout(rm.ui.ribbon.refresh, 10);
			}
		});
	},
	showMilestoneUpdateReminder: function () {
		if (selectedProjectDetails.projectCode) {
			var projectCode = selectedProjectDetails.projectCode;
			var protocol = selectedProjectDetails.protocolNumber || "Not Available";
			rm.ui.messages.showWarningWithCloseButton(Resources.ProjectMilestoneSetupReminder.replace("{0}", projectCode).replace("{1}", protocol));
		}
	}
};

$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });
	$(document).bind("keyup click", rm.ui.ribbon.refresh);
	$("#txtProjectAwardDate,#txtInitialSiteDate").qDatepicker().bind("change", rm.ui.ribbon.refresh);
	$("[readonly=readonly]").keydown($.q.preventNavigationOnBackSpace);

	$.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, rmProjNs.getJsonForEntirePage());

	rmProjNs.showProjectDetails();
	rmProjNs.projectDescriptionKeyup();
});
