﻿/// <reference path="../common/rmhelper.js" />

function ChangeProject(projectCode) {
	var isDirty = false;
	if (window.location.pathname.indexOf("ProjectBackground.aspx") >= 0) {
		isDirty = rmProjNs.isProjectFormDirty();
	}
	else if (window.location.pathname.indexOf("ProjectConfiguration.aspx") >= 0) {
		isDirty = milestoneNs.checkPageDirty() || dteSchemaNs.isPageDirty();
	}

	if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
		if (projectCode != null && projectCode != "") {
			ReloadPageWithProjectCode(projectCode);
		}
		else {
			var h = "";
			h += "<div id='SelectProjectDialog' class='ssvRequestPaddingTable'><form id='frmDialog' onsubmit='return false;'>";
			h += "<table class='styleWidthNinety'>";
			h += "    <tr>";
			h += "        <td>Project&nbsp;Code</td>";
			h += "        <td><input type='text' name='Q_ProjectList_DialogTextBox' id='Q_ProjectList_DialogTextBox'/></td>";
			h += "    </tr>";
			h += "</table></form></div>";

			var okButton = {
				text: "OK", click: function () {
					ReloadPageWithProjectCode($('#Q_ProjectList_DialogTextBox').val());
					$(this).dialog("close");
				}
			};
			var title = (GetCurrentProjectName() == "") ? "Select Project" : "Change Project";
			rm.ui.dialog.showModalWithButtonsAndCloseHandler("#divDialog", title, h, false, 300, 150, [okButton, rm.ui.dialog.standardButtons.cancel], null, function () {
				SetupProposalAndAwardedProjectAutoComplete($('#Q_ProjectList_DialogTextBox'));
				$('#Q_ProjectList_DialogTextBox').focus();
			});
		}
	}
}

function JumpToProjectSite() {
	rm.ui.dialog.showWaitModalWithNoClose("Redirecting to " + GetCurrentProjectName() + "'s Project Site");
	//document.location = "http://qrpm-dev.quintiles.com/pwa/" + GetCurrentProjectName() + "/";
	document.location = "http://ppm.quintiles.com/pwa/projects.aspx";
}

var editProject = {
	projectCustomFieldContainerSelector: ".projectCustomFieldContainer",
	projectCustomfieldSelector: ".projectCustomField",
	txtInitialAwardDateSelector: "[id$=txtInitialAwardDate]",
	ddlSivFsiWeeksSelector: "[id$=ddlSivFsiWeeks]",
	ddlFsiImvWeeksSelector: "[id$=ddlFsiImvWeeks]",
	ddlImvWindowWeeksSelector: "[id$=ddlImvWindowWeeks]",
	ddlWinProbabilitySelector: "[id$=ddlWinProbability]",
	ddlInitialSiteTieringSelector: "[id$=ddlInitialSiteTiering]",
	ddlStopMissingPclAlertsSelector: "[id$=ddlStopMissingPclAlerts]",
	projectId: "[id$=hdnProjectId]",
	hdnInitialTieringPerformedSelector: "[id$=hdnInitialTieringPerformed]",
	lblInitialAwardedDateSelector: "[id$=lblInitialAwardedDate]",
	hasPermissionToEnableDisableInitialSiteTieringSelector: "[id$=HasPermissionToEnableDisableInitialSiteTiering]",
	isProposalProject: function () { return $("[id$=hdnIsProposalProject]").val() == "1"; },
	isRmProject: function () { return !editProject.isProposalProject() && $("[id$=OrganizationType]").val() == OrganizationType_E.RmSingleService },
	isCancelChangesEnabled: function () { return editProject.isFormDirty(); },
	isStopEditingEnabled: function () { return $(editProject.ddlSivFsiWeeksSelector).length != 0 && !$(editProject.ddlSivFsiWeeksSelector).is(":disabled"); },
	isEditProjectEnabled: function () { return editProject.isProposalProject() || editProject.isRmProject() || ($(editProject.ddlSivFsiWeeksSelector).length != 0 && $(editProject.ddlSivFsiWeeksSelector).is(":disabled")); },
	isSaveProjectEnabled: function () { return editProject.isFormDirty(); },
	hasPermissionToEnableDisableInitialSiteTiering: function () { return $(editProject.hasPermissionToEnableDisableInitialSiteTieringSelector).val() == "1"; },
	isInitialSiteTieringAlreadyPerformed: function () { return $(editProject.hdnInitialTieringPerformedSelector).val() == "1"; },

	bindChangeEvents: function () {
		$(editProject.getJsonForFormDirtyBinding().items[0].selector).change(editProject.refreshRibbonWithDelay);
		$(editProject.txtInitialAwardDateSelector).bind("keydown cut paste drop", editProject.refreshRibbonWithDelay);
	},
	bindToolTips: function () {
		var styleConfig = { width: '160px' };
		rm.qtip.showInfo("#ProjectedFSI", "Projected First Subject In", styleConfig);
		rm.qtip.showInfo("#ProjectedLSI", "Projected Last Subject In", styleConfig);
		rm.qtip.showInfo("#SIVFSI", "Site Initiation Visit - First Subject In interval represents the admin time, in weeks, between the Site Initiation Visit and the First Subject In. The default is 12 weeks.", styleConfig);
		rm.qtip.showInfo("#FSIFirstIMV", "‘First Subject In - First Interim Monitoring Visit interval represents the gap in time, in weeks, between the First Subject In and First Interim Monitoring Visit. The default is 1 week.", styleConfig);
		rm.qtip.showInfo("#ImvWindow", "The 'Forthcoming Site Visits' report (for CRAs and their Line Managers) displays RM's projections of forthcoming Interim Monitoring Visits.<br/><br/>Enter an (/- weeks) allowance to enable the report to also display the earliest (Positive) and latest (Negative) dates for each visit. Entering, e.g., '/- 1 week' here will cause the report to display a two week range (Visit Date -1 week to Visit Date +1 week) in which to make their visit", styleConfig);
		rm.qtip.showInfo($("[id$=ProjectDetailsContainer_InitialAwardedDate]"), Resources.InitialAwardedDateTooltip, styleConfig);

		var msg = editProject.isInitialSiteTieringAlreadyPerformed() ?
								"Initial Site Tiering has already been run for this Project, and therefore cannot be run again." :
								"Set to Yes to enable Initial Site Tiering in the Site List page. Initial Site Tiering can be run only once per Project.";
		rm.qtip.showInfo("#infoInitialSiteTiering", msg, styleConfig);
	},
	saveProject: function () {
		if (editProject.isProposalProject()) { editProject.saveProposalProject(); }
		else { editProject.saveAwardedProject(); }
	},
	saveAwardedProject: function () {
		if (editProject.isFormValid()) {
			rm.ajax.projectSvcAsyncPost("UpdatePPMProjectDetails", editProject.getProjectPostData(), function (data) {
				rm.ui.messages.showSuccess('Project Data Saved sucessfully');
				if ($(editProject.ddlImvWindowWeeksSelector).val() != "") {
					$(editProject.ddlImvWindowWeeksSelector + " option[value='']").remove();
				}
				editProject.updateUiMetadata(data);
				editProject.bindDirty();
				setTimeout(editProject.stopEditing, 10);
			});
		}
	},
	saveProposalProject: function () {
		if (editProject.isProposalFormValid()) {
			rm.ajax.projectSvcAsyncPost("UpdateProposalProjectSummary", editProject.getProposalProjectPostData(), function (data) {
				rm.ui.messages.showSuccess('Project Data Saved sucessfully');
				if ($(editProject.ddlWinProbabilitySelector).val() != "") {
					$(editProject.ddlWinProbabilitySelector + " option[value='']").remove();
				}
				editProject.bindDirty();
				setTimeout(editProject.stopEditing, 10);
			});
		}
	},
	updateUiMetadata: function (response) {
		//set the dbid in each custom field so that next save without page refresh update the existing fields instead of creating new ones
		if (response != null && response.ProjectCustomFields != null) {
			$.each(response.ProjectCustomFields, function (index, customField) {
				$("[CustomFieldId=" + customField.CustomFieldId + "]").attr("dbid", customField.Id);
			});
		}
	},
	cancelChanges: function () {
		if (editProject.isFormDirty() && (confirm(Resources.UnsavedChangesOnThePage))) {
			editProject.resetForm();
			editProject.refreshRibbonWithDelay();
		}
	},
	stopEditing: function () {
		var isFormDirty = editProject.isFormDirty();
		if (!isFormDirty || (isFormDirty && (confirm(Resources.UnsavedChangesOnThePage)))) {
			editProject.resetForm();
			editProject.lockControls();
		}
	},
	refreshRibbonWithDelay: function () { rm.ui.ribbon.delayedRefresh(); },
	bindDirty: function () { $.formStatus.bindDirty(Resources.UnsavedChangesOnThePage, editProject.getJsonForFormDirtyBinding()); },
	clearFormDirty: function () { $.formStatus.clearDirty(editProject.getJsonForFormDirtyBinding()); },
	resetForm: function () {
		$.formStatus.resetForm(editProject.getJsonForFormDirtyBinding());
		$(editProject.txtInitialAwardDateSelector).removeClass("q_validation_error");
	},

	getJsonForFormDirtyBinding: function () { return { items: [{ selector: editProject.ddlWinProbabilitySelector + "," + editProject.ddlImvWindowWeeksSelector + "," + editProject.txtInitialAwardDateSelector + "," + editProject.ddlFsiImvWeeksSelector + "," + editProject.ddlSivFsiWeeksSelector + "," + editProject.projectCustomfieldSelector + "," + editProject.ddlStopMissingPclAlertsSelector + "," + editProject.ddlInitialSiteTieringSelector }] }; },
	lockControls: function () {
		$(editProject.txtInitialAwardDateSelector).attr("disabled", "disabled").qDatepicker({ destroy: true });
		$(editProject.ddlSivFsiWeeksSelector).attr("disabled", "disabled");
		$(editProject.ddlFsiImvWeeksSelector).attr("disabled", "disabled");
		$(editProject.ddlImvWindowWeeksSelector).attr("disabled", "disabled");
		$(editProject.projectCustomfieldSelector).attr("disabled", "disabled");
		$(editProject.ddlStopMissingPclAlertsSelector).attr("disabled", "disabled");
		$(editProject.ddlInitialSiteTieringSelector).attr("disabled", "disabled");
		$(editProject.ddlWinProbabilitySelector).attr("disabled", "disabled");

		editProject.refreshRibbonWithDelay();
	},
	isFormDirty: function () { return $.formStatus.isDirty(editProject.getJsonForFormDirtyBinding()); },
	editProject: function () {
		rm.ui.tabs.activateByIndex("#tabs", 0);
		if (LoggedInUser.IsAdmin || LoggedInUser.IsDemandPlanner || LoggedInUser.IsSupport) {
			$(editProject.txtInitialAwardDateSelector).attr("disabled", null).qDatepicker();
		}
		$(editProject.ddlSivFsiWeeksSelector).attr("disabled", null);
		$(editProject.ddlFsiImvWeeksSelector).attr("disabled", null);
		$(editProject.ddlImvWindowWeeksSelector).attr("disabled", null);
		$(editProject.projectCustomfieldSelector).not("[readonly]").attr("disabled", null);
		$(editProject.ddlStopMissingPclAlertsSelector).attr("disabled", null);
		$(editProject.ddlWinProbabilitySelector).attr("disabled", null);
		if (!editProject.isInitialSiteTieringAlreadyPerformed() && editProject.hasPermissionToEnableDisableInitialSiteTiering()) { $(editProject.ddlInitialSiteTieringSelector).attr("disabled", null); }
		editProject.bindDirty();
		editProject.refreshRibbonWithDelay();
	},
	getProposalProjectPostData: function () {
		return {
			projectSummary: {
				ProjectId: $(editProject.projectId).val(),
				WinProbabilityId: $(editProject.ddlWinProbabilitySelector).val()
			}
		};
	},
	getProjectPostData: function () {
		return {
			projectDetails: {
				ProjectId: $(editProject.projectId).val(),
				InitialAwardedDate: $(editProject.txtInitialAwardDateSelector).val(),
				SivFsiWeeks: $(editProject.ddlSivFsiWeeksSelector).val(),
				FsiImvWeeks: $(editProject.ddlFsiImvWeeksSelector).val(),
				ImvWindowWeeks: rm.utilities.getNullIfEmpty($(editProject.ddlImvWindowWeeksSelector).val()),
				ProjectCustomFields: editProject.getCustomFieldData(),
				StopMissingPrimaryClAlerts: ($(editProject.ddlStopMissingPclAlertsSelector).val() == "1"),
				AllowInitialSiteTiering: editProject.hasPermissionToEnableDisableInitialSiteTiering() ? ($(editProject.ddlInitialSiteTieringSelector).val() == "1") : ($(editProject.ddlInitialSiteTieringSelector).data("initial") == "1")
			}
		};
	},
	getCustomFieldData: function () {
		var customFieldsList = [];
		$.each($(editProject.projectCustomFieldContainerSelector), function (index, tableRow) {
			var customFieldObj = $(tableRow).find(editProject.projectCustomfieldSelector).not("[readonly]");
			if (customFieldObj.length != 0) {
				var customField = customFieldObj[0];
				customFieldsList.push({
					ProjectId: $(editProject.projectId).val(),
					Id: $(customField).attr("DbId"),
					CustomFieldId: $(customField).attr("CustomFieldId"),
					Value: rm.customFields.getCustomFieldValue($(customField))
				});
			}
		});
		return customFieldsList;
	},
	isFormValid: function () {
		return !$(editProject.txtInitialAwardDateSelector).hasClass("q_validation_error");
	},
	isProposalFormValid: function () {
		return $(editProject.ddlWinProbabilitySelector).val() != "";
	},
};
function EditProjectBackground() {
	var projectSource = $("[id$=lblProjectSource]").html();
	if (projectSource == "PPM" || projectSource == "SES") {
		editProject.editProject();
	}
	else {
		document.location = "/_Layouts/SPUI/profile/ProjectBackground.aspx";
	}
};

function ClearRecentProjectsList() {
	if (confirm("Clear your list of recently accessed projects?")) {
		rm.ui.dialog.showWaitModalWithNoClose("Clearing List");
		var url = $.url();
		var href = url.attr('path');

		document.location = href + "?clearRecents=true";
	}
}

$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });
	editProject.bindDirty();
	editProject.bindChangeEvents();
	$(editProject.projectCustomfieldSelector).attr("disabled", "disabled");
	editProject.bindToolTips();
});
var FirewallProject = {
	firewallProjectDialog: "#FirewallProjectDiaLog",
	removeFunctionString: "FirewallProject.DeleteFirewallProject(this);",
	firwallProjectTextBox: "#FirewallProjectList_DialogTextBox",
	firwallProjectLabel: "[id$=lblFirewalledStudies]",
	firwallProjectLabelForSingleServiceProject: "[id$=lblFirewalledStudiesForSingleServiceProject]",
	firwallProjectContainer: "#projectList ul",
	projectId: "[id$=hdnProjectId]",
	projectList: new Array(),
	enterKeyCode: 13,
	ConfigureFirewalledProjects: function () {
		FirewallProject.toggleDialogButtonEnableDisable(false);
		if ($("[id$=OrganizationType]").val() != OrganizationType_E.TDU) {
			FirewallProject.firwallProjectLabel = FirewallProject.firwallProjectLabelForSingleServiceProject;
		}
		FirewallProject.SetupProjectAutoCompleteForFirewall($(FirewallProject.firwallProjectTextBox));
		var firewalledProjectList = [];

		if ($.trim($(FirewallProject.firwallProjectLabel).text()) != "") {
			firewalledProjectList = $.trim($(FirewallProject.firwallProjectLabel).text()).split(",");
		}

		var h = "<div id='FirewallProjectDiaLog'>"
						+ "	<div>Project <input type='text' name='FirewallProjectList_DialogTextBox' id='FirewallProjectList_DialogTextBox' /></div>"
						+ "	<div><br />"
						+ "		<div id='projectList'><ul class='fieldsetLabel'></ul></div>"
						+ "	</div><br />"
						+ "</div>";

		$(FirewallProject.firwallProjectContainer).empty();
		FirewallProject.BindFirewalledProjects(firewalledProjectList);

		var saveButton = {
			text: "Save", click: function () {
				if (FirewallProject.SaveFirewalledProjects()) { $(this).dialog("close") };
			}
		};
		var buttons = [saveButton, rm.ui.dialog.standardButtons.cancel];
		rm.ui.dialog.showModalWithButtonsAndCloseHandler("#dialogContainer", "Firewalled Projects", h, false, 450, 500, buttons, null, function () { FirewallProject.toggleDialogButtonEnableDisable(false); });

		setTimeout(function () {
			FirewallProject.BindFirewalledProjects(firewalledProjectList);
			FirewallProject.SetupProjectAutoCompleteForFirewall($(FirewallProject.firwallProjectTextBox));
		}, 10);

	},
	AddSelectedProjectToFirewalledProjectsContainer: function (firewalledProject) {
		var found = $.grep(FirewallProject.projectList, function (projectItem) {
			return firewalledProject == projectItem.value;
		}).length > 0;

		if (found) {
			if (!FirewallProject.IsValuePresentInList(firewalledProject, FirewallProject.firwallProjectContainer + " li")) {
				var attributes = "entityCode='" + firewalledProject + "' ";

				$(FirewallProject.firwallProjectContainer).append('<li style="list-style: none;"><a href="#" onclick="' + FirewallProject.removeFunctionString + '" class="closeButtonAdmin">X</a> <span ' + attributes + '>' + firewalledProject + '</span></li>');
			}
		}
		else {
			rm.ui.messages.clearAllMessages();
			rm.ui.messages.addError('Invalid Project - protocolNumber');
		}
		setTimeout(function () { $(FirewallProject.firwallProjectTextBox).val(''); }, 100);
	},
	IsValuePresentInList: function (valueToCheck, selector) //sample selector "#departmentList ul li"
	{
		var valueAlreadyExists = false;

		$(selector).each(function (i, data) {
			if ($(data).find('span').attr("entityCode") == valueToCheck) {
				valueAlreadyExists = true;
				return false;
			}
		});

		return valueAlreadyExists;
	},
	DeleteFirewallProject: function (obj) {
		$(obj).closest("li").remove();
		FirewallProject.toggleDialogButtonEnableDisable(true);
	},
	BindFirewalledProjects: function (itemList) {
		if (itemList) {
			$.each(itemList, function (index, item) {
				FirewallProject.AddSelectedProjectToFirewalledProjectsContainer($.trim(item));
			});
		}
	},
	toggleDialogButtonEnableDisable: function (isEnabled) { $(".ui-dialog-buttonpane button:contains('Save')").button(isEnabled ? "enable" : "disable"); },

	SetupProjectAutoCompleteForFirewall: function (TextboxObj) {
		var resultset;

		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.projectSvcUrl + "GetAwardedProjectList?filterBasedonRMUser=false",
			dataType: "json",
			async: false,
			success: function (data) {
				FirewallProject.projectList = data;
				//bind the autocomplete plugin to the search box
				TextboxObj.autocomplete({
					source: data,
					matchContains: false
				}).keypress(function (e) {
					if (e.keyCode === FirewallProject.enterKeyCode) {
						FirewallProject.AddSelectedProjectToFirewalledProjectsContainer($.trim($(this).val()));
						FirewallProject.toggleDialogButtonEnableDisable(true);
					}
				});

				//When option in list is selected, do something
				TextboxObj.bind("autocompleteselect", function (event, ui) {
					FirewallProject.AddSelectedProjectToFirewalledProjectsContainer($.trim(ui.item.value));
					FirewallProject.toggleDialogButtonEnableDisable(true);
				});
			},
			error: function (errMsg) {
				alert('Unable to load master list of projects for Firwall configuration.');
			}
		});
	},
	SaveFirewalledProjects: function () {
		var saveSuccessful = false;
		var projectData = new Array();
		var firewalledProjects = "";;
		$(FirewallProject.firwallProjectContainer + " span").each(function (index, uiElement) {
			var jqElement = $(uiElement);
			var indexOfHyphen = $.trim(jqElement.html()).indexOf("-");
			var projectCode = $.trim(jqElement.html().substring(0, indexOfHyphen));
			var protoclNumber = $.trim(jqElement.html().substring(indexOfHyphen + 1, jqElement.html().length));
			firewalledProjects += jqElement.html() + ", ";
			projectData.push({
				ProjectCode: projectCode,
				ProtocolNumber: protoclNumber
			});
		});
		if (firewalledProjects != "") {
			firewalledProjects = firewalledProjects.substring(0, firewalledProjects.length - 2);
		}
		if ($.inArray(GetSelectedProjectCodeAndProtocol(), firewalledProjects.split(', ')) == -1) {
			var postData = { projectId: $(FirewallProject.projectId).val(), projects: projectData }
			$.rm.Ajax_ProjectSynchronous("SaveFirewalledProjects", postData, function (data) {
				rm.ui.messages.showSuccess('Firewalled Projects has been configured sucessfully');
			}, false, function (errMsg) { rm.ui.messages.addError('Error saving SaveFirewalledProjects'); });
			$(FirewallProject.firwallProjectLabel).text(firewalledProjects);
			saveSuccessful = true;
			//$(FirewallProject.firewallProjectDialog).dialog("close");
		}
		else {
			rm.ui.messages.addError('You may not Firewall a project against itself');
		}
		return saveSuccessful;
	},
	CloseFirewallDialog: function () {
		$(FirewallProject.firewallProjectDialog).dialog("close");
		$(FirewallProject.firwallProjectContainer).empty();
	}
}