﻿/// <reference path="../common/rmHelper.js" />
$(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); rm.ui.ribbon.refresh(); });

	$("[id$=txtContractualRequirements]").on("keyup", function (e) {
		if (rmCommon.isNonControlCharacter(e.keyCode)) {
			ResourcingRequirements.isSaveEnabled = true;
		}
		if ($.q.textCounter(this, ResourcingRequirements.contractualRequirementsMaxLength, "#lblRemainingLength")) {
			if ($.trim($(this).val()) != "") {
				rm.validation.clearError($(this));
			}
			else {
				rm.validation.addError("[id$=txtContractualRequirements]", Resources.ContractualRequirementsRequired);
			}
		}
		else {
			rm.validation.addError($(this), "Maximum character limit: " + ResourcingRequirements.contractualRequirementsMaxLength);
		}
		ResourcingRequirements.SaveCancelEnabled();
	});

	$(".JobRoleGrpAppliesTo").on("change", "input:checkbox", function () {
		ResourcingRequirements.isSaveEnabled = true;
		ResourcingRequirements.isCancelEnabled = true;
		ResourcingRequirements.SaveCancelEnabled();
	});

	$('input[name=Experience]').on("click", function () {
		rm.validation.clearError($("#spanTherapeuticArea"));
		rm.validation.clearError($("#spanMonitoringExperience"));
		rm.validation.clearError($("#spanOther"));
		ResourcingRequirements.SaveCancelEnabled();
	});

	$('input[name=JobRole]').on("click", function () {
		rm.validation.clearError($("#spanCRA"));
		rm.validation.clearError($("#spanCPM"));
		ResourcingRequirements.SaveCancelEnabled();
	});

	$('input[name=RequirementType]').on("click", function () {
		rm.validation.clearError($("#spanContractual"));
		rm.validation.clearError($("#spanCoustomerPref"));
		rm.validation.clearError($("#spanBidDefence"));
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionGlobalProjExp").change(function () {
		if ($(this).val() != -1) {
			rm.validation.clearError($(this));
		}
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionTherapeuticArea").change(function () {
		if ($(this).val() != -1) {
			rm.validation.clearError($(this));
		}
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionIndication").change(function () {
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionIndicationYrs").change(function () {
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionTherapeuticYrs").change(function () {
		if ($(this).val() != -1) {
			rm.validation.clearError($(this));
		}
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionIndication").change(function () {
		ResourcingRequirements.isDirty = true;
		if ($(this).val() != -1) {
			rm.validation.clearError($(this));
		}
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionIndicationYrs").change(function () {
		ResourcingRequirements.isDirty = true;
		if ($(this).val() != -1) {
			rm.validation.clearError($(this));
		}
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionInHouseMonitoring").change(function () {
		if ($(this).val() != -1) {
			rm.validation.clearError($(this));
		}
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#optionOnsiteYrs").change(function () {
		if ($(this).val() != -1) {
			rm.validation.clearError($(this));
		}
		ResourcingRequirements.SaveCancelEnabled();
	});

	$("#txtEducation").keyup(function () {
		ResourcingRequirements.SaveCancelEnabled();
	});

	vm.Init();
	ko.applyBindings(vm);

	$("#lblRemainingLength").html(ResourcingRequirements.contractualRequirementsMaxLength - $("[id$=txtContractualRequirements]").val().length);
	if ($("[id$=HdnUserHasEditAccess]").val() == "False") {
		$("#RequirementsMain").attr('disabled', true);
		$("#RequirementsMain input,#RequirementsMain select").attr('disabled', true);
		ResourcingRequirements.renderReadOnlyView = true;
	}

	if ($("[id$=HdnResourcingRequirementsTypeId]").val() == ResourcingRequirementsType_E.Resourcing)
		vm.RequirementsExist("Yes");
	else if ($("[id$=HdnResourcingRequirementsTypeId]").val() == ResourcingRequirementsType_E.NoRequirement)
		vm.RequirementsExist("No");

	ResourcingRequirements.bindDirty();
});
var ViewModel = function () {
	var self = this;
	self.Init = function () {
		if ($(":input[id$=HdnProjectId]").val() != "") {
			self.GetTherapeuticAreas();
			self.GetAppliesToJobRoles();
			self.GetAppliesToResourceTypes();
			ResourcingRequirements.buildGrid();
		}
	}
	self.other = ko.observable();
	self.showJobRole = ko.observable();
	self.RequirementsExist = ko.observable();
	self.JobRole = ko.observable();
	self.RequirementType = ko.observable();
	self.Notes = ko.observable();
	self.Experience = ko.observable();
	self.therapeuticArea = ko.observableArray();
	self.indications = ko.observableArray();
	self.therapeuticArea = ko.observableArray();
	self.selectedTherapeuticArea = ko.observable();
	self.indications = ko.observableArray();
	self.selectedIndication = ko.observable();
	self.inHouseMonitoring = ko.observableArray(ResourcingRequirements.inHouseMonitoringExperience);
	self.selectedInHouseMonitoring = ko.observable();
	self.onSiteMonitoring = ko.observableArray(ResourcingRequirements.onSiteMonitoringExperience);
	self.selectedOnSiteMonitoring = ko.observable();
	self.globalProjectExperience = ko.observableArray(ResourcingRequirements.globalProjectManagementExperience);
	self.therapeuticYrs = ko.observableArray(ResourcingRequirements.experience);
	self.indicationYrs = ko.observableArray(ResourcingRequirements.experience);
	self.selectedTherapeuticYrs = ko.observable();
	self.selectedIndicationYrs = ko.observable();
	self.selectedGlobalProjectExperience = ko.observable();
	self.projectJobRoleId = 0;
	self.criteriaId = 0;
	self.CRARoleText = ko.observable();
	self.CPMRoleText = ko.observable();
	self.AppliesToJobRole = ko.observableArray();
	self.SelectedAppliesToJobRole = ko.observableArray();
	self.CRAAppliesToResTypeGrp = ko.observableArray();
	self.SelectedCRAAppliesToResTypeGrp = ko.observableArray();

	self.GetTherapeuticAreas = function () {
		var vm = this;
		$.ajax({
			type: "Get",
			contentType: "application/json; charset=utf-8",
			dataType: "json",
			url: rm.ajax.utilitySvcUrl + "OneClick/GetTherapeuticAreas",
			data: {},
			success: function (result) {
				ResourcingRequirements.therapeuticAreas = result;
				var arrTherapeuticAreas = $.map(result, function (item) { return { Id: item.Id, Name: item.Name } });
				vm.therapeuticArea(arrTherapeuticAreas);
			},
			error: function (errMsg) { $.rm.ShowHtmlPopup("Web Service Error: GetTherapeuticAreas", errMsg); }
		});
	};

	self.GetAppliesToResourceTypes = function () {
		var vm = this;
		var postData = { jobRoleGroupName: JobRoleGroupName_E.CRA };

		$.rm.Ajax_Utility("GetJobRolesGroupData", postData, function (data) {
			ResourcingRequirements.AppliesTo = data;
			var arrAppliesToResourceTypes = $.map(data, function (item) { return { Id: item.Id, Name: item.Name } });
			vm.CRAAppliesToResTypeGrp(arrAppliesToResourceTypes);
		}, true, true);
	}

	self.GetAppliesToJobRoles = function () {
		var vm = this;
		var postData = { jobRoleGroupName: JobRoleGroupName_E.ProjectLeadership };

		$.rm.Ajax_Utility("GetJobRolesGroupData", postData, function (data) {
			ResourcingRequirements.appliesToJobRoles = data;
			var arrAppliesToJobRoles = $.map(data, function (item) { return { Id: item.Id, Name: item.Name } });
			vm.AppliesToJobRole(arrAppliesToJobRoles);
		}, true, true);
	};

	self.selectedTherapeuticArea.subscribe(function (selectedTA) {
		var localIndications = new Array();
		if ((selectedTA !== -1) && (selectedTA !== typeof (undefined))) {
			$.each(ResourcingRequirements.therapeuticAreas, function (i, area) {
				if (area.Id == selectedTA) {
					$.each(area.Indications, function (j, indication) {
						var option = new ResourcingRequirements.Option(indication.Name, indication.Id);
						localIndications[localIndications.length] = option;
					});
				}
			});
			self.indications(localIndications);
		}
	});

	self.JobRole.subscribe(function (selectedJR) {
		if (selectedJR == JobRoleGroupName_E.CRA) {
			if (!ResourcingRequirements.DoesGridHaveRow(selectedJR)) {
				self.Notes("");
				self.CRARoleText("")
			}
			else
				self.Notes(self.CRARoleText());

			if (self.Experience() == ExperienceCategory_E.GlobalProjectExperience) {
				self.ClearExperienceCategory();
				self.ClearExperienceSubCategory();
			}
		}
		else {
			if (!ResourcingRequirements.DoesGridHaveRow(selectedJR)) {
				self.CPMRoleText("");
				self.Notes("");
			}
			else
				self.Notes(self.CPMRoleText());

			if (self.Experience() == ExperienceCategory_E.MonitoringExperience) {
				self.ClearExperienceCategory();
				self.ClearExperienceSubCategory();
			}
		}
		self.ClearCRAAppliesToResTypeGrp();
		self.ClearAppliesToJobRoles();
	});

	self.RequirementsExist.subscribe(function (value) {
		if (value != 'Yes') {
			self.showJobRole(false);
			self.ClearJobRole();
			self.ClearRequirement();
			self.ClearExperienceCategory();
			self.ClearExperienceSubCategory();
		}
		else {
			self.showJobRole(false);
		}

		ResourcingRequirements.SaveCancelEnabled();
	});

	self.Experience.subscribe(function () {
		self.ClearExperienceSubCategory();
	});

	self.RequirementType.subscribe(function () {
		rm.validation.clearError($("[id$=txtContractualRequirements]"));
		$("#lblRemainingLength").html(ResourcingRequirements.contractualRequirementsMaxLength - $("[id$=txtContractualRequirements]").val().length);
	});

	self.ClearRequirement = function () {
		vm.RequirementType('');
	};

	self.ClearExperienceCategory = function () {
		vm.Experience('');
	};

	self.ClearExperienceSubCategory = function () {
		vm.selectedTherapeuticArea(null);
		vm.selectedTherapeuticYrs(null);
		vm.selectedGlobalProjectExperience(null);
		vm.selectedIndication(null);
		vm.selectedIndicationYrs(null);
		vm.selectedInHouseMonitoring(null);
		vm.selectedOnSiteMonitoring(null);
		vm.other('');
	};

	self.ClearAppliesToJobRoles = function () {
		vm.SelectedAppliesToJobRole([]);
	};

	self.ClearCRAAppliesToResTypeGrp = function () {
		vm.SelectedCRAAppliesToResTypeGrp([]);
	};
	self.ClearJobRole = function () {
		vm.JobRole('');
	};
	self.ClearMisc = function () {
		vm.projectJobRoleId = 0;
		vm.criteriaId = 0;
	};
};

var ResourcingRequirements = {
	isSaveEnabled: false,
	isModifyEnabled: false,
	isDeleteEnabled: false,
	isCancelEnabled: false,
	isCloseEnabled: false,
	renderReadOnlyView: false,
	gridRowData: null,
	contractualRequirementsMaxLength: 8000,
	experience: ["NA", "<1", "1-3", "3-5", "5-10", "10-15", ">15"],
	inHouseMonitoringExperience: [
	 { id: "18", name: "<2" },
	 { id: "19", name: ">=2" },
	 { id: "20", name: ">=5" }
	],
	onSiteMonitoringExperience: [
	 { id: "21", name: "<2" },
	 { id: "22", name: ">=2" },
	 { id: "23", name: ">=5" }
	],
	globalProjectManagementExperience: [
	 { id: "0", name: "NA" },
	 { id: "1", name: "<1" },
	 { id: "2", name: "1-3" },
	 { id: "3", name: "3-5" },
	 { id: "4", name: "5-10" },
	 { id: "5", name: "10-15" },
	 { id: "6", name: ">15" }
	],
	Option: function (name, id) {
		this.Name = name;
		this.Id = id;
	},
	therapeuticAreas: [], // For CPM role send this ,#ResourcingRequirementAppliesTo input[type=checkbox]
	getJsonObjectForDirtyCheck: function () {
		return { items: [{ selector: "#RequirementsMain input:text:not([readonly]),select, input[type=radio],#RequirementsMain textarea:visible", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},
	bindDirty: function () {
		$.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, ResourcingRequirements.getJsonObjectForDirtyCheck());
	},
	CheckPageDirty: function () {
		return $.formStatus.isDirty(ResourcingRequirements.getJsonObjectForDirtyCheck());
	},
	clearDirty: function () {
		$.formStatus.clearDirty(ResourcingRequirements.getJsonObjectForDirtyCheck());
	},
	isEditFormDirty: function () {
		var isDirty = $.formStatus.isDirty(ResourcingRequirements.getJsonObjectForDirtyCheck());
		return isDirty;
	},
	buildGrid: function () {
		var postData =
		{
			projectId: $(":input[id$=HdnProjectId]").val()
		};
		$("#listExperience").jqGrid({
		    url: rm.ajax.projectSvcUrl + "GetResourcingRequirements",
			datatype: 'json',
			mtype: 'POST',
			postData: JSON.stringify(postData),
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(true),
			jsonReader: rm.grid.getJqGridJsonReader(),
			loadonce: false,
			shrinkToFit: false,
			height: '230',
			width: window.screen.width - 245,
			forceFit: true,
			rowNum: 9999,
			multiselect: true,
			colModel: [
			{ name: 'JobRole', index: 'JobRole', label: 'Job Role Type', width: 110, classes: 'ui-ellipsis', sortable: false },
			{ name: 'AppliesTo', index: 'AppliesTo', label: 'Applies To', width: 300, sortable: false },
			{ name: 'ResourceRequirementType', index: 'ResourceRequirementType', label: 'Requirement Type', width: 180, sortable: false, classes: 'ui-ellipsis' },
			{ name: 'ExperienceCategory', index: 'ExperienceCategory', label: 'Experience Category', width: 190, sortable: false },
			{ name: 'Experience', index: 'Experience', label: 'Experience', width: ResourcingRequirements.renderReadOnlyView ? 317 : 291, sortable: false },
			{ name: 'Notes', index: 'Notes', label: 'Notes', hidden: true },
			{ name: 'JobRoleId', index: 'JobRoleId', label: 'JobRoleId', hidden: true },
			{ name: 'ProjectJobRoleId', index: 'ProjectJobRoleId', label: 'ProjectJobRoleId', hidden: true },
			{ name: 'ProjectJobRoleExperienceCriteriaId', index: 'ProjectJobRoleExperienceCriteriaId', label: 'ProjectJobRoleExperienceCriteriaId', hidden: true, key: true },
			{ name: 'RequirementTypeId', index: 'RequirementTypeId', label: 'RequirementTypeId', hidden: true },
			{ name: 'ExperienceCategoryId', index: 'ExperienceCategoryId', label: 'ExperienceCategoryId', hidden: true },
			{ name: 'TherapeuticAreaId', index: 'TherapeuticAreaId', label: 'TherapeuticAreaId', hidden: true },
			{ name: 'NoOfYearsForArea', index: 'NoOfYearsForArea', label: 'NoOfYearsForArea', hidden: true },
			{ name: 'IndicationId', index: 'IndicationId', label: 'IndicationId', hidden: true },
			{ name: 'NoOfYearsForIndication', index: 'NoOfYearsForIndication', label: 'NoOfYearsForIndication', hidden: true },
			{ name: 'InHouseMonitoring', index: 'InHouseMonitoring', label: 'InHouseMonitoring', hidden: true },
			{ name: 'OnSiteMonitoring', index: 'OnSiteMonitoring', label: 'OnSiteMonitoring', hidden: true },
			{ name: 'GlobalProjectExperience', index: 'GlobalProjectExperience', label: 'GlobalProjectExperience', hidden: true },
			{ name: 'AppliesToIds', index: 'AppliesToIds', label: 'AppliesToIds', hidden: true }
			],
			viewsortcols: [true, 'vertical', true],
			sortname: 'ProjectJobRoleExperienceCriteriaId',
			sortorder: 'asc',
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			ondblClickRow: function (id) { },
			onSelectRow: function (id) { ResourcingRequirements.CheckGridRows(); },
			onSelectAll: function (rowIdxArray, sts) { ResourcingRequirements.CheckGridRows(); },
			loadComplete: function () {
				var data = jQuery("#listExperience").jqGrid("getRowData");
				ResourcingRequirements.GetNotes(data);
				if (ResourcingRequirements.renderReadOnlyView) {
					$("#listExperience").jqGrid('hideCol', 'cb');
				}
			}
		});
		ResourcingRequirements.RibbonRefresh();
	},
	CheckGridRows: function () {
		ResourcingRequirements.isModifyEnabled = rm.grid.hasSingleRowSelected("#listExperience");
		ResourcingRequirements.isDeleteEnabled = rm.grid.hasRowsSelected("#listExperience");
		ResourcingRequirements.RibbonRefresh();
	},
	RemoveGridRowSelecedClass: function () {
		rm.grid.uncheckAllGridRows("#listExperience");
		$("#listExperience tr").each(function () {
			$(this).removeClass("ui-state-highlight");
			$(this).attr('aria-selected', false);
			$('.cbox').attr('checked', false);
		});
	},
	AddRequirements: function () {
		vm.showJobRole(true);
		ResourcingRequirements.isCloseEnabled = true;
		ResourcingRequirements.RibbonRefresh();
	},
	AddEnabled: function () {
		return (vm.RequirementsExist() == 'Yes' && !vm.showJobRole() && $("[id$=HdnUserHasEditAccess]").val() != "False");
	},
	ModifyRequirements: function () {
		var selectedRow = $("#listExperience").getGridParam('selarrrow');
		ResourcingRequirements.gridRowData = $("#listExperience").getRowData(selectedRow);
		ResourcingRequirements.EditSelectedRow(ResourcingRequirements.gridRowData);
		ResourcingRequirements.RemoveGridRowSelecedClass();
		ResourcingRequirements.isCloseEnabled = true;
		ResourcingRequirements.bindDirty();
		ResourcingRequirements.RibbonRefresh();
	},
	ModifyEnabled: function () {
		return ResourcingRequirements.isModifyEnabled;
	},
	EditSelectedRow: function (rowData) {
		vm.RequirementsExist("Yes");
		if (rowData.JobRoleId == JobRoleGroupName_E.CRA)
		{ vm.JobRole(rowData.JobRoleId); }
		else
		{ vm.JobRole(JobRoleGroupName_E.ProjectLeadership); }
		vm.showJobRole(true);
		if (rowData.AppliesToIds && rowData.AppliesToIds != "") {
			if (rowData.JobRoleId == JobRoleGroupName_E.CRA) {
				//vm.AppliesTo(rowData.AppliesToIds.split(',')); //--TODO: Delete this line
				vm.SelectedCRAAppliesToResTypeGrp(rowData.AppliesToIds.split(','));
			}
			else {
				vm.SelectedAppliesToJobRole(rowData.AppliesToIds.split(','));
			}
		}

		vm.RequirementType(rowData.RequirementTypeId);
		vm.Experience(rowData.ExperienceCategoryId);
		vm.Notes(rowData.Notes);
		vm.selectedTherapeuticArea(rowData.TherapeuticAreaId);
		vm.selectedTherapeuticYrs(rowData.NoOfYearsForArea);
		vm.selectedIndication(rowData.IndicationId);
		vm.selectedIndicationYrs(rowData.NoOfYearsForIndication);
		vm.selectedGlobalProjectExperience(rowData.GlobalProjectExperience);
		vm.selectedInHouseMonitoring(rowData.InHouseMonitoring);
		vm.selectedOnSiteMonitoring(rowData.OnSiteMonitoring);
		vm.Experience() == ExperienceCategory_E.Other ? vm.other(rowData.Experience) : vm.other('');
		vm.projectJobRoleId = rowData.ProjectJobRoleId;
		vm.criteriaId = rowData.ProjectJobRoleExperienceCriteriaId;
		$("#lblRemainingLength").html(ResourcingRequirements.contractualRequirementsMaxLength - $("[id$=txtContractualRequirements]").val().length);
	},
	GetPostData: function () {
		var projectJobRoleExpCriteria = {
			HasRequirements: vm.RequirementsExist() == 'Yes',
			ProjectJobRoleId: vm.projectJobRoleId,
			ResourceRequirementsResouceTypeGroupLst: (vm.JobRole() != "" && vm.JobRole() == JobRoleGroupName_E.ProjectLeadership) ? vm.SelectedAppliesToJobRole() : vm.SelectedCRAAppliesToResTypeGrp(),
			RequirementTypeId: vm.RequirementType() == "" ? undefined : vm.RequirementType(),
			ExperienceCategoryId: vm.Experience() == "" ? undefined : vm.Experience(),
			TherapeuticAreaId: vm.selectedTherapeuticArea(),
			NoOfYearsForArea: vm.selectedTherapeuticYrs(),
			IndicationId: vm.selectedIndication(),
			NoOfYearsForIndication: vm.selectedIndicationYrs(),
			InHouseMonitoring: vm.selectedInHouseMonitoring(),
			OnSiteMonitoring: vm.selectedOnSiteMonitoring(),
			GlobalProjectExperience: vm.selectedGlobalProjectExperience(),
			Education: vm.other(),
			ProjectId: $(":input[id$=HdnProjectId]").val() == null ? -1 : $(":input[id$=HdnProjectId]").val(),
			JobRoleId: vm.JobRole() == "" ? undefined : vm.JobRole(),
			ContractualRequirements: (vm.RequirementType() == ResourcingRequirementsType_E.Contractual) ? $.trim(vm.Notes()) : "",
			ProjJobRoleExpCriteriaId: vm.criteriaId,
			ProjectJobRoleGroupId: vm.projectJobRoleId
		};
		return projectJobRoleExpCriteria;
	},
	SaveRequirements: function () {
		if (!ResourcingRequirements.AlertUserLossOfData() || (ResourcingRequirements.AlertUserLossOfData() && confirm(Resources.AlertUserLossOfData))) {
			if (ResourcingRequirements.IsFormValid()) {
				var postData = { projectJobRoleExpCriteria: $.parseJSON(ko.toJSON(ResourcingRequirements.GetPostData())) };
				if (!ResourcingRequirements.HasDuplicateRows(postData)) {
					$.ajax({
						type: "POST",
						contentType: "application/json; charset=utf-8",
						dataType: "json",
						url: rm.ajax.projectSvcUrl + "SaveResourcingRequirements",
						data: JSON.stringify(postData),
						success: function (data) {
							if (data.ContainsValidationErrors) {
								$.validationHelper.ShowErrorMessages(data.ValidationErrors);
							}
							else {
								rm.ui.messages.clearAllMessages();
								rm.ui.messages.showSuccess(Resources.DataSavedSuccessfully);
								ResourcingRequirements.buildGrid();
								$('#listExperience').trigger('reloadGrid');
								ResourcingRequirements.ClearForm();
								ResourcingRequirements.bindDirty();
								ResourcingRequirements.isSaveEnabled = false;
								ResourcingRequirements.isCancelEnabled = false;
								ResourcingRequirements.SaveCancelEnabled();
							}
						},
						error: function (errMsg) {
							rm.ui.messages.addError(Resources.ErrorInSaving);
						}
					});
				} else {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.addError(Resources.DuplicateResourcingRequirementsHighlightRow);
				}
			}
		}
	},
	SaveEnabled: function () {
		return this.isEditFormDirty() || ResourcingRequirements.isSaveEnabled;
	},
	DeleteRequirements: function () {
		var selectedrows = $("#listExperience").getGridParam('selarrrow');
		if (selectedrows.length == 0) {
			alert("No requirement selected.");
			return false;
		}
		else {
			if (confirm(Resources.DeleteResourcingRequirementConfirm)) {
				postData = {
					projectJobRoleExpCriteriaIds: selectedrows
				};
				$.ajax({
					type: "POST",
					contentType: "application/json; charset=utf-8",
					dataType: "json",
					url: rm.ajax.projectSvcUrl + "DeleteResourcingRequirements",
					data: JSON.stringify(postData),
					success: function (data) {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showSuccess(Resources.DataDeletedSuccessfully);
						ResourcingRequirements.buildGrid();
						$('#listExperience').trigger('reloadGrid');
						ResourcingRequirements.ClearForm();
					},
					error: function (errMsg) {
						rm.ui.messages.addError(Resources.ErrorInDeleteRecords);
					}
				});
			}
		}
	},
	DeleteEnabled: function () {
		return ResourcingRequirements.isDeleteEnabled
	},
	CancelRequirements: function () {
		var isDirty = ResourcingRequirements.CheckPageDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			if (ResourcingRequirements.gridRowData) {
				ResourcingRequirements.EditSelectedRow(ResourcingRequirements.gridRowData);
			}
			else {
				document.location.reload();
			}
			ResourcingRequirements.isSaveEnabled = false;
			ResourcingRequirements.isCancelEnabled = false;
			ResourcingRequirements.SaveCancelEnabled();
			ResourcingRequirements.bindDirty();
		}
	},
	CancelEnabled: function () {
		return this.isEditFormDirty() || ResourcingRequirements.isCancelEnabled;
	},
	CloseRequirements: function () {
		var isDirty = ResourcingRequirements.CheckPageDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			ResourcingRequirements.ClearForm();
		}
		rm.ui.messages.clearAllMessages();
		ResourcingRequirements.RemoveGridRowSelecedClass();
		ResourcingRequirements.isSaveEnabled = false;
		ResourcingRequirements.isCancelEnabled = false;
		ResourcingRequirements.SaveCancelEnabled();
		ResourcingRequirements.bindDirty();
	},
	CloseEnabled: function () {
		return ResourcingRequirements.isCloseEnabled;
	},
	DoesGridHaveRow: function (roleName) {
		var result = false;
		var recordCount = $('#listExperience').getGridParam("reccount");
		if (recordCount <= 0)
			return false;
		else {
			var mygrid = $("#listExperience");
			if ($.inArray(roleName, mygrid.getCol('JobRoleId')) >= 0)
				return true;
			else
				return false;
		}
	},
	IsFormValid: function () {
		var isFormValid = true;

		if (!vm.RequirementsExist()) {
			rm.validation.addError("#spanYes", Resources.RequirementExistsRequired);
			rm.validation.addError("#spanNo", Resources.RequirementExistsRequired);
			isFormValid = false;
		}
		else {
			rm.validation.clearError($("#spanYes"));
			rm.validation.clearError($("#spanNo"));
		}
		if (vm.showJobRole()) {
			if (!vm.JobRole()) {
				rm.validation.addError("#spanCRA", Resources.JobRoleRequired);
				rm.validation.addError("#spanCPM", Resources.JobRoleRequired);
				isFormValid = false;
			}
			else {
				rm.validation.clearError($("#spanCRA"));
				rm.validation.clearError($("#spanCPM"));
			}
			if (vm.JobRole()) {
				var craAppliesToList = $("#ResourcingRequirementAppliesTo").find("span").not('.styleColorRed');
				var projLeadJobRoleList = $("#ResourcingRequirementAppliesToJobRole").find("span").not('.styleColorRed');

				if (vm.JobRole() == JobRoleGroupName_E.CRA && !vm.SelectedCRAAppliesToResTypeGrp().length) {
					$.each(craAppliesToList, function (i, span) {
						rm.validation.addError(span, Resources.AppliesToRequired);
					});
					isFormValid = false;
				}
				else if (vm.JobRole() == JobRoleGroupName_E.ProjectLeadership && !vm.SelectedAppliesToJobRole().length) {
					$.each(projLeadJobRoleList, function (i, span) {
						rm.validation.addError(span, Resources.ProjectJobRoleRequired);
					});
					isFormValid = false;
				}
				else {
					$.each(craAppliesToList, function (i, span) {
						rm.validation.clearError($(span));
					});
					$.each(projLeadJobRoleList, function (i, span) {
						rm.validation.clearError($(span));
					});
				}
				if (!vm.RequirementType()) {
					rm.validation.addError("#spanContractual", Resources.RequirementRequired);
					rm.validation.addError("#spanCoustomerPref", Resources.RequirementRequired);
					rm.validation.addError("#spanBidDefence", Resources.RequirementRequired);
					isFormValid = false;
				} else {
					rm.validation.clearError($("#spanContractual"));
					rm.validation.clearError($("#spanCoustomerPref"));
					rm.validation.clearError($("#spanBidDefence"));
				}
				if (vm.RequirementType() == ResourcingRequirementsType_E.Contractual && ($.trim(vm.Notes()) == "")) {
					rm.validation.addError("[id$=txtContractualRequirements]", Resources.ContractualRequirementsRequired);
					isFormValid = false;
				}
				else if ($('#lblRemainingLength').html() < 0) {
					rm.validation.addError($(this), "Maximum character limit: " + ResourcingRequirements.contractualRequirementsMaxLength);
					isFormValid = false;
				}
				else {
					rm.validation.clearError($("[id$=txtContractualRequirements]"));
				}
				if (!vm.Experience()) {
					rm.validation.addError("#spanTherapeuticArea", Resources.ExperienceRequired);
					rm.validation.addError("#spanMonitoringExperience", Resources.ExperienceRequired);
					rm.validation.addError("#spanOther", Resources.ExperienceRequired);
					rm.validation.addError("#spanGlobalProjExp", Resources.ExperienceRequired);
					isFormValid = false;
				}
				else {
					rm.validation.clearError($("#spanTherapeuticArea"));
					rm.validation.clearError($("#spanMonitoringExperience"));
					rm.validation.clearError($("#spanOther"));
					rm.validation.clearError($("#spanGlobalProjExp"));
				}
				if (vm.Experience() == ExperienceCategory_E.TherapeuticAreaIndication) {
					if (!vm.selectedTherapeuticArea()) {
						rm.validation.addError("#optionTherapeuticArea", Resources.TherapeuticAreaRequired);
						isFormValid = false;
					} else {
						rm.validation.clearError($("#optionTherapeuticArea"));
					}
					if (!vm.selectedTherapeuticYrs()) {
						rm.validation.addError("#optionTherapeuticYrs", Resources.TherapeuticYrsRequired);
						isFormValid = false;
					}
					else {
						rm.validation.clearError($("#optionTherapeuticYrs"));
					}
					if (vm.selectedIndication() && !vm.selectedIndicationYrs()) {
						rm.validation.addError("#optionIndicationYrs", Resources.IndicationYrsRequired);
						isFormValid = false;
					} else {
						rm.validation.clearError($("#optionIndicationYrs"));
					}
					if (!vm.selectedIndication() && vm.selectedIndicationYrs()) {
						rm.validation.addError("#optionIndication", Resources.IndicationsRequired);
						isFormValid = false;
					} else {
						rm.validation.clearError($("#optionIndication"));
					}
				}
				if (vm.Experience() == ExperienceCategory_E.MonitoringExperience) {
					if (!vm.selectedInHouseMonitoring()) {
						rm.validation.addError("#optionInHouseMonitoring", Resources.InHouseYrsRequired);
						isFormValid = false;
					} else {
						rm.validation.clearError($("#optionInHouseMonitoring"));
					}
					if (!vm.selectedOnSiteMonitoring()) {
						rm.validation.addError("#optionOnsiteYrs", Resources.OnSiteYrsRequried);
						isFormValid = false;
					}
					else { rm.validation.clearError($("#optionOnsiteYrs")); }
				}
				if (vm.Experience() == ExperienceCategory_E.GlobalProjectExperience && vm.JobRole() == JobRoleGroupName_E.ProjectLeadership) {
					if (!vm.selectedGlobalProjectExperience()) {
						rm.validation.addError("#optionGlobalProjExp", Resources.GlobalProjectExperienceRequired);
						isFormValid = false;
					}
					else {
						rm.validation.clearError($("#optionGlobalProjExp"));
					}
				}
				if (vm.Experience() == ExperienceCategory_E.Other) {
					if ($.trim(vm.other()) == "") {
						rm.validation.addError("#txtEducation", Resources.OtherExperienceRequired);
						isFormValid = false;
					}
					else {
						rm.validation.clearError($("#txtEducation"));
					}
				}
			}
		}
		return isFormValid;
	},
	HasDuplicateRows: function (postData) {
		var data = jQuery("#listExperience").jqGrid("getRowData");
		if (data.length > 0) {
			var hasDuplicate = false;
			$.each(data, function (index) {
				if (postData.projectJobRoleExpCriteria.HasRequirements && postData.projectJobRoleExpCriteria.JobRoleId != ""
					&& postData.projectJobRoleExpCriteria.JobRoleId == data[index].JobRoleId
					&& postData.projectJobRoleExpCriteria.RequirementTypeId == data[index].RequirementTypeId
					&& postData.projectJobRoleExpCriteria.ProjJobRoleExpCriteriaId != this.ProjectJobRoleExperienceCriteriaId) {
					if (postData.projectJobRoleExpCriteria.ExperienceCategoryId == ExperienceCategory_E.TherapeuticAreaIndication &&
						postData.projectJobRoleExpCriteria.ExperienceCategoryId == data[index].ExperienceCategoryId &&
						postData.projectJobRoleExpCriteria.TherapeuticAreaId == data[index].TherapeuticAreaId &&
						(postData.projectJobRoleExpCriteria.IndicationId == data[index].IndicationId ||
						(postData.projectJobRoleExpCriteria.IndicationId == undefined && data[index].IndicationId == -1))) {
						hasDuplicate = true;
						if (postData.projectJobRoleExpCriteria.JobRoleId == JobRoleGroupName_E.ProjectLeadership && hasDuplicate) {
							hasDuplicate = ResourcingRequirements.CheckIfDuplicateResourcingRequirementsExists(postData.projectJobRoleExpCriteria.ResourceRequirementsResouceTypeGroupLst, data[index].AppliesToIds.split(','));
						}
						if (hasDuplicate) {
							$("#" + this.ProjectJobRoleExperienceCriteriaId).addClass('ui-state-highlight');
							return;
						}
					} else {
						$("#" + this.ProjectJobRoleExperienceCriteriaId).removeClass('ui-state-highlight');
					}
					if ((postData.projectJobRoleExpCriteria.ExperienceCategoryId == ExperienceCategory_E.MonitoringExperience ||
						postData.projectJobRoleExpCriteria.ExperienceCategoryId == ExperienceCategory_E.Other ||
						postData.projectJobRoleExpCriteria.ExperienceCategoryId == ExperienceCategory_E.GlobalProjectExperience) &&
						postData.projectJobRoleExpCriteria.ExperienceCategoryId == data[index].ExperienceCategoryId) {
						hasDuplicate = true;
						if (postData.projectJobRoleExpCriteria.JobRoleId == JobRoleGroupName_E.ProjectLeadership && hasDuplicate) {
							hasDuplicate = ResourcingRequirements.CheckIfDuplicateResourcingRequirementsExists(postData.projectJobRoleExpCriteria.ResourceRequirementsResouceTypeGroupLst, data[index].AppliesToIds.split(','));
						}
						if (hasDuplicate) {
							$("#" + this.ProjectJobRoleExperienceCriteriaId).addClass('ui-state-highlight');
							return;
						}
					} else {
						$("#" + this.ProjectJobRoleExperienceCriteriaId).removeClass('ui-state-highlight');
					}
				} else {
					$("#" + this.ProjectJobRoleExperienceCriteriaId).removeClass('ui-state-highlight');
				}
			});
		}
		return hasDuplicate;
	},

	CheckIfDuplicateResourcingRequirementsExists: function (resReqResouceTypeGroupLst, appliesToJobRoles) {
		var returnVal = false;
		$.each(resReqResouceTypeGroupLst, function (index) {
			if (!returnVal) {
				returnVal = $.inArray(resReqResouceTypeGroupLst[index], appliesToJobRoles) > -1
			}
		});
		return returnVal;
	},

	ClearForm: function () {
		vm.showJobRole(false);
		vm.ClearJobRole();
		vm.ClearAppliesToJobRoles();
		vm.ClearCRAAppliesToResTypeGrp();
		vm.ClearRequirement();
		vm.ClearExperienceCategory();
		vm.ClearExperienceSubCategory();
		vm.ClearMisc();
		ResourcingRequirements.gridRowData = null;
		ResourcingRequirements.CheckGridRows();
		ResourcingRequirements.isCloseEnabled = false;
		ResourcingRequirements.bindDirty();
		ResourcingRequirements.RibbonRefresh();
	},
	SaveCancelEnabled: function () {
		ResourcingRequirements.RibbonRefresh();
	},
	RibbonRefresh: function () { rm.ui.ribbon.refresh(); },
	GetNotes: function (data) {
		var isCRARoleTextSet = "false";
		var isCPMRoleTextSet = "false";
		if (data.length > 0) {
			$.each(data, function (index) {
				if (isCRARoleTextSet == "true" && isCPMRoleTextSet == "true") {
					return false;
				}
				if (data[index].JobRole == "CRA" && isCRARoleTextSet != "true") {
					vm.CRARoleText(data[index].Notes);
					isCRARoleTextSet = "true";
				} else if (data[index].JobRole == "Project Leadership" && isCPMRoleTextSet != "true") {
					vm.CPMRoleText(data[index].Notes);
					isCPMRoleTextSet = "true";
				}
			});
		}
		if (isCRARoleTextSet == "false") vm.CRARoleText('');
		if (isCPMRoleTextSet == "false") vm.CPMRoleText('');
	},
	AlertUserLossOfData: function () {
		if (vm.RequirementsExist() == 'No' && $('#listExperience').getGridParam("reccount") != 0)
			return true;
		else
			return false;
	}
};
var vm = new ViewModel();
