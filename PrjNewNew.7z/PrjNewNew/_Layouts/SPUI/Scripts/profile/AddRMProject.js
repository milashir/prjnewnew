﻿/// <reference path="../common/rmhelper.js" />
addRmProjNs = {
	awardedProjects: [],
	dialogSelector: "#divDialog",
	projectCodeSelector: "#Q_ProjectList_DialogTextBox",
	organizationSelector: "#ddlOrganization",
	getOrganizationSuffix: function () { return $(addRmProjNs.organizationSelector).val(); },
	getProtocolType: function () { return $("[name=protocolType]:checked").val(); },
	getDteType: function () { return $("[name=ProjectDteType]:checked").val(); },
	getIsClinicalRedesignProject: function () { return $("[name=clinicalRedesignProject]:checked").val() === "1"; },
	isManualProtocol: function () { return addRmProjNs.getProtocolType() === "manualProtocol"; },
	isProjectAlreadyPresentInRm: function (projectCodeProtocol) {
		var projectCodeExistInRm = false;
		$.each(addRmProjNs.awardedProjects, function (index, item) {
			if ($.trim(projectCodeProtocol).toUpperCase() == item.value.toUpperCase()) {
				projectCodeExistInRm = true;
				return false;
			}
		});
		return projectCodeExistInRm;
	},
	handleProjectSelection: function () {
		var projectCodeProtocol = $(addRmProjNs.projectCodeSelector).val();
		if (!IsProjectCodeFormatValid(projectCodeProtocol)) { $(addRmProjNs.projectCodeSelector).focus(); }
		else {
			var indexOfHyphen = projectCodeProtocol.indexOf("-");
			var projectCode = (indexOfHyphen > 0) ? $.trim(projectCodeProtocol.substring(0, indexOfHyphen)) : projectCodeProtocol;

			addRmProjNs.getCrmProjectsByProjectCode(projectCode, addRmProjNs.isProjectAlreadyPresentInRm(projectCodeProtocol));
			$(addRmProjNs.dialogSelector).dialog("close");
		}
	},
	showAddProjectDialog: function () {
		var isDirty = false;
		if (window.location.pathname.indexOf("ProjectBackground.aspx") >= 0) {
			isDirty = rmProjNs.isProjectFormDirty();
		}
		else if (window.location.pathname.indexOf("ProjectConfiguration.aspx") >= 0) {
			isDirty = milestoneNs.checkPageDirty() || dteSchemaNs.isPageDirty();
		}
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			var h = "";
			h += "<div id='SelectProjectDialog' class='ssvRequestPaddingTable'><form id='frmDialog' onsubmit='return false;'>";
			h += "<table  style='width: 100 %'>";
			h += "<tr>";
			h += "<td colspan='2'>";
			h += "Typeahead will list existing matching Project Code - Protocol Number combinations in RM.Do not select an existing project from the list.Enter a unique Project Code - Protocol Number to create a new project in RM";
			h += "</td></tr>";
			h += " <tr>";
			h += "<td>Project&nbsp;Code</td>";
			h += "<td><input type='text' name='Q_ProjectList_DialogTextBox' id='Q_ProjectList_DialogTextBox'/></td>";
			h += "</tr>";
			h += "</table></form></div>";
			var okButton = { text: "OK", click: addRmProjNs.handleProjectSelection };
			rm.ui.dialog.showModalWithButtonsAndCloseHandler(addRmProjNs.dialogSelector, "Add Local RM Awarded Project",h, false, 600, "auto", [okButton, rm.ui.dialog.standardButtons.cancel], null, function () {
				addRmProjNs.setupProjectAutoComplete($(addRmProjNs.projectCodeSelector));
				$(addRmProjNs.projectCodeSelector).focus();
			});
		}
	},
	setupProjectAutoComplete: function (TextboxObj) {
		rm.ajax.projectSvcAsyncPost("GetAwardedProjectList", { filterBasedonRMUser: false }, function (serviceResponse) {
			//bind the autocomplete plugin to the search box
			addRmProjNs.awardedProjects = serviceResponse;
			TextboxObj.autocomplete({
				source: serviceResponse,
				matchContains: false
			}).keypress(function (e) {
				if (e.keyCode === 13) { addRmProjNs.handleProjectSelection(); }
			});

			//handle auto complete list select event
			TextboxObj.bind("autocompleteselect", function (event, ui) {
				addRmProjNs.getCrmProjectsByProjectCode(ui.item.value.substring(0, ui.item.value.indexOf(" - ")), true);
			});
		});
	},
	isProjectCodePatternValid: function (projectCode) { return projectCode.length == 8 && /^[A-Za-z0-9 ]{3,20}$/.test(); },
	showCreateProjectDialog: function (pageHtml, okButton) {
		var buttonList = okButton == null ? [rm.ui.dialog.standardButtons.cancel] : [okButton, rm.ui.dialog.standardButtons.cancel];
		rm.ui.dialog.showModalWithButtonsAndCloseHandler(addRmProjNs.dialogSelector, "Create a Project", pageHtml, false, 650, 350, buttonList, null, function () {
			// Show organization dropdown only for admin user
			if (LoggedInUser.IsAdmin || LoggedInUser.IsResourcingCenterAdmin || LoggedInUser.IsDemandPlanner || LoggedInUser.IsSupport) {
				$("#orgSuffix").show();
				rm.ajax.requestSvcSyncGet("GetOrganizationalUnitSuffixList", {}, function (data) {
					rm.dropdown.fill("#ddlOrganization", data, "suffix", "Name", LoggedInUser.OrganizationSuffix, true, false);
					$("#ddlOrganization").bind("change", function () { $("#lblOrganization").text($(this).val() === "-1" ? "[Org]" : $(this).val()); });
				});
			}
			else { $("#orgSuffix").hide(); }
		});
	},
	userHasAccess: function () { return (LoggedInUser.IsAdmin || LoggedInUser.IsResourcingCenterAdmin || LoggedInUser.IsDemandPlanner || LoggedInUser.IsSupport); },
	isProjectOrganziationValid: function () {
		var isValid = true;

		var ddlOrganizationSuffix = $("#ddlOrganization");
		var organizationSuffix = ddlOrganizationSuffix.val();
		var validationMessage = "";
		if (organizationSuffix === "-1") {
			if (addRmProjNs.userHasAccess()) {
				rm.validation.addError(ddlOrganizationSuffix, Resources.OrganizationRequired)
				isValid = false;
			}
			else {
				rm.ui.messages.addError(Resources.UnAuthorizedAccess);
				isValid = false;
			}
		}
		else { rm.validation.clearError(ddlOrganizationSuffix); }
		return isValid;
	},
	isProtocolSelectionValid: function () {
		var isValid = true;
		if (addRmProjNs.getProtocolType() !== undefined) {
			rm.validation.clearError($("[name=protocolType]").parent());
			if (addRmProjNs.isManualProtocol() && $.trim($("#txtUserProtocolNumber").val()) == "") {
				rm.validation.addError("#txtUserProtocolNumber", Resources.ProtocolRequired)
				isValid = false;
			}
			else { rm.validation.clearError($("#txtUserProtocolNumber")); }
		}
		else {
			rm.validation.addError($("[name=protocolType]").parent(), Resources.ProtocolTypeRequired)
			isValid = false;
		}
		return isValid;
	},
	isProjectDteSelectionValid: function () {
		var isValid = true;
		if (addRmProjNs.getDteType() === undefined) {
			rm.validation.addError($("[name=ProjectDteType]:first").parent(), "Select Project RBM type.");
			isValid = false;
		}
		else {
			rm.validation.clearError($("[name=ProjectDteType]:first").parent());
		}
		return isValid;
	},
	isDuplicateCheckPassedAndUserConfirmationReceived: function (projectCode, autoGeneratedProtocol) {
		var isValid = true;
		if (!addRmProjNs.isDuplicateProjectProtocolCombination(projectCode + " - " + autoGeneratedProtocol)) {
			isValid = confirm("Are you sure you want to add the following project : " + projectCode + " - " + autoGeneratedProtocol);
		}
		return isValid;
	},
	isManualEntryFormValid: function (projectCode) {
		var isValid = addRmProjNs.isProjectOrganziationValid();
		isValid = addRmProjNs.isProtocolSelectionValid() && isValid;
		isValid = addRmProjNs.isProjectDteSelectionValid() && isValid;

		return isValid;
	},
	isClickToSelectFormValid: function () {
		var isValid = addRmProjNs.isProjectOrganziationValid();
		isValid = addRmProjNs.isProjectDteSelectionValid() && isValid;

		return isValid;
	},
	createProjectDialogOkClick: function () {
		if (addRmProjNs.isManualEntryFormValid()) {
			var projectCode = $("#spnProjectCode").html();
			var protocolNumber = "Not Available";//Since project code itself was not found in CRM, protocol is always set to NA
			var autoGeneratedProtocol = "";
			if (addRmProjNs.isManualProtocol()) {
				autoGeneratedProtocol = $("#txtUserProtocolNumber").val() + "_" + addRmProjNs.getOrganizationSuffix();
			}
			else {
				rm.ajax.projectSvcSyncPost("CreateCustomProtocolNumber", { organizationPrefix: $("#ddlOrganization").val() }, function (serviceResponse) {
					autoGeneratedProtocol = serviceResponse;//auto-generated protocol already has suffix concatenated with it.
				});
			}
			addRmProjNs.createProject(projectCode, protocolNumber, autoGeneratedProtocol, false);
		}
	},
	createProject: function (projectCode, protocolNumber, autoGeneratedProtocol, queryCrm) {
		if (addRmProjNs.isDuplicateCheckPassedAndUserConfirmationReceived(projectCode, autoGeneratedProtocol)) {
			$(document).ajaxStart(function () { rm.ui.block("Creating RM Project"); });

			var postData = {
				projectCode: projectCode,
				protocolNumber: protocolNumber,
				organizationPrefix: addRmProjNs.getOrganizationSuffix(),
				queryCRM: queryCrm,
				autogeneratedProtocolNumber: autoGeneratedProtocol,
				isClinicalRedesignProject: addRmProjNs.getIsClinicalRedesignProject(),
				DTEStudyType: addRmProjNs.getDteType()
			};

			rm.ajax.projectSvcAsyncPost("GetRMProjectDetails", postData, function (response) {
				if (response.ContainsValidationErrors) {
					$.validationHelper.ShowErrorMessages(response.ValidationErrors);
				}
				else {
					setTimeout(function () {
						rm.ui.messages.showSuccess("The project has been added.");
						window.onbeforeunload = null
						document.location = "/_Layouts/SPUI/profile/ProjectBackground.aspx?projectCreated=1";
					}, 50);
				}
			});
		}
	},
	bindEventsToControls: function () {
		$("[addProjLink=1]").click(function () {
			if (addRmProjNs.isClickToSelectFormValid()) {
				var linkObj = $(this);
				var projectCode = linkObj.html();
				var protocolNumber = linkObj.closest("td").parent().find("td[tdProtocol=1]").html();
				protocolNumber = $.trim(protocolNumber) === "" ? "Not Available" : protocolNumber;
				var autoGeneratedProtocol = protocolNumber + "_" + addRmProjNs.getOrganizationSuffix();
				addRmProjNs.createProject(projectCode, protocolNumber, autoGeneratedProtocol, true);
			}
		});

		$("#txtUserProtocolNumber").bind('keyup keydown paste cut drop', function () { rm.validation.clearError($("#txtUserProtocolNumber")); });

		$("#ddlOrganization").bind('change', function () { rm.validation.clearError($("#ddlOrganization")); });

		$("[name=ProjectDteType]").change(function () { rm.validation.clearError($("[name=ProjectDteType]:first").parent()); });

		$("[name=protocolType]").change(function () {
			if (addRmProjNs.isManualProtocol()) { $("#userProtocol").show(); }
			else { $("#userProtocol").hide(); }
			$("#txtUserProtocolNumber").val("");
			rm.validation.clearError($("#txtUserProtocolNumber"));
			rm.validation.clearError($("[name=protocolType]").parent());
		});
	},
	getCreateProjectHeaderHtml: function () {
		return "<div id='AddProjectDialog' class='ssvRequestPaddingTable'><form id='frmAddDialog' onsubmit='return false;'>";
	},
	getCreateProjectFooterHtml: function () { return "</form></div>"; },
	getCreateProjectOrgUnitDropDownHtml: function () {
		return "<div id='orgSuffix'><label><strong>Project Organizational Unit:<span class='styleColorRed'>*</span></strong> <select id='ddlOrganization' class=\"fieldsetLabelWIdthVeryBig\"></select></label></div>";
	},
	getCreateProjectNotInCrmHtml: function (projectCode) {
		return "<div style='padding-top:10px;'><h3>Project code <span id='spnProjectCode'>" + projectCode + "</span> is not available in CRM. </h3></div>";
	},
	getCreateProjectCrdDteHtml: function () {
		var html = "<table style='padding-top:10px;'><tr><td><strong>Is Clinical Redesign</strong></td>";
		html += "<td><input type='radio' name='clinicalRedesignProject' id='radioClinicalYes' value='1' checked='checked'>Yes";
		html += "<input type='radio' name='clinicalRedesignProject' id='radioClinicalNo' value='0'>No</td></tr>";
		html += "<tr><td><strong>Is this a RBM study?</strong></td>";
		html += "<td><input type='radio' name='ProjectDteType' id='radioDTEStudyTypeYes' value='" + ProjectDteType_E.Dte + "' >Yes";
		html += "<input type='radio' name='ProjectDteType' id='radioDTEStudyTypeNo' value='" + ProjectDteType_E.NonDte + "'>No</td></tr></table>";
		return html;
	},
	getCreateProjectProtocolSelectionHtml: function () {
		var html = "Protocol Number</br><div style='padding-top:10px;'><input type='radio' name='protocolType' id='rmGeneratedProtocol' value='rdoUser'>Use RM-generated Protocol Number</input><br/>";
		html += "<input type='radio' name='protocolType' id='radioUserGenerated' value='manualProtocol'>Manually enter a Protocol Number</input><div id='userProtocol' style='display:none;padding-left:5px;padding-top:5px;'><strong>Protocol Number<span class='styleColorRed'>*</span>: </strong><input type='text' id='txtUserProtocolNumber' maxlength='499' size='50' /> _<span id='lblOrganization'>[Org]</span></div></div>";
		return html;
	},
	getCreateProjectProjectListHtml: function (projectList) {
		var html = "<div class='fieldsetLabel'>Please select the project that you wish to add.</div>";
		html += "<table class= \"tblMatch table-RMProject\"><thead><tr><th>Project Code</th><th>Protocol Number</th></tr></thead><tbody>";
		$.each(projectList, function (index, project) {
			html += "<tr><td><a href='#' addProjLink='1'>" + project.OpportunityNumber + "</a></td><td tdProtocol='1'>" + project.ProtocolNumber + "</td><tr>";
		});
		html += "</tbody></table></form>";
		return html;
	},
	getCreateProjectProjectsInRmHtml: function (projectCode) {
		var projectCodeLength = projectCode.length;
		projectCode = projectCode.toUpperCase();
		var html = "";
		$.each(addRmProjNs.awardedProjects, function (index, projectProtocol) {
			if ($.trim(projectProtocol.value).substring(0, projectCodeLength).toUpperCase() == projectCode) {
				html += "<tr><td>" + projectProtocol.value + "</td></tr>";
			}
		});
		if (html !== "") {
			html = "<table class= \"tblMatch table-RMProject\" style='margin: 10px 0px!important;'><thead><tr><th>Projects existing in RM</th></tr></thead><tbody>" + html + "</tbody></table></br>";
		}
		return html;
	},
	getCreateProjectFullCrmProjectsExists: function (serviceResponse, projectCode) {
		var html = addRmProjNs.getCreateProjectHeaderHtml();
		html += addRmProjNs.getCreateProjectOrgUnitDropDownHtml();
		html += addRmProjNs.getCreateProjectCrdDteHtml();
		html += addRmProjNs.getCreateProjectProjectListHtml(serviceResponse);
		html += addRmProjNs.getCreateProjectFooterHtml();
		return html;
	},
	getCreateProjectFullNoCrmProjectsExists: function (serviceResponse, projectCode) {
		var html = addRmProjNs.getCreateProjectHeaderHtml();
		html += addRmProjNs.getCreateProjectOrgUnitDropDownHtml();
		html += addRmProjNs.getCreateProjectNotInCrmHtml(projectCode);
		html += addRmProjNs.getCreateProjectProjectsInRmHtml(projectCode);
		html += addRmProjNs.getCreateProjectProtocolSelectionHtml();
		html += addRmProjNs.getCreateProjectCrdDteHtml();
		html += addRmProjNs.getCreateProjectFooterHtml();
		return html;
	},
	getCrmProjectsByProjectCode: function (projectCode, projectExistInRm) {
		if (!addRmProjNs.isProjectCodePatternValid(projectCode)) { alert(Resources.RMProjectCodeValidation); }
		else if (projectExistInRm) { alert(Resources.ProjectAlreadyExistInRM); }
		else {
			$(document).ajaxStart(function () { rm.ui.block("Searching for CRM Projects"); });
			rm.ajax.projectSvcAsyncPost("GetCRMProjects", { ProjectCode: projectCode }, function (serviceResponse) {
				var okButton = null;
				var html = "";
				if (serviceResponse.IsSuccessful) {
					if (serviceResponse.AdditionalData.length > 0) {
						html = addRmProjNs.getCreateProjectFullCrmProjectsExists(serviceResponse.AdditionalData, projectCode);
					}
					else {
						okButton = { text: "Save", click: addRmProjNs.createProjectDialogOkClick };
						html = addRmProjNs.getCreateProjectFullNoCrmProjectsExists(serviceResponse.AdditionalData, projectCode);
					}
					addRmProjNs.showCreateProjectDialog(html, okButton);
					addRmProjNs.bindEventsToControls();
				}
				else {
					rm.ui.dialog.showServiceErrorModal("Web Service Error: GetCRMProjects", serviceResponse.Message);
				}
			});
		}
	},
	isDuplicateProjectProtocolCombination: function (projectProtocol) {
		var duplicatProjectExists = false;
		$.each(addRmProjNs.awardedProjects, function (index, projectCodeProtocol) {
			if (projectCodeProtocol.value.toUpperCase() == projectProtocol.toUpperCase()) {
				duplicatProjectExists = true;
				rm.ui.messages.addError(Resources.ProjectProtocolAlreadyExist);
				return false;
			}
		});
		return duplicatProjectExists;
	}
};

$(document).ready(function () {
	var hasAccessToAddRmProject = LoggedInUser.IsAdmin || LoggedInUser.IsSupport || LoggedInUser.IsDemandPlanner || LoggedInUser.IsResourcingCenterAdmin;
	if (rm.queryString.getValue("addRmProject") == "1" && hasAccessToAddRmProject) {
		addRmProjNs.showAddProjectDialog();
	}
});