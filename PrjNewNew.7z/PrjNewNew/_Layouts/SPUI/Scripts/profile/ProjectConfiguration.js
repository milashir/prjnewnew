﻿/// <reference path="../common/rmhelper.js" />
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });
	tabs = $('#tabs').tabs({
		activate: function (event, ui) {
			if (ui.newPanel.selector == "#tabs-1") {
				milestoneNs._selectedTab = 0;
			}
			else if (ui.newPanel.selector == "#tabs-2") {
				milestoneNs._selectedTab = 1;
			}
			else if (ui.newPanel.selector == "#tabs-4") {
				if (dteSchemaNs._isVisitSchemaUndefined == true) {
					rm.ui.messages.addError(Resources.VisitSchemaUndefinedError.replace('{0}', projConfig.globalValues.projectCode));
				}
			}
			else {
				milestoneNs._selectedTab = 2;
			}
		}
	});
	$("#custommilestonedate").qDatepicker().qDatepicker("disable");;

	$("#ddlRegionList").change(function (event) {
		countryMilestoneNs.GetCountry();
	});
	$("#ddlCountryList").change(function (event) {
		rm.validation.clearError($("#ddlCountryList"));
	});

	projConfig.setGlobalVariables();
	dteSchemaNs.init();

	projConfig.getProjectMilestoneById(projConfig.getProjectId(), true);
	//Get the custom milestone
	if (projConfig.getProjectId() != 0) {
		projConfig.buildCustomMilestoneGrid(projConfig.getProjectId());
		countryMilestoneNs.LoadCountryMilestoneData();
	}
	else { bindDirty(); }

	SetReadonlyContents();
	if (projConfig.getProjectId() != 0) {
		milestoneNs._isAddEditButtonEnabled = true;
	}
	rm.ui.ribbon.delayedRefresh();

});

var projConfig = {
	hdnIsDteSchemaAlreadyConfiguredSelector: "[id$=hdnIsDteSchemaAlreadyConfigured]",
	hdnAreMilesontesValidForPseudoSchamaCreationSelector: "[id$=hdnAreMilesontesValidForPseudoSchamaCreation]",
	hdnHasUserDefinedSchemaSelector: "[id$=hdnHasUserDefinedSchema]",
	dteSchemaContainerSelector: "#dteSchemaContainer",
	lblNumberOfSitesSelector: "#lblNumberOfSites",
	lblFsiCovWeeksSelector: "[id$=lblFsiCovWeeks]",
	lblFsiSelector: "#lblFsi",
	lblLsiSelector: "#lblLsi",
	lblLsoSelector: "#lblLso",
	lblCovSelector: "#lblCov",
	lblSivFsiWeeksSelector: "#lblSivFsiWeeks",
	lblJapanSivPerSiteSelector: "#lblJapanSivPerSite",
	lblJapanCovPerSiteSelector: "#lblJapanCovPerSite",
	siteMonitoringTierRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.tierRow",
	siteMonitoringTotalRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.tierTotalRow",
	siteMonitoringBudgetRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.budgetRow",
	siteMonitoringBufferRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.bufferRow",
	siteMonitoringBufferVisitsRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.bufferVisitsRow",
	siteMonitoringActualBufferRowTemplateSelector: "#tblDteSiteMonRowTemplate tr.actualBufferRow",
	pharmacyTierRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.tierRow",
	pharmacyTotalRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.tierTotalRow",
	pharmacyBudgetRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.budgetRow",
	pharmacyBufferRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.bufferRow",
	pharmacyBufferVisitsRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.bufferVisitsRow",
	pharmacyActualBufferRowTemplateSelector: "#tblDtePharmacyMonRowTemplate tr.actualBufferRow",
	siteMonitoringTableSelector: "#dteSiteMonitoringSchema",
	siteMonitoringBufferTableSelector: "#dteSiteMonitoringBufferTable",
	pharmacyTableSelector: "#dtePharmacyMonitoringSchema",
	pharmacyBufferTableSelector: "#dtePharmacyMonitoringBufferTable",
	isPharmacyEnabledSelector: "#cbIsPharmacyEnabled",
	txtRvOsRatioSelector: "#txtRvOsRatio",
	txtReasonForSchemaChangeSelector: "#txtReasonForSchemaChange",
	divRvAsOsEquivalentSelector: "#divRvasOsEquivalent",
	divRevisedOsTargetSelector: "#divRevisedOsTarget",
	targetSitePercentageSelector: "[name=TargetSitePercentage]",
	cbTierEnabledSelector: "[name=cbTierEnabled]",
	rbFsiLsiDefaultTierSelector: "[name=rbFsiLsiDefaultTier]",
	rbLsiLsoDefaultTierSelector: "[name=rbLsiLsoDefaultTier]",
	rbLsoCovDefaultTierSelector: "[name=rbLsoCovDefaultTier]",
	tierNameSelector: "[placeholderKey=TierName]",
	tierCycleSelector: "[name=TierCycle]",
	onSiteVisitRatioSelector: "[name=OnSiteVisitRatio]",
	remoteVisitRatioSelector: "[name=RemoteVisitRatio]",
	contactFrequencyWeeksSelector: "[placeholderKey=ContactFrequencyWeeks]",
	fsiLsiSiteCountSelector: "[placeholderKey=FsiLsiSiteCount]",
	fsiLsiSitePctSelector: "[placeholderKey=FsiLsiSitePct]",
	lsiLsoSiteCountSelector: "[placeholderKey=LsiLsoSiteCount]",
	lsiLsoSitePctSelector: "[placeholderKey=LsiLsoSitePct]",
	lsoCovSiteCountSelector: "[placeholderKey=LsoCovSiteCount]",
	lsoCovSitePctSelector: "[placeholderKey=LsoCovSitePct]",
	rbPharmacyDefaultTierSelector: "[name=rbPharmacyDefaultTier]",
	PharmacySiteCountSelector: "[placeholderKey=PharmacySiteCount]",
	PharmacySitePctSelector: "[placeholderKey=PharmacySitePct]",
	clearForDisabledTiersSelector: "[clearForDisabledTiers=1]",
	sivCovVisitCountSelector: "[placeholderkey=SivCovVisitCount]",
	onsiteVisitCountSelector: "[placeholderkey=OnsiteImvVisitCount]",
	remoteVisitCountSelector: "[placeholderkey=RemoteVisitCount]",
	totalVisitCountSelector: "[placeholderkey=TotalVisitCount]",
	pastActualOsVisitCountSelector: "[placeholderKey=PastActualOsVisitCount]",
	plannedActualOsVisitCountSelector: "[placeholderKey=PlannedActualOsVisitCount]",
	totalActualOsVisitCountSelector: "[placeholderKey=TotalActualOsVisitCount]",
	pastActualRvVisitCountSelector: "[placeholderKey=PastActualRvVisitCount]",
	plannedActualRvVisitCountSelector: "[placeholderKey=PlannedActualRvVisitCount]",
	totalActualRvVisitCountSelector: "[placeholderKey=TotalActualRvVisitCount]",
	getTotalPharmacyTargetSitePctSelector: function () { return projConfig.pharmacyTableSelector + " [placeholderKey=TotalPharmacyTargetSitePct]"; },
	totalPharmacyProjectedNumberOfSitesSelector: "[placeholderKey=TotalPharmacyProjectedNumberOfSites]",
	getTotalOnsiteTargetSitePctSelector: function () { return projConfig.siteMonitoringTableSelector + " [placeholderKey=TotalOnsiteTargetSitePct]"; },
	totalOnsiteProjectedNumberOfSitesSelector: "[placeholderKey=TotalOnsiteProjectedNumberOfSites]",
	ppmProjectedInitiatedSiteSelector: "[id$=lblPpmProjectedInitiatedSite]",
	projectedNumberOfSitesSelector: "[placeholderKey=ProjectedNumberOfSites]",
	onsiteVisitFrequencySelector: "[placeholderKey=OnsiteVisitFrequency]",
	removeVisitFrequencySelector: "[placeholderKey=RemoveVisitFrequency]",
	hdnAllowTierWithNoVisitsSelector: "[id$=hdnAllowTierWithNoVisits]",
	tierCycleWarningDialogSelector: "#tierCycleWarningDialog",
	zeroOnsiteVisitsWarningDialogSelector: "#zeroOnsiteVisitsWarningDialog",
	getSiteMonitoringBudgetedSivCovVisitCountSelector: function () { return projConfig.siteMonitoringTableSelector + " [placeholderkey=siteMonitoringBudgetedSivCovVisitCount]"; },
	getSiteMonitoringBudgetedOnsiteImvVisitCountSelector: function () { return projConfig.siteMonitoringTableSelector + " [placeholderkey=siteMonitoringBudgetedOnsiteImvVisitCount]"; },
	getSiteMonitoringBudgetedRemoteVisitCountSelector: function () { return projConfig.siteMonitoringTableSelector + " [placeholderkey=siteMonitoringBudgetedRemoteVisitCount]"; },
	getSiteMonitoringBufferSelector: function () { return projConfig.siteMonitoringBufferTableSelector + " [placeholderkey=SiteMonitoringBuffer]"; },
	getSiteMonitoringTargetNumberOfBufferVisitsSelector: function () { return projConfig.siteMonitoringBufferTableSelector + " [placeholderkey=SiteMonitoringTargetNumberOfBufferVisits]"; },
	getSiteMonitoringActualBufferSelector: function () { return projConfig.siteMonitoringBufferTableSelector + " [placeholderkey=SiteMonitoringActualBuffer]"; },
	getTotalOnsiteOnsiteVisitCountSelector: function () { return projConfig.siteMonitoringTableSelector + " [placeholderkey=TotalOnsiteOnsiteImvVisitCount]"; },
	getGrandTotalPharmacyVisitCountSelector: function () { return projConfig.pharmacyTableSelector + " [placeholderkey=GrandTotalPharmacyVisitCount]"; },
	getPharmacyBudgetedSivCovVisitCountSelector: function () { return projConfig.pharmacyTableSelector + " [placeholderKey=pharmacyBudgetedSivCovVisitCountSelect]"; },
	getPharmacyBudgetedOnsiteImvVisitCountSelector: function () { return projConfig.pharmacyTableSelector + " [placeholderKey=pharmacyBudgetedOnsiteImvVisitCountSelect]"; },
	getPharmacyBufferSelector: function () { return projConfig.pharmacyBufferTableSelector + " [placeholderKey=PharmacyBuffer]"; },
	getPharmacyTargetNumberOfBufferVisitsSelector: function () { return projConfig.pharmacyBufferTableSelector + " [placeholderKey=PharmacyTargetNumberOfBufferVisits]"; },
	getPharmacyActualBufferSelector: function () { return projConfig.pharmacyBufferTableSelector + " [placeholderKey=PharmacyActualBuffer]"; },
	getSiteMonitoringTierRowCollectionSelector: function () { return projConfig.siteMonitoringTableSelector + " tr.tierRow"; },
	getPharmacyTierRowCollectionSelector: function () { return projConfig.pharmacyTableSelector + " tr.tierRow"; },
	isTierWithZeroVisitsAllowed: function () { return $(projConfig.hdnAllowTierWithNoVisitsSelector).val() == "1"; },
	globalValues: {
		organizationId: null,
		projectId: null,
		userOrganizationalUnitName: null,
		userOrganizationalUnitId: null,
		isDteProject: false,
		projectCode: null,
		userSharePointRole: null
	},
	getProjectId: function () { return projConfig.globalValues.projectId; },
	customMilestoneGridSelector: "#customMsList",
	countryGridSelector: "#countryMsList",
	projectGridSelector: "#projectMsList",
	isSaveButtonEnabled: function (isDteProject) { return milestoneNs.checkPageDirty() || milestoneNs._isSaveButtonEnabled; },
	isDeleteButtonEnabled: function () { return rm.grid.hasRowsSelected(projConfig.customMilestoneGridSelector); },
	isAddEditeButtonEnabled: function () { return milestoneNs._isAddEditButtonEnabled },
	isCancelButtonEnabled: function () { return milestoneNs.checkPageDirty() || milestoneNs._isCancelButtonEnabled; },
	isMilestoneExist: function (milestoneName) {
		var milestoneExists = false;

		//Check project milestone
		$("#projectMilestone td.milestoneDescription").each(function (index, descriptionTd) {
			if ($.trim($(descriptionTd).text().toUpperCase()) == milestoneName.toUpperCase()) {
				milestoneExists = true;
				return false;
			}
		});

		//Check custom milestone
		if (!milestoneExists) {
			var userOrganizationalUnit = projConfig.globalValues.userOrganizationalUnitName;
			var customMilestoneIds = $(projConfig.customMilestoneGridSelector).getDataIDs(); //all the rowids   
			for (var index = 0; index < customMilestoneIds.length; index++) {
				var rowData = rm.grid.rowData.getById(projConfig.customMilestoneGridSelector, customMilestoneIds[index]);
				if (rowData.MilestoneName.toUpperCase() == milestoneName.toUpperCase() && projConfig.globalValues.userOrganizationalUnitId == rowData.OrganizationalUnitId) {
					milestoneExists = true;
					break;
				}
			}
		}
		return milestoneExists;
	},
	getCountryMilestoneTextBoxHtml: function (cellvalue, options, rowObject) {
		var returnValue;
		var textboxId = "txt" + rowObject.id;
		var readOnly = rowObject.IsPpmMilestone || (rowObject.OrganizationalUnitId != 0 && rowObject.OrganizationalUnitId != projConfig.globalValues.userOrganizationalUnitId);
		if (readOnly) {
			returnValue = "<input type='text' class='countrymilestonedate fieldsetLabelWIdthMedium' disabled='true' allowEdit='0' readonly='true' id='" + textboxId + "'  value='" + cellvalue + "'>";
		}
		else {
			returnValue = "<input type='text' class='countrymilestonedate fieldsetLabelWIdthMedium' disabled='true' allowEdit='1' id='" + textboxId + "' value='" + cellvalue + "'>";
		}
		return returnValue;
	},
	getMilestoneComment: function () {
		if (projConfig.globalValues.userOrganizationalUnitName != null && projConfig.globalValues.userOrganizationalUnitName != "") {
			return "Manually updated" + "-" + projConfig.globalValues.userOrganizationalUnitName;
		}
		else {
			return "Manually updated" + "-" + projConfig.globalValues.userSharePointRole;
		}
	},
	getNewOrUpdatedCountryMilestones: function () {
		var gridSelector = projConfig.countryGridSelector;
		var countryMilestoneList = new Array();
		if ($("#ddlRegionList").val() != "-1" && $("#ddlCountryList").val() != "-1") {
			countryMilestoneList.push({
				Id: -1,
				ProjectId: projConfig.getProjectId(),
				CountryMilestoneId: -1,
				CountryId: $("#ddlCountryList").val()
			});
		}
		else {
			var milestoneIds = $(gridSelector).getDataIDs();
			for (var index = 0; index < milestoneIds.length; index++) {
				var rowData = rm.grid.rowData.getById(gridSelector, milestoneIds[index]);
				var updatedDate = $(gridSelector + " tr[id=" + rowData.id + "] .countrymilestonedate").val();
				if (updatedDate != rowData.MilestoneDate) {
					countryMilestoneList.push({
						Id: rowData.id,
						ProjectId: rowData.ProjectId,
						CountryMilestoneId: rowData.CountryMilestoneId,
						CountryId: rowData.CountryId,
						MilestoneDate: $(gridSelector + " tr[id=" + rowData.id + "] .countrymilestonedate").val(),
						Comment: projConfig.getMilestoneComment(),
						OrganizationalUnitId: projConfig.globalValues.userOrganizationalUnitId
					});
				}
			}
		}
		return countryMilestoneList;
	},
	getUpdatedProjectMilestones: function () {
		var projectMilestoneList = new Array();
		$("#projectMilestone tbody tr").each(function (index, element) {
			var milestoneDate = $(this).find(".projectMilestoneDate").val();
			var originalDate = $(this).find("td[originalDate]").attr("originalDate");
			if (originalDate.toUpperCase() != milestoneDate.toUpperCase()) {
				projectMilestoneList.push({
					ProjectId: projConfig.getProjectId(),
					ProjectMilestoneId: $(this).find("td[projectMilestoneId]").attr("projectMilestoneId"),
					MilestoneDate: milestoneDate,
					Comment: projConfig.getMilestoneComment()
				});
			}
		});
		return projectMilestoneList;
	},
	getNewCustomMilestone: function () {
		var customMilestones = new Array();
		//Add the values to an array
		if (milestoneNs._selectedTab == 2 && $.trim($("#custommilestonedate").val()) != "" && $.trim($("#txtmilestone").val()) != "") {
			customMilestones.push({
				CustomMilestoneId: 0, //always zero sinc this method always returns new custom milestone
				ProjectId: projConfig.getProjectId(),
				Name: $("#txtmilestone").val(),
				MilestoneDate: $("#custommilestonedate").val(),
				OrganizationalUnitId: projConfig.globalValues.userOrganizationalUnitId,
				Description: "Custom Milestone",
			});
		}
		return customMilestones;
	},
	getMilestonePostData: function () {
		return {
			projectDetails: {
				ProjectId: projConfig.getProjectId(),
				CustomMilestones: projConfig.getNewCustomMilestone(),
				ProjectMilestonesList: projConfig.getUpdatedProjectMilestones(),
				CountryMilestones: projConfig.getNewOrUpdatedCountryMilestones()
			}
		};
	},
	buildCountryMilestonesGrid: function (projectId) {
		var gridPost = { sidx: "CountryName", sord: "asc" };
		$(projConfig.countryGridSelector).jqGrid({
			url: rm.ajax.projectSvcUrl + "GetCountryMilestone",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			postData: gridPost,
			loadonce: false,
			autowidth: false,
			height: window.screen.height - 465,
			width: 850,
			shrinkToFit: false,
			pager: '#listCountryPager',
			colModel: [
				{ name: 'CountryMilestoneId', index: 'CountryMilestoneId', label: 'CountryMilestoneId', hidden: true },
				{ name: 'RegionName', index: 'RegionName', label: 'Region', sortable: true, search: true, hidden: true },
				{ name: 'CountryId', index: 'CountryId', label: 'CountryId', hidden: true },
				{ name: 'MappingTable', index: 'MappingTable', label: 'MappingTable', hidden: true },
				{ name: 'MappingColumn', index: 'MappingColumn', label: 'MappingColumn', hidden: true },
				{ name: 'DateToCompare', index: 'DateToCompare', label: 'DateToCompare', hidden: true },
				{ name: 'CountryName', index: 'CountryName', label: 'Country', sortable: true, search: true, searchoptions: { attr: { maxlength: 255 } } },
				{ name: 'MilestoneName', index: 'MilestoneName', label: 'Milestone', sortable: true, width: 200, search: true, searchoptions: { attr: { maxlength: 255 } } },
				{
					name: 'MilestoneDate', index: 'MilestoneDate', label: 'Date', sortable: true, align: 'left', width: 150, search: true,
					searchoptions: { attr: { maxlength: 255 } },
					formatter: projConfig.getCountryMilestoneTextBoxHtml, formatoptions: {}
				},
				{ name: 'Comment', index: 'Comment', label: 'Comment', width: 120, classes: 'ui-ellipsis', sortable: true, search: true, searchoptions: { attr: { maxlength: 255 } } },
				{ name: 'ManualEntryDate', index: 'ManualEntryDate', label: 'Manual Entry Date', classes: 'ui-ellipsis', sortable: false, search: false },
			],
			sortname: gridPost.sidx,
			sortorder: gridPost.sord,
			multipleSearch: true,
			//Use on double click instead of onSelect - much safer (i.e. no side-effects)
			ondblClickRow: function (id, rowId) { },
			onSelectRow: function (id) { },
			onSelectAll: function (rowIdxArray, sts) { },
			onPaging: function () { },
			serializeRowData: function (postData) { return JSON.stringify(postData); },
			serializeGridData: function (postData) {
				var data = null;
				var countryValue = $.trim($("#gs_CountryName").val());
				if (countryValue == "") {
					if ($("#ddlCountryList").is(":enabled") && $("#ddlCountryList").val() != "-1") {
						countryValue = $("#ddlCountryList :selected").text();
					}
				}
				if (countryValue != "") {
					var data = { ProjectId: projectId, CountryName: countryValue };
					$("#gs_CountryName").val(countryValue);
				}
				else {
					data = { ProjectId: projectId };
				}
				return rm.grid.serializeGridData(postData, data);
			},
			gridComplete: function () {
				if (!milestoneNs._isAddEditButtonEnabled) {
					SetEditMode();
				}
				bindDirty();
			},
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData(projConfig.countryGridSelector, data); }
		});
		$(projConfig.countryGridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},
	buildCustomMilestoneGrid: function (projectId) {
		var gridPost = { sidx: "OrganizationalUnitName", sord: "asc" };
		$(projConfig.customMilestoneGridSelector).jqGrid({
			url: rm.ajax.projectSvcUrl + "GetCustomMilestone",
			editurl: rm.ajax.projectSvcUrl + "UpdateCustomMilestone",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			postData: gridPost,
			loadonce: false,
			autowidth: false,
			height: window.screen.height - 465,
			width: 740,
			shrinkToFit: false,
			multiselect: true,
			colModel: [
				{
					name: '', label: '', index: 'actions',
					formatter: 'actions', editable: false, sortable: false, resizable: false,
					fixed: true, width: 40, search: false,
					formatoptions: {
						keys: true, editbutton: false, delbutton: false,
						onEdit: function (rowid) {   //only fires when you click the icon, not when you call editRow
							addToRowsEditing(rowid);
							return true;
						},
						afterRestore: function (rowid) {
							rowsEditing.pop(rowid);
							rm.grid.scrollTableBodyToFixAlignmentIssue(projConfig.countryGridSelector);
						},
						// have to use onError to handle the validation errors (sent as exceptions)
						onError: function (rowid, response, errorType) { },
						//onSuccess is where AJAX response comes in
						onSuccess: function (response) {
							return saveSuccessCallback(response, true);  //singleRow
						}
					}
				},
				rm.grid.standardColumns.getMessageColumn(),
				rm.grid.standardColumns.getEditableMilestoneNameColumn('MilestoneName', 'MilestoneName', 'Name'),
				rm.grid.standardColumns.getEditableMilestoneDateColumn('MilestoneDate', 'MilestoneDate', 'Date'),
				{ name: 'OrganizationalUnitName', index: 'OrganizationalUnitName', label: 'Owner', width: 225, classes: 'ui-ellipsis', sortable: true, search: true, hidden: false }
			],
			sortname: gridPost.sidx,      //passed as postData and enables the sort icon in header - but DOES NOT sort the table
			sortorder: gridPost.sord,       //passed as postData and enables the sort icon in header - but DOES NOT sort the table
			multipleSearch: true,
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			ondblClickRow: function (id) {
				var rowData = rm.grid.rowData.getById(projConfig.customMilestoneGridSelector, id);
				if (projConfig.globalValues.userOrganizationalUnitId != rowData.OrganizationalUnitId) {
					alert("Milestone(s) belonging to other owner cannot be updated.");
				}
				else {
					addToRowsEditing(id);
					$(this).jqGrid('editRow', id, false);   //handleResult only fires when saving using Keys!! damnit
					$(projConfig.customMilestoneGridSelector + " tr[id=" + id + "]").find("div.ui-inline-edit,div.ui-inline-del").hide();
					$(projConfig.customMilestoneGridSelector + " tr[id=" + id + "]").find("div.ui-inline-save,div.ui-inline-cancel").show();
					milestoneNs._isSaveButtonEnabled = true;
					milestoneNs._isCancelButtonEnabled = true;
					rm.ui.ribbon.delayedRefresh();
				}
			},
			onSelectRow: function (id) { rm.ui.ribbon.delayedRefresh(); },
			onSelectAll: function (id) { rm.ui.ribbon.delayedRefresh(); },
			serializeRowData: function (postData) { return JSON.stringify(postData); },
			serializeGridData: function (postData) {
				var data = { ProjectId: projectId };
				return rm.grid.serializeGridData(postData, data);
			},
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData(projConfig.customMilestoneGridSelector, data); }
		});
		$(projConfig.customMilestoneGridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},
	setGlobalVariables: function () {
		if (globalValues) {
			projConfig.globalValues.isDteProject = globalValues.isDteProject;
			projConfig.globalValues.projectCode = globalValues.projectCode;
			projConfig.globalValues.projectId = globalValues.selectedProjectId;
			projConfig.globalValues.userOrganizationalUnitName = globalValues.organizationalUnitName;
			projConfig.globalValues.userOrganizationalUnitId = globalValues.organizationalUnitId;
			projConfig.globalValues.userSharePointRole = globalValues.userSharePointRole;
			projConfig.globalValues.isProposalProject = globalValues.isProposalProject;
			$("#txtOwner").val(projConfig.globalValues.userOrganizationalUnitName);
		}
	},
	allowDeletingCustomMilestone: function () {
		var allowDelete = true;
		var selectedRows = $(projConfig.customMilestoneGridSelector).getGridParam('selarrrow');
		$.each(selectedRows, function (index, rowId) {
			var rowData = rm.grid.rowData.getById(projConfig.customMilestoneGridSelector, rowId);
			if (rowData.OrganizationalUnitId != projConfig.globalValues.userOrganizationalUnitId) {
				allowDelete = false;
				return false;
			}
		});
		return allowDelete;
	},
	addNewCustomMilestoneToGrid: function (data) {
		rm.grid.rowData.addData(projConfig.customMilestoneGridSelector, data);
		$(projConfig.customMilestoneGridSelector).addRowData(data.id, [{
			Message: "",
			MilestoneName: data.MilestoneName,
			MilestoneDate: data.MilestoneDate,
			OrganizationalUnitName: projConfig.globalValues.userOrganizationalUnitName
		}], "last");
	},
	addProjectMilestoneRow: function (projectMilestoneId, milestoneDate, description, comment, isReadonly, manualEntryDate) {
		var newRow = "<tr " + (isReadonly ? "disabled='true'" : "") + ">" +
			"<td  class='descriptionTd milestoneDescription'>" + description + "</td>" +
			"<td projectMilestoneId='" + projectMilestoneId + "' originalDate='" + milestoneDate + "'><input type='text' " + (isReadonly ? "disabled='true'" : "") + " class='projectMilestoneDate " + (isReadonly ? "" : "qdatePickerControl") + " fieldsetLabelWIdthMedium' value='" + milestoneDate + "'> </td>" +
			"<td class='commentTd'>" + comment + "</td>" +
			"<td class='historyTd'>" + manualEntryDate + "</td>" +
			"</tr>";
		return newRow;
	},
	getProjectMilestoneById: function (projectId, showReadOnly) {
		RemoveProjectMilestoneRow();
		if (projectId != 0) {
			rm.ajax.projectSvcAsyncPost("GetProjectMilestonesByProjectId", { projectId: projectId }, function (data) {
				projConfig.projectMilestoneData = data;

				$.each(data, function (index, element) {
					projConfig.showDateOnDteSchemaTab(element);
					var comment = element.Comment;
					var isReadonly = showReadOnly;

					if (element.MilestoneDate != "" && (comment == "" || comment == null)) {
						comment = "From PPM";
						isReadonly = true;
					}

					var manualEntryDate = (comment == "From PPM") ? element.ManualEntryDate : "";
					$("#projectMilestone tbody").append(projConfig.addProjectMilestoneRow(element.ProjectMilestoneId, element.MilestoneDate, element.Description, comment, isReadonly, manualEntryDate));
				});
				projConfig.calculateFsiCovWeeks();
				$(".qdatePickerControl").qDatepicker();
				bindDirty();
				rm.ui.ribbon.delayedRefresh();
			})
		}
	},
	calculateFsiCovWeeks: function () {
		if (projConfig.globalValues.isDteProject) {
			var fsiMilestoneString = $(projConfig.lblFsiSelector).text();
			var covMilestoneString = $(projConfig.lblCovSelector).text();
			if (rm.date.isValidDate(fsiMilestoneString, false) && rm.date.isValidDate(covMilestoneString, false)) {
				$(projConfig.lblFsiCovWeeksSelector).text(Math.round(rm.date.qDateDiffWeeks(fsiMilestoneString, covMilestoneString)));
			}
			else { $(projConfig.lblFsiCovWeeksSelector).text(""); }
		}
	},
	showDateOnDteSchemaTab: function (projectMilestoneWs) {
		var selector = "";
		switch (projectMilestoneWs.ProjectMilestoneId) {
			case 15: selector = projConfig.lblFsiSelector;
				break;
			case 24: selector = projConfig.lblCovSelector;
				break;
			case 29: selector = projConfig.lblLsiSelector;
				break;
			case 27: selector = projConfig.lblLsoSelector;
				break;
		}
		if (selector != "") { $(selector).text(projectMilestoneWs.MilestoneDate); }
	}
};

SetProjectMilestoneReadonly = function () { $("#projectMilestone *").attr("disabled", "disabled"); };
SetReadonlyContents = function () {
	$("#customMileStone *").attr("disabled", "disabled");
	$("#customMilestoneGrid *").attr("disabled", "disabled");
	$("#CountryMilestoneInput *").attr("disabled", "disabled");
};

SetEditMode = function () {
	if (projConfig.globalValues.userOrganizationalUnitId != null) {
		$("#customMileStone *").removeAttr("disabled");
		$("#custommilestonedate").qDatepicker("enable");
	}
	$("#customMilestoneGrid *").removeAttr("disabled");
	projConfig.getProjectMilestoneById(projConfig.getProjectId(), false);
	$("#txtOwner").attr("disabled", "disabled");
	$("#CountryMilestoneInput *").removeAttr("disabled");
	$(".countrymilestonedate[allowedit=1]").removeAttr("disabled").qDatepicker();
};
SaveMilestone = function () {

	$(document).trigger('click');
	if (ValidateMilestone()) {

		milestoneNs.Save();
		ClearAll();
		$(document).blur();
	}
	else {
		rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
	}
};
CancelMilestone = function () {
	var isDirty = milestoneNs.checkPageDirty();
	if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
		window.onbeforeunload = null;
		var url = $.url();
		document.location.href = url.attr('protocol') + "://" + url.attr('host') + url.attr('path');
	}
};
DeleteMilestone = function () {

	if (milestoneNs._selectedTab == 2 && GetSelectedCustomMilestone().length != 0) {

		if (projConfig.allowDeletingCustomMilestone()) {
			if (confirm("Are you sure you want to delete the milestone(s)? If deleted, it will no longer be available in this project.")) {
				DeleteSelectedMilestone();
			}
		}
		else {
			alert("Milestone(s) belonging to other owner cannot be deleted. Please unselect and try.");
		}
	}
};

var dteSchemaNs = {
	_isVisitSchemaUndefined: false,
	_errmsg: "",
	dteSchemaLoadComplete: false,
	hdnIsStafFileUploadedSelector: "[id$=hdnIsStafFileUploaded]",
	divStafExcelUploadSelector: "#divStafExcelUpload",
	fuStafExcelSelector: "[id$=fuStafExcel]",
	isUploadStafExcelButtonEnabled: function () { return projConfig.globalValues.isDteProject; },
	isDownloadStafExcelButtonEnabled: function () { return $(dteSchemaNs.hdnIsStafFileUploadedSelector).val() === "1"; },
	showUploadStafExcelDialog: function () {
		var btnOk = {
			text: "Upload", click: function () {
				if (dteSchemaNs.isValidStafExcelSelected()) {
					rm.ui.dialog.showWaitModalWithNoClose("Uploading...");
					setTimeout(dteSchemaNs.uploadStafExcel, 10);
					$(this).dialog("close");
				}
			}
		}
		rm.ui.dialog.showModalWithButtonsAndCloseHandler(dteSchemaNs.divStafExcelUploadSelector, "Upload STAF Excel", "", false, 350, 200, [btnOk, rm.ui.dialog.standardButtons.cancel], null, dteSchemaNs.clearUploadFileControlOnClose);
	},
	isValidStafExcelSelected: function () {
		var maxFileSize = 52428800;
		var isValid = true;
		var fileExtension = $(dteSchemaNs.fuStafExcelSelector).val().toUpperCase();
		if ($(dteSchemaNs.fuStafExcelSelector).val() === "") {
			rm.ui.messages.addError("Select STAF excel file to upload.");
			isValid = false;
		}
		else if (!fileExtension.endsWith('.XLSM') && !fileExtension.endsWith('.ZIP') && !fileExtension.endsWith('.7Z')) {
			rm.ui.messages.addError("Select a STAF Excel file to upload. Allowed file types: .xlsm, .zip, .7z.");
			isValid = false;
		}
		else if ($(dteSchemaNs.fuStafExcelSelector).get(0).files[0].size > maxFileSize) {
			rm.ui.messages.addError("File exceeds max allowed size of " + maxFileSize / (1024 * 1024) + "MB.");
			isValid = false;
		}
		return isValid;
	},
	uploadStafExcel: function () {
		var formData = new FormData();
		formData.append("projectId", projConfig.getProjectId());
		formData.append("ID", 13);
		formData.append("stafFileContent", $(dteSchemaNs.fuStafExcelSelector).get(0).files[0]);

		var xhr = new XMLHttpRequest();
		xhr.open("POST", "/ViewAttachment.ashx", true);

		//Handler for "OnRequestComplete"
		xhr.onload = function () {
			rm.ui.unblock();
			dteSchemaNs.clearUploadFileControlOnClose();
			if (xhr.status === 200) {
				var jsonResponse = JSON.parse(xhr.response);
				if (jsonResponse.IsSuccessful) {
					rm.ui.messages.clearError();
					rm.ui.messages.showSuccess("STAF excel uploaded successfully.");
					$(dteSchemaNs.hdnIsStafFileUploadedSelector).val(1); //update the file upload status in the page so that download button gets enabled.
					rm.ui.ribbon.delayedRefresh();
				}
				else { rm.validation.processErrorMessages(jsonResponse.Errors); }
			}
			else { rm.ui.dialog.showServiceErrorModal("Upload Error: ", xhr.responseText ? xhr.responseText : xhr.response); }
		};

		xhr.send(formData);
	},
	clearUploadFileControlOnClose: function () { $(dteSchemaNs.fuStafExcelSelector).val(""); },
	downloadStafExcel: function () {
		document.location.href = "/ViewAttachment.ashx?ID=14&projectId=" + projConfig.getProjectId();
	},
	isSaveButtonEnabled: function () {
		if (dteSchemaNs.isSchemaRefreshRequired()) {
			if ($("#overlayDiv").length == 0) {
				$("[id$=staticGraphData]").prepend($("<div>", { id: 'overlayDiv', class: 'overlayDiv', html: "<br/><span style='padding: 3px;background-color:orange;color:white;'>Click 'Save Schema' to refresh visit pattern<span>" }));
			}
		}
		else { $("#overlayDiv").remove(); }
		return dteSchemaNs.isPageDirty();
	},
	isModifyButtonEnabled: function () { return $(projConfig.siteMonitoringTableSelector + " input:enabled").length === 0; },
	isCancelButtonEnabled: function () { return !dteSchemaNs.isModifyButtonEnabled() },
	init: function () {
		dteSchemaNs.setVisitRangeMinValue();
		dteSchemaNs.bindHelpTextHover();
		dteSchemaNs.bindEventHandlers();
		dteSchemaNs.showDteSchema(projConfig.getProjectId());
		dteSchemaNs.showHidePseudoSchemaWarning();
		//handle Budget refresh complete event to show latest qip version on UI
		$(document).on(rm.events.onBudgetRefreshComplete, function (event, latestQipVersion) {
			$("[id$=lblQipVersion]").text(latestQipVersion);
			dteSchemaNs.refreshDteSchemaDetails();
		});
		rbmCnvNs.init();
	},

	setVisitRangeMinValue: function () {
		var minValue = projConfig.isTierWithZeroVisitsAllowed() ? 0 : 1;
		//$(projConfig.siteMonitoringTierRowTemplateSelector).find(projConfig.onSiteVisitRatioSelector).attr("from", minValue);--QRPM-25207
		$(projConfig.pharmacyTierRowTemplateSelector).find(projConfig.tierCycleSelector).attr("from", minValue);
	},
	showHidePseudoSchemaWarning: function () {
		if (projConfig.globalValues.isDteProject && //DTE Project
			$(projConfig.hdnIsDteSchemaAlreadyConfiguredSelector).val() === "1" && //DTE schema is configured
			$(projConfig.hdnHasUserDefinedSchemaSelector).val() === "0") { //it is not a user saved schema
			rm.ui.messages.addWarningAsBlock(Resources.UserDefinedSchemaMsg);
		}
		else if (projConfig.globalValues.isDteProject && //DTE Project
			$(projConfig.hdnIsDteSchemaAlreadyConfiguredSelector).val() === "0" && //DTE schema is not configured
			$(projConfig.hdnAreMilesontesValidForPseudoSchamaCreationSelector).val() === "0") { //Milestones required from pseudo-schema are missing
			rm.ui.messages.addWarningAsBlock(Resources.MissingMilestonesForPseudoSchemaGeneration);
		} else {
			rm.ui.messages.clearWarning();
		}
	},

	showSiteDistributionModeler: function () {
		rm.ui.dialog.showModal("#divSiteDistributionModeler", "Site Distribution Modeler", "", false, 330, 350, null, dteSchemaNs.onSiteDistributionModalOpen);
	},
	showOsVsRvComparison: function () {
		rm.ui.dialog.showModal("#divOsVsRvComparison", "On-Site vs Remote Visit Comparison", "", false, 300, 200, null, dteSchemaNs.osVsRvComparisonModalOpen);
	},
	osVsRvComparisonModalOpen: function () {
		rm.ui.tabs.activateByIndex("#tabs", 3);
		$(projConfig.txtRvOsRatioSelector).trigger("change");
	},
	onSiteDistributionModalOpen: function () {
		rm.ui.tabs.activateByIndex("#tabs", 3);
		$("#tblSiteDistributionModeler tr.modelerRow").remove();
		$(projConfig.getSiteMonitoringTierRowCollectionSelector()).each(function (index, row) {
			var tierRow = $(row);
			var html = "<tr class='modelerRow'><td>" + tierRow.find(projConfig.tierNameSelector).text() + "</td>";
			html += "<td>" + tierRow.find(projConfig.targetSitePercentageSelector).val() + "</td>";
			html += "<td><input type='text'  class='validateRange' style='width:60px' allowBlank='true' from='0' to='99999' formating='5,0' value='" + tierRow.find(projConfig.projectedNumberOfSitesSelector).text() + "'/></td>";
			html += "<td placeholderKey='modelerRowSitePct'>" + tierRow.find(projConfig.targetSitePercentageSelector).val() + "</td></tr>";
			$("#tblSiteDistributionModeler").append(html);
		});
		$("#tblSiteDistributionModeler").append("<tr class='modelerRow'><td colspan='2' aligh='right'>Total sites</td><td><span placeholderKey='modelerRowSiteTotal'/><img src='../images/searchIcon.png' id='infoModelerRowSiteTotal' class='infoIcon'/></td><td></td></tr>");

		setTimeout(function () {
			rm.qtip.showInfo("#infoModelerRowSiteTotal", "Proportions are computed and displayed as <i>integer</i> numbers of sites per tier. This may cause 'Total sites' to not exactly match the RBM Schema's value for 'Projected Initiated Sites'. This is not a defect and should not significantly affect the resulting computed percentages.")
			dteSchemaNs.handleSiteDistributionSiteCountChange();
			$("#tblSiteDistributionModeler input").each(function (index, element) {
				$(element).change(dteSchemaNs.handleSiteDistributionSiteCountChange);
			});
		}, 20);
	},
	handleSiteDistributionSiteCountChange: function () {
		var siteCountTotal = 0;
		var allValid = true;

		$("#tblSiteDistributionModeler input").each(function (index, element) {
			if (rm.validation.range.validate($(element))) {
				if ($(element).val() != "") {
					siteCountTotal += parseInt($(element).val());
				}
			}
			else { allValid = false; }
		});

		if (allValid) {
			$("#tblSiteDistributionModeler input").each(function (index, element) {
				if ($(element).val() != "" && siteCountTotal != 0) {
					$(element).closest("tr").find("td[placeholderKey=modelerRowSitePct]").text(Math.round(parseInt($(element).val()) * 100 / siteCountTotal));
				}
				else {
					$(element).closest("tr").find("td[placeholderKey=modelerRowSitePct]").text("");
				}
			});

			$("#tblSiteDistributionModeler span[placeholderKey=modelerRowSiteTotal]").text(siteCountTotal);
		}
	},
	showTargetSitePercentageDefault: function () {
		var sitePercentageToolTip = "The percentage of sites which are intended to fall into each Tier. Each Tier will have different visit patterns, so varying this percentage will affect whether the total projected visits exceed the Project's total budgeted visits.<br/>The business expectation of the average Target Site Percentage distribution between Tiers for all our Projects is:<br/><br/>";

		rm.ajax.utilitySvcAsyncGet("GetTargetSitePercentageDefault", {}, function (serviceResponse) {
			rm.qtip.showInfo("#infoSmSitePercentage", sitePercentageToolTip + dteSchemaNs.getDefaultValueTable(serviceResponse.OnsiteDefaults));
			rm.qtip.showInfo("#infoPmSitePercentage", sitePercentageToolTip + dteSchemaNs.getDefaultValueTable(serviceResponse.PharmacyDefaults));
		});
	},
	getDefaultValueTable: function (defaultValueList) {
		var tableHtml = "<table border='1' class='table-milestone'><tr><th>Tier</th><th>Typical Site Percentage</th></tr>";

		if (defaultValueList != null) {
			$.each(defaultValueList, function (index, defaultValue) {
				tableHtml += "<tr><td>" + defaultValue.Tier + "</td><td>" + defaultValue.Percentage + "</td></tr>"
			});
		}
		return tableHtml += "</table>";
	},
	cancelSchema: function () {
		var isDirty = dteSchemaNs.isPageDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			rm.ui.messages.clearAllMessages();
			dteSchemaNs.refreshDteSchemaDetails();
		}
	},
	isPageDirty: function () { return rm.formStatus.isDirty(dteSchemaNs.getJsonObjectForDirtyCheck()); },
	isSchemaRefreshRequired: function () { return rm.formStatus.isDirty(dteSchemaNs.getDirtyCheckSelectorForSchemaRefresh()); },
	isSchemaVersionChangeRequired: function () { return rm.formStatus.isDirty(dteSchemaNs.getDirtyCheckSelectorForSchemaVersionChange()); },
	getDirtyCheckSelectorForSchemaRefresh: function () {
		return {
			items:
				[{
					selector: projConfig.getSiteMonitoringTierRowCollectionSelector() + " input," + projConfig.getPharmacyTierRowCollectionSelector() + " input, " + projConfig.isPharmacyEnabledSelector,
					dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort
				}]
		};
	},
	getJsonObjectForDirtyCheck: function () {
		return {
			items:
				[{
					selector: dteSchemaNs.getDirtyCheckSelectorForSchemaRefresh().items[0].selector + ",.budgetRow input[type=text],.bufferRow input[type=text]",
					dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort
				}]
		};
	},
	getDirtyCheckSelectorForSchemaVersionChange: function () {
		return {
			items:
				[{
					selector: "input[affectsschemaversion=1]:visible",
					dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort
				}]
		};
	}, getPpmProjectedInitiatedSite: function () { return parseInt($(projConfig.ppmProjectedInitiatedSiteSelector).text()); },
	refreshDteSchemaDetails: function () {
		$(projConfig.isPharmacyEnabledSelector).prop("disabled", "disabled");
		dteSchemaNs.showDteSchema(projConfig.getProjectId());
		dteSchemaNs.showVisitPatternGraphData(projConfig.getProjectId());
		rm.ui.tabs.activateByIndex("#tabs", 3);
		rm.ui.ribbon.delayedRefresh();
	},
	saveSchema: function () {
		dteSchemaNs._errmsg = Resources.CorrectErrorsTryAgain;
		rm.ui.messages.clearError();
		var isValid = dteSchemaNs.isOnsiteMonitoringSchemaValid();
		isValid = dteSchemaNs.isPharmacySchemaValid() && isValid;

		if (isValid) {
			if (dteSchemaNs.hasTierCycleGt52()) { dteSchemaNs.showTierCycleGt52WaringDialog(); }
			else {
				if (!projConfig.isTierWithZeroVisitsAllowed() && dteSchemaNs.hasZeroOnsiteVisits()) { dteSchemaNs.showZeroOnsiteVisitsWarningDialogAndSave(); }
				else { dteSchemaNs.showSchemaChangeReasonDialog(); }
			}
		}
		else { rm.ui.messages.addError(dteSchemaNs._errmsg); }
	},
	showSchemaChangeReasonDialog: function () {
		if (dteSchemaNs.isSchemaVersionChangeRequired()) {
			dteSchemaNs.showChangeReasonDialogAndSave();
		}
		else {
			dteSchemaNs.saveSchamaToDatabase();
		}
	},
	hasTierCycleGt52: function () {
		var hasValueGt52 = false;
		$(projConfig.getSiteMonitoringTierRowCollectionSelector()).each(function (index, row) {
			var tierRow = $(row);
			if (tierRow.find(projConfig.cbTierEnabledSelector).is(":checked")) {
				if (tierRow.find(projConfig.tierCycleSelector).val() > 52) {
					hasValueGt52 = true;
					return false;
				}
			}
		});
		return hasValueGt52;
	},
	showTierCycleGt52WaringDialog: function () {
		var buttons = [
			rm.ui.dialog.standardButtons.cancel,
			{
				text: "Save", click: function () {
					$(this).dialog("close");
					if (!projConfig.isTierWithZeroVisitsAllowed() && dteSchemaNs.hasZeroOnsiteVisits()) { dteSchemaNs.showZeroOnsiteVisitsWarningDialogAndSave(); }
					else { dteSchemaNs.showSchemaChangeReasonDialog(); }
				}
			}
		];
		rm.ui.dialog.showModalWithButtons(projConfig.tierCycleWarningDialogSelector, "Confirm Save with high Tier Cycle (Weeks)?", "", false, 400, 180, buttons);
	},
	hasZeroOnsiteVisits: function () {
		var hasZeroOnsiteVisits = false;
		$(projConfig.getSiteMonitoringTierRowCollectionSelector()).each(function (index, row) {
			var tierRow = $(row);
			if (tierRow.find(projConfig.cbTierEnabledSelector).is(":checked")) {
				if (tierRow.find(projConfig.onSiteVisitRatioSelector).val() == 0) {
					hasZeroOnsiteVisits = true;
					return false;
				}

			}
		});
		return hasZeroOnsiteVisits;
	},
	showZeroOnsiteVisitsWarningDialogAndSave: function () {
		var buttons = [
			{
				text: "Ok", click: function () {
					$(this).dialog("close");
					dteSchemaNs.showSchemaChangeReasonDialog();
				}
			},
			rm.ui.dialog.standardButtons.cancel
		];
		rm.ui.dialog.showModalWithButtonsAndCloseHandler(projConfig.zeroOnsiteVisitsWarningDialogSelector, "Warning", "", false, 400, 140, buttons, null, function () { rm.ui.dialog.setDefaultButton(projConfig.zeroOnsiteVisitsWarningDialogSelector, "Cancel"); });
	},
	saveSchamaToDatabase: function () {
		rm.ajax.projectSvcAsyncPost("SaveProjectCustomSchemaDetails", dteSchemaNs.getPostData(), function (data) {
			if (data.ContainsValidationErrors) {
				$.each(data.ValidationErrors, function (index, ele) { rm.ui.messages.addError(ele.Value); });
			}
			else {
				$(projConfig.hdnHasUserDefinedSchemaSelector).val("1");
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showSuccess("Custom schema details saved successfully.");
				dteSchemaNs.refreshDteSchemaDetails();
			}
		});
	},
	showChangeReasonDialogAndSave: function () {
		$(projConfig.txtReasonForSchemaChangeSelector).val("");
		rm.validation.clearError(projConfig.txtReasonForSchemaChangeSelector);

		var okButton = {
			text: "OK", click: function () {
				if ($.trim($(projConfig.txtReasonForSchemaChangeSelector).val()) == "") {
					rm.validation.addError(projConfig.txtReasonForSchemaChangeSelector, "Change reason is required");
				}
				else {
					rm.validation.clearError(projConfig.txtReasonForSchemaChangeSelector);
					dteSchemaNs.saveSchamaToDatabase();
					$(this).dialog("close");
				}
			}
		};
		var title = "Change Reason";
		rm.ui.dialog.showModalWithButtonsAndCloseHandler("#selectChangeReasonDialog", title, "", false, 400, 150, [okButton, rm.ui.dialog.standardButtons.cancel], null, function () {
			$(projConfig.txtReasonForSchemaChangeSelector).focus();

			$(projConfig.txtReasonForSchemaChangeSelector).unbind("keydown").keydown(function (event) {
				if (rm.utilities.isEnterKey(event.keyCode)) {
					$(this).closest("div.ui-dialog").find("button:contains('" + okButton.text + "')").trigger("click")
				}
			});
		});
	},
	areControlsWithValueRangeValid: function (tierRowListSelector) {
		var isValid = true;
		$(tierRowListSelector).find(projConfig.cbTierEnabledSelector + ":checked").closest("tr").find(rm.validation.visibleValidateRangeSelector).each(function (index, element) {
			if (!rm.validation.range.validate($(element))) { isValid = false; }
		});
		return isValid;
	},
	isDefaultTierSelected: function (tierRowListSelector, tierRadioButtonSelector) { return $(tierRowListSelector).find(tierRadioButtonSelector + ":checked").length != 0; },
	sitePercentageAddsTo100: function (totalSitePercentSelector) { return parseFloat($(totalSitePercentSelector).text()) == 100; },
	atLeastOnTierEnabled: function (tierRowListSelector) { return $(tierRowListSelector).find(projConfig.cbTierEnabledSelector + ":checked").length != 0; },
	isOnsiteMonitoringSchemaValid: function () {
		var error = "";
		var isValid = true;
		if (!dteSchemaNs.atLeastOnTierEnabled(projConfig.getSiteMonitoringTierRowCollectionSelector())) {
			error += "<br />At least one tier should be enabled for RBM Site Monitoring.";
			isValid = false;
		}
		if (!dteSchemaNs.sitePercentageAddsTo100(projConfig.getTotalOnsiteTargetSitePctSelector())) {
			error += "<br />Total Target Site Percentage should be equal to 100 for RBM Site Monitoring.";
			isValid = false;
		}
		if (!dteSchemaNs.areControlsWithValueRangeValid(projConfig.getSiteMonitoringTierRowCollectionSelector())) {
			isValid = false;
		}

		$(projConfig.getSiteMonitoringTierRowCollectionSelector()).find(projConfig.cbTierEnabledSelector + ":checked").closest("tr").find(projConfig.onSiteVisitRatioSelector).each(function () {
			validationStatus = dteSchemaNs.validateOnsiteAndRemoteVisitRatio({ target: this });

			if (validationStatus != null && !validationStatus.isValid) {
				error += "<br />" + validationStatus.errorMessage;
				isValid = false;
				return false;
			}
		});

		var fsiLsiDefaultTierSelected = dteSchemaNs.isDefaultTierSelected(projConfig.getSiteMonitoringTierRowCollectionSelector(), projConfig.rbFsiLsiDefaultTierSelector);
		var lsiLsoDefaultTierSelected = dteSchemaNs.isDefaultTierSelected(projConfig.getSiteMonitoringTierRowCollectionSelector(), projConfig.rbLsiLsoDefaultTierSelector);
		var lsoCovDefaultTierSelected = dteSchemaNs.isDefaultTierSelected(projConfig.getSiteMonitoringTierRowCollectionSelector(), projConfig.rbLsoCovDefaultTierSelector);
		if (!fsiLsiDefaultTierSelected || !lsiLsoDefaultTierSelected || !lsoCovDefaultTierSelected) {
			isValid = false;
			var innerError = "";
			if (!fsiLsiDefaultTierSelected) { innerError += (innerError == "" ? "" : ", ") + "FSI-LSI Default Tier"; }
			if (!lsiLsoDefaultTierSelected) { innerError += (innerError == "" ? "" : ", ") + "LSI-LSO Default Tier"; }
			if (!lsoCovDefaultTierSelected) { innerError += (innerError == "" ? "" : ", ") + "LSO-COV Default Tier"; }

			error += "<br />Please select " + innerError + ".";
		}
		$(projConfig.pharmacyOnsite)

		if (!rm.validation.range.validate(projConfig.getSiteMonitoringBufferSelector())) { isValid = false; }

		dteSchemaNs._errmsg += error;
		return isValid;
	},
	isPharmacySchemaValid: function () {
		var error = "";
		var isValid = true;
		if (dteSchemaNs.isPharmacySchemaEnabled()) {
			if (!dteSchemaNs.atLeastOnTierEnabled(projConfig.getPharmacyTierRowCollectionSelector())) {
				error += "<br />At least one tier should be enabled for RBM Pharmacy Monitoring.";
				isValid = false;
			}
			if (!dteSchemaNs.sitePercentageAddsTo100(projConfig.getTotalPharmacyTargetSitePctSelector())) {
				error += "<br />Total Target Site Percentage should be equal to 100 for RBM Pharmacy Monitoring.";
				isValid = false;
			}
			if (!dteSchemaNs.isDefaultTierSelected(projConfig.getPharmacyTierRowCollectionSelector(), projConfig.rbPharmacyDefaultTierSelector)) {
				error += "<br />Please select Pharmacy Default Tier.";
				isValid = false;
			}
			if (!dteSchemaNs.areControlsWithValueRangeValid(projConfig.getPharmacyTierRowCollectionSelector())) { isValid = false; }
			if (!rm.validation.range.validate(projConfig.getPharmacyBufferSelector())) { isValid = false; }
		}
		dteSchemaNs._errmsg += error;
		return isValid;
	},
	showDteSchema: function (projectId) {
		if (!projConfig.globalValues.isDteProject || projConfig.globalValues.isProposalProject) {
			rm.ui.tabs.disableByIndex("#tabs", [3]);
		}
		else {
			rm.ajax.projectSvcAsyncPost("GetDTESchemaByProjectId", { projectId: projectId }, function (serviceResponse) {
				if (!serviceResponse.IsSuccessful) {
					rm.ui.dialog.showServiceErrorModal("Service Error", serviceResponse.Message);
				}

				var data = serviceResponse.AdditionalData;
				if (data.SchemaLevel != '') {
					$("#DteVisitSchemaLevel").text('Visit Schema Level: ' + data.SchemaLevel);
					if (data.LastModifiedBy != null) {
						$("#DTELastModifiedDate").text("Last Modified: " + data.LastModifiedOn + " v" + data.SchemaVersion + " by " + data.LastModifiedBy);
					}
					$(".budgetRow input[type=text]:visible").prop("disabled", true);
					$(".bufferRow input[type=text]:visible").prop("disabled", true);

					$(projConfig.getSiteMonitoringTierRowCollectionSelector()).remove();
					$(projConfig.siteMonitoringTableSelector + " tr.tierTotalRow").remove();
					$(projConfig.siteMonitoringTableSelector + " tr.budgetRow").remove();

					$(projConfig.getPharmacyTierRowCollectionSelector()).remove();
					$(projConfig.pharmacyTableSelector + " tr.tierTotalRow").remove();
					$(projConfig.pharmacyTableSelector + " tr.budgetRow").remove();

					dteSchemaNs.handleSiteMonitoringResponse(data.SiteMonitoringSchemaDetails);
					dteSchemaNs.handlePharmacyResponse(data.PharmacySchemaDetails);

					setTimeout(function () {
						$(projConfig.getPharmacyBufferSelector()).bind("change", dteSchemaNs.calculateBufferVisitsCount);
						$(projConfig.getSiteMonitoringBufferSelector()).bind("change", dteSchemaNs.calculateBufferVisitsCount);

						$(dteSchemaNs.getJsonObjectForDirtyCheck().items[0].selector).bind("click blur keyup", rm.ui.ribbon.refresh);
						dteSchemaNs.updateTableTotals(projConfig.siteMonitoringTableSelector);
						dteSchemaNs.updateTableTotals(projConfig.pharmacyTableSelector);
						rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, dteSchemaNs.getJsonObjectForDirtyCheck());

						rm.qtip.showInfo("#infoSmBuffer", "Enter desired buffer for triggered visits. 10% of Budgeted On-Site Interim Monitoring Visits is typical");
						rm.qtip.showInfo("#infoSmBudget", "Sourced from budget<br/>Update to the most recent budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
						rm.qtip.showInfo("#infoSmBufferTargetVisitCount", "% Buffer x Budget x 100. The number of visits to reserve in the buffer for unprojected visits (including, e.g. CTMS-Triggered visits)");
						rm.qtip.showInfo("#infoSmActualBuffer", "Budgeted Visits - Projected Visits. <br/>Red if over-budget. <br/>NB: That this calculation ignores 'Target # Visits for Buffer' for unprojected visits");

						rm.qtip.showInfo("#infoSmCtmdBookedVisits", "Planned or Actual Visits booked into CTMS. These totals will increase if more visits are entered into CTMS - especially likely for future visits. QRPM: RM uses the CTMS Actual Date where available, otherwise the CTMS Planned Date.");
						rm.qtip.showInfo("#infoPmCtmdBookedVisits", "Planned or Actual Visits booked into CTMS. These totals will increase if more visits are entered into CTMS - especially likely for future visits. QRPM: RM uses the CTMS Actual Date where available, otherwise the CTMS Planned Date.");

						rm.qtip.showInfo("#infoSmPastRvVisits", "Past Remote Visits booked into CTMS as Planned or Actual. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS");
						rm.qtip.showInfo("#infoSmPlannedRvVisits", "Future Remote Visits booked into CTMS as Planned or Actual Dates. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS.");
						rm.qtip.showInfo("#infoSmTotalRvVisits", "Total Past and Future Remote Visits booked into CTMS as Planned or Actual Dates. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS.");

						rm.qtip.showInfo("#infoSmPastOsVisits", "Past On-Site Visits booked into CTMS as Planned or Actual. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS");
						rm.qtip.showInfo("#infoSmPlannedOsVisits", "Future On-Site Visits booked into CTMS as Planned or Actual Dates. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS.");
						rm.qtip.showInfo("#infoSmTotalOsVisits", "Total Past and Future On-Site Visits booked into CTMS as Planned or Actual Dates. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS.");

						rm.qtip.showInfo("#infoPmPastOsVisits", "Past Pharmacy Visits booked into CTMS as Planned or Actual. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS");
						rm.qtip.showInfo("#infoPmPlannedOsVisits", "Future Pharmacy Visits booked into CTMS as Planned or Actual Dates. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS.");
						rm.qtip.showInfo("#infoPmTotalOsVisits", "Total Past and Future Pharmacy Visits booked into CTMS as Planned or Actual Dates. This shows only those visits already entered into CTMS, and will increase if more visits are entered into CTMS.");

						rm.qtip.showInfo("#infoPmBuffer", "Enter desired buffer for triggered visits. 2% of Budgeted Pharmacy Visits is typical");
						rm.qtip.showInfo("#infoPmBudget", "Sourced from Budget<br/>Update to the most recent Budget values by selecting the 'Refresh Budget Data' option in the ribbon menu.");
						rm.qtip.showInfo("#infPmBufferTargetVisitCount", "% Buffer x Budget x 100. The number of visits to reserve in the buffer for unprojected visits (including, e.g. CTMS-Triggered visits)");
						rm.qtip.showInfo("#infoPmActualBuffer", "Budgeted Visits - Projected Visits. <br/>Red if over-budget. <br/>NB: This calculation ignores 'Target # Visits for Buffer' for unprojected visits");

						rm.qtip.showInfo("#infoSmProjections", "The visit Projection counts are not exact, as their simple algorithm assumes all Sites in each Country have the same 'Site Initiation Visit' date. <br/><br/> The calculation uses each Project-Country 'First Subject In' - 'Close Out Visit' milestones, plus each Site's assigned Tier, to compute the estimated visit counts.  <br/><br/>Country SIV and COV dates can be found in the 'Monitoring Attributes' page. For exact projections, see the 'Site List' page summary table, or the 'CRA Resourcing and Forecasting Report'");
						rm.qtip.showInfo("#infoPmProjections", "The visit Projection counts are not exact, as their simple algorithm assumes all Sites in each Country have the same 'Site Initiation Visit' date. <br/><br/> The calculation uses each Project-Country 'First Subject In' - 'Close Out Visit' milestones, plus each Site's assigned Tier, to compute the estimated visit counts.  <br/><br/>Country SIV and COV dates can be found in the 'Monitoring Attributes' page. For exact projections, see the 'Site List' page summary table, or the 'CRA Resourcing and Forecasting Report'");
					}, 20);
					dteSchemaNs.dteSchemaLoadComplete = true;
					rm.ui.ribbon.delayedRefresh();
				}
				else {
					dteSchemaNs._isVisitSchemaUndefined = true;
					$(projConfig.dteSchemaContainerSelector).hide();
				}
				$(projConfig.getSiteMonitoringTierRowCollectionSelector() + " input.validateRange," + projConfig.getPharmacyTierRowCollectionSelector() + " input.validateRange").attr('oldtitle', null);
				bindDirty();
			});
		}
	},
	bindHelpTextHover: function () {
		rm.qtip.showInfo("#infoNumberOfSites", "Sourced from PPM for countries where non-zero, otherwise initially from budget on Project Award.<br/>Ensure that Total Projected Initiated sites does not exceed Total Budgeted Sites.<br/>If an excess is seen (and is required), consider creating a Change Order (CO).");
		rm.qtip.showInfo("#infoFsi", "To edit this value, navigate to, and edit PPM Project Schedule > First Subject Randomized, and then Publish the PPM Project");
		rm.qtip.showInfo("#infoLsi", "To edit this value, navigate to, and edit PPM Project Schedule > Last Subject Randomized, and then Publish the PPM Project");
		rm.qtip.showInfo("#infoLso", "To edit this value, navigate to, and edit PPM Project Schedule > Last Subject Out (LPLV), and then Publish the PPM Project");
		rm.qtip.showInfo("#infoCov", "To edit this value, navigate to, and edit PPM Project Schedule > Last Site Closed, and then Publish the PPM Project");
		rm.qtip.showInfo("#infoSivFsi", "To edit this value, navigate to, and edit RM > Project Summary page > SIV-FSI (weeks) field");
		rm.qtip.showInfo("#infoJapanSivPerSite", "To edit this value, navigate to, and edit RM > Monitoring Attributes > [Japan] > RBM Site Monitoring FTE Calculator > On-site Visit > Visits per site - PIV & SIV field<br/>N/A if Japan is not listed as an Active Country in Monitoring Attributes");
		rm.qtip.showInfo("#infoJapancovPerSite", "To edit this value, navigate to, and edit RM > Monitoring Attributes > [Japan] > RBM Site Monitoring FTE Calculator > On-site Visit > Visits per site - COV field<br/>N/A if Japan is not listed as an Active Country in Monitoring Attributes");

		rm.qtip.showInfo("#infoSmEnabled", "Enable the Tiers that you intend to use.<br/>Note: Once any RBM 'Site' or 'Pharmacy' Monitoring Requests have been Submitted, then the Tiers that they use cannot be disabled.<br/>This will usually affect Tier 4, because, it is used for all Requests autogenerated when a Site is Selected, prior to a RBM Schema being formally defined by the Primary Clinical Lead");
		rm.qtip.showInfo("#infoSmFsiLsiDefautlTier", "Select the default Tier which will be used for 'RBM Site Monitoring' Requests prior to 'Initial Site Tiering' being performed for each Site in the 'Site List' page");
		rm.qtip.showInfo("#infoSmLsiLsoDefaultTier", "Select the default Tier which will be used for 'RBM Site Monitoring' Requests prior to 'Initial Site Tiering' being performed for each Site in the 'Site List' page");
		rm.qtip.showInfo("#infoSmLsoCovDefaultTier", "Select the default Tier which will be used for 'RBM Site Monitoring' Requests prior to 'Initial Site Tiering' being performed for each Site in the 'Site List' page");
		rm.qtip.showInfo("#infoSmTierCycle", "The duration, in weeks, of the repeating pattern of alternating On-Site and Remote Visits.<br/>After making changes, select Save to see a visualization of the Visit Pattern below.");
		rm.qtip.showInfo("#infoSmOnsiteVisitRatio", "The number of On-Site Visits within each repeating Tier Cycle.<br/>Enter 0-52.<br/>QRPM:RM always projects an On-Site Visit on the first day of each Frequency in the Requests.<br/>After making changes, select Save to see a visualization of the Visit Pattern below.");
		rm.qtip.showInfo("#infoSmRemoteVisitRatio", "The number of Remote Visits within each repeating Tier Cycle.<br/>Enter 0-52. Enter zero if no Remote Visits are planned.<br/>After making changes, select Save to see a visualization of the Visit Pattern below.");
		rm.qtip.showInfo("#infoSmContactFrequency", "The average interval between visits to a Site using this Tier (whether On-Site or Remote)");
		rm.qtip.showInfo("#infoSmProjectedNumberOfSite", "Number of Sites in this Tier");
		rm.qtip.showInfo("#infoSmOnsiteFrequency", "On-Site Visit Frequency in weeks, derived from 'Tier Cycle (weeks)' repeat cycle, and the OS:RV ratio");
		rm.qtip.showInfo("#infoSmRemoteFrequency", "Remote Visit Frequency in weeks, derived from 'Tier Cycle (weeks)' repeat cycle, and the OS:RV ratio");
		rm.qtip.showInfo("#infoSmProjectedSivCovVisitCount", "SIV + COV Visit numbers are computed in this column using a simple algorithm based on the number of projected sites.");
		rm.qtip.showInfo("#infoSmProjectedOnsiteImvVisitCount", "On-Site IMV Visit numbers are computed in this column using a simple algorithm based on the entered visit frequencies, and the project's overall \"First Subject Randomized-Last Site Closed Duration (weeks)\" monitoring period (shown top right.)<br/>This will be inaccurate for projects which span multiple countries with different monitoring start dates.<br/>For more accurate visit count projections for such projects, see the Monitoring Attributes page - which projects visits separately for each country.");
		rm.qtip.showInfo("#infoSmProjectedRemoteVisitCount", "Remote Visit numbers are computed in this column using a simple algorithm based on the entered visit frequencies, and the project's overall \"First Subject Randomized-Last Site Closed Duration (weeks)\" monitoring period (shown top right.)<br/>This will be inaccurate for projects which span multiple countries with different monitoring start dates.<br/>For more accurate visit count projections for such projects, see the Monitoring Attributes page - which projects visits separately for each country.");
		rm.qtip.showInfo("#infoSmProjectedTotalVisitCount", "Total Visit numbers are computed in this column using a simple algorithm based on the entered visit frequencies, and the project's overall \"First Subject Randomized-Last Site Closed Duration (weeks)\" monitoring period (shown top right.)<br/>This will be inaccurate for projects which span multiple countries with different monitoring start dates.<br/>For more accurate visit count projections for such projects, see the Monitoring Attributes page - which projects visits separately for each country.");
		rm.qtip.showInfo("#infoSmFsiLsiActualSiteCount", "Number of Sites for PPM-Active countries having FSI-LSI set to this Tier");
		rm.qtip.showInfo("#infoSmFsiLsiActualSitePct", "% of Sites for PPM-Active countries having FSI-LSI set to this Tier");
		rm.qtip.showInfo("#infoSmLsiLsoActualSiteCount", "Number of Sites for PPM-Active countries having LSI-LSO set to this Tier");
		rm.qtip.showInfo("#infoSmLsiLsoActualSitePct", "% of Sites for PPM-Active countries having LSI-LSO set to this Tier");
		rm.qtip.showInfo("#infoSmLsoCovActualSiteCount", "Number of Sites for PPM-Active countries having LSO-COV set to this Tier");
		rm.qtip.showInfo("#infoSmLsoCovActualSitePct", "% of Sites for PPM-Active countries having LSO-COV set to this Tier");


		rm.qtip.showInfo("#infoPmEnabled", "Enable the Tiers that you intend to use.<br/>Note: Once any RBM 'Site' or 'Pharmacy' Monitoring Requests have been Submitted, then the Tiers that they use cannot be disabled.<br/>This will usually affect Tier 4, because, it is used for all Requests autogenerated when a Site is Selected, prior to a RBM Schema being formally defined by the Primary Clinical Lead");
		rm.qtip.showInfo("#infoPmPharmacyDefaultTier", "Select the default Tier which will be used for 'RBM Pharmacy Monitoring' Requests prior to 'Initial Site Tiering' being performed for each Site in the 'Site List' page");
		rm.qtip.showInfo("#infoPmOnsiteVisitFrequency", "Enter the planned Pharmacy OS Visit Frequency in weeks");
		rm.qtip.showInfo("#infoPmProjectedSiteCount", "Number of Sites in this Tier");
		rm.qtip.showInfo("#infoPmSivCovVisitCount", "Number of projected SIV + COV Visits for Pharmacy sites");
		rm.qtip.showInfo("#infoPmProjectedVisitCount", "Number of projected On-Site Visits in the entire Pharmacy period");
		rm.qtip.showInfo("#infoPmActualSiteCount", "Number of Sites for PPM-Active countries having Pharmacy set to this Tier");
		rm.qtip.showInfo("#infoPmActualSitePct", "% of Sites for PPM-Active countries having Pharmacy set to this Tier");

		rm.qtip.showInfo("[id$=_uploadStafExcel]", "Click to upload a STAF Tool Excel spreadsheet. Only the latest uploaded copy will be retained.");
		rm.qtip.showInfo("[id$=_downloadStafExcel]", "Click to download the latest-uploaded STAF Tool Excel spreadsheet.");

		dteSchemaNs.showTargetSitePercentageDefault();
	},
	isPharmacySchemaEnabled: function () { return $(projConfig.isPharmacyEnabledSelector).is(":checked"); },
	getSiteMonitoringOnsiteVisitBuffer: function () { return $(projConfig.getSiteMonitoringBufferSelector()).val(); },
	getPharmacyOnsiteVisitBuffer: function () { return dteSchemaNs.isPharmacySchemaEnabled() ? $(projConfig.getPharmacyBufferSelector()).val() : null; },
	getPostData: function () {
		var postData = {
			projectSchemaDetails: {
				SiteMonitoringSchemaDetails: {
					TierList: new Array(),
					Budget: {
						OnsiteVisitBuffer: dteSchemaNs.getSiteMonitoringOnsiteVisitBuffer()
					}
				},
				PharmacySchemaDetails: {
					TierList: new Array(),
					Budget: {
						RemoteVisitCount: 0,
						OnsiteVisitBuffer: dteSchemaNs.getPharmacyOnsiteVisitBuffer()
					}
				},
				IsPharmacyEnabled: dteSchemaNs.isPharmacySchemaEnabled(),
				ProjectId: projConfig.getProjectId(),
				ChangeReason: $.trim($(projConfig.txtReasonForSchemaChangeSelector).val())
			}
		};

		$(projConfig.getSiteMonitoringTierRowCollectionSelector()).each(function (index, row) {
			var tierRow = $(row);
			if (tierRow.find(projConfig.cbTierEnabledSelector).is(":checked")) {
				postData.projectSchemaDetails.SiteMonitoringSchemaDetails.TierList.push({
					TierName: tierRow.find(projConfig.tierNameSelector).text(),
					IsFsiLsiDefaultTier: tierRow.find(projConfig.rbFsiLsiDefaultTierSelector).is(":checked"),
					IsLsiLsoDefaultTier: tierRow.find(projConfig.rbLsiLsoDefaultTierSelector).is(":checked"),
					IsLsoCovDefaultTier: tierRow.find(projConfig.rbLsoCovDefaultTierSelector).is(":checked"),
					TargetSitePercentage: tierRow.find(projConfig.targetSitePercentageSelector).val(),
					TierCycle: tierRow.find(projConfig.tierCycleSelector).val(),
					OnSiteVisitRatio: tierRow.find(projConfig.onSiteVisitRatioSelector).val(),
					RemoteVisitRatio: tierRow.find(projConfig.remoteVisitRatioSelector).val(),
					CalculatorGroup: CalculatorGroup_E.DTEMonitoringCalculator,
					ProjectId: projConfig.getProjectId(),
					IsTierEnabled: true,
					IsPharmacy: false
				});
			}
		});

		if (dteSchemaNs.isPharmacySchemaEnabled()) {
			$(projConfig.getPharmacyTierRowCollectionSelector()).each(function (index, row) {
				var tierRow = $(row);
				if (tierRow.find(projConfig.cbTierEnabledSelector).is(":checked")) {
					var tierCycle = tierRow.find(projConfig.tierCycleSelector).val();
					postData.projectSchemaDetails.PharmacySchemaDetails.TierList.push({
						TierName: tierRow.find(projConfig.tierNameSelector).text(),
						IsPharmacyDefaultTier: tierRow.find(projConfig.rbPharmacyDefaultTierSelector).is(":checked"),
						TargetSitePercentage: tierRow.find(projConfig.targetSitePercentageSelector).val(),
						TierCycle: tierCycle,
						OnSiteVisitRatio: dteSchemaNs.getOnsiteVisitRatio(true, tierCycle, 1),
						RemoteVisitRatio: 0,
						CalculatorGroup: CalculatorGroup_E.DTEPharmacyCalculator,
						ProjectId: projConfig.getProjectId(),
						IsTierEnabled: true,
						IsPharmacy: true
					});
				}
			});
		}

		return postData;
	},
	showVisitPatternGraphData: function (projectId) {
		rm.ajax.projectSvcSyncGet("GetVisitPatternGraphData", { projectId: projectId }, function (data) { $('[id$=staticGraphData]').html(data.Body); });
	},
	bindEventHandlers: function () {
		$(projConfig.isPharmacyEnabledSelector).click(dteSchemaNs.enableDisablePharmacySchema);
		$(projConfig.txtRvOsRatioSelector).bind("blur change", dteSchemaNs.handleRvOsRatioChange);
	},
	handleRvOsRatioChange: function (eventArgs) {
		if ($(this).val() !== "" && rm.validation.range.validate($(this))) {
			var remoteToOnsiteRatio = parseFloat($(projConfig.txtRvOsRatioSelector).val());
			var totalRemoteVisits = parseInt($("td[placeholderkey=TotalOnsiteRemoteVisitCount]").text());
			var rvAsOsEquivalent = Math.round(totalRemoteVisits / remoteToOnsiteRatio);

			var totalOnsiteVisitBudgetText = $(projConfig.getSiteMonitoringBudgetedOnsiteImvVisitCountSelector()).text();

			$(projConfig.divRvAsOsEquivalentSelector).text(rvAsOsEquivalent);
			if ($.isNumeric(totalOnsiteVisitBudgetText)) {
				$(projConfig.divRevisedOsTargetSelector).text(parseInt(totalOnsiteVisitBudgetText) - rvAsOsEquivalent);
			}
			else { $(projConfig.divRevisedOsTargetSelector).text(""); }
		}
		else {
			$(projConfig.divRvAsOsEquivalentSelector).text("");
			$(projConfig.divRevisedOsTargetSelector).text("");
		}
	},
	getOnsiteVisitRatio: function (isPharmacySchema, tierCycle, onsiteVisitRatio) {
		if (isPharmacySchema) { return (tierCycle == 0) ? 0 : onsiteVisitRatio; }
		else { return onsiteVisitRatio; }
	},
	updateVisitCount: function (eventArgs) {
		var tierRow = $(eventArgs.target).closest("tr");
		var schemaTable = tierRow.closest("table");
		var isPharmacySchema = schemaTable.attr("isPharmacySchema") === "1";


		var validValuesEntered = rm.validation.range.validate(tierRow.find(projConfig.tierCycleSelector)) &&
			rm.validation.range.validate(tierRow.find(projConfig.targetSitePercentageSelector));
		if (!isPharmacySchema) {
			validValuesEntered = validValuesEntered &&
				rm.validation.range.validate(tierRow.find(projConfig.onSiteVisitRatioSelector)) &&
				rm.validation.range.validate(tierRow.find(projConfig.remoteVisitRatioSelector));
		}
		var tierCycle = tierRow.find(projConfig.tierCycleSelector).val();
		var tempOnsiteVisitRatio = isPharmacySchema ? 1 : tierRow.find(projConfig.onSiteVisitRatioSelector).val();
		var onsiteVisitRatio = dteSchemaNs.getOnsiteVisitRatio(isPharmacySchema, tierCycle, tempOnsiteVisitRatio);
		var remoteVisitRatio = isPharmacySchema ? 0 : tierRow.find(projConfig.remoteVisitRatioSelector).val();
		var targetSitePercentage = tierRow.find(projConfig.targetSitePercentageSelector).val();

		if (validValuesEntered && tierCycle >= 0 && onsiteVisitRatio >= 0 && remoteVisitRatio >= 0 && targetSitePercentage >= 0) {
			var postData = {
				projectId: projConfig.globalValues.projectId,
				tierCycle: tierCycle,
				onsiteVisitRatio: onsiteVisitRatio,
				remoteVisitRatio: remoteVisitRatio,
				targetSitePercentage: targetSitePercentage,
				isPharmacy: isPharmacySchema
			}
			rm.ajax.projectSvcAsyncPost("GetDteSiteVisitCount", postData, function (serviceResponse) {
				if (serviceResponse.IsSuccessful) {
					tierRow.find(projConfig.sivCovVisitCountSelector).text(Math.round(serviceResponse.AdditionalData.SivVisitCount + serviceResponse.AdditionalData.CovVisitCount));
					tierRow.find(projConfig.onsiteVisitCountSelector).text(Math.round(serviceResponse.AdditionalData.OnsiteImvVisitCount));
					tierRow.find(projConfig.remoteVisitCountSelector).text(Math.round(serviceResponse.AdditionalData.RemoteVisitCount));
					tierRow.find(projConfig.totalVisitCountSelector).text(Math.round((serviceResponse.AdditionalData.OnsiteImvVisitCount + serviceResponse.AdditionalData.RemoteVisitCount)));
					setTimeout(function () { dteSchemaNs.updateTableTotals("#" + schemaTable.attr("id")); }, 20);
				} else {
					rm.ui.dialog.showServiceErrorModal("Service Error", serviceResponse.Message);
				}
			});
		}
	},
	updateOnsiteFrequency: function (eventArgs) {
		var tierRow = $(eventArgs.target).closest("tr");
		var tierCycle = tierRow.find(projConfig.tierCycleSelector).val();
		var onsiteVisitRatio = tierRow.find(projConfig.onSiteVisitRatioSelector).val();

		if ($.isNumeric(tierCycle) && $.isNumeric(onsiteVisitRatio) && parseInt(onsiteVisitRatio) > 0) {
			tierRow.find(projConfig.onsiteVisitFrequencySelector).text((parseInt(tierCycle) / parseInt(onsiteVisitRatio)).toFixed(2) / 1);
		} else {
			tierRow.find(projConfig.onsiteVisitFrequencySelector).text("");
		}
	},
	updateRemoteFrequency: function (eventArgs) {
		var tierRow = $(eventArgs.target).closest("tr");
		var tierCycle = tierRow.find(projConfig.tierCycleSelector).val();
		var remoteVisitRatio = tierRow.find(projConfig.remoteVisitRatioSelector).val();

		if ($.isNumeric(tierCycle) && $.isNumeric(remoteVisitRatio) && parseInt(remoteVisitRatio) > 0) {
			tierRow.find(projConfig.removeVisitFrequencySelector).text((parseInt(tierCycle) / parseInt(remoteVisitRatio)).toFixed(2) / 1);
		} else {
			tierRow.find(projConfig.removeVisitFrequencySelector).text("");
		}
	},
	updateContactFrequency: function (eventArgs) {
		var tierRow = $(eventArgs.target).closest("tr");
		var tierCycle = tierRow.find(projConfig.tierCycleSelector).val();
		var onsiteVisitRatio = tierRow.find(projConfig.onSiteVisitRatioSelector).val();
		var remoteVisitRatio = tierRow.find(projConfig.remoteVisitRatioSelector).val();

		if ($.isNumeric(tierCycle) && $.isNumeric(remoteVisitRatio) && $.isNumeric(onsiteVisitRatio)
			&& tierCycle > 0 && onsiteVisitRatio > 0 && remoteVisitRatio >= 0
			&& (parseInt(onsiteVisitRatio) + parseInt(remoteVisitRatio)) > 0) {
			tierRow.find(projConfig.contactFrequencyWeeksSelector).text((parseInt(tierCycle) / (parseInt(onsiteVisitRatio) + parseInt(remoteVisitRatio))).toFixed(2) / 1);
		}
	},
	calculateAndShowProjectedNumberOfSites: function (sourceTierRow) {
		projectedNumberOfSites = dteSchemaNs.calculateProjectedSiteCount(sourceTierRow.find(projConfig.targetSitePercentageSelector).val(), dteSchemaNs.getPpmProjectedInitiatedSite());
		if ($.isNumeric(projectedNumberOfSites) && projectedNumberOfSites >= 0) {
			sourceTierRow.find(projConfig.projectedNumberOfSitesSelector).attr("rawValue", projectedNumberOfSites).text(projectedNumberOfSites.toFixed(0));
		} else { sourceTierRow.find(projConfig.projectedNumberOfSitesSelector).text("").attr("rawValue", ""); }
	},
	updateTableTotals: function (targetTableSelector) {
		var numberOfSigmaGroups = 18;
		for (var groupIndex = 0; groupIndex < numberOfSigmaGroups; groupIndex++) {
			var sigmaColumnSelector = targetTableSelector + " [sigmacolumn=1][sigmagroup=" + groupIndex + "]";
			var sigmaAnswerColumnSelector = targetTableSelector + " [sigmaAnswercolumn=1][sigmagroup=" + groupIndex + "]";
			var columnTotal = 0;
			var nonNumericValueFound = false;

			$(sigmaColumnSelector).each(function (index, column) {
				var columnObj = $(column);
				var valueForSigma = "";
				if (columnObj.attr("includeDisabledTier") === "1" || columnObj.parent().find(projConfig.cbTierEnabledSelector).is(":checked")) {
					var rawValue = columnObj.attr("rawValue");
					if (rawValue == null || rawValue === "") { rawValue = columnObj.text(); }
					var textBox = columnObj.find("input[type=text]");

					if (textBox.length > 0) { valueForSigma = textBox.val(); }
					else { valueForSigma = rawValue; }

					if (valueForSigma !== "") {
						if ($.isNumeric(valueForSigma)) {
							columnTotal += parseFloat(valueForSigma);
						} else {
							nonNumericValueFound = true;
						}
					}
				}
			});

			if (nonNumericValueFound) {
				$(sigmaAnswerColumnSelector).text("");
			}
			else {
				var isDecimal = $(sigmaAnswerColumnSelector).attr("isDecimal") === "1";
				var digitsAfterDecinmal = isDecimal ? $(sigmaAnswerColumnSelector).attr("digitsAfterDecinmal") : 0;
				$(sigmaAnswerColumnSelector).text(columnTotal.toFixed(digitsAfterDecinmal));
			}
		}

		setTimeout(dteSchemaNs.calculateBufferVisitsCount, 10);
	},
	validateOnsiteAndRemoteVisitRatio: function (eventArgs) {
		var isValid = true;
		var errorMessage = "";
		var tierRow = $(eventArgs.target).closest("tr");
		var onsiteVisitRatioControl = tierRow.find(projConfig.onSiteVisitRatioSelector);
		var remoteVisitRatioControl = tierRow.find(projConfig.remoteVisitRatioSelector);

		if (rm.validation.range.validate(onsiteVisitRatioControl) && rm.validation.range.validate(remoteVisitRatioControl)) {
			var onsiteVisitRatio = onsiteVisitRatioControl.val();
			var remoteVisitRatio = remoteVisitRatioControl.val();
			if (!projConfig.isTierWithZeroVisitsAllowed() && onsiteVisitRatio == 0 && remoteVisitRatio == 0) {
				rm.validation.addError(onsiteVisitRatioControl, Resources.ZeroOnsiteVisitRatioErrorOnCell);
				rm.validation.addError(remoteVisitRatioControl, Resources.ZeroRemoteVisitRatioErrorOnCell);
				isValid = false;
				errorMessage = Resources.ZeroOnsiteAndRemoteVisitRatioValidateOnSaveError;
			}
			else if (remoteVisitRatio == 0 && onsiteVisitRatio > 1) {
				rm.validation.addError(onsiteVisitRatioControl, Resources.OnsiteVisitRatioErrorOnCell.replace("{0}", onsiteVisitRatioControl.attr("from")));
				rm.validation.addError(remoteVisitRatioControl, Resources.RemoteVisitRatioErrorOnCell);
				isValid = false;
				errorMessage = Resources.VisitRatioValidateOnSaveError;
			}
			else {
				rm.validation.clearError(remoteVisitRatioControl);
				if (onsiteVisitRatio != 0) { rm.validation.clearError(onsiteVisitRatioControl); }
			}
		}

		return {
			isValid: isValid,
			errorMessage: errorMessage
		};
	},
	modifySchema: function () {
		rm.ui.messages.clearAllMessages();
		rm.ui.messages.showSuccess('You may wish to experiment with alternative Schema configurations using the <a href="/_Layouts/SPUI/Sandbox/DteSchemaSimulator.aspx">RBM Schema Simulator</a> page');
		rm.ui.tabs.activateByIndex("#tabs", 3);
		var checkboxes = $(projConfig.getSiteMonitoringTierRowCollectionSelector()).find("[allowuncheck=true]");
		checkboxes.prop("disabled", false);
		rm.qtip.showInfo(checkboxes.parent(), Resources.TooltipforEnabledSchema);

		checkboxes = $(projConfig.getSiteMonitoringTierRowCollectionSelector()).find("[allowuncheck=false]");
		rm.qtip.showInfo(checkboxes.parent(), Resources.TooltipforDisabledSchema);

		$(projConfig.getSiteMonitoringTierRowCollectionSelector()).find(projConfig.cbTierEnabledSelector + ":checked").closest("tr").find('input[type=text],input[type=radio]').prop("disabled", false);

		checkboxes = $(projConfig.getPharmacyTierRowCollectionSelector()).find("[allowuncheck=true]");
		checkboxes.prop("disabled", false);
		rm.qtip.showInfo(checkboxes.parent(), Resources.TooltipforEnabledSchema);

		checkboxes = $(projConfig.getPharmacyTierRowCollectionSelector()).find("[allowuncheck=false]");
		rm.qtip.showInfo(checkboxes.parent(), Resources.TooltipforDisabledSchema);

		$(projConfig.getPharmacyTierRowCollectionSelector()).find(projConfig.cbTierEnabledSelector + ":checked").closest("tr").find("input[type=text],input[type=radio]").prop("disabled", false);
		$(".budgetRow input[type=text]:visible").prop("disabled", false);
		$(".bufferRow input[type=text]:visible").prop("disabled", false);

		var enableDiablePharmacyCb = $(projConfig.isPharmacyEnabledSelector);
		//If pharmacy schema is not enabled (i.e. enableDiablePharmacyCb is unchecked) and 
		//if allowUncheck is not allowed then we should allow user to check the box and once checked, user should not be able to uncheck it.
		if (!enableDiablePharmacyCb.is(":checked") && enableDiablePharmacyCb.attr("allowUncheck") == "false") {
			enableDiablePharmacyCb.prop("disabled", false);
			enableDiablePharmacyCb.click(function () {
				enableDiablePharmacyCb.prop("disabled", true);
				rm.qtip.showInfo(enableDiablePharmacyCb.parent(), Resources.DisablingPharmacySchemaNotAllowed);
			});
		}
		else if (enableDiablePharmacyCb.attr("allowUncheck") == "true") {
			enableDiablePharmacyCb.prop("disabled", false);
			rm.qtip.showInfo(enableDiablePharmacyCb.parent(), Resources.DisablingPharmacySchemaAllowed);
		}
		else {
			enableDiablePharmacyCb.prop("disabled", true);
			rm.qtip.showInfo(enableDiablePharmacyCb.parent(), Resources.DisablingPharmacySchemaNotAllowed);
		}

		rm.ui.ribbon.delayedRefresh();
	},
	enableDisablePharmacySchema: function () {
		if ($(this).is(":checked")) {
			$(projConfig.getPharmacyTierRowCollectionSelector()).find('input[type=checkbox]').prop("disabled", false);
			$(projConfig.getPharmacyBufferSelector()).prop("disabled", false);

		}
		else {
			$(projConfig.getPharmacyTierRowCollectionSelector()).find('input').prop("disabled", true).prop("checked", false).val("");
			$(projConfig.getTotalPharmacyTargetSitePctSelector()).text("");
			$(projConfig.pharmacyTargetNumberOfBufferVisitsSelector).text("");
			$(projConfig.pharmacyActualBufferSelector).text("");
			$(projConfig.getPharmacyBufferSelector()).val("");
			rm.validation.clearError(projConfig.getPharmacyBufferSelector());
		}
		dteSchemaNs.handlePharmacySchemaVisibility();
	},
	enableDisableTierRow: function (checkBox, sourcTableSelector) {
		var jqCheckBox = $(checkBox);
		if (jqCheckBox.is(":checked")) {
			jqCheckBox.closest("tr").find('input[disabled]').prop("disabled", false);
		}
		else {
			rm.validation.clearError(jqCheckBox.closest("tr").find('input[type=text], input[type=radio]').prop("disabled", true).prop("checked", false).val(""));
			jqCheckBox.closest("tr").find(projConfig.clearForDisabledTiersSelector).text("").removeAttr("rawValue");
		}
		setTimeout(function () { dteSchemaNs.updateTableTotals(sourcTableSelector); }, 20);
	},
	getSiteMonitoringBudgetRow: function () { return $(projConfig.siteMonitoringBudgetRowTemplateSelector).clone(); },
	getSiteMonitoringSchemaFooterRow: function () {
		return $(projConfig.siteMonitoringTotalRowTemplateSelector).clone();
	},
	calculateProjectedSiteCount: function (targetSitePercent, ppmProjectedInitiatedSiteCount) { return ppmProjectedInitiatedSiteCount * targetSitePercent / 100; },
	handleSiteMonitoringResponse: function (siteMonitoringConfiguration) {
		if (siteMonitoringConfiguration.TierList.length > 0) {
			$.each(siteMonitoringConfiguration.TierList, function (index, tierRow) {
				dteSchemaNs.addOnsiteTierRowToSchemaTable(tierRow)
			});

			$(projConfig.siteMonitoringTableSelector).append(dteSchemaNs.getSiteMonitoringSchemaFooterRow());
			$(projConfig.siteMonitoringTableSelector).append(dteSchemaNs.getSiteMonitoringBudgetRow());

			setTimeout(function () {
				$(projConfig.getSiteMonitoringBudgetedSivCovVisitCountSelector()).text(siteMonitoringConfiguration.Budget.SivVisitCount + siteMonitoringConfiguration.Budget.CovVisitCount);
				$(projConfig.getSiteMonitoringBudgetedOnsiteImvVisitCountSelector()).text(siteMonitoringConfiguration.Budget.OnsiteImvVisitCount);
				$(projConfig.getSiteMonitoringBudgetedRemoteVisitCountSelector()).text(siteMonitoringConfiguration.Budget.RemoteVisitCount);
				$(projConfig.getSiteMonitoringBufferSelector()).val(siteMonitoringConfiguration.Budget.OnsiteVisitBuffer);
			}, 10);
		}
		else {
			$("#DteVisitSchemaLevel").text('No results to display.');
			$(projConfig.siteMonitoringTableSelector).parent().hide();
		}
	},
	addOnsiteTierRowToSchemaTable: function (tierRow) {
		var newRow = $(projConfig.siteMonitoringTierRowTemplateSelector).clone();

		if (tierRow.IsTierEnabled) {
			var projectedNumberOfSites = dteSchemaNs.calculateProjectedSiteCount(tierRow.TargetSitePercentage, dteSchemaNs.getPpmProjectedInitiatedSite());
			newRow.find(projConfig.projectedNumberOfSitesSelector).text(projectedNumberOfSites.toFixed(0)).attr("rawValue", projectedNumberOfSites);
			newRow.find(projConfig.onsiteVisitFrequencySelector).text((tierRow.OnSiteVisitRatio === 0) ? "" : (tierRow.TierCycle / tierRow.OnSiteVisitRatio).toFixed(2) / 1);
			newRow.find(projConfig.removeVisitFrequencySelector).text((tierRow.RemoteVisitRatio === 0) ? "" : (tierRow.TierCycle / tierRow.RemoteVisitRatio).toFixed(2) / 1);
			newRow.find(projConfig.sivCovVisitCountSelector).text(tierRow.SivVisitCount + tierRow.CovVisitCount);
			newRow.find(projConfig.onsiteVisitCountSelector).text(tierRow.OnsiteImvVisitCount);
			newRow.find(projConfig.remoteVisitCountSelector).text(tierRow.RemoteVisitCount);
			newRow.find(projConfig.totalVisitCountSelector).text(tierRow.SivVisitCount + tierRow.CovVisitCount + tierRow.OnsiteImvVisitCount + tierRow.RemoteVisitCount);
		}

		newRow.find(projConfig.tierNameSelector).text(tierRow.TierName);
		newRow.find(projConfig.rbFsiLsiDefaultTierSelector).prop("checked", tierRow.IsFsiLsiDefaultTier);
		newRow.find(projConfig.rbLsiLsoDefaultTierSelector).prop("checked", tierRow.IsLsiLsoDefaultTier);
		newRow.find(projConfig.rbLsoCovDefaultTierSelector).prop("checked", tierRow.IsLsoCovDefaultTier);
		newRow.find(projConfig.fsiLsiSiteCountSelector).text(tierRow.FsiLsiSiteCount);
		newRow.find(projConfig.fsiLsiSitePctSelector).text(tierRow.FsiLsiSitePct.toFixed(2));
		newRow.find(projConfig.lsiLsoSiteCountSelector).text(tierRow.LsiLsoSiteCount);
		newRow.find(projConfig.lsiLsoSitePctSelector).text(tierRow.LsiLsoSitePct.toFixed(2));
		newRow.find(projConfig.lsoCovSiteCountSelector).text(tierRow.LsoCovSiteCount);
		newRow.find(projConfig.lsoCovSitePctSelector).text(tierRow.LsoCovSitePct.toFixed(2));
		newRow.find(projConfig.pastActualOsVisitCountSelector).text(tierRow.PastActualOsVisitCount);
		newRow.find(projConfig.plannedActualOsVisitCountSelector).text(tierRow.PlannedActualOsVisitCount);
		newRow.find(projConfig.totalActualOsVisitCountSelector).text(tierRow.PastActualOsVisitCount + tierRow.PlannedActualOsVisitCount);
		newRow.find(projConfig.pastActualRvVisitCountSelector).text(tierRow.PastActualRvVisitCount);
		newRow.find(projConfig.plannedActualRvVisitCountSelector).text(tierRow.PlannedActualRvVisitCount);
		newRow.find(projConfig.totalActualRvVisitCountSelector).text(tierRow.PastActualRvVisitCount + tierRow.PlannedActualRvVisitCount);

		newRow.find(projConfig.cbTierEnabledSelector).prop("checked", tierRow.IsTierInUse || tierRow.IsTierEnabled).attr("allowUncheck", !tierRow.IsTierInUse).click(function () {
			dteSchemaNs.enableDisableTierRow(this, projConfig.siteMonitoringTableSelector);
		});

		newRow.find(projConfig.targetSitePercentageSelector).val(tierRow.TargetSitePercentage).bind("keyup keydown paste cut drop", function () {
			dteSchemaNs.calculateAndShowProjectedNumberOfSites($(this).closest("tr"));
			setTimeout(function () { dteSchemaNs.updateTableTotals(projConfig.siteMonitoringTableSelector); }, 20);
		});

		newRow.find(projConfig.tierCycleSelector).val(tierRow.TierCycle).bind("blur change", function (eventArgs) {
			dteSchemaNs.updateContactFrequency(eventArgs);
			dteSchemaNs.updateOnsiteFrequency(eventArgs);
			dteSchemaNs.updateRemoteFrequency(eventArgs);
		});

		newRow.find(projConfig.onSiteVisitRatioSelector).val(tierRow.OnSiteVisitRatio).bind("blur change", function (eventArgs) {
			dteSchemaNs.updateContactFrequency(eventArgs);
			dteSchemaNs.updateOnsiteFrequency(eventArgs);
			dteSchemaNs.validateOnsiteAndRemoteVisitRatio(eventArgs);
		});

		newRow.find(projConfig.remoteVisitRatioSelector).val(tierRow.RemoteVisitRatio).bind("blur change", function (eventArgs) {
			dteSchemaNs.updateContactFrequency(eventArgs);
			dteSchemaNs.updateRemoteFrequency(eventArgs);
			dteSchemaNs.validateOnsiteAndRemoteVisitRatio(eventArgs);
		});

		newRow.find("input[type=text]").bind("change", dteSchemaNs.updateVisitCount);
		if (tierRow.ContactFrequencyWeeks != null) { newRow.find(projConfig.contactFrequencyWeeksSelector).text(tierRow.ContactFrequencyWeeks.toFixed(2) / 1); }

		$(projConfig.siteMonitoringTableSelector).append(newRow);
	},
	handlePharmacyResponse: function (pharmacyConfiguration) {
		var atLeastOnePharmacyTierActive = false;
		if (pharmacyConfiguration.TierList.length > 0) {
			$.each(pharmacyConfiguration.TierList, function (index, tierRow) {
				dteSchemaNs.addPharmacyTierRowToSchemaTable(tierRow);
				if (tierRow.IsTierEnabled) { atLeastOnePharmacyTierActive = true; }
			});
			$(projConfig.pharmacyTableSelector).append(dteSchemaNs.getPharmacyMonitoringSchemaFooterRow());
			$(projConfig.pharmacyTableSelector).append(dteSchemaNs.getPharmacyMonitoringBudgetRow());

			$(projConfig.isPharmacyEnabledSelector).prop("checked", atLeastOnePharmacyTierActive);

			setTimeout(function () {
				$(projConfig.getPharmacyBudgetedSivCovVisitCountSelector()).text(pharmacyConfiguration.Budget.SivVisitCount + pharmacyConfiguration.Budget.CovVisitCount);
				$(projConfig.getPharmacyBudgetedOnsiteImvVisitCountSelector()).text(pharmacyConfiguration.Budget.OnsiteImvVisitCount);
				$(projConfig.getPharmacyBufferSelector()).val(pharmacyConfiguration.Budget.OnsiteVisitBuffer);
			}, 10);
			setTimeout(dteSchemaNs.handlePharmacySchemaVisibility, 10);

		} else {
			$("#DteVisitSchemaLevel").text('No results to display.');
			$(projConfig.pharmacyTableSelector).parent().hide();
		}
	},
	addPharmacyTierRowToSchemaTable: function (tierRow) {
		var newRow = $(projConfig.pharmacyTierRowTemplateSelector).clone();
		if (tierRow.IsTierEnabled) {
			var projectedNumberOfSites = dteSchemaNs.calculateProjectedSiteCount(tierRow.TargetSitePercentage, dteSchemaNs.getPpmProjectedInitiatedSite());
			newRow.find(projConfig.projectedNumberOfSitesSelector).text(projectedNumberOfSites.toFixed(0)).attr("rawValue", projectedNumberOfSites);
			newRow.find(projConfig.onsiteVisitCountSelector).text(tierRow.OnsiteImvVisitCount);
			newRow.find(projConfig.sivCovVisitCountSelector).text(tierRow.SivVisitCount + tierRow.CovVisitCount);
		}
		newRow.find(projConfig.tierNameSelector).text(tierRow.TierName);
		newRow.find(projConfig.rbPharmacyDefaultTierSelector).prop("checked", tierRow.IsPharmacyDefaultTier);
		newRow.find(projConfig.PharmacySiteCountSelector).text(tierRow.PharmacySiteCount);
		newRow.find(projConfig.PharmacySitePctSelector).text(tierRow.PharmacySitePct.toFixed(2));
		newRow.find(projConfig.tierCycleSelector).val(tierRow.TierCycle);
		newRow.find(projConfig.pastActualOsVisitCountSelector).text(tierRow.PastActualOsVisitCount);
		newRow.find(projConfig.plannedActualOsVisitCountSelector).text(tierRow.PlannedActualOsVisitCount);
		newRow.find(projConfig.totalActualOsVisitCountSelector).text(tierRow.PastActualOsVisitCount + tierRow.PlannedActualOsVisitCount);

		newRow.find(projConfig.cbTierEnabledSelector).prop("checked", tierRow.IsTierInUse || tierRow.IsTierEnabled).attr("allowUncheck", !tierRow.IsTierInUse).click(function () {
			dteSchemaNs.enableDisableTierRow(this, projConfig.pharmacyTableSelector);
		});

		newRow.find(projConfig.targetSitePercentageSelector).val(tierRow.TargetSitePercentage).bind("keyup paste cut drop", function () {
			dteSchemaNs.calculateAndShowProjectedNumberOfSites($(this).closest("tr"));
			setTimeout(function () { dteSchemaNs.updateTableTotals(projConfig.pharmacyTableSelector); }, 20);
		});

		if (tierRow.IsPharmacyDefaultTier) {
			$(projConfig.isPharmacyEnabledSelector).prop("checked", true);
		}

		if (tierRow.IsTierInUse) {
			$(projConfig.isPharmacyEnabledSelector).attr("allowUncheck", false);
		}

		newRow.find("input[type=text]").bind("change", dteSchemaNs.updateVisitCount);
		$(projConfig.pharmacyTableSelector).append(newRow);
	},
	getPharmacyMonitoringBudgetRow: function () { return $(projConfig.pharmacyBudgetRowTemplateSelector).clone(); },
	getPharmacyMonitoringSchemaFooterRow: function () {
		return $(projConfig.pharmacyTotalRowTemplateSelector).clone();
	},
	handlePharmacySchemaVisibility: function () {
		var rowSelector = projConfig.pharmacyTableSelector + " tr.pharmacyRow";
		rm.validation.clearError(projConfig.getPharmacyTierRowCollectionSelector() + " input.validateRange");
		if ($(projConfig.isPharmacyEnabledSelector).is(":checked")) {
			$(rowSelector).show();
			$(projConfig.pharmacyBufferTableSelector).show();
		}
		else {
			$(projConfig.pharmacyBufferTableSelector).hide();
			$(rowSelector).hide();
			$(rowSelector).find(projConfig.clearForDisabledTiersSelector).text("").removeAttr("rawValue");
			$(".tierTotalRow.pharmacyRow [sigmaAnswercolumn=1]").text("");
		}
	},
	calculateBufferVisitsCount: function () {
		dteSchemaNs.calculateBufferVisitsCountHelper($(projConfig.getTotalOnsiteOnsiteVisitCountSelector()),
			$(projConfig.getSiteMonitoringBudgetedOnsiteImvVisitCountSelector()),
			$(projConfig.getSiteMonitoringBufferSelector()),
			$(projConfig.getSiteMonitoringTargetNumberOfBufferVisitsSelector()),
			$(projConfig.getSiteMonitoringActualBufferSelector()));

		dteSchemaNs.calculateBufferVisitsCountHelper($(projConfig.getGrandTotalPharmacyVisitCountSelector()),
			$(projConfig.getPharmacyBudgetedOnsiteImvVisitCountSelector()),
			$(projConfig.getPharmacyBufferSelector()),
			$(projConfig.getPharmacyTargetNumberOfBufferVisitsSelector()),
			$(projConfig.getPharmacyActualBufferSelector()));
	},
	calculateBufferVisitsCountHelper: function (projectedTotalVisitsControl, budgetedVisitsControl, bufferControl, bufferVisitCountControl, actualBufferControl) {
		var projectedTotalVisits = projectedTotalVisitsControl.text();
		var budgetedVisits = budgetedVisitsControl.html();
		var buffer = bufferControl.val();

		if ($.isNumeric(budgetedVisits)) {
			if ($.isNumeric(buffer)) {
				bufferVisitCountControl.text(Math.round(parseInt(budgetedVisits) * parseInt(buffer) / 100));
			}
			else { bufferVisitCountControl.text(""); }

			if ($.isNumeric(projectedTotalVisits)) {
				var actualBuffer = parseInt(budgetedVisits) - parseInt(projectedTotalVisits);
				actualBufferControl.text(actualBuffer);
				if (actualBuffer <= 0) { actualBufferControl.addClass("overBudget"); }
				else { actualBufferControl.removeClass("overBudget"); }
			}
			else { actualBufferControl.text(""); }
		} else {
			bufferVisitCountControl.text("");
			actualBufferControl.text("");
		}
	}
};

var rbmCnvNs = {
	_isRbmConversionRunning: false,
	_isRbmConversionAllowed: true,
	rbmConversionSpinnerId: "rbmConversionSpinner",
	btnRbmConversionSelector: "[id*=ConvertNonRBMToRBM]",
	init: function () {
		rbmCnvNs.showNonRbmToRbmConversionWarning();
		rbmCnvNs.addHiddenRefreshSpinner();
		rbmCnvNs.isRbmConversionRunning(true);
		rbmCnvNs.showToolTipOnRbmConversionButton();
	},
	isRbmProjectManagedAsNonRbmInRm: function () { return $("[id$=hdnIsRbmProjectManagedAsNonRbmInRm]").val() === "1"; },
	showNonRbmToRbmConversionWarning: function () {
		if (rbmCnvNs.isRbmProjectManagedAsNonRbmInRm()) { rm.ui.messages.showWarningWithCloseButton(Resources.NonRbmToRbmConversion); }
	},
	addHiddenRefreshSpinner: function () {
		rm.ui.ribbon.addHiddenWaitSpinner("[id*=ConvertNonRBMToRBM]", rbmCnvNs.rbmConversionSpinnerId);
	},
	convertProjectFromNonRbmToRbm: function () {
		rm.ajax.projectSvcAsyncPost("ConvertNonRbmProjectToRbm", { projectId: projConfig.getProjectId() }, function (response) {
			rbmCnvNs._isRBMConversionRunning = true;
			rm.ui.ribbon.refresh();
			$("#" + rbmCnvNs.rbmConversionSpinnerId).show();
			rbmCnvNs.isRbmConversionRunning(false);
		});
	},
	getRbmConversionDialogButtons: function () {
		return [
			rm.ui.dialog.standardButtons.cancel,
			{
				text: "Ok",
				click: function () {
					rbmCnvNs.convertProjectFromNonRbmToRbm();
					$(this).dialog("close");
				}
			}
		];
	},
	showProjectConversionDialog: function () {
		rm.ui.dialog.showModalWithButtons("#rbmConfirmRbmConversionDiaLog", "Convert project to Risk Based Monitoring", "", false, "auto", "auto", rbmCnvNs.getRbmConversionDialogButtons());
	},
	isRbmConversionRunning: function (isInitialCheck) {
		var postData = { entityId: projConfig.getProjectId(), processId: Process_E.NonRbmToRbmProjectConversion, entityTypeId: EntityType.Project };
		rm.ajax.utilitySvcAsyncGet("IsProcessRunning", postData, function (isProcessRunning) {
			if (isInitialCheck) {
				if (isProcessRunning) {
					$("#" + rbmCnvNs.rbmConversionSpinnerId).show();
					rbmCnvNs._isRBMConversionRunning = true;
					rm.ui.ribbon.delayedRefresh();
					setTimeout(function () { rbmCnvNs.isRbmConversionRunning(false); }, 10000);
				}
			}
			else if (isProcessRunning) { setTimeout(function () { rbmCnvNs.isRbmConversionRunning(false); }, 10000); }
			else {
				$("#" + rbmCnvNs.rbmConversionSpinnerId).hide();
				rm.ui.dialog.showModalWithButtons("#rbmConversionCompleteDiaLog",
					"Project conversion to Risk Based Monitoring complete",
					"",
					false,
					"auto",
					"auto",
					[{
						text: "Ok", click: function () {
							$(this).dialog("close");
							rm.utilities.reloadPageWithDelay();
						}
					}]);
				rbmCnvNs._isRBMConversionRunning = false;
				rbmCnvNs._isRbmConversionAllowed = false;
				rm.ui.ribbon.delayedRefresh();
			}
		});

	},
	isRbmConversionEnabled: function () { return rbmCnvNs._isRbmConversionAllowed && !rbmCnvNs._isRBMConversionRunning; },
	showToolTipOnRbmConversionButton: function () {
		var tooltipMessage = "Convert project from 'non-Risk Based Monitoring' to 'Risk Based Monitoring' (RBM)"
		rm.qtip.showInfo($(rbmCnvNs.btnRbmConversionSelector), tooltipMessage);
	},
};
var milestoneNs = {
	_isAddEditButtonEnabled: false,
	_isSaveButtonEnabled: false,
	_isCancelButtonEnabled: false,
	_showReadOnlyProjectMilestones: false,
	_selectedTab: 0,

	AddEditMilestone: function () {
		SetEditMode();
		milestoneNs._isAddEditButtonEnabled = false;
		rm.ui.ribbon.delayedRefresh();
	},
	checkPageDirty: function () {
		return rm.formStatus.isDirty(getJsonObjectForDirtyCheck());
	},

	Save: function () {
		milestoneNs._showReadOnlyProjectMilestones = false;
		if (milestoneNs._selectedTab == 0) {
			rm.validation.clearError($("#txtmilestone"));
			rm.validation.clearError($("#custommilestonedate"));
			rm.validation.clearError($("#ddlCountryList"));

		}
		else if (milestoneNs._selectedTab == 2) {

			rm.validation.clearError($("#ddlCountryList"));
			if (rm.grid.hasRowsInEditMode(projConfig.customMilestoneGridSelector)) {
				if ($("#txtmilestone").hasClass(rm.validation.errorClass))
					rm.validation.clearError($("#txtmilestone"));
				if ($("#custommilestonedate").hasClass(rm.validation.errorClass))
					rm.validation.clearError($("#custommilestonedate"));
			}
		}
		else if (milestoneNs._selectedTab == 1) {
			rm.validation.clearError($("#txtmilestone"));
			rm.validation.clearError($("#custommilestonedate"));
		}
		$.each($('#list').find('input[type=text]'), function (index, element) {
			rm.validation.clearError($(element));
		});
		countryMilestoneNs.ClearGrid();
		var isValid = !rm.validation.hasControlsWithErrors();

		if (isValid) {
			var postData = projConfig.getMilestonePostData();
			$.ajax({
				url: rm.ajax.projectSvcUrl + "UpdateProjectMilestones",
				type: "POST",
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				data: JSON.stringify(postData),
				cache: false,
				success: function (data) {
					$("#custommilestonedate").qDatepicker("disable");
					if (data.RowJson) {
						projConfig.addNewCustomMilestoneToGrid(data.RowJson);
					}
					if (rm.grid.hasRowsInEditMode(projConfig.customMilestoneGridSelector)) {
						SaveGrid();
					}
					else {
						rm.ui.messages.showSuccess('Milestone saved successfully.');
						$("[id$=IsPageDirty]").val("0");
						$("#txtMilestoneId").val('');
						milestoneNs._isSaveButtonEnabled = false;
						milestoneNs._isCancelButtonEnabled = false;
						milestoneNs._isAddEditButtonEnabled = true;
						milestoneNs._showReadOnlyProjectMilestones = true;
						$(projConfig.countryGridSelector).trigger("reloadGrid");
						$("#ddlCountryList").empty().append($("<option>").val("-1").html("--Select--"));
						$("#ddlRegionList").val("-1");
						SetReadonlyContents();
					}
					projConfig.getProjectMilestoneById(projConfig.getProjectId(), milestoneNs._showReadOnlyProjectMilestones);
					rm.ui.ribbon.delayedRefresh();
				},
				error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: UpdateProjectMilestones", data.responseText); }
			});
		}
		else {
			rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
		}

	}
};

GetSelectedCustomMilestone = function () {
	var idArray = [];
	var mygrid = $(projConfig.customMilestoneGridSelector);
	var ids = mygrid.getDataIDs(); //all the rowids   
	for (var i = 0; i < ids.length; i++) {
		var check = mygrid.find('#' + ids[i] + ' input[type=checkbox]').attr('checked');
		mygrid.getRowData(ids[i]);
		if (check) { idArray.push(ids[i]); }
	}

	return idArray;
};
DeleteSelectedMilestone = function () {
	var Ids = GetSelectedCustomMilestone().join(",");
	var milestoneIds = Ids;
	$.ajax({
		url: rm.ajax.projectSvcUrl + "DeleteCustomMilestone",
		type: "POST",
		contentType: "application/json; charset=utf-8",
		dataType: "json",
		data: JSON.stringify({ milestoneIds: milestoneIds }),
		cache: false,
		success: function (data) {
			rm.ui.messages.showSuccess('Milestone(s) deleted successfully.');
			$("#txtmilestone").val('');
			$("#custommilestonedate").val('');
			rm.validation.clearError($("#txtmilestone"));
			rm.validation.clearError($("#custommilestonedate"));
			$(projConfig.customMilestoneGridSelector).trigger('reloadGrid');
			rm.ui.ribbon.delayedRefresh();
		},
		error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: DeleteCustomMilestone", data.responseText); }
	});
};
BindDatePicker = function () {
	$("#projectMilestone tr").each(function (index, element) {
		if (index > 0) {
			if ($(this).attr('disabled', 'true')) {
				$(this).find(".projectMilestoneDate").qDatepicker();
			}
		}
	});
};

ValidateMilestone = function () {
	if (milestoneNs._selectedTab == 0) { return true; }
	else if (milestoneNs._selectedTab == 2) { return ValidateCustomMilestone(); }
	else if (milestoneNs._selectedTab == 1) { return countryMilestoneNs.Validate(); }
};

$(document).on("keyup change cut paste", ".projectMilestoneDate,#custommilestonedate,#txtmilestone,#countryMsList input:enabled:visible", function (event) {
	rm.ui.ribbon.delayedRefresh();
	setPageIsDirty();
});

bindDirty = function () {
	rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, getJsonObjectForDirtyCheck());
	rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, dteSchemaNs.getJsonObjectForDirtyCheck());
};

setPageIsDirty = function () {
	$("[id$=IsPageDirty]").val("1");
};

getJsonObjectForDirtyCheck = function () {
	return { items: [{ selector: ".projectMilestoneDate,#custommilestonedate,#txtmilestone,#countryMsList input", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
};

//RMK: Validate custom milestone here
ValidateCustomMilestone = function () {

	var isValid = true;
	var milestoneName = $.trim($("#txtmilestone").val());
	var milestoneDate = $.trim($("#custommilestonedate").val());
	if (!rm.grid.hasRowsInEditMode(projConfig.customMilestoneGridSelector)) {
		if (milestoneName == "") {
			rm.validation.addError("#txtmilestone", Resources.MilestoneRequired);
			isValid = false;
		}
		else {
			if (projConfig.isMilestoneExist($("#txtmilestone").val())) {
				rm.validation.addError("#txtmilestone", Resources.MilestoneExists);
				isValid = false;
			}
			else {
				rm.validation.clearError($("#txtmilestone"));
			}
		}
		if (milestoneDate == "") {
			rm.validation.addError("#custommilestonedate", Resources.MilestoneDateRequired);
			isValid = false;
		}
		else {
			if (!rm.date.isValidDate(milestoneDate, true)) {
				rm.validation.addError("#custommilestonedate", "Invalid Date format. (dd-MMM-yyyy)");
				isValid = false;
			} else {
				rm.validation.clearError($("#custommilestonedate"));
			}
		}
	}
	else {

		if (milestoneName != "" || milestoneDate != "") {
			if (($("#txtmilestone").val() == "")) {
				rm.validation.addError("#txtmilestone", Resources.MilestoneRequired);
				isValid = false;
			}
			else {
				if (projConfig.isMilestoneExist($("#txtmilestone").val())) {
					rm.validation.addError("#txtmilestone", Resources.MilestoneExists);
					isValid = false;
				}
				else {
					rm.validation.clearError($("#txtmilestone"));
				}
			}


			if (milestoneDate == "") {
				rm.validation.addError("#custommilestonedate", Resources.MilestoneDateRequired);
				isValid = false;
			}
			else {
				if (!rm.date.isValidDate(milestoneDate, true)) {
					rm.validation.addError("#custommilestonedate", "Invalid Date format. (dd-MMM-yyyy)");
					isValid = false;
				} else {
					rm.validation.clearError($("#custommilestonedate"));
				}
			}
		}
	}
	return isValid;
};

//RMK: Clear the custom milestone input fields
function ClearAll() {
	$("#txtmilestone").val("");
	$("#custommilestonedate").val("");

	$("#projectMilestone").find('input[type=checkbox]').attr('checked', false);
	$("#customMileStone").find('input[type=checkbox]').attr('checked', false);
	$("#customMilestoneGrid").find('input[type=checkbox]').attr('checked', false);
	$("#CountryMilestoneInput").find('input[type=checkbox]').attr('checked', false);
};

RemoveProjectMilestoneRow = function () {
	$("#projectMilestone tr").each(function (index, element) {
		if (index > 0) { $(this).remove(); }
	});
};
addToRowsEditing = function (rowid) {
	var row = { 'message': '', 'ajaxComplete': false };
	rowsEditing.put(rowid, row);
};
//MR: Keep track of all the AJAX return messages and display a message if there were any problems
var rowsEditing = new Hash();
rowsEditing.HasMessage = false;
rowsEditing.LastMessage = '';
rowsEditing.AjaxCount = 0;
rowsEditing.SavedSomething = false;
rowsEditing.clearAll = function () {
	rowsEditing.empty();
	rowsEditing.HasMessage = false;
	rowsEditing.LastMessage = '';
	rowsEditing.AjaxCount = 0;
	rowsEditing.SavedSomething = false;
};

//Successful Ajax response, so dequeue the Ajax call
checkForErrorsOnSuccess = function (rowid, singleRow) {
	var row = rowsEditing.pop(rowid);
	rowsEditing.AjaxCount--;
	rowsEditing.SavedSomething = true;

	if (rowsEditing.AjaxCount == 0 || singleRow) {
		if (rowsEditing.length == 0) {
			rm.ui.messages.clearAllMessages();
			rm.ui.messages.showSuccess(Resources.AllDataSavedSuccessfully);
			rowsEditing.clearAll();
			milestoneNs._isSaveButtonEnabled = false;
			milestoneNs._isCancelButtonEnabled = false;
			milestoneNs._isAddEditButtonEnabled = true;
			milestoneNs._showReadOnlyProjectMilestones = true;
			SetReadonlyContents();
			rm.ui.ribbon.delayedRefresh();

		} else if (singleRow) {
			rm.ui.messages.clearAllMessages();
			rm.ui.messages.showSuccess(Resources.DataSavedSuccessfully);
			milestoneNs._isSaveButtonEnabled = false;
			milestoneNs._isCancelButtonEnabled = false;
			milestoneNs._isAddEditButtonEnabled = true;
			milestoneNs._showReadOnlyProjectMilestones = true;
			SetReadonlyContents();
			rm.ui.ribbon.delayedRefresh();
		} else if (rowsEditing.length > 0) {
			rm.ui.messages.addError('Data saved with some errors found.');
		}
		if (rowsEditing.HasMessage) {
			if (rowsEditing.LastMessage != "")
				alert(rowsEditing.LastMessage);
		}
		rowsEditing.HasMessage = false;
		rowsEditing.SavedSomething = false;
	}


};

//Failed Ajax response, so leave on the queue
checkForErrorsOnError = function (rowid, singleRow) {
	var row = rowsEditing.get(rowid);
	rowsEditing.AjaxCount--;

	if (rowsEditing.AjaxCount == 0 || singleRow) {
		if (rowsEditing.length > 0) {
			if (rowsEditing.SavedSomething) {
				rm.ui.messages.addError('Data saved with some errors found.');
			} else {
				rm.ui.messages.addError('Errors found.  Nothing saved.');
			}
		}

		rowsEditing.HasMessage = false;
		rowsEditing.SavedSomething = false;
	}
};

aftersaveCallback = function () {
	var args = arguments;
};

errorCallback = function (rowid, response, errorType, singleRow) {
	var d = $.parseJSON(response.responseText);
	var row = rowsEditing.get(rowid);

	if (row !== undefined) {
		row.ajaxComplete = true;
		rm.validation.processErrorMessages(d.ValidationErrors, projConfig.customMilestoneGridSelector, "Message");
		rowsEditing.HasMessage = true;
		rowsEditing.LastMessage = row.message;
		checkForErrorsOnError(rowid, singleRow);
	}
};

saveSuccessCallback = function (response, singleRow) {
	var d = $.parseJSON(response.responseText);
	var additionalData = d.RequestExecutionStatus[0].AdditionalData;
	if (!d.ContainsValidationErrors) {
		//Give it a split second so the row can go back to read-only mode
		setTimeout(function () {
			$(projConfig.customMilestoneGridSelector).setCell(additionalData.id, "Name", additionalData.MilestoneName, "", "", true);
			$(projConfig.customMilestoneGridSelector).setCell(additionalData.id, "MilestoneDate", additionalData.MilestoneDate, "", "", true);

		}, 100);

		rm.grid.cancelRowEditMode(projConfig.customMilestoneGridSelector, additionalData.id);
		$(projConfig.customMilestoneGridSelector).setCell(additionalData.RowId, "Message", " ");
		checkForErrorsOnSuccess(additionalData.id, singleRow);
	}
	else {
		errorCallback(additionalData.id, response, null, singleRow);
		return false;
	}

	return true;
};

//Added for country milestone functionality
var countryMilestoneNs = {
	BindCountryMilestoneDatePicker: function () {
		$(".countrymilestonedate").qDatepicker();
	},
	Validate: function () {
		var isValid = true;
		if ($("#ddlRegionList").val() != "-1" && $("#ddlCountryList").val() == "-1") {

			rm.validation.addError("#ddlCountryList", "Select The Country");//to be moved to Resource    
			isValid = false;
		}
		else {
			rm.validation.clearError($("#ddlCountryList"));
		}
		return isValid;
	},
	ClearGrid: function () {
		var ids = $(projConfig.countryGridSelector).getDataIDs();  //all the rowids
		for (var i = 0; i < ids.length; i++) {
			if ($("#" + $($(projConfig.countryGridSelector).getCell(ids[i], "MilestoneDate")).attr("id")).hasClass(rm.validation.errorClass)) {
				rm.validation.clearError($("#" + $($(projConfig.countryGridSelector).getCell(ids[i], "MilestoneDate")).attr("id")))
			}
		}
	},
	GetRegion: function () {
		$.rm.Ajax_Utility("Geography/GetRegions", "", function (data) {
			rm.dropdown.fill("#ddlRegionList", $.parseJSON(data), "Id", "Name", -1, true, false);
		}, true, true);
	},
	GetCountry: function () {
		var region = $("#ddlRegionList").val();
		if (region != "-1") {
			var postData = {
				regionIds: region,
				projectId: projConfig.getProjectId()
			};

			$.rm.Ajax_Utility("FindCountriesByRegionsAndProjectId", postData, function (data) {
				rm.dropdown.fill("#ddlCountryList", data, "key", "value", -1, true, false);
				milestoneNs._isSaveButtonEnabled = true;
				milestoneNs._isCancelButtonEnabled = true;
				setPageIsDirty();
				rm.ui.ribbon.delayedRefresh();
			}, true, true);
		}
		else {
			$("#ddlCountryList").empty().append($("<option>").val("-1").html("--Select--"));
			milestoneNs._isSaveButtonEnabled = false;
			milestoneNs._isCancelButtonEnabled = false;
			rm.ui.ribbon.delayedRefresh();
		}
	},
	LoadCountryMilestoneData: function () {
		projConfig.buildCountryMilestonesGrid(projConfig.getProjectId());
		countryMilestoneNs.GetRegion();
		$("#ddlCountryList").empty().append($("<option>").val("-1").html("--Select--"));
	}
};

SaveGrid = function () {
	//Saves only rows that are in edit mode
	//Override the hidden dates too or the sorting is broken until you reload the page

	var mygrid = $(projConfig.customMilestoneGridSelector);
	var ids = mygrid.getDataIDs();  //all the rowids

	rowsEditing.AjaxCount = 0;
	for (var i = 0; i < ids.length; i++) {
		var rowid = ids[i];
		if ($($(projConfig.customMilestoneGridSelector).jqGrid("getInd", rowid, true)).attr("editable") === "1") {
			rowsEditing.AjaxCount++;
		}
	}
	rm.grid.clearGridError(projConfig.customMilestoneGridSelector, "Message"); //Clear all grid errors before saving
	//Count in one loop, save in the next - otherwise creates a race condition
	for (var i = 0; i < ids.length; i++) {
		var rowid = ids[i];
		//From docs http://www.trirand.com/jqgridwiki/doku.php?id=wiki:inline_editing
		mygrid.jqGrid("saveRow", rowid, saveSuccessCallback, null, null, aftersaveCallback, null, null);
	}
};

//Cancel editing for the entire grid.  Restores last saved values.
CancelGrid = function () {
	rm.grid.cancelGridEditMode(projConfig.customMilestoneGridSelector);
	rowsEditing.clearAll();
	rm.ui.ribbon.delayedRefresh();
};
