﻿/// <reference path="../common/rmhelper.js" />
$(document).ready(function () {
	$(document).ajaxStart(function () { rm.ui.block(); });
	$(subRqNs.gridSelector).ajaxStop(function () { rm.ui.unblock(); });
	$(document).on("click", "[name=hlDeleteAndTerminate],[name=hlDeleteAndRevive],[name=hlCancel]", subRqNs.handleBackfillDeleteLinkClick);

	var rmPageLinkId = GetRmPageLinkId();
	rm.utilities.setSelectedNavLinkAndHelpUrl(rmPageLinkId);
	$(subRqNs.modifyRequestsRibbonControlId).hide();
	subRqNs.buildGrid(rmPageLinkId);
	subRqNs.init();
	window.onbeforeunload = function () {
		if (rm.grid.hasRowsInEditMode(subRqNs.gridSelector)) { return "Are you sure you want to leave without saving your changes?"; }
	};
	rm.grid.bindEventsToResizeGrid(subRqNs.gridSelector);
	rm.qtip.showInfo("[id$=_ResubmitRow]", "'Return Response' button is enabled only when you hold an 'RM User Role' to which selected request(s) have been returned.");
});

var subRqNs = {
	gridSelector: "#list",
	resubmitContainerSelector: "#resubmitDiv",
	terminateContainerSelector: "#terminateDiv",
	modifyRequestRibbonControlId: '#Ribbon_RequestRibbon_GridActions_EditRow',
	modifyRequestsRibbonControlId: '#Ribbon_RequestRibbon_GridActions_EditMultipleRow',
	splitAndAssignButtonSelector: "[id*=SplitAndAssign]",
	columnModelUsedByGrid: null,
	frozenColumnAlreadyBound: false,
	isCreateBackfillEnabled: function () { return subRqNs.areAllSelectedRequestsHardBooked(); },
	isCancelGridEditModeEnabled: function () { return rm.grid.hasRowsInEditMode(subRqNs.gridSelector); },
	isSaveRequestsInEditModeFromGridEnabled: function () { return rm.grid.hasRowsInEditMode(subRqNs.gridSelector); },
	isResubmitQueriedRequestEnabled: function () { return subRqNs.areAllSelectedRequestsInStatus(RequestStatusName.Returned); },
	isViewQueryDetailsEnabled: function () { return rm.grid.hasSingleRowSelected(subRqNs.gridSelector) && subRqNs.areAllSelectedRequestsInStatus(RequestStatusName.Returned); },
	isRemoveSoftBookEnabled: function () { return subRqNs.hasAccessToAssignRequest() && rm.grid.hasSingleRowSelected(subRqNs.gridSelector) && subRqNs.areAllSelectedRequestsInStatus(RequestStatusName.Pending); },
	isAcceptSoftBookingEnabled: function () { return subRqNs.hasAccessToAssignRequest() && rm.grid.hasSingleRowSelected(subRqNs.gridSelector) && subRqNs.areAllSelectedRequestsInStatus(RequestStatusName.Pending); },
	isEditSelectedRequestEnabled: function () { return rm.grid.hasSingleRowSelected(subRqNs.gridSelector); },
	isDeleteSubmittedRequestsEnabled: function () { return rm.grid.hasRowsSelected(subRqNs.gridSelector) && !subRqNs.areAllSelectedRequestsHardBooked(); },
	isTerminateRequestEnabled: function () { return subRqNs.areAllSelectedRequestsHardBooked(); },
	isQueryRequestEnabled: function () { return subRqNs.areAllSelectedRequestsInStatus(RequestStatusName.Submitted); },
	isAssignResourceEnabled: function () { return subRqNs.areAllSelectedRequestsInStatus(RequestStatusName.Submitted); },
	isAssignAndSplitRequestEnabled: function () { return rm.grid.hasSingleRowSelected(subRqNs.gridSelector) && subRqNs.getSelectedResourceTypeDetailsFromSelectedSingleRow().AllowRequestSpliting; },
	getSelectedResourceTypeDetailsFromSelectedSingleRow: function () {
		if (rm.grid.hasSingleRowSelected(subRqNs.gridSelector)) {
			return ResourceTypeDetails[subRqNs.getSelectedRequestRowData().ResourceTypeId];
		}
		else { return null; }
	},
	init: function () {
		rm.qtip.showInfoOnGridColumn(subRqNs.splitAndAssignButtonSelector, "Split and optionally Assign Records Management 'TMF Specialist' or Local RSU '# Country Sites' requests'");
	},
	isEditMultipleRequestsEnabled: function () {
		$(subRqNs.modifyRequestsRibbonControlId).hide();
		return $.rm.requestCommon.ModifyMultipleRowsEnabled(subRqNs.gridSelector, subRqNs.modifyRequestRibbonControlId, subRqNs.modifyRequestsRibbonControlId);
	},
	hasAccessToAssignRequest: function () { return HasAccessToAssignRequest(); /*Defined in the ASPX page*/ },
	hideMessageColumn: function () { rm.grid.clearGridError(subRqNs.gridSelector, "Message"); },
	getSelectedRequestRowData: function () {
		var selectedRequesIds = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		return (selectedRequesIds.length == 1) ? rm.grid.rowData.getById(subRqNs.gridSelector, selectedRequesIds[0]) : null;
	},
	showRemoveSoftBookDialog: function () { arSbNs.showControl(subRqNs.gridSelector, subRqNs.getSelectedRequestRowData(), false); },
	showAcceptSoftBookDialog: function () {
		if (subRqNs.requestWithFteErrorSelected()) {
			alert("You have selected a request with FTE Allocation Error. This request cannot be assigned until FTE Allocation Error is fixed.");
		}
		else if (subRqNs.requestsSelectedThatPreventAssignmentBecauseOfDteMismatch()) {
			alert(Resources.PpmRmDteMismatchPreventsAcceptSoftBook);
		}
		else {
			arSbNs.showControl(subRqNs.gridSelector, subRqNs.getSelectedRequestRowData(), true);
		}
	},
	assignResource: function () {
		var selectedrows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		rm.ui.messages.clearAllMessages();

		if (selectedrows.length > 0) {
			var selectedResourceTypeIds = subRqNs.getResourceTypesFromSelectedRequests();
			if (selectedResourceTypeIds.length > 1) {
				alert("Requests that belong to different resource types cannot be assigned in a single batch.");
			}
			else if (subRqNs.isProposalRequestSelected()) {
				alert("Proposal requests cannot be assigned from Submitted Request page. Please use 'Resourcing Worklist' page.");
			}
			else if (subRqNs.requestWithFteErrorSelected()) {
				alert("Requests with FTE Allocation Error cannot be assigned.");
			}
			else if (subRqNs.requestsSelectedThatPreventAssignmentBecauseOfDteMismatch()) {
				alert(Resources.PpmRmDteMismatchPreventsAssignmentAndBackfill.replace("{0}", "assigned"));
			}
			else {
				var resourceTypeId = selectedResourceTypeIds[0];
				var selectedProjectIds = subRqNs.getProjectIdsFromSelectedRequests();
				var singleProjectSelected = (selectedProjectIds.length == 1);
				var projectId = singleProjectSelected ? selectedProjectIds[0] : -1;

				asgnResNs.showControl(subRqNs.gridSelector, selectedrows, singleProjectSelected, projectId, resourceTypeId);

				rm.grid.clearGridError(subRqNs.gridSelector, "Message");
			}
		}
		else {
			rm.ui.messages.addError("Please select at least one unassigned request.");
		}
	},
	getFilterValues: function () {
		return (GetRmPageLinkId() == RmPageLink_E.SubmittedRequests) ? rm.grid.filterOptions.iconSearch_SubmittedPage : rm.grid.filterOptions.iconSearch;
	},
	areAllSelectedRequestsHardBooked: function () {
		var allHardBooked = false;
		var selectedRows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		if (selectedRows) {
			$.each(selectedRows, function (index, ele) {
				var rowJson = rm.grid.rowData.getById(subRqNs.gridSelector, ele);
				if (rowJson.RequestStatusId != RequestStatusName.Assigned &&
					rowJson.RequestStatusId != RequestStatusName.Backfilled) {
					allHardBooked = false;
					return false;
				}
				else { allHardBooked = true; }
			});
		}
		return allHardBooked;
	},
	areAllSelectedRequestsUnassigned: function () {
		var allUnassigned = false;
		var selectedRows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		if (selectedRows) {
			$.each(selectedRows, function (index, ele) {
				var rowJson = rm.grid.rowData.getById(subRqNs.gridSelector, ele);
				if (rowJson.RequestStatusId == RequestStatusName.Assigned ||
					rowJson.RequestStatusId == RequestStatusName.Backfilled ||
					rowJson.RequestStatusId == RequestStatusName.Pending) {
					allUnassigned = false;
					return false;
				}
				else { allUnassigned = true; }
			});
		}
		return allUnassigned;
	},
	logggedinUserHasRole: function (requiredRoleId) {
		return (LoggedInUser != null && Array.isArray(LoggedInUser.Roles)) ? (LoggedInUser.Roles.find(function (userRoleId) { return requiredRoleId == userRoleId; }) != null) : false;
	},
	loggedinUserHasRoleToRespondToQuery: function () {
		var loggedinUserHasRoleToRespondToQuery = LoggedInUser.IsAdmin || LoggedInUser.IsSupport;
		if (!loggedinUserHasRoleToRespondToQuery) {
			var selectedRows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
			if (selectedRows) {
				$.each(selectedRows, function (index, ele) {
					var rowJson = rm.grid.rowData.getById(subRqNs.gridSelector, ele);
					if (subRqNs.logggedinUserHasRole(rowJson.QueriedRequestRoleId)) {
						loggedinUserHasRoleToRespondToQuery = true;
					}
					else {
						loggedinUserHasRoleToRespondToQuery = false;
						return false;
					}
				});
			}
		}
		return loggedinUserHasRoleToRespondToQuery;
	},
	areAllSelectedRequestsInStatus: function (requestStatusId) {
		var allInGivenStatus = false;
		var selectedRows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		if (selectedRows) {
			$.each(selectedRows, function (index, ele) {
				var rowJson = rm.grid.rowData.getById(subRqNs.gridSelector, ele);
				if (rowJson.RequestStatusId != requestStatusId) {
					allInGivenStatus = false;
					return false;
				}
				else { allInGivenStatus = true; }
			});
		}
		return allInGivenStatus;
	},
	clearSelectAllCheckedButton: function () {
		if ($("#cb_list").is(":checked") && !rm.grid.hasRowsSelected(subRqNs.gridSelector))
			$(subRqNs.gridSelector).jqGrid('resetSelection');
	},
	terminateRequestAjax: function () {
		if ($("#taTerminateNotes").val().trim() == "") {
			$("#taTerminateNotes").val("");
			alert("A note must entered to proceed.");
			return false;
		}

		subRqNs.hideMessageColumn();
		var postData = { requestIds: rm.grid.getSelectedIdArray(subRqNs.gridSelector), comments: $("#taTerminateNotes").val() };
		rm.ajax.requestSvcAsyncPost("TerminateRequests", postData, function (jsonData) {
			var isSuccess = true;
			var errorMessages = "";
			$.each(jsonData, function (index, request) {
				if (request.IsSuccessful) {
					rm.grid.removeRow(subRqNs.gridSelector, request.EntityId);
				}
				else {
					isSuccess = false;
					rm.grid.showErrorIconInMessageColumn(subRqNs.gridSelector, request.EntityId, 'Message', request.Message);
					errorMessages += "<tr><td>" + request.EntityId + "</td><td>" + request.Message + "</td></tr>";
				}
			});

			rm.ui.ribbon.delayedRefresh();
			$(subRqNs.terminateContainerSelector).off("dialogbeforeclose");
			$(subRqNs.terminateContainerSelector).dialog("close");
			$.q.RebindQtip(subRqNs.gridSelector);
			rm.serviceCalls.getRequestCounts();
			$("#taTerminateNotes").val("");

			if (isSuccess) {
				subRqNs.clearSelectAllCheckedButton();
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showSuccess('Request(s) terminated successfully.');
			}
			else {
				rm.ui.messages.addError('Failed to terminate one or more requests. Hover over error indicator for more details.');

				errorMessages = "<table class='validationTable'><tr class='headerRow'><td>Request Id</td><td valign='top'>Message</td></tr>" + errorMessages + "</table>";
				rm.ui.dialog.showModal("#divDialog", "Termination Errors/Warning", errorMessages, true, 620, "auto");
			}
		});
	},
	assignAndSplitRequest: function () {
		var selectedRequestDetails = subRqNs.getSelectedRequestRowData();
		selectedRequestDetails.JobRoleId = subRqNs.getSelectedResourceTypeDetailsFromSelectedSingleRow().JobRoleId;
		splitAssignReq.showDialog(selectedRequestDetails, rm.utilities.reloadPage, function () { rm.grid.reloadGrid(subRqNs.gridSelector); });
	},
	terminateRequest: function () {
		var selectedrows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		if (selectedrows.length == 0) {
			alert("No request selected.");
		}
		else {
			selectedId = selectedrows[0];
			var isAllowModify = rm.grid.rowData.getById(subRqNs.gridSelector, selectedId).allowModify;

			if (isAllowModify == false) { alert(Resources.AllowModifyMessage); }
			else {
				if (confirm(Resources.TerminateRequestConfirm)) {
					var okButton = { text: "Ok", click: subRqNs.terminateRequestAjax };
					var btnArray = [okButton, rm.ui.dialog.standardButtons.cancel];
					rm.ui.dialog.showModalWithButtons(subRqNs.terminateContainerSelector, "Enter Termination Notes", "", false, 340, 200, btnArray);

					$(subRqNs.terminateContainerSelector).off("dialogbeforeclose").on("dialogbeforeclose", function (event, ui) {
						if (confirm("If you continue then no notes will be entered and the request cannot be terminated.")) {
							$("#taTerminateNotes").val("");
						}
						else { event.preventDefault(); }
					});
				}
			}
		}
	},
	deleteSubmittedRequests: function () {
		var selectedrows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		if (selectedrows.length == 0) {
			alert("No request selected.");
			return false;
		}
		else {
			if (confirm(Resources.DeleteRequestConfirm)) {
				subRqNs.hideMessageColumn();
				var postData = { requestIds: selectedrows };
				var errorMessages = "";

				rm.ajax.requestSvcAsyncPost("DeleteSubmittedRequests", postData, function (jsonData) {
					var isSuccess = true;
					$.each(jsonData, function (index, request) {
						if (request.IsSuccessful) {
							rm.grid.removeRow(subRqNs.gridSelector, request.EntityId);

							if (request.ParentRequestId != -1) {
								$(subRqNs.gridSelector).setCell(request.ParentRequestId, 'StopDate', request.ParentStopDate);
							}
						}
						else {
							isSuccess = false;
							rm.grid.showErrorIconInMessageColumn(subRqNs.gridSelector, request.EntityId, 'Message', request.Message);
							errorMessages += "<tr><td>" + request.EntityId + "</td><td>" + request.Message + "</td></tr>";
						}
					});
					rm.ui.ribbon.delayedRefresh();
					$.q.RebindQtip(subRqNs.gridSelector);
					rm.serviceCalls.getRequestCounts();
					if (isSuccess) {
						subRqNs.clearSelectAllCheckedButton();
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showSuccess('Request(s) removed successfully.');
					}
					else {
						rm.ui.messages.addError('Failed to remove one or more requests. Hover over error indicator for more details.');

						errorMessages = "<table class='validationTable'><tr class='headerRow'><td>Request Id</td><td valign='top'>Message</td></tr>" + errorMessages + "</table>";
						rm.ui.dialog.showModal("#divDialog", "Deletion Errors/Warning", errorMessages, true, 620, "auto");
					}
				});
			}
		}
	},
	editSelectedRequest: function () {
		var selectedrows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		selectedId = selectedrows[0];
		$.validationHelper.GetCustomeMilestoneStatus(selectedrows.join(","), "", false, false);
		if (selectedrows.length > 1) {
			alert("Can only edit one request at a time.");
			return false;
		}

		if (selectedrows.length == 0) {
			alert("No request selected.");
			return false;
		}

		var isAllowModify = rm.grid.rowData.getById(subRqNs.gridSelector, selectedId).allowModify;
		if (isAllowModify == false) {
			alert(Resources.AllowModifyMessage);
		}
		else {
			rm.cookie.pushProperties(rm.constants.keys.cookie.SubReqGridFilter, { selectedRequestId: selectedrows[0], page: $(subRqNs.gridSelector).getGridParam("page") });
			if (rm.serviceCalls.isRequestValid(selectedrows[0], true, GetRmPageLinkId())) {

				document.location.href = "/_layouts/SPUI/Requests/EditRequestNew.aspx?source=submitted&requestId=" + selectedrows[0] + "&rmPageLink=" + GetRmPageLinkId();
			}
		}
	},
	queryRequest: function () {
		var selectedrows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		$.validationHelper.GetCustomeMilestoneStatus(selectedrows.join(","), "", false, false);

		if (!$.validationHelper.isAnyMilestoneDeactivated) {
			rm.grid.clearGridError(subRqNs.gridSelector, "Message");
			queryRqNs.showControl(subRqNs.gridSelector, selectedrows);
		}
	},
	saveRequestsInEditModeFromGrid: function () {
		rm.ui.messages.clearAllMessages();

		var rowsToSave = [];
		var rowsInEditMode = rm.grid.getRowsInEditMode(subRqNs.gridSelector);

		$.each(rowsInEditMode, function (index, editedRow) {
			var startDate = $(rm.grid.getControlFromEditRow(subRqNs.gridSelector, editedRow.id, "StartDate"));
			var stopDate = $(rm.grid.getControlFromEditRow(subRqNs.gridSelector, editedRow.id, "StopDate"));

			if (rm.date.isValidDate(startDate.val(), true) &&
				rm.date.isValidDate(stopDate.val(), true)) {
				rowsToSave.push(rm.grid.getUpdatedRowDataById(subRqNs.gridSelector, editedRow.id));
			}
			else {
				rm.ui.messages.addError("Please fix the errors and click Save again. Page will attempt to save the records with valid data.");
			}
		});

		if (rowsToSave.length > 0) {
			subRqNs.saveRequests(rowsToSave, rowsInEditMode.length);
		}
	},
	cancelGridEditMode: function () {
		rm.grid.cancelGridEditMode(subRqNs.gridSelector);
		rm.ui.ribbon.delayedRefresh();
	},
	resubmitQueriedRequest: function () {
		if (!subRqNs.loggedinUserHasRoleToRespondToQuery()) {
			alert("You have selected one or more requests that are returned to an 'RM User Role' which you do not hold. Therefore, you cannot respond to these requests. It is recommended that you filter the grid on 'Request Status Indicator' for 'Queried Request' before responding to the queries.");
		}
		else {
			$.validationHelper.GetCustomeMilestoneStatus(rm.grid.getSelectedIds(subRqNs.gridSelector), "", false, false);

			if (!$.validationHelper.isAnyMilestoneDeactivated) {
				var okButton = { text: "Resubmit", click: subRqNs.resubmitQueriedRequestAjax };
				var btnArray = [okButton, rm.ui.dialog.standardButtons.cancel];
				rm.ui.dialog.showModalWithButtons(subRqNs.resubmitContainerSelector, "Resubmit Comments", "", false, 300, 160, btnArray);

				$(subRqNs.resubmitContainerSelector).off("dialogbeforeclose").on("dialogbeforeclose", function (event, ui) {
					if (confirm("If you continue then no comment will be entered and the request cannot be resubmitted.")) {
						$("#taResubmitComments").val("");
					}
					else { event.preventDefault(); }
				});
			}
		}
	},
	resubmitQueriedRequestAjax: function () {
		if ($("#taResubmitComments").val().trim() == "") {
			$("#taResubmitComments").val("");
			alert("A comment has to be entered before a request can be resubmitted.");
			return false;
		}
		var postData = {
			resubmitRequest: {
				RequestIds: rm.grid.getSelectedIdArray(subRqNs.gridSelector),
				Comment: $("#taResubmitComments").val()
			}
		};
		rm.ajax.requestSvcAsyncPost("Resubmit", postData, function (jsonData) {
			var isSuccess = true;
			$.each(jsonData, function (index, request) {
				if (request.IsSuccessful) {
					rm.grid.removeRow(subRqNs.gridSelector, request.EntityId);
				}
				else {
					isSuccess = false;
					rm.grid.showErrorIconInMessageColumn(subRqNs.gridSelector, request.EntityId, 'Message', request.Message);
				}
			});
			$(subRqNs.resubmitContainerSelector).off("dialogbeforeclose")
			$("#resubmitDiv").dialog('close');
			$.q.RebindQtip(subRqNs.gridSelector);
			rm.serviceCalls.getRequestCounts();
			$("#taResubmitComments").val("");
			if (isSuccess) {
				rm.ui.ribbon.delayedRefresh();
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showSuccess('Request(s) resubmitted successfully.');
			}
			else {
				rm.ui.messages.addError('Failed to resubmit one or more requests. Hover over error indicator for more details.');
				rm.ui.ribbon.refresh();
			}
		});
	},
	viewQueryDetails: function () {
		var requestId = rm.grid.getSelectedIds(subRqNs.gridSelector);
		var rowData = rm.grid.rowData.getById(subRqNs.gridSelector, requestId);
		var siteName = (rowData.SponsorSiteName == null || rowData.SponsorSiteName == "") ? rowData.SponsorSiteName : rowData.SponsorSiteName + " - ";
		var piName = (rowData.PrincipalInvestigator == null || rowData.PrincipalInvestigator == "") ? rowData.PrincipalInvestigator : rowData.PrincipalInvestigator + " - ";
		var countryCode = (rowData.CountryCode == null || rowData.CountryCode == "") ? "Global - " : rowData.CountryCode + " - ";

		var title = countryCode + siteName + piName + rowData.ResourceType;

		var queryDiv = "queryDetailsDiv";
		rm.utilities.addDivToDomIfNotPresent(queryDiv);
		rm.ajax.serverPageAsyncGet("/_Layouts/SPUI/Requests/QueryDetails.aspx?requestId=" + requestId, {}, function (data) {
			rm.ui.dialog.showModal("#" + queryDiv, title, data, false, 400, 400);
		});
	},
	editMultipleRequests: function () {
		var expiredReqResponse = $.rm.requestCommon.isExpiredRequestSelected(subRqNs.gridSelector);
		if (expiredReqResponse.ContainsValidationErrors) {
			var htmlMessage = "<div>One or more request(s) cannot be edited<br><br></div><table class='validationTable'><tr class='headerRow'><td>Request Id</td><td valign='top'>Reason</td></tr>";
			$.each(expiredReqResponse.ValidationErrors, function (index, message) {
				htmlMessage += "<tr><td>" + message.Key + "</td><td>" + message.Value + "</td></tr>";
			});
			htmlMessage += "</table>";
			rmCommon.showDialogWithOkButton("Request validation", htmlMessage);
		}
		else if ($.rm.requestCommon.isGenericRequestSelected(subRqNs.gridSelector)) {
			var response = subRqNs.checkGenericRequestStageCount($(subRqNs.gridSelector).getGridParam('selarrrow'));
			if (response.ContainsValidationErrors) {
				var htmlMessage = "<div>Requests cannot be edited as they do not have the same number of stages<br><br></div><table class='validationTable'><tr class='headerRow'><td>Request Id</td><td>Stage Count</td></tr>";
				$.each(response.ValidationErrors, function (index, message) {
					htmlMessage += "<tr><td>" + message.Key + "</td><td>" + message.Value + "</td></tr>";
				});
				htmlMessage += "</table>";
				rmCommon.showDialogWithOkButton("Requests calculator stage count validation", htmlMessage);
			}
			else {
				$.rm.requestCommon.ModifyMultipleRequests(GetRmPageLinkId(), subRqNs.gridSelector, "searchCriteria");
			}
		}
		else {
			$.rm.requestCommon.ModifyMultipleRequests(GetRmPageLinkId(), subRqNs.gridSelector, "searchCriteria");
		}
	},
	getResourceTypesFromSelectedRequests: function () {
		var selectedRequestIds = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		var selectedResourceTypeIds = [];

		selectedRequestIds.forEach(function (requestId) {
			var rowData = rm.grid.rowData.getById(subRqNs.gridSelector, requestId);
			if (selectedResourceTypeIds.find(function (resourceTypeId) { return resourceTypeId == rowData.ResourceTypeId; }) == null) {
				selectedResourceTypeIds.push(rowData.ResourceTypeId);
			}
		});

		return selectedResourceTypeIds;
	},
	isProposalRequestSelected: function () {
		var proposalRequestSelected = false;
		var selectedRequestIds = rm.grid.getSelectedIdArray(subRqNs.gridSelector);

		for (var index = 0; index < selectedRequestIds.length; index++) {
			if (rm.grid.rowData.getById(subRqNs.gridSelector, selectedRequestIds[index]).RequestTypeId == RequestType_E.Proposal) {
				proposalRequestSelected = true;
				break;
			}
		}
		return proposalRequestSelected;
	},
	requestWithFteErrorSelected: function () {
		var requestWithFteErrorSelected = false;
		var selectedRequestIds = rm.grid.getSelectedIdArray(subRqNs.gridSelector);

		for (var index = 0; index < selectedRequestIds.length; index++) {
			if (rm.grid.rowData.getById(subRqNs.gridSelector, selectedRequestIds[index]).hasFTEError) {
				requestWithFteErrorSelected = true;
				break;
			}
		}
		return requestWithFteErrorSelected;
	},
	isDteDependentResoruceType: function (resourceTypeId) { return ResourceTypeDetails[resourceTypeId].DteCheckRequired; },
	requestsSelectedThatPreventAssignmentBecauseOfDteMismatch: function () {
		var requestsSelectedThatPreventAssignmentBecauseOfDteMismatch = false;
		var selectedRequestIds = rm.grid.getSelectedIdArray(subRqNs.gridSelector);

		for (var index = 0; index < selectedRequestIds.length; index++) {
			var rowData = rm.grid.rowData.getById(subRqNs.gridSelector, selectedRequestIds[index]);
			if (rowData.HasRmPpmDteMismatch && subRqNs.isDteDependentResoruceType(rowData.ResourceTypeId)) {
				requestsSelectedThatPreventAssignmentBecauseOfDteMismatch = true;
				break;
			}
		}
		return requestsSelectedThatPreventAssignmentBecauseOfDteMismatch;
	},
	getProjectIdsFromSelectedRequests: function () {
		var selectedRequestIds = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		var selectedProjectIds = [];

		selectedRequestIds.forEach(function (requestId) {
			var rowData = rm.grid.rowData.getById(subRqNs.gridSelector, requestId);
			if (selectedProjectIds.find(function (projectId) { return projectId == rowData.ProjectId; }) == null) {
				selectedProjectIds.push(rowData.ProjectId);
			}
		});

		return selectedProjectIds;
	},
	getAssignedResourceIdsFromSelectedRequests: function () {
		var selectedRequestIds = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
		var assignedResourceIds = [];
		selectedRequestIds.forEach(function (requestId) {
			var rowData = rm.grid.rowData.getById(subRqNs.gridSelector, requestId);
			if (assignedResourceIds.find(function (assignedResourceId) { return assignedResourceId == rowData.AssignedResource.Id; }) == null) {
				assignedResourceIds.push(rowData.AssignedResource.Id);
			}
		});
		return assignedResourceIds;
	},
	createBackfill: function () {
		if (subRqNs.requestsSelectedThatPreventAssignmentBecauseOfDteMismatch()) {
			alert(Resources.PpmRmDteMismatchPreventsAssignmentAndBackfill.replace("{0}", "backfilled"));
		}
		else {
			var selectedrows = rm.grid.getSelectedIdArray(subRqNs.gridSelector);
			var resourceTypeId = null;
			$.validationHelper.GetCustomeMilestoneStatus(selectedrows.join(","), "", false, false);

			if (!$.validationHelper.isAnyMilestoneDeactivated) {
				var requestWithFteErrorSelected = subRqNs.requestWithFteErrorSelected();
				var proposalRequestSelected = subRqNs.isProposalRequestSelected();
				var hasAccessToAssignRequests = subRqNs.hasAccessToAssignRequest();
				if (hasAccessToAssignRequests && requestWithFteErrorSelected) {
					alert("You have selected one or more requests with FTE Allocation Error. These requests cannot be assigned. If you want to assign a resource, unselect request(s) with FTE allocation error and try again. If you do not want to assign a resource during backfill process, you can continue with the current selection.");
				}
				else if (proposalRequestSelected) {
					alert("You have selected one or more proposal requests. Proposal requests cannot be assigned from Submitted Request page. If you want to assign a resource, unselect proposal request(s) and try again. If you do not want to assign a resource during backfill process, you can continue with the current selection.");
				}
				var allowBooking = hasAccessToAssignRequests && !proposalRequestSelected && !requestWithFteErrorSelected;
				if (allowBooking) {
					var selectedResourceTypeIds = subRqNs.getResourceTypesFromSelectedRequests();
					allowBooking = selectedResourceTypeIds.length == 1;
					resourceTypeId = (allowBooking ? selectedResourceTypeIds[0] : null);
				}

				var selectedProjectIds = subRqNs.getProjectIdsFromSelectedRequests();
				var singleProjectSelected = (selectedProjectIds.length == 1);
				var projectId = singleProjectSelected ? selectedProjectIds[0] : -1;
				var assignedResourceIds = subRqNs.getAssignedResourceIdsFromSelectedRequests();

				permBfNs.showControl(subRqNs.gridSelector, "Resource", selectedrows, allowBooking, resourceTypeId, singleProjectSelected, projectId, assignedResourceIds[0]);
			}
		}
	},
	isBackfillRequestPage: function () { return (GetRmPageLinkId() == RmPageLink_E.BackfillRequests); },
	isQueriedRequestPage: function () { return (GetRmPageLinkId() == RmPageLink_E.QueriedRequests); },
	showProposalResourceColumn: function (rmPageLinkId) {
		return (rmPageLinkId == RmPageLink_E.SubmittedRequests ||
			rmPageLinkId == RmPageLink_E.UnassignedSubmittedRequests ||

			rmPageLinkId == RmPageLink_E.OverDue_DirectReport_SubmittedRequests ||
			rmPageLinkId == RmPageLink_E.OverDue_All_SubmittedRequests ||

			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_All_Submitted ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_All_Monitoring ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_All_Ssv ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Submitted ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Monitoring ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Ssv
		);
	},
	saveSingleRequest: function (gridSelector, rowId) {
		rm.ui.messages.clearAllMessages();
		var startDate = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "StartDate"));
		var stopDate = $(rm.grid.getControlFromEditRow(gridSelector, rowId, "StopDate"));

		if (rm.date.isValidDate(startDate.val(), true) &&
			rm.date.isValidDate(stopDate.val(), true)) {
			var rowToSave = rm.grid.getUpdatedRowDataById(gridSelector, rowId);
			subRqNs.saveRequests([rowToSave], 1);
		}
		else {
			rm.ui.messages.addError("Please fix the errors and click Save again.");
		}
	},
	saveRequests: function (rowsToSave, totalRowsInEditMode) {
		if (rowsToSave.length > 0) {
			rm.ajax.requestSvcAsyncPost("UpdateRequestStartStopDates", { requestDataList: rowsToSave }, function (serviceResponse) {
				var successCount = 0;
				$.each(serviceResponse.EntityStatus, function (index, response) {
					if (response.IsSuccessful) {
						successCount++;
						rm.grid.cancelRowEditMode(subRqNs.gridSelector, response.EntityId);
						//Give it a split second so the row can go back to read-only mode
						setTimeout(function () {
							var rowData = rm.grid.rowData.getById(subRqNs.gridSelector, response.EntityId);
							rowData.StartDate = response.Output.StartDateQ;
							rowData.StopDate = response.Output.StopDateQ;
							rowData.StartDateStatus.connected = response.Output.StartDateStatus;
							rowData.StopDateStatus.connected = response.Output.StopDateStatus;

							$(subRqNs.gridSelector).setCell(response.EntityId, "StartDate", response.Output.StartDateQ, "", "", true);
							$(subRqNs.gridSelector).setCell(response.EntityId, "StopDate", response.Output.StopDateQ, "", "", true);
							$(subRqNs.gridSelector).setCell(response.EntityId, "NeedByDate", response.Output.NeedByDateQ, "", "", true);

							rm.grid.cancelRowEditMode(subRqNs.gridSelector, response.EntityId);
							//$(subRqNs.gridSelector).setCell(response.EntityId, "Message", " ");
							rm.grid.clearSingleGridRowError(subRqNs.gridSelector, "Message", response.EntityId)

							rm.ui.ribbon.refresh();
						}, 50);
					} else {
						rm.validation.processErrorMessages(response.Errors, subRqNs.gridSelector, "IconColumn");
					}
				});

				if (successCount === 0) {
					rm.ui.messages.addError("Errors found.  Nothing saved.");
				}
				else if (rowsToSave.length === successCount) {
					if (rowsToSave.length !== totalRowsInEditMode) {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showWarningWithCloseButton("Data saved with some errors found.");
					}
					else {
						rm.ui.messages.clearAllMessages();
						rm.ui.messages.showSuccess(Resources.AllDataSavedSuccessfully);
					}
				}
				else {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showWarningWithCloseButton("Data saved with some errors found.");
				}
			});
		}
	},
	getMandatoryColumns: function () {
		return [
			{
				name: '', label: '', index: 'actions', frozen: true,
				formatter: 'actions', editable: false, sortable: false, resizable: false,
				fixed: true, width: 50, search: false,
				formatoptions: {
					keys: true, editbutton: false, delbutton: false,
					afterRestore: function (rowid) {
						rm.ui.ribbon.delayedRefresh();
						rm.grid.scrollTableBodyToFixAlignmentIssue(subRqNs.gridSelector);
					},
				}
			},
			rm.grid.standardColumns.getMessageColumn()
		];
	},
	getFullColumnModelList: function () {
		return [
			{ name: 'IconColumn', index: 'IconColumn', label: 'Request Status <br />Indicator', width: 130, search: true, sortable: false, hidden: false, stype: 'select', searchoptions: { sopt: ['eq'], value: ":All;" + subRqNs.getFilterValues() } },
			rm.grid.standardColumns.getNotesColumn(),
			rm.grid.standardColumns.getFteColumn(true),
			rm.grid.standardColumns.getEditableDateColumn('StartDate', 'StartDate', (subRqNs.isBackfillRequestPage() ? 'Backfill<br>' : '') + 'Start Date', true, 'StopDate', subRqNs.gridSelector),
			rm.grid.standardColumns.getEditableDateColumn('StopDate', 'StopDate', (subRqNs.isBackfillRequestPage() ? 'Backfill<br>' : '') + 'Stop Date', false, subRqNs.gridSelector),
			{ name: 'Region', index: 'Region', label: 'Region', width: 150, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Country', index: 'Country', label: 'Country', width: 70, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'CountryRegion', index: 'CountryRegion', label: 'Country<br />Region', width: 70, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Program', index: 'Program', label: 'Program', width: 65, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Customer', index: 'Customer', label: 'Customer', width: 70, search: true, sortable: false, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project<br/>Code', width: 70, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'ProjectDteType', index: 'ProjectDteType', label: 'RBM Project', width: 80, classes: 'ui-ellipsis', search: true, stype: 'select', searchoptions: { value: rm.grid.filterOptions.dteType } },
			{ name: 'RequestBlinded', index: 'RequestBlinded', label: 'Request<br />Blinded', width: 100, classes: 'ui-ellipsis', search: true, stype: 'select', searchoptions: { value: rm.grid.filterOptions.blinded } },
			{ name: 'ProjectOrganizationalUnit', index: 'ProjectOrganizationalUnit', label: 'Project<br/>Organizational Unit', width: 124, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'SpmClass', index: 'SpmClass', label: 'SPM Class', width: 70, search: true, sortable: false, stype: 'select', searchoptions: { sopt: ['eq'], value: rm.grid.filterOptions.getCompetencyBand() } },
			{ name: 'ResourceType', index: 'ResourceType', label: 'Resource<br />Request Type', width: 100, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Resource', index: 'Resource', label: 'Resource<br/>Name', width: 80, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'ProposalResource', index: 'ProposalResource', label: 'Proposal<br/>Resource Name', width: 111, hidden: !subRqNs.showProposalResourceColumn(GetRmPageLinkId()), classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'NeedByDate', index: 'NeedByDate', label: 'Need By<br/> Date', width: 80, searchoptions: { attr: { maxlength: 11 } } },
			{ name: 'CreatedBy', index: 'CreatedBy', label: 'Created By', sortable: true, search: true, hidden: subRqNs.isQueriedRequestPage(), searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'SiteStatus', index: 'SiteStatus', label: 'Site Status', width: 110, searchoptions: { attr: { maxlength: 100 } } },
			{ name: 'SponsorSiteName', index: 'SponsorSiteName', label: 'Sponsor<br/>Site ID', width: 50, searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'PrincipalInvestigator', index: 'PrincipalInvestigator', label: 'PI', width: 50, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'Location', index: 'Location', label: 'Location', width: 70, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'VisitTypeName', index: 'VisitTypeName', label: 'Visit<br />Type', width: 60, classes: 'ui-ellipsis', searchoptions: { attr: { maxlength: 255 } } },
			{ name: 'SSVType', index: 'SSVType', label: 'SSV Type', width: 70 },
			{ name: 'IMDate', index: 'IMDate', label: 'IM Date', width: 120, formatter: $.qGrid.showDateWithConnectIcon, align: 'right', searchoptions: { attr: { maxlength: 11 } } },
			{ name: 'CRADate', index: 'CRADate', label: 'CRA Training<br/> Date', width: 120, formatter: $.qGrid.showDateWithConnectIcon, align: 'right', searchoptions: { attr: { maxlength: 11 } } },
			{ name: 'RequestBudgeted', index: 'RequestBudgeted', label: 'Request<br />Budgeted?', width: 80, classes: 'ui-ellipsis', stype: 'select', searchoptions: { value: rm.grid.filterOptions.yesNo } },
			{ name: 'RequestIdForFilter', index: 'RequestIdForFilter', label: 'RequestId', width: 70, searchoptions: { attr: { maxlength: 10 } } },
			{ name: 'DateSubmitted', index: 'DateSubmitted', label: 'Submitted<br />Date', width: 80, hidden: subRqNs.isBackfillRequestPage(), searchoptions: { attr: { maxlength: 11 } } },
			{ name: 'ProjectId', index: 'ProjectId', label: 'ProjectId', hidden: true },
			{ name: 'SiteId', index: 'SiteId', label: 'SiteId', hidden: true },
			{ name: 'MonthlyFTESSVAttrCountryLevel', index: 'MonthlyFTESSVAttrCountryLevel', label: 'MonthlyFTESSVAttrCountryLevel', search: false, sort: false, editable: false, search: false, hidden: true },

			rm.grid.standardColumns.getFteMonthColumn('CurrentMonthFTE', (new Date()).getMonth()),
			rm.grid.standardColumns.getFteMonthColumn('SecondMonthFTE', (new Date()).getMonth() + 1),
			rm.grid.standardColumns.getFteMonthColumn('ThirdMonthFTE', (new Date()).getMonth() + 2),
			rm.grid.standardColumns.getFteMonthColumn('FourthMonthFTE', (new Date()).getMonth() + 3),
			rm.grid.standardColumns.getFteMonthColumn('FifthMonthFTE', (new Date()).getMonth() + 4),
			rm.grid.standardColumns.getFteMonthColumn('SixthMonthFTE', (new Date()).getMonth() + 5)
		];
	},
	getGridIdFromRmPageLinkId: function (rmPageLinkId) {
		if (rmPageLinkId == RmPageLink_E.SubmittedRequests ||
			rmPageLinkId == RmPageLink_E.OverDue_All_SubmittedRequests ||
			rmPageLinkId == RmPageLink_E.OverDue_DirectReport_SubmittedRequests ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_All_Submitted ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Submitted ||
			rmPageLinkId == RmPageLink_E.UnassignedSubmittedRequests) {
			return DataGrid.SubmittedRequests;
		}
		else if (rmPageLinkId == RmPageLink_E.BackfillRequests ||
			rmPageLinkId == RmPageLink_E.OverDue_All_BackfillRequests ||
			rmPageLinkId == RmPageLink_E.OverDue_DirectReport_BackfillRequests ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_All_Backfill ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Backfill ||
			rmPageLinkId == RmPageLink_E.UnsubmittedBackfillRequests_All ||
			rmPageLinkId == RmPageLink_E.UnsubmittedBackfillRequests_DirectReports) {
			return DataGrid.UnsubmittedBackfillRequests;
		}
		else if (rmPageLinkId == RmPageLink_E.QueriedRequests ||
			rmPageLinkId == RmPageLink_E.OverDue_All_QueriedRequests ||
			rmPageLinkId == RmPageLink_E.OverDue_DirectReport_QueriedRequests ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_All_Queried ||
			rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Queried) {
			return DataGrid.QueriedRequests;
		}
	},
	buildGrid: function (rmPageLinkId) {
		var handleUserPreferencesResponse = function (userColumnPreferences) {
			userColumnPreferences.UiColumnConfiguration = subRqNs.getFullColumnModelList();
			var columnModel = rm.grid.getFinalColumnModelFromFullColumnListAndUserColumnPreferences(subRqNs.getFullColumnModelList(), userColumnPreferences, subRqNs.getMandatoryColumns());
			subRqNs.columnModelUsedByGrid = columnModel;
			subRqNs.buildDynamicGrid(rmPageLinkId, columnModel, userColumnPreferences);
		};
		rm.serviceCalls.getRmUserDataGridColumnPreferences(subRqNs.getGridIdFromRmPageLinkId(rmPageLinkId), handleUserPreferencesResponse)
	},
	buildDynamicGrid: function (rmPageLinkId, columnModel, userColumnPreferences) {
		var gridPost = gridPost = { sidx: "Region", sord: "asc", page: 1, };
		var projectCode = rm.queryString.getValue("ProjectCode");
		var protocolNumber = rm.queryString.getValue("Protocol");

		if (projectCode != null) {
			gridPost = {
				ProjectCode: projectCode,
				Protocol: protocolNumber
			};
			setTimeout(function () {
				for (property in gridPost) {
					$("#gs_" + property).val(gridPost[property]);
				}
			}, 200);
		}
		else {
			gridPost = rm.grid.getGridFilterFromCookieAndSetGridFilterTextboxes(subRqNs.gridSelector, rm.constants.keys.cookie.SubReqGridFilter);
		}		
		rm.grid.showGridToolsV2("#gridToolsParent", rmPageLinkId, subRqNs.getGridIdFromRmPageLinkId(rmPageLinkId), subRqNs.gridSelector, userColumnPreferences,gridPost.selectedRowFilterId,true);
		

		$(subRqNs.gridSelector).jqGrid({
			url: rm.ajax.requestSvcUrl + "GetSubmittedRequests",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			postData: gridPost,
			loadui: "block",
			loadonce: false,
			pager: '#listPager',
			autowidth: false,
			shrinkToFit: false,
			height: rm.ui.getMaxGridHeight() + 15,
			width: rm.ui.getMaxGridWidth() - 50,
			multiselect: true,
			colModel: columnModel,
			page: gridPost.page,
			sortname: gridPost.sidx,
			sortorder: gridPost.sord,
			multipleSearch: true,
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			ondblClickRow: function (id) {
				var rowJson = $.qGrid.getGridRowDataById($.qGrid.getGridUserData(subRqNs.gridSelector).Records, id);

				if (rowJson.IsGeneric == true) {
					window.onbeforeunload = null
					subRqNs.handleCalculatorIconClick(id);
				}
				else {
					if (rm.serviceCalls.isRequestValid(id, true, GetRmPageLinkId())) {
						if (subRqNs.isProposalReqeustWithQipData(id)) {
							subRqNs.handleCalculatorIconClick(id);
						}
						else {
							var areAllEditableColumnsPresent = rm.grid.areAllEditableColumnsPresent(subRqNs.getFullColumnModelList(), subRqNs.columnModelUsedByGrid, true);

							if (areAllEditableColumnsPresent) {
								rm.grid.editRow(subRqNs.gridSelector, id);
								rm.grid.attachCustomSaveHandler(subRqNs.gridSelector, id, subRqNs.saveSingleRequest);
								rm.ui.ribbon.delayedRefresh();
							}
						}
					}
				}
			},
			onSelectRow: function (id, status, e) {
				rm.ui.messages.clearAllMessages();
				rm.ui.ribbon.delayedRefresh();
				if (!status) {
					rm.grid.clearSingleGridRowError(subRqNs.gridSelector, "Message", id);
				}
			},
			onSelectAll: function (rowIdxArray, sts) {
				rm.ui.messages.clearAllMessages();
				rm.ui.ribbon.delayedRefresh();
			},
			onPaging: function () {
				rm.ui.ribbon.delayedRefresh();
			},
			serializeRowData: function (postData) {
				return JSON.stringify(postData);
			},
			serializeGridData: function (postData) {
				var data = { RmPageLink: rmPageLinkId };
				postData.selectedRowFilterId = rm.grid.getGridToolFilterDropdownValueFromControlOrCookie(subRqNs.gridSelector, rm.constants.keys.cookie.SubReqGridFilter);
				rm.cookie.setValue(rm.constants.keys.cookie.SubReqGridFilter, postData);
				return rm.grid.serializeGridData(postData, data);
			},
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("list"); },
			gridComplete: function () {
				subRqNs.freezeColumnsAndBindInfo();
				rm.utilities.delayedBindInfoOnGridFteIconColumn();
			},
			loadComplete: function (data) {
				rm.grid.addTitlesOnIconColumn();
				rm.grid.rowData.attachAllRowsData(subRqNs.gridSelector, data);
				rm.ui.notes.bindNotesIconClick();
				rm.ui.tabs.removeAllTabs("#existingNotes");

				if (gridPost && gridPost.selectedRequestId) {
					$(subRqNs.gridSelector).jqGrid('setSelection', gridPost.selectedRequestId);
					rm.cookie.removeProperty(rm.constants.keys.cookie.SubReqGridFilter, "selectedRequestId");
					delete gridPost.selectedRequestId;
					delete $(subRqNs.gridSelector).getGridParam("postData").selectedRequestId;
					$(subRqNs.gridSelector).setGridParam({ postData: gridPost });
				}

				var rowIds = $(subRqNs.gridSelector).getDataIDs();
				$.each(rowIds, function (index, rowId) {
					rm.qtip.showError("#errIcon_" + rowId, $("#errIcon_" + rowId).attr("title"))
				});

				rm.ui.messages.clearAllMessages();
				rm.ui.ribbon.delayedRefresh();
			},
			resizeStop: function (newWidth, columnIndex) {
				//Becasue grid allows multiselect, it adds a checkbox column as a first column. To find out the column index in the colModel, subtract 1.
				//Not required for grids that don't show checkbox column
				columnIndex -= 1;
				var dataGridColumnId = rm.grid.getDataGridColumnIdFromColIndexColModelAndUserPref(columnIndex, columnModel, userColumnPreferences);
				rm.grid.saveDataGridColumnWidthPreference(newWidth, subRqNs.getGridIdFromRmPageLinkId(rmPageLinkId), dataGridColumnId, subRqNs.gridSelector);
			}
		});
		//.jqGrid('filterToolbar', {
		//	beforeSearch: function () {
		//		rm.grid.autoSaveFilterOnGridSearch(subRqNs.gridSelector, rm.constants.keys.cookie.SubReqGridFilter);
		//	}
		//});
		$(subRqNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},
	freezeColumnsAndBindInfo: function () {
		if (!subRqNs.frozenColumnAlreadyBound) {
			//mrfNs.onFrozenColumnsBound();
			rm.grid.bindclearGridToolFilterDropdownGridSearch(subRqNs.gridSelector);
			subRqNs.frozenColumnAlreadyBound = true;
			//freezing columns involve rebuilding the grid. Once grid is rebuilt, we need to rebing the information qtip.
			rm.grid.delayedRebindFrozenColumns(subRqNs.gridSelector);
			setTimeout(function () {
				subRqNs.setQtipOnGridHeaders();
				rm.grid.getGridFilterFromCookieAndSetGridFilterTextboxes(subRqNs.gridSelector, rm.constants.keys.cookie.SubReqGridFilter);
			}, 100);
		}
		rm.grid.scrollTableBodyToFixAlignmentIssue(subRqNs.gridSelector);
	},
	setQtipOnGridHeaders: function () {
		var rmPageLink = GetRmPageLinkId();
		rm.qtip.showInfoOnGridColumn("#list_IconColumn", "Request Status Indicator.");
		rm.qtip.showInfoOnGridColumn("#list_Notes", "Use to add/view comments about the particular project/request.");
		rm.qtip.showInfoOnGridColumn("#list_FTE", "Provides the details of the resource request need and takes into account the country working hours and % utilization.");
		rm.qtip.showInfoOnGridColumn("#list_StartDate", "The date when the work begins for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#list_StopDate", "The date when the work ends for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#list_Country", "The country may be the preferred resource location or the country where the study is taking place. The country will be reset for non-site specific resource requests when a resource is hard booked outside the request country.");
		rm.qtip.showInfoOnGridColumn("#list_CountryRegion", "The region within the country.");
		rm.qtip.showInfoOnGridColumn("#list_Program", "Program.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectCode", "Project Code.");
		rm.qtip.showInfoOnGridColumn("#list_Protocol", "Protocol.");
		rm.qtip.showInfoOnGridColumn("#list_ProjectDteType", "RBM Project");
		rm.qtip.showInfoOnGridColumn("#list_ResourceTypeId", "The type of resource needed to fill a project need.");
		rm.qtip.showInfoOnGridColumn("#list_ResourceType", "Resource Request Type.");
		rm.qtip.showInfoOnGridColumn("#list_NeedByDate", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn("#list_SiteStatus", "The site status from CTMS/InnTrax.");
		rm.qtip.showInfoOnGridColumn("#list_SponsorSiteName", "Sponsor Site ID.");
		rm.qtip.showInfoOnGridColumn("#list_PrincipalInvestigator", "Principal Investigator.");
		rm.qtip.showInfoOnGridColumn("#list_Location", "Location of the site.");
		rm.qtip.showInfoOnGridColumn("#list_Resource", "The name of the Resource assigned to the request.");
		rm.qtip.showInfoOnGridColumn("#list_SSVType", "Visit description (On-site or Phone) applicable to SSV requests.");
		rm.qtip.showInfoOnGridColumn("#list_IMDate", "Investigator Meeting Date.");
		rm.qtip.showInfoOnGridColumn("#list_CRADate", "CRA Training Date.");
		rm.qtip.showInfoOnGridColumn("#list_RequestBudgeted", "Is the request budgeted-yes/no?");
		rm.qtip.showInfoOnGridColumn("#list_RequestIdForFilter", "Request Id.");
		rm.qtip.showInfoOnGridColumn("#list_DateSubmitted", "Date request was submitted");
		rm.qtip.showInfoOnGridColumn("#list_ProjectOrganizationalUnit", "Project Organizational Unit.");
		rm.qtip.showInfoOnGridColumn("#list_RequestBlinded", "Does this Request require a Blinded or Unblinded Resource?");
		rm.qtip.showInfoOnGridColumn("#list_CurrentMonthFTE", "Projected future FTE - updated every 24 hours.");
		rm.qtip.showInfoOnGridColumn("#list_SecondMonthFTE", "Projected future FTE - updated every 24 hours.");
		rm.qtip.showInfoOnGridColumn("#list_ThirdMonthFTE", "Projected future FTE - updated every 24 hours.");
		rm.qtip.showInfoOnGridColumn("#list_FourthMonthFTE", "Projected future FTE - updated every 24 hours.");
		rm.qtip.showInfoOnGridColumn("#list_FifthMonthFTE", "Projected future FTE - updated every 24 hours.");
		rm.qtip.showInfoOnGridColumn("#list_SixthMonthFTE", "Projected future FTE - updated every 24 hours.");
		rm.qtip.showInfoOnGridColumn("#list_ProposalResource", "The name of the Resource assigned to the original hard booked Proposal Request, before the project was awarded.");
		rm.qtip.showInfoOnGridColumn("#list_VisitTypeName", "Visit description or reason for the visit. Applicable to some request types.");
		rm.qtip.showInfoOnGridColumn("#list_CreatedBy", "Person who created the Backfill request.");

		if (rmPageLink == RmPageLink_E.SubmittedRequests) {
			rm.qtip.showInfoOnGridColumn("#list_Resource", "The name of the Resource assigned to the request. Soft-booked requests, requests returned for query and unsubmitted backfill requests will not appear in this list.");
		}
		else if (rmPageLink == RmPageLink_E.BackfillRequests) {
			rm.qtip.showInfoOnGridColumn("#list_StartDate", "The date when the new resource will replace the old assigned resource.");
			rm.qtip.showInfoOnGridColumn("#list_StopDate", "The date when the new resource stops working on the assigned project.");
			rm.qtip.showInfoOnGridColumn("#list_Resource", "Resource Name.");
		}
	},
	handleBackfillDeleteLinkClick: function (event) {
		event.stopPropagation();
		event.preventDefault();

		var lnkObj = $(this);
		var postData = { requestId: lnkObj.attr("requestId"), backfillDeleteOption: lnkObj.attr("backfillDeleteOption") };

		if (postData.backfillDeleteOption == BackfillDeleteOption_E.None) {
			if (lnkObj.closest(".validationTable").find("tr").length == 2) {
				$(lnkObj.closest("div.ui-dialog-content")).dialog("close");
			}
			$("#img" + postData.requestId + "_frz").qtip("hide");
			$("#img" + postData.requestId).qtip("hide");
			rm.grid.clearSingleGridRowError(subRqNs.gridSelector, "Message", postData.requestId);
			lnkObj.closest(".validationTable tr").remove();
		}
		else {
			rm.ajax.requestSvcAsyncPost("DeleteBackfillRequest", postData, function (response) {
				if (response.IsSuccessful) {
					rm.grid.removeRow(subRqNs.gridSelector, response.EntityId);
					if (postData.backfillDeleteOption == BackfillDeleteOption_E.DeleteBackfillAndTermianteParent) {
						rm.grid.removeRow(subRqNs.gridSelector, response.ParentRequestId);
					}
					rm.ui.messages.showSuccess('Request deleted successfully.');
					rm.serviceCalls.getRequestCounts();
				}
				else {
					rm.grid.showErrorIconInMessageColumn(subRqNs.gridSelector, response.EntityId, 'Message', response.Message);
				}
			});
		}
	},
	isProposalReqeustWithQipData: function (requestId) {
		var proposalReqeustWithQipData = false;
		rm.ajax.requestSvcSyncGet("IsProposalReqeustWithQipData", { requestId: requestId }, function (data) { proposalReqeustWithQipData = data });
		return proposalReqeustWithQipData;
	},
	checkGenericRequestStageCount: function (requestIds) {
		var returnvalue;
		rm.ajax.requestSvcSyncPost("CheckGenericRequestStageCount", { requestIds: requestIds }, function (data) { returnvalue = data; }, false)
		return returnvalue;
	},
	handleCalculatorIconClick: function (requestId) {
		rm.grid.uncheckAllGridRows(subRqNs.gridSelector);
		rm.grid.checkRowById(subRqNs.gridSelector, requestId);

		setTimeout(function () { subRqNs.editSelectedRequest(); }, 20);
	}
};

function ConnectMeToCountryOnSuccess(response, rowId, column) {
	var d = $.parseJSON(response);
	if (d.IsSuccessful) {
		var rowJson = rm.grid.rowData.getById(subRqNs.gridSelector, rowId);
		rowJson[column + "Status"].connected = GetStatusFromStatusString(d.DateStatus);
		$(subRqNs.gridSelector).setCell(rowId, column, d.QDate, "", "", true);
		if (d.NeedByDate != null) {
			$(subRqNs.gridSelector).setCell(rowId, "NeedByDate", d.NeedByDate, "", "", true);
		}
	}
	else { alert(d.Message); }
}

function ConnectMeToPpmOnSuccess(response, rowId, column) {
	var d = $.parseJSON(response);
	if (d.IsSuccessful) {
		var rowJson = rm.grid.rowData.getById(subRqNs.gridSelector, rowId);
		rowJson[column + "Status"].connected = GetStatusFromStatusString(d.DateStatus);
		$(subRqNs.gridSelector).setCell(rowId, column, d.QDate, "", "", true);
		if (d.NeedByDate != null) {
			$(subRqNs.gridSelector).setCell(rowId, "NeedByDate", d.NeedByDate, "", "", true);
		}
		if (rowJson.ResourceTypeId == ResourceTypeName.Golbal_Budget_Solutions_Lead) {
			var stopDate = getRequestStopDateFromComputedRequestMilestone(rowJson.ResourceTypeId, rowJson.RegionId, d.QDate, $("#" + rowId + "_stopDate"));
			$(subRqNs.gridSelector).setCell(rowId, "StopDate", stopDate, "", "", true);
		}
	}
	else { alert(d.Message); }
}

function getRequestStopDateFromComputedRequestMilestone(resourceTypeId, regionId, startQDateString, stopDateJqElement) {
	var milestoneList = getComputedReqestMilestoneDaysToAdd();
	var stopDate = "";
	$.each(milestoneList, function (index, item) {
		if ((regionId > 0 && item.ResourceTypeId == resourceTypeId && item.RegionId == regionId) || item.ResourceTypeId == resourceTypeId) {
			rm.validation.clearError(stopDateJqElement)
			if (stopDate == "") stopDate = rm.date.addDaysToQdate(startQDateString, item.DaysToAdd);
		}
	});
	return stopDate;
};
var _computedReqestMilestoneDaysToAddFor = null;
function getComputedReqestMilestoneDaysToAdd() {
	if (_computedReqestMilestoneDaysToAddFor == null) {
		$.rm.Ajax_RequestSynchronous("GetAllComputedReqestMilestoneDaysToAdd", {}, function (data) {
			_computedReqestMilestoneDaysToAddFor = data;
		}, true);
	}

	return _computedReqestMilestoneDaysToAddFor;
}
function ConnectMeToCountryOnError(errMsg) { alert(errMsg); }
function ConnectMeToPpmOnError(errMsg) { alert(errMsg); }
//Do not remove following function. It is required by the common code that shows calculator icon in the grid and expects this function to be present here
function HandleCalculatorIconClick(requestId) { subRqNs.handleCalculatorIconClick(requestId); }