﻿$.imageFactory = function ()
{
  this.GetImage = function (id, requestType, resourceType, column, connected)
  {
    switch (requestType * 1.0)
    {
      case (RequestType_E.Permanent):
        if (column == "start" || column == "im" || column == "cra")
        {
          return this.BuildImage(id, column, connected);
        }
        break;
      case (RequestType_E.SSV):
        switch (resourceType * 1)
        {
        	case (ResourceTypeName.Short_term_SWAT_Monitoring_OnSite_Visit):
          break;

        case (ResourceTypeName.Standard_Monitoring):
          if (column == "start" || column == "stop" || column == "cra")
          {
            return this.BuildImage(id, column, connected);
          }
          break;
        }
      default:
        //do nothing
        break;
    }
    return "";

  };

  this.BuildImage = function (id, column, connected)
  {
    if (connected == 1)
    {
      return "<img src='" + this.ConnectedImageSource() + "' " +
              "alt='" + column + id + "' " +
              "title='The values for this date are connected to the country level values.'" +
              " />";
    } else
    {
      return "<img src='" + this.DisconnectedImageSource() + "' " +
              "alt='" + column + id + "' style='cursor: pointer;' " +
              "title='The values for this date are not connected to the country level values.' " +
              "onclick='ConnectMeToCountry(" + id + ",\"" + column + "\");' " +
              " />";
    }
  };

  this.ConnectedImageSource = function ()
  {
    return '/_layouts/SPUI/images/conncted.png';
  };

  this.DisconnectedImageSource = function ()
  {
    return '/_layouts/SPUI/images/reconnect.png';
  };

};
