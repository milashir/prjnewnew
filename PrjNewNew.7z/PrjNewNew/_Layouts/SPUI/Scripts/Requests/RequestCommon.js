﻿$.rm.requestCommon =
{
	BindFTECalculatorClick: function (imageSelector) {
		$(imageSelector).click(function () {
			var image = $(this);
			$.rm.requestCommon.GetReadOnlyCalculatorDetails(image.attr("requestId"), image.attr("divId"));
		});
	},
	GetReadOnlyCalculatorDetails: function (requestId, divId) {
		var isDataAvailable = true;
		var fteReadonlyDiv = $("#" + divId);
		if (fteReadonlyDiv.length == 0) {
			fteReadonlyDiv = $("<div id='" + divId + "' />");
			$('body').append(fteReadonlyDiv);
			isDataAvailable = false;
		}

		if (!isDataAvailable) {
			$.ajax({
			    url: rm.ajax.requestSvcUrl + "GetCalculatorDetails?requestId=" + requestId,
				cache: false,
				success: function (data) {
					fteReadonlyDiv.html(data.Body).dialog({
						modal: true,
						cache: false,
						title: data.Title,
						resizable: false,
						width: data.Width,
						height: data.Height
					});
					setTimeout(function () {
						$.each($(".fteTableTitlesHover"), function (index, element) {
							var jqObj = $(element).find("span");
							rm.qtip.showInfo(jqObj, jqObj.attr("toolTip"));
                        });
                        $.each($(".imgAdhocInfo"), function (index, element) {
                            var jqObj = $(element);
                            rm.qtip.showInfo(jqObj, jqObj.attr("title"));
                        });
						$(".FSILSIFreq1").each(function (index, element) {
							if (element.innerText == "Trad" && $(element).attr('oldtitle') != "Traditional") {
								$(element).removeAttr('oldtitle');
								rm.qtip.showInfo($(element), "Traditional");
							}
						});
						$(".LSILSOFreq2").each(function (index, element) {
							if (element.innerText == "Trad" && $(element).attr('oldtitle') != "Traditional") {
								$(element).removeAttr('oldtitle');
								rm.qtip.showInfo($(element), "Traditional");
							}
						});
					}, 10);
					$.rm.requestCommon.bindQtipToInfoIcons(data.SiteSchedule, data.RequestId);
				}
			});
		}
		else {
			$("#" + divId).dialog("open");
		}
	},

	bindQtipToInfoIcons: function (siteSchedule, requestId) {
		if (siteSchedule) {
			$.each(siteSchedule.FrequencyDates, function (index, element) {
				$.rm.requestCommon.showStartStopDatesWithSource(requestId, element);
			});
		}
	},

	showStartStopDatesWithSource: function (requestId, frequencyDateDetail) {
		var infoValue = "<b>Start Date:</b> " + frequencyDateDetail.StartDate +
						"<br /><b>Start Date Source:</b> " + frequencyDateDetail.StartDateSource +
						"<br /><b>Stop Date:</b> " + frequencyDateDetail.StopDate +
						"<br /><b>Stop Date Source:</b> " + frequencyDateDetail.StopDateSource;

		var iconSelector = "#infoIcon_" + requestId + "_" + frequencyDateDetail.CalculatorType;
		rm.qtip.showInfo(iconSelector, infoValue);
	},

	HasMultiSameProjectRowSelected: function (gridListControlId) {

		var isEnabled = true;
		var projectId = "";
		var resourceTypeId = "";
		var requestTypeId = "";
		var countryId = "";
		var regionId = "";
		var selectedrows = $(gridListControlId).getGridParam('selarrrow');

		if (selectedrows && selectedrows.length > 1) {
			var proposalRequestTypeId = RequestType_E.Proposal;
			var standardMonitoringResourceTypeId = ResourceTypeName.Standard_Monitoring;
			var dteSiteMonitoringResourceTypeId = ResourceTypeName.DTESite_Monitoring;
			var dtePharmacyMonitoringResourceTypeId = ResourceTypeName.DTEPharmacy_Monitoring;
			var japanCountryId = rmConstants.JapanCountryId;
			for (var i = 0; i < selectedrows.length; i++) {
				var rowJson = rm.grid.rowData.getById(gridListControlId, selectedrows[i]);
				if (rowJson.ResourceTypeId == ResourceTypeName.SSVMonitoring_CountrySpecific) {
					isEnabled = false;
					break;
				}
				else if (projectId == "") {
					projectId = rowJson.ProjectId;
					resourceTypeId = rowJson.ResourceTypeId;
					requestTypeId = rowJson.RequestTypeId;
					countryId = rowJson.CountryId;
					regionId = rowJson.RegionId;
				}
				else if (projectId != rowJson.ProjectId
							|| resourceTypeId != rowJson.ResourceTypeId
							|| ((requestTypeId == proposalRequestTypeId && rowJson.RequestTypeId != proposalRequestTypeId) || (requestTypeId != proposalRequestTypeId && rowJson.RequestTypeId == proposalRequestTypeId))
							|| (requestTypeId != proposalRequestTypeId && rowJson.RequestTypeId != proposalRequestTypeId
									&& resourceTypeId == rowJson.ResourceTypeId && (resourceTypeId == standardMonitoringResourceTypeId || resourceTypeId == dteSiteMonitoringResourceTypeId || resourceTypeId == dtePharmacyMonitoringResourceTypeId)
									&& ((countryId == japanCountryId && rowJson.CountryId != japanCountryId)
									|| (countryId != japanCountryId && rowJson.CountryId == japanCountryId))
									)
							|| (regionId != rowJson.RegionId && ResourceTypeDetails[resourceTypeId].IsRegionBased)
					) {
					isEnabled = false;
					break;
				}
			}
		}
		else {
			isEnabled = false;
		}

		return isEnabled;
	},

	ModifyMultipleRowsEnabled: function (gridListControlId, modifyRequestRibbonControlId, modifyRequestsRibbonControlId) {
		var selectedrows = $(gridListControlId).getGridParam('selarrrow');
		if (selectedrows && selectedrows.length > 1) {
			$(modifyRequestsRibbonControlId).show();
			$(modifyRequestRibbonControlId).hide();
		} else {
			$(modifyRequestsRibbonControlId).hide();
			$(modifyRequestRibbonControlId).show();
		}
		return $.rm.requestCommon.HasMultiSameProjectRowSelected(gridListControlId);
	},

	ModifySingleRequest: function (rmPageLinkId) {
		//implement single req edit here
	},

	ModifyMultipleRequests: function (rmPageLinkId, gridSelector, cookieKey) {
		var mygrid = $(gridSelector);
		var gridState = { searchCriteria: mygrid.getGridParam("postData") };
		$.cookie(cookieKey, JSON.stringify(gridState));

		$("#rmPageLinkId").val(rmPageLinkId);
		$("#selectedRequestIds").val(rm.grid.getSelectedIds(gridSelector));
		var action = "/_layouts/SPUI/Requests/RedirectToEditMultipleRequests.aspx?source=submitted&rmPageLink=" + rmPageLinkId;
		$("#aspnetForm").attr("action", action);
		$("#aspnetForm").submit();
	},

	getToolTipText: function (className) {
		var tooltiptext = $(className).text();
		return tooltiptext.toLowerCase() == 'trad' ? 'Traditional' : "";
	},

	isGenericRequestSelected: function (gridSelector) {
		var isGeneric = false;

		var rowIds = $(gridSelector).getGridParam('selarrrow');
		if (rowIds && rowIds.length > 0) {
			var rowData = rm.grid.rowData.getById(gridSelector, rowIds[0]);
			isGeneric = rowData.IsGeneric;
		}

		return isGeneric;
	},

	isExpiredRequestSelected: function (gridSelector) {
		var response;
		$.rm.Ajax_RequestSynchronous("CheckRequestValidity", { requestIdList: $(gridSelector).getGridParam('selarrrow') }, function (data) { response = data; }, false)
		return response;
	}
};


