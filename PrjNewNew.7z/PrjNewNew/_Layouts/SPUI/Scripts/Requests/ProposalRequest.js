﻿/// <reference path="../common/rmhelper.js" />
$.Proposal = {
	isAddButtonEnabled: false,
	isRemoveButtonEnabled: false,
	isSubmitButtonEnabled: false,
	isUpdateButtonEnabled: false,
	isSaveProposalButtonEnabled: false,
	isCancelButtonEnabled: false,
	isCancelUpdateButtonEnabled: false,
	selectedRequestId: -1,
	projectId: -1,

	IsAddButtonEnabled: function () { return $.Proposal.isAddButtonEnabled; },
	IsRemoveButtonEnabled: function () { return $.Proposal.isRemoveButtonEnabled; },
	IsSubmitButtonEnabled: function () { return $.Proposal.isSubmitButtonEnabled; },
	IsUpdateButtonEnabled: function () { return $.Proposal.isUpdateButtonEnabled; },
	IsSaveProposalButtonEnabled: function () { return $.Proposal.isSaveProposalButtonEnabled; },
	IsCancelButtonEnabled: function () { return $.Proposal.isCancelButtonEnabled; },
	IsCancelUpdateButtonEnabled: function () { return $.Proposal.isCancelUpdateButtonEnabled; },

	CheckGridRows: function (id) {
		$.Proposal.CancelUpdateRequest();
		var oneOrMoreRowsSelected = rm.grid.hasRowsSelected("#listRequest");
		var singleRowSelected = rm.grid.hasSingleRowSelected("#listRequest");
		$.Proposal.isRemoveButtonEnabled = oneOrMoreRowsSelected;
		$.Proposal.isSubmitButtonEnabled = oneOrMoreRowsSelected;
		$.Proposal.isAddButtonEnabled = false;
		$.Proposal.isUpdateButtonEnabled = false;
		rm.grid.unHighlightAllRows("#listRequest");
		rm.ui.ribbon.refresh();
	},

	CancelUpdateRequest: function () {
		var isDirty = $.Proposal.IsRequestFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			$.Proposal.selectedRequestId = -1;
			$.Proposal.isCancelUpdateButtonEnabled = false;
			$.Proposal.isAddButtonEnabled = false;
			$.Proposal.isUpdateButtonEnabled = false;
			$.Proposal.ClearAllErrors();
			$.Proposal.ResetRequestForm();
			$("#divProposalRequestDetails").hide();
			rm.grid.unHighlightAllRows("#listRequest");
			rm.ui.ribbon.refresh();
		}
	},

	ShowRequestDetails: function () {
		$("#divProposalRequestDetails").show();
	},

	AddCountriesToDropdown: function (data) {
		var countryDropdown = $("#ddlPreferredCountry").empty().append($("<option>").val("-1").html("--Select--"));
		$.each(data, function (index, element) {
			countryDropdown.append($("<option>").val(element.key).html(element.value));
		});
	},

	EnableDisableRibbonIconsOnProjectDirtyChange: function (isDirty) {
		if ($.Proposal.projectId != -1) {
			$.Proposal.isCancelButtonEnabled = isDirty;
			$.Proposal.isSaveProposalButtonEnabled = isDirty;
		}
		else {
			$.Proposal.isCancelButtonEnabled = false;
			$.Proposal.isSaveProposalButtonEnabled = false;
		}

		rm.ui.ribbon.refresh();
	},

	EnableDisableRequestRibbonButtons: function (isEnabled) {
		$.Proposal.isAddButtonEnabled = isEnabled || ($.Proposal.selectedRequestId != -1);
		$.Proposal.isUpdateButtonEnabled = isEnabled && ($.Proposal.selectedRequestId != -1);
		$.Proposal.isCancelUpdateButtonEnabled = isEnabled;
		rm.ui.ribbon.refresh();
	},

	EnableDisableRibbonIconsOnRequestDirtyChange: function (isDirty) {
		if ($.Proposal.selectedRequestId != -1) {
			$.Proposal.isCancelUpdateButtonEnabled = isDirty;
		}
		else {
			$.Proposal.isAddButtonEnabled = false;
			$.Proposal.isUpdateButtonEnabled = false;
			$.Proposal.isCancelUpdateButtonEnabled = false;
		}

		rm.ui.ribbon.refresh();
	},

	HandleMultiSelectChange: function (itemCollection) {
		$.Proposal.EnableDisableRibbonIconsOnProjectDirtyChange($.Proposal.IsProjectFormDirty());
	},

	HandleRegionChange: function (itemCollection) {
		$.Proposal.EnableDisableRibbonIconsOnProjectDirtyChange($.Proposal.IsProjectFormDirty());
		var selectedRegionIds = "";
		if (itemCollection) {
			$.each(itemCollection, function (index, item) {
				if (item.isChecked) {
					selectedRegionIds += "," + item.key;
				}
			});
			selectedRegionIds = selectedRegionIds.replace(",", "");
		}
		if (selectedRegionIds == "") {
			$.Proposal.PopulateProposedCountries(null);
		}
		else {
			$.ajax({
				url: rm.ajax.utilitySvcUrl + "GetAllCountriesByRegion",
				data: { regionIds: selectedRegionIds },
				dataType: "json",
				contentType: "application/json; charset=utf-8",
				type: "GET",
				success: function (data) {
					var existingCountries = $("#countryDropDownContainer").data("ItemsCollection");
					//remember country states from first page load
					var countriesDuringProjectLoad = $("#countryDropDownContainer").data("InitialItemsCollection");

					var existingCountryCount = existingCountries ? existingCountries.length : 0;
					var existingCountry;
					var titleString = "";
					$.each(data, function (index, country) {
						for (var countryIndex = 0; countryIndex < existingCountryCount; countryIndex++) {
							existingCountry = existingCountries[countryIndex];
							if (existingCountry.key == country.key) {
								country.isChecked = existingCountry.isChecked;
								break;
							}
						}
					});

					var initialCountryCount = countriesDuringProjectLoad ? countriesDuringProjectLoad.length : 0;
					if (initialCountryCount > 0) {
						var initialCountry;
						var titleString = "";
						$.each(data, function (index, country) {
							for (var countryIndex = 0; countryIndex < initialCountryCount; countryIndex++) {
								initialCountry = countriesDuringProjectLoad[countryIndex];
								if (initialCountry.key == country.key) {
									country.wasOriginallyChecked = initialCountry.wasOriginallyChecked;
									break;
								}
							}
						});
					}

					$.Proposal.PopulateProposedCountries(data);

				},
				error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: GetAllCountriesByRegion", data.responseText); }
			});
		}
	},

	PopulateProposedRegions: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "regionDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { $.Proposal.HandleRegionChange(itemCollection); }
		};
		$("#proposalRegionHyperlink").dropdownV2(dropdownOptions);

	},

	PopulateProposedCountries: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "countryDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { $.Proposal.HandleMultiSelectChange(itemCollection); }
		};
		$("#proposalCountryHyperlink").dropdownV2(dropdownOptions);
	},

	PopulateIndications: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "indicationsDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { $.Proposal.HandleMultiSelectChange(itemCollection); }
		};
		$("#proposalIndicationsHyperlink").dropdownV2(dropdownOptions);
	},

	PopulateServices: function (data) {
		var dropdownOptions = {
			items: data,
			ContainerId: "servicesDropDownContainer",
			DataKey: "ItemsCollection",
			onCollapse: function (itemCollection) { $.Proposal.HandleMultiSelectChange(itemCollection); }
		};
		$("#proposalServicesHyperlink").dropdownV2(dropdownOptions);

	},

	GetCountriesByRegionId: function () {
		var regionId = $("[id$=ddlPreferredRegion]").val();
		if (regionId != "-1") {
			var postData = { regionIds: $("[id$=ddlPreferredRegion]").val() };
			$.ajax({
				url: rm.ajax.utilitySvcUrl + "GetAllCountriesByRegion",
				type: "GET",
				cache: false,
				async: false,
				data: postData,
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				success: function (data) { $.Proposal.AddCountriesToDropdown(data) }
			});
		}
	},

	SelectOpportunityNumber: function () {
		$.Proposal.ShowProposalProjectSelectionModal();
		$.Proposal.ClearAllErrors();
	},

	RecentOpportunityNumbers: function () {
		$.Proposal.ClearAllErrors();
		$("#divProposalProjectDetails").show().accordion("enable");
		$("#divProposalRequestDetails").show();
		$("[id$=ddlResourceType]").removeAttr("disabled");
	},

	GetCheckedValues: function (selector, dataKey, isCountryDropdown) {
		var data = $(selector).data(dataKey);
		var selectedItems = new Array();
		if (data) {
			$.each(data, function (index, item) {
				if (item.isChecked != item.wasOriginallyChecked) {
					if (isCountryDropdown) {
						selectedItems.push({
							key: item.key,
							//value: item.value, no need to send text vaues. Uncomment for debugging
							isChecked: item.isChecked,
							regionId: item.regionId,
							dmlOperation: item.isChecked ? DMLOperation_E.Insert : DMLOperation_E.Delete
						});
					}
					else {
						selectedItems.push({
							key: item.key,
							//value: item.value, no need to send text vaues. Uncomment for debugging
							isChecked: item.isChecked,
							dmlOperation: item.isChecked ? DMLOperation_E.Insert : DMLOperation_E.Delete
						});
					}
				}
			});
		}

		return selectedItems;
	},

	IsItemSelected: function (selector, dataKey) {
		var data = $(selector).data(dataKey);
		var itemSelected = false;
		if (data) {
			$.each(data, function (index, item) {
				if (item.isChecked) {
					itemSelected = true;
					return false;
				}
			});
		}

		return itemSelected;
	},

	GetProjectPostData: function () {
		return {
			projectDetails: {
				ProjectId: $.Proposal.projectId,
				ProjectCode: $("#txtOpportunityNumber").val(),
				ProjectCode: $("#txtProjectCode").val(),
				CustomerName: $("#txtCustomer").val(),
				Sponsor: $("#txtSponsor").val(),
				RfpReceivedDate: $("#txtRFPReceivedDate").val(),
				ProposalLead: $.q.getPeoplePickerValue("peProposalmgr"),
				ProposalDueDate: $("#txtProposalDueDate").val(),
				StratCallDate: $("#txtStratCallDate").val(),
				PrepCallMeetingDate: $("#txtPrepCallMeetingDate").val(),
				ProtocolNumber: $("#txtProtocolNumber").val(),
				BidDefenseLocation: $("#txtBidDefenseLocation").val(),
				BidDefenseDate: $("#txtBidDefenseDate").val(),
				WinProbabilityId: $("[id$=ddlWinProbability]").val(),
				Budget: $("#txtBudget").val(),
				ProjectStageName: $("#txtStageName").val(),
				ProgramIdentifier: $("#txtProgramIdentifier").val(),
				TherapeuticAreaId: $("[id$=ddlTherapeuticArea]").val(),
				StudyPhaseId: $("[id$=ddlStudyPhase]").val(),
				NumberOfSites: $("#txtNumberOfSites").val(),
				NumberOfPatients: $("#NumberOfPatients").val(),
				ProjectCountryAndRegion: {
					RegionList: $.Proposal.GetCheckedValues("#regionDropDownContainer", "ItemsCollection", false),
					CountryList: $.Proposal.GetCheckedValues("#countryDropDownContainer", "ItemsCollection", true)
				},
				Indications: $.Proposal.GetCheckedValues("#indicationsDropDownContainer", "ItemsCollection", false),
				Services: $.Proposal.GetCheckedValues("#servicesDropDownContainer", "ItemsCollection", false),
				OrganizationUnitId: $("[id$=_ddlOrganization]").val()
			}
		};
	},

	UpdateProposalForm: function () { alert("Not implemented in this release"); },

	UpdateNeedByDate: function (projectId, proposalDueDate) {
		var gridInstance = $("#listRequest");
		var ids = gridInstance.getDataIDs();
		for (var i = 0; i < ids.length; i++) {
			var rowid = ids[i];
			var rowJson = rm.grid.rowData.getById("#listRequest", rowid);
			if (rowJson != undefined && rowJson.ProjectId == projectId) {
				gridInstance.setCell(rowid, 'NeedByDate', proposalDueDate);
			}
		}
	},

	SaveProposalForm: function () {
		$.q.lookupPeoplePickerValue("peProposalmgr");
		if ($.Proposal.IsProjectFormValid()) {
			var postData = $.Proposal.GetProjectPostData();
			$.ajax({
			    url: rm.ajax.projectSvcUrl + "UpdateProposalProjectDetails",
				type: "POST",
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				data: JSON.stringify(postData),
				cache: false,
				success: function (data) {
					$.Proposal.MapProjectValuesToControls(data, true);
					$.Proposal.UpdateNeedByDate($.Proposal.projectId, postData.projectDetails.ProposalDueDate);
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess(Resources.ProposalFormSavedSuccessfully);
				},
				error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: UpdateProposalProjectDetails", data.responseText); }
			});
		}
		else {
			rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
		}
	},

	CancelProposalForm: function () {
		var isDirty = $.Proposal.IsProjectFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			var url = $.url();
			document.location.href = url.attr('protocol') + "://" + url.attr('host') + url.attr('path') + "?opportunityNumber=" + $("#txtOpportunityNumber").val() + "&protocolNumber=" + $("#txtProtocolNumber").data("originalValue");
		}
	},

	GetPostData: function (forUpdate) {
		var postData = {
			proposalRequest: {
				ProjectId: $.Proposal.projectId,
				CountryId: $("[id$=ddlPreferredCountry]").val(),
				ResourceTypeId: $("[id$=ddlResourceType]").val(),
				StartDate: $("#txtStartDate").val(),
				StopDate: $("#txtStopDate").val(),
				NeedByDate: $("#txtProposalDueDate").val(),
				FTE: $("#txtFTEField").val(),
				Notes: $("#taNotes").val()
			}
		};

		if (forUpdate) {
			postData.proposalRequest = $.extend(postData.proposalRequest, { RequestId: $.Proposal.selectedRequestId });
		}

		return postData;
	},

	AddOrUpdateGridRow: function (isUpdate, data) {
		var grid = $("#listRequest");
		if (isUpdate) {
			grid.setCell(data.id, 'Message', " ");
			grid.setCell(data.id, 'Region', data.Region);
			grid.setCell(data.id, 'Country', data.Country);
			grid.setCell(data.id, 'Program', data.Program);
			grid.setCell(data.id, 'ProjectCode', data.ProjectCode);
			grid.setCell(data.id, 'Protocol', data.Protocol);
			grid.setCell(data.id, 'ResourceType', data.ResourceType);
			grid.setCell(data.id, 'NeedByDate', data.NeedByDate);
			grid.setCell(data.id, 'StartDate', data.StartDate);
			grid.setCell(data.id, 'StopDate', data.StopDate);
			grid.setCell(data.id, 'FTE', data.FTE);
			grid.setCell(data.id, 'Notes', data.Notes);
		}
		else {
			grid.addRowData(data.id, [{
				Message: "",
				Region: data.Region,
				Country: data.Country,
				Program: data.Program,
				ProjectCode: data.ProjectCode,
				Protocol: data.Protocol,
				ResourceType: data.ResourceType,
				NeedByDate: data.NeedByDate,
				StartDate: data.StartDate,
				StopDate: data.StopDate,
				FTE: data.FTE,
				Notes: data.Notes
			}], "last");
		}

		$.Proposal.selectedRequestId = -1;
		$.Proposal.ResetRequestForm();
		$.Proposal.ClearAllErrors();

		//wait for the row to be added to grid and then bind comment click handler
		setTimeout(function () {
			rm.ui.notes.bindNotesIconClick();
			rm.formStatus.clearDirty($.Proposal.getJsonObjectForProjectDetails());
			rm.formStatus.clearDirty($.Proposal.getJsonObjectForRequestDetails());
		}, 50);
	},

	HideMessageColumn: function () {
		$('#listRequest').hideCol("Message");
		rm.grid.clearGridError('#listRequest', "Message");
	},

	IsPeoplePickerValid: function () {
		var isValid = true;
		var personName = $.trim($.q.getPeoplePickerValue("peProposalmgr"));

		if (personName && personName != "" && $("[id$=_peProposalmgr_errorLabel]").html() != "") {
			isValid = false;
		}
		return isValid;
	},

	IsProjectFormValid: function () {
		var isValid = $.validationHelper.IsFormValid();
		if ($("#txtOpportunityNumber").val() == "") {
			isValid = false;
		}

		if ($("#txtProposalDueDate").val() == "") {
			rm.validation.addError("#txtProposalDueDate", Resources.EnterProposalDueDate);
			isValid = false;
		}
		if (!$.Proposal.IsPeoplePickerValid()) {
			rm.validation.addError("#" + $.q.getPeoplePickerDivId("peProposalmgr"), Resources.SelectValidResource);
			isValid = false;
		}

		if ($("[id$=_ddlOrganization]").val() == "-1") {
			rm.validation.addError("[id$=_ddlOrganization]", Resources.ProjectOrganizationalUnitRequired);
			isValid = false;
		}

		if ($("[id$=_ddlTherapeuticArea]").val() == "-1") {
			rm.validation.addError("[id$=_ddlTherapeuticArea]", Resources.TherapeuticAreaRequired);
			isValid = false;
		}

		if (!$.Proposal.IsItemSelected("#indicationsDropDownContainer", "ItemsCollection")) {
			rm.validation.addError("#indicationsDropDownContainer", Resources.IndicationsRequired);
			isValid = false;
		}

		return isValid;
	},

	IsRequestFormValid: function () {
		var isValid = true;

		if (rm.date.isValidDate($("#txtStartDate").val(), false)) {
			if (rm.date.getDateFromQDateString($("#txtStartDate").val()) < rm.date.today()) {
				rm.validation.addError("#txtStartDate", Resources.StartDateInPast);
				isValid = false;
			}
			else {
				rm.validation.clearError($("#txtStartDate"));
			}
		}
		if (rm.date.isValidDate($("#txtStopDate").val(), false)) {
			if (rm.date.getDateFromQDateString($("#txtStopDate").val()) < rm.date.today()) {
				rm.validation.addError("#txtStopDate", Resources.StopDateInPast);
				isValid = false;
			}
			else {
				rm.validation.clearError($("#txtStopDate"));
			}
		}

		if ($("[id$=ddlResourceType]").val() == "-1") {
			rm.validation.addError("[id$=ddlResourceType]", Resources.ResourceRequestTypeRequired);
			isValid = false;
		}
		if ($("[id$=ddlPreferredRegion]").val() == "-1") {
			rm.validation.addError("[id$=ddlPreferredRegion]", Resources.PreferredRegionRequired);
			isValid = false;
		}
		var countryValue = $("[id$=ddlPreferredCountry]").val();
		if (countryValue == null || countryValue == "-1") {
			rm.validation.addError("[id$=ddlPreferredCountry]", Resources.PreferredCountryRequired);
			isValid = false;
		}
		if ($("#txtFTEField").val() == "") {
			rm.validation.addError("#txtFTEField", Resources.EnterFTEField);
			isValid = false;
		}
		else if (!rm.validation.range.validate("#txtFTEField") {
			isValid = false;
		}
		else {
			rm.utilities.formatTextboxText("#txtFTEField");
			rm.validation.clearError($("#txtFTEField"));
		}
		if ($("#txtStartDate").val() == "") {
			rm.validation.addError("#txtStartDate", Resources.StartDateIsBlank);
			isValid = false;
		}
		if ($("#txtStopDate").val() == "") {
			rm.validation.addError("#txtStopDate", Resources.StopDateIsBlank);
			isValid = false;
		}

		if (!rm.validation.hasError("#txtStartDate") && !rm.validation.hasError("#txtStopDate") && $("#txtStartDate").val() != "" && $("#txtStopDate").val() != "") {
			if (rm.date.getDateFromQDateString($("#txtStartDate").val()) > rm.date.getDateFromQDateString($("#txtStopDate").val())) {
				rm.validation.addError("#txtStartDate", Resources.StartDateGreaterThanStopDate);
				rm.validation.addError("#txtStopDate", Resources.StopDateLessThanStartDate);
				isValid = false;
			}
		}
		return isValid;
	},

	AddRequest: function () {
		var postData =
		{
			proposalRequest: $.Proposal.GetPostData(false).proposalRequest,
			projectDetails: $.Proposal.GetProjectPostData().projectDetails
		};

		if ($.Proposal.IsRequestFormValid() && $.Proposal.IsProjectFormValid()) {
			$.ajax({
			    url: rm.ajax.requestSvcUrl + "AddProposalRequest",
				type: "POST",
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				data: JSON.stringify(postData),
				cache: false,
				success: function (data) {
					$.Proposal.isAddButtonEnabled = false;
					$.Proposal.isUpdateButtonEnabled = false;
					$.Proposal.isSaveProposalButtonEnabled = false;
					$.Proposal.isCancelButtonEnabled = false;
					rm.ui.ribbon.refresh();
					$.Proposal.AddOrUpdateGridRow(false, data);
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess(Resources.AddedToRequestQueue);
					$("#divProposalRequestDetails").hide();
					rm.grid.rowData.addData("#listRequest", data);
				},
				error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: AddRequest", data.responseText); }
			});
		}
		else {
			rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
		}
	},

	RemoveFromQueue: function () {
		var postData = { requestIds: $("#listRequest").getGridParam('selarrrow') };
		$.Proposal.HideMessageColumn();

		$.rm.Ajax_Request("DeleteSubmittedRequests", postData,
		function (data) {
			if (data) {
				rm.grid.removeAllCheckedRows("#listRequest");
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showSuccess(Resources.RequestDeletedSuccessfully);
			}
			else {
				rm.ui.messages.addError(Resources.ErrorInDeleteRequest);
			}
		}, false);
	},

	UpdateRequest: function () {
		if ($.Proposal.IsRequestFormValid() && $.Proposal.IsProjectFormValid()) {
			var postData =
			{
				proposalRequest: $.Proposal.GetPostData(true).proposalRequest,
				projectDetails: $.Proposal.GetProjectPostData().projectDetails
			};

			$.ajax({
			    url: rm.ajax.requestSvcUrl + "UpdateProposalRequest",
				type: "POST",
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				data: JSON.stringify(postData),
				cache: false,
				success: function (data) {
					$.Proposal.isAddButtonEnabled = false;
					$.Proposal.isUpdateButtonEnabled = false;
					$.Proposal.isSaveProposalButtonEnabled = false;
					$.Proposal.isCancelButtonEnabled = false;
					rm.ui.ribbon.refresh();
					$.Proposal.AddOrUpdateGridRow(true, data);
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess(Resources.RequestQueueUpdated);
					$("#divProposalRequestDetails").hide();
					rm.grid.unHighlightAllRows("#listRequest");
					rm.grid.rowData.updateData("#listRequest", data);
				},
				error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: UpdateRequest", data.responseText); }
			});
		}
		else {
			rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
		}
	},

	SubmitRequest: function () {
		var postData = { requestIds: $("#listRequest").getGridParam('selarrrow') };
		$.Proposal.HideMessageColumn();

		$.ajax({
		    url: rm.ajax.requestSvcUrl + "SubmitRequests",
			type: "POST",
			contentType: "application/json; charset=utf-8",
			dataType: "json",
			data: JSON.stringify(postData),
			cache: false,
			success: function (data) {
				var isSuccess = true;
				$.each(data, function (index, request) {
					if (request.IsSuccessful) {
						rm.grid.removeRow("#listRequest", request.EntityId);
					}
					else {
						isSuccess = false;
						$('#listRequest').setCell(request.EntityId, 'Message', request.Message);
						$('#listRequest').showCol("Message");
					}
				});
				if (isSuccess) {
					rm.ui.messages.clearAllMessages();
					rm.ui.messages.showSuccess(Resources.RequestSubmittedSuccessfully);
				}
				else {
					rm.ui.messages.addError(Resources.FailedToSubmitRequest);
				}
			},
			error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: SubmitRequests", data.responseText); }
		});

	},

	ResetRequestForm: function () {
		$.Proposal.selectedRequestId = -1;
		$.Proposal.EnableDisableRequestRibbonButtons(false);
		$("div#divProposalRequestDetails input, div#divProposalRequestDetails textarea").val("");
		$("div#divProposalRequestDetails select,[id$=ddlResourceType]").val("-1");
		$("#ddlPreferredCountry  > option:gt(0)").remove();
		rm.grid.unHighlightAllRows("#listRequest");
		rm.formStatus.clearDirty($.Proposal.getJsonObjectForRequestDetails());
		$.Proposal.ClearAllRequestErrors();
	},

	ResetProjectForm: function () {
		$.Proposal.EnableDisableRibbonIconsOnProjectDirtyChange(false);
		$.Proposal.projectId = -1;
		$("div#divProposalProjectDetails input").val("");
		$("div#divProposalProjectDetails select").val("-1");
		$.q.setPeoplePickerValue("peProposalmgr", "");
		$.Proposal.PopulateProposedRegions(null);
		$.Proposal.PopulateProposedCountries(null);
		$.Proposal.PopulateIndications(null);
		$.Proposal.PopulateServices(null);
		rm.formStatus.clearDirty($.Proposal.getJsonObjectForProjectDetails());
		$.Proposal.ClearAllProjectErrors();
	},

	ClearAllProjectErrors: function () {
		rm.validation.clearAllErrors("#indicationsDropDownContainer div#divProposalProjectDetails input,div#divProposalProjectDetails select");
		rm.validation.clearError($("#" + $.q.getPeoplePickerDivId("peProposalmgr")));
		rm.validation.clearError($("#indicationsDropDownContainer"));
	},

	ClearAllRequestErrors: function () {
		rm.validation.clearAllErrors("div#divProposalRequestDetails input,div#divProposalRequestDetails select,div#divProposalRequestDetails textarea,[id$=ddlResourceType],#divProposalProjectDetails input");
	},

	ClearAllErrors: function () {
		$.Proposal.ClearAllProjectErrors();
		$.Proposal.ClearAllRequestErrors();
	},

	CopyRequestDetailsToEditForm: function (id) {
		if ($.Proposal.IsRequestFormDirty()) {
			if (!confirm("There are unsaved changes on \"Proposal Resource Request Form\". " + Resources.OkToContinueCancelToStayOnCurrentPage)) {
				return false;
			}
		}

		if ($.Proposal.IsProjectFormDirty()) {
			if (!confirm("There are unsaved changes on \"Proposal Form\". " + Resources.OkToContinueCancelToStayOnCurrentPage)) {
				return false;
			}
		}
		$.Proposal.ResetProjectForm();
		var currentlySelectedRegionId = $("[id$=ddlPreferredRegion]").val();

		$.Proposal.ClearAllErrors();
		rm.grid.uncheckAllGridRows("#listRequest")
		$("#" + id).addClass("ui-state-highlight");
		$.Proposal.ShowRequestDetails();

		var gridInstance = $("#listRequest");
		var rowJson = rm.grid.rowData.getById("#listRequest", id);
		$("#txtStartDate").val(gridInstance.getCell(id, "StartDate"));
		$("#txtStopDate").val(gridInstance.getCell(id, "StopDate"));
		$("#txtFTEField").val(gridInstance.getCell(id, "FTE"));
		$.Proposal.projectId = rowJson.ProjectId;
		$.Proposal.selectedRequestId = id;
		$.Proposal.isAddButtonEnabled = true;
		$.Proposal.isUpdateButtonEnabled = true;
		$.Proposal.isCancelUpdateButtonEnabled = true;

		$.Proposal.GetProposalProjectById(rowJson.ProjectId, function () {
			$.Proposal.isSaveProposalButtonEnabled = false;
			$.Proposal.isCancelButtonEnabled = false;
			rm.ui.ribbon.refresh();
		});

		$("[id$=ddlResourceType]").val(rowJson.ResourceTypeId);
		$("[id$=ddlPreferredRegion]").val(rowJson.RegionId);

		if (currentlySelectedRegionId != rowJson.RegionId) {
			$.Proposal.GetCountriesByRegionId();
		}

		setTimeout(function () {
			$("[id$=ddlPreferredCountry]").val(rowJson.CountryId);
			setTimeout(function () {
				rm.formStatus.clearDirty($.Proposal.getJsonObjectForRequestDetails());

				setTimeout(function () {
					$.Proposal.EnableDisableRibbonIconsOnProjectDirtyChange($.Proposal.IsProjectFormDirty());
				}, 20);
			}, 20);
		}, 20);

		rm.ui.ribbon.refresh();
	},

	ShowProposalProjectSelectionModal: function () {
		$("#divOpportunity").dialog({
			modal: true,
			cache: false,
			title: "Select Opportunity Number",
			resizable: false,
			width: 300,
			height: 120,
			open: function () {
				$('.ui-dialog-titlebar-close').unbind('click');
				$("#d_cancelButton,.ui-dialog-titlebar-close").click(function () { $("#divOpportunity").dialog('close'); });
				$.Proposal.SetupProjectAutoComplete($('#txtOpportunityNumderDialogTextBox').val("").focus());
			}
		});
	},

	MapProjectValuesToControls: function (data, callRefreshUi) {
		rm.grid.clearGridError("#listRequest", "Message");
		if (ProjectStage_E.Prospecting == data.ProjectStageId || ProjectStage_E.Qualification == data.ProjectStageId ||
            ProjectStage_E.Ballpark == data.ProjectStageId || ProjectStage_E.Bid_Requested == data.ProjectStageId ||
            ProjectStage_E.Proposal_Sent == data.ProjectStageId || ProjectStage_E.Verbally_Agreed == data.ProjectStageId) {
			$.Proposal.isAddButtonEnabled = true;
			if (callRefreshUi) {
				rm.ui.ribbon.refresh();
			}
			$.Proposal.projectId = data.ProjectId;
			$("#txtOpportunityNumber").val(data.ProjectCode);
			$("#txtProjectCode").val(data.ProjectCode);
			$("#txtCustomer").val(data.CustomerName);
			$("#txtSponsor").val(data.Sponsor);
			$("#txtRFPReceivedDate").val(data.RfpReceivedDate);
			$.q.setPeoplePickerValue("peProposalmgr", data.ProposalLead);
			if (data.ProposalLead != "") {
				$.q.lookupPeoplePickerValue("peProposalmgr");
			}
			$("#txtProposalType").val(data.ProposalTypeName);
			$("#txtProposalDueDate").val(data.ProposalDueDate);
			$("#txtStratCallDate").val(data.StratCallDate);
			$("#txtPrepCallMeetingDate").val(data.PrepCallMeetingDate);
			$("#txtProtocolNumber").val(data.ProtocolNumber).data("originalValue", data.ProtocolNumber);
			$("#txtBidDefenseLocation").val(data.BidDefenseLocation);
			$("#txtBidDefenseDate").val(data.BidDefenseDate);
			$("[id$=ddlWinProbability]").val(data.WinProbabilityId);
			$("#txtBudget").val(data.Budget);
			$("#txtStageName").val(data.ProjectStageName);
			$("#txtProgramIdentifier").val(data.ProgramIdentifier);
			$("[id$=ddlTherapeuticArea]").val(data.TherapeuticAreaId);
			$("[id$=ddlStudyPhase]").val(data.StudyPhaseId);
			$("#txtNumberOfSites").val(data.NumberOfSites);
			$("#NumberOfPatients").val(data.NumberOfPatients);
			$("[id$=_ddlOrganization]").val(data.OrganizationUnitId);

			$.Proposal.PopulateProposedRegions(data.ProjectCountryAndRegion ? data.ProjectCountryAndRegion.RegionList : null);
			$.Proposal.PopulateProposedCountries(data.ProjectCountryAndRegion ? data.ProjectCountryAndRegion.CountryList : null);
			$.Proposal.PopulateIndications(data.Indications);
			$.Proposal.PopulateServices(data.Services);

			$("#countryDropDownContainer").data("InitialItemsCollection", data.ProjectCountryAndRegion ? data.ProjectCountryAndRegion.CountryList : null);
			$.Proposal.ClearAllErrors();
			rm.ui.messages.clearAllMessages();

			setTimeout(function () {
				$("#divProposalProjectDetails").accordion("enable");
				rm.ui.openCollapsiblePanel('#divProposalProjectDetails');
				rm.formStatus.clearDirty($.Proposal.getJsonObjectForProjectDetails());
				rm.formStatus.clearDirty($.Proposal.getJsonObjectForRequestDetails());
				$("[id$=ddlResourceType]").removeAttr("disabled");
			}, 200);
		}
		else if (ProjectStage_E.Opportunity_Won_LOI_COO_Agreed == data.ProjectStageId ||
						 ProjectStage_E.Opportunity_Won_Repricing == data.ProjectStageId ||
             ProjectStage_E.Signed_Contract == data.ProjectStageId ||
						 ProjectStage_E.Opportunity_Closed_Lost == data.ProjectStageId ||
						 ProjectStage_E.Stopped == data.ProjectStageId ||
						 ProjectStage_E.Change_Cancellation_Not_Awarded == data.ProjectStageId ||
						 ProjectStage_E.Change_Cancellation_Awarded == data.ProjectStageId ||
						 ProjectStage_E.Ballpark_Stopped == data.ProjectStageId ||
						 ProjectStage_E.Opportunity_Won == data.ProjectStageId) {
			rm.ui.messages.addError(Resources.ProposalResourcesNotAssignedItsAwarded);
			$.Proposal.ResetProjectForm();
			$("#divProposalProjectDetails").accordion("disable");
			$("[id$=ddlResourceType]").attr("disabled", "disabled");
		}
		else {
			rm.ui.messages.addError(Resources.ProposalResourcesNotAssignedItsNotInproposalPhase);
			$.Proposal.ResetProjectForm();
			$("#divProposalProjectDetails").accordion("disable");
			$("[id$=ddlResourceType]").attr("disabled", "disabled");
		}
	},

	HandleCustomErrors: function (validationErrors, protocolNumber) {
		$.each(validationErrors, function (index, ele) {
			var arrayMessagesfordialog = new Array();
			if (ele.MessageType == MessageType_E.CustomHandling) {
				arrayMessagesfordialog.push(ele.Value);
			}

			if (arrayMessagesfordialog.length > 0) {
				var htmlMessage = "Protocol Number (" + protocolNumber + ") does not match in Salesforce CRM and Quintiles middleware." +
													"Please correct this. Then wait up to 48 hours for the changes to be available in QRPM:RM." +
													"The available Protocol Numbers in middleware are: <br/><br/>" +
													"<table class='validationTable'><tr class='headerRow'><td valign='top'>Available Protocols</td></tr>";
				$.each(arrayMessagesfordialog, function (index, message) {
					htmlMessage += "<tr><td>" + message + "</td></tr>";
				});
				htmlMessage += "</table>";
				rmCommon.showDialogWithOkButton("Protocol Mismatch", htmlMessage, null);
			}
		});
	},

	ChangeProposalProject: function (opportunityNumberProtocolNumber, callRefreshUi) {
		if ($.Proposal.IsProjectFormDirty()) {
			if (!confirm("There are unsaved changes on \"Proposal Form\". " + Resources.OkToContinueCancelToStayOnCurrentPage)) {
				return false;
			}
		}

		if ($.Proposal.IsRequestFormDirty()) {
			if (!confirm("There are unsaved changes on \"Proposal Resource Request Form\". " + Resources.OkToContinueCancelToStayOnCurrentPage)) {
				return false;
			}
		}

		$.Proposal.ResetRequestForm();
		$.Proposal.ClearAllErrors();

		$("#divProposalRequestDetails").hide();

		if (callRefreshUi) {
			$.Proposal.isUpdateButtonEnabled = false;
			rm.ui.ribbon.refresh();
		}

		if (!opportunityNumberProtocolNumber || opportunityNumberProtocolNumber == "" || opportunityNumberProtocolNumber.indexOf("-") == -1) {
			alert("The Project and protocol combination selected is invalid. Please try again.");
			return false;
		}

		$("#d_cancelButton").click();

		var indexOfHyphen = opportunityNumberProtocolNumber.indexOf("-");
		var opportunityNumber = $.trim(opportunityNumberProtocolNumber.substring(0, indexOfHyphen));
		var protocolNumber = $.trim(opportunityNumberProtocolNumber.substring(indexOfHyphen + 1, opportunityNumberProtocolNumber.length));

		if (opportunityNumberProtocolNumber != "") {
			$.ajax({
			    url: rm.ajax.projectSvcUrl + "GetProposalProjectDetails",
				type: "POST",
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				data: JSON.stringify({ opportunityNumber: opportunityNumber, protocolNumber: protocolNumber }),
				cache: false,
				success: function (data) {
					if (data.ContainsValidationErrors) {
						rm.validation.processErrorMessages(data.ValidationErrors);
						$.Proposal.ResetProjectForm();
						$.Proposal.HandleCustomErrors(data.ValidationErrors, protocolNumber);
					}
					else {
						var additionalData = data.RequestExecutionStatus[0].AdditionalData;
						$.Proposal.MapProjectValuesToControls(additionalData, callRefreshUi);
						setTimeout(function () { $.Proposal.EnableDisableRibbonIconsOnProjectDirtyChange(false); }, 10);
					}
				},
				error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: GetProposalProjectDetails", data.responseText); }
			});
		}
	},

	GetProposalProjectById: function (projectId, callbackFunction) {
		if (projectId != "") {
			$.ajax({
			    url: rm.ajax.projectSvcUrl + "GetProposalProjectById",
				type: "POST",
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				data: JSON.stringify({ projectId: projectId }),
				cache: false,
				success: function (data) {
					$.Proposal.MapProjectValuesToControls(data, true);
					if (callbackFunction) { callbackFunction(); }
				},
				error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: GetProposalProjectById", data.responseText); }
			});
		}
	},

	SetupProjectAutoComplete: function (TextboxObj) {
		var resultset;
		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.projectSvcUrl + "GetProposalProjectList",
			dataType: "text",
			success: function (data) {
				//bind the autocomplete plugin to the search box
				TextboxObj.unbind("keypress").autocomplete({
					source: data.split(","),
					matchContains: false
				}).keypress(function (e) {
					if (e.keyCode === 13) {
						$.Proposal.ChangeProposalProject($(this).val(), true);
					}
				});

				//When option in list is selected, do something
				TextboxObj.unbind("autocompleteselect").bind("autocompleteselect", function (event, ui) {
					$.Proposal.ChangeProposalProject(ui.item.value, true);
				});

				$("#d_okButton").unbind("click").click(function () { $.Proposal.ChangeProposalProject(TextboxObj.val(), true); });

				TextboxObj.on('focus focusin', function () {
					if ($(this).val() == 'Search...') {
						$(this).val('');
					}
				});
			},
			error: function (errMsg) {
				alert('Unable to load list of proposal projects.');
			}
		});
	},

	ClearRecentProposalProjectsList: function () {
		if (confirm("Clear your list of recently accessed projects?")) {
			$.ajax({
				type: "POST",
				contentType: "application/json; charset=utf-8",
				url: rm.ajax.utilitySvcUrl + "DeleteRecentProjects",
				dataType: "JSON",
				data: JSON.stringify({ OpportunityStatus: OpportunityStatus_E.Open }),
				success: function () { document.location.href = document.location.href }
			});
		}
	},

	buildGrid: function (rmPageLinkId) {
		$("#listRequest").jqGrid({
		    url: rm.ajax.requestSvcUrl + "GetProposalRequests",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
			loadonce: false,
			autowidth: false,
			shrinkToFit: true,
			height: 320,
			forceFit: false,
			pager: '#listPager',
			multiselect: true,
			jsonReader: rm.grid.getJqGridJsonReader(),
			colModel: [
				rm.grid.standardColumns.getMessageColumn(),
                { name: 'Region', index: 'Region', label: 'Region', width: 80, search: true, searchoptions: { attr: { maxlength: 255 } } },
                { name: 'Country', index: 'Country', label: 'Country', width: 80, search: true, searchoptions: { attr: { maxlength: 255 } } },
                { name: 'Program', index: 'Program', label: 'Program', width: 80, search: true, searchoptions: { attr: { maxlength: 255 } } },
                { name: 'ProjectCode', index: 'ProjectCode', label: 'Project<br/> Code', width: 80, search: true, searchoptions: { attr: { maxlength: 255 } } },
                { name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 75, search: true, searchoptions: { attr: { maxlength: 510 } } },
                { name: 'ResourceType', index: 'ResourceType', label: 'Resource Request<br/>Type', width: 135, search: true, searchoptions: { attr: { maxlength: 255 } } },
                { name: 'NeedByDate', index: 'NeedByDate', label: 'Need By<br/> Date', width: 77, search: true, searchoptions: { attr: { maxlength: 11 } } },
                { name: 'StartDate', index: 'StartDate', label: 'Start Date', width: 77, search: true, searchoptions: { attr: { maxlength: 11 } } },
                { name: 'StopDate', index: 'StopDate', label: 'Stop Date', width: 77, search: true, searchoptions: { attr: { maxlength: 11 } } },
                { name: 'FTE', index: 'FTE', label: 'FTE', sortable: true, search: true, searchoptions: { attr: { maxlength: 255 } } },
				rm.grid.standardColumns.getNotesColumn()
			],
			viewsortcols: [true, 'vertical', true],
			sortname: 'Country',
			sortorder: 'asc',
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			onPaging: function () { $.Proposal.CheckGridRows(); },
			ondblClickRow: function (id) { rm.grid.clearGridError("#listRequest", "Message"); $.Proposal.CopyRequestDetailsToEditForm(id); },
			onSelectRow: function (id) { rm.grid.clearGridError("#listRequest", "Message"); $.Proposal.CheckGridRows(id); },
			onSelectAll: function (rowIdxArray, sts) { rm.grid.clearGridError("#listRequest", "Message"); $.Proposal.CheckGridRows(); },
			gridComplete: function () { rm.ui.notes.bindNotesIconClick(); },
			serializeGridData: function (postData) {
				var data = { RmPageLink: rmPageLinkId };
				return rm.grid.serializeGridData(postData, data);
			},
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData("#listRequest", data); }
		});
		$("#listRequest").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},

	IsMultiselectDirty: function () {
		var isDirty = $("#proposalRegionHyperlink").dropdownV2("isDirty", "regionDropDownContainer");
		if (!isDirty) {
			isDirty = $("#proposalCountryHyperlink").dropdownV2("isDirty", "countryDropDownContainer");
			if (!isDirty) {
				isDirty = $("#proposalIndicationsHyperlink").dropdownV2("isDirty", "indicationsDropDownContainer");
				if (!isDirty) {
					isDirty = $("#proposalServicesHyperlink").dropdownV2("isDirty", "servicesDropDownContainer");
				}
			}
		}
		return isDirty;
	},

	IsProjectFormDirty: function () {
		var isDirty = rm.formStatus.isDirty($.Proposal.getJsonObjectForProjectDetails());
		if (!isDirty) {
			isDirty = $.Proposal.IsMultiselectDirty();
		}
		return isDirty;
	},

	IsRequestFormDirty: function () {
		return rm.formStatus.isDirty($.Proposal.getJsonObjectForRequestDetails());
	},

	getJsonObjectForProjectDetails: function () {
		return { items: [{ selector: "#divProposalProjectDetails input:text,#divProposalProjectDetails select", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},

	getJsonObjectForRequestDetails: function () {
		return { items: [{ selector: "#divProposalRequestDetails input:text,#divProposalRequestDetails select,#divProposalRequestDetails textarea, [id$=ddlResourceType]", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},

	GetJsonObjectForEntirePage: function () {
		var selector = $.Proposal.getJsonObjectForRequestDetails().items[0].selector + "," + $.Proposal.getJsonObjectForProjectDetails().items[0].selector;
		return { items: [{ selector: selector, dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},

	RefetchProjectDetails: function () {
		var url = $.url();
		if (url.param("opportunityNumber")) {
			$.Proposal.ChangeProposalProject(url.param("opportunityNumber") + " - " + url.param("protocolNumber"), false);
		}
	},

	BindResourceTypeChangeEvent: function () {
		$("[id$=ddlResourceType]").attr("disabled", "disabled").change(function () {
			$.Proposal.ShowRequestDetails();
			var resourceType = $("[id$=ddlResourceType]");
			if ($.Proposal.selectedRequestId != -1) {
				alert("The Resource Request Type cannot be modified.  If the action you want to take is create a new resource request, then click the \"Cancel Update\" button and follow the Initiate New Proposal Request process.");
				$.Proposal.isCancelUpdateButtonEnabled = true;
				var rowId = rm.grid.getHighlightedRowId("#listRequest");
				var rowJson = rm.grid.rowData.getById("#listRequest", rowId);
				resourceType.val(rowJson.ResourceTypeId);
				rm.ui.ribbon.refresh();
			}
			if (resourceType != "-1") {
				rm.validation.clearError(resourceType);
				$.Proposal.isAddButtonEnabled = $.Proposal.projectId != -1;
				rm.ui.ribbon.refresh();
			}
		});
	},

	BindStartStopDateChangeEvent: function () {
		$("#txtStartDate").change(function () { rm.validation.clearError($("#txtStopDate")); });
		$("#txtStopDate").change(function () { rm.validation.clearError($("#txtStartDate")); });
	},

	bindLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn("#listRequest_Region", "Region.");
		rm.qtip.showInfoOnGridColumn("#listRequest_Country", "Country where the study is expected to take place.");
		rm.qtip.showInfoOnGridColumn("#listRequest_Program", "Program.");
		rm.qtip.showInfoOnGridColumn("#listRequest_ProjectCode", "Project Code.");
		rm.qtip.showInfoOnGridColumn("#listRequest_Protocol", "Protocol.");
		rm.qtip.showInfoOnGridColumn("#listRequest_ResourceType", "Resource Request Type.");
		rm.qtip.showInfoOnGridColumn("#listRequest_NeedByDate", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn("#listRequest_StartDate", "The date when the work begins for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#listRequest_StopDate", "The date when the work ends for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("#listRequest_FTE", "Provides the details of the resource request need and takes into account the country working hours and % utilization.");
		rm.qtip.showInfoOnGridColumn("#listRequest_Notes", "Use to add/view comments about the particular proposal/request.");
	}
};

$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });

	$.Proposal.buildGrid(GetRmPageLinkId());
	$("#divProposalRequestDetails").hide();
	rm.qtip.showInfo("#proposalFormHeader", "Select Opportunity number", {}, { at: 'top left' });
	$.Proposal.BindResourceTypeChangeEvent();
	$.Proposal.BindStartStopDateChangeEvent();

	$("[id$=ddlPreferredRegion]").change(function () {
		$.Proposal.GetCountriesByRegionId();
		rm.validation.clearError($(this));
	});

	$("[id$=ddlPreferredCountry]").change(function () { rm.validation.clearError($(this)); });
	$("#txtStopDate,#txtStartDate,#txtRFPReceivedDate,#txtProposalDueDate,#txtStratCallDate,#txtPrepCallMeetingDate,#txtBidDefenseDate,").qDatepicker();


	$("[class~=validateRange]").bind('blur', function () { $.q.formatText(this); });

	$("#divProposalProjectDetails").accordion({
		collapsible: true
	});
	$("[id$=ddlResourceType]").attr("disabled", "disabled");
	$("#divProposalProjectDetails").accordion("option","active", -1).accordion("disable");

	rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, $.Proposal.GetJsonObjectForEntirePage());

	$(document).bind("keyup click", function () {
		$.Proposal.EnableDisableRibbonIconsOnProjectDirtyChange($.Proposal.IsProjectFormDirty());
	});

	$.Proposal.RefetchProjectDetails();
	$("[readonly=readonly]").keydown($.q.preventNavigationOnBackSpace);

	setTimeout(function () {
		var peoplePickerObject = $("#" + $.q.getPeoplePickerDivId("peProposalmgr"));
		peoplePickerObject.keydown(function () {
			rm.validation.clearError(peoplePickerObject);
		});
		$(document).on("change",".hasDatepicker", function () {
			$.Proposal.EnableDisableRibbonIconsOnProjectDirtyChange(rm.formStatus.isDirty($.Proposal.getJsonObjectForProjectDetails()));
		});
	}, 200);

	$.Proposal.bindLabelQtip();
	$("#indicationsDropDownContainer").bind("ItemCheckChanged", function (event, isChecked, checkedItemCouont) {
		if (checkedItemCouont == 0) {
			rm.validation.addError("#indicationsDropDownContainer", Resources.IndicationsRequired);
		}
		else {
			rm.validation.clearError($("#indicationsDropDownContainer"));
		}
	});

	$("[id$=_ddlOrganization]").bind("change", function () {
		rm.validation.clearError($(this));
	})

	$("[id$=_ddlTherapeuticArea]").bind("change", function () {
		rm.validation.clearError($(this));
	})
});
