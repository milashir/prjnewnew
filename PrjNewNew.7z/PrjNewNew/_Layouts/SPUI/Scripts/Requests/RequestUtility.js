﻿$.RequestUtility = {
	IsAssignResourceEnabled: function ()
	{
		return rm.grid.hasRowsSelected("#listRequest");
	},

	AssignResource: function ()
	{
		var selectedRows = rm.grid.getSelectedIds("#listRequest");
		if (selectedRows.length != 0)
		{
			$.ajax({
				url: "/_Layouts/SPUI/UtilityPages/AssignResource.aspx?requestIds=" + selectedRows,
				cache: false,
				success: function (data)
				{
					var container = $("#dialogContainer");
					if (container.length == 0)
					{
						container = $("<div id='dialogContainer' />");
						$('body').append(container);
					}
					container.html(data).dialog({
						modal: true,
						cache: false,
						title: "Assign Resource",
						resizable: false,
						width: 820,
						height: 450
					});
				}
			});
		}
		else
		{
			alert("Please select only one request.");
		}
	}
};