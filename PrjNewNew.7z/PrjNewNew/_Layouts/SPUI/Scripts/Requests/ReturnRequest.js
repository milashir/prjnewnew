﻿$.dirty = function ()
{
    //bindDirty: bind isDirty function to window onbeforeunload function
    //isDirty: is the form dirty in any way?
    //clearDirty: clear and reset
    //resetInitialValues: set fields back to starting

    this.bindDirty = function ()
    {
        this.clearDirty('all');

        window.onbeforeunload = function ()
        {
            if (dirtyManager.isDirty() && !$.returnRequest._onSaving)
            {
            	return Resources.UnsavedChangesOnThePageShort;
            }
        };
    };

    this.isDirty = function ()
    {
        //Check Monitoring
        inputs = $(".returnRequestContent input:text,textarea ");
        var foundDirty = false;
        $.each(inputs, function (key, input)
        {
            if ($(input).data("initial") !== $(input).val())
            {
                foundDirty = true;
                return false;
            }
        });

        if (foundDirty)
        {
            return true;
        }

        return false;
    };

    this.clearDirty = function (choice)
    {
        this.resetInitialValues();
    };

    this.resetInitialValues = function (div)
    {
        var inputs;
        if (div)
        {
            inputs = $(div).find("input:text");
        } else
        {
            inputs = $("input:text");
        }
        $.each(inputs, function (key, input)
        {
            $(input).data("initial", $(input).val());
        });

    };

};

$.returnRequest = {

    _saveButtonEnabled: true,
    _cancelButtonEnabled: true,
    _closeButtonEnabled: true,

    SaveButtonEnabled: function ()
    {
        return $.returnRequest._saveButtonEnabled;
    },

    CancelButtonEnabled: function ()
    {
        return $.returnRequest._cancelButtonEnabled;
    },

    CloseButtonEnabled: function ()
    {
        return $.returnRequest._closeButtonEnabled;
    },

    Save: function ()
    {
        // AJAX call for saving.
    },

    Close: function ()
    {
        document.location.href = "/_layouts/SPUI/Requests/SubmittedRequest.aspx";
    },

    Cancel: function ()
    {
        //TODO: Add confirmation and disable window.onbeforeunload check
        document.location.href = $.url().attr("source");
    },

    _onLoad: true,
    _onSaving: false,
    _ajaxErrors: false,
    _requestIds: $.url().param("requestIds")
};

$(document).ready(function ()
{
    $.returnRequest._onLoad = false;
    $.returnRequest._onSaving = false;

    dirtyManager = new $.dirty();
    dirtyManager.bindDirty();
});