﻿/// <reference path="../common/rmhelper.js" />
var pageManager;
var objPageManager;

$(document).ready(function () {
	rm.utilities.setSelectedNavLinkAndHelpUrl(editRequest.getRmPageLinkId());
	if (!editRequest.allowReqeustEdit()) {
		$("#RequestContent input:text").attr("disabled", "disabled");
		rm.ui.messages.showWarning(Resources.AssignedRequestReadOnly_StopDateIsInPast);
	}
	var showResoruceDetails = editRequest.getAssignedResoruceId() != "";
	if (showResoruceDetails) {
		resDtlNs.init(editRequest.infoContainerSelector, showResoruceDetails);
		resDtlNs.showSelectedResourcedetails(editRequest.getAssignedResoruceId());
	}
	prjDtlNs.init(editRequest.projectInfoContainerSelector, true, editRequest.getProjectId(), true);

	pageManager = editRequest.getPageManager(editRequest.getRequestTypeId(), editRequest.getResourceTypeId());

	var fteCalculatorHelpText = rm.utilities.getFteCalculatorTextByResourceTypeId(editRequest.getResourceTypeId());
	if (fteCalculatorHelpText == "") { $("#divFTECalcualtorText").html("").hide(); }
	else { $("#divFTECalcualtorText").html(fteCalculatorHelpText).show(); }

	if (!editRequest.isProposalRequest()) {
		rm.serviceCalls.getCustomFieldsByResourceTypeId(editRequest.getResourceTypeId(), editRequest.getRequestId(), editRequest.getProjectId(), function (response) {
			rm.customFields.renderResourceTypeCustomfields(response, $(editRequest.customFieldsContainerSelector), true, 1, function () {
				editRequest.bindDirty();
			});
		});
	}
	$(editRequest.fteSelector).bind('blur', function () { $.q.formatText(this); rm.ui.ribbon.delayedRefresh(); });

	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); rm.ui.ribbon.refresh(); });

	editRequest.bindDatePicker();
	editRequest.bindRegionChange();
	editRequest.bindCountryChange();
	editRequest.bindRequestBudgetedChange();
	editRequest.bindRequestBlindedChange();
	editRequest.bindLabelQtip();
	$('#radioblindedYes').click(function () { editRequest.handleRequestBlindedChange(true); });
	$('#radioblindedNo').click(function () { editRequest.handleRequestBlindedChange(true); });
	editRequest.bindMaxLengthOnReason();
	calculatorGroup.countryWeeklyHours = $(editRequest.countryWeeklyHoursSelector).val();

	editRequest.handleRequestBudgetedChange(true);
	calculatorHelper.selectedCountryId = editRequest.getCoutryId();
	calculatorHelper.selectedResourceTypeId = editRequest.getResourceTypeId();

	pageManager.draw();

	if (typeof qipOtherCalculator !== "undefined") {
		qipOtherCalculator.regionId = editRequest.getRegionId();
		qipOtherCalculator.countryId = editRequest.getCoutryId();
	}

	rm.ui.ribbon.delayedRefresh();

	$(document).on("change", ".ui-multiselect-checkboxes input", function () {
		editRequest.isMultiSelectDdlChanged = true;
		rm.ui.ribbon.refresh();
	});

	if ($("[id$=hdnIsOpenLabel]").val() == 'True') {
		$(editRequest.requestBlindedMainContainerSelector).addClass(editRequest.hideClass);
	}
	$(document).on("click", ".disconnectedFromCountry", function (event) {
		editRequest._isDateChanged = true;
	});

	if (editRequest.isDteProject() && !editRequest.hasUserdefinedSchemaForProject() && editRequest.isDteCheckRequiredForResoruceType()) {
		rm.ui.messages.addWarningAsBlock(Resources.UserDefinedSchemaMsgForCalculator);
	}
	editRequest.init();
});

var editRequest = {
	divSiteCountByStatusSelector: "#divSiteCountByStatus",
	infoContainerSelector: "#divInfoContainer",
	projectInfoContainerSelector: "#divProjectInfoContainer",
	hdnHasUserDefinedSchemaSelector: "[id$=hdnHasUserDefinedSchema]",
	connectedMilestoneDetails: {},
	accordionSettings: { collapsible: true },
	customFieldsContainerSelector: "#DynamicContent",
	getResourceTypeName: function () { return $("[id$=HdnResourceTypeName]").val(); },
	getCalculatorHeader: function () { return editRequest.getResourceTypeName() + " FTE Calculator"; },
	getRequestId: function () { return (1 * $("[id$=RequestId]").val()); },
	getRmPageLinkId: function () { return (1 * $("[id$=RmPageLinkId]").val()); },
	getRequestTypeId: function () { return (1 * $("[id$=RequestTypeId]").val()); },
	getRequestStatusId: function () { return (1 * $("[id$=RequestStatusId]").val()); },
	getRequestStopDate: function () { return $(editRequest.stopDateSelector).val(); },
	getRequestLastModifiedOn: function () { return ($(editRequest.requestLastModifiedOnSelector).val()); },
	getAttributeLastModifiedOn: function () { return ($(editRequest.attributeLastModifiedOnSelector).val() == "0" ? null : $(editRequest.attributeLastModifiedOnSelector).val()); },
	getSiteLastModifiedOn: function () { return ($(editRequest.siteLastModifiedOnSelector).val() == "0" ? null : $(editRequest.siteLastModifiedOnSelector).val()); },
	getAddressLastModifiedOn: function () { return ($(editRequest.addressLastModifiedOnSelector).val() == "0" ? null : $(editRequest.addressLastModifiedOnSelector).val()); },
	getPiLastModifiedOn: function () { return ($(editRequest.piLastModifiedOnSelector).val() == "0" ? null : $(editRequest.piLastModifiedOnSelector).val()); },
	getProjectLastModifiedOn: function () { return ($(editRequest.projectLastModifiedOnSelector).val()); },
	getResourceTypeId: function () { return (1 * $(editRequest.resourceTypeSelector).val()); },
	getRegionId: function () { return $(editRequest.requestRegionIdSelector).val(); },
	getOrganizationId: function () { return (1 * $(editRequest.organizationTypeSelector).val()); },
	getAssignedResoruceId: function () { return $("[id$=AssignedResoruceId]").val(); },
	getProjectId: function () { return (1 * $("[id$=ProjectId]").val()); },
	getSiteId: function () { return (1 * $("[id$=HdnSiteId]").val()); },
	getCoutryId: function () { return (1 * $(editRequest.countrySelector).val()); },
	getCountryIdFromDropdown: function () { return (1 * $(editRequest.countryDropdownSelector).val()); },
	getRegionIdFromDropdown: function () { return (1 * $(editRequest.regionDropdownSelector).val()); },
	getResourceTypeDetails: function () { return ResourceTypeDetails[editRequest.getResourceTypeId()]; },
	getCountryIdForFteCalculation: function () { return $(editRequest.countryDropdownSelector).is(":visible") ? editRequest.getCountryIdFromDropdown() : (1 * $(editRequest.countryIdForFteCalculationSelector).val()); },
	getJobRoleIdForFteCalculation: function () { return (1 * $(editRequest.jobRoleIdForFteCalculationSelector).val()); },
	isDteProject: function () { return $("[id$=isDteProject]").val() == "1"; },
	hasUserdefinedSchemaForProject: function () { return $(editRequest.hdnHasUserDefinedSchemaSelector).val() == "1"; },
	isDteCheckRequiredForResoruceType: function () { return ResourceTypeDetails[editRequest.getResourceTypeId()].DteCheckRequired; },
	isBackfillRequest: function () { return ($("[id$=IsBackfillRequest]").val() == "1"); },
	isGenericResourceType: function () { return ($("[id$=IsGenericResourceType]").val() == "1"); },
	isPermanentBackfillRequest: function () { return ($("[id$=IsPermanentBackfillRequest]").val() == "1"); },
	isProposalRequest: function () { return ($("[id$=IsProposalRequest]").val() == "1"); },
	isHardBooked: function () { return ($("[id$=IsHardBooked]").val() == "1"); },
	allowFteCalculatorEdits: function () { return ($("[id$=AllowFteCalculatorEdits]").val() == "1"); },
	allowReqeustEdit: function () { return ($("[id$=AllowRequestEdit]").val() == "1"); },
	getStartDateConnectStatus: function () { return $("[id$=StartDateConnectStatus]").val(); },
	getStopDateConnectStatus: function () { return $("[id$=StopDateConnectStatus]").val(); },
	getImDateConnectStatus: function () { return $("[id$=ImDateConnectStatus]").val(); },
	getCraTrainingDateConnectStatus: function () { return $("[id$=CraTrainingDateConnectStatus]").val(); },
	getResourceTransitionTimeinDays: function () { return $("[id$=ResourceTransitionTimeinDays]").val(); },
	getGenericResourceTransitionTimeinDays: function () { return $("[id$=GenericResourceTransitionTimeinDays]").val(); },
	getProtocol: function () { return $("[id$=hdnProtocol]").val(); },
	getProjectCode: function () { return $("[id$=hdnProjectCode]").val(); },
	getCoutryName: function () { return $(editRequest.countryDropdownSelector).is(":visible") ? $(editRequest.countryDropdownSelector + " option:selected").text() : $("[id$=hdnCountryName]").val();; },
	showCountryRegion: function () { return ($("[id$=ShowCountryRegion]").val() == "1"); },
	getTotalHours: function () { return $("[id$=TotalHours]").val(); },
	getTotalSites: function () { return ($(editRequest.totalSitesSelector).val() == '' ? null : $(editRequest.totalSitesSelector).val()); },
	showOriginalResourceStopDate: function () { return (editRequest.isBackfillRequest() && editRequest.getRmPageLinkId() == RmPageLink_E.BackfillRequests); },
	isUnassignedRequest: function () { return !editRequest.isHardBooked(); },
	isAssignAndSplitRequestEnabled: function () { return !editRequest.isSaveButtonEnabled() && editRequest.getResourceTypeDetails().AllowRequestSpliting; },
	requestLastModifiedOnSelector: "[id$=RequestLastModifiedOn]",
	attributeLastModifiedOnSelector: "[id$=AttributeLastModifiedOn]",
	projectLastModifiedOnSelector: "[id$=ProjectLastModifiedOn]",
	siteLastModifiedOnSelector: "[id$=SiteLastModifiedOn]",
	addressLastModifiedOnSelector: "[id$=AddressLastModifiedOn]",
	piLastModifiedOnSelector: "[id$=PiLastModifiedOn]",
	resourceTypeSelector: "[id$=ResourceTypeId]",
	organizationTypeSelector: "[id$=OrganizationId]",
	projectOrganizationIdSelector: "[id$=ProjectOrganizationId]",
	countrySelector: "[id$=CountryId]",
	countryIdForFteCalculationSelector: "[id$=CountryIdForFteCalculation]",
	startDateSelector: "[id$=txtStartDate]",
	stopDateSelector: "[id$=txtStopDate]",
	imDateSelector: "[id$=txtIMDate]",
	craTrainingDateSelector: "[id$=txtCRATrainingDate]",
	originalResourceStopDateSelector: "[id$=txtOriginalResourceStopDate]",
	needByDateSelector: "[id$=txtNeedByDate]",
	totalSitesSelector: "[id$=txtTotalSites]",
	lblSiteStatus: "[id$=lblSiteStatus]",
	ssvTypeId: "[id$=ssvTypeId]",
	requestRegionIdSelector: "[id$=requestRegionId]",
	radioRequestBudgetedNoSelector: "[id$=radioRequestBudgetedNo]",
	radioRequestBudgetedYesSelector: "[id$=radioRequestBudgetedYes]",
	radioRequestBudgetedSpanNoSelector: "#spanNo",
	radioRequestBudgetedSpanYesSelector: "#spanYes",
	radioRequestBlindedNoSelector: "[id$=radioblindedNo]",
	radioRequestBlindedYesSelector: "[id$=radioblindedYes]",
	radioRequestBlindedSpanNoSelector: "#spanBlindedNo",
	radioRequestBlindedSpanYesSelector: "#spanBlindedYes",
	fteSelector: "[id$=txtFte]",
	txtReasonSelector: "[id$=txtReason]",
	regionDropdownSelector: "[id$=ddlRegion]",
	countryDropdownSelector: "[id$=ddlCountry]",
	jobRoleIdForFteCalculationSelector: "[id$=jobRoleIdForFteCalculation]",
	isDirtySelector: "[id$=IsDirty]",
	countryWeeklyHoursSelector: "[id$=CountryWeeklyHours]",
	lblRemainingLengthSelector: "#lblRemainingLength",
	hideClass: "hideMe",
	originalResourceStopDateContainerSelector: "#OriginalResourceStopDateContainer",
	preferredLocationContainerSelector: "#PreferredLocationContainer",
	editableRegionContainerSelector: "#EditableRegionContainer",
	editableCountryContainerSelector: "#EditableCountryContainer",
	regionContainerSelector: "#RegionContainer",
	countryContainerSelector: "#CountryContainer",
	assignedLocationContainerSelector: "#AssignedLocationContainer",
	assignedRegionContainerSelector: "#AssignedRegionContainer",
	assignedCountryContainerSelector: "#AssignedCountryContainer",
	countryRegionContainerSelector: "#CountryRegionContainer",
	siteContainerSelector: "#SiteContainer",
	fieldDurationContainerSelector: "#FieldDurationContainer",
	piContainerSelector: "#PIContainer",
	visitTypeContainerSelector: "#VisitTypeContainer",
	craDateContainerSelector: "#CRADateContainer",
	imDateContainerSelector: "#IMDateContainer",
	startDateContainerSelector: "#StartDateContainer",
	stopDateContainerSelector: "#StopDateContainer",
	needByDateContainerSelector: "#NeedByDateContainer",
	totalSitesContainerSelector: "#TotalSitesContainer",
	fteContainerSelector: "#FteContainer",
	requestBudgetedMainContainerSelector: "#RequestBudgetedMainContainer",
	requestBlindedMainContainerSelector: "#initiateFieldBlindedSpan",
	qipClinicalCalculatorInnerContainer: "#calculatorContainer",
	qipOtherFteCalcContainerSelector: "#QipOtherFteCalcContainer",
	coMonFteCalcContainerSelector: "#CoMonFteCalcContainer",
	qipClinicalFteCalcContainerSelector: "#qipClinicalFteCalcContainer",
	genericFteCalcContainerSelector: "#GenericFTECalculatorContainer",
	siteStatusContainerSelector: "#SiteStatusContainer",
	reasonContainerSelector: "#ReasonContainer",
	SsvTypeContainerSelector: "#SsvTypeContainer",
	isSaveButtonEnabled: function () { return editRequest.isDirty(); },
	isCancelButtonEnabled: function () { return editRequest.isDirty(); },
	isCloseButtonEnabled: function () { return true; },
	isInterimFrequencyButtonEnabled: function () { return editRequest.allowReqeustEdit(); },
	dateEventsToBind: "keyup change cut paste drop",
	splitAndAssignButtonSelector: "[id*=SplitAndAssign]",
	_isDateChanged: false,
	isDateConnected: function (selector) { return $(selector).parent().find(".connectedToCountry,.connectedToPpm").length == 1 ? RequestConnect_E.Connected : RequestConnect_E.Disconnected; },
	_computedReqestMilestoneDaysToAdd: null,
	getComputedReqestMilestoneDaysToAdd: function () {
		if (editRequest._computedReqestMilestoneDaysToAdd == null) {
			$.rm.Ajax_RequestSynchronous("GetAllComputedReqestMilestoneDaysToAdd", {}, function (data) {
				editRequest._computedReqestMilestoneDaysToAdd = data;
			}, true);
		}

		return editRequest._computedReqestMilestoneDaysToAdd;
	},
	init: function () {
		rm.qtip.showInfoOnGridColumn(editRequest.splitAndAssignButtonSelector, "Split, and optionally assign, this request");
	},
	updateRequestStopDateFromComputedRequestMilestone: function (resourceTypeId, regionId) {
		if (ResourceTypeDetails[resourceTypeId].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Request) {
			var milestoneList = editRequest.getComputedReqestMilestoneDaysToAdd();
			$.each(milestoneList, function (index, item) {
				if ((ResourceTypeDetails[resourceTypeId].IsRegionBased && item.ResourceTypeId == resourceTypeId && item.RegionId == regionId) ||
					(!ResourceTypeDetails[resourceTypeId].IsRegionBased && item.ResourceTypeId == resourceTypeId)) {
					rm.validation.clearError($(editRequest.stopDateSelector));
					$(editRequest.stopDateSelector).val(rm.date.addDaysToQdate($(editRequest.startDateSelector).val(), item.DaysToAdd));
					return false;
				}
			});
		}
	},
	isMultiSelectDdlChanged: false,
	isStartDateDerivedFromCountry: function () {
		var resourceTypeDetails = editRequest.getResourceTypeDetails();
		return resourceTypeDetails.RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Monitoring || resourceTypeDetails.RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Ssv;
	},
	isStopDateDerivedFromCountry: function () {
		var resourceTypeDetails = editRequest.getResourceTypeDetails();
		return resourceTypeDetails.RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Monitoring || resourceTypeDetails.RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Ssv;
	},
	appendDisconnectedImge: function (dateControl, isDateDerivedFromCountry) {
		if (isDateDerivedFromCountry) { requestHelper.appendDisconnectedImageCountry(dateControl); }
		else { requestHelper.appendDisconnectedImagePpm(dateControl); }
	},
	appendConnectedImge: function (dateControl, isDateDerivedFromCountry) {
		if (isDateDerivedFromCountry) { requestHelper.appendConnectedImageCountry(dateControl); }
		else { requestHelper.appendConnectedImagePpm(dateControl); }
	},
	isCountrySpecificRequestGridChanged: false,
	isSiteListEnabled: function () {
		var showSiteList = $("[id$=hdnShowSiteList]").val();
		return showSiteList == 1 ? true : false;
	},

	viewProjectDetailsClick: function () { rm.uiComponents.showProjectDetails(editRequest.getProjectId()); },

	isViewProjectDetailsButtonEnabled: function () { return true; },


	getSelectedRequestDetails: function () {
		var selectedResourceTypeDetails = editRequest.getResourceTypeDetails();
		return {
			id: editRequest.getRequestId(),
			ResourceTypeId: selectedResourceTypeDetails.Id,
			JobRoleId: editRequest.getJobRoleIdForFteCalculation(),
			ResourceType: selectedResourceTypeDetails.Name,
			CountryId: editRequest.getCountryIdForFteCalculation(),
			Country: editRequest.getCoutryName(),
			TotalSites: editRequest.getTotalSites(),
			StartDate: $(editRequest.startDateSelector).val(),
			StopDate: $(editRequest.stopDateSelector).val(),
			ProjectCode: editRequest.getProjectCode(),
			Protocol: editRequest.getProtocol(),
			ProjectId: editRequest.getProjectId(),
			RequestStatusId: editRequest.getRequestStatusId(),
			AssignedResource: {
				Id: $("[id$=AssignedResoruceId]").val(),
				Name: $("[id$=AssignedResoruceName]").val(),
				QId: $("[id$=AssignedResoruceQid]").val()
			}
		};
	},
	assignAndSplitRequest: function () {
		splitAssignReq.showDialog(editRequest.getSelectedRequestDetails(), rm.utilities.reloadPage);
	},
	viewSiteListDetials: function () {
		var countryId = $("[id$=CountryId]").val();
		var projectId = editRequest.getProjectId();
		$.ajax({
			url: "../SiteListDetailsDialog.aspx?projectId=" + projectId + "&countryId=" + countryId + "",
			success: function (data) {
				$("#divSiteListDetails").html(data).dialog({
					autoOpen: false,
					draggable: false,
					modal: true,
					width: 1240,
					title: "Site List",
					height: 500,
					open: function (event, ui) {
						//hide close button.
						$(this).parent().children().children('.ui-dialog-titlebar-close').hide();
					},
					buttons: {
						"Close": function () {
							$(this).dialog("close");
						}
					}
				})
				$("#divSiteListDetails").dialog('open');
			},
			error: function (x, e) {
				alert(e);
			}
		});

	},
	isViewProjectMilestonesButtonEnabled: function () {
		return true;
	},
	handleOriginalResourceStopDateVisibility: function () {
		if (editRequest.showOriginalResourceStopDate()) {
			$(editRequest.originalResourceStopDateContainerSelector).removeClass(editRequest.hideClass)
			$(editRequest.originalResourceStopDateSelector).qDatepicker();
		}
	},
	handleRegionCountryVisibility: function () {
		var resourceTypeDetails = editRequest.getResourceTypeDetails();
		if (editRequest.isHardBooked()) {
			if (!resourceTypeDetails.IsGlobal) {
				$(editRequest.regionContainerSelector).removeClass(editRequest.hideClass);
				if (!resourceTypeDetails.IsRegionBased) { $(editRequest.countryContainerSelector).removeClass(editRequest.hideClass); }
			}
		}
		else {
			if (!resourceTypeDetails.IsGlobal) {
				$(editRequest.editableRegionContainerSelector).removeClass(editRequest.hideClass);
				if (!resourceTypeDetails.IsRegionBased) { $(editRequest.editableCountryContainerSelector).removeClass(editRequest.hideClass); }
			}
		}
	},
	getFlatFteValue: function () {
		if ($(editRequest.fteSelector).is(":visible")) {
			return $(editRequest.fteSelector).val();
		}
		else if ($.SmallFTECalculator != null) {
			return $.SmallFTECalculator.GetValues().FTE;
		}
		else { null; }
	},
	getTotalHoursFromUi: function () {
		return ($.SmallFTECalculator != null) ? $.SmallFTECalculator.GetValues().TotalHours : null;
	},
	getPostData: function () {
		var bigCalculatorData = (typeof calculatorHelper != "undefined") ? calculatorHelper.getCalculatorGroupData(calculatorHelper.getSelectedTabIndex(), false, new Array()) : null;
		var _adhocInitiateCalculator;
		var _adhocInitiateCalculatorTimestamp;
		if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
			_adhocInitiateCalculator = $.GenericFTECalculator ? $.GenericFTECalculator._adHocValues : null;
			_adhocInitiateCalculatorTimestamp = $.GenericFTECalculator ? $.GenericFTECalculator._adHocTimestampValues : null;
		}
		else {
			_adhocInitiateCalculator = $.Calculator ? $.Calculator._adHocValues : null;
			_adhocInitiateCalculatorTimestamp = $.Calculator ? $.Calculator._adHocTimestampValues : null;
		}
		var resourceTypeId = editRequest.getResourceTypeId();
		var postData =
		{
			modifiedRequest:
			{
				RequestTimestamp: {
					RequestLastModifiedOn: editRequest.getRequestLastModifiedOn(),
					AttributeLastModifiedOn: editRequest.getAttributeLastModifiedOn(),
					ProjectLastModifiedOn: editRequest.getProjectLastModifiedOn(),
					SiteLastModifiedOn: editRequest.getSiteLastModifiedOn(),
					AddressLastModifiedOn: editRequest.getAddressLastModifiedOn(),
					PiLastModifiedOn: editRequest.getPiLastModifiedOn()
				},
				RequestId: editRequest.getRequestId(),
				StartDate: $(editRequest.startDateSelector).val(),
				StartDateStatus: editRequest.isDateConnected(editRequest.startDateSelector),
				StopDate: $(editRequest.stopDateSelector).val(),
				StopDateStatus: editRequest.isDateConnected(editRequest.stopDateSelector),
				RegionId: (editRequest.isUnassignedRequest() && $(editRequest.regionDropdownSelector).is(":visible")) ? $(editRequest.regionDropdownSelector).val() : null,
				CountryId: editRequest.isUnassignedRequest() ? $(editRequest.countryDropdownSelector).val() : null,
				RequestBudgeted: $(editRequest.requestBudgetedMainContainerSelector).is(":visible") ? $(editRequest.radioRequestBudgetedYesSelector).is(":checked") : null,
				RequestBlinded: $(editRequest.requestBlindedMainContainerSelector).is(":visible") ? $(editRequest.radioRequestBlindedYesSelector).is(":checked") : null,
				Reason: $(editRequest.requestBudgetedMainContainerSelector).is(":visible") ? $(editRequest.txtReasonSelector).val() : null,
				FTE: editRequest.getFlatFteValue(),
				TotalHours: editRequest.getTotalHoursFromUi(),
				StaticInitiateCalculator: $.Calculator ? $.Calculator._staticValues : null,
				AdhocInitiateCalculator: _adhocInitiateCalculator,
				StaticInitiateCalcTimestamp: $.Calculator ? $.Calculator._staticTimestampValues : null,
				AdhocInitiateCalcTimestamp: _adhocInitiateCalculatorTimestamp,
				GenericInitiateCalculatorPhaseDate: $.GenericFTECalculator ? $.GenericFTECalculator._genericRowsValues : null,
				GenericInitiateCalcTimestamp: $.GenericFTECalculator ? $.GenericFTECalculator._genericRowTimestampValues : null,
				calculatorGroupData: bigCalculatorData,

				CraTrainingDate: $(editRequest.craTrainingDateSelector).is(":visible") ? $(editRequest.craTrainingDateSelector).val() : null,
				CraTrainingDateStatus: editRequest.isDateConnected(editRequest.craTrainingDateSelector),
				IMDate: $(editRequest.imDateSelector).is(":visible") ? $(editRequest.imDateSelector).val() : null,
				IMDateStatus: editRequest.isDateConnected(editRequest.imDateSelector),
				OriginalResourceStopDate: editRequest.isBackfillRequest() ? $(editRequest.originalResourceStopDateSelector).val() : null,
				DynamicCustomFieldsData: rm.customFields.getCustomFieldUserEnteredValues($(editRequest.customFieldsContainerSelector)),
				TotalSites: editRequest.getTotalSites()
			}
		};
		return postData;
	},

	save: function () {
		if (pageManager.isValid()) {
			calculatorHelper.dataChangeValidationRequired = false;//to avoid checking if DTE,Visitschemalevelid was changed as this request is not in new,closed or deleted.
			if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
				var milestoneIds = $.GenericFTECalculator.GetAllCustomMilestoneIds();
				$.validationHelper.GetCustomeMilestoneStatus($("[id$=RequestId]").val(), milestoneIds, true, false, $.GenericFTECalculator.DeletedMilestones);
			}
			if (!$.validationHelper.isAnyMilestoneDeactivated) {
				pageManager.updateRequest();
			}
		}
		else {
			rm.ui.messages.addError(Resources.NoDataSaved);
		}
	},

	ValidateDynamicCustomFields: function () { return rm.customFields.areCustomFieldsValid($(editRequest.customFieldsContainerSelector)); },

	saveCoMonitoringReqeust: function () {

		$.SmallFTECalculator.CalculateTotalHours();
		editRequest.makeSaveAjaxCall();
	},

	saveQipClinicalReqeust: function () {
		calculatorHelper.connectStatusDialogOnOkClick = editRequest.makeSaveAjaxCall;
		calculatorGroup.saveCalculator(false);
	},

	saveGenericReqeust: function () {
		if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
			$.GenericFTECalculator.CalculateWeeklyHoursOrFteOnRibbonClick();

			setTimeout(function () {

				$.GenericFTECalculator.save(false);
				editRequest.makeSaveAjaxCall();

			}, 100);
		}
	},
	saveQipRegionalReqeust: function () { editRequest.saveQipOtherReqeust(); },
	saveQipOtherReqeust: function () {
		$.Calculator.CalculateWeeklyHoursOrFteOnRibbonClick();

		setTimeout(function () {
			if ($.Calculator.IsPromptRequiredForConnectDisconnectStatus()) {
				$.Calculator.DialogOkClickHandler = editRequest.makeSaveAjaxCall;
				$.Calculator.ShowConnectDisconnectChoiceDialog();
			}
			else {
				$.Calculator.save(false);
				editRequest.makeSaveAjaxCall();
			}
		}, 100);
	},

	saveReqeustWithNoCalculator: function () {
		editRequest.makeSaveAjaxCall();
	},

	makeSaveAjaxCall: function () {

		if (editRequest.isBackfillRequest() &&
			editRequest.showOriginalResourceStopDate() &&
			rm.date.getDateFromQDateString($(editRequest.originalResourceStopDateSelector).val()) < rm.date.getDateFromQDateString($(editRequest.startDateSelector).val()) &&
			!confirm(Resources.ResourceStopDateLessThanBackfillStartDate)) {
			return false;
		}

		var postData = editRequest.getPostData();
		$.rm.Ajax_Request("saveEditRequest", postData, function (data) {
			if (data.ContainsValidationErrors) {
				if (data.ValidationErrors[0].Key == "DisabledTiers")/*request has disabled tiers , so just reload the tier dropdown*/ {
					$.validationHelper.ShowErrorMessages(data.ValidationErrors);
					editRequest.LoadTierDropdowns();
				}
				else {
					rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
					$.validationHelper.ShowErrorMessages(data.ValidationErrors);
				}
			}
			else {
				rm.ui.messages.clearAllMessages();
				var resourceTypeDetails = editRequest.getResourceTypeDetails();
				if (!editRequest.isHardBooked() && !resourceTypeDetails.IsGlobal) {
					$(editRequest.requestRegionIdSelector).val(editRequest.getRegionIdFromDropdown());
					if (!resourceTypeDetails.IsRegionBased) { $(editRequest.countrySelector).val(editRequest.getCountryIdFromDropdown()); }
				}

				pageManager.onSaveSuccess(data.QipCliniclaCalculatorStatus);
				editRequest.onSaveSuccess();
				//editRequest.clearDirty();
				$(editRequest.requestLastModifiedOnSelector).val(data.RequestStatus.RequestTimeStamp);
				$(editRequest.attributeLastModifiedOnSelector).val(data.RequestStatus.AttributeTimeStamp);
				$(editRequest.projectLastModifiedOnSelector).val(data.RequestStatus.ProjectTimeStamp);
				rm.ui.messages.showSuccess(Resources.DataSavedSuccessfully);
				$(editRequest.isDirtySelector).val("0");

				setTimeout(function () {
					editRequest.bindDirty();
					rm.ui.ribbon.delayedRefresh();
				}, 10);

			}
		}, false);
	},

	cancel: function () {
		var isDirty = editRequest.isDirty();

		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			RefreshPage();
		}
	},

	close: function () {
		var isDirty = editRequest.isDirty();

		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null; //Prevent prompt
			var rmPageLinkId = editRequest.getRmPageLinkId();

			if (RmPageLink_E.SSVRequests == rmPageLinkId ||
				RmPageLink_E.Autogenerated_SsvRequests == rmPageLinkId ||
				RmPageLink_E.MonitoringSsvAttributesAllZero_All_Ssv == rmPageLinkId ||
				RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Ssv == rmPageLinkId) {
				document.location.href = "/_layouts/SPUI/Notification/SSVRequest.aspx?rmPageLink=" + rmPageLinkId;
			}
			else if (RmPageLink_E.MonitoringRequests == rmPageLinkId ||
				RmPageLink_E.Autogenerated_MonitoringRequests == rmPageLinkId ||
				RmPageLink_E.MonitoringSsvAttributesAllZero_All_Monitoring == rmPageLinkId ||
				RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Monitoring == rmPageLinkId) {
				document.location.href = "/_layouts/SPUI/Notification/PermanentRequest.aspx?rmPageLink=" + rmPageLinkId;
			}
			else if (RmPageLink_E.ResourcingWorklist == rmPageLinkId) {
				document.location.href = "/_layouts/SPUI/Requests/ResourceSearch.aspx?RequestGroupId=" + rm.queryString.getValue("RequestGroupId");
			}
			else if (RmPageLink_E.MyStaff == rmPageLinkId) {
				window.close();
			}
			else {
				document.location.href = "/_layouts/SPUI/Requests/SubmittedRequest.aspx?rmPageLink=" + rmPageLinkId;
			}
		}
	},

	onSaveSuccess: function () {
		if (editRequest.isPermanentBackfillRequest() && editRequest.getRmPageLinkId() == RmPageLink_E.BackfillRequests)/*ss:added and condition based on lynne confirmation QRPM-8138*/ {
			alert("Please navigate to  \"Submitted Requests\" to change the FTE of the original request, if an FTE change is required.");
		}
	},

	onDrawComplete: function () { editRequest.bindDirty(); },

	handleStartDateChange: function () {
		editRequest.calculateNeedByDate();
		editRequest.onAfterConnectIconClick();
	},

	handleStartDateChangePpm: function (event) {
		var checkConnectStatus = true;
		if (event) {
			var keyCode = event.which || event.keyCode;
			checkConnectStatus = !$.q.isNonPrintableKey(keyCode);
		}

		if (checkConnectStatus) {
			var txtBox = $(this);
			setTimeout(function () {
				requestHelper.handleStartStopDateChangePpm(txtBox, true);
				editRequest.onAfterConnectIconClick();
			}, 5);
		}
	},

	handleOtherDateChangePpm: function () {
		requestHelper.handleStartStopDateChangePpm($(this), false);
		editRequest.onAfterConnectIconClick();
	},
	calculateNeedByDateHandler: function () { setTimeout(editRequest.calculateNeedByDate, 10); },

	handleStartDateChangePpmImageClick: function (context, onClickFunctionString) {
		requestHelper.handleStartStopDateChangePpm($(context), true, onClickFunctionString);
		editRequest.onAfterConnectIconClick();
	},

	handleOtherDateChangePpmImageClick: function (context, onClickFunctionString) {
		requestHelper.handleStartStopDateChangePpm($(context), false, onClickFunctionString);
		editRequest.onAfterConnectIconClick();
	},

	handleStartDateChangeCountry: function (event) {
		var checkConnectStatus = true;
		if (event) {
			var keyCode = event.which || event.keyCode;
			checkConnectStatus = !$.q.isNonPrintableKey(keyCode);
		}

		if (checkConnectStatus) {
			var txtBox = $(this);
			setTimeout(function () {
				requestHelper.handleStartStopDateChangeCountry(txtBox, true);
				editRequest.onAfterConnectIconClick();
			}, 5);
		}
	},

	handleOtherDateChangeCountry: function () {
		requestHelper.handleStartStopDateChangeCountry($(this), false);
		editRequest.onAfterConnectIconClick();
	},

	handleProposalStartDateChangeCountry: function () {
		editRequest.calculateNeedByDate();
	},

	//Handle Start and Stop  Date Change for SSV Country Specific RRTS

	handleSSVCountrySpecificRequestStartStopDateChange: function () {
		if (editRequest.isDateValid($(editRequest.startDateSelector)) && editRequest.isDateValid($(editRequest.stopDateSelector)))//First check whether the Request Date is Valid
		{
			//We must change the Montlhy FTE in each rows of the Grid which is in inline edit mode.
			var startDate = (new Date($.datepicker.formatDate("mm/dd/yy", $(editRequest.startDateSelector).datepicker("getDate"))) < new Date($.datepicker.formatDate('mm/dd/yy', new Date()))) ? $.datepicker.formatDate('mm/dd/yy', new Date()) : $(editRequest.startDateSelector).val();
			var stopDate = $(editRequest.stopDateSelector).val();
			// For Each Rows  
			$.each($('#list').jqGrid('getDataIDs'), function (index, element) {
				if ($('#' + element + '_TotalHours').val() != "." && $('#' + element + '_TotalHours').val() != "" && (element.startsWith('jqg') || parseInt(element) == editRequest.getRequestId())) {
					var postData =
					{
						resourceTypeId: 0,
						countryId: parseInt(editRequest.getCoutryId() == null ? 0 : editRequest.getCoutryId()),
						startDate: startDate,
						stopDate: stopDate,
						modifiedWeeklyHoursFTE: parseFloat($('#' + element + '_TotalHours').val() == "" ? 0 : $('#' + element + '_TotalHours').val()),
						hoursPerSite: 0,//this is not needed to get monthly fte

					};
					$.rm.Ajax_Utility("CalculateFTE", postData, function (data) {
						$('#list').setRowData(element, {
							MonthlyFTE: data.MonthlyFTE
						});
					}, true, false);
				}
			});
			rmSSVCountrySpecificGridCustomCode.calculateTotal();
		}
	},

	//End


	onAfterConnectIconClick: function () { rm.ui.ribbon.delayedRefresh(); },

	setPageIsDirty: function () { $(editRequest.isDirtySelector).val("1"); },

	bindDirty: function () {
		setTimeout(function () {
			rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, editRequest.getJsonObjectForDirtyCheck());
			$(editRequest.getJsonObjectForDirtyCheck().items[0].selector).unbind('change', editRequest.handleChangeRangeValidateTextBox).change(editRequest.handleChangeRangeValidateTextBox).unbind('keyup', editRequest.handleChangeRangeValidateTextBox).keyup(editRequest.handleChangeRangeValidateTextBox).unbind('cut', editRequest.handleChangeRangeValidateTextBox).bind("cut", editRequest.handleChangeRangeValidateTextBox).unbind('paste', editRequest.handleChangeRangeValidateTextBox).bind("paste", editRequest.handleChangeRangeValidateTextBox);
			rm.ui.ribbon.delayedRefresh();
		}, 10);
	},

	handleChangeRangeValidateTextBox: function () {
		editRequest.setPageIsDirty();
		rm.ui.ribbon.delayedRefresh();
	},

	clearDirty: function () { $.formStatus.clearDirty(editRequest.getJsonObjectForDirtyCheck()); },
	isDirty: function () { return $.formStatus.isDirty(editRequest.getJsonObjectForDirtyCheck()) || (editRequest.isMultiSelectDdlChanged) || (editRequest.isCountrySpecificRequestGridChanged); },
	getJsonObjectForDirtyCheck: function () { return { items: [{ selector: "#RequestContent input:text:not([readonly]),#RequestContent select:visible,#RequestContent textarea:visible,#RequestContent input:radio:visible,#RequestContent input:checkbox, #RequestContent [type=hidden]", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },

	initializeQipGlobalCalculator: function (calculatorHeading) {
		var arePreviousValuesShown = editRequest.previousValuesShown();
		qipOtherCalculator.isRegionBasedCalculator = false;
		qipOtherCalculator.isGlobalCalculator = true;
		qipOtherCalculator.getOrganizationIdFromUi = function () { return $(editRequest.projectOrganizationIdSelector).val(); };
		qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return editRequest.isProposalRequest(); };
		qipOtherCalculator.getCountryIdFromUi = function () { return null; };
		qipOtherCalculator.getCountryIdForFteCalculation = editRequest.getCountryIdForFteCalculation;
		qipOtherCalculator.getJobRoleIdForFteCalculation = editRequest.getJobRoleIdForFteCalculation;
		qipOtherCalculator.getRequestStopDateFromUi = editRequest.getRequestStopDate;

		$.Calculator.ClearCalculatorDirty();
		$.Calculator.OnConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnCalculatorEdit = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.AfterCalculatorDraw = function () {
			$.Calculator.ClearCalculatorDirty();
		};
		$.Calculator._countryId = editRequest.getCoutryId();
		$.Calculator._resourceTypeId = editRequest.getResourceTypeId();
		$.Calculator.AllowEditing = editRequest.allowReqeustEdit();
		//$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) { editRequest.phaseCalculatorRenderCompleteHandlerForProposal(qipData); };
		$.Calculator.renderCalculator(editRequest.getRequestId(), null, $.Calculator._resourceTypeId, $.Calculator._countryId, calculatorHeading, false, $(editRequest.requestRegionIdSelector).val(), editRequest.getRequestId(), $(editRequest.projectOrganizationIdSelector).val());
		setTimeout(function () {
			if (arePreviousValuesShown) {
				$.Calculator.ShowPreviousPhaseValues();
			}
		}, 5);
	},
	initializeQipRegionalCalculator: function (calculatorHeading) {
		var arePreviousValuesShown = editRequest.previousValuesShown();
		qipOtherCalculator.isRegionBasedCalculator = true;
		qipOtherCalculator.isGlobalCalculator = false;
		if (editRequest.isHardBooked()) {
			qipOtherCalculator.getRegionIdFromUi = function () { return $(editRequest.requestRegionIdSelector).val(); };
		}
		else {
			qipOtherCalculator.getRegionIdFromUi = editRequest.getRegionIdFromDropdown;
		}
		qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return editRequest.isProposalRequest(); };
		qipOtherCalculator.getCountryIdForFteCalculation = editRequest.getCountryIdForFteCalculation;
		qipOtherCalculator.getRequestStopDateFromUi = editRequest.getRequestStopDate;
		qipOtherCalculator.getJobRoleIdForFteCalculation = editRequest.getJobRoleIdForFteCalculation;

		$.Calculator.ClearCalculatorDirty();
		$.Calculator.OnConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnCalculatorEdit = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.AfterCalculatorDraw = function () {
			$.Calculator.ClearCalculatorDirty();
		};
		$.Calculator._countryId = editRequest.getCoutryId();
		$.Calculator._resourceTypeId = editRequest.getResourceTypeId();
		$.Calculator.AllowEditing = editRequest.allowReqeustEdit();
		//$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) { editRequest.phaseCalculatorRenderCompleteHandlerForProposal(qipData); };
		$.Calculator.renderCalculator(editRequest.getRequestId(), null, $.Calculator._resourceTypeId, $.Calculator._countryId, calculatorHeading, false, $(editRequest.requestRegionIdSelector).val(), editRequest.getRequestId());
		setTimeout(function () {
			if (arePreviousValuesShown) {
				$.Calculator.ShowPreviousPhaseValues();
			}
		}, 5);
	},
	initializeQipOtherCalculator: function (calculatorHeading) {
		var arePreviousValuesShown = editRequest.previousValuesShown();
		qipOtherCalculator.isRegionBasedCalculator = false;
		qipOtherCalculator.isGlobalCalculator = false;
		qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return editRequest.isProposalRequest(); };
		if (editRequest.isHardBooked()) {
			qipOtherCalculator.getCountryIdFromUi = editRequest.getCoutryId;
		}
		else {
			qipOtherCalculator.getCountryIdFromUi = editRequest.getCountryIdFromDropdown;
		}
		qipOtherCalculator.getCountryIdForFteCalculation = editRequest.getCountryIdForFteCalculation;
		qipOtherCalculator.getRequestStopDateFromUi = editRequest.getRequestStopDate;
		qipOtherCalculator.getJobRoleIdForFteCalculation = editRequest.getJobRoleIdForFteCalculation;

		$.Calculator.ClearCalculatorDirty();
		$.Calculator.OnConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnCalculatorEdit = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.AfterCalculatorDraw = function () {
			$.Calculator.ClearCalculatorDirty();
		};
		$.Calculator._countryId = editRequest.getCoutryId();
		$.Calculator._resourceTypeId = editRequest.getResourceTypeId();
		$.Calculator.AllowEditing = editRequest.allowReqeustEdit();

		//$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) { editRequest.phaseCalculatorRenderCompleteHandlerForProposal(qipData); };

		$.Calculator.renderCalculator(editRequest.getRequestId(), null, $.Calculator._resourceTypeId, $.Calculator._countryId, calculatorHeading, false, null, editRequest.getRequestId());
		setTimeout(function () {
			if (arePreviousValuesShown) {
				$.Calculator.ShowPreviousPhaseValues();
			}
		}, 5);
	},
	initializeGenericCalculator: function (calculatorHeading) {
		var arePreviousValuesShown = editRequest.previousValuesShown();
		if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
			$.GenericFTECalculator.ClearCalculatorDirty();
			$.GenericFTECalculator.OnConnectImageClick = function () { rm.ui.ribbon.refresh(); };
			$.GenericFTECalculator.OnDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
			$.GenericFTECalculator.OnCalculatorEdit = function () { rm.ui.ribbon.refresh(); };
			$.GenericFTECalculator.AfterCalculatorDraw = function () {
				$.GenericFTECalculator.ClearCalculatorDirty();
			};
			$.GenericFTECalculator._countryId = editRequest.getCoutryId();
			$.GenericFTECalculator._resourceId = editRequest.getResourceTypeId();
			$.GenericFTECalculator.AllowEditing = editRequest.allowFteCalculatorEdits();
			genericCalculator.getRequestStopDateFromUi = editRequest.getRequestStopDate;
			genericCalculator.getCountryIdForFteCalculation = editRequest.getCountryIdForFteCalculation;
			genericCalculator.getJobRoleIdForFteCalculation = editRequest.getJobRoleIdForFteCalculation;

			$.GenericFTECalculator.renderCalculator(editRequest.getRequestId(), editRequest.getProjectId(), $.GenericFTECalculator._resourceId, $.GenericFTECalculator._countryId, calculatorHeading, false, editRequest.getOrganizationId());
		}
	},

	LoadTierDropdowns: function () {
		var postData =
		{
			calculatorTypeId: ResourceTypeName.DTESite_Monitoring == editRequest.getResourceTypeId() ? CalculatorGroup_E.DTEMonitoringCalculator : CalculatorGroup_E.DTEPharmacyCalculator,
			projectId: editRequest.getProjectId(),
			countryId: editRequest.getCoutryId()
		};
		$.rm.Ajax_Calculator("GetDefaultTier", postData, function (data) {
			if (ResourceTypeName.DTESite_Monitoring == editRequest.getResourceTypeId()) {
				editRequest.Fill(".ddltier_freq1", data[0].Value.FrequencyTiers, "Key Value", data[0].Value.DefaultTier.Key, false);
				editRequest.Fill(".ddltier_freq2", data[1].Value.FrequencyTiers, "Key Value", data[1].Value.DefaultTier.Key, false);

				// Re-bind tooltip ** REQUIRED FOR JAPAN ** - remember to destroy the old_title to enable resetting.
				$("#" + $('.ddltier_freq1').attr('id')).qtip('destroy');
				$("#" + $('.ddltier_freq2').attr('id')).qtip('destroy');
				rm.qtip.showInfo("#" + $('.ddltier_freq1').attr('id'), $(".ddltier_freq1 option:selected").text().toLowerCase() == 'trad' ? 'Traditional' : "The selected Tier will set the Visit Frequency");
				rm.qtip.showInfo("#" + $('.ddltier_freq2').attr('id'), $(".ddltier_freq2 option:selected").text().toLowerCase() == 'trad' ? 'Traditional' : "The selected Tier will set the Visit Frequency");
			}
			else {
				editRequest.Fill(".ddltier_pharma", data[0].Value.FrequencyTiers, "Key Value", data[0].Value.DefaultTier.Key, false);

				// QRPM-6687: TL: Trigger the onchange event to set the Visit Frequency Weeks.
				$(".ddltier_pharma").trigger("change");

				// Re-bind tooltip ** REQUIRED FOR JAPAN ** - remember to destroy the old_title to enable resetting.
				$("#" + $('.ddltier_pharma').attr('id')).qtip('destroy');
				rm.qtip.showInfo("#" + $('.ddltier_pharma').attr('id'), $(".ddltier_pharma option:selected").text().toLowerCase() == 'trad' ? 'Traditional' : "The selected Tier will set the Visit Frequency");
			}
		}, true, false);
	},

	Fill: function (selector, data, keyValueName, selected, defaultRequired) {
		if (defaultRequired != false) {
			$(selector).empty().append($("<option>").val("-1").html("--Select--"));
		}
		else {
			$(selector).empty();
		}
		$.each(data, function (index, element) {
			switch (keyValueName) {
				case "Key Value":
					{
						if (element.Key == selected) {
							$(selector).append($("<option selected>").val(element.Key).html(element.Value));
						}
						else {
							$(selector).append($("<option>").val(element.Key).html(element.Value));
						}
						break;
					}
				default:
			}
		});
	},

	previousValuesShown: function () { return $(".oldValue:visible").length > 0; },

	onSaveSuccessQipGlobalalculator: function (calculatorHeading) { editRequest.initializeQipGlobalCalculator(calculatorHeading); },
	onSaveSuccessQipRegionalCalculator: function (calculatorHeading) { editRequest.initializeQipRegionalCalculator(calculatorHeading); },
	onSaveSuccessQipOtherCalculator: function (calculatorHeading) { editRequest.initializeQipOtherCalculator(calculatorHeading); },
	onSaveSuccessGenericCalculator: function (CalculatorHeading) { editRequest.initializeGenericCalculator(CalculatorHeading); },

	updatePreviousValuesIfVisible: function () {
		if (editRequest.previousValuesShown()) {
			calculatorGroup.showPreviousValues();
		}
	},
	initializeQipClinicalCalculator: function () {
		calculatorHelper.onConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		calculatorHelper.onDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		calculatorHelper.onAdhocDateEdit = function () { rm.ui.ribbon.refresh(); };
		calculatorHelper.handleDirty = false;
		calculatorHelper.onTabReady = function () { calculatorHelper.handleCovByCountryId(editRequest.getCoutryId()); };
		calculatorHelper.getRequestStopDateFromUi = editRequest.getRequestStopDate;
	},

	clearDirtyCoMonitoirngCalculator: function () {
		$.SmallFTECalculator.ClearCalculatorDirty();
	},

	isQipOtherCalculatorValid: function () {
		if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
			var isValid = true;
			if (!$.GenericFTECalculator.saveCalculator()) { isValid = false; }
			if (!$.GenericFTECalculator.IsValid()) { isValid = false; }
			return isValid;
		}
		else {
			return $.Calculator.isValid();
		}
	},

	isQipClinicalCalculatorValid: function () {
		var isValid = true;

		if (typeof calculatorHelper != "undefined" &&
			!calculatorHelper.isCalculatorValid(calculatorIdJson, calculatorHelper.getSelectedTabIndex())) {
			isValid = false;

			if (!$(editRequest.qipClinicalCalculatorInnerContainer).is(":visible")) {
				$(editRequest.qipClinicalFteCalcContainerSelector).accordion("option", "active", 0);
			}
		}

		return isValid;
	},

	isBaseValid: function () {
		var isValid = true;


		if ($(editRequest.startDateSelector).val() == "") {
			isValid = false;
			rm.validation.addError($(editRequest.startDateSelector), Resources.StartDateIsBlank);
		}
		else if (!editRequest.isDateValid($(editRequest.startDateSelector))) { isValid = false; }
		else if ($.datepicker.formatDate("mm/dd/yy", $(editRequest.startDateSelector).datepicker("getDate")) != $("[id$=OldStartDateValue]").val()) {
			if (rm.date.isQDateDateInPast($(editRequest.startDateSelector).val())) {
				rm.validation.addError($(editRequest.startDateSelector), Resources.StartDateInPast);
				isValid = false;
			}
			else {
				rm.validation.clearError($(editRequest.startDateSelector));
			}
		}

		if ($(editRequest.stopDateSelector).val() == "") {
			isValid = false;
			rm.validation.addError($(editRequest.stopDateSelector), Resources.StopDateIsBlank);
		}
		else if (!editRequest.isDateValid($(editRequest.stopDateSelector))) { isValid = false; }
		else if (rm.date.isQDateDateInPast($(editRequest.stopDateSelector).val())) {
			rm.validation.addError($(editRequest.stopDateSelector), Resources.StopDateInPast);
			isValid = false;
		}
		else {
			rm.validation.clearError($(editRequest.stopDateSelector));
		}

		var imDate = $(editRequest.imDateSelector);
		if (imDate.is(":visible") && imDate.val() != "" && !editRequest.isDateValid(imDate)) { isValid = false; }

		var craTrainingDate = $(editRequest.craTrainingDateSelector);
		if (craTrainingDate.is(":visible") && craTrainingDate.val() != "" && !editRequest.isDateValid(craTrainingDate)) { isValid = false; }

		if (editRequest.showOriginalResourceStopDate()) {
			var originalResourceStopDate = $(editRequest.originalResourceStopDateSelector);
			if (!editRequest.isDateValid(originalResourceStopDate)) // Validate original resource's Stop Date
			{
				isValid = false;
			}
		}

		if ($(editRequest.requestBlindedMainContainerSelector).is(":visible")) {
			var rbbYes = $(editRequest.radioRequestBlindedYesSelector);
			var rbbNo = $(editRequest.radioRequestBlindedNoSelector);
			if (!rbbNo.is(":checked") && !rbbYes.is(":checked")) {
				rm.validation.addError($(editRequest.radioRequestBlindedSpanYesSelector), Resources.RequestBlindedRequired);
				rm.validation.addError($(editRequest.radioRequestBlindedSpanNoSelector), Resources.RequestBlindedRequired);
				isValid = false;
			}
			else {
				rm.validation.clearError($(editRequest.radioRequestBlindedSpanYesSelector));
				rm.validation.clearError($(editRequest.radioRequestBlindedSpanNoSelector));
			}
		}

		if ($(editRequest.requestBudgetedMainContainerSelector).is(":visible")) {

			var rbYes = $(editRequest.radioRequestBudgetedYesSelector);
			var rbNo = $(editRequest.radioRequestBudgetedNoSelector);
			var reason = $(editRequest.txtReasonSelector);
			if (!rbNo.is(":checked") && !rbYes.is(":checked")) {
				rm.validation.addError(editRequest.radioRequestBudgetedSpanYesSelector, Resources.RequestBudgetedRequired);
				rm.validation.addError(editRequest.radioRequestBudgetedSpanNoSelector, Resources.RequestBudgetedRequired);
				isValid = false;
			}
			else if (rbNo.is(":checked")) // Validate reason
			{
				if ($.trim(reason.val()) == "") {
					rm.validation.addError(editRequest.txtReasonSelector, Resources.ReasonRequired);
					isValid = false;
				}
				else if (!editRequest.isMaxLengthWithinRange(reason)) {
					isValid = false;
				}
			}
		}

		var regionDropdown = $(editRequest.regionDropdownSelector);
		rm.validation.clearError(regionDropdown);
		if (regionDropdown.is(":visible") && regionDropdown.val() == "-1") {
			rm.validation.addError(regionDropdown, Resources.RegionRequired);
			isValid = false;
		}

		var countryDropdown = $(editRequest.countryDropdownSelector);
		rm.validation.clearError(countryDropdown);
		if (countryDropdown.is(":visible") && countryDropdown.val() == "-1") {
			rm.validation.addError(countryDropdown, Resources.CountryRequired);
			isValid = false;
		}

		var totalSitesTextBox = $(editRequest.totalSitesSelector);
		if (totalSitesTextBox.is(":visible") && !rm.validation.range.validate(totalSitesTextBox)) {
			isValid = false;
		}

		return isValid;
	},

	isFlatFteValueValid: function () {
		var isValid = true;

		var fteTextBox = $(editRequest.fteSelector);
		if (fteTextBox.is(":visible") && !$.q.rangeValidate(fteTextBox)) {
			isValid = false;
		}

		return isValid;
	},

	isProposalRequestValid: function () {
		return editRequest.isFlatFteValueValid();
	},

	setNeedByDate: function (startDateValue, resourceTransitionTimeInDays) {
		$(editRequest.needByDateSelector).val("");
		if (startDateValue != "") {
			$(editRequest.needByDateSelector).val(rm.bizRules.getNeedByDate(startDateValue, resourceTransitionTimeInDays));
		}
	},

	bindLabelQtip: function () {
		rm.qtip.showInfo("#imgUnblindedResource", "Will the resource assigned to this study request be 'Unblinded' ? If you are requesting an Unblinded resource, then your project must have an unblinded component");
	},
	bindDatePicker: function () {
		$(editRequest.startDateSelector).qDatepicker();
		$(editRequest.stopDateSelector).qDatepicker();
		$(editRequest.imDateSelector).qDatepicker();
		$(editRequest.craTrainingDateSelector).qDatepicker();
	},

	bindRequestBudgetedChange: function () {
		$(editRequest.radioRequestBudgetedNoSelector + "," + editRequest.radioRequestBudgetedYesSelector).bind("change", function () { editRequest.handleRequestBudgetedChange(false) });
	},

	bindRequestBlindedChange: function () {
		$(editRequest.radioRequestBlindedNoSelector + "," + editRequest.radioRequestBlindedYesSelector).bind("change", function () { editRequest.handleRequestBlindedChange(false) });
	},

	bindRegionChange: function () {
		var ddlRegionObject = $(editRequest.regionDropdownSelector);
		ddlRegionObject.change(function () {
			editRequest.setPageIsDirty();
			var regionId = ddlRegionObject.val();
			var resourceTypeDetails = editRequest.getResourceTypeDetails();
			if (resourceTypeDetails.IsRegionBased) {
				if (confirm('You are changing the Region location. Please select OK to retain the current start, stop date and weekly hours. Click Cancel to reset and load the values for the new region.')) {
					$.Calculator.disconnectAll();
					$.Calculator.UpdatedRegionalConnedtedValues(editRequest.getRequestId(), editRequest.getProjectId(), editRequest.getResourceTypeId(), regionId);
					setTimeout($.Calculator.RecalculateFTEValues, 10);
				}
				else {
					$.Calculator.DeleteAllAdHocRow();
					editRequest.drawRegionBasedCalculator(editRequest.getResourceTypeName() + "Calculator");
					editRequest.updateRequestStopDateFromComputedRequestMilestone(editRequest.getResourceTypeId(), editRequest.getRegionIdFromDropdown());
				}
			}

			if (!resourceTypeDetails.IsRegionBased) {
				var countryDropdown = $(editRequest.countryDropdownSelector).empty().append($("<option>").val("-1").html("--Select--"));
				if (regionId != "-1") {
					rm.validation.clearError(ddlRegionObject);
					rm.validation.clearError(countryDropdown);
					var postData = { regionIds: regionId };
					$.rm.Ajax_Utility("GetAllCountriesByRegion", postData, function (data) {
						$.each(data, function (index, element) {
							countryDropdown.append($("<option>").val(element.key).html(element.value));
						});
					}, true, true);
				}
			}
		});
	},

	bindCountryChange: function () {
		var ddlCountryObject = $(editRequest.countryDropdownSelector);
		ddlCountryObject.change(function () {
			editRequest.setPageIsDirty();
			if (ddlCountryObject.val() != "-1") {
				rm.validation.clearError(ddlCountryObject);
			}

			//If request is not hard booked and if country is changed, then the fte calculation should happen based on new countryId
			if (!editRequest.isHardBooked) {
				$(editRequest.countryIdForFteCalculationSelector).val(editRequest.getCountryIdFromDropdown());
			}

			if (objPageManager.Id != PageManagerType_E.Proposal_Base_PageManager) {
				var resourceTypeDetails = editRequest.getResourceTypeDetails();
				if (confirm('You are changing the Country location. Please select OK to retain the current start, stop date and weekly hours. Click Cancel to reset and load the values for the new country.')) {
					if (resourceTypeDetails.IsGeneric) {
						$.GenericFTECalculator.disconnectAll();
						setTimeout($.GenericFTECalculator.RecalculateFTEValues, 10);

						//Reload milestones for new country
						$.GenericFTECalculator.RepopulateMilestoneDataForCountry(editRequest.getProjectId(), 0, editRequest.getCountryIdFromDropdown(), editRequest.getOrganizationId(), editRequest.getResourceTypeId());
						$.GenericFTECalculator.disconnectDatesOnCountryChangeAndRepopulateMilestoneDropdownLists();
					}
					else if (resourceTypeDetails.IsOthers || resourceTypeDetails.IsGlobal || resourceTypeDetails.IsRegionBased) {
						$.Calculator.disconnectAll();
						$.Calculator.UpdatedConnedtedValues(editRequest.getRequestId(), editRequest.getProjectId(), editRequest.getResourceTypeId(), editRequest.getCountryIdFromDropdown());
						setTimeout($.Calculator.RecalculateFTEValues, 10);
						var connectedValues = pageManager.GetConnectedStartStopDateValues();
						editRequest.setConnectedStartStopDateAttributes(connectedValues.startDate, connectedValues.stopDate, "", "");
						if (!editRequest.isProposalRequest()) {
							if (resourceTypeDetails.RequestStartDateConnectedMilestoneType != RequestMilestoneType_E.Project) {
								requestHelper.appendDisconnectedImagePpm($(editRequest.startDateSelector));
							}
							if (resourceTypeDetails.RequestStopDateConnectedMilestoneType != RequestMilestoneType_E.Project) {
								requestHelper.appendDisconnectedImagePpm($(editRequest.stopDateSelector));
							}
						}
					}
					else if (objPageManager.Id == PageManagerType_E.MonitoringCountrySpecificPageManager_Type1) {
						var connectedValues = pageManager.GetConnectedStartStopDateValues();
						editRequest.setConnectedStartStopDateAttributes(connectedValues.startDate, connectedValues.stopDate, "", "");
						if (!editRequest.isProposalRequest()) {
							editRequest.appendDisconnectedImge($(editRequest.startDateSelector), editRequest.isStartDateDerivedFromCountry());
							editRequest.appendDisconnectedImge($(editRequest.stopDateSelector), editRequest.isStopDateDerivedFromCountry());
						}
					}
					else if (objPageManager.Id != PageManagerType_E.FlatFteCalculatorPageManager_Type2) {
						$.SmallFTECalculator.countrySelector = editRequest.countryDropdownSelector;
						$.SmallFTECalculator.CalculateTotalHours();
					}
				}
				else {
					if (resourceTypeDetails.IsGeneric) { $.GenericFTECalculator.DeleteAllAdHocRow(); }
					else if (resourceTypeDetails.IsOthers || resourceTypeDetails.IsGlobal || resourceTypeDetails.IsRegionBased) { $.Calculator.DeleteAllAdHocRow(); }

					if (objPageManager.Id != PageManagerType_E.FlatFteCalculatorPageManager_Type2) {
						editRequest.drawCalculator(editRequest.getResourceTypeName() + "Calculator");
					}
					pageManager.ShowDatesOnCountryOrPreferredCountryChange();
				}

				if (resourceTypeDetails.ShowSiteCountBySiteStatus) {
					editRequest.renderSiteCountBySiteIdControl(true);
				}
			}
		});
	},
	phaseCalculatorRenderCompleteHandlerForProposal: function (regionId, countryId, qipData) {
		if (editRequest.isProposalRequest()) {
			if (qipData) {
				if (qipData.hasQipData) {
					$('#txtStartDate').val(qipData.startDate);
					$('#txtStopDate').val(qipData.stopDate);
				}
				else {
					var resourceTypeDetails = editRequest.getResourceTypeDetails();

					$('#txtStartDate,#txtStopDate').val("");
					$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();
					$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();

					$.each($.Calculator._staticValues, function (index, phase) {
						$("#txtWeeklyHours_" + phase.FTETypeFTEMilestoneTypeId).val(phase.WeeklyHours);
						$("#txtFTE_" + phase.FTETypeFTEMilestoneTypeId).val(phase.FTE);
						$("#hdnFTETypeId_" + phase.FTETypeFTEMilestoneTypeId).val($.Calculator._staticTimestampValues[index].FteTypeId);
					});
				}
			}
		}
		else {
			$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();
			$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();
		}
	},

	drawSmallFteCalculator: function (calculatorHeading) {
		$.SmallFTECalculator.renderCalculator(null, editRequest.getProjectId(), editRequest.getResourceTypeId(), editRequest.getCountryIdFromDropdown(), calculatorHeading);
	},
	drawGenericCalculator: function (calculatorHeading) {
		$.GenericFTECalculator._fireChangeEvent = true;
		$.GenericFTECalculator.renderCalculator(null, editRequest.getProjectId(), editRequest.getResourceTypeId(), editRequest.getCountryIdFromDropdown(), calculatorHeading, true, editRequest.getOrganizationId());
		rm.ui.ribbon.refresh();
	},
	drawPhaseCalculator: function (calculatorHeading) {
		$.Calculator._fireChangeEvent = true;

		$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) {
			editRequest.phaseCalculatorRenderCompleteHandlerForProposal(regionId, countryId, qipData);
			$.Calculator.OnCalculatorRenderComplete = function () { };
		};
		$.Calculator.renderCalculator(null, editRequest.getProjectId(), editRequest.getResourceTypeId(), editRequest.getCountryIdFromDropdown(), calculatorHeading, true, null, editRequest.getRequestId());

		rm.ui.ribbon.refresh();
	},
	drawCalculator: function (calculatorHeading) {
		if (objPageManager.Name != "" && objPageManager.Id != PageManagerType_E.MonitoringCountrySpecificPageManager_Type1) {
			if (objPageManager.Name == "Co_monitoring_PageManager" || objPageManager.Name == "FlatFteCalculatorPageManager_Type1") {
				smallCalculator.getCountryIdForFteCalculation = editRequest.getCountryIdForFteCalculation;
				smallCalculator.getJobRoleIdForFteCalculation = editRequest.getJobRoleIdForFteCalculation;

				$(editRequest.startDateSelector).val("");
				$(editRequest.stopDateSelector).val("");
				$(editRequest.needByDateSelector).val("");
				$.SmallFTECalculator.ClearCalculator();
				editRequest.drawSmallFteCalculator(calculatorHeading);
			}
			else if (objPageManager.Name == "Generic_PageManager") {
				editRequest.drawGenericCalculator(true, false, editRequest.countryDropdownSelector, calculatorHeading, pageManager);
			}
			else {
				$.Calculator._countryId = editRequest.getCountryIdFromDropdown();
				editRequest.drawPhaseCalculator(calculatorHeading);
			}
		}
	},
	drawRegionBasedCalculator: function (calculatorHeading) {
		$.Calculator._interimFrequencyEnabled = true;
		$.Calculator._fireChangeEvent = true;

		$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) {
			editRequest.phaseCalculatorRenderCompleteHandlerForProposal(regionId, countryId, qipData);
			$.Calculator.OnCalculatorRenderComplete = function () { };
		};
		$.Calculator.renderCalculator(null, editRequest.getProjectId(), editRequest.getResourceTypeId(), null, calculatorHeading, true, editRequest.getRegionIdFromDropdown(), editRequest.getRequestId());
		rm.ui.ribbon.refresh();
	},
	setConnectedStartStopDateAttributes: function (startDate, stopDate, imDate, craTrainingDate) {
		$(editRequest.startDateSelector).attr("connectedDateValue", startDate);
		$(editRequest.stopDateSelector).attr("connectedDateValue", stopDate);
		$(editRequest.imDateSelector).attr("connectedDateValue", imDate);
		$(editRequest.craTrainingDateSelector).attr("connectedDateValue", craTrainingDate);
	},
	showDatesOnCountryOrPreferredCountryChange: function () {
		var startDateControl = $(editRequest.startDateSelector);
		var stopDateControl = $(editRequest.stopDateSelector);

		if (!editRequest.isProposalRequest()) {
			var connectedValues = pageManager.GetConnectedStartStopDateValues();
			var startDateValue = connectedValues.startDate;

			editRequest.setConnectedStartStopDateAttributes(connectedValues.startDate, connectedValues.stopDate, "", "");

			if (connectedValues.startDate != "") {
				if (rm.date.isQDateDateInPast(connectedValues.startDate)) {
					startDateValue = rm.date.getQDateStringFromDate(new Date());
					editRequest.appendDisconnectedImge(startDateControl, editRequest.isStartDateDerivedFromCountry());
				}
				else {
					editRequest.appendConnectedImge(startDateControl, editRequest.isStartDateDerivedFromCountry());
				}
			}
			else {
				editRequest.appendConnectedImge(startDateControl, editRequest.isStartDateDerivedFromCountry());
			}

			if (connectedValues.stopDate != "") {
				editRequest.appendConnectedImge(stopDateControl, editRequest.isStopDateDerivedFromCountry());
			}
			else {
				editRequest.appendDisconnectedImge(stopDateControl, editRequest.isStopDateDerivedFromCountry());
			}

			startDateControl.val(startDateValue);
			stopDateControl.val(connectedValues.stopDate);
			editRequest.setNeedByDate(startDateValue, editRequest.getResourceTransitionTimeinDays());

			rm.validation.clearError($(editRequest.startDateSelector));
			rm.validation.clearError($(editRequest.stopDateSelector));
		}
	},
	getConnectedMilestoneDetailsFromDb: function (resourceTypeId, projectId, countryId) {
		var connectedMilestoneDetails;
		$.rm.Ajax_RequestSynchronous("GetConnectedMilestoneDetailsFromDb", { resourceTypeId: resourceTypeId, projectId: projectId, countryId: countryId }, function (data) {
			connectedMilestoneDetails = data;
		}, false);

		return connectedMilestoneDetails;
	},
	getRegionConnectedMilestoneDetailsFromDb: function (resourceTypeId, projectId, regionId) {
		var connectedMilestoneDetails;
		$.rm.Ajax_RequestSynchronous("GetRegionConnectedMilestoneDetailsFromDb", { resourceTypeId: resourceTypeId, projectId: projectId, regionId: regionId }, function (data) {
			connectedMilestoneDetails = data;
		}, false);

		return connectedMilestoneDetails;
	},
	getConnectedDates: function (resourceTypeId, projectId, countryId) {
		//Set country Id to -1 so that the it can be looked up later from json cache
		if (countryId == null) { countryId = -1; }
		var resourceTypeDetails = editRequest.getResourceTypeDetails();
		//Do not make ajax call if resource type has no connected dates
		if (resourceTypeDetails &&
			resourceTypeDetails.CraTrainingDateConnectedMilestoneType == null &&
			resourceTypeDetails.ImDateConnectedMilestoneType == null &&
			resourceTypeDetails.RequestStartDateConnectedMilestoneType == null &&
			resourceTypeDetails.RequestStopDateConnectedMilestoneType == null) {
			return { startDate: "", stopDate: "", imDate: "", craTrainingDate: "" };
		}
		else {
			var connectedMilestoneDetails;
			if (editRequest.connectedMilestoneDetails[resourceTypeId] &&
				editRequest.connectedMilestoneDetails[resourceTypeId][projectId] &&
				editRequest.connectedMilestoneDetails[resourceTypeId][projectId][countryId]) {
				connectedMilestoneDetails = editRequest.connectedMilestoneDetails[resourceTypeId][projectId][countryId];
			}
			else {
				connectedMilestoneDetails = editRequest.getConnectedMilestoneDetailsFromDb(resourceTypeId, projectId, countryId);
				if (!editRequest.connectedMilestoneDetails[resourceTypeId]) { editRequest.connectedMilestoneDetails[resourceTypeId] = {}; }
				if (!editRequest.connectedMilestoneDetails[resourceTypeId][projectId]) { editRequest.connectedMilestoneDetails[resourceTypeId][projectId] = {}; }
				editRequest.connectedMilestoneDetails[resourceTypeId][projectId][countryId] = connectedMilestoneDetails;
			}
			return connectedMilestoneDetails;
		}
	},
	getRegionalConnectedDates: function (resourceTypeId, projectId, regionId) {
		//Do not make ajax call if resource type has no connected dates
		var regionConnectedMilestoneDetails;
		if (editRequest.regionConnectedMilestoneDetails[resourceTypeId] &&
			editRequest.regionConnectedMilestoneDetails[resourceTypeId][projectId] &&
			editRequest.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId]) {
			regionConnectedMilestoneDetails = editRequest.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId];
		}
		else {
			regionConnectedMilestoneDetails = editRequest.getRegionConnectedMilestoneDetailsFromDb(resourceTypeId, projectId, regionId);
			if (!editRequest.regionConnectedMilestoneDetails[resourceTypeId]) { editRequest.regionConnectedMilestoneDetails[resourceTypeId] = {}; }
			if (!editRequest.regionConnectedMilestoneDetails[resourceTypeId][projectId]) { editRequest.regionConnectedMilestoneDetails[resourceTypeId][projectId] = {}; }
			editRequest.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId] = regionConnectedMilestoneDetails;
		}
		return regionConnectedMilestoneDetails;
	},
	getGlobalConnectedDates: function (resourceTypeId, projectId) {
		return editRequest.getConnectedDates(resourceTypeId, projectId, -1);
	},

	handleRequestBudgetedChange: function (fromDocumentReady) {
		if (!fromDocumentReady) { editRequest.setPageIsDirty(); }
		rm.validation.clearError($(editRequest.radioRequestBudgetedSpanNoSelector));
		rm.validation.clearError($(editRequest.radioRequestBudgetedSpanYesSelector));
		if ($(editRequest.radioRequestBudgetedNoSelector).is(":checked")) {
			$(editRequest.reasonContainerSelector).removeClass(editRequest.hideClass).show();
		}
		else {
			$(editRequest.reasonContainerSelector).hide();
			$(editRequest.txtReasonSelector).val("");
			rm.validation.clearError($(editRequest.txtReasonSelector));
			setTimeout(function () { $.q.textCounter($(editRequest.txtReasonSelector).get(0), $(editRequest.txtReasonSelector).attr("maxLength"), editRequest.lblRemainingLengthSelector); }, 5);
		}
		rm.ui.ribbon.refresh();
	},

	handleRequestBlindedChange: function (fromDocumentReady) {
		if (!fromDocumentReady) { editRequest.setPageIsDirty(); }
		rm.ui.ribbon.refresh();
	},

	bindMaxLengthOnReason: function () {
		var reason = $(editRequest.txtReasonSelector);
		var maxLength = reason.attr("maxLength");

		$.q.textCounter(reason.get(0), maxLength, editRequest.lblRemainingLengthSelector);
		$(editRequest.txtReasonSelector).keyup(function () {
			editRequest.setPageIsDirty();
			reason = $(this);
			$.q.textCounter(this, maxLength, editRequest.lblRemainingLengthSelector);
			editRequest.isMaxLengthWithinRange(reason);
		});
	},

	isMaxLengthWithinRange: function (jqReason) {
		var isWithinRange = true;
		var maxLength = jqReason.attr("maxLength");
		if (maxLength < jqReason.val().length) {
			rm.validation.addError(editRequest.txtReasonSelector, "Maximum character limit:" + maxLength);
			isWithinRange = false;
		}
		else {
			rm.validation.clearError(jqReason);
		}

		return isWithinRange;
	},

	calculateNeedByDate: function () {
		if ($(editRequest.needByDateContainerSelector).is(":visible") && rm.date.isQDateDateInPast($(editRequest.startDateSelector).val()) == false) {
			if (rm.date.isValidDate($(editRequest.startDateSelector).val(), false)) {
				var resourceTransitionTimeInDays = 0;
				if (editRequest.isGenericResourceType()) {
					resourceTransitionTimeInDays = editRequest.getGenericResourceTransitionTimeinDays();
				}
				if (resourceTransitionTimeInDays == 0) {
					resourceTransitionTimeInDays = editRequest.getResourceTransitionTimeinDays();
				}
				editRequest.setNeedByDate($(editRequest.startDateSelector).val(), resourceTransitionTimeInDays);
				if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
					$.GenericFTECalculator.SetStartAndEndMilestonesBasedOnDates(true);
					$.GenericFTECalculator.SetStartAndEndMilestonesBasedOnDates(false);
				}
			}
			else {
				$(editRequest.needByDateSelector).val("Not Available");
			}
		}
	},

	isDateValid: function (jqObject) {
		var isValid = true;

		if (!rm.date.isValidDate(jqObject.val(), false)) {
			jqObject.addClass("q_validation_error");
			isValid = false;
		}
		else {
			rm.validation.clearError(jqObject);
		}

		return isValid;
	},

	handleNeedByDateVisibility: function () {
		if (ResourceTypeDetails[editRequest.getResourceTypeId()].ShowNeedByDate) { $(editRequest.needByDateContainerSelector).removeClass(editRequest.hideClass); }
		else { $(editRequest.needByDateContainerSelector).addClass(editRequest.hideClass); }
	},

	getPageManagerDetails: function (resourceTypeId, isProposalRequest) {
		$.rm.Ajax_RequestSynchronous("GetPageManagerTypeName", { resourceTypeId: resourceTypeId, isProposalRequest: isProposalRequest }, function (data) {
			objPageManager = data;
		}, false);
	},

	getPageManager: function (requestTypeId, resourceTypeId) {
		editRequest.getPageManagerDetails(resourceTypeId, (requestTypeId == RequestType_E.Proposal));
		$.rm.SetRequestBlindedFieldVisibility(objPageManager.DisplaysBlindedField);

		if (jQuery.isFunction(eval(objPageManager.Name))) {
			if (editRequest.isGenericResourceType()) {
				$('#regionIDName').text("Preferred Region: ");
				$('#countryIDName').text("Preferred Country: ")
				$("#editableRegionLabel").text("Preferred Region: ");
				$("#editableCountryLabel").text("Preferred Country: ")
			}
			else {
				$('#regionIDName').text("Region: ");
				$('#countryIDName').text("Country: ");
				$("#editableRegionLabel").text("Region: ");
				$("#editableCountryLabel").text("Country: ")
			}

			return eval("new " + objPageManager.Name + "()");
		}
		else {
			alert("Invalid resource type " + resourceTypeId);
			return null;
		}
	},
	ShowConnectDisconnectPPMIcon: function () {
		if (!ResourceTypeDetails[editRequest.getResourceTypeId()].ShowStartDateConnectDisconnectIcon)
			$(editRequest.startDateSelector).parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
		if (!ResourceTypeDetails[editRequest.getResourceTypeId()].ShowStopDateConnectDisconnectIcon)
			$(editRequest.stopDateSelector).parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
	},
	ShowMilestones: function () {
		milestoneNs.showControl(milestoneNs.gridSelector, editRequest.getProjectId());
	},
	handleSiteCountBySiteIdVisibility: function () {
		if (ResourceTypeDetails[editRequest.getResourceTypeId()].ShowSiteCountBySiteStatus) {
			$(editRequest.divSiteCountByStatusSelector).show();
			editRequest.renderSiteCountBySiteIdControl(false);
		}
	},
	renderSiteCountBySiteIdControl: function (isCountryChanging) { ucscbsNs.render(editRequest.getProjectId(), (isCountryChanging ? editRequest.getCountryIdFromDropdown() : editRequest.getCoutryId()), true); }
};

// for Standard_Monitoring start
Standard_Monitoring_PageManager = function () {
	this.draw = function () //Standard_Monitoring
	{
		calculatorHelper.handleSiteChange(editRequest.getSiteId(), editRequest.getProjectId(), editRequest.getCoutryId(), editRequest.getRequestId(), ResourceTypeName.Standard_Monitoring, pageManager, false, function () { calculatorHelper.siteChanged = false; });

		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		requestHelper.showConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.imDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.craTrainingDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () //Standard_Monitoring
	{
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipClinicalCalculatorValid() && isValid;
		return (isValid);
	};

	this.updateRequest = function () //Standard_Monitoring
	{
		editRequest.saveQipClinicalReqeust();
	};

	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	}; //Standard_Monitoring 

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
};
// for Standard_Monitoring end

// for Co_monitoring start
Co_monitoring_PageManager = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		v
		//$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.coMonFteCalcContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		$.SmallFTECalculator.resourceTypeSelector = editRequest.resourceTypeSelector;
		if ($("[id$=HdnSiteId]").val() != "0") {
			$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		}
		$.SmallFTECalculator.countrySelector = editRequest.countryIdForFteCalculationSelector;
		$.SmallFTECalculator.startDateSelector = editRequest.startDateSelector;
		$.SmallFTECalculator.stopDateSelector = editRequest.stopDateSelector;

		$.SmallFTECalculator.SetCalculatorValues($(editRequest.fteSelector).val(), editRequest.getTotalHours());
		$.SmallFTECalculator.renderCalculator(editRequest.getRequestId(), null, editRequest.getResourceTypeId(), null, "Co-monitoring FTE Calculator");

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDate);
		$(editRequest.startDateSelector).bind('change', $.SmallFTECalculator.CalculateTotalHours);
		$(editRequest.stopDateSelector).bind('change', $.SmallFTECalculator.CalculateTotalHours);

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = $.SmallFTECalculator.IsValid() && isValid;
		return (isValid);
	};

	this.updateRequest = function () { editRequest.saveCoMonitoringReqeust(); };

	this.onSaveSuccess = function (data) {
		editRequest.clearDirtyCoMonitoirngCalculator();
		if (editRequest.previousValuesShown()) {
			$.SmallFTECalculator.ShowPreviousPhaseValues();
		}
	};
};
// for Co_monitoring end

// for Generic start
Generic_PageManager = function () {
	$.GenericFTECalculator.requestInDraftMode = false;
	this.draw = function () //Generic Resource
	{
		$.GenericFTECalculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.genericFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		$.GenericFTECalculator.resourceTypeSelector = editRequest.resourceTypeSelector;
		$.GenericFTECalculator.countrySelector = editRequest.countryIdForFteCalculationSelector;
		$.GenericFTECalculator.startDateSelector = editRequest.startDateSelector;
		$.GenericFTECalculator.stopDateSelector = editRequest.stopDateSelector;

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDate);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDate);
		$(editRequest.startDateSelector).bind('change', $.GenericFTECalculator.CalculateTotalHours);
		$(editRequest.stopDateSelector).bind('change', $.GenericFTECalculator.CalculateTotalHours);

		$.GenericFTECalculator.SetCalculatorValues($(editRequest.fteSelector).val(), editRequest.getTotalHours());
		editRequest.initializeGenericCalculator(editRequest.getCalculatorHeader());
		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		//update request start and stop dates based on the start and stop dates of first and last phase
		$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(true);
		$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(false);

		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;
		return isValid;
	};
	this.updateRequest = function () { editRequest.saveGenericReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessGenericCalculator(editRequest.getCalculatorHeader()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { };
};
// for Genric end

// for Pharmacy_Monitoring start
Pharmacy_Monitoring_PageManager = function () {
	this.draw = function () //Pharmacy_Monitoring
	{
		calculatorHelper.handleSiteChange(editRequest.getSiteId(), editRequest.getProjectId(), editRequest.getCoutryId(), editRequest.getRequestId(), ResourceTypeName.Pharmacy_Monitoring, pageManager, false);

		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		requestHelper.showConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.imDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.craTrainingDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
};
// for Pharmacy_Monitoring end

// for CRS start
CRS_PageManager = function () {
	this.draw = function () //CRS
	{
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.preferredLocationContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.regionContainerSelector).removeClass(editRequest.hideClass);
		if (!editRequest.isProposalRequest()) {
			$(editRequest.assignedLocationContainerSelector).removeClass(editRequest.hideClass);
			$(editRequest.assignedRegionContainerSelector).removeClass(editRequest.hideClass);
			$(editRequest.assignedCountryContainerSelector).removeClass(editRequest.hideClass);
		}
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		if (!editRequest.isProposalRequest()) {
			requestHelper.showConnectDisconnectIconPpm($(editRequest.startDateSelector));
			requestHelper.showConnectDisconnectIconPpm($(editRequest.stopDateSelector));
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
			$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);
		}
		else {
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDateHandler);
		}

		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeader());

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessQipOtherCalculator(editRequest.getCalculatorHeader()); };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getRegionIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};
// for CRS end

// for iCRA_Monitoring start
iCRA_Monitoring_PageManager = function () {
	this.draw = function () //iCRA_Monitoring
	{
		calculatorHelper.handleSiteChange(editRequest.getSiteId(), editRequest.getProjectId(), editRequest.getCoutryId(), editRequest.getRequestId(), ResourceTypeName.iCRA_Monitoring, pageManager, false);

		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		requestHelper.showConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.imDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.craTrainingDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
};
// for iCRA_Monitoring end

// for Co-Monitoring Site Specific start
Co_monitoring_SiteSpecific_PageManager = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChange);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
	this.GetConnectedStartStopDateValues = function () { };
};
// for Co-Monitoring Site Specific end

// for Non Standard-Monitoring Site Specific start
Non_Standard_Monitoring_SiteSpecific_PageManager = function () {
	this.draw = function () //
	{
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChange);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Non Standard-Monitoring Site Specific end

// for Short_term_SWAT_Monitoring_OnSite_Visit start
Short_term_SWAT_Monitoring_OnSite_Visit_PageManager = function () {
	this.draw = function () //Short_term_SWAT_Monitoring_OnSite_Visit
	{
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.visitTypeContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChange);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Short_term_SWAT_Monitoring_OnSite_Visit end

// for Short_term_SWAT_Monitoring_Phone_Visit start
Short_term_SWAT_Monitoring_Phone_Visit_PageManager = function () {
	this.draw = function () //Short_term_SWAT_Monitoring_Phone_Visit
	{
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.visitTypeContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChange);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Short_term_SWAT_Monitoring_Phone_Visit end

// for Regional_CPM start
Regional_CPM_PageManager = function () {
	this.draw = function () //Regional_CPM
	{
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.preferredLocationContainerSelector).removeClass(editRequest.hideClass);
		if (!editRequest.isProposalRequest()) {
			$(editRequest.assignedLocationContainerSelector).removeClass(editRequest.hideClass);
			$(editRequest.assignedRegionContainerSelector).removeClass(editRequest.hideClass);
			$(editRequest.assignedCountryContainerSelector).removeClass(editRequest.hideClass);
		}
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		if (!editRequest.isProposalRequest()) {
			requestHelper.showConnectDisconnectIconPpm($(editRequest.startDateSelector));
			requestHelper.showConnectDisconnectIconPpm($(editRequest.stopDateSelector));
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
			$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);
		}
		else {
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDateHandler);
		}

		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeader());

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessQipOtherCalculator(editRequest.getCalculatorHeader()); };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getRegionIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};
// for Regional_CPM end

// for SSV_Monitoring start
SSV_Monitoring_PageManager = function () {
	this.draw = function () //SSV_Monitoring
	{
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		//$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.SsvTypeContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		requestHelper.showConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.craTrainingDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, function () { requestHelper.handleStartStopDateChangeCountry($(this), true); editRequest.onAfterConnectIconClick(); });
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipClinicalCalculatorValid() && isValid;
		isValid = rmCommon.ValidateSSVPerSite(editRequest.ssvTypeId, "[id$=__ssvPerSite]", "[id$=__phoneSsvPerSite]") && isValid;
		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for SSV_Monitoring end

// for Proposal_Base_PageManager start
Proposal_Base_PageManager = function () {
	this.draw = function () {
		var selectedResourceTypeId = editRequest.getResourceTypeId();
		if (selectedResourceTypeId == ResourceTypeName_E.DTE_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.DTE_Pharmacy_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.Non_DTE_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.Non_DTE_Pharmacy_CRA_Project_Country) {
			$(editRequest.fteSelector).attr("formating", "2,2").attr("from", 0.01).attr("to", 20).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 20.0.");
		}

		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();

		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.fteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleProposalStartDateChangeCountry);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		editRequest.onDrawComplete();
	};
	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isProposalRequestValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;
		return isValid;
	};
	this.updateRequest = function () { editRequest.saveReqeustWithNoCalculator(); };
	this.onSaveSuccess = function (data) { };
	this.GetConnectedStartStopDateValues = function () { };
};
// for Proposal_Base_PageManager end

// for DTESite_Monitoring_PageManager start
DTESite_Monitoring_PageManager = function () {
	this.draw = function () //DTESite Monitoring
	{
		calculatorHelper.handleSiteChange(editRequest.getSiteId(), editRequest.getProjectId(), editRequest.getCoutryId(), editRequest.getRequestId(), ResourceTypeName.DTESite_Monitoring, pageManager, false, function () { calculatorHelper.siteChanged = false; });

		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		requestHelper.showConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.imDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.craTrainingDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
};
// for Standard_Monitoring end

// for DTEPharmacy_Monitoring start
DTEPharmacy_Monitoring_PageManager = function () {
	//calculatorHelper.isProjectDTE = true;
	this.draw = function () //DTEPharmacy_Monitoring
	{
		calculatorHelper.handleSiteChange(editRequest.getSiteId(), editRequest.getProjectId(), editRequest.getCoutryId(), editRequest.getRequestId(), ResourceTypeName.DTEPharmacy_Monitoring, pageManager, false);

		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		requestHelper.showConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.imDateSelector), false);
		requestHelper.handleStartStopDateChangeCountry($(editRequest.craTrainingDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
};
// for DTEPharmacy_Monitoring end

//PhaseCalculatorPageManager_Type1
PhaseCalculatorPageManager_Type1 = function () {
	this.draw = function () //PhaseCalculatorPageManager_Type1
	{
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		//$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		if (!editRequest.isProposalRequest()) {
			requestHelper.showConnectDisconnectIconPpm($(editRequest.startDateSelector));
			requestHelper.showConnectDisconnectIconPpm($(editRequest.stopDateSelector));
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
			$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);
		}
		else {
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDateHandler);
		}

		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeader());

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;

		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessQipOtherCalculator(editRequest.getCalculatorHeader()); };

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getCountryIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};
//PhaseCalculatorPageManager_Type1

//PhaseCalculatorPageManager_Type2
PhaseCalculatorPageManager_Type2 = function () {
	this.draw = function () //PhaseCalculatorPageManager_Type1
	{
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.editableRegionContainerSelector).hide();
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		if (!editRequest.isProposalRequest()) {
			requestHelper.showConnectDisconnectIconPpm($(editRequest.startDateSelector));
			requestHelper.showConnectDisconnectIconPpm($(editRequest.stopDateSelector));
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
			$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);
		}
		else {
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDateHandler);
		}

		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeader());

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;

		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessQipOtherCalculator(editRequest.getCalculatorHeader()); };

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getCountryIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};
//PhaseCalculatorPageManager_Type2

//PhaseCalculatorPageManager_Type3: on edit page type1 and type2 are exactly the same
PhaseCalculatorPageManager_Type3 = function () {
	this.draw = function () //PhaseCalculatorPageManager_Type1
	{
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.editableRegionContainerSelector).hide();
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		if (!editRequest.isProposalRequest()) {
			requestHelper.showConnectDisconnectIconPpm($(editRequest.startDateSelector));
			requestHelper.showConnectDisconnectIconPpm($(editRequest.stopDateSelector));
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
			$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);
		}
		else {
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDateHandler);
		}

		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeader());

		editRequest.onDrawComplete();
	};


	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;

		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessQipOtherCalculator(editRequest.getCalculatorHeader()); };

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getCountryIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
}; //PhaseCalculatorPageManager_Type3

//PhaseCalculatorPageManager_Type4
PhaseCalculatorPageManager_Type4 = function () {
	this.draw = function () //PhaseCalculatorPageManager_Type4
	{
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		//$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.totalSitesContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		if (!editRequest.isProposalRequest()) {
			requestHelper.showConnectDisconnectIconPpm($(editRequest.startDateSelector));
			requestHelper.showConnectDisconnectIconPpm($(editRequest.stopDateSelector));
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
			$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);
		}
		else {
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDateHandler);
		}

		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeader());

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;

		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessQipOtherCalculator(editRequest.getCalculatorHeader()); };

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getCountryIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};
//PhaseCalculatorPageManager_Type4

//FlatFteCalculatorPageManager_Type1
FlatFteCalculatorPageManager_Type1 = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.editableRegionContainerSelector).hide();

		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.coMonFteCalcContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		$.SmallFTECalculator.resourceTypeSelector = editRequest.resourceTypeSelector;
		$.SmallFTECalculator.countrySelector = editRequest.countryIdForFteCalculationSelector;
		$.SmallFTECalculator.startDateSelector = editRequest.startDateSelector;
		$.SmallFTECalculator.stopDateSelector = editRequest.stopDateSelector;

		smallCalculator.getCountryIdForFteCalculation = editRequest.getCountryIdForFteCalculation;
		smallCalculator.getJobRoleIdForFteCalculation = editRequest.getJobRoleIdForFteCalculation;

		$.SmallFTECalculator.SetCalculatorValues($(editRequest.fteSelector).val(), editRequest.getTotalHours());
		$.SmallFTECalculator.renderCalculator(editRequest.getRequestId(), null, editRequest.getResourceTypeId(), null, editRequest.getCalculatorHeader());

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDate);
		$(editRequest.startDateSelector).bind('change', $.SmallFTECalculator.CalculateTotalHours);
		$(editRequest.stopDateSelector).bind('change', $.SmallFTECalculator.CalculateTotalHours);

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = $.SmallFTECalculator.IsValid() && isValid;
		return isValid;
	};
	this.updateRequest = function () { editRequest.saveCoMonitoringReqeust(); };
	this.onSaveSuccess = function (data) {
		editRequest.clearDirtyCoMonitoirngCalculator();
		if (editRequest.previousValuesShown()) {
			$.SmallFTECalculator.ShowPreviousPhaseValues();
		}
	};
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getRegionIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};
//FlatFteCalculatorPageManager_Type1 End

//FlatFteCalculatorPageManager_Type2
FlatFteCalculatorPageManager_Type2 = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.fteSelector).attr("from", 0.01).attr("to", 1.5).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 1.5.");
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.fteContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }
		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDate);

		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isFlatFteValueValid() && isValid;
		return isValid;
	};
	this.updateRequest = function () { editRequest.saveReqeustWithNoCalculator(); };
	this.onSaveSuccess = function (data) { };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getRegionIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};
//FlatFteCalculatorPageManager_Type1 End

RegionCalculatorPageManager_Type1 = function () {
	this.draw = function () {
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$.Calculator.StopDateSelector = editRequest.stopDateSelector;
		$.Calculator.StartDateSelector = editRequest.startDateSelector;
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind,
			function () {
				editRequest.calculateNeedByDateHandler();
				editRequest.updateRequestStopDateFromComputedRequestMilestone(editRequest.getResourceTypeId(), editRequest.getRegionId());
			});

		editRequest.initializeQipRegionalCalculator(editRequest.getCalculatorHeader());
		editRequest.onDrawComplete();
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;

		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipRegionalReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessQipRegionalCalculator(editRequest.getCalculatorHeader()); };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getRegionalConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getRegionIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};

GlobalCalculatorPageManager_Type1 = function () {
	this.draw = function () {
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleRegionCountryVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();

		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		if (!editRequest.isProposalRequest()) {
			requestHelper.showConnectDisconnectIconPpm($(editRequest.startDateSelector));
			requestHelper.showConnectDisconnectIconPpm($(editRequest.stopDateSelector));
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
			$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);
		}
		else {
			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.calculateNeedByDateHandler);
		}

		editRequest.initializeQipGlobalCalculator(editRequest.getCalculatorHeader());
		editRequest.onDrawComplete();

		//editRequest.updateRequestStopDateFromComputedRequestMilestone(editRequest.getResourceTypeId());
		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind,
			function () {
				editRequest.updateRequestStopDateFromComputedRequestMilestone(editRequest.getResourceTypeId(), 0);
			});
	};

	this.isValid = function () {
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isQipOtherCalculatorValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;

		return isValid;
	};
	this.updateRequest = function () { editRequest.saveQipRegionalReqeust(); };
	this.onSaveSuccess = function (data) { editRequest.onSaveSuccessQipGlobalalculator(editRequest.getCalculatorHeader()); };

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) { SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate); };
	this.GetConnectedStartStopDateValues = function () { return editRequest.getGlobalConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};

//MonitoringCountrySpecificPageManager_Type1
MonitoringCountrySpecificPageManager_Type1 = function () {
	this.draw = function () //Standard_Monitoring
	{
		$(editRequest.fteSelector).attr("formating", "2,2").attr("from", 0.01).attr("to", 20).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 20.0.");
		editRequest.handleOriginalResourceStopDateVisibility();
		editRequest.handleSiteCountBySiteIdVisibility();
		$(editRequest.editableCountryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.fteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleProposalStartDateChangeCountry);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		editRequest.onDrawComplete();


		requestHelper.showConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
	};

	this.isValid = function () //MonitoringCountrySpecificPageManager_Type1
	{
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isProposalRequestValid() && isValid;
		isValid = editRequest.ValidateDynamicCustomFields() && isValid;
		return isValid;
	};

	this.updateRequest = function () { editRequest.saveReqeustWithNoCalculator(); }; //MonitoringCountrySpecificPageManager_Type1
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	}; //MonitoringCountrySpecificPageManager_Type1 
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getCountryIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
};
// MonitoringCountrySpecificPageManager_Type1 end

SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate) {
	$(editRequest.startDateSelector).attr("connectedDateValue", startDate);
	requestHelper.showConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
};
