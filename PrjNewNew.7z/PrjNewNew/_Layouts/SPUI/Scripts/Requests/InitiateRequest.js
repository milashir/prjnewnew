﻿///<reference path="../Requests/InitiateRequestHelper.js"/>
$(document).ajaxStop(function () { rm.ui.unblock(); });
$(document).ajaxStart(function () { rm.ui.block(); });

var initReqPgNs = {
	selectedRequestDetails: null,
	frozenColumnAlreadyBound: false,
	txtProjectNameSelector: "#txtProjectName",
	gridSelector: "#listRequest",
	pastRequestsGridSelector: "#pastRequestsListGrid",
	ddlResourceTypeSelector: "#ddlResourceType",
	ddlCountrySelector: "#ddlCountry",
	ddlPreferredCountrySelector: "#ddlPreferredCountry",
	ddlPreferredRegionSelector: "#ddlPreferredRegion",
	ddlOrganizationSelector: "#ddlOrganization",
	ddlOrganizationalUnitSelector: "#ddlOrganizationalUnit",
	txtNeedByDateSelector: "#txtNeedByDate",
	txtTotalSitesSelector: "#txtTotalSites",
	txtStartDateSelector: "#txtStartDate",
	txtStopDateSelector: "#txtStopDate",
	txtCraTrainingDateSelector: "#txtCRATrainingDate",
	txtImDateSelector: "#txtIMDate",
	isDirtySelector: "[id$=IsDirty]",
	ddlTierSelector: "[id$='ddlTierLevel']",
	txtProposalFteSelector: "#txtProposalFte",
	lblProposalFteSelector: "#lblProposalFte",
	divCalculatorHolderSelector: "#divCalculatorHolder",
	divNotesSelector: "#divNotes",
	taNotesSelector: "#taNotes",
	divSiteCountByStatusSelector: "#divSiteCountByStatus",
	initiateFieldTotalSitesSelector: ".initiateFieldTotalSites",
	isCountryRegionOptional: false,
	organizationOrganizationalUnitRRTData: [],
	anyOrganizationalUnit: 0,
	_computedReqestMilestoneDaysToAdd: null,
	getSelectedResourceTypeDetails: function () { return ResourceTypeDetails[initReqPgNs.getResourceTypeId()]; },
	showHideSiteCountByStatus: function () {
		if (initReqPgNs.getResourceTypeId() > 0) {
			var selectedResourceType = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];
			if (selectedResourceType.ShowSiteCountBySiteStatus) {
				$(initReqPgNs.divSiteCountByStatusSelector).show();
				ucscbsNs.render(initReqPgNs.getProjectIdFromUi(), initReqPgNs.getCountryIdFromUi(), true);
			}
		}
	},
	showHidePastRequests: function () {
		if (initReqPgNs.getResourceTypeId() > 0) {
			var selectedResourceType = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];
			if (selectedResourceType.ShowPastRequestsGridInInitiateRequestPage && !initReqPgNs.isInEditMode()) {
				var organizationalUnitId = initReqPgNs.getOrganizationalUnitId();
				var regionId = initReqPgNs.getRegionIdFromUi();
				var countryId = initReqPgNs.getCountryIdFromUi();
				if ((selectedResourceType.IsGlobal && organizationalUnitId != null && organizationalUnitId != -1) ||
					(selectedResourceType.IsRegionBased && regionId != null && regionId != -1) ||
					(countryId != null && countryId != -1)) {
					initReqPgNs.populatePastRequestGrid();
				}
				else { initReqPgNs.hidePastRequestGrid(); }
			}
			else { initReqPgNs.hidePastRequestGrid(); }
		}
		else { initReqPgNs.hidePastRequestGrid(); }
	},
	getPostDataForPastRequests: function () {
		var selectedResourceType = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];
		return {
			ProjectId: initReqPgNs.getProjectId(),
			ResourceTypeId: selectedResourceType.Id,
			OrganizationalUnitId: initReqPgNs.getOrganizationalUnitId(),
			RegionId: selectedResourceType.IsRegionBased ? initReqPgNs.getRegionIdFromUi() : null,
			CountryId: (selectedResourceType.IsRegionBased || selectedResourceType.IsGlobal) ? null : initReqPgNs.getCountryIdFromUi()
		};
	},
	populatePastRequestGrid: function () {
		if ($(initReqPgNs.pastRequestsGridSelector)[0].grid) {
			$(initReqPgNs.pastRequestsGridSelector).jqGrid('setGridParam', { postData: initReqPgNs.getPostDataForPastRequests(), datatype: "json" }).trigger('reloadGrid');
		}
		else { initReqPgNs.buildPastRequestGrid(); }
	},
	hidePastRequestGrid: function () { $("#pastRequestsList").hide(); },
	getGridCaption: function () { return 'Requests Already Submitted for - ' + $(initReqPgNs.txtProjectNameSelector).val() + ' - ' + initReqPgNs.getResourceTypeName(); },

	buildPastRequestGrid: function () {
		var selectedResourceType = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];

		$(initReqPgNs.pastRequestsGridSelector).jqGrid({
			url: rm.ajax.requestSvcUrl + "GetPastRequestsByProjectIdResourceTypeId",
			datatype: 'json',
			mtype: 'POST',
			width: 740,
			height: 150,
			shrinkToFit: false,
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(true),
			postData: initReqPgNs.getPostDataForPastRequests(),
			jsonReader: rm.grid.getJqGridJsonReader(),
			caption: initReqPgNs.getGridCaption(),
			//Grid options
			loadonce: true,
			multiselect: false,
			rowList: [],
			pgbuttons: false,     // disable page control like next, back button
			pgtext: null,         // disable pager text like 'page 0 of 10'
			viewrecords: false,   // disable current view record text like 'view 1-10 of 100'
			pginput: false,
			rownumbers: false,
			pager: '#listPagerSubmitted',
			colModel: [
				{ name: 'RegionName', index: 'RegionName', label: 'Region', hidden: selectedResourceType.IsGlobal, width: 200, fixed: true },
				{ name: 'CountryName', index: 'CountryName', label: 'Country', hidden: selectedResourceType.IsRegionBased, width: 180, fixed: true },
				{ name: 'StartDate', index: 'StartDate', label: 'StartDate', width: 80, fixed: true },
				{ name: 'StopDate', index: 'StopDate', label: 'StopDate', width: 80, fixed: true },
				{ name: 'Fte', index: 'Fte', label: 'FTE', align: 'center', hidden: !selectedResourceType.UsesFixedSingleStageCalculator, width: 80, fixed: true },
				{ name: 'RequestId', index: 'RequestId', label: 'Request ID', align: 'center', width: 80, fixed: true }
			],
			serializeGridData: rm.grid.serializeGridData,
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			beforeRequest: function () {
				$(initReqPgNs.pastRequestsGridSelector).jqGrid('setCaption', initReqPgNs.getGridCaption());
				return true;
			},
			loadComplete: function (data) {
				var selectedResourceType = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];
				$(initReqPgNs.pastRequestsGridSelector).jqGrid(selectedResourceType.IsGlobal ? "hideCol" : "showCol", "RegionName");
				$(initReqPgNs.pastRequestsGridSelector).jqGrid((selectedResourceType.IsGlobal || selectedResourceType.IsRegionBased) ? "hideCol" : "showCol", "CountryName");
				$(initReqPgNs.pastRequestsGridSelector).jqGrid(selectedResourceType.UsesFixedSingleStageCalculator ? "showCol" : "hideCol", "Fte");

				if (data.RecordCount == 0) { initReqPgNs.hidePastRequestGrid(); }
				else {
					$("#pastRequestsList").removeClass("hideMe").show();
					$(initReqPgNs.pastRequestsGridSelector).closest("div.ui-jqgrid-view").children("div.ui-jqgrid-titlebar").attr('style', 'height: 25px !important');
					$(initReqPgNs.pastRequestsGridSelector).closest("div.ui-jqgrid-view").find(".HeaderButton").css('display', 'none');
					$(initReqPgNs.pastRequestsGridSelector).closest("div.ui-jqgrid-view").children("div.ui-jqgrid-titlebar").css("color", "red");
					$(initReqPgNs.pastRequestsGridSelector).closest("div.ui-jqgrid-view").find(".ui-jqgrid-sortable").css("color", "darkred");
				}
			}
		});
	},
	getComputedReqestMilestoneDaysToAdd: function () {
		if (initReqPgNs._computedReqestMilestoneDaysToAdd == null) {
			$.rm.Ajax_RequestSynchronous("GetAllComputedReqestMilestoneDaysToAdd", {}, function (data) {
				initReqPgNs._computedReqestMilestoneDaysToAdd = data;
			}, true);
		}

		return initReqPgNs._computedReqestMilestoneDaysToAdd;
	},
	resetSelectedRequestDetails: function () { initReqPgNs.selectedRequestDetails = null; },
	setSelectedRequestDetails: function (requestDetails) {
		initReqPgNs.selectedRequestDetails = {
			countryId: requestDetails.CountryId,
			countryRegionId: requestDetails.CountryRegionId,
			organizationId: requestDetails.OrganizationId,
			organizationalUnitId: (requestDetails.RequestOrganizationalUnitId == null) ? "0" : requestDetails.RequestOrganizationalUnitId,
			projectId: requestDetails.ProjectId,
			regionId: requestDetails.RegionId,
			countryRegionId: requestDetails.CountryRegionId,
			requestStatusId: requestDetails.RequestStatusId,
			requestTypeId: requestDetails.RequestTypeId,
			resourceTypeId: requestDetails.ResourceTypeId,
			requestId: requestDetails.id,
			totalSites: requestDetails.TotalSites
		};
	},
	resetPage: function (unhideOrgUnit) {
		$("#calculatorInstructions").text("").hide();
		initReqPgNs.hidePastRequestGrid();
		initReqPgNs.resetSelectedRequestDetails();

		$(initReqPgNs.divSiteCountByStatusSelector).hide();

		if (!unhideOrgUnit) {
			$("#ddlOrganization").val("-1");
			$("#ddlOrganizationalUnit").val("-1");
			$("#ddlOrganizationalUnit").hide();
			$("#lblOrgUnit").hide();
		}
		$.Dropdown.EmptyDropdown("#ddlResourceType");
		$("#ddlResourceType").val("-1");
		$(".initiateNewRequestFloat").removeClass("initiateNewRequestFloat").addClass("initiateNewRequestFloatEdit");
		$(".initiateNewRequestListTop").attr("style", "height: 30px;");
		$(".initiateNewRequestFields").hide();
		$(".initiateNewRequestFieldsetCalculator").hide();
		$('.initiateNewRequestSiteCountByStatus').hide();

		$("#divAccordionCalculator").hide();
		$("#divFTECalcualtorText").hide();
		$.Calculator._interimFrequencyEnabled = false;
		$.GenericFTECalculator._interimFrequencyEnabled = false;
		$.InitiateRequest._adhocCalcIdsToDelete.length = 0; // AI: clear SSV Attribute calculator.
		$.Calculator._staticValues.length = 0;
		$("#imgVisitType").removeClass("ui-iconNew").addClass("ui-iconHide");
		if (GetRmPageLinkId() == RmPageLink_E.AwardedProposalRequest) {
			$("#InitiateRequestForm").addClass("hideMe");
		}
		initReqPgNs.stopDateOriginal = '';
		initReqPgNs.initialStopDateFromQueue = '';
		rm.ui.ribbon.refresh();
	},
	isInEditMode: function () { return initReqPgNs.selectedRequestDetails != null; },
	isGlobalResourceTypeSelected: function () {
		var resourceTypeDetails = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];
		return ((resourceTypeDetails != null) ? resourceTypeDetails.IsGlobal : false);
	},
	isRegionalResourceTypeSelected: function () {
		var resourceTypeDetails = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];
		return ((resourceTypeDetails != null) ? resourceTypeDetails.IsRegionBased : false);
	},
	getRequestId: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.selectedRequestDetails.requestId : null; },
	getSelectedRegionId: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.getRegionId() : initReqPgNs.getRegionIdFromUi(); },
	getRegionId: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.selectedRequestDetails.regionId : null; },
	getRegionIdFromUi: function () { return $(initReqPgNs.ddlPreferredRegionSelector).val(); },
	getCountryRegionId: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.selectedRequestDetails.countryRegionId : null; },
	getResourceTypeName: function () { return $(initReqPgNs.ddlResourceTypeSelector + " option:selected").text(); },
	getResourceTypeId: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.selectedRequestDetails.resourceTypeId : initReqPgNs.getResourceTypeIdFromDropdown(); },
	getResourceTypeIdFromDropdown: function () { return $(initReqPgNs.ddlResourceTypeSelector).val(); },
	getOrganizationalUnitId: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.selectedRequestDetails.organizationalUnitId : initReqPgNs.getOrganizationalUnitIdFromDropdown(); },
	getOrganizationalUnitIdFromDropdown: function () { return $(initReqPgNs.ddlOrganizationalUnitSelector).val(); },
	isCountryChanged: function () { return (!initReqPgNs.isInEditMode() || (initReqPgNs.isInEditMode() && !initReqPgNs.isGlobalResourceTypeSelected() && !initReqPgNs.isRegionalResourceTypeSelected() && initReqPgNs.getCountryIdFromUi() != initReqPgNs.selectedRequestDetails.countryId)); },
	isRegionChanged: function () { return (!initReqPgNs.isInEditMode() || (initReqPgNs.isInEditMode() && !initReqPgNs.isGlobalResourceTypeSelected() && initReqPgNs.getRegionIdFromUi() != initReqPgNs.selectedRequestDetails.regionId)); },
	getCountryId: function () {//Country can be changed. Therefore, countryId from UI gets preference, if available
		var countryId = initReqPgNs.getCountryIdFromUi();
		if (initReqPgNs.isInEditMode()) { return (countryId != null && countryId != "" && countryId != "-1") ? countryId : initReqPgNs.selectedRequestDetails.countryId; } else { return countryId; }
	},
	getCountryIdFromUi: function () { return $(initReqPgNs.isPreferredCountryVisible() ? initReqPgNs.ddlPreferredCountrySelector : initReqPgNs.ddlCountrySelector).val(); },
	isPreferredCountryVisible: function () { return $(initReqPgNs.ddlPreferredCountrySelector).is(":visible"); },
	getCountryName: function () {
		var countryName = $((initReqPgNs.isPreferredCountryVisible() ? initReqPgNs.ddlPreferredCountrySelector : initReqPgNs.ddlCountrySelector) + " option:selected").text();
		var resourceTypeDetails = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];
		return countryName != "" ? countryName : (resourceTypeDetails.IsGlobal ? "Global" : "Regional");
	},
	getRegionName: function () {
		var countryId = initReqPgNs.getCountryId();
		var regionId = initReqPgNs.getRegionIdFromUi();
		var regionName = "";
		var resourceTypeDetails = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];

		if (resourceTypeDetails.IsGlobal) { return "Global"; }
		else if (resourceTypeDetails.IsRegionBased) { return $(initReqPgNs.ddlPreferredRegionSelector + " option:selected").text(); }
		else {
			$.each(CountriesByRegion, function (rIndex, region) {
				$.each(region.CountryList, function (cIndex, country) {
					if (country.Key == countryId) {
						regionName = region.Value;
						return false;
					}
				});
			});
			return regionName;
		}
	},

	getNeedByDate: function () { return $.trim($(initReqPgNs.txtNeedByDateSelector).val()); },
	getTotalSites: function () {
		var totalSites = $.trim($(initReqPgNs.txtTotalSitesSelector).val());
		return (totalSites == "") ? null : totalSites;
	},
	getStartDate: function () { return $.trim($(initReqPgNs.txtStartDateSelector).val()); },
	getStopDate: function () { return $.trim($(initReqPgNs.txtStopDateSelector).val()); },
	getCraTrainingDate: function () { return $.trim($(initReqPgNs.txtCraTrainingDateSelector).val()); },
	getImDate: function () { return $.trim($(initReqPgNs.txtImDateSelector).val()); },

	getProjectId: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.selectedRequestDetails.projectId : initReqPgNs.getProjectIdFromUi(); },
	getProjectIdFromUi: function () { return initReqPgNs.getSelectedProjectId(); },

	getOrganizationId: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.selectedRequestDetails.organizationId : initReqPgNs.getOrganizationIdFromUi(); },
	getOrganizationIdFromUi: function () { return $(initReqPgNs.ddlOrganizationSelector).val(); },

	projectDetails: {},//{<resourceTypeId>: { <projectId>: { <countryId>: {startDate:'12-JAN-2015', stopDate:'12-JAN-2016',ImDate:'12-AUG-2015',craTrainingDate:'12-FEB-2015'    }}}}
	connectedMilestoneDetails: {}, //{1: { 2214: { 245: {startDate:'12-JAN-2015', stopDate:'12-JAN-2016',ImDate:'12-AUG-2015',craTrainingDate:'12-FEB-2015'    }}}}
	regionConnectedMilestoneDetails: {}, //{1: { 2214: { 1: {startDate:'12-JAN-2015', stopDate:'12-JAN-2016',ImDate:'12-AUG-2015',craTrainingDate:'12-FEB-2015'    }}}}
	projectLookupArray: null,
	inactiveProjectLookupArray: null,
	getSelectedProjectId: function () { return initReqPgNs.getProjectFromLookupArrayByProjectCodeProtocol($(initReqPgNs.txtProjectNameSelector).val()).id; },
	getProjectFromLookupArrayByProjectCodeProtocol: function (projectLookupString) {
		if (projectLookupString != "") {
			var projectItem = null;
			if (initReqPgNs.projectLookupArray != null) {
				$.each(initReqPgNs.projectLookupArray, function (index, item) {
					if (item.value == projectLookupString) {
						projectItem = item;
						return false;
					}
				});
			}

			if (projectItem == null) { projectItem = initReqPgNs.getProjectFromInactiveLookupArrayByProjectCodeProtocol(projectLookupString); }

			return projectItem;
		}
		else
			return "";
	},
	getProjectFromInactiveLookupArrayByProjectCodeProtocol: function (projectLookupString) {
		var projectItem = null;
		if (initReqPgNs.inactiveProjectLookupArray == null) { initReqPgNs.inactiveProjectLookupArray = new Array(); }

		$.each(initReqPgNs.inactiveProjectLookupArray, function (index, item) {
			if (item.value == projectLookupString) {
				projectItem = item;
				return false;
			}
		});

		if (projectItem == null) {
			$.rm.Ajax_ProjectSynchronous("GetInactiveProjectDetails", { projectCodeProtocol: projectLookupString }, function (data) {
				projectItem = data;
			}, true);
			initReqPgNs.inactiveProjectLookupArray.push(projectItem);
		}

		return projectItem;
	},

	getProjectFromLookupArrayByProjectId: function (projectId) {
		var projectItem = null;
		if (initReqPgNs.projectLookupArray != null) {
			$.each(initReqPgNs.projectLookupArray, function (index, item) {
				if (item.id == projectId) {
					projectItem = item;
					return false;
				}
			});
		}
		return projectItem;
	},
	getProjectDetailsByProjectId: function (projectId) {

		var selectedProjectData = initReqPgNs.projectDetails[projectId];;

		if (selectedProjectData == null) {
			$.rm.Ajax_RequestSynchronous("GetProjectDetailsForInitiateRequest", { projectId: projectId }, function (data) {
				selectedProjectData = data;
				initReqPgNs.projectDetails[projectId] = data;
			}, true);
		}

		return selectedProjectData;
	},
	allowProjectChange: function (projectId) {
		var projectItem = initReqPgNs.getProjectFromLookupArrayByProjectId(projectId);
		var isResourceTypeSelected = $("#ddlResourceType").val() != -1;
		if (projectItem != null && (!isResourceTypeSelected || (isResourceTypeSelected && confirm('The project code has been changed, if you wish to proceed with changing the project code all data entered will be reset. Click OK to change the project code and reset the resource request form, or Cancel to keep the original project code and entered data')))) {
			$.InitiateRequest._selectedProjectID = projectId;
			$.Dropdown.EmptyDropdown("#ddlResourceType");
			initReqPgNs.handleProjectChange(projectId);
			return true;
		}
		else {
			$('#txtProjectName').val($.InitiateRequest._projectName);
			return false;
		}
	},
	isProposalProjectSelected: function () { return $.Dropdown.GetSelectedProjectDetails().ExternalSource == ProjectSource.SES; },
	manageProposalImageVisibility: function (projectExternalSource) {
		$("#imgProposal").remove();
		if (projectExternalSource == ProjectSource.SES) {
			var img = $("<img>", { id: "imgProposal", src: "/_layouts/spui/images/proposalicon.png", alt: "Proposal Project", title: "Proposal Project", style: "position:relative;top:4px" });
			$("#txtProjectName").parent().append(img);
		}
	},
	handleProjectChange: function (projectId) {
		if ($("#txtProjectName").val() != "") {
			initReqPgNs.hidePastRequestGrid();
			var additionalProjectData = initReqPgNs.getProjectDetailsByProjectId(projectId);

			ClearAll();
			$.Dropdown.Organization(projectId);
			$('.initiateNewRequestFields').hide();
			$("#divAccordionCalculator").hide();
			CleanAllError();
			if (!additionalProjectData.IsMilestoneSequenceValid) {
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showWarningAndFadeAway(Resources.ProjectMilestoneSequenceValidationError);
			}
			$.InitiateRequest._operationRemove = false;
			$.Calculator._interimFrequencyEnabled = false;
			$.GenericFTECalculator._interimFrequencyEnabled = false;
			rm.ui.ribbon.refresh();
			rm.grid.uncheckAllGridRows(initReqPgNs.gridSelector);
			$(".initiateNewRequestFloat").removeClass("initiateNewRequestFloat").addClass("initiateNewRequestFloatEdit");
			initReqPgNs.resetPage();
			if (additionalProjectData) {
				$.InitiateRequest._protocol = additionalProjectData.ProtocolNumber;
				$.InitiateRequest._program = additionalProjectData.ProgramName;
				initReqPgNs.manageProposalImageVisibility(additionalProjectData.ExternalSource);
			}
		}
		else {
			$.Dropdown.EmptyDropdown("#ddlResourceType");
			$.Dropdown.EmptyDropdown("#ddlOrganization");
			$.Dropdown.EmptyDropdown("#ddlOrganizationalUnit");
			RemoveGridRowSelecedClass();
			initReqPgNs.resetPage();
			initReqPgNs.manageProposalImageVisibility(-1);
		}
	},
	checkForValidProjectSelection: function (projectCodeProtocol) {
		var projectItem = initReqPgNs.getProjectFromLookupArrayByProjectCodeProtocol(projectCodeProtocol);
		if (projectItem != null && projectItem != "") {
			initReqPgNs.allowProjectChange(projectItem.id);
		}
		else {
			alert("Invalid Project Selected.");
			$.Dropdown.EmptyDropdown("#ddlResourceType");
			$.Dropdown.EmptyDropdown("#ddlOrganization");
			$.Dropdown.EmptyDropdown("#ddlOrganizationalUnit");
			initReqPgNs.resetPage();
		}
	},
	getConnectedMilestoneDetailsFromDb: function (resourceTypeId, projectId, countryId) {
		var connectedMilestoneDetails;
		$.rm.Ajax_RequestSynchronous("GetConnectedMilestoneDetailsFromDb", { resourceTypeId: resourceTypeId, projectId: projectId, countryId: countryId }, function (data) {
			connectedMilestoneDetails = data;
		}, false);

		return connectedMilestoneDetails;
	},
	getRegionConnectedMilestoneDetailsFromDb: function (resourceTypeId, projectId, regionId) {
		var connectedMilestoneDetails;
		$.rm.Ajax_RequestSynchronous("GetRegionConnectedMilestoneDetailsFromDb", { resourceTypeId: resourceTypeId, projectId: projectId, regionId: regionId }, function (data) {
			connectedMilestoneDetails = data;
		}, false);

		return connectedMilestoneDetails;
	},
	getConnectedDates: function (resourceTypeId, projectId, countryId) {
		//Set country Id to -1 so that the it can be looked up later from json cache
		if (countryId == null) { countryId = -1; }
		var resourceTypeDetails = ResourceTypeDetails[resourceTypeId];
		//Do not make ajax call if resource type has no connected dates
		if (resourceTypeDetails &&
			resourceTypeDetails.CraTrainingDateConnectedMilestoneType == null &&
			resourceTypeDetails.ImDateConnectedMilestoneType == null &&
			resourceTypeDetails.RequestStartDateConnectedMilestoneType == null &&
			resourceTypeDetails.RequestStopDateConnectedMilestoneType == null) {
			return { startDate: "", stopDate: "", imDate: "", craTrainingDate: "" };
		}
		else {
			var connectedMilestoneDetails;
			if (initReqPgNs.connectedMilestoneDetails[resourceTypeId] &&
				initReqPgNs.connectedMilestoneDetails[resourceTypeId][projectId] &&
				initReqPgNs.connectedMilestoneDetails[resourceTypeId][projectId][countryId]) {
				connectedMilestoneDetails = initReqPgNs.connectedMilestoneDetails[resourceTypeId][projectId][countryId];
			}
			else {
				connectedMilestoneDetails = initReqPgNs.getConnectedMilestoneDetailsFromDb(resourceTypeId, projectId, countryId);
				if (!initReqPgNs.connectedMilestoneDetails[resourceTypeId]) { initReqPgNs.connectedMilestoneDetails[resourceTypeId] = {}; }
				if (!initReqPgNs.connectedMilestoneDetails[resourceTypeId][projectId]) { initReqPgNs.connectedMilestoneDetails[resourceTypeId][projectId] = {}; }
				initReqPgNs.connectedMilestoneDetails[resourceTypeId][projectId][countryId] = connectedMilestoneDetails;
			}
			return connectedMilestoneDetails;
		}
	},
	getRegionalConnectedDates: function (resourceTypeId, projectId, regionId) {
		//Do not make ajax call if resource type has no connected dates
		var regionConnectedMilestoneDetails;
		if (initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId] &&
			initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId][projectId] &&
			initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId]) {
			regionConnectedMilestoneDetails = initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId];
		}
		else {
			regionConnectedMilestoneDetails = initReqPgNs.getRegionConnectedMilestoneDetailsFromDb(resourceTypeId, projectId, regionId);
			if (!initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId]) { initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId] = {}; }
			if (!initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId][projectId]) { initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId][projectId] = {}; }
			initReqPgNs.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId] = regionConnectedMilestoneDetails;
		}
		return regionConnectedMilestoneDetails;
	},
	getGlobalConnectedDates: function (resourceTypeId, projectId) {
		return initReqPgNs.getConnectedDates(resourceTypeId, projectId, -1);
	},
	setCountryRegion: function () {
		var countryId = initReqPgNs.getCountryId();
		var isCountryFound = false;
		var DistinctCountryIds = $("#txtProjectName").data("DistinctCountryIds");

		$.each(DistinctCountryIds, function (index, ele) {
			if (ele == countryId) {
				$.Dropdown.CountryRegion(countryId, -1);
				isCountryFound = true;
				return false;
			}
		});

		if (isCountryFound) { $('.initiateFieldCountryRegion').show(); }
		else { $('.initiateFieldCountryRegion').hide(); }
	},
	bindDirty: function () {
		setTimeout(function () {
			initReqPgNs.clearDirty();
			$.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, initReqPgNs.jsonSelectorForDirtyForm());
		}, 10);
	},
	jsonSelectorForDirtyForm: function () { return { items: [{ selector: "#GenericAdHocRow a.adhocDate:visible,#AdHocRow a.adhocDate:visible,#RequestContent input:text:not([readonly]),#RequestContent select:visible,#RequestContent textarea:visible,#RequestContent input:radio:visible", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },
	clearDirty: function () {
		$.formStatus.clearDirty(initReqPgNs.jsonSelectorForDirtyForm());
	},
	isDirty: function () {
		return $.formStatus.isDirty(initReqPgNs.jsonSelectorForDirtyForm());
	},
	phaseCalculatorRenderCompleteHandlerForProposal: function (regionId, countryId, qipData) {
		if (initReqPgNs.isProposalProjectSelected()) {
			if (qipData) {
				if (qipData.hasQipData) {
					if (!initReqPgNs.isInEditMode() || initReqPgNs.isCountryChanged() || initReqPgNs.isRegionChanged()) {
						$('#txtStartDate').val(qipData.startDate);
						$('#txtStopDate').val(qipData.stopDate);
					}
					//if (rm.date.isQDateDateGreaterOrEqualToToday(qipData.startDate)) {
					//	$('#txtStartDate').addClass("disabledTextBox").attr("readonly", true).parent().find(".ui-datepicker-trigger").hide();
					//	$('#txtStopDate').addClass("disabledTextBox").attr("readonly", true).parent().find(".ui-datepicker-trigger").hide();
					//} else {
					//	$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();
					//	$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();
					//}
				}
				else {
					var resourceTypeDetails = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];

					if ((resourceTypeDetails.IsGlobal && !initReqPgNs.isInEditMode()) ||
						(resourceTypeDetails.IsOthers && initReqPgNs.isCountryChanged())) {
						$('#txtStartDate,#txtStopDate').val("");
					}
					$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();
					$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();

					$.each($.Calculator._staticValues, function (index, phase) {
						$("#txtWeeklyHours_" + phase.FTETypeFTEMilestoneTypeId).val(phase.WeeklyHours);
						$("#txtFTE_" + phase.FTETypeFTEMilestoneTypeId).val(phase.FTE);
						$("#hdnFTETypeId_" + phase.FTETypeFTEMilestoneTypeId).val($.Calculator._staticTimestampValues[index].FteTypeId);
					});
				}
			}
		}
		else {
			$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();
			$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly").parent().find(".ui-datepicker-trigger").show();
		}
	},
	getCustomFieldDefaultvalues: function (resourceTypeId, projectId, countryId) {
		$.rm.Ajax_Request("GetCustomFieldDefaultvalues", { resourceTypeId: resourceTypeId, projectId: projectId, countryId: countryId }, function (data) {
			if (data && data.length > 0) {
				$.each(data, function (index, item) { $("#InputNumericField_" + item.FieldId).val(item.Default); });
			}
		}, true);
	},
	getResourceTransitionTimeInDays: function () { return ResourceTypeDetails[initReqPgNs.getResourceTypeId()].ResourceTransitionTimeInDays; },
	ShowCountryDisconnectedIconsForStartAndStopDates: function () {
		$.InitiateRequest.AppendDisconnectedCountryImage($(initReqPgNs.txtStartDateSelector));
		$.InitiateRequest.AppendDisconnectedCountryImage($(initReqPgNs.txtStopDateSelector));
	},
	ShowPpmDisconnectedIconsForStartAndStopDates: function () {
		$.InitiateRequest.AppendDisconnectedImage($(initReqPgNs.txtStartDateSelector));
		$.InitiateRequest.AppendDisconnectedImage($(initReqPgNs.txtStopDateSelector));
	}
};
var objPageManager;
var Checkautoselect = false;
var bindingObject = {

	reasonKeyup: function () {
		$('#txtReason').keyup(function () {
			if ($.q.textCounter(this, $.InitiateRequest._reasonMaxLength, "#lblRemainingLength")) {
				if ($.trim($('#txtReason').val()).length != 0) {
					rm.validation.clearError($(this));
				}
				else {
					rm.validation.addError("#txtReason", Resources.ReasonRequired);
				}
			}
			else {
				rm.validation.addError($(this), "Maximum character limit: " + $.InitiateRequest._reasonMaxLength);
			}
		});
	},

	spanAssignedRegionListClick: function () {
		$("#spanAssignedRegionList").bind("click", function (event) { return false; });
	},

	spanAssignedCountryListClick: function () {
		$("#spanAssignedCountryList").bind("click", function (event) { return false; });
	},

	imgAssignedRegionListClick: function () {
		$("#imgAssignedRegionList").bind("click", function (event) {
			if ($("#imgAssignedRegionList").attr("isHideShow") == "show") {
				if ($.InitiateRequest._regionIds == "") {
					$.Dropdown.ClearAssignCountry();
				}
				else {
					var postData =
					{
						projectId: $.InitiateRequest._selectedProjectID,
						regionIds: $.InitiateRequest._regionIds
					};

					$.rm.Ajax_Utility("GetActiveCountries", postData, function (data) {
						$.Dropdown.BindAssignedCountry(data);
					}, true, true);
				}

				RunMethod(objPageManager, "CountryRegion");
			}

			if ($("#imgAssignedRegionList").attr("isHideShow") == "hide") {
				$("#imgAssignedRegionList").attr("isHideShow", "show");
			}
			else {
				$("#imgAssignedRegionList").attr("isHideShow", "hide");
			}

			if ($(".dropDownMenuAssignedCountryList").size() > 0) {
				$(".dropDownMenuAssignedCountryList").remove();
			}
		});
	},

	imgAssignedCountryListClick: function () {
		$("#imgAssignedCountryList").bind("click", function (event) {
			if ($(".dropDownMenuAssignedRegionList").size() > 0) {
				$(".dropDownMenuAssignedRegionList").remove();
			}
			$("#imgAssignedRegionList").attr("isHideShow", "hide");

			if ($("#imgAssignedCountryList").attr("isHideShow") == "hide") {
				$("#imgAssignedCountryList").attr("isHideShow", "show");
			}
			else {
				RunMethod(objPageManager, "CountryRegion");

				$("#imgAssignedCountryList").attr("isHideShow", "hide");

				if ($(".dropDownMenuAssignedCountryList").size() > 0) {
					setTimeout(function () { $(".dropDownMenuAssignedCountryList").remove(); }, 100);
				}
			}
			SetCancelUpdateButtonEnabled();
		});
	},

	radioChange: function () {
		$('input:radio[name=radioRequestBudgeted]').bind("change", function (event) {
			rm.validation.clearError($("#spanYes"));
			rm.validation.clearError($("#spanNo"));
			RunMethod(objPageManager, "ChangeFrameSize");
		});

		$("input:radio[name=radioRequestBlinded]").bind("change", function (event) {
			rm.validation.clearError($("#spanBlindedYes"));
			rm.validation.clearError($("#spanBlindedNo"));
			RunMethod(objPageManager, "ChangeFrameSize");
		});
	},

	VisitTypeChange: function () {
		$('#ddlVisitType').bind("change", function (event) {
			if (_visitType.Telephone_Training_Booster == $(this).val()) {
				$("#imgVisitType").removeClass("ui-iconHide").addClass("ui-iconNew");
				rm.qtip.showInfo("#imgVisitType", "This option can be used for an additional CRF collection assignment or for any other type of miscellaneous visit not covered by other menu options.");
			}
			else if (_visitType.Pharmacy_Visit_Initiation == $(this).val() || _visitType.Pharmacy_Visit_Interim == $(this).val() || _visitType.Pharmacy_Visit_Closeout == $(this).val()) {
				$("#imgVisitType").removeClass("ui-iconHide").addClass("ui-iconNew");
				rm.qtip.showInfo("#imgVisitType", "For ongoing Pharmacy monitoring assignments, use the Pharmacy Monitoring Resource Request type. For a short term Pharmacy monitoring assignments, use the Short Term SWAT Resource Request type.");
			}
			else {
				$("#imgVisitType").removeClass("ui-iconNew").addClass("ui-iconHide");
			}
		});
	},

	ajaxStop: function () {
		$("#aspnetForm").ajaxStop(function () {
			// Set Preferred Region & Preferred Country here because of race condition.
			if ($.InitiateRequest._rowEdit) {
				$("#ddlPreferredRegion").val(initReqPgNs.getRegionId());
				$("#ddlPreferredCountry").val(initReqPgNs.getCountryId());
				$("#ddlCountryRegion").val(initReqPgNs.getCountryRegionId());

				$.InitiateRequest._rowEdit = false;
				RunMethod(objPageManager, "DrawCalculator", true, true, objPageManager);
				setTimeout(initReqPgNs.bindDirty, 200);
			}

			if ($.InitiateRequest._operationRemove) {
				$.InitiateRequest._operationRemove = false;
				$.Calculator._interimFrequencyEnabled = false;
				$.GenericFTECalculator._interimFrequencyEnabled = false;
			}

			$.InitiateRequest._preventCheckEvent = false;

			setTimeout(rm.ui.ribbon.refresh, 10);
		});
	},

	accordion: function () {
		$("#divAccordionCalculator").accordion({
			collapsible: true,
			animated: true,
			autoHeight: false,
			active: false
		}).hide();
	},

	bindLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_Region", "Region.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_Country", "May be the preferred resource location or the country where the study is taking place.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_CountryRegion", "The region within the country.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_Program", "Program.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_ProjectCode", "Project Code.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_Protocol", "Protocol.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_ProjectDteType", "RBM Project");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_SiteStatus", "The site status from CTMS/InnTrax.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_SponsorSiteName", "Sponsor Site ID.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_PrincipalInvestigator", "Principal Investigator.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_Location", "Location of the site.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_ResourceTypeId", "The type of resource needed to fill a project need.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_VisitTypeName", "Visit description or reason for the visit. Applicable to some request types.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_SSVType", "Visit description (On-site or Phone) applicable to SSV requests.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_NeedByDate", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_StartDate", "The date when the work begins for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_StopDate", "The date when the work ends for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_IMDate", "Investigator Meeting Date.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_CRADate", "CRA Training Date.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_RequestBudgeted", "Is the request budgeted-yes/no?");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_Reason", "The reason the resource is requested when it isn't budgeted.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_Notes", "Use to add/view comments about the particular project/request.");
		rm.qtip.showInfoOnGridColumn(initReqPgNs.gridSelector + "_RequestIdForFilter", "Request Id.");

		styleConfig = { width: '300px' };
		rm.qtip.showInfoOnGridColumn("#initiateReqPreferredLocation", "Place where the Resource Requester would like the resource to be located. All regions and associated countries are  available within the drop downs list.", styleConfig);
		rm.qtip.showInfoOnGridColumn("#initiateReqAssignedLocation", "Area of responsibility for the resource on the project. Countries only appear in the dropdown list if they are in the Project Schedule.", styleConfig);
		rm.qtip.showInfoOnGridColumn("#imgUnblindedResource", "Will the resource assigned to this study request be 'Unblinded' ? If you are requesting an Unblinded resource, then your project must have an unblinded component", styleConfig);
		rm.qtip.showInfoOnGridColumn("#imgVisitType", " ");
	}
};

$(document).ready(function () {
	bindEventHandlersIrp();
	$(initReqPgNs.taNotesSelector).on("change keyup", function () { setTimeout(SetCancelUpdateButtonEnabled, 20); });
	$(document).on("change keyup", "#RequestContent textarea", function () { setTimeout(SetCancelUpdateButtonEnabled, 20); });
	rm.utilities.setSelectedNavLinkAndHelpUrl(GetRmPageLinkId());

	$(document).on("click", ".imgReconnect", function () { SetCancelUpdateButtonEnabled(); });

	$(document).on("click", "[id$='imgReConnect']", function () { SetCancelUpdateButtonEnabled(); });

	$(".initiateNewRequestFloat").removeClass("initiateNewRequestFloat").addClass("initiateNewRequestFloatEdit");

	bindingObject.spanAssignedRegionListClick();
	bindingObject.spanAssignedCountryListClick();
	bindingObject.imgAssignedRegionListClick();
	bindingObject.imgAssignedCountryListClick();
	bindingObject.reasonKeyup();
	bindingObject.radioChange();
	bindingObject.VisitTypeChange();
	bindingObject.accordion();
	bindingObject.ajaxStop();
	$("#s4-workspace").attr("style", "").attr("style", "overflow-x: hidden;"); // Hide page horizontal scrol bar.
	$.SmartSearch.SetupProjectSmartSearchforInitiateRequest($('#txtProjectName'));
	GetDistinctCountryIds();
	if (isInitiateRequestPage(GetRmPageLinkId())) {
		$("#InitiateRequestForm").removeClass("hideMe");
	}
	if (GetRmPageLinkId() == RmPageLink_E.AwardedProposalRequest) {
		$("#InitiateRequestForm").addClass("hideMe");
	}
	$.Dropdown.EmptyDropdown("#ddlResourceType");
	$.Dropdown.EmptyDropdown("#ddlOrganization");
	$.Dropdown.EmptyDropdown("#ddlOrganizationalUnit");
	buildGrid(GetRmPageLinkId());
	$("#txtCRATrainingDate, #txtIMDate").qDatepicker();
	$('.initiateNewRequestFields').hide();
	$(".initiateNewRequestListTop").attr("style", "height: 30px;");
	$("input[type=radio]").attr("checked", false);

	rm.grid.bindEventsToResizeGrid(initReqPgNs.gridSelector);

	$(initReqPgNs.txtProjectNameSelector).blur(function () {
		rm.ui.ribbon.refresh();
	});
});


$(document).click(function () {
	if ($(".dropDownMenuAssignedRegionList").size() > 0) {
		$("#imgAssignedRegionList").trigger('click');
		setTimeout(function () { $(".dropDownMenuAssignedRegionList").remove(); }, 100);
	}
	if ($(".dropDownMenuAssignedCountryList").size() > 0) {
		$("#imgAssignedCountryList").trigger('click');
		setTimeout(function () { $(".dropDownMenuAssignedCountryList").remove(); }, 100);
	}
	$("#imgAssignedRegionList").attr("isHideShow", "hide");
	$("#imgAssignedCountryList").attr("isHideShow", "hide");
});


$.SmartSearch = {

	SetupProjectSmartSearchforInitiateRequest: function (TextboxObj) {
		var resultset;

		var Checkenter = false;
		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.projectSvcUrl + "GetAwardedAndProposalProjectList",
			dataType: "json",
			success: function (data) {
				initReqPgNs.projectLookupArray = data;
				var eventHandled = false;
				//bind the autocomplete plugin to the search box
				TextboxObj.autocomplete({
					source: data,
					matchContains: false
				}).keydown(function (e) {
					//event is not already handled by select handler and either enter or tab is pressed
					if (!eventHandled && (e.keyCode === 13 || e.keyCode === 9)) {
						eventHandled = true;
						initReqPgNs.checkForValidProjectSelection($(this).val());
					} else {
						eventHandled = false;
					}
				});
				$("#txtProjectName").autocomplete({
					select: function (event, ui) {
						//event is not already handled by keydown handler
						if (!eventHandled && !initReqPgNs.allowProjectChange(ui.item.id)) {
							event.stopPropagation();
							event.preventDefault();
						}
						eventHandled = true;
					}
				});
			},

			error: function (errMsg) {
				alert('Unable to load master list of projects.');
			}
		});
	},
};

var bindEventHandlersIrp = function () {
	$("#ddlOrganization").on('change', function (event) {
		initReqPgNs.hidePastRequestGrid();
		$('.initiateNewRequestFieldsetCalculator').hide();
		$('.initiateNewRequestSiteCountByStatus').hide();

		if ($("#ddlOrganization").val() != -1) {
			ClearAll();
			$.Dropdown.OrganizationalUnit($("#ddlOrganization").val());
			$("#ddlOrganizationalUnit").trigger("change");
			$('.initiateNewRequestFields').hide();
			$("#divAccordionCalculator").hide();
			$("#divFTECalcualtorText").hide();
			CleanAllError();
			$.InitiateRequest._operationRemove = false;
			$.Calculator._interimFrequencyEnabled = false;
			$.GenericFTECalculator._interimFrequencyEnabled = false;
			rm.ui.ribbon.refresh();
			rm.grid.uncheckAllGridRows(initReqPgNs.gridSelector);
			$(".initiateNewRequestFloat").removeClass("initiateNewRequestFloat").addClass("initiateNewRequestFloatEdit");

			var additionalProjectData = $.Dropdown.GetSelectedProjectDetails();
			if (additionalProjectData) {
				$.InitiateRequest._protocol = additionalProjectData.ProtocolNumber;
				$.InitiateRequest._program = additionalProjectData.ProgramName;
			}
		}
		else {
			$.Dropdown.EmptyDropdown("#ddlOrganizationalUnit");
			RemoveGridRowSelecedClass();
			initReqPgNs.resetPage();
		}
	});

	$("#ddlOrganizationalUnit").on('change', function (event) {
		initReqPgNs.hidePastRequestGrid();
		$('.initiateNewRequestFieldsetCalculator').hide();
		$('.initiateNewRequestSiteCountByStatus').hide();
		if ($("#ddlOrganizationalUnit").val() != -1) {
			$.Dropdown.ResourceType($("#ddlOrganizationalUnit").val());
			$('.initiateNewRequestFields').hide();
			$("#divAccordionCalculator").hide();
			$("#divFTECalcualtorText").hide();
			CleanAllError();
			$.InitiateRequest._operationRemove = false;
			$.Calculator._interimFrequencyEnabled = false;
			$.GenericFTECalculator._interimFrequencyEnabled = false;
			rm.ui.ribbon.refresh();
			rm.grid.uncheckAllGridRows(initReqPgNs.gridSelector);
			$(".initiateNewRequestFloat").removeClass("initiateNewRequestFloat").addClass("initiateNewRequestFloatEdit");
		}
		else {
			$.Dropdown.EmptyDropdown("#ddlResourceType");
			RemoveGridRowSelecedClass();
			initReqPgNs.resetPage(true);
		}
	});

	$("#ddlResourceType").on('change', function (event) {
		rm.validation.clearError("#ddlResourceType");
		if (initReqPgNs.isInEditMode() && initReqPgNs.getResourceTypeId() != initReqPgNs.getResourceTypeIdFromDropdown()) {
			alert("The Resource Request Type cannot be modified.  If the action you want to take is create a new resource request, then click the \"Cancel Update\" button and follow the Initiate New Request process.");
			$("#ddlResourceType").val(initReqPgNs.getResourceTypeId());
			event.preventDefault();
			event.stopPropagation();
		}
		else {
			var fteCalculatorHelpText = rm.utilities.getFteCalculatorTextByResourceTypeId(initReqPgNs.getResourceTypeId());
			if (fteCalculatorHelpText == "") { $("#divFTECalcualtorText").html("").hide(); }
			else { $("#divFTECalcualtorText").html(fteCalculatorHelpText).show(); }

			$("#DynamicContent").empty();
			rm.ui.messages.clearAllMessages();

			var resoruceTypeDetails = ResourceTypeDetails[initReqPgNs.getResourceTypeIdFromDropdown()];
			var additionalProjectData = $.Dropdown.GetSelectedProjectDetails();

			if (!initReqPgNs.isProposalProjectSelected() && resoruceTypeDetails.DteCheckRequired && additionalProjectData.ProjectDteType.toUpperCase() == "UNKNOWN") {
				initReqPgNs.resetPage();
				alert(Resources.ProjectDteTypeIsUnknown.replace("{Project}", $(initReqPgNs.txtProjectNameSelector).val()));
				return false;
			}
			CleanAllError();
			DrawMe(true);
			$.Calculator._resourceTypeId = $("#ddlResourceType").val();
			$.Calculator._countryId = -1;
			if ($.InitiateRequest._PageManager == "Global_CPM_PageManager") {
				RunMethod(objPageManager, "DrawCalculator", false, false, objPageManager);
			}
			if ($.InitiateRequest._PageManager == "Generic_PageManager") { $("#txtStartDate,#txtStopDate").qDatepicker({ 'destroy': true }); }
			else { $("#txtStartDate,#txtStopDate").qDatepicker(); }
			initReqPgNs.showHidePastRequests();
			CleanValidationErrors();

			rm.ui.ribbon.refresh();
			rm.grid.uncheckAllGridRows(initReqPgNs.gridSelector);
			$.InitiateRequest.ClearConnectDisconnectImages();
			RunMethod(objPageManager, "OnDrawComplete");
		}
		$("#imgVisitType").removeClass("ui-iconNew").addClass("ui-iconHide");
	});

	$("#ddlPreferredRegion").on('change', function (event) {
		RunMethod(objPageManager, "GetPreferredCountryByPreferredRegion");
		RunMethod(objPageManager, "GetOtherByResourceTypeCountry");
		initReqPgNs.showHidePastRequests();
	});

	$("#ddlCountry").on('change', function (event) {
		if (calculatorHelper != undefined) {
			calculatorHelper.selectedCountryId = $("#ddlCountry").val();
		}

		if ($("#ddlCountry").val() != -1) {
			RunMethod(objPageManager, "GetOtherByResourceTypeCountry");
			RunMethod(objPageManager, "GetFTECalculator", this, objPageManager);
			rm.validation.clearError($("#ddlCountry"));
		}
		else {
			$.Dropdown.EmptyDropdown("#ddlSiteId");
			$.Dropdown.EmptyDropdown("#ddlVisitType");
			$("#txtSiteStatus").val("");
			$("#txtStartDate").val("");
			$("#txtStopDate").val("");
			$("#txtNeedByDate").val("");
			$("#txtIMDate").val("");
			$("#txtCRATrainingDate").val("");
			HideDateIcon();
			HideDateCountryIcon();
		}
		$("#imgVisitType").removeClass("ui-iconNew").addClass("ui-iconHide");
	});

	$("#ddlSiteId").on('change', function (event) {
		if ($("#ddlSiteId").val() != -1) {
			RunMethod(objPageManager, "GetOtherByResourceType");
			rm.validation.clearError($("#ddlSiteId"));
			var siteData = $("#ddlSiteId").data("siteData");

			if (typeof calculatorHelper != "undefined") {
				calculatorHelper.handleSiteChange($("#ddlSiteId").val(), $.InitiateRequest._selectedProjectID, $("#ddlCountry").val(), initReqPgNs.getRequestId(), initReqPgNs.getResourceTypeId(), objPageManager, true);
				calculatorHelper.setTiersFromSite($("#ddlSiteId").val(), initReqPgNs.getRequestId(), initReqPgNs.getResourceTypeId(), siteData);
			}
		}
		else {
			$("#txtSiteStatus").val("");
			$.InitiateRequest._piName = "";
			$.InitiateRequest._sponsorSite = "";
			$.InitiateRequest._requestLocation = "";

			if (typeof calculatorHelper != "undefined") {
				calculatorHelper.handleEmptySite(); // TL: Not sure why this is passed
			}
		}
	});

	$("#ddlPreferredCountry").on('change', function (event) {
		if ($("#ddlPreferredCountry").val() != -1) {
			RunMethod(objPageManager, "GetOtherByResourceTypeCountry");
			RunMethod(objPageManager, "GetFTECalculator", this, objPageManager);
			rm.validation.clearError($("#ddlPreferredCountry"));
			initReqPgNs.showHidePastRequests();
			initReqPgNs.showHideSiteCountByStatus();
		}
		else {
			HideDateIcon();
			HideDateCountryIcon();
		}
	});

	$("#ddlVisitType,#ddlSSVType,#ddlPreferredRegion,#ddlPreferredCountry,#ddlCountryRegion").on('change', function (event) {
		if ($(this).val() != -1) {
			rm.validation.clearError($(this));
		}
	});

	$("#txtStartDate,#txtStopDate").on('blur', function (event) {
		if ($.trim($(this).val()) == "") {
			var message = "";
			if ($(this).attr("id") == "txtStartDate") {
				message = Resources.StartDateIsBlank;
			}
			else if ($(this).attr("id") == "txtStopDate") {
				message = Resources.StopDateIsBlank;
			}
			rm.validation.addError($(this), message);
		}
	});

	$("#txtStartDate").on('keyup change', function (event) {
		if (rm.date.isValidDate($("#txtStartDate").val(), false)) {
			CalculateNeedByDate();
		}
		else {
			$("#txtNeedByDate").val("Not Available");
		}
	});

	$("#txtStopDate,#txtStartDate").on('change', function (event) {
		if (!initReqPgNs.isProposalProjectSelected()) { RunMethod(objPageManager, "handleStartStopDateChange"); }
	});
};
setNeedByDate = function (startDateValue, ResourceTransitionTimeinDays) {
	$("#txtNeedByDate").val("");
	if ($(initReqPgNs.txtNeedByDateSelector).is(":visible") && startDateValue != "") {
		$("#txtNeedByDate").val(rm.bizRules.getNeedByDate(startDateValue, ResourceTransitionTimeinDays));
	}
};

DrawMe = function (withCountry, requestBlinded) {
	GetPageManagerName(function (output) {
		ClearAll();
		objPageManager = new $.InitiateRequest.GetPageManager(output["Name"]);
		$.InitiateRequest._PageManager = output["Name"];
		$.InitiateRequest._DefaultFromMilestoneId = output["DefaultFromMilestoneId"];
		$.InitiateRequest._DefaultToMilestoneId = output["DefaultToMilestoneId"];
		$.InitiateRequest._resourceTransitionTime = output["ResourceTransitionTime"];
		RunMethod(objPageManager, "Draw", withCountry);
		if (initReqPgNs.projectDetails[initReqPgNs.getProjectId()].IsOpenLabel) {
			$('#initiateFieldBlindedSpan').hide();
		} else {
			$.rm.SetRequestBlindedFieldVisibility(output["DisplaysBlindedField"]);
		}
		//ClearAll();
		RunMethod(objPageManager, "SetDefaultProposalDates", $.Dropdown.GetSelectedProjectDetails());
	});
	initReqPgNs.bindDirty();
};

//RMK: Added to get the page manager name
function GetPageManagerName(output) {
	var resourceTypeId = $('#ddlResourceType').val();
	var postData = {
		resourceTypeId: resourceTypeId,
		isProposalRequest: initReqPgNs.isProposalProjectSelected()
	};

	$.rm.Ajax_RequestSynchronous("GetPageManagerTypeName", postData, function (data) {
		output(data);
	}, false);
};

function GetAssignedCountryRegionsJson() {
	return {
		RegionList: GetRegionArrayFromString($.InitiateRequest._regionIds),
		CountryList: GetCountryArrayFromString($.InitiateRequest._countryRegions)
	};
};

function GetRegionArrayFromString(arrayString) {
	var selectedItems = new Array();
	if (arrayString && arrayString.indexOf(',') != -1) {
		var countryRegionList = arrayString.split(',');

		for (var i = 0; i < countryRegionList.length; i++) {
			selectedItems.push({
				key: countryRegionList[i]
			});
		}
	}
	else if (arrayString && arrayString.length > 0) {
		selectedItems.push({
			key: arrayString
		});
	}
	return selectedItems;
}

function GetCountryArrayFromString(arrayString) {
	var selectedItems = new Array();
	if (arrayString && arrayString.indexOf(',') != -1) {
		var countryRegionList = arrayString.split(',');

		for (var i = 0; i < countryRegionList.length; i++) {
			items = countryRegionList[i].split('|');
			selectedItems.push({
				key: items[1],
				regionId: items[0]
			});
		}
	}
	else if (arrayString && arrayString.length > 0) {
		items = arrayString.split('|');
		selectedItems.push({
			key: items[1],
			regionId: items[0]
		});
	}
	return selectedItems;
};


AddInitiateRequest = function () {
	$(document).trigger('click');
	if (ValidateEntry("Add")) {
		if ($.InitiateRequest._PageManager == "Generic_PageManager") {
			var milestoneIds = $.GenericFTECalculator.GetAllCustomMilestoneIds();
			CalculateNeedByDate();
			$.validationHelper.GetCustomeMilestoneStatus("", milestoneIds, true, false, $.GenericFTECalculator.DeletedMilestones);
		}
		if (!$.validationHelper.isAnyMilestoneDeactivated) {
			//$(".hasDatepicker").change();
			RunMethod(objPageManager, "SaveRequest");
		}
	}
	else {
		rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
	}
};

GetCountryRegionName = function () {
	var countryRegionName = "";
	if ($.InitiateRequest._PageManager == "SSV_Monitoring_PageManager" ||
		$.InitiateRequest._PageManager == "Standard_Monitoring_PageManager" ||
		$.InitiateRequest._PageManager == "Pharmacy_Monitoring_PageManager" ||
		$.InitiateRequest._PageManager == "Short_term_SWAT_Monitoring_OnSite_Visit_PageManager" ||
		$.InitiateRequest._PageManager == "Short_term_SWAT_Monitoring_Phone_Visit_PageManager" ||
		$.InitiateRequest._PageManager == "iCRA_Monitoring_PageManager" ||
		$.InitiateRequest._PageManager == "DTESite_Monitoring_PageManager" ||
		$.InitiateRequest._PageManager == "DTEPharmacy_Monitoring_PageManager" ||
		$.InitiateRequest._PageManager == "Co_monitoring_SiteSpecific_PageManager" ||
		$.InitiateRequest._PageManager == "Non_Standard_Monitoring_SiteSpecific_PageManager") {
		countryRegionName = $.InitiateRequest._countryRegionName;
	}
	else {
		countryRegionName = $.InitiateRequest._countryRegion != -1 ? $('#ddlCountryRegion option:selected').text() : "";
	}
	return countryRegionName;
};

GetRequestLastModifiedOn = function (isAdd) {
	return isAdd ? null : $.InitiateRequest._requestLastModifiedOn;
};

GetAttributeLastModifiedOn = function (isAdd) {
	if (isAdd) {
		var attr = RunMethod(objPageManager, "GetAttribute", $.InitiateRequest._country);
		return attr == undefined ? null : attr.AttributeLastModifiedOn;
	}
	else {
		return ($.InitiateRequest._attributeLastModifiedOn * 1) == 0 ? null : $.InitiateRequest._attributeLastModifiedOn;
	}
};

GetProjectLastModifiedOn = function () {
	return $.Dropdown.GetSelectedProjectDetails().ProjectLastModifiedOn;
};

GetSiteAdressPiLastModifiedOn = function () {
	var returnVal = {
		SiteLastModifiedOn: null,
		AddressLastModifiedOn: null,
		PiLastModifiedOn: null
	};

	var siteData = $("#ddlSiteId").data("siteData");
	if (siteData != null) {
		$.each(siteData, function (inex, ele) {
			if (ele.SiteId == $.InitiateRequest._siteId) {
				returnVal.SiteLastModifiedOn = ele.SiteLastModifiedOn == 0 ? null : ele.SiteLastModifiedOn;
				returnVal.AddressLastModifiedOn = ele.AddressLastModifiedOn == 0 ? null : ele.AddressLastModifiedOn;
				returnVal.PiLastModifiedOn = ele.PiLastModifiedOn == 0 ? null : ele.PiLastModifiedOn;
				return false;
			}
		});
	}

	return returnVal;
};

GetPostData = function (isAdd) {
	if ($.Calculator._PageManager == "Generic_PageManager") {
		$.InitiateRequest._adhocInitiateCalculator = $.GenericFTECalculator._adHocValues;
		$.InitiateRequest._adhocInitiateCalculatorTimestamp = $.GenericFTECalculator._adHocTimestampValues;
	}
	else {
		$.InitiateRequest._adhocInitiateCalculator = $.Calculator._adHocValues;
		$.InitiateRequest._adhocInitiateCalculatorTimestamp = $.Calculator._adHocTimestampValues;
	}

	var fte = null;
	var totalHours = null;

	//TODO:Refactor to move this to page manager
	if ((initReqPgNs.isProposalProjectSelected() && $.Calculator._PageManager == "Proposal_Base_PageManager") ||
		$.Calculator._PageManager == "MonitoringCountrySpecificPageManager_Type1") {
		fte = $(initReqPgNs.txtProposalFteSelector).val();
	}
	else if ($.Calculator._PageManager == "SSV_CountrySpecific_Monitoring_PageManager") {
		fte = SSVCountryCalculatorNs.GetValues().FTE;
		totalHours = SSVCountryCalculatorNs.GetValues().TotalHours;
	}
	else if ($.Calculator._PageManager == "FlatFteCalculatorPageManager_Type2") {
		fte = $(initReqPgNs.txtProposalFteSelector).val();
	}
	else {
		fte = $.Calculator._PageManager == "Generic_PageManager" ? $.GenericFTECalculator.GetValues().FTE : $.SmallFTECalculator.GetValues().FTE;
		totalHours = $.Calculator._PageManager == "Generic_PageManager" ? $.GenericFTECalculator.GetValues().TotalHours : $.SmallFTECalculator.GetValues().TotalHours;
	}

	var adhocsToDelete = new Array();
	if (!isAdd) {
		adhocsToDelete = $.InitiateRequest._adhocCalcIdsToDelete;
	}
	var bigCalculatorData = (typeof calculatorHelper != "undefined") ? calculatorHelper.getCalculatorGroupData(calculatorHelper.getSelectedTabIndex(), isAdd, adhocsToDelete) : null;
	var siteTimestamp = GetSiteAdressPiLastModifiedOn();
	var resourceTypeDetails = ResourceTypeDetails[initReqPgNs.getResourceTypeId()];
	var postData =
	{
		initiateRequest:
		{
			ProjectId: $.InitiateRequest._projectCode,
			CountryId: initReqPgNs.getCountryId(),
			ResourceTypeId: initReqPgNs.getResourceTypeId(),
			OrganizationId: initReqPgNs.getOrganizationId(),
			OrganizationalUnitId: (initReqPgNs.getOrganizationalUnitId() == "0") ? null : initReqPgNs.getOrganizationalUnitId(),
			SiteId: $.InitiateRequest._siteId,
			StartDate: initReqPgNs.getStartDate(),
			StopDate: initReqPgNs.getStopDate(),
			NeedByDate: resourceTypeDetails.ShowNeedByDate ? initReqPgNs.getNeedByDate() : null,
			RequestBudgeted: $.InitiateRequest._requestBudgeted,
			RequestBlinded: $('#initiateFieldBlindedSpan').is(":visible") ? $.InitiateRequest._requestUnblinded : "",
			Reason: $.InitiateRequest._reason,
			Location: $.InitiateRequest._requestLocation,
			RequestId: initReqPgNs.getRequestId(),
			RowId: initReqPgNs.getRequestId(),
			Duration: $.InitiateRequest._duration,
			VisitType: $.InitiateRequest._visitType,
			AssignedCountryRegions: GetAssignedCountryRegionsJson(),
			RegionId: $.InitiateRequest._regionId,
			StaticInitiateCalculator: (resourceTypeDetails.IsOthers || resourceTypeDetails.IsRegionBased || resourceTypeDetails.IsGlobal) ? $.Calculator._staticValues : null,
			AdhocInitiateCalculator: (resourceTypeDetails.IsOthers || resourceTypeDetails.IsGeneric || resourceTypeDetails.IsRegionBased || resourceTypeDetails.IsGlobal) ? $.InitiateRequest._adhocInitiateCalculator : null,
			StaticInitiateCalcTimestamp: $.Calculator._staticTimestampValues,
			AdhocInitiateCalcTimestamp: $.InitiateRequest._adhocInitiateCalculatorTimestamp,
			GenericInitiateCalculatorPhaseDate: resourceTypeDetails.IsGeneric ? $.GenericFTECalculator._genericRowsValues : null,
			GenericInitiateCalcTimestamp: $.GenericFTECalculator._genericRowTimestampValues,
			CountryRegion: $.InitiateRequest._countryRegion,
			StartDateStatus: $("#txtStartDate").parent().find(".connectedToCountry,.connectedToPpm").length > 0 ? RequestConnect_E.Connected : RequestConnect_E.Disconnected,
			StopDateStatus: $("#txtStopDate").parent().find(".connectedToCountry,.connectedToPpm").length > 0 ? RequestConnect_E.Connected : RequestConnect_E.Disconnected,
			FTE: fte,
			Notes: $(initReqPgNs.taNotesSelector).val(),
			TotalHours: totalHours,
			TotalSites: $.Calculator._PageManager == "SSV_CountrySpecific_Monitoring_PageManager" ? SSVCountryCalculatorNs.GetValues().TotalSites : initReqPgNs.getTotalSites(),
			TotalHoursPerSite: $.Calculator._PageManager == "SSV_CountrySpecific_Monitoring_PageManager" ? SSVCountryCalculatorNs.GetValues().TotalHoursPerSite : null,
			SSVType: $.InitiateRequest._SSVType,
			CRATrainingDate: initReqPgNs.getCraTrainingDate(),
			calculatorGroupData: bigCalculatorData,
			IMDateStatus: $("#txtIMDate").parent().find(".connectedToCountry,.connectedToPpm").length > 0 ? RequestConnect_E.Connected : RequestConnect_E.Disconnected,
			CRATrainingDateStatus: $("#txtCRATrainingDate").parent().find(".connectedToCountry,.connectedToPpm").length > 0 ? RequestConnect_E.Connected : RequestConnect_E.Disconnected,
			IMDate: initReqPgNs.getImDate(),
			RequestTimestamp: {
				RequestLastModifiedOn: GetRequestLastModifiedOn(isAdd),
				AttributeLastModifiedOn: GetAttributeLastModifiedOn(isAdd),
				ProjectLastModifiedOn: GetProjectLastModifiedOn(),
				SiteLastModifiedOn: siteTimestamp.SiteLastModifiedOn,
				AddressLastModifiedOn: siteTimestamp.AddressLastModifiedOn,
				PiLastModifiedOn: siteTimestamp.PiLastModifiedOn
			},
			DynamicCustomFieldsData: rm.customFields.getCustomFieldUserEnteredValues($("#DynamicContent")),
			JobGrade: objPageManager.getJobGrade(),
			JobGradeInfoStr: objPageManager.getJobGradeInfoString()
		}
	}
	return postData;
};

SaveNewInitiateRequest = function () {
	var postData = GetPostData(true);
	var isSuccess = true;
	var error_msg;
	if ($.Dropdown.IsValidationRequired($('#ddlResourceType').val())) {
		var Request =
		{
			ProjectId: $.InitiateRequest._selectedProjectID,
			ResourceTypeId: $('#ddlResourceType').val(),
			CountryId: initReqPgNs.getCountryId(),
			SiteId: $.InitiateRequest._siteId
		};
		var _postdata = { Request: Request };
		$.rm.Ajax_RequestSynchronous("AddToQueueRequests", _postdata, function (data) {
			if (data.IsSuccessful) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
				error_msg = data.Message;
			}
		});
	}

	if (isSuccess)//will be true if no request with same details exist.
	{
		$.rm.Ajax_Request("ValidateAndSaveInitiateRequest", postData, function (data) {
			Checkautoselect = false;
			if (data.ContainsValidationErrors) {
				if (data.ValidationErrors[0].Key == "DisabledTiers")/*request has disabled tiers , so just reload the tier dropdown*/ {
					//$.validationHelper.ShowErrorMessages(data.ValidationErrors);
					rm.validation.processErrorMessages(data.ValidationErrors, initReqPgNs.gridSelector, "Message");
					$.InitiateRequest.LoadTierDropdowns();
				}
				else {
					//$.validationHelper.ShowErrorMessages(data.ValidationErrors);
					rm.validation.processErrorMessages(data.ValidationErrors, initReqPgNs.gridSelector, "Message");
					rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
				}
			}
			else {
				rm.grid.rowData.addData(initReqPgNs.gridSelector, data.RowJson);
				var selectedProjectDetails = $.Dropdown.GetSelectedProjectDetails();
				var blinded = "";
				if (initReqPgNs.projectDetails[initReqPgNs.getProjectId()].IsOpenLabel == true)
					blinded = 'Open Label'
				else if ($.InitiateRequest._requestUnblinded == "No")
					blinded = 'Blinded'
				else if ($.InitiateRequest._requestUnblinded == "Yes")
					blinded = 'Unblinded'
				else
					blinded = ""
				$(initReqPgNs.gridSelector).addRowData(data.RowJson.id, [{
					Id: data.RowJson.id,
					Message: "",
					IconColumn: initReqPgNs.isProposalProjectSelected() ? "<img class='iconPaddingRight' title='Proposal Request' src='/_layouts/SPUI/images/proposalIcon.png'>" : "",
					Region: initReqPgNs.getRegionName(),
					Country: initReqPgNs.getCountryName(),
					CountryRegion: GetCountryRegionName(),
					Program: $.InitiateRequest._program,
					ProjectOrganizationalUnit: selectedProjectDetails.OrganizationalUnit,
					ProjectCode: $('#txtProjectName').val().substring(0, $('#txtProjectName').val().indexOf("-") - 1),
					Protocol: $.InitiateRequest._protocol,
					ProjectDteType: selectedProjectDetails.ProjectDteType,
					SiteStatus: $.InitiateRequest._siteStatus,
					SponsorSiteName: $.InitiateRequest._siteId != -1 ? $.InitiateRequest._sponsorSite : "",
					PrincipalInvestigator: $.InitiateRequest._piName,
					Location: $.InitiateRequest._requestLocation,
					ResourceType: $('#ddlResourceType option:selected').text(),
					VisitTypeName: $.InitiateRequest._visitType != -1 ? $('#ddlVisitType option:selected').text() : "",
					SSVType: $.InitiateRequest._SSVType != -1 ? $('#ddlSSVType option:selected').text() : "",
					StartDate: initReqPgNs.getStartDate(),
					StopDate: initReqPgNs.getStopDate(),
					IMDate: initReqPgNs.getImDate(),
					CRADate: initReqPgNs.getCraTrainingDate(),
					NeedByDate: data.RowJson.NeedByDate,
					RequestBudgeted: $.InitiateRequest._requestBudgeted,
					RequestBlinded: blinded,
					Reason: "<PRE>" + $.InitiateRequest._reason + "</PRE>",
					Notes: data.RowJson.Notes,
					RequestIdForFilter: data.RowJson.id,
				}], "last");


				RunMethod(objPageManager, "OnSaveSuccess");
				initReqPgNs.resetPage();
				RemoveGridRowSelecedClass();
				$.Calculator._interimFrequencyEnabled = false;
				$.GenericFTECalculator._interimFrequencyEnabled = false;
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showSuccess(Resources.AddedToRequestQueue);
				setTimeout(function () {
					initReqPgNs.clearDirty();
					initReqPgNs.bindDirty();
					rm.ui.ribbon.refresh();
				}, 10);
			}

		}, false);
	}
	else {
		rm.ui.messages.clearAllMessages();
		rm.ui.messages.addError(error_msg);
	}
};
UpdateRequest = function () {
	$(document).trigger('click');
	var highlightedId = rm.grid.getHighlightedRowId(initReqPgNs.gridSelector);
	if ((highlightedId != undefined && highlightedId != "")) {
		if (ValidateEntry("Update")) {
			if ($.InitiateRequest._PageManager == "Generic_PageManager") {
				var milestoneIds = $.GenericFTECalculator.GetAllCustomMilestoneIds();
				CalculateNeedByDate();
				$.validationHelper.GetCustomeMilestoneStatus(initReqPgNs.getRequestId(), milestoneIds, true, false, $.GenericFTECalculator.DeletedMilestones);
			}
			if (!$.validationHelper.isAnyMilestoneDeactivated) {
				//$(".hasDatepicker").change();
				RunMethod(objPageManager, "UpdateRequest");
			}
		}
		else {
			rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
		}
	}
	else {
		rm.ui.messages.addError(Resources.NoRowSelected);
	}
};

SaveUpdatedRequest = function () {
	var postData = GetPostData(false);
	var isSuccess = true;
	var error_msg;
	if ($.Dropdown.IsValidationRequired($('#ddlResourceType').val())) {
		var Request =
		{
			ProjectId: $.InitiateRequest._selectedProjectID,
			ResourceTypeId: $('#ddlResourceType').val(),
			CountryId: initReqPgNs.getCountryId(),
			SiteId: $.InitiateRequest._siteId,
			RequestId: initReqPgNs.getRequestId(),
		};
		var _postdata = { Request: Request };
		$.rm.Ajax_RequestSynchronous("UpdateRequests", _postdata, function (data) {
			if (data.IsSuccessful) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
				error_msg = data.Message;
			}
		});
	}
	if (isSuccess) {
		$.rm.Ajax_Request("ValidateAndUpdateInitiateRequest", postData, function (data) {
			Checkautoselect = false;
			if (data.ContainsValidationErrors) {
				if (data.ValidationErrors[0].Key == "DisabledTiers")/*request has disabled tiers , so just reload the tier dropdown*/ {
					//$.validationHelper.ShowErrorMessages(data.ValidationErrors);
					rm.validation.processErrorMessages(data.ValidationErrors, initReqPgNs.gridSelector, "Message");
					$.InitiateRequest.LoadTierDropdowns();
				}
				else {
					//$.validationHelper.ShowErrorMessages(data.ValidationErrors);
					rm.validation.processErrorMessages(data.ValidationErrors, initReqPgNs.gridSelector, "Message");
					rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
				}
			}
			else {
				data.RowJson.ProposalResource = rm.grid.rowData.getById(initReqPgNs.gridSelector, initReqPgNs.getRequestId()).ProposalResource;
				rm.grid.rowData.updateData(initReqPgNs.gridSelector, data.RowJson);
				var blinded = "";
				if (initReqPgNs.projectDetails[initReqPgNs.getProjectId()].IsOpenLabel == true)
					blinded = 'Open Label'
				else if ($.InitiateRequest._requestUnblinded == "No")
					blinded = 'Blinded'
				else if ($.InitiateRequest._requestUnblinded == "Yes")
					blinded = 'Unblinded'
				else
					blinded = ""
				$(initReqPgNs.gridSelector).setRowData(data.RowJson.id, {
					Message: "",
					Region: initReqPgNs.getRegionName(),
					Country: initReqPgNs.getCountryName(),
					CountryRegion: GetCountryRegionName(),
					Program: $.InitiateRequest._program,
					ProjectOrganizationalUnit: $.Dropdown.GetSelectedProjectDetails().OrganizationalUnit,
					ProjectCode: $('#txtProjectName').val().substring(0, $('#txtProjectName').val().indexOf("-") - 1),
					Protocol: $.InitiateRequest._protocol,
					SiteStatus: $.InitiateRequest._siteStatus,
					SponsorSiteName: $.InitiateRequest._siteId != -1 ? $.InitiateRequest._sponsorSite : "",
					PrincipalInvestigator: $.InitiateRequest._piName,
					Location: $.InitiateRequest._requestLocation,
					ResourceType: $('#ddlResourceType option:selected').text(),
					VisitTypeName: $.InitiateRequest._visitType != -1 ? $('#ddlVisitType option:selected').text() : "",
					SSVType: $.InitiateRequest._SSVType != -1 ? $('#ddlSSVType option:selected').text() : "",
					StartDate: initReqPgNs.getStartDate(),
					StopDate: initReqPgNs.getStopDate(),
					IMDate: initReqPgNs.getImDate(),
					CRADate: initReqPgNs.getCraTrainingDate(),
					NeedByDate: data.RowJson.NeedByDate,
					RequestBudgeted: $.InitiateRequest._requestBudgeted,
					RequestBlinded: blinded,
					Reason: "<PRE>" + $.InitiateRequest._reason + "</PRE>",
					ProposalResource: rm.grid.rowData.getById(initReqPgNs.gridSelector, initReqPgNs.getRequestId()).ProposalResource,
				});

				RunMethod(objPageManager, "OnSaveSuccess");
				initReqPgNs.resetPage();
				RemoveGridRowSelecedClass();
				$.Calculator._interimFrequencyEnabled = false;
				$.GenericFTECalculator._interimFrequencyEnabled = false;
				$("#divAccordionCalculator").hide();
				rm.ui.messages.clearAllMessages();
				rm.ui.messages.showSuccess(Resources.RequestQueueUpdated);
				setTimeout(function () {
					initReqPgNs.clearDirty();
					initReqPgNs.bindDirty();
					rm.ui.ribbon.refresh();
				}, 10);
			}
		}, false);
	}
	else {
		rm.ui.messages.clearAllMessages();
		rm.ui.messages.addError(error_msg);
	}
};

RemoveQueue = function () {
	var requestIds = $(initReqPgNs.gridSelector).getGridParam('selarrrow');
	if (requestIds.length == 0) {
		requestIds[0] = rm.grid.getHighlightedRowId(initReqPgNs.gridSelector);
	}
	if (requestIds.length == 0) {
		rm.ui.messages.addError(Resources.SelectRowToDelete);
		return false;
	}

	if (confirm('Are you sure you want to delete selected request(s)?')) {
		var postData =
		{
			requestIds: requestIds
		};

		$.rm.Ajax_Request("DeleteSubmittedRequests", postData,
			function (jsonData) {
				var isSuccess = true;
				$.each(jsonData, function (index, request) {
					if (request.IsSuccessful) {
						rm.grid.removeRow(initReqPgNs.gridSelector, request.EntityId);
					}
					else {
						isSuccess = false;
						rm.grid.showErrorIconInMessageColumn(initReqPgNs.gridSelector, request.EntityId, "Message", request.Message);
						//$(initReqPgNs.gridSelector).setCell(request.EntityId, 'Message', request.Message);
						//$(initReqPgNs.gridSelector).showCol("Message");
					}
				});

				$.q.RebindQtip(initReqPgNs.gridSelector);

				if (isSuccess) {
					rm.ui.messages.clearAllMessages();
					RemoveGridRowSelecedClass();
					rm.ui.messages.showSuccess(Resources.DataRemovedSuccessfully);
				}
				else {
					rm.ui.messages.addError(Resources.FailedToRemoveRequest);
				}
			}, false);

		initReqPgNs.resetPage();
		$.InitiateRequest._operationRemove = true;
		$.Calculator._interimFrequencyEnabled = false;
		$.GenericFTECalculator._interimFrequencyEnabled = false;
		$("#divAccordionCalculator").hide();
		setTimeout(function () {
			initReqPgNs.clearDirty();
			initReqPgNs.bindDirty();
			rm.ui.ribbon.refresh();
		}, 10);
	}
};

SubmitQueue = function () {
	makeSubmitAjaxCall("SubmitRequests", Resources.RequestSubmittedSuccessfully, Resources.FailedToSubmitRequest);
	setTimeout(function () {
		initReqPgNs.clearDirty();
		initReqPgNs.bindDirty();
		rm.ui.ribbon.refresh();
	}, 10);
};

CancelUpdateRequest = function () {
	RemoveGridRowSelecedClass();
	initReqPgNs.resetPage();
	rm.ui.messages.clearAllMessages();
	setTimeout(function () {
		initReqPgNs.clearDirty();
		initReqPgNs.bindDirty();
		rm.ui.ribbon.refresh();
	}, 10);
};

getMandatoryColumns = function () {
	return [
		rm.grid.standardColumns.getMessageColumn(),
		{ name: 'IconColumn', index: 'IconColumn', label: ' ', width: 20, search: false, sortable: false, hidden: false, frozen: true }
	];
};
getFullColumnModelList = function (rmPageLinkId) {
	return [
		{ name: 'Region', index: 'Region', label: 'Region', width: 80 },
		{ name: 'Country', index: 'Country', label: 'Country', width: 80 },
		{ name: 'CountryRegion', index: 'CountryRegion', label: 'Country<br/>Region', width: 78 },
		{ name: 'Program', index: 'Program', label: 'Program', width: 80 },
		{ name: 'ProjectOrganizationalUnit', index: 'ProjectOrganizationalUnit', label: 'Project<br/>Organizational Unit', width: 130, search: true },
		{ name: 'Customer', index: 'Customer', label: 'Customer', width: 70, search: true, sortable: false, searchoptions: { attr: { maxlength: 255 } } },
		{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project<br/> Code', width: 80 },
		{ name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 75 },
		{ name: 'ProjectDteType', index: 'ProjectDteType', label: 'RBM Project', width: 80, stype: 'select', searchoptions: { value: rm.grid.filterOptions.dteType } },
		{ name: 'ProposalResource', index: 'ProposalResource', label: 'Resource Name', width: 120, hidden: (rmPageLinkId != RmPageLink_E.AwardedProposalRequest) },
		{ name: 'SiteStatus', index: 'SiteStatus', label: 'Site Status', width: 75, 'text-align': 'right !important;' },
		{ name: 'SponsorSiteName', index: 'SponsorSiteName', label: 'Sponsor<br/>Site ID', width: 70, 'text-align': 'right !important;' },
		{ name: 'PrincipalInvestigator', index: 'PrincipalInvestigator', label: 'PI', width: 100 },
		{ name: 'Location', index: 'Location', label: 'Location', width: 70 },
		{ name: 'RequestBlinded', index: 'RequestBlinded', label: 'Request<br />Unblinded', width: 100, search: true, stype: 'select', searchoptions: { value: rm.grid.filterOptions.blinded } },
		{ name: 'ResourceType', index: 'ResourceType', label: 'Resource Request<br/> Type', width: 120 },
		{ name: 'VisitTypeName', index: 'VisitTypeName', label: 'Visit Type', width: 100 },
		{ name: 'SSVType', index: 'SSVType', label: 'SSV Type', width: 100 },
		{ name: 'NeedByDate', index: 'NeedByDate', label: 'Need By<br/> Date', width: 80 },
		{ name: 'StartDate', index: 'StartDate', label: 'Start Date', width: 80 },
		{ name: 'StopDate', index: 'StopDate', label: 'Stop Date', width: 80 },
		{ name: 'IMDate', index: 'IMDate', label: 'IM Date', width: 80 },
		{ name: 'CRADate', index: 'CRADate', label: 'CRA<br/>Training Date', width: 90 },
		{ name: 'RequestBudgeted', index: 'RequestBudgeted', label: 'Request<br/> Budgeted', width: 77, stype: 'select', searchoptions: { value: rm.grid.filterOptions.yesNo } },
		{ name: 'Reason', index: 'Reason', label: 'Reason', width: 77, search: false, sortable: false },
		rm.grid.standardColumns.getNotesColumn(),
		{ name: 'RequestIdForFilter', index: 'RequestIdForFilter', label: 'Request Id', width: 72 }
	];
};

getDateGridIdFromRmPageLink = function (rmPageLinkId) {
	return isInitiateRequestPage(rmPageLinkId) ? DataGrid.InitiateNewRequest : DataGrid.AwardedProposalRequests;
};
freezeColumnsAndBindInfo = function () {
	if (!initReqPgNs.frozenColumnAlreadyBound) {
		initReqPgNs.frozenColumnAlreadyBound = true;
		//freezing columns involve rebuilding the grid. Once grid is rebuilt, we need to rebing the information qtip.
		rm.grid.delayedRebindFrozenColumns(initReqPgNs.gridSelector);
		setTimeout(bindingObject.bindLabelQtip, 100);
	}
	rm.grid.scrollTableBodyToFixAlignmentIssue(initReqPgNs.gridSelector);
};
buildGrid = function (rmPageLinkId) {
	var handleUserPreferencesResponse = function (userColumnPreferences) {
		var columnModel = rm.grid.getFinalColumnModelFromFullColumnListAndUserColumnPreferences(getFullColumnModelList(rmPageLinkId), userColumnPreferences, getMandatoryColumns());
		buildDynamicGrid(rmPageLinkId, columnModel, userColumnPreferences);
	};

	rm.serviceCalls.getRmUserDataGridColumnPreferences(getDateGridIdFromRmPageLink(rmPageLinkId), handleUserPreferencesResponse)
};

function buildDynamicGrid(rmPageLinkId, columnModel, userColumnPreferences) {
	var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
	gridToolsConfig.exportParameters = { rmPageLink: rmPageLinkId, dataGridId: getDateGridIdFromRmPageLink(rmPageLinkId) };
	gridToolsConfig.manageColumnsParameters = userColumnPreferences;
	rm.grid.showGridTools(initReqPgNs.gridSelector, gridToolsConfig);


	$(initReqPgNs.gridSelector).jqGrid({
		url: rm.ajax.requestSvcUrl + (isInitiateRequestPage(rmPageLinkId) ? "GetAllInitiateRequests" : "GetAutogeneratedFromProposalRequests"),
		datatype: 'json',
		mtype: 'POST',
		ajaxGridOptions: { contentType: 'application/json; charset=utf-8' }, //MR: for loading the grid
		jsonReader: rm.grid.getJqGridJsonReader(),
		loadonce: false,
		shrinkToFit: false,
		autowidth: true,
		height: rm.ui.getMinPageHeight(),
		width: rm.ui.getContentContainerWidth(),
		forceFit: false,
		pager: '#listPager',
		multiselect: true,
		colModel: columnModel,
		viewsortcols: [true, 'vertical', true],
		viewrecords: true,
		sortname: 'Country',
		sortorder: 'asc',
		onPaging: function () { CheckGridRows(); },
		ondblClickRow: function (id) {
			initReqPgNs.hidePastRequestGrid();
			PopulateRequestDetails(id);
			//freezeColumnsAndBindInfo();
			//setTimeout(function () { $("#s4-workspace").scrollTop(0); }, 10);
		},
		afterInsertRow: function (rowid, rowdata, rowelem) {
			//Latest version of the grid does not use provided row id as the id in the DOM. Therefore, we need to change if after the row is loaded in DOM.
			$(initReqPgNs.gridSelector).find("#" + rowid).attr("id", rowdata.Id);
		},
		beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
		onSelectRow: function (id) {
			initReqPgNs.hidePastRequestGrid();
			if (!$.InitiateRequest._preventCheckEvent) {
				rm.grid.clearGridError(initReqPgNs.gridSelector, "Message");
			}
			CheckGridRows();
		},
		onSelectAll: function (rowIdxArray, sts) { CheckGridRows(); },
		gridComplete: function () {
			bindingObject.bindLabelQtip();
			rm.ui.notes.bindNotesIconClick();
			initReqPgNs.resetPage();
			freezeColumnsAndBindInfo();
		},
		serializeGridData: function (postData) {
			var data = { RmPageLink: rmPageLinkId };
			return rm.grid.serializeGridData(postData, data);
		},
		beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("listRequest"); },
		loadComplete: function (data) {
			rm.grid.rowData.attachAllRowsData(initReqPgNs.gridSelector, data);
			rm.grid.addTitlesOnIconColumn();
		},
		resizeStop: function (newWidth, columnIndex) {
			//Becasue grid allows multiselect, it adds a checkbox column as a first column. To find out the column index in the colModel, subtract 1.
			//Not required for grids that don't show checkbox column
			columnIndex -= 1;
			var dataGridColumnId = rm.grid.getDataGridColumnIdFromColIndexColModelAndUserPref(columnIndex, columnModel, userColumnPreferences);
			rm.grid.saveDataGridColumnWidthPreference(newWidth, getDateGridIdFromRmPageLink(rmPageLinkId), dataGridColumnId, initReqPgNs.gridSelector);
		}
	});
	$(initReqPgNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
};

function PopulateRequestDetails(id) {
	$("#isGenericDirtyCalculator").val('False');
	$("#isDirtyCalculator").val('False');
	$("#DynamicContent").empty();
	CleanAllError();
	Checkautoselect = true;
	$.InitiateRequest._isRequestinEditMode = true;
	var hiddenJson = rm.grid.rowData.getById(initReqPgNs.gridSelector, id);

	initReqPgNs.setSelectedRequestDetails(hiddenJson);

	initReqPgNs.getProjectDetailsByProjectId(hiddenJson.ProjectId)

	if (hiddenJson.ResourceTypeId == ResourceTypeName_E.Co_monitoring) {
		rm.ui.messages.addError(Resources.CoMonitoringRRTInvalidError);
		rm.grid.showErrorIconInMessageColumn(initReqPgNs.gridSelector, hiddenJson.id, 'Message', Resources.CoMonitoringRRTInvalidError);
		return;
	}
	$.validationHelper.GetCustomeMilestoneStatus(initReqPgNs.getRequestId(), "", false, false);
	if (rm.serviceCalls.isRequestValid(initReqPgNs.getRequestId(), true, GetRmPageLinkId())) {
		var protocolNumber = " - " + (hiddenJson.Protocol == "" ? "Not Available" : hiddenJson.Protocol);
		var projectCode = hiddenJson.ProjectCode + protocolNumber;
		$("#txtProjectName").val(projectCode);
		$.InitiateRequest._projectName = projectCode;

		$.InitiateRequest._selectedProjectID = hiddenJson.ProjectId;
		$.InitiateRequest._adhocCalcIdsToDelete.length = 0;
		var ProjectId = $.InitiateRequest._selectedProjectID;

		if (ProjectId != "-1") {
			$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
			//Fill Organization Dropdown based on ProjectId
			$.Dropdown.Organization(ProjectId);
			$('#ddlOrganization').val(hiddenJson.OrganizationId);
			//Fill OrgUnit Dropdown based on OrganizationId
			$.Dropdown.OrganizationalUnit(hiddenJson.OrganizationId);
			$('#ddlOrganizationalUnit').val(hiddenJson.RequestOrganizationalUnitId);
			//Fill ResourceType Dropdown based on OrganizationalUnitId
			$.Dropdown.ResourceType(hiddenJson.RequestOrganizationalUnitId);
			$('#ddlResourceType').val(hiddenJson.ResourceTypeId);

			var postData = { projectId: ProjectId };
			$.rm.Ajax_Request("GetInitiateRequestInfo", postData, function (result) {
				$.InitiateRequest._rowEdit = true;
				DrawMe(false);
				$.InitiateRequest._initiateRequestJSON = result;
				RunMethod(objPageManager, "GetCountryByResourceType");

				var selectedResourceType = ResourceTypeDetails[hiddenJson.ResourceTypeId];
				if (qipOtherCalculator) {
					qipOtherCalculator.regionId = hiddenJson.RegionId;
					qipOtherCalculator.countryId = hiddenJson.CountryId;
					qipOtherCalculator.organizationId = hiddenJson.OrganizationId;
					qipOtherCalculator.getRequestStopDateFromUi = initReqPgNs.getStopDate;
					qipOtherCalculator.getCountryIdForFteCalculation = initReqPgNs.getCountryId;
					qipOtherCalculator.getJobRoleIdForFteCalculation = function () { return selectedResourceType.JobRoleId; };
				}

				if (calculatorHelper) {
					calculatorHelper.getRequestStopDateFromUi = initReqPgNs.getStopDate;
				}

				if (genericCalculator) {
					genericCalculator.getCountryIdForFteCalculation = initReqPgNs.getCountryId;
					genericCalculator.getJobRoleIdForFteCalculation = function () { return selectedResourceType.JobRoleId; };
				}

				var rowData = rm.grid.rowData.getById(initReqPgNs.gridSelector, id);
				$("#ddlOrganization").val(hiddenJson.OrganizationId);
				$("#ddlCountry").val(hiddenJson.CountryId);
				RunMethod(objPageManager, "GetSite", objPageManager);
				RunMethod(objPageManager, "SetCountryRegion", objPageManager);

				if (selectedResourceType.ShowSiteCountBySiteStatus) {
					$(initReqPgNs.divSiteCountByStatusSelector).show();
					ucscbsNs.render(hiddenJson.ProjectId, hiddenJson.CountryId, true);
				}

				$.InitiateRequest._siteId = hiddenJson.SiteId;
				$.InitiateRequest._projectCode = hiddenJson.ProjectId;
				$("#ddlSiteId").val(hiddenJson.SiteId);
				$("#txtStartDate").val(rowData.StartDate);
				$("#txtStopDate").val(rowData.StopDate);
				$("#txtNeedByDate").val(rowData.NeedByDate);
				$("#txtIMDate").val(rowData.IMDate);
				$(initReqPgNs.txtTotalSitesSelector).val(rowData.TotalSites);
				$("#lblResourceName").html(hiddenJson.ProposalResource == "" ? "N/A" : hiddenJson.ProposalResource);
				$("#txtCRATrainingDate").val(rowData.CRADate);
				$(initReqPgNs.txtProposalFteSelector).val(hiddenJson.FTE);

				RunMethod(objPageManager, "SetStartStopDateImage", hiddenJson, objPageManager);
				var connectedValues = RunMethod(objPageManager, "GetConnectedStartStopDateValues", initReqPgNs.getProjectDetailsByProjectId(hiddenJson.ProjectId));
				if (connectedValues) {
					$.InitiateRequest.SetConnectedStartStopDateAttributes(connectedValues.startDate, connectedValues.stopDate, connectedValues.imDate, connectedValues.craTrainingDate);
				}

				$.InitiateRequest._region = rowData.Region;
				$.InitiateRequest._program = rowData.Program;
				$.InitiateRequest._protocol = rowData.Protocol;
				$.InitiateRequest._sponsorSite = rowData.SponsorSiteName;
				$.InitiateRequest._piName = rowData.PrincipalInvestigator;
				$.InitiateRequest._requestLocation = rowData.Location;
				if (rowData.RequestBudgeted == "No") {
					$("#radioRequestBudgetedNo").attr("checked", true);
					$("#txtReason").val($.trim(rowData.Reason).replace("<PRE>", "").replace("</PRE>", "").replace("<pre>", "").replace("</pre>", "")); // replace PRE is the patch for IE to display text in multiline in textarea 
					$("#lblRemainingLength").html($.InitiateRequest._reasonMaxLength - $("#txtReason").get(0).value.length);
					$('.initiateFieldReason').show();
				}

				if (rowData.RequestBudgeted == "Yes") {
					$("#radioRequestBudgetedYes").attr("checked", true);
					$("#lblRemainingLength").empty();
					$('.initiateFieldReason').hide();
				}

				var requestBlindedValue = rowData.RequestBlinded;
				if (requestBlindedValue != "") {
					$("#radioblinded" + (requestBlindedValue == 'Blinded' ? 'No' : 'Yes'))[0].checked = true;
				}
				$("#txtDuration").val(hiddenJson.DurationTotalHours);
				$.InitiateRequest._requestLastModifiedOn = hiddenJson.RequestLastModifiedOn;
				$.InitiateRequest._attributeLastModifiedOn = hiddenJson.AttributeLastModifiedOn;
				$.InitiateRequest._projectLastModifiedOn = hiddenJson.ProjectLastModifiedOn;

				RunMethod(objPageManager, "SetCalculatorValues", hiddenJson.FTE, hiddenJson.TotalHours, hiddenJson.TotalHoursPerSite, hiddenJson.TotalSites, hiddenJson.TotalFTE, hiddenJson.MonthlyFTEPerSite);
				RunMethod(objPageManager, "ChangeFrameSize");
				RemoveGridRowSelecedClass();
				$("#" + id).addClass("ui-state-highlight");
				rm.validation.clearError($("#txtStartDate"));
				rm.validation.clearError($("#txtStopDate"));

				initReqPgNs.manageProposalImageVisibility($.Dropdown.GetSelectedProjectDetails().ExternalSource);
			}, false);
		}
		$("#InitiateRequestForm").removeClass("hideMe");
	}
	else {
		initReqPgNs.resetPage();
	}
	rm.ui.ribbon.delayedRefresh();
}

function ClearAllTextBox() {
	$("#txtSiteStatus").val("");
	$("#txtStartDate").val("");
	$("#txtStopDate").val("");
	$("#txtNeedByDate").val("");
	$("#txtIMDate").val("");
	$("#txtCRATrainingDate").val("");
	$("#txtDuration").val("");
	$("#txtReason").val("");
	$(initReqPgNs.txtTotalSitesSelector).val("");
	$(initReqPgNs.txtProposalFteSelector).val("");
	$(initReqPgNs.taNotesSelector).val("");
	$.SmallFTECalculator.ClearCalculator();
	$.GenericFTECalculator.ClearCalculator();
	$.Calculator.ClearCalculator();
	$.GenericFTECalculator._newGenericRowID = 0;
};

function ClearAll() {
	$("#ddlCountry").empty();
	$("#ddlSiteId").empty();
	$("#ddlVisitType").empty();
	$("#ddlPreferredRegion").empty();
	$("#ddlPreferredCountry").empty();
	$("#lblRemainingLength").html("250");
	$.Dropdown.ClearAssignCountry();
	ClearAllTextBox();
	$("input[type=radio]").attr("checked", false);
	$(".ms-entity-resolved").parent().text("");
	$("#divCalculator").empty();
	rm.validation.clearError($(initReqPgNs.txtProposalFteSelector));
};

function sort_by(field, reverse, primer) {
	var key = function (x) { return primer ? primer(x[field]) : x[field] };
	return function (a, b) {
		var A = key(a), B = key(b);
		return ((A < B) ? -1 : (A > B) ? +1 : 0) * [-1, 1][+!!reverse];
	}
};

ValidateEntry = function (Operation) {
	var isValid = true;

	if (objPageManager == undefined) {
		rm.validation.addError("#ddlResourceType", Resources.ResourceRequestTypeRequired);
		return false;
	}
	if (rm.date.isValidDate($("#txtStartDate").val(), false)) {
		rm.validation.clearError($("#txtStartDate"));
	}
	else {
		isValid = false;
	}
	if (rm.date.isValidDate($("#txtStopDate").val(), false)) {
		rm.validation.clearError($("#txtStopDate"));
	}
	else {
		isValid = false;
	}
	if ($("#lblRemainingLength").html() < 0) {
		rm.validation.addError($(this), "Maximum character limit: " + $.InitiateRequest._reasonMaxLength);
		isValid = false;
	}

	if ($.trim($(":input[id$=txtProjectName]").val()) == "") {
		rm.validation.addError("[id$=txtProjectName]", Resources.ProjectCodeRequired);
		$("#txtProjectName").focus();
		isValid = false;
	}

	var allInputs = $(".validateRange:visible");
	$.each(allInputs, function () { $.q.rangeValidate($(this)); });
	if ($(".FTE_Calculator").is(":visible") && $.Calculator) {
		$.Calculator.CalculateWeeklyHoursOrFteOnRibbonClick();
	}
	if (objPageManager != undefined) {
		RunMethod(objPageManager, "CleanError");
	}
	if ($("#divAccordionCalculator .q_validation_error:visible").size() > 0) {
		if (!$("#divCalculator").is(":visible")) {
			$("#divAccordionCalculator").accordion("option", "active", 0);
		}
		$("#divCalculator").show();
	}
	if (!RunMethod(objPageManager, "Validate")) { isValid = false; }
	if (!rm.customFields.areCustomFieldsValid($("#DynamicContent"))) { isValid = false; }

	if (!$.validationHelper.IsFormValid()) { isValid = false; }
	if (initReqPgNs.getResourceTypeId() == ResourceTypeName.SSV_Monitoring) {
		return isValid && rmCommon.ValidateSSVPerSite("#ddlSSVType", "[id$=__ssvPerSite]", "[id$=__phoneSsvPerSite]");
	}

	return isValid;
};

function RemoveGridRowSelecedClass() {
	rm.grid.uncheckAllGridRows(initReqPgNs.gridSelector);
	$("#listRequest tr").each(function () {
		$(this).removeClass("ui-state-highlight");
		$(this).attr('aria-selected', false);
		$('.cbox').attr('checked', false);
	});
};

CheckGridRows = function () {
	if ($.InitiateRequest.isRemoveButtonEnabled()) {
		$("#listRequest tr").each(function () {
			if ($(this).attr('aria-selected') == "false") {
				$(this).removeClass("ui-state-highlight");
			}
		});
		initReqPgNs.resetPage();
	}
	rm.ui.ribbon.refresh();
	rm.ui.messages.clearAllMessages();
};



SubmitAndAssignRequest = function () {
	makeSubmitAjaxCall("SubmitAndAssignToProposalResource", Resources.RequestSubmittedSuccessfully, Resources.FailedToSubmitRequest);
};

makeSubmitAjaxCall = function (serviceName, successMessage, failureMessage) {
	$.InitiateRequest._preventCheckEvent = true;

	var selectedrows = $(initReqPgNs.gridSelector).getGridParam('selarrrow');
	if (selectedrows.length == 0) {
		selectedrows[0] = rm.grid.getHighlightedRowId(initReqPgNs.gridSelector);
	}
	if (selectedrows.length == 0) {
		rm.ui.messages.addError(Resources.SelectRowToSubmit);
		return false;
	}
	$.validationHelper.GetCustomeMilestoneStatus(selectedrows.join(","), "", false, false);

	if (!$.validationHelper.isAnyMilestoneDeactivated) {
		var postData = { requestIds: selectedrows };
		$.rm.Ajax_Request(serviceName, postData, function (data) { handleServiceResponse(data, successMessage, failureMessage) });
	}
};

handleServiceResponse = function (data, successMessage, failureMessage) {
	var isSuccess = true;
	var invalidRequest = false;
	var errorOccured = false;
	data.sort(self.sort_by('IsSuccessful', false, function (a) { return a }));

	$.each(data, function (index, request) {
		if (request.IsSuccessful) {
			rm.grid.removeRow(initReqPgNs.gridSelector, request.EntityId);
		}
		else if (request.TierDisabled) {
			invalidRequest = true;
			isSuccess = false;
			rm.grid.showErrorIconInMessageColumn(initReqPgNs.gridSelector, request.EntityId, "Message", request.Message);
		}
		else {
			isSuccess = false;
			errorOccured = true;
			rm.grid.showErrorIconInMessageColumn(initReqPgNs.gridSelector, request.EntityId, "Message", request.Message);
		}
	});

	if (isSuccess) {
		rm.ui.messages.clearAllMessages();
		RemoveGridRowSelecedClass();
		rm.ui.messages.showSuccess(successMessage);
	}
	else {
		if (invalidRequest) {
			alert(Resources.InvalidRequestSubmitErrorAlert);
		}
		if (errorOccured) {
			rm.ui.messages.addError(failureMessage);
		}
	}

	initReqPgNs.resetPage();
	$.Calculator._interimFrequencyEnabled = false;
	$.GenericFTECalculator._interimFrequencyEnabled = false;
	$("#divAccordionCalculator").hide();
	rm.ui.ribbon.refresh();
};
isInitiateRequestPage = function (rmPageLinkId) { return (rmPageLinkId == RmPageLink_E.InitiateNewRequests || rmPageLinkId == RmPageLink_E.MonitoringSsvAttributesAllZero_All_Initiate); };

$.Dropdown = {
	IsEcdProject: function () {
		return $.Dropdown.GetSelectedProjectDetails().OrganizationalUnitId == OrganizationalUnit_E.Early_Clinical_Development
	},

	fill: function (selector, data, keyName, valueName, selectedValue, addSelectAsFirstItem, firstItem) {
		if (addSelectAsFirstItem != false) {
			$(selector).empty().append($("<option>").val("-1").html("--Select--"));
		}
		else {
			$(selector).empty().append($("<option>").val("0").html(firstItem));
		}

		if (data) {
			$.each(data, function (index, element) {
				$(selector).append($("<option>", (element[keyName] == selectedValue) ? { "selected": "selected" } : {}).val(element[keyName]).html(element[valueName]));
			});
		}
	},

	GetSelectedProjectDetails: function () {
		return initReqPgNs.getProjectDetailsByProjectId($.InitiateRequest._selectedProjectID);
	},

	//AB : Added to map the organization on UI
	Organization: function (projectId) {
		initReqPgNs.organizationOrganizationalUnitRRTData = rm.serviceCalls.getAllOrganizationOrganizationalUnitRRTListForUser(projectId, false);
		$.Dropdown.fill("#ddlOrganization", initReqPgNs.organizationOrganizationalUnitRRTData, "organizationId", "organizationName");
	},

	OrganizationalUnit: function (organizationId) {

		var organizationalUnitList = rm.serviceCalls.getAllOrganizationalUnitForOrganizationalId(organizationId, initReqPgNs.organizationOrganizationalUnitRRTData);
		$.Dropdown.fill("#ddlOrganizationalUnit", organizationalUnitList, "organizationalUnitId", "organizationalUnitName", -1, false, "Any");
		//If there is no OrganizationalUnit or if the OrganizationalUnitID is 0 or if OrganizationalUnitList has only one value
		if (organizationalUnitList.length <= 1) {
			$("#ddlOrganizationalUnit").val($("#ddlOrganizationalUnit option").eq(0).val());
			$("#ddlOrganizationalUnit").trigger("change");
			$("#ddlOrganizationalUnit").hide();
			$("#lblOrgUnit").hide();
		}
		else {
			$("#ddlOrganizationalUnit").show();
			$("#lblOrgUnit").show();
		}
	},

	Country: function () {
		var projectItem = initReqPgNs.getProjectFromLookupArrayByProjectCodeProtocol($("#txtProjectName").val())

		if (projectItem != null) {
			$.InitiateRequest._selectedProjectID = projectItem.id;
			if ($.InitiateRequest._initiateRequestJSON == null || $.InitiateRequest._initiateRequestJSON.ProjectId != $.InitiateRequest._selectedProjectID) {
				var postData = { projectId: $.InitiateRequest._selectedProjectID };
				$.rm.Ajax_Request("GetInitiateRequestInfo", postData, function (data) {
					$.InitiateRequest._initiateRequestJSON = data;
					RunMethod(objPageManager, "GetCountryByResourceType");
				}, false);
			}
			else {
				setTimeout(function () { RunMethod(objPageManager, "GetCountryByResourceType"); }, 50);
			}
		}
	},

	AddItemsToDropdownByIdName: function (data) {
		if (data != undefined) { $.Dropdown.Fill("#ddlCountry", data, "Id Name"); }
	},

	CountryFromJSON: function (data) {
		if (data != undefined) { $.Dropdown.Fill("#ddlCountry", data, "CountryId CountryName"); }
	},

	PreferredRegion: function () {
		$.rm.Ajax_Utility("Geography/GetRegions", "", function (data) {
			$.Dropdown.Fill("#ddlPreferredRegion", $.parseJSON(data), "Id Name");
		}, true, true);
	},

	AssignRegion: function () {
		$("#spanAssignedRegionList").html("Select all that apply").attr("title", "Select all that apply")

		var postData = { projectId: $.InitiateRequest._selectedProjectID };

		$.rm.Ajax_Request("GetAssignedRegions", postData, function (data) {
			$.Dropdown.BindAssignedRegion($.parseJSON(data));
		}, false);
	},

	BindAssignedCountry: function (data) {
		$('#assignedCountryList').dropdownCountry({
			items: data,
			itemClick: function (key, value, isChecked, regionId) {
				$.InitiateRequest._countryIds = "";
				$.InitiateRequest._countryRegions = "";
				var countryList = "Select all that apply";
				$.each(this.items, function (k, v) {
					if (v.isChecked && v.key != key) {
						if ($.InitiateRequest._countryIds != "") {
							$.InitiateRequest._countryIds += "|";
							countryList += ", ";
							$.InitiateRequest._countryRegions += ",";
						}
						$.InitiateRequest._countryIds += v.key;
						countryList = countryList == "Select all that apply" ? v.value : countryList + v.value;
						$.InitiateRequest._countryRegions += v.regionId + "|" + v.key + "|" + v.value;
					}
				});
				if (isChecked) {
					if ($.InitiateRequest._countryIds != "") {
						$.InitiateRequest._countryIds += "|";
						countryList += ", ";
						$.InitiateRequest._countryRegions += ",";
					}
					$.InitiateRequest._countryIds += key;
					countryList = countryList == "Select all that apply" ? value : countryList + value;
					$.InitiateRequest._countryRegions += regionId + "|" + key + "|" + value;
				}
				$("#spanAssignedCountryList").html(countryList.length > 39 ? countryList.substring(0, 42) + "..." : countryList);
				$("#spanAssignedCountryList").attr("title", countryList);
			},
			controlId: "AssignedCountryList"
		});

		if ($("#spanAssignedRegionList").html() == "Select all that apply") {
			$("#spanAssignedCountryList").empty();
			$("#spanAssignedCountryList").attr("title", "");
		}
		else if ($.InitiateRequest._countryRegions == "") {
			$("#spanAssignedCountryList").html("Select all that apply");
			$("#spanAssignedCountryList").attr("title", "Select all that apply");
		}
	},

	BindAssignedRegion: function (data) {
		$('#assignedRegionList').dropdown({
			items: data,
			itemClick: function (key, value, isChecked) {
				var regionsList = "Select all that apply";
				$.InitiateRequest._regionIds = "";
				$.each(this.items, function (k, v) {
					if (v.isChecked && v.key != key) {
						if ($.InitiateRequest._regionIds != "") {
							$.InitiateRequest._regionIds += ",";
							regionsList += ", ";
						}
						$.InitiateRequest._regionIds += v.key;
						regionsList = regionsList == "Select all that apply" ? v.value : regionsList + v.value;
					}
				});
				if (isChecked) {
					if ($.InitiateRequest._regionIds != "") {
						$.InitiateRequest._regionIds += ",";
						regionsList += ", ";
					}
					$.InitiateRequest._regionIds += key;
					regionsList = regionsList == "Select all that apply" ? value : regionsList + value;
				}

				$("#spanAssignedRegionList").html(regionsList.length > 39 ? regionsList.substring(0, 42) + "..." : regionsList);
				$("#spanAssignedRegionList").attr("title", regionsList);

				//update variable countryIds & tooltip
				var countryList = "";
				if ($.InitiateRequest._countryRegions != "") {
					var arrarCountry = $.InitiateRequest._countryRegions.split(',');
					$.InitiateRequest._countryIds = "";
					$.InitiateRequest._countryRegions = "";
					for (var i = 0; i < arrarCountry.length; i++) {
						if (key != arrarCountry[i].split("|")[0]) // index 0 is regionid key
						{
							if ($.InitiateRequest._countryIds != "") {
								$.InitiateRequest._countryIds += "|";
								countryList += ", ";
								$.InitiateRequest._countryRegions += ",";
							}
							$.InitiateRequest._countryIds += arrarCountry[i].split("|")[1];  // index 1 is countryid key
							countryList += arrarCountry[i].split("|")[2]; // index 2 is name of the country
							$.InitiateRequest._countryRegions += arrarCountry[i].split("|")[0] + "|" + arrarCountry[i].split("|")[1] + "|" + arrarCountry[i].split("|")[2];
						}
					}
				}
				if (countryList == "") {
					$.InitiateRequest._countryIds = "";
					$.InitiateRequest._countryRegions = "";
				}
				$("#spanAssignedCountryList").html(countryList.length > 39 ? countryList.substring(0, 42) + "..." : countryList);
				$("#spanAssignedCountryList").attr("title", countryList);
			},
			controlId: "AssignedRegionList"
		});
	},

	GetAssignedRegionCountry: function (requestId) {
		var postData =
		{
			requestId: requestId,
			projectId: initReqPgNs.getProjectId()
		};

		$.rm.Ajax_Request("GetRegionCountryByRequestId", postData, function (data) {
			$.Dropdown.BindAssignedRegion($.parseJSON(data).RegionList);
			$.Dropdown.BindAssignedCountry($.parseJSON(data).CountryList);

			//update tooltip
			var regionsList = "Select all that apply";
			$.InitiateRequest._regionIds = "";
			$.each($.parseJSON(data).RegionList, function (k, v) {
				if (v.isChecked) {
					if ($.InitiateRequest._regionIds != "") {
						$.InitiateRequest._regionIds += ",";
						regionsList += ", ";
					}
					$.InitiateRequest._regionIds += v.key;
					regionsList = regionsList == "Select all that apply" ? v.value : regionsList + v.value;
				}
			});
			$("#spanAssignedRegionList").html(regionsList.length > 39 ? regionsList.substring(0, 42) + "..." : regionsList);
			$("#spanAssignedRegionList").attr("title", regionsList);

			$.InitiateRequest._countryIds = "";
			$.InitiateRequest._countryRegions = "";
			var countryList = "Select all that apply";
			$.each($.parseJSON(data).CountryList, function (k, v) {
				if (v.isChecked) {
					if ($.InitiateRequest._countryIds != "") {
						$.InitiateRequest._countryIds += "|";
						countryList += ", ";
						$.InitiateRequest._countryRegions += ",";
					}
					$.InitiateRequest._countryIds += v.key;
					countryList = countryList == "Select all that apply" ? v.value : countryList + v.value;
					$.InitiateRequest._countryRegions += v.regionId + "|" + v.key + "|" + v.value;
				}
			});
			$("#spanAssignedCountryList").html(countryList.length > 39 ? countryList.substring(0, 42) + "..." : countryList);
			$("#spanAssignedCountryList").attr("title", countryList);

			RunMethod(objPageManager, "CountryRegion"); // Populate CountryRegion for CRS
		}, false);
	},

	ResourceType: function (organizationalUnitId) {
		var RRTsForOrganizationalUnit = [];
		var organizationalUnitList = rm.serviceCalls.getAllOrganizationalUnitForOrganizationalId($("#ddlOrganization").val(), initReqPgNs.organizationOrganizationalUnitRRTData);
		if (organizationalUnitId == initReqPgNs.anyOrganizationalUnit || organizationalUnitId == null) {
			//Whenever OrganizationUnit Value is null , then pick RRTs from all orgUnits and display in the RRT DDL
			$.each(organizationalUnitList, function (key, orgUnit) {
				$.each(orgUnit.resourceTypeKVList, function (key, resType) {
					var rrt = { resourceTypeId: resType.resourceTypeId, resourceTypeName: resType.resourceTypeName };
					RRTsForOrganizationalUnit.push(rrt);
				});
			});
			//Sort the RRT List
			RRTsForOrganizationalUnit = RRTsForOrganizationalUnit.sort(function (a, b) {
				return a.resourceTypeName.localeCompare(b.resourceTypeName);
			});
		}
		else {
			RRTsForOrganizationalUnit = $.map(organizationalUnitList, function (element, index) { if (element.organizationalUnitId == organizationalUnitId) return element.resourceTypeKVList });
		}
		RRTsForOrganizationalUnit = rmCommon.arrUniqueFilterResourceType(RRTsForOrganizationalUnit);
		$.Dropdown.fill("#ddlResourceType", RRTsForOrganizationalUnit, "resourceTypeId", "resourceTypeName");
	},

	SiteFromJSON: function (data) {
		if (data != undefined) {
			$.Dropdown.Fill("#ddlSiteId", data, "SiteId SponsorPICity");
		}
	},

	PreferredCountry: function () {
		var preferredRegion = $("#ddlPreferredRegion").val();
		if (preferredRegion != "-1") {
			var postData =
			{
				regionIds: preferredRegion
			};

			$.rm.Ajax_Utility("GetAllCountriesByRegion", postData, function (data) {
				$.Dropdown.Fill("#ddlPreferredCountry", data, "key value");
				setTimeout(function () {
					if ($.InitiateRequest.OnCountryPopulate) {
						$.InitiateRequest.OnCountryPopulate();
					}
				}, 100);
			}, true, true);
		}
	},

	CountryRegion: function (countryIds, selected) {
		$('.initiateFieldCountryRegion').show();
		$.rm.Ajax_Request("GetCountryRegions?countryIds=" + countryIds, {}, function (data) {
			$.Dropdown.Fill("#ddlCountryRegion", data, "Id Name", selected);
		}, true);
	},

	CountryRegionCountryName: function (countryIds, selected) {
		$('.initiateFieldCountryRegion').show();
		$.rm.Ajax_Request("GetCountryRegionCountryName?countryIds=" + countryIds, {}, function (data) {
			$.Dropdown.Fill("#ddlCountryRegion", data, "Id Name", selected);
		}, true);
	},

	ClearAssignCountry: function () {
		$.Dropdown.BindAssignedCountry($.parseJSON("{}"));
		$("#spanAssignedCountryList").empty();
		$("#spanAssignedCountryList").attr("title", "");
		$.InitiateRequest._regionIds = "";
		$.InitiateRequest._countryIds = "";
		$.InitiateRequest._countryRegions = "";
	},

	SSVType: function () {
		if ($.InitiateRequest._initiateRequestJSON != null) {
			$.Dropdown.Fill("#ddlSSVType", $.InitiateRequest._initiateRequestJSON.SSVTypeList, "Key Value");
		}
	},

	GetVisitType: function (resourceTypeId, isAsync) {
		var postData =
		{
			resourceTypeName: resourceTypeId
		};
		$.rm.Ajax_Utility("GetSiteVisitTypeByResourceType", postData, function (data) {
			$("#txtProjectName").data("VisitTypeList", data);
		}, true, isAsync);
	},

	VisitType: function (countryId) {
		var data = $("#txtProjectName").data("VisitTypeList");
		$("#ddlVisitType").empty().append($("<option>").val("-1").html("--Select--"));
		if (data != undefined) {
			$.each(data, function (index, element) {
				if (element.CountryId == null || element.CountryId == countryId) {
					$("#ddlVisitType").append($("<option>").val(element.SiteVisitTypeId).html(element.SiteVisitTypeName));
				}
			});
		}
	},

	EmptyDropdown: function (selector) {
		$(selector).empty().append($("<option>").val("-1").html("--Select--"));
	},

	Fill: function (selector, data, keyValueName, selected, defaultRequired) {
		if (defaultRequired != false) {
			$(selector).empty().append($("<option>").val("-1").html("--Select--"));
		}
		else {
			$(selector).empty();
		}
		$.each(data, function (index, element) {
			switch (keyValueName) {
				case "Key Value":
					{
						if (element.Key == selected) {
							$(selector).append($("<option selected>").val(element.Key).html(element.Value));
						}
						else {
							$(selector).append($("<option>").val(element.Key).html(element.Value));
						}
						break;
					}
				case "key value":
					{
						if (element.key == selected) {
							$(selector).append($("<option selected>").val(element.key).html(element.value));
						}
						else {
							$(selector).append($("<option>").val(element.key).html(element.value));
						}
						break;
					}
				case "Id ProjectCode":
					{
						var protocolNumber = " - " + (element.ProtocolNumber == "" ? "Not Available" : element.ProtocolNumber);
						if (element.Id == selected) {
							$(selector).append($("<option selected>").val(element.Id).html(element.ProjectCode + protocolNumber));
						}
						else {
							$(selector).append($("<option>").val(element.Id).html(element.ProjectCode + protocolNumber));
						}
						break;
					}
				case "SiteId SponsorPICity":
					{
						if (element.SiteId == selected) {
							$(selector).append($("<option selected>").val(element.SiteId).html(element.SponsorPICity));
						}
						else {
							$(selector).append($("<option>").val(element.SiteId).html(element.SponsorPICity));
						}
						break;
					}
				case "CountryId CountryName":
					{
						if (element.CountryId == selected) {
							$(selector).append($("<option selected>").val(element.CountryId).html(element.CountryName));
						}
						else {
							$(selector).append($("<option>").val(element.CountryId).html(element.CountryName));
						}
						break;
					}
				case "Id Name":
					{
						if (element.Id == selected) {
							$(selector).append($("<option selected>").val(element.Id).html(element.Name));
						}
						else {
							$(selector).append($("<option>").val(element.Id).html(element.Name));
						}
						break;
					}
				default:
			}
		});
	},

	IsValidationRequired: function (ResourceTypeid) {
		var Required = false;
		if (ResourceTypeid == 22 || ResourceTypeid == 5 || ResourceTypeid == 7 || ResourceTypeid == 18 || ResourceTypeid == 27 || ResourceTypeid == 28 || ResourceTypeid == 31) {
			Required = true;
		}
		return Required;
	}
};