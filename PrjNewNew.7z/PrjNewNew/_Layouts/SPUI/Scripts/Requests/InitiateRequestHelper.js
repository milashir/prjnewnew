﻿///<reference path="../Requests/InitiateRequest.js"/>
/// <reference path="../common/FTECalculator.js"/>
/// <reference path="../common/SmallFTECalculator.js"/>
var _visitType = {
	Co_monitoring_Pharmacy: 9,
	Telephone_Training_Booster: 30,
	Pharmacy_Visit_Initiation: 62,
	Pharmacy_Visit_Interim: 63,
	Pharmacy_Visit_Closeout: 64
};
$.InitiateRequest = {
	OnCountryPopulate: function () { },
	_preventCheckEvent: false,
	_operationRemove: false,
	_reasonMaxLength: 250,
	_rowEdit: false,
	_projectCode: -1,
	_resourceRequestType: -1,
	_PageManager: "",
	_PageManagerID: -1,
	_siteId: -1,
	_piName: "",
	_sponsorSite: "",
	_SSVType: -1,
	_requestBudgeted: "",
	_requestUnblinded: "",
	_reason: "",
	_duration: -1,
	_visitType: -1,
	_preferredRegion: -1,
	_initiateRequestJSON: null,
	_regionId: -1,
	_region: null,
	_program: null,
	_protocol: null,
	_requestLocation: "", // location is reserve word so i am using requestLocation.
	_regionIds: "",
	_countryIds: "",
	_countryRegions: "",
	_countryRegion: -1,
	_countryRegionName: "",
	_siteStatus: "",
	_countrySites: "",
	_removeButtonEnabled: false,
	_isDisconnectedFTECalculator: false,
	_staticInitiateCalculator: "",
	_adhocInitiateCalculator: "",
	_adhocCalcIdsToDelete: new Array(),
	_requestLastModifiedOn: 0,
	_attributeLastModifiedOn: 0,
	_projectLastModifiedOn: 0,
	_selectedProjectID: -1,
	_organizationID: -1,
	_projectName: "",
	_isAnyMilestoneDeactivated: false,
	_resourceTransitionTime: 0,
	_DefaultToMilestoneId: 0,
	_DefaultFromMilestoneId: 0,
	_isRequestinEditMode: false,
	_isModifyRequest: false,
	_allCountries: null,
	_siteCountriesByProject: {},
	GetAllCountries: function () {
		if ($.InitiateRequest._allCountries == null) {
			$.rm.Ajax_Utility("GetCountryList", {}, function (data) { $.InitiateRequest._allCountries = data; }, false, false);
		}
		return $.InitiateRequest._allCountries;
	},

	GetCountriesFromSiteAddressByProjectId: function (projectId) {
		if ($.InitiateRequest._siteCountriesByProject[projectId] == null) {
			$.rm.Ajax_RequestSynchronous("GetCountriesFromSiteAddressByProjectId", { projectId: projectId }, function (data) { $.InitiateRequest._siteCountriesByProject[projectId] = data; }, false);
		}
		return $.InitiateRequest._siteCountriesByProject[projectId];
	},
	isAddButtonEnabled: function () {
		var orgId = initReqPgNs.getOrganizationIdFromUi();
		return initReqPgNs.isInEditMode() || (orgId != "" && orgId != "-1");
	},

	isUpdateButtonEnabled: function () { return initReqPgNs.isInEditMode() ? initReqPgNs.isDirty() || $("#isDirtyCalculator").val() == 'True' || $("#isGenericDirtyCalculator").val() == 'True' : false; },

	isInterimFrequencyButtonEnabled: function () {
		if ($.InitiateRequest._PageManager != undefined && $.InitiateRequest._PageManager == "Generic_PageManager") {
			return $.GenericFTECalculator.isInterimFrequencyButtonEnabled();
		}
		else {
			return $.Calculator.isInterimFrequencyButtonEnabled();
		}
	},

	isCancelUpdateButtonEnabled: function () { return initReqPgNs.isInEditMode(); },

	isViewProjectDetailsButtonEnabled: function () {
		if ($(initReqPgNs.txtProjectNameSelector).val() != "") {
			var projectItem = null;
			if (initReqPgNs.projectLookupArray != null) {
				$.each(initReqPgNs.projectLookupArray, function (index, item) {
					if (item.value == $(initReqPgNs.txtProjectNameSelector).val()) {
						projectItem = item;
						return false;
					}
				});
			}
			return projectItem != null;
		}
	},

	isViewProjectMilestonesButtonEnabled: function () {
		if ($(initReqPgNs.txtProjectNameSelector).val() != "") {
			var projectItem = null;
			if (initReqPgNs.projectLookupArray != null) {
				$.each(initReqPgNs.projectLookupArray, function (index, item) {
					if (item.value == $(initReqPgNs.txtProjectNameSelector).val()) {
						projectItem = item;
						return false;
					}
				});
			}
			return projectItem != null;
		}
	},
	isRemoveButtonEnabled: function () {
		var hasSelectedRows = rm.grid.hasRowsSelected(initReqPgNs.gridSelector);

		if (GetRmPageLinkId() == RmPageLink_E.InitiateNewRequests) {
			return hasSelectedRows;
		}
		else if (GetRmPageLinkId() == RmPageLink_E.AwardedProposalRequest) {
			var highlightedRows = rm.grid.getHighlightedRowId(initReqPgNs.gridSelector);
			return hasSelectedRows || (highlightedRows && highlightedRows.length > 0);
		}
	},

	isSubmitAndAssignButtonEnabled: function () {
		var isEnabled = false;
		var selectedRequestIds = $("#listRequest").getGridParam('selarrrow');

		if (selectedRequestIds) {
			if (selectedRequestIds.length != 0) {
				$.each(selectedRequestIds, function (index, requestId) {
					var hiddenJson = rm.grid.rowData.getById("#listRequest", requestId);
					if (hiddenJson.ProposalResource != "") {
						isEnabled = true;
						return false;
					}
				});
			}

			var selectedRequestIds2 = new Array();
			if (selectedRequestIds.length == 0 && (rm.grid.getHighlightedRowId("#listRequest") != undefined)) {
				selectedRequestIds2[0] = rm.grid.getHighlightedRowId("#listRequest");
			}
			$.each(selectedRequestIds2, function (index, requestId) {
				var hiddenJson = rm.grid.rowData.getById("#listRequest", requestId);
				if (hiddenJson.ProposalResource != "") {
					isEnabled = true;
					return false;
				}
			});

		}
		return isEnabled;
	},

	IsModifyButtonEnabled: function () {
		return rm.grid.hasSingleRowSelected("#listRequest");
		return false;
	},

	ModifyRequest: function () {
		var id = $("#listRequest").getGridParam('selarrrow');
		PopulateRequestDetails(id[0]);
	},

	ClearConnectDisconnectImages: function () {
		$("#txtStartDate").parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
		$("#txtStopDate").parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
		$("#txtIMDate").parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
		$("#txtCRATrainingDate").parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
	},

	SetConnectedStartStopDateAttributes: function (startDate, stopDate, imDate, craTrainingDate) {
		$("#txtStartDate").attr("connectedDateValue", startDate);
		$("#txtStopDate").attr("connectedDateValue", stopDate);
		$("#txtIMDate").attr("connectedDateValue", imDate);
		$("#txtCRATrainingDate").attr("connectedDateValue", craTrainingDate);
	},

	HandleStartStopDateChange: function () {
		element = this;
		var connectedAttr = $(element).attr("connectedDateValue");
		if (connectedAttr || connectedAttr == "") {
			if (connectedAttr == $(element).val()) {
				$.InitiateRequest.AppendConnectedImage($(element));
			}
			else {
				$.InitiateRequest.AppendDisconnectedImage($(element));
			}
		}
	},

	AppendConnectedImage: function (textBoxObject) {
		textBoxObject.parent().find(".disconnectedFromCountry,.connectedToCountry,.connectedToPpm,.disconnectedFromPpm").remove();
		if (!initReqPgNs.isProposalProjectSelected()) {
			var connectedImage = $("<img>").attr("class", "connectedToPpm marginLeft35").attr("src", "/_layouts/SPUI/images/ppmLinkIcon.png");
			textBoxObject.parent().append(connectedImage);
		}
		CalculateNeedByDate();
		ShowConnectDisconnectPPMIcon();
	},

	AppendDisconnectedImage: function (textBoxObject) {
		textBoxObject.parent().find(".disconnectedFromCountry,.connectedToCountry,.connectedToPpm,.disconnectedFromPpm").remove();
		if (!initReqPgNs.isProposalProjectSelected()) {
			var disconnectedImageHtml;
			if ($.Calculator._PageManager == "Global_RSUL_PageManager") {
				disconnectedImageHtml = "<img src='/_layouts/SPUI/images/ppmUnLinkIcon.png' class='disconnectedFromPpm marginLeft35 cursorHand' onclick='$.InitiateRequest.ConnectToPpmDate(\"" + textBoxObject.attr("id") + "\"); $.InitiateRequest.calculateTotalHoursOnImageClick(\"" + textBoxObject.attr("id") + "\"); return false;' title='Reconnect to PPM milestone date' >";
			}
			else {
				disconnectedImageHtml = "<img src='/_layouts/SPUI/images/ppmUnLinkIcon.png' class='disconnectedFromPpm marginLeft35 cursorHand' onclick='$.InitiateRequest.ConnectToPpmDate(\"" + textBoxObject.attr("id") + "\"); return false;' title='Reconnect to PPM milestone date' >";
			}
			textBoxObject.parent().append(disconnectedImageHtml);
		}
		ShowConnectDisconnectPPMIcon();
	},

	ConnectToPpmDate: function (controlId) {
		var control = $("#" + controlId);
		if (control.attr("connectedDateValue") != "") {
			control.val(control.attr("connectedDateValue"));
			$.InitiateRequest.AppendConnectedImage(control);
			rm.validation.clearError($(control));
			SetCancelUpdateButtonEnabled();
			updateRequestStopDateFromComputedRequestMilestone($('#ddlResourceType').val(), 0);
		}
		else {
			alert("You are not able to connect to PPM milestone date since the PPM milestone date is not available.");
		}
	},

	HandleStartStopDateChangeCountry: function () {
		element = this;
		var connectedAttr = $(element).attr("connectedDateValue");
		if (connectedAttr || connectedAttr == "") {
			if (connectedAttr == $(element).val()) {
				$.InitiateRequest.AppendConnectedCountryImage($(element));
			}
			else {
				$.InitiateRequest.AppendDisconnectedCountryImage($(element));
			}
		}
	},

	AppendConnectedCountryImage: function (textBoxObject) {
		textBoxObject.parent().find(".disconnectedFromCountry,.connectedToCountry,.connectedToPpm,.disconnectedFromPpm").remove();
		var connectedImage = $("<img>").attr("class", "connectedToCountry marginLeft35").attr("src", "/_layouts/SPUI/images/conncted.png");
		textBoxObject.parent().append(connectedImage);
		CalculateNeedByDate();
	},

	AppendDisconnectedCountryImage: function (textBoxObject) {
		var titleText = 'Reconnect to Country milestone date.';
		if ($('#ddlResourceType').val() == ResourceTypeName.DTESite_Monitoring ||
			$('#ddlResourceType').val() == ResourceTypeName.Standard_Monitoring ||
			$('#ddlResourceType').val() == ResourceTypeName.DTEPharmacy_Monitoring ||
			$('#ddlResourceType').val() == ResourceTypeName.Pharmacy_Monitoring ||
			$('#ddlResourceType').val() == ResourceTypeName.iCRA_Monitoring) {
			if (textBoxObject.data().datepicker.id.endsWith('txtStopDate')) {
				titleText = 'Reconnect to calculated Site COV date.';
			}
			else {
				if ($('#ddlResourceType').val() == ResourceTypeName.DTESite_Monitoring || $('#ddlResourceType').val() == ResourceTypeName.Standard_Monitoring) {
					titleText = 'Reconnect to calculated Site Selection date.';
				}
				else {
					titleText = 'Reconnect to calculated Site SIV date.';
				}
			}
		}

		textBoxObject.parent().find(".disconnectedFromCountry,.connectedToCountry,.connectedToPpm,.disconnectedFromPpm").remove();
		var disconnectedImageHtml = "<img src='/_layouts/SPUI/images/reconnect.png' class='disconnectedFromCountry marginLeft35 cursorHand' onclick='$.InitiateRequest.ConnectToCountryDate(\"" + textBoxObject.attr("id") + "\"); return false;' title='" + titleText + "' >";
		textBoxObject.parent().append(disconnectedImageHtml);
	},

	ConnectToCountryDate: function (controlId) {
		var control = $("#" + controlId);
		control.val(control.attr("connectedDateValue"));
		$.InitiateRequest.AppendConnectedCountryImage(control);
		rm.validation.clearError($(control));
		if ($.InitiateRequest._isModifyRequest) {
			SetCancelUpdateButtonEnabled();
		}
	},

	SetDateImage: function (connectedValue, selector) {
		if (connectedValue == selector.val()) {
			$.InitiateRequest.AppendConnectedImage(selector);
		}
		else {
			$.InitiateRequest.AppendDisconnectedImage(selector);
		}
	},

	SetDateCountryImage: function (connectedValue, selector) {
		if (connectedValue == selector.val()) {
			$.InitiateRequest.AppendConnectedCountryImage(selector);
		}
		else {
			$.InitiateRequest.AppendDisconnectedCountryImage(selector);
		}
	},

	calculateTotalHoursOnImageClick: function (controlId) {
		$("#" + controlId).trigger("change");
	},

	HandleInterimFrequencyClick: function () {
		if ($.Calculator._PageManager == "Standard_Monitoring_PageManager") {
			calculatorGroup.addAdhocCalculator(CalculatorGroup_E.MonitoringCalculator, false);
		}
		else if ($.Calculator._PageManager == "DTESite_Monitoring_PageManager") {
			calculatorGroup.addAdhocCalculator(CalculatorGroup_E.DTEMonitoringCalculator, false);
		}
		else if ($.Calculator._PageManager == "Pharmacy_Monitoring_PageManager") {
			calculatorGroup.addAdhocCalculator(CalculatorGroup_E.PharmacyCalculator, false);
		}
		else if ($.Calculator._PageManager == "DTEPharmacy_Monitoring_PageManager") {
			calculatorGroup.addAdhocCalculator(CalculatorGroup_E.DTEPharmacyCalculator, false);
		}
		else if ($.Calculator._PageManager == "iCRA_Monitoring_PageManager") {
			calculatorGroup.addAdhocCalculator(CalculatorGroup_E.ICraCalculator, false);
		}
		else if ($.Calculator._PageManager == "Generic_PageManager") {
			$.GenericFTECalculator.InterimFrequency();
		}
		else {
			$.Calculator.InterimFrequency();
		}
	},

	ViewProjectDetailsClick: function () {
		rm.uiComponents.showProjectDetails($.InitiateRequest._selectedProjectID);
	},
	LoadTierDropdowns: function () {
		var postData =
		{
			calculatorTypeId: ResourceTypeName.DTESite_Monitoring == $('#ddlResourceType').val() ? CalculatorGroup_E.DTEMonitoringCalculator : CalculatorGroup_E.DTEPharmacyCalculator,
			projectId: $.InitiateRequest._selectedProjectID,
			countryId: $('#ddlCountry').val()
		};
		$.rm.Ajax_Calculator("GetDefaultTier", postData, function (data) {
			if (ResourceTypeName.DTESite_Monitoring == $('#ddlResourceType').val()) {
				$.Dropdown.Fill(".ddltier_freq1", data[0].Value.FrequencyTiers, "Key Value", data[0].Value.DefaultTier.Key, false);
				$.Dropdown.Fill(".ddltier_freq2", data[1].Value.FrequencyTiers, "Key Value", data[1].Value.DefaultTier.Key, false);

				// Re-bind tooltip ** REQUIRED FOR JAPAN ** - remember to destroy the old_title to enable resetting.
				$("#" + $('.ddltier_freq1').attr('id')).qtip('destroy');
				$("#" + $('.ddltier_freq2').attr('id')).qtip('destroy');
				rm.qtip.showInfo("#" + $('.ddltier_freq1').attr('id'), "The selected Tier will set the Visit Frequency");
				rm.qtip.showInfo("#" + $('.ddltier_freq2').attr('id'), "The selected Tier will set the Visit Frequency");
			}
			else {
				$.Dropdown.Fill(".ddltier_pharma", data[0].Value.FrequencyTiers, "Key Value", data[0].Value.DefaultTier.Key, false);

				// QRPM-6687: TL: Trigger the onchange event to set the Visit Frequency Weeks.
				$(".ddltier_pharma").trigger("change");

				// Re-bind tooltip ** REQUIRED FOR JAPAN ** - remember to destroy the old_title to enable resetting.
				$("#" + $('.ddltier_pharma').attr('id')).qtip('destroy');
				rm.qtip.showInfo("#" + $('.ddltier_pharma').attr('id'), "The selected Tier will set the Visit Frequency");
			}
		}, true, false);
	},

	GetPageManager: function (pageManagerName) {
		var pageManagerExists = false;
		qipOtherCalculator.getCountryIdFromUi = initReqPgNs.getCountryId;
		qipOtherCalculator.getCountryIdForFteCalculation = initReqPgNs.getCountryId;
		qipOtherCalculator.getJobRoleIdForFteCalculation = function () { return ResourceTypeDetails[initReqPgNs.getResourceTypeId()].JobRoleId; };

		calculatorHelper.isInitiateRequestForDTE = false;
		$.Calculator._PageManager = pageManagerName;
		try {
			// TL: Set label text for region/country
			if (pageManagerName != undefined && pageManagerName == "Generic_PageManager") {
				$('#regionIDName').text("Preferred Region: ");
				$('#countryIDName').text("Preferred Country: ")
			}
			else {
				$('#regionIDName').text("Region: ");
				$('#countryIDName').text("Country: ");
			}

			pageManagerExists = jQuery.isFunction(eval(pageManagerName));

			return eval("new " + pageManagerName + "()");
		}
		catch (e) {
			alert("User interface not available for this resource type");
			initReqPgNs.resetPage();
			//ResetPageToDefault();
		}
	},
	ShowMilestones: function () {
		milestoneNs.showControl(milestoneNs.gridSelector, $.InitiateRequest._selectedProjectID);
	}
};

//Drawing start
ResetBrush = function () {
	this.Reset = function () {
		$(initReqPgNs.divCalculatorHolderSelector).hide();
		$(initReqPgNs.txtProposalFteSelector).attr("formating", "1,2").attr("from", 0.01).attr("to", 1).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 1.0.");
		$("#calculatorInstructions").text("").hide();
		$(initReqPgNs.lblProposalFteSelector).hide();
		$(initReqPgNs.divNotesSelector).hide();
		$("#ddlPreferredRegion").unbind("change.regionbased");
		$('#lblPreferredLocation').hide();
		$('.initiateFieldAssignedRegionList').hide();
		$('.initiateFieldAssignedCountryList').hide();
		$('.initiateFieldPreferredRegion').hide();
		$('.initiateFieldPreferredCountry').hide();
		$('.initiateFieldCountryRegion').hide();
		$('.initiateFieldCountry').hide();
		$('.initiateFieldSiteID').hide();
		$('.initiateFieldSiteStatus').hide();
		$('.initiateFieldVisitType').hide();
		$('.initiateFieldDuration').hide();
		$('.initiateFieldStartDate').hide();
		$('.initiateFieldStopDate').hide();
		$('.initiateFieldNeedByDate').hide();
		$(initReqPgNs.initiateFieldTotalSitesSelector).hide();
		$(initReqPgNs.divSiteCountByStatusSelector).hide();

		$('.initiateFieldIMDate').hide();
		$('.initiateFieldCRATrainingDate').hide();
		$('.initiateFieldSSVType').hide();
		$('.initiateFieldRequestBudgeted').hide();
		$('#initiateFieldBlindedSpan').hide();
		$('.initiateFieldReason').hide();
		$('.initiateNewRequestFields').hide();
		$('.initiateFieldProposalResource').hide();
		$(".initiateNewRequestListTop").attr("style", "height: 30px;");
		$.InitiateRequest._operationRemove = false;
		$.Calculator._interimFrequencyEnabled = false;
		qipOtherCalculator.isRegionBasedCalculator = false;
		qipOtherCalculator.isGlobalCalculator = false;
		$.GenericFTECalculator._interimFrequencyEnabled = false;
		$(".FTE_Calculator").hide();
		$(".Small_FTE_Calculator").hide();
		$(".GenericFTE_Calculator").hide();
		$(".SSVCountry_FTE_Calculator").hide()
		$("#divCalculator").empty();
		$(".initiateNewRequestFloat").removeClass("initiateNewRequestFloat").addClass("initiateNewRequestFloatEdit");
		$("#divAccordionCalculator").hide();

		//Reset variable here
		$.InitiateRequest._countryRegion = -1;
		$.InitiateRequest._country = -1;
		$.InitiateRequest._regionId = -1;
		$.InitiateRequest._preferredRegion = -1;
		$.InitiateRequest._siteId = -1;
		$.InitiateRequest._SSVType = -1;
		$.InitiateRequest._visitType = -1;
		$.SmallFTECalculator.ClearCalculator();
		$.InitiateRequest._piName = "";
		$.InitiateRequest._requestLocation = "";
		$.InitiateRequest._sponsorSite = "";
		$.InitiateRequest._duration = -1;
		$.InitiateRequest._reason = "";
		$.InitiateRequest._requestBudgeted = "";
		$.InitiateRequest._adhocCalcIdsToDelete.length = 0;
		$.InitiateRequest._requestLastModifiedOn = 0;
		$.InitiateRequest._attributeLastModifiedOn = 0;
		$.InitiateRequest._projectLastModifiedOn = 0;
		calculatorHelper.siteChanged = false;
		calculatorHelper.removeUnusedNamespaces($("#ddlResourceType").val());
		HideDateIcon();
		HideDateCountryIcon();


		unbindEvent("#txtStartDate", "connectDisconnect", "change");
		unbindEvent("#txtStartDate", "rsul", "change");
		unbindEvent("#txtStopDate", "connectDisconnect", "change");

		$("#txtStartDate").unbind("change.rsul");
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate,#txtIMDate").removeAttr("connectedDateValue")
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate,#txtIMDate").unbind("change.connectDisconnect");
	};
};

Standard_Monitoring_Brush = function () {
	this.Draw = function (withCountry) {
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show();
		$('.initiateFieldSiteStatus').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldIMDate').show();
		$('.initiateFieldCRATrainingDate').show();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate,#txtIMDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);
	};
};

Pharmacy_Monitoring_Brush = function () {
	this.Draw = function (withCountry) {
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show();
		$('.initiateFieldSiteStatus').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldIMDate').show();
		$('.initiateFieldCRATrainingDate').show();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate,#txtIMDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);
	};
};

iCRA_Monitoring_Brush = function () {
	this.Draw = function (withCountry) {
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show();
		$('.initiateFieldSiteStatus').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldIMDate').show();
		$('.initiateFieldCRATrainingDate').show();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate,#txtIMDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);
	};
};

Short_term_SWAT_Monitoring_Brush = function () {
	this.Draw = function (withCountry) {
		$("#txtStartDate,#txtStopDate").qDatepicker();
		Short_term_SWAT_Monitoring_Draw(withCountry);
	};
};

SSV_Monitoring_Brush = function () {
	this.Draw = function (withCountry) {
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show();
		$('.initiateFieldSiteStatus').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		//$('.initiateFieldCRATrainingDate').show();
		$('.initiateFieldSSVType').show();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);
	};
};

// TL:Added for generic brush
Generic_Brush = function () {
	this.Draw = function (withRegion) {
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldPreferredRegion').show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();

		$('#txtStartDate').addClass("disabledTextBox").attr("readonly", true);
		$('#txtStopDate').addClass("disabledTextBox").attr("readonly", true);
		$("#txtStartDate,#txtStopDate").qDatepicker({ 'destroy': true });
		$('#SpanStart').hide();
		$('#SpanStop').hide();

		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		$.GenericFTECalculator._interimFrequencyEnabled = true;
		handleProposalResourceVisibility();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withRegion) {
			$.Dropdown.PreferredRegion();
		}
		$.GenericFTECalculator.countrySelector = "#ddlPreferredCountry";
		displayCustomFields();
	};
};
//Drawing end

// TL: Start of DTESite brush
DTESite_Monitoring_Brush = function () {
	this.Draw = function (withCountry) {
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show();
		$('.initiateFieldSiteStatus').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldIMDate').show();
		$('.initiateFieldCRATrainingDate').show();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate,#txtIMDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);
		showHideTierWarning(false);
	};
};
// TL: End of DTESite brush

// TL: Start of DTEPharmacy brush
DTEPharmacy_Monitoring_Brush = function () {
	this.Draw = function (withCountry) {
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show();
		$('.initiateFieldSiteStatus').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldIMDate').show();
		$('.initiateFieldCRATrainingDate').show();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate,#txtIMDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);
		showHideTierWarning(true);
	};
};
// TL: End of DTEPharmacy brush

// for Standard_Monitoring start
Standard_Monitoring_PageManager = function () {
	GetDrawing = new Standard_Monitoring_Brush();
	this.Draw = function (withCountry) //Standard_Monitoring #1
	{
		GetDrawing.Draw(withCountry);
	};

	this.Validate = function () //Standard_Monitoring #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!Validate_Standard_Monitoring()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //Standard_Monitoring #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //Standard_Monitoring #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //Standard_Monitoring #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};

	this.GetOtherByResourceType = function () //Standard_Monitoring #6
	{
		SetSiteDetails();
	};

	this.GetOtherByResourceTypeCountry = function () //Standard_Monitoring #7
	{
		GetSiteDetails();
		ShowDateCountryIcon();
		ShowAndOpenCalculator();
		$.Calculator._interimFrequencyEnabled = true;
		rm.ui.ribbon.refresh();
		$("#txtStartDate").parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		$("#txtStartDate").val('');
		$("#txtNeedByDate").val('');
	};

	this.GetSite = function (pageManager) //Standard_Monitoring #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Standard_Monitoring #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), $.InitiateRequest._siteId, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //Standard_Monitoring #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Standard_Monitoring #12
	{
		SetStartStopCountryDateImage(hiddenJson);
		SetIMDateCountryImage(hiddenJson);
		SetCRATrainingDateCountryImage(hiddenJson);
		pageManager.GetOtherByResourceType();
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //Standard_Monitoring #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowCountryDisconnectedIconsForStartAndStopDates(); };
	this.SaveRequest = function () //Standard_Monitoring #15
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveNewInitiateRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.UpdateRequest = function () //Standard_Monitoring #16
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveUpdatedRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.GetFTECalculator = function (selector, pageManager) //Standard_Monitoring //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.Standard_Monitoring, pageManager);
	};

	this.OnSaveSuccess = function () //Standard_Monitoring #18
	{
		calculatorHelper.onSaveSuccess();
	};

	this.SetDatesAttributeForNewCountry = function () //Standard_Monitoring #22
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.GetAttribute = function (countryId) //Standard_Monitoring //AI: call this to get attribute details #23
	{
		return GetMonitoringAttribute(countryId);
	};
	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate, populateStartDate) {
		SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate, populateStartDate);
	};

	this.getJobGrade = function () { return calculatorGroup.getJobGrade(); } //Standard_Monitoring #24
	this.getJobGradeInfoString = function () { return calculatorGroup.getJobGradeInfoString(); } //Standard_Monitoring #25
};

Validate_Standard_Monitoring = function () {
	return ValidateSsvCalculator();
};
// for Standard_Monitoring end

// for Co_monitoring start
Co_monitoring_PageManager = function () {
	this.Draw = function (withCountry) //Co_monitoring #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show(); //SV:due to story 3617
		$('.initiateFieldSiteStatus').show(); //SV:due to story 3617 
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$.SmallFTECalculator.countrySelector = "#ddlCountry";
	};

	this.Validate = function () //Co_monitoring #2
	{
		var isValid = CommonValidate();
		//if (!CommonValidate()) { isValid = false; }

		if ($.trim($("#txtStartDate").val()) != "" && $.trim($("#txtStopDate").val()) != "" && $.trim($.SmallFTECalculator.GetValues().FTE) != "") {
			if (!$.SmallFTECalculator.save()) { isValid = false; }
		}

		return isValid;
	};

	this.CleanError = function () //Co_monitoring #3
	{
		CleanDurationError();
	};

	this.ChangeFrameSize = function () //Co_monitoring #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //Co_monitoring #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};

	this.GetOtherByResourceType = function () //Co_monitoring #6
	{
		SetSiteDetails();
	};

	this.GetOtherByResourceTypeCountry = function () //Co_monitoring #7
	{
		GetSiteDetails();
		GetOtherByResourceTypeCountry();
		var GetMethod = new Co_monitoring_PageManager();
		GetMethod.CountryRegion();
		HideDateIcon();
		HideDateCountryIcon();
	};

	this.GetSite = function () //Co_monitoring #9
	{
		GetOtherByResourceTypeCountry(); //AI: Special case for Co-Monitoring to handle SiteCOV date after double click the row in edit mode.
		GetSiteDetails();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Co_monitoring #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlCountry', "Co-monitoring FTE Calculator", pageManager);
		$.Calculator._interimFrequencyEnabled = false;
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //Co_monitoring #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Co_monitoring #12  even the date is not populating from PPM but need this method to set Site Status readonly textbax.
	{
		pageManager.GetOtherByResourceType();
	};

	this.SetCalculatorValues = function (FTE, totalHours) //Co_monitoring #14
	{
		$.SmallFTECalculator.SetCalculatorValues(FTE, totalHours);
	};

	this.SaveRequest = function () //Co_monitoring #15
	{
		setTimeout(function () {
			if ($.Calculator.IsPromptRequiredForConnectDisconnectStatus()) {
				$.Calculator.DialogOkClickHandler = SaveNewInitiateRequest;
				$.Calculator.ShowConnectDisconnectChoiceDialog();
			}
			else {
				SaveNewInitiateRequest();
			}
		}, 100);
	};

	this.UpdateRequest = function () //Co_monitoring #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //Co_monitoring //AI: called this function on country change dropdown #17
	{
		GetSmallFTECalculator(pageManager, ResourceTypeName.Co_monitoring);
	};

	this.CountryRegion = function () //Co_monitoring #19
	{
		initReqPgNs.setCountryRegion();
	};

	this.SetCountryRegion = function (pageManager) //Co_monitoring #21
	{
		pageManager.CountryRegion();
	};

	this.getJobGrade = function () { return null; } //Co_monitoring #24
	this.getJobGradeInfoString = function () { return null; } //Co_monitoring #25

	this.handleStartStopDateChange = function () {
		$.SmallFTECalculator.CalculateTotalHours();
	};
};
// for Co_monitoring end

// for Co_monitoring_SiteSpecific start
Co_monitoring_SiteSpecific_PageManager = function () {
	this.Draw = function (withCountry) //Co_monitoring_SiteSpecific #1
	{
		$("#txtStartDate,#txtStopDate").qDatepicker();
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show();
		$('.initiateFieldSiteStatus').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
		$.Dropdown.GetVisitType(initReqPgNs.getResourceTypeId(), !initReqPgNs.isInEditMode());

	};

	this.Validate = function () //Co_monitoring_SiteSpecific #2
	{
		return Validate_Co_monitoring_SiteSpecific();
	};

	this.CleanError = function () //Co_monitoring_SiteSpecific #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //Co_monitoring_SiteSpecific #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //Co_monitoring_SiteSpecific #5
	{
		if ($.Dropdown.IsEcdProject()) {
			$.Dropdown.AddItemsToDropdownByIdName($.InitiateRequest.GetCountriesFromSiteAddressByProjectId($.InitiateRequest._selectedProjectID));
		}
		else {
			$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
		}
	};

	this.GetOtherByResourceType = function () //Co_monitoring_SiteSpecific #6
	{
		Co_Monitoring_SiteSpecific_GetOtherByResourceType();
	};

	this.GetOtherByResourceTypeCountry = function () //Co_monitoring_SiteSpecific #7
	{
		$.Dropdown.VisitType();
		Co_Monitoting_SiteSpecific_GetOtherByResourceTypeCountry();
	};

	this.GetSite = function (pageManager) //Co_monitoring_SiteSpecific #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Co_monitoring_SiteSpecific #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), -1, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //Co_monitoring_SiteSpecific #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Co_monitoring_SiteSpecific #12  even the date is not populating from PPM but need this method to set Site Status readonly textbax.
	{
		pageManager.GetOtherByResourceType();
		$("#ddlVisitType").val(hiddenJson.SiteVisitTypeId);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //Short_term_SWAT_Monitoring_OnSite_Visit #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.SaveRequest = function () //Co_monitoring_SiteSpecific #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //Co_monitoring_SiteSpecific #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //Co_monitoring_SiteSpecific //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.Co_monitoring_SiteSpecific, pageManager);
	};

	this.SetDatesAttributeForNewCountry = function () //Co_monitoring_SiteSpecific #21
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.getJobGrade = function () { return null; } //Co_monitoring_SiteSpecific #24
	this.getJobGradeInfoString = function () { return null; } //Co_monitoring_SiteSpecific #25
};

Validate_Co_monitoring_SiteSpecific = function () {
	var retVal = Short_term_SWAT_Monitoring_Validate();
	return retVal;
};
// for Co_monitoring_SiteSpecific end
// for Non_Standard_Monitoring_SiteSpecific start
Non_Standard_Monitoring_SiteSpecific_PageManager = function () {
	this.Draw = function (withCountry) //Non_Standard_Monitoring_SiteSpecific #1
	{
		$("#txtStartDate,#txtStopDate").qDatepicker();
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('.initiateFieldCountry').show();
		$('.initiateFieldSiteID').show();
		$('.initiateFieldSiteStatus').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
		$.Dropdown.GetVisitType(initReqPgNs.getResourceTypeId(), !initReqPgNs.isInEditMode());
	};

	this.Validate = function () //Non_Standard_Monitoring_SiteSpecific #2
	{
		var retVal = Validate_Non_Standard_Monitoring_SiteSpecific();
		return retVal;
	};

	this.CleanError = function () //Non_Standard_Monitoring_SiteSpecific #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //Non_Standard_Monitoring_SiteSpecific #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //Non_Standard_Monitoring_SiteSpecific #5
	{
		if ($.Dropdown.IsEcdProject()) {
			$.Dropdown.AddItemsToDropdownByIdName($.InitiateRequest.GetCountriesFromSiteAddressByProjectId($.InitiateRequest._selectedProjectID));
		}
		else {
			$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
		}
	};

	this.GetOtherByResourceType = function () //Non_Standard_Monitoring_SiteSpecific #6
	{
		Non_Standard_Monitoring_SiteSpecific_GetOtherByResourceType();
	};

	this.GetOtherByResourceTypeCountry = function () //Non_Standard_Monitoring_SiteSpecific #7
	{
		$.Dropdown.VisitType();
		Non_Standard_Monitoring_SiteSpecific_GetOtherByResourceTypeCountry();
	};

	this.GetSite = function (pageManager) //Non_Standard_Monitoring_SiteSpecific #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Non_Standard_Monitoring_SiteSpecific #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), -1, $.InitiateRequest._projectCode, initReqPgNs.getCountryIdFromUi(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //Non_Standard_Monitoring_SiteSpecific #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryIdFromUi());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Non_Standard_Monitoring_SiteSpecific #12  even the date is not populating from PPM but need this method to set Site Status readonly textbax.
	{
		pageManager.GetOtherByResourceType();
		$("#ddlVisitType").val(hiddenJson.SiteVisitTypeId);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //Non_Standard_Monitoring_SiteSpecific #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute(initReqPgNs.getCountryId());
	};

	this.SaveRequest = function () //Non_Standard_Monitoring_SiteSpecific #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //Non_Standard_Monitoring_SiteSpecific #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //Non_Standard_Monitoring_SiteSpecific //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.Non_Standard_Monitoring_SiteSpecific, pageManager);
	};

	this.SetDatesAttributeForNewCountry = function () //Non_Standard_Monitoring_SiteSpecific #21
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute(initReqPgNs.getCountryId());
	};

	this.getJobGrade = function () { return null; } //Non_Standard_Monitoring_SiteSpecific #24
	this.getJobGradeInfoString = function () { return null; } //Non_Standard_Monitoring_SiteSpecific #25
};

Validate_Non_Standard_Monitoring_SiteSpecific = function () {
	var retVal = Short_term_SWAT_Monitoring_Validate();
	return retVal;
};
// for Co_monitoring_SiteSpecific end
// for Pharmacy_Monitoring start
Pharmacy_Monitoring_PageManager = function () {
	GetDrawing = new Pharmacy_Monitoring_Brush();
	this.Draw = function (withCountry) //Pharmacy_Monitoring #1
	{
		GetDrawing.Draw(withCountry);
	};

	this.Validate = function () //Pharmacy_Monitoring #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!Validate_Pharmacy_Monitoring()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //Pharmacy_Monitoring #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //Pharmacy_Monitoring #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //Pharmacy_Monitoring #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};

	this.GetOtherByResourceType = function () //Pharmacy_Monitoring #6
	{
		SetSiteDetails();
	};

	this.GetOtherByResourceTypeCountry = function () //Pharmacy_Monitoring #7
	{
		GetSiteDetails();
		ShowDateCountryIcon();
		ShowAndOpenCalculator();
		$.Calculator._interimFrequencyEnabled = true;
		rm.ui.ribbon.refresh();
		$("#txtStartDate").parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		$("#txtStartDate").val('');
		$("#txtNeedByDate").val('');
	};

	this.GetSite = function (pageManager) //Pharmacy_Monitoring #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Pharmacy_Monitoring #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), $.InitiateRequest._siteId, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //Pharmacy_Monitoring #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Pharmacy_Monitoring #12
	{
		SetStartStopCountryDateImage(hiddenJson);
		SetIMDateCountryImage(hiddenJson);
		SetCRATrainingDateCountryImage(hiddenJson);
		pageManager.GetOtherByResourceType();
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //Pharmacy_Monitoring #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowCountryDisconnectedIconsForStartAndStopDates(); };

	this.SaveRequest = function () //Pharmacy_Monitoring #15
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveNewInitiateRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.UpdateRequest = function () //Pharmacy_Monitoring #16
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveUpdatedRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.GetFTECalculator = function (selector, pageManager) //Pharmacy_Monitoring //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.Pharmacy_Monitoring, pageManager);
	};

	this.OnSaveSuccess = function () //Pharmacy_Monitoring #18
	{
		calculatorHelper.onSaveSuccess();
	};

	this.SetDatesAttributeForNewCountry = function () //Pharmacy_Monitoring #22
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.GetAttribute = function (countryId) //Pharmacy_Monitoring //AI: call this to get attribute details #23
	{
		return GetMonitoringAttribute(countryId);
	};

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate, populateStartDate) {
		SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate, populateStartDate);
	};

	this.getJobGrade = function () { return calculatorGroup.getJobGrade(); } //Pharmacy_Monitoring #24
	this.getJobGradeInfoString = function () { return calculatorGroup.getJobGradeInfoString(); } //Pharmacy_Monitoring #25
};

Validate_Pharmacy_Monitoring = function () {
	return ValidateSsvCalculator();
};
// for Pharmacy_Monitoring end

// for CRS start
CRS_PageManager = function () {
	this.Draw = function (withCountry) //CRS #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('#lblPreferredLocation').show();
		if (!initReqPgNs.isProposalProjectSelected()) {
			$('.initiateFieldAssignedRegionList').show();
			$('.initiateFieldAssignedCountryList').show();
		}
		else { $(initReqPgNs.divNotesSelector).show(); }

		$('.initiateFieldPreferredRegion').show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		$.Dropdown.PreferredRegion();
		$.Dropdown.AssignRegion();
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
	};

	this.Validate = function () //CRS #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!Validate_CRS()) { isValid = false; }
		if (!IsQipOtherCalculatorValid()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //CRS #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //CRS #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //CRS #5
	{
		PopulateRegionAndCountry(true);
	};

	this.GetOtherByResourceType = function () //CRS #6
	{
		ClearAllTextBox();
	};

	this.GetOtherByResourceTypeCountry = function () //CRS #7
	{
		$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		requestLocation = "";
		ShowDateIcon();
	};

	this.GetPreferredCountryByPreferredRegion = function () //CRS  #8
	{
		$.Dropdown.PreferredCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //CRS #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlPreferredCountry', "CRS FTE Calculator", pageManager);
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //CRS #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson) //CRS #12
	{
		SetStartStopDateImage(hiddenJson);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) //CRS #13
	{
		ShowDatesOnCountryOrPreferredCountryChange(pageManager);
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };

	this.SetCalculatorValues = function (FTE, totalHours)  //CRS #14
	{
		$.SmallFTECalculator.ClearCalculator();
	};

	this.SaveRequest = function () //CRS #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //CRS #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //CRS //AI: called this function on country change dropdown #17
	{
		GetFTECalculator(selector, ResourceTypeName.CRS, pageManager);
	};

	this.CountryRegion = function () //CRS #19
	{
		var countryIds = "";
		var countryUSCanada = $.InitiateRequest._countryIds.split('|');
		var DistinctCountryIds = $("#txtProjectName").data("DistinctCountryIds");

		$.each(DistinctCountryIds, function (index, ele) {
			if ($.inArray("" + ele + "", countryUSCanada) != -1) {
				if (countryIds != "") {
					countryIds += "|";
				}
				countryIds += ele;
			}
		});

		if (countryIds != "") {
			$.Dropdown.CountryRegionCountryName(countryIds, -1);
			$('.initiateFieldCountryRegion').show();
		}
		else {
			$.InitiateRequest._countryRegion = -1;
			$("#ddlCountryRegion").empty();
			$('.initiateFieldCountryRegion').hide();
		}
	};

	this.getJobGrade = function () { return $.Calculator.getJobGrade(); } //CRS #24
	this.getJobGradeInfoString = function () { return $.Calculator.getJobGradeInfoString(); } //CRS #25
};

Validate_CRS = function () {
	var isValid = true;
	var isCountryRegionApplicable = false;
	var countryUSCanada = $.InitiateRequest._countryIds.split('|');
	var DistinctCountryIds = $("#txtProjectName").data("DistinctCountryIds");

	$.each(DistinctCountryIds, function (index, ele) {
		if ($.inArray("" + ele + "", countryUSCanada) != -1) {
			isCountryRegionApplicable = this;
			return false;
		}
	});

	if ($('.initiateFieldCountryRegion').is(":visible")) {
		var countryRegion = $('#ddlCountryRegion').val();
		if (isCountryRegionApplicable && countryRegion == -1) {
			$.InitiateRequest._countryRegion = -1;
			rm.validation.addError("#ddlCountryRegion", Resources.CountryRegionRequired);
			isValid = false;
		}
		else {
			$.InitiateRequest._countryRegion = $('#ddlCountryRegion').val();
			rm.validation.clearError($("#ddlCountryRegion"));
		}
	}

	return isValid;
};
// for CRS end

// for iCRA_Monitoring start
iCRA_Monitoring_PageManager = function () {
	GetDrawing = new iCRA_Monitoring_Brush();
	this.Draw = function (withCountry) //iCRA_Monitoring #1
	{
		GetDrawing.Draw(withCountry);
	};

	this.Validate = function () //iCRA_Monitoring #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!Validate_iCRA_Monitoring()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //iCRA_Monitoring #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //iCRA_Monitoring #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //iCRA_Monitoring #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};

	this.GetOtherByResourceType = function () //iCRA_Monitoring #6
	{
		SetSiteDetails();
	};

	this.GetOtherByResourceTypeCountry = function () //iCRA_Monitoring #7
	{
		GetSiteDetails();
		ShowDateCountryIcon();
		ShowAndOpenCalculator();
		$.Calculator._interimFrequencyEnabled = true;
		rm.ui.ribbon.refresh();
		$("#txtStartDate").parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		$("#txtStartDate").val('');
		$("#txtNeedByDate").val('');
	};

	this.GetSite = function (pageManager) //iCRA_Monitoring #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //iCRA_Monitoring #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), $.InitiateRequest._siteId, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //iCRA_Monitoring #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //iCRA_Monitoring #12
	{
		SetStartStopCountryDateImage(hiddenJson);
		SetIMDateCountryImage(hiddenJson);
		SetCRATrainingDateCountryImage(hiddenJson);
		pageManager.GetOtherByResourceType();
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) //iCRA_Monitoring #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowCountryDisconnectedIconsForStartAndStopDates(); };

	this.SaveRequest = function () //iCRA_Monitoring #15
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveNewInitiateRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.UpdateRequest = function () //iCRA_Monitoring #16
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveUpdatedRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.GetFTECalculator = function (selector, pageManager) //iCRA_Monitoring //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.iCRA_Monitoring, pageManager);
	};

	this.OnSaveSuccess = function () //iCRA_Monitoring #18
	{
		calculatorHelper.onSaveSuccess();
	};

	this.SetDatesAttributeForNewCountry = function () //iCRA_Monitoring #22
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.GetAttribute = function (countryId) //iCRA_Monitoring //AI: call this to get attribute details #23
	{
		return GetMonitoringAttribute(countryId);
	};

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate, populateStartDate) {
		SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate, populateStartDate);
	};

	this.getJobGrade = function () { return calculatorGroup.getJobGrade(); } //iCRA_Monitoring #24
	this.getJobGradeInfoString = function () { return calculatorGroup.getJobGradeInfoString(); } //iCRA_Monitoring #25
};

Validate_iCRA_Monitoring = function () {
	return ValidateSsvCalculator();
};
// for iCRA_Monitoring end

// for Short_term_SWAT_Monitoring_OnSite_Visit start
Short_term_SWAT_Monitoring_OnSite_Visit_PageManager = function () {
	GetDrawing = new Short_term_SWAT_Monitoring_Brush();
	this.Draw = function (withCountry) //Short_term_SWAT_Monitoring_OnSite_Visit #1
	{
		GetDrawing.Draw(withCountry);
	};

	this.Validate = function () //Short_term_SWAT_Monitoring_OnSite_Visit #2
	{
		return Short_term_SWAT_Monitoring_Validate();
	};

	this.CleanError = function () //Short_term_SWAT_Monitoring_OnSite_Visit #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //Short_term_SWAT_Monitoring_OnSite_Visit #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //Short_term_SWAT_Monitoring_OnSite_Visit #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};

	this.GetOtherByResourceType = function () //Short_term_SWAT_Monitoring_OnSite_Visit #6
	{
		Short_term_SWAT_Monitoring_GetOtherByResourceType();
	};

	this.GetOtherByResourceTypeCountry = function () //Short_term_SWAT_Monitoring_OnSite_Visit #7
	{
		$.Dropdown.VisitType();
		Short_term_SWAT_Monitoring_GetOtherByResourceTypeCountry();
	};

	this.GetSite = function (pageManager) //Short_term_SWAT_Monitoring_OnSite_Visit #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Short_term_SWAT_Monitoring_OnSite_Visit #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), -1, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //Short_term_SWAT_Monitoring_OnSite_Visit #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Short_term_SWAT_Monitoring_OnSite_Visit #12
	{
		pageManager.GetOtherByResourceType();
		$("#ddlVisitType").val(hiddenJson.SiteVisitTypeId);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //Short_term_SWAT_Monitoring_OnSite_Visit #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.SaveRequest = function () //Short_term_SWAT_Monitoring_OnSite_Visit #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //Short_term_SWAT_Monitoring_OnSite_Visit #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //Short_term_SWAT_Monitoring_OnSite_Visit //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.Short_term_SWAT_Monitoring_OnSite_Visit, pageManager);
	};

	this.SetDatesAttributeForNewCountry = function () //Short_term_SWAT_Monitoring_OnSite_Visit #22
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.getJobGrade = function () { return null; } //Short_term_SWAT_Monitoring_OnSite_Visit #24
	this.getJobGradeInfoString = function () { return null; } //Short_term_SWAT_Monitoring_OnSite_Visit #25
};

Validate_Short_term_SWAT_Monitoring_OnSite_Visit = function () {
	Validate_Short_term_SWAT_Monitoring();
};
// for Short_term_SWAT_Monitoring_OnSite_Visit end

// for Short_term_SWAT_Monitoring_Phone_Visit start
Short_term_SWAT_Monitoring_Phone_Visit_PageManager = function () {
	GetDrawing = new Short_term_SWAT_Monitoring_Brush();
	this.Draw = function (withCountry) //Short_term_SWAT_Monitoring_Phone_Visit #1
	{
		GetDrawing.Draw(withCountry);
	};

	this.Validate = function () //Short_term_SWAT_Monitoring_Phone_Visit #2
	{
		return Short_term_SWAT_Monitoring_Validate();
	};

	this.CleanError = function () //Short_term_SWAT_Monitoring_Phone_Visit #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //Short_term_SWAT_Monitoring_Phone_Visit #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //Short_term_SWAT_Monitoring_Phone_Visit #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};

	this.GetOtherByResourceType = function () //Short_term_SWAT_Monitoring_Phone_Visit #6
	{
		Short_term_SWAT_Monitoring_GetOtherByResourceType();
	};

	this.GetOtherByResourceTypeCountry = function () //Short_term_SWAT_Monitoring_Phone_Visit #7
	{
		$.Dropdown.VisitType();
		Short_term_SWAT_Monitoring_GetOtherByResourceTypeCountry();
	};

	this.GetSite = function (pageManager) //Short_term_SWAT_Monitoring_Phone_Visit #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Short_term_SWAT_Monitoring_Phone_Visit #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), -1, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //Short_term_SWAT_Monitoring_Phone_Visit #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Short_term_SWAT_Monitoring_Phone_Visit #12
	{
		pageManager.GetOtherByResourceType();
		$("#ddlVisitType").val(hiddenJson.SiteVisitTypeId);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //Short_term_SWAT_Monitoring_Phone_Visit #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.SaveRequest = function () //Short_term_SWAT_Monitoring_Phone_Visit #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //Short_term_SWAT_Monitoring_Phone_Visit #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //Short_term_SWAT_Monitoring_Phone_Visit //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.Short_term_SWAT_Monitoring_Phone_Visit, pageManager);
	};

	this.SetDatesAttributeForNewCountry = function () //Short_term_SWAT_Monitoring_Phone_Visit #22
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.getJobGrade = function () { return null; } //Short_term_SWAT_Monitoring_Phone_Visit #24
	this.getJobGradeInfoString = function () { return null; } //Short_term_SWAT_Monitoring_Phone_Visit #25
};

Validate_Short_term_SWAT_Monitoring_Phone_Visit = function () {
	Validate_Short_term_SWAT_Monitoring();
};
// for Short_term_SWAT_Monitoring_Phone_Visit end

// for Regional_CPM start
Regional_CPM_PageManager = function () {
	//GetDrawing = new Regional_CPM_Brush();
	this.Draw = function () //Regional_CPM #1
	{
		//GetDrawing.Draw();
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$('#lblPreferredLocation').show();
		if (!initReqPgNs.isProposalProjectSelected()) {
			$('.initiateFieldAssignedRegionList').show();
			$('.initiateFieldAssignedCountryList').show();
		}
		else { $(initReqPgNs.divNotesSelector).show(); }
		$('.initiateFieldPreferredRegion').show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();

		setButton();
		$.Calculator._interimFrequencyEnabled = true;
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		$.Dropdown.PreferredRegion();
		$.Dropdown.AssignRegion();
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
	};

	this.Validate = function () //Regional_CPM #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!IsQipOtherCalculatorValid()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //Regional_CPM #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //Regional_CPM #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () { PopulateRegionAndCountry(true); };//Regional_CPM #5

	this.GetOtherByResourceType = function () { ClearAllTextBox(); };//Regional_CPM #6

	this.GetOtherByResourceTypeCountry = function () //Regional_CPM #7
	{
		$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		requestLocation = "";
		ShowDateIcon();
	};

	this.GetPreferredCountryByPreferredRegion = function () { $.Dropdown.PreferredCountry(); };//Regional_CPM #8
	this.DrawCalculator = function (withCountry, onRequest, pageManager) { DrawCalculator(withCountry, onRequest, '#ddlPreferredCountry', "Regional CPM FTE Calculator", pageManager); };//Regional_CPM #10

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) { return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId()); };//Regional_CPM #11

	this.SetStartStopDateImage = function (hiddenJson) { SetStartStopDateImage(hiddenJson); };//Regional_CPM #12

	this.ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) { ShowDatesOnCountryOrPreferredCountryChange(pageManager); };//Regional_CPM #13
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };

	this.SetCalculatorValues = function (FTE, totalHours) //Regional_CPM #14
	{
		$.SmallFTECalculator.ClearCalculator();
	};

	this.SaveRequest = function () //Regional_CPM #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //Regional_CPM #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //Regional_CPM //AI: called this function on country change dropdown #17
	{
		GetFTECalculator(selector, ResourceTypeName.Regional_CPM, pageManager);
	};

	this.getJobGrade = function () { return $.Calculator.getJobGrade(); } //Regional_CPM #24
	this.getJobGradeInfoString = function () { return $.Calculator.getJobGradeInfoString(); } //Regional_CPM #25
};
// for Regional_CPM end

// for SSV_Monitoring start
SSV_Monitoring_PageManager = function () {
	GetDrawing = new SSV_Monitoring_Brush();
	this.Draw = function (withCountry) //SSV_Monitoring #1
	{
		GetDrawing.Draw(withCountry);
	};

	this.Validate = function () //SSV_Monitoring #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!Validate_SSV_Monitoring()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //SSV_Monitoring #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //SSV_Monitoring #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //SSV_Monitoring #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.SSVAttributeList);
		$.Dropdown.SSVType();
	};

	this.GetOtherByResourceType = function () //SSV_Monitoring #6
	{
		SetSiteDetails();
	};

	this.GetOtherByResourceTypeCountry = function () //SSV_Monitoring #7
	{
		GetSiteDetails();
		ShowDateCountryIcon();
		ShowAndOpenCalculator();
	};

	this.GetSite = function (pageManager) //SSV_Monitoring #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //SSV_Monitoring #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), -1, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //SSV_Monitoring #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //SSV_Monitoring #12
	{
		SetStartStopCountryDateImage(hiddenJson);
		SetCRATrainingDateCountryImage(hiddenJson);
		pageManager.GetOtherByResourceType();
		$("#ddlSSVType").val(hiddenJson.SSVTypeId);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //SSV_Monitoring #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromSsvAttribute($("#ddlCountry").val());
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowCountryDisconnectedIconsForStartAndStopDates(); };

	this.SaveRequest = function () //SSV_Monitoring #15
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveNewInitiateRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.UpdateRequest = function () //SSV_Monitoring #16
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveUpdatedRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.GetFTECalculator = function (selector, pageManager) //SSV_Monitoring //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.SSV_Monitoring, pageManager);
	};

	this.OnSaveSuccess = function () //SSV_Monitoring #18
	{
		calculatorHelper.onSaveSuccess();
	};

	this.SetDatesAttributeForNewCountry = function () //SSV_Monitoring #22
	{
		SetDatesOnCountryOrPreferredCountryChangeFromSsvAttribute($("#ddlCountry").val());
	};

	this.GetAttribute = function (countryId) //SSV_Monitoring //AI: call this to get attribute details #23
	{
		return GetSsvAttribute(countryId);
	};

	this.getJobGrade = function () { return calculatorGroup.getJobGrade(); } //SSV_Monitoring #24
	this.getJobGradeInfoString = function () { return calculatorGroup.getJobGradeInfoString(); } //SSV_Monitoring #25
};

Validate_SSV_Monitoring = function () {
	return ValidateSsvCalculator();
};
// for SSV_Monitoring end

// TL:Added for generic page manager
Generic_PageManager = function () {
	GetDrawing = new Generic_Brush();
	this.Draw = function (withRegion) //Generic #1
	{
		GetDrawing.Draw(withRegion);
		$(initReqPgNs.divCalculatorHolderSelector).show();
	};

	this.Validate = function () //Generic #2
	{
		//update request start and stop dates based on the start and stop dates of first and last phase
		$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(true);
		$.GenericFTECalculator.SetStartDateAndEndDateBasedOnMilestones(false);
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!Validate_Generic()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //Generic #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //Generic #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //Generic #5
	{
		PopulateRegionAndCountry(false);
	};

	this.GetOtherByResourceTypeCountry = function () //Generic #6
	{
		$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		requestLocation = "";
		HideDateIcon();

	};

	this.GetPreferredCountryByPreferredRegion = function () //Generic  #8
	{
		$.Dropdown.PreferredCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Generic #10
	{
		if (initReqPgNs.getResourceTypeId() == 9106) {
			$("#calculatorInstructions").text("The standard setup for this Resource Request Type is a single Stage requiring 0.2 FTE").removeClass("hideMe").show();
		} else {
			$("#calculatorInstructions").text("").hide();
		}
		DrawCalculator(withCountry, onRequest, '#ddlPreferredCountry', $('#ddlResourceType option:selected').text() + " FTE Calculator", pageManager);
		$.GenericFTECalculator._interimFrequencyEnabled = true;
		$.GenericFTECalculator._DefaultToMilestoneId = $.InitiateRequest._DefaultToMilestoneId;
		$.GenericFTECalculator._DefaultFromMilestoneId = $.InitiateRequest._DefaultFromMilestoneId;
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //Generic #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Generic #12 
	{ };

	this.SetCalculatorValues = function (FTE, totalHours) //Generic #14
	{
		$.GenericFTECalculator.SetCalculatorValues(FTE, totalHours);
	};

	this.SaveRequest = function () //Generic #15
	{
		setTimeout(function () {
			//GS:Code Review-This validation can be removed as there is no validation in IsPromptRequiredForConnectDisconnectStatus()
			if ($.Calculator.IsPromptRequiredForConnectDisconnectStatus()) {
				$.Calculator.DialogOkClickHandler = SaveNewInitiateRequest;
				$.Calculator.ShowConnectDisconnectChoiceDialog();
			}
			else {
				$.GenericFTECalculator.save(true);
				SaveNewInitiateRequest();
			}
		}, 100);
	};

	this.UpdateRequest = function () //Generic #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) {
		GetFTECalculator(selector, $('#ddlResourceType').val(), pageManager);
	};

	this.CountryRegion = function () //Generic #19
	{
		var countryId = $('#ddlCountry').val();
		var isCountryFound = false;
		var DistinctCountryIds = $("#txtProjectName").data("DistinctCountryIds");

		$.each(DistinctCountryIds, function (index, ele) {
			if (ele == countryId) {
				$.Dropdown.CountryRegion(countryId, -1);
				$('.initiateFieldCountryRegion').show();
				isCountryFound = true;
				return false;
			}
		});

		if (!isCountryFound) {
			$('.initiateFieldCountryRegion').hide();
		}
	};

	this.SetCountryRegion = function (pageManager) //Generic #21
	{
		pageManager.CountryRegion();
	};

	this.getJobGrade = function () { return null; } //Generic #24
	this.getJobGradeInfoString = function () { return null; } //Generic #25
};

// TL: Validate genric
Validate_Generic = function () {
	var isValid = true;
	if (!$.GenericFTECalculator.saveCalculator()) { isValid = false; }
	if (!$.GenericFTECalculator.IsValid()) { isValid = false; }
	return isValid;
};

// for DTE Site_Monitoring start
DTESite_Monitoring_PageManager = function () {
	//calculatorHelper.isProjectDTE = true;

	GetDrawing = new DTESite_Monitoring_Brush();
	this.Draw = function (withCountry) //DTE Site_Monitoring #1
	{
		GetDrawing.Draw(withCountry);
	};

	this.Validate = function () //DTE Site_Monitoring #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!Validate_DTESite_Monitoring()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //DTE Site_Monitoring #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //DTE Site_Monitoring #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //DTE Site_Monitoring #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};

	this.GetOtherByResourceType = function () //DTE Site_Monitoring #6
	{
		SetSiteDetails();
	};

	this.GetOtherByResourceTypeCountry = function () //DTE Site_Monitoring #7
	{
		GetSiteDetails();
		ShowDateCountryIcon();
		ShowAndOpenCalculator();
		$.Calculator._interimFrequencyEnabled = true;
		rm.ui.ribbon.refresh();
		$("#txtStartDate").parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		$("#txtStartDate").val('');
		$("#txtNeedByDate").val('');
	};

	this.GetSite = function (pageManager) //DTE Site_Monitoring #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //DTE Site_Monitoring #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), $.InitiateRequest._siteId, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //DTE Site_Monitoring #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //DTE Site_Monitoring #12
	{
		SetStartStopCountryDateImage(hiddenJson);
		SetIMDateCountryImage(hiddenJson);
		SetCRATrainingDateCountryImage(hiddenJson);
		pageManager.GetOtherByResourceType();
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //DTE Site_Monitoring #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowCountryDisconnectedIconsForStartAndStopDates(); };

	this.SaveRequest = function () //DTE Site_Monitoring #15
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveNewInitiateRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.UpdateRequest = function () //DTE Site_Monitoring #16
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveUpdatedRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.GetFTECalculator = function (selector, pageManager) //DTE Site_Monitoring //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.DTESite_Monitoring, pageManager);
	};

	this.OnSaveSuccess = function () //DTE Site_Monitoring #18
	{
		calculatorHelper.onSaveSuccess();
	};

	this.SetDatesAttributeForNewCountry = function () //DTE Site_Monitoring #22
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.GetAttribute = function (countryId) //DTE Site_Monitoring //AI: call this to get attribute details #23
	{
		return GetMonitoringAttribute(countryId);
	};

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate, populateStartDate) {
		SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate, populateStartDate);
	};
	this.getJobGrade = function () { return calculatorGroup.getJobGrade(); } //DTE Site_Monitoring #24
	this.getJobGradeInfoString = function () { return calculatorGroup.getJobGradeInfoString(); } //DTE Site_Monitoring #25
};

Validate_DTESite_Monitoring = function () {
	return ValidateSsvCalculator();
};
// for DTE Site_Monitoring end

// for DTEPharmacy_Monitoring start
DTEPharmacy_Monitoring_PageManager = function () {
	//calculatorHelper.isProjectDTE = true;

	GetDrawing = new DTEPharmacy_Monitoring_Brush();
	this.Draw = function (withCountry) //DTEPharmacy_Monitoring #1
	{
		GetDrawing.Draw(withCountry);
	};

	this.Validate = function () //DTEPharmacy_Monitoring #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!Validate_DTEPharmacy_Monitoring()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //DTEPharmacy_Monitoring #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //DTEPharmacy_Monitoring #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //DTEPharmacy_Monitoring #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};

	this.GetOtherByResourceType = function () //DTEPharmacy_Monitoring #6
	{
		SetSiteDetails();
	};

	this.GetOtherByResourceTypeCountry = function () //DTEPharmacy_Monitoring #7
	{
		GetSiteDetails();
		ShowDateCountryIcon();
		ShowAndOpenCalculator();
		$.Calculator._interimFrequencyEnabled = true;
		rm.ui.ribbon.refresh();
		$("#txtStartDate").parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		$("#txtStartDate").val('');
		$("#txtNeedByDate").val('');
	};

	this.GetSite = function (pageManager) //DTEPharmacy_Monitoring #9
	{
		pageManager.GetOtherByResourceTypeCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //DTEPharmacy_Monitoring #10
	{
		RenderCalculatorContainerGroupByRequestId(initReqPgNs.getRequestId(), $.InitiateRequest._siteId, $.InitiateRequest._projectCode, initReqPgNs.getCountryId(), initReqPgNs.getResourceTypeId());
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //DTEPharmacy_Monitoring #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //DTEPharmacy_Monitoring #12
	{
		SetStartStopCountryDateImage(hiddenJson);
		SetIMDateCountryImage(hiddenJson);
		SetCRATrainingDateCountryImage(hiddenJson);
		pageManager.GetOtherByResourceType();
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function () //DTEPharmacy_Monitoring #13
	{
		ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowCountryDisconnectedIconsForStartAndStopDates(); };

	this.SaveRequest = function () //DTEPharmacy_Monitoring #15
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveNewInitiateRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.UpdateRequest = function () //DTEPharmacy_Monitoring #16
	{
		calculatorHelper.connectStatusDialogOnOkClick = SaveUpdatedRequest;
		calculatorGroup.saveCalculator(false);
	};

	this.GetFTECalculator = function (selector, pageManager) //DTEPharmacy_Monitoring //AI: called this function on country change dropdown #17
	{
		GetSSVCalculator(selector, ResourceTypeName.DTEPharmacy_Monitoring, pageManager);
	};

	this.OnSaveSuccess = function () //DTEPharmacy_Monitoring #18
	{
		calculatorHelper.onSaveSuccess();
	};

	this.SetDatesAttributeForNewCountry = function () //DTEPharmacy_Monitoring #22
	{
		SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val());
	};

	this.GetAttribute = function (countryId) //DTEPharmacy_Monitoring //AI: call this to get attribute details #23
	{
		return GetMonitoringAttribute(countryId);
	};

	this.SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate, populateStartDate) {
		SetRequestStartDateFromCalculatedSIVFrequencyDate(startDate, populateStartDate);
	};
	this.getJobGrade = function () { return calculatorGroup.getJobGrade(); } //DTEPharmacy_Monitoring #24
	this.getJobGradeInfoString = function () { return calculatorGroup.getJobGradeInfoString(); } //DTEPharmacy_Monitoring #25
};

Validate_DTEPharmacy_Monitoring = function () {
	return ValidateSsvCalculator();
};
// for DTEPharmacy_Monitoring end

IsQipOtherCalculatorValid = function () {
	return $.Calculator.isValid();
};
PhaseCalculatorPageManager_Type1 = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";

	this.Draw = function (withRegion) //PhaseCalculatorPageManager_Type1 #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$(initReqPgNs.divCalculatorHolderSelector).show();
		$('#lblPreferredLocation').show();
		$('.initiateFieldPreferredRegion').show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();
		if (initReqPgNs.isProposalProjectSelected()) { $(initReqPgNs.divNotesSelector).show(); }
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withRegion) {
			$.Dropdown.PreferredRegion();
		}
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);

		displayCustomFields();
	};

	this.Validate = function () //PhaseCalculatorPageManager_Type1 #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!IsQipOtherCalculatorValid()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //PhaseCalculatorPageManager_Type1 #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //PhaseCalculatorPageManager_Type1 #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //PhaseCalculatorPageManager_Type1 #5
	{
		PopulateRegionAndCountry(false);
	};

	this.GetOtherByResourceTypeCountry = function () //PhaseCalculatorPageManager_Type1 #7
	{
		$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		requestLocation = "";
		ShowDateIcon();
	};

	this.GetPreferredCountryByPreferredRegion = function () //PhaseCalculatorPageManager_Type1  #8
	{
		$.Dropdown.PreferredCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //PhaseCalculatorPageManager_Type1 #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlPreferredCountry', calculatorHeading, pageManager);
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //PhaseCalculatorPageManager_Type1 #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson) //PhaseCalculatorPageManager_Type1 #12
	{
		SetStartStopDateImage(hiddenJson);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) //PhaseCalculatorPageManager_Type1 #13
	{
		ShowDatesOnCountryOrPreferredCountryChange(pageManager);
		if ($("#txtStartDate").val() == "" && !ResourceTypeDetails[initReqPgNs.getResourceTypeId()].RequestStartDateConnectedMilestoneId && !initReqPgNs.isInEditMode())
			$("#txtStartDate").val(rm.date.getQDateStringFromDate(rm.date.today()));
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };

	this.SetCalculatorValues = function (FTE, totalHours)  //PhaseCalculatorPageManager_Type1  #14
	{
		$.SmallFTECalculator.ClearCalculator();
	};

	this.SaveRequest = function () //PhaseCalculatorPageManager_Type1 #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //PhaseCalculatorPageManager_Type1 #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //PhaseCalculatorPageManager_Type1 #17
	{
		GetFTECalculator(selector, initReqPgNs.getResourceTypeId(), pageManager);
	};

	this.getJobGrade = function () { return $.Calculator.getJobGrade(); } //PhaseCalculatorPageManager_Type1 #24
	this.getJobGradeInfoString = function () { return $.Calculator.getJobGradeInfoString(); } //PhaseCalculatorPageManager_Type1 #25
};

PhaseCalculatorPageManager_Type2 = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";

	this.Draw = function (withCountry) //PhaseCalculatorPageManager_Type2 #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.

		$(initReqPgNs.divCalculatorHolderSelector).show();
		$('#lblPreferredLocation').show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();
		if (initReqPgNs.isProposalProjectSelected()) {
			$(initReqPgNs.divNotesSelector).show();
			$('.initiateFieldPreferredRegion').show();
		}
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");

		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);

		displayCustomFields();
	};

	this.Validate = function () //PhaseCalculatorPageManager_Type2 #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!IsQipOtherCalculatorValid()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //PhaseCalculatorPageManager_Type2 #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //PhaseCalculatorPageManager_Type2 #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //PhaseCalculatorPageManager_Type2 #5
	{
		if (initReqPgNs.isProposalProjectSelected()) {
			PopulateRegionAndCountry(false);
		} else {
			$.Dropdown.Fill("#ddlPreferredCountry", $.InitiateRequest._initiateRequestJSON.MonitoringAttributeList, "CountryId CountryName");
		}
	};

	this.GetOtherByResourceTypeCountry = function () //PhaseCalculatorPageManager_Type2 #7
	{
		//$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		//requestLocation = "";
		//ShowDateIcon();
	};

	this.GetPreferredCountryByPreferredRegion = function () //PhaseCalculatorPageManager_Type2  #8
	{
		$.Dropdown.PreferredCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //PhaseCalculatorPageManager_Type2 #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlPreferredCountry', calculatorHeading, pageManager);
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //PhaseCalculatorPageManager_Type2 #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson) //PhaseCalculatorPageManager_Type2 #12
	{
		SetStartStopDateImage(hiddenJson);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) //PhaseCalculatorPageManager_Type2 #13
	{
		ShowDatesOnCountryOrPreferredCountryChange(pageManager);
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };

	this.SetCalculatorValues = function (FTE, totalHours)  //PhaseCalculatorPageManager_Type2  #14
	{
		$.SmallFTECalculator.ClearCalculator();
	};

	this.SaveRequest = function () //PhaseCalculatorPageManager_Type2 #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //PhaseCalculatorPageManager_Type2 #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //PhaseCalculatorPageManager_Type2 #17
	{
		GetFTECalculator(selector, initReqPgNs.getResourceTypeId(), pageManager);
	};

	this.getJobGrade = function () { return $.Calculator.getJobGrade(); } //PhaseCalculatorPageManager_Type2 #24
	this.getJobGradeInfoString = function () { return $.Calculator.getJobGradeInfoString(); } //PhaseCalculatorPageManager_Type2 #25
};
PhaseCalculatorPageManager_Type3 = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";

	this.Draw = function (withCountry) //PhaseCalculatorPageManager_Type3 #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.

		$(initReqPgNs.divCalculatorHolderSelector).show();
		$('#lblPreferredLocation').show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();
		if (initReqPgNs.isProposalProjectSelected()) {
			$(initReqPgNs.divNotesSelector).show();
			$('.initiateFieldPreferredRegion').show();
		}
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");

		if (withCountry) {
			$.Dropdown.Country();
		}
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);

		displayCustomFields();
	};

	this.Validate = function () //PhaseCalculatorPageManager_Type3 #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!IsQipOtherCalculatorValid()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //PhaseCalculatorPageManager_Type3 #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //PhaseCalculatorPageManager_Type3 #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //PhaseCalculatorPageManager_Type3 #5
	{
		if (initReqPgNs.isProposalProjectSelected()) {
			PopulateRegionAndCountry(false);
		} else {
			$.Dropdown.Fill("#ddlPreferredCountry", $.InitiateRequest._initiateRequestJSON.SSVAttributeList, "CountryId CountryName");
		}
	};

	this.GetOtherByResourceTypeCountry = function () //PhaseCalculatorPageManager_Type3 #7
	{
		//$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		//requestLocation = "";
		//ShowDateIcon();
	};

	this.GetPreferredCountryByPreferredRegion = function () //PhaseCalculatorPageManager_Type3  #8
	{
		$.Dropdown.PreferredCountry();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //PhaseCalculatorPageManager_Type3 #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlPreferredCountry', calculatorHeading, pageManager);
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //PhaseCalculatorPageManager_Type3 #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson) //PhaseCalculatorPageManager_Type3 #12
	{
		SetStartStopDateImage(hiddenJson);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) //PhaseCalculatorPageManager_Type3 #13
	{
		ShowDatesOnCountryOrPreferredCountryChange(pageManager);
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };

	this.SetCalculatorValues = function (FTE, totalHours)  //PhaseCalculatorPageManager_Type3  #14
	{
		$.SmallFTECalculator.ClearCalculator();
	};

	this.SaveRequest = function () //PhaseCalculatorPageManager_Type3 #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //PhaseCalculatorPageManager_Type3 #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //PhaseCalculatorPageManager_Type3 #17
	{
		GetFTECalculator(selector, initReqPgNs.getResourceTypeId(), pageManager);
	};

	this.getJobGrade = function () { return $.Calculator.getJobGrade(); } //PhaseCalculatorPageManager_Type3 #24
	this.getJobGradeInfoString = function () { return $.Calculator.getJobGradeInfoString(); } //PhaseCalculatorPageManager_Type3 #25
};
PhaseCalculatorPageManager_Type4 = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";

	this.Draw = function (withRegion) //PhaseCalculatorPageManager_Type4 #1
	{
		var resourceTypeDetails = initReqPgNs.getSelectedResourceTypeDetails();
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$(initReqPgNs.divCalculatorHolderSelector).show();
		$('#lblPreferredLocation').show();
		$('.initiateFieldPreferredRegion').show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$(initReqPgNs.initiateFieldTotalSitesSelector).show();

		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();
		if (initReqPgNs.isProposalProjectSelected()) { $(initReqPgNs.divNotesSelector).show(); }
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withRegion) {
			rm.dropdown.fill(initReqPgNs.ddlPreferredRegionSelector, rm.bizRules.getRegionListByResourceTypeId(resourceTypeDetails.Id), "Key", "Value", initReqPgNs.getRegionId(), true, false);
		}
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);

		displayCustomFields();
	};

	this.Validate = function () //PhaseCalculatorPageManager_Type4 #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!IsQipOtherCalculatorValid()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //PhaseCalculatorPageManager_Type4 #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //PhaseCalculatorPageManager_Type4 #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //PhaseCalculatorPageManager_Type4 #5
	{
		var resourceTypeDetails = initReqPgNs.getSelectedResourceTypeDetails();
		rm.dropdown.fill(initReqPgNs.ddlPreferredRegionSelector, rm.bizRules.getRegionListByResourceTypeId(resourceTypeDetails.Id), "Key", "Value", initReqPgNs.getRegionId(), true, false);
		rm.dropdown.fill(initReqPgNs.ddlPreferredCountrySelector, rm.bizRules.getCountryListByResourceTypeId(resourceTypeDetails.Id, initReqPgNs.getSelectedProjectId(), initReqPgNs.getSelectedRegionId()), "Key", "Value", initReqPgNs.getCountryId(), true, false);
	};

	this.GetOtherByResourceTypeCountry = function () //PhaseCalculatorPageManager_Type4 #7
	{
		$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		requestLocation = "";
		ShowDateIcon();
	};

	this.GetPreferredCountryByPreferredRegion = function () //PhaseCalculatorPageManager_Type4  #8
	{
		var resourceTypeDetails = initReqPgNs.getSelectedResourceTypeDetails();
		rm.dropdown.fill(initReqPgNs.ddlPreferredCountrySelector, rm.bizRules.getCountryListByResourceTypeId(resourceTypeDetails.Id, initReqPgNs.getSelectedProjectId(), initReqPgNs.getRegionIdFromUi()), "Key", "Value", initReqPgNs.getCountryId(), true, false);
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //PhaseCalculatorPageManager_Type4 #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlPreferredCountry', calculatorHeading, pageManager);
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //PhaseCalculatorPageManager_Type4 #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson) //PhaseCalculatorPageManager_Type4 #12
	{
		SetStartStopDateImage(hiddenJson);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) //PhaseCalculatorPageManager_Type4 #13
	{
		ShowDatesOnCountryOrPreferredCountryChange(pageManager);
		if ($("#txtStartDate").val() == "" && !ResourceTypeDetails[initReqPgNs.getResourceTypeId()].RequestStartDateConnectedMilestoneId && !initReqPgNs.isInEditMode())
			$("#txtStartDate").val(rm.date.getQDateStringFromDate(rm.date.today()));
	};
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };

	this.SetCalculatorValues = function (FTE, totalHours)  //PhaseCalculatorPageManager_Type4  #14
	{
		$.SmallFTECalculator.ClearCalculator();
	};

	this.SaveRequest = function () //PhaseCalculatorPageManager_Type4 #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //PhaseCalculatorPageManager_Type4 #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //PhaseCalculatorPageManager_Type4 #17
	{
		GetFTECalculator(selector, initReqPgNs.getResourceTypeId(), pageManager);
	};

	this.getJobGrade = function () { return $.Calculator.getJobGrade(); } //PhaseCalculatorPageManager_Type4 #24
	this.getJobGradeInfoString = function () { return $.Calculator.getJobGradeInfoString(); } //PhaseCalculatorPageManager_Type4 #25
};
RegionCalculatorPageManager_Type1 = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";

	this.Draw = function () //RegionCalculatorPageManager_Type1 #1
	{
		var pageManager = this;

		qipOtherCalculator.getRegionIdFromUi = initReqPgNs.getRegionIdFromUi;
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$(initReqPgNs.divCalculatorHolderSelector).show();
		$('#lblPreferredLocation').show();
		$('.initiateFieldPreferredRegion').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();
		if (initReqPgNs.isProposalProjectSelected()) { $(initReqPgNs.divNotesSelector).show(); }
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		$.Dropdown.PreferredRegion();
		//$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
		$("#txtStartDate").bind("change.rsul", function () { pageManager.UpdateRequestStopDate(initReqPgNs.getResourceTypeId(), initReqPgNs.getRegionIdFromUi()); });

		displayCustomFields();

		$("#ddlPreferredRegion").bind("change.regionbased", function (event) {
			handleRegionChange(initReqPgNs.getResourceTypeId(), $(this).val(), objPageManager);
		});
	};

	this.Validate = function () //RegionCalculatorPageManager_Type1 #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!IsQipOtherCalculatorValid()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //RegionCalculatorPageManager_Type1 #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //RegionCalculatorPageManager_Type1 #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //RegionCalculatorPageManager_Type1 #5
	{
		PopulateRegionAndCountry(false);
	};

	this.GetOtherByResourceTypeCountry = function () //RegionCalculatorPageManager_Type1 #7
	{
		$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		requestLocation = "";
	};

	//this.GetPreferredCountryByPreferredRegion = function () //RegionCalculatorPageManager_Type1  #8
	//{
	//	$.Dropdown.PreferredCountry();
	//};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //RegionCalculatorPageManager_Type1 #10
	{
		//if ($("#txtStartDate").val() == "" || !initReqPgNs.isInEditMode()) { //if dates should not change on updating the region in edit mode
		if ($("#txtStartDate").val() == "" || initReqPgNs.isRegionChanged()) { //dates should change on updating the region in edit mode
			$("#txtStartDate").val(rm.date.getQDateStringFromDate(rm.date.today()));
			setTimeout(function () { pageManager.UpdateRequestStopDate(initReqPgNs.getResourceTypeId(), initReqPgNs.getRegionIdFromUi()); }, 10);
		}
		DrawRegionBasedCalculator(onRequest, calculatorHeading, pageManager);
	};

	this.UpdateRequestStopDate = function (resourceTypeId, regionId) {
		updateRequestStopDateFromComputedRequestMilestone(resourceTypeId, regionId);
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //RegionCalculatorPageManager_Type1 #11
	{
		//var regionId = initReqPgNs.getRegionIdFromUi();
		//if (regionId == null || regionId == -1) {
		//	regionId = initReqPgNs.selectedRequestDetails.regionId;
		//}
		//return initReqPgNs.getRegionalConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), regionId);
	};

	this.SetStartStopDateImage = function (hiddenJson) //RegionCalculatorPageManager_Type1 #12
	{
		//SetStartStopDateImage(hiddenJson);
	};

	this.ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) { };//RegionCalculatorPageManager_Type1 #13

	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };

	this.SetCalculatorValues = function (FTE, totalHours)  //RegionCalculatorPageManager_Type1  #14
	{
		$.SmallFTECalculator.ClearCalculator();
	};

	this.SaveRequest = function () //RegionCalculatorPageManager_Type1 #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //RegionCalculatorPageManager_Type1 #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //RegionCalculatorPageManager_Type1 #17
	{
		GetFTECalculator(selector, initReqPgNs.getResourceTypeId(), pageManager);
	};

	this.getJobGrade = function () { return $.Calculator.getJobGrade(); } //RegionCalculatorPageManager_Type1 #24
	this.getJobGradeInfoString = function () { return $.Calculator.getJobGradeInfoString(); } //RegionCalculatorPageManager_Type1 #25
};
GlobalCalculatorPageManager_Type1 = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";
	var pageManager = this;
	this.Draw = function () //GlobalCalculatorPageManager_Type1 #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$(initReqPgNs.divCalculatorHolderSelector).show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		handleProposalResourceVisibility();
		if (initReqPgNs.isProposalProjectSelected()) { $(initReqPgNs.divNotesSelector).show(); }
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		$.Dropdown.PreferredRegion();
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
		$("#txtStartDate").bind("change.rsul", function () { pageManager.UpdateRequestStopDate(initReqPgNs.getResourceTypeId()); });
		displayCustomFields();
	};

	this.OnDrawComplete = function () {
		ShowDatesOnCountryOrPreferredCountryChange(objPageManager);
		DrawGlobalCalculator(false, calculatorHeading, objPageManager);
		if ($("#txtStartDate").val() == "") { //dates should change on updating the region in edit mode
			$("#txtStartDate").val(rm.date.getQDateStringFromDate(rm.date.today()));
			setTimeout(function () { pageManager.UpdateRequestStopDate(initReqPgNs.getResourceTypeId(), 0); }, 10);
		}
		else { pageManager.UpdateRequestStopDate(initReqPgNs.getResourceTypeId(), 0); }
	};

	this.Validate = function () //GlobalCalculatorPageManager_Type1 #2
	{
		var isValid = true;
		if (!CommonValidate()) { isValid = false; }
		if (!IsQipOtherCalculatorValid()) { isValid = false; }
		return isValid;
	};

	this.CleanError = function () //GlobalCalculatorPageManager_Type1 #3
	{
		CleanDurationError();
		$.SmallFTECalculator.ClearCalculator();
	};

	this.ChangeFrameSize = function () //GlobalCalculatorPageManager_Type1 #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //GlobalCalculatorPageManager_Type1 #5
	{ };

	this.GetOtherByResourceTypeCountry = function () //GlobalCalculatorPageManager_Type1 #7
	{
		$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
		requestLocation = "";
	};


	this.DrawCalculator = function (withCountry, onRequest, pageManager) //GlobalCalculatorPageManager_Type1 #10
	{
		DrawGlobalCalculator(onRequest, calculatorHeading, pageManager);
	};

	this.UpdateRequestStopDate = function (resourceTypeId) {
		updateRequestStopDateFromComputedRequestMilestone(resourceTypeId, 0);
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //GlobalCalculatorPageManager_Type1 #11
	{
		return initReqPgNs.getGlobalConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId());
	};

	this.SetStartStopDateImage = function (hiddenJson) //GlobalCalculatorPageManager_Type1 #12
	{
		SetStartStopDateImage(hiddenJson);
	};

	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };

	this.SetCalculatorValues = function (FTE, totalHours)  //GlobalCalculatorPageManager_Type1  #14
	{
		$.SmallFTECalculator.ClearCalculator();
	};

	this.SaveRequest = function () //GlobalCalculatorPageManager_Type1 #15
	{
		SaveRequestCommon();
	};

	this.UpdateRequest = function () //GlobalCalculatorPageManager_Type1 #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //GlobalCalculatorPageManager_Type1 #17
	{
		GetFTECalculator(selector, initReqPgNs.getResourceTypeId(), pageManager);
	};

	this.getJobGrade = function () { return $.Calculator.getJobGrade(); } //GlobalCalculatorPageManager_Type1 #24
	this.getJobGradeInfoString = function () { return $.Calculator.getJobGradeInfoString(); } //GlobalCalculatorPageManager_Type1 #25
};

//FlatFteCalculatorPageManager_Type1
FlatFteCalculatorPageManager_Type1 = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";

	this.Draw = function (withCountry) //FlatFteCalculatorPageManager_Type1 #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$(initReqPgNs.divCalculatorHolderSelector).show();
		$('.initiateFieldCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withCountry) {
			$.Dropdown.Country();
		}
		$.SmallFTECalculator.countrySelector = "#ddlCountry";
	};

	this.Validate = function () //FlatFteCalculatorPageManager_Type1 #2
	{
		var isValid = CommonValidate();
		if ($.trim($("#txtStartDate").val()) != "" && $.trim($("#txtStopDate").val()) != "" && $.trim($.SmallFTECalculator.GetValues().FTE) != "") {
			if (!$.SmallFTECalculator.save()) { isValid = false; }
		}
		return isValid;
	};

	this.CleanError = function () //FlatFteCalculatorPageManager_Type1 #3
	{
		CleanDurationError();
	};

	this.ChangeFrameSize = function () //FlatFteCalculatorPageManager_Type1 #4
	{
		ChangeFrameSize();
	};

	this.GetCountryByResourceType = function () //FlatFteCalculatorPageManager_Type1 #5
	{
		if (rmCommon.DisplayAllContries($.Dropdown.GetSelectedProjectDetails())) {
			$.Dropdown.AddItemsToDropdownByIdName($.InitiateRequest.GetAllCountries());
		}
		else {
			$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
		}
	};

	this.GetOtherByResourceType = function () //FlatFteCalculatorPageManager_Type1 #6
	{
		SetSiteDetails();
	};

	this.GetOtherByResourceTypeCountry = function () //FlatFteCalculatorPageManager_Type1 #7
	{
		GetSiteDetails();
		GetOtherByResourceTypeCountry();
		//var GetMethod = new Co_monitoring_NonSiteSpecific_PageManager();
		//GetMethod.CountryRegion();
		initReqPgNs.setCountryRegion();
		HideDateIcon();
		HideDateCountryIcon();
	};

	this.GetSite = function () //FlatFteCalculatorPageManager_Type1 #9
	{
		GetOtherByResourceTypeCountry(); //AI: Special case for Nonstandard_monitoring to handle SiteCOV date after double click the row in edit mode.
		GetSiteDetails();
	};

	this.DrawCalculator = function (withCountry, onRequest, pageManager) //FlatFteCalculatorPageManager_Type1 #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlCountry', calculatorHeading, pageManager);
		$.Calculator._interimFrequencyEnabled = false;
	};

	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) //FlatFteCalculatorPageManager_Type1 #11
	{
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //FlatFteCalculatorPageManager_Type1 #12  even the date is not populating from PPM but need this method to set Site Status readonly textbax.
	{
		pageManager.GetOtherByResourceType();
	};

	this.SetCalculatorValues = function (FTE, totalHours) //FlatFteCalculatorPageManager_Type1 #14
	{
		$.SmallFTECalculator.SetCalculatorValues(FTE, totalHours);
	};

	this.SaveRequest = function () //FlatFteCalculatorPageManager_Type1 #15
	{
		setTimeout(function () {
			if ($.Calculator.IsPromptRequiredForConnectDisconnectStatus()) {
				$.Calculator.DialogOkClickHandler = SaveNewInitiateRequest;
				$.Calculator.ShowConnectDisconnectChoiceDialog();
			}
			else {
				SaveNewInitiateRequest();
			}
		}, 100);
	};

	this.UpdateRequest = function () //FlatFteCalculatorPageManager_Type1 #16
	{
		UpdateRequestCommon();
	};

	this.GetFTECalculator = function (selector, pageManager) //FlatFteCalculatorPageManager_Type1 //AI: called this function on country change dropdown #17
	{
		GetSmallFTECalculator(pageManager, ResourceTypeName.Co_monitoring);
	};

	this.CountryRegion = function () //FlatFteCalculatorPageManager_Type1 #19
	{
		initReqPgNs.setCountryRegion();
		//var countryId = $('#ddlCountry').val();
		//var isCountryFound = false;
		//var DistinctCountryIds = $("#txtProjectName").data("DistinctCountryIds");

		//$.each(DistinctCountryIds, function (index, ele)
		//{
		//	if (ele == countryId)
		//	{
		//		$.Dropdown.CountryRegion(countryId, -1);
		//		$('.initiateFieldCountryRegion').show();
		//		isCountryFound = true;
		//		return false;
		//	}
		//});

		//if (!isCountryFound)
		//{
		//	$('.initiateFieldCountryRegion').hide();
		//}
	};

	this.SetCountryRegion = function (pageManager) //FlatFteCalculatorPageManager_Type1 #21
	{
		pageManager.CountryRegion();
	};

	this.getJobGrade = function () { return null; } //FlatFteCalculatorPageManager_Type1 #24
	this.getJobGradeInfoString = function () { return null; } //FlatFteCalculatorPageManager_Type1 #25

	this.handleStartStopDateChange = function () {
		$.SmallFTECalculator.CalculateTotalHours();
	};
};
//FlatFteCalculatorPageManager_Type1 End

//FlatFteCalculatorPageManager_Type2
FlatFteCalculatorPageManager_Type2 = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";
	this.Draw = function (withRegion) //FlatFteCalculatorPageManager_Type2 #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.

		var selectedResourceTypeId = initReqPgNs.getResourceTypeId();

		$(initReqPgNs.txtProposalFteSelector).attr("from", 0.01).attr("to", 1.5).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 1.5.");
		$('.initiateFieldPreferredRegion').show();
		$(initReqPgNs.lblProposalFteSelector).show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$("#txtStartDate,#txtStopDate").qDatepicker();
		$('.initiateFieldRequestBudgeted').show();
		handleNeedByDateVisibility();
		if (initReqPgNs.isProposalProjectSelected()) { $(initReqPgNs.divNotesSelector).show(); }
		$('.initiateNewRequestFields').show();
		setButton();
		$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withRegion) {
			$.Dropdown.PreferredRegion();
		}
		displayCustomFields();
	};

	this.Validate = function () //FlatFteCalculatorPageManager_Type2 #2
	{
		var isValid = CommonValidate();
		var txtFte = $(initReqPgNs.txtProposalFteSelector);

		if (!$.q.rangeValidate(txtFte)) { isValid = false; }

		return isValid;
	};

	this.CleanError = function () { CleanDurationError(); };//FlatFteCalculatorPageManager_Type2 #3
	this.ChangeFrameSize = function () //FlatFteCalculatorPageManager_Type2 #4
	{
		ChangeFrameSize();
	};
	this.GetCountryByResourceType = function () { PopulateRegionAndCountry(false); };
	this.GetOtherByResourceType = function () { };
	this.GetOtherByResourceTypeCountry = function () //FlatFteCalculatorPageManager_Type2 #7
	{
		$.Dropdown.AddItemsToDropdownByIdName($.InitiateRequest.GetAllCountries());
		HideDateIcon();
		HideDateCountryIcon();
	};
	this.GetPreferredCountryByPreferredRegion = function () //FlatFteCalculatorPageManager_Type2  #8
	{
		$.Dropdown.PreferredCountry();
	};
	//this.GetSite = function () { };//FlatFteCalculatorPageManager_Type2 #9
	this.DrawCalculator = function (withCountry, onRequest, pageManager) //FlatFteCalculatorPageManager_Type2 #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlCountry', calculatorHeading, pageManager);
		$.Calculator._interimFrequencyEnabled = false;
	};
	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) { };//FlatFteCalculatorPageManager_Type2 #11
	this.SetConnectedStartStopDateAttributes = function (startDate, stopDate, imDate, craTrainingDate) { };//FlatFteCalculatorPageManager_Type2 #11

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //FlatFteCalculatorPageManager_Type2 #12  even the date is not populating from PPM but need this method to set Site Status readonly textbax.
	{
		pageManager.GetOtherByResourceType();
	};
	//this.SetCalculatorValues = function (FTE, totalHours) { };//FlatFteCalculatorPageManager_Type2 #14
	this.SaveRequest = function () { SaveNewInitiateRequest(); };//FlatFteCalculatorPageManager_Type2 #15
	this.UpdateRequest = function () { UpdateRequestCommon(); };//FlatFteCalculatorPageManager_Type2 #16

	this.GetFTECalculator = function (selector, pageManager) { };//FlatFteCalculatorPageManager_Type2 //AI: called this function on country change dropdown #17
	this.CountryRegion = function () { };//FlatFteCalculatorPageManager_Type2 #19
	//this.SetCountryRegion = function (pageManager) { }; //FlatFteCalculatorPageManager_Type2 #21
	this.getJobGrade = function () { return null; } //FlatFteCalculatorPageManager_Type2 #24
	this.getJobGradeInfoString = function () { return null; } //FlatFteCalculatorPageManager_Type2 #25

	this.handleStartStopDateChange = function () { };

	this.SetDefaultProposalDates = function (selectedProjectDetails) //FlatFteCalculatorPageManager_Type2 #24
	{
		var startDate = rm.date.maxDate(rm.date.today(), rm.date.getDateFromQDateString(selectedProjectDetails.ExpectedStartDate));
		$("#txtStartDate").val(rm.date.getQDateStringFromDate(startDate));
		CalculateNeedByDate();
	};
};
//FlatFteCalculatorPageManager_Type2

//MonitoringCountrySpecificPageManager_Type1
MonitoringCountrySpecificPageManager_Type1 = function () {
	this.isCountrySelected = false;
	this.Draw = function (withCountry) //MonitoringCountrySpecificPageManager_Type1 #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
		$(initReqPgNs.txtProposalFteSelector).attr("formating", "2,2").attr("from", 0.01).attr("to", 20).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 20.0.");
		$('.initiateFieldCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$(initReqPgNs.lblProposalFteSelector).show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
		$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
		$("#txtStartDate,#txtStopDate").qDatepicker();
		handleNeedByDateVisibility();
		$('.initiateFieldRequestBudgeted').show();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		displayCustomFields();
		if (withCountry) { $.Dropdown.Country(); }
		else { this.isCountrySelected = true; }
		$("#txtStartDate,#txtStopDate,#txtCRATrainingDate,#txtIMDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);

	};
	this.OnDrawComplete = function () { if (!initReqPgNs.isInEditMode()) { $("#radioRequestBudgetedYes").attr("checked", true); } };
	this.Validate = function () //MonitoringCountrySpecificPageManager_Type1 #2
	{
		var isValid = CommonValidate();
		var txtFte = $(initReqPgNs.txtProposalFteSelector);

		if (!$.q.rangeValidate(txtFte)) { isValid = false; }

		return isValid;
	};

	this.CleanError = function () { CleanDurationError(); };//MonitoringCountrySpecificPageManager_Type1 #3
	this.ChangeFrameSize = function () { ChangeFrameSize(); };//MonitoringCountrySpecificPageManager_Type1 #4
	this.GetCountryByResourceType = function () //MonitoringCountrySpecificPageManager_Type1 #5
	{
		$.Dropdown.CountryFromJSON($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList);
	};
	this.GetOtherByResourceType = function () { };
	this.GetOtherByResourceTypeCountry = function () //MonitoringCountrySpecificPageManager_Type1 #7
	{
		ShowDateCountryIcon();
		rm.ui.ribbon.refresh();
	};
	this.GetPreferredCountryByPreferredRegion = function () //MonitoringCountrySpecificPageManager_Type1  #8
	{
		//$.Dropdown.PreferredCountry();
	};
	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) {//MonitoringCountrySpecificPageManager_Type1 #11
		return initReqPgNs.getConnectedDates(initReqPgNs.getResourceTypeId(), initReqPgNs.getSelectedProjectId(), initReqPgNs.getCountryId());
	};
	this.SetConnectedStartStopDateAttributes = function (startDate, stopDate, imDate, craTrainingDate) { };//MonitoringCountrySpecificPageManager_Type1 #11
	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Standard_Monitoring #12
	{
		SetStartStopCountryDateImage(hiddenJson);
		pageManager.GetOtherByResourceType();
	};
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute($("#ddlCountry").val()); }; //Standard_Monitoring #13
	this.ShowDisconnectedIconsForStartAndStopDates = function () { initReqPgNs.ShowPpmDisconnectedIconsForStartAndStopDates(); };
	this.SaveRequest = function () { SaveNewInitiateRequest(); };//MonitoringCountrySpecificPageManager_Type1 #15
	this.UpdateRequest = function () { UpdateRequestCommon(); };//MonitoringCountrySpecificPageManager_Type1 #16
	this.GetFTECalculator = function (selector, pageManager) {
		if (this.isCountrySelected) {
			if (confirm('You are changing the country location. Please select OK to retain the current start and stop dates. Click Cancel to reset and load the values for the new country.')) {
				this.ShowDisconnectedIconsForStartAndStopDates();
			}
			else {
				this.ShowDatesOnCountryOrPreferredCountryChange();
			}
		}
		else { this.ShowDatesOnCountryOrPreferredCountryChange(); }
		this.isCountrySelected = true;
	};//MonitoringCountrySpecificPageManager_Type1 //AI: called this function on country change dropdown #17
	this.CountryRegion = function () { };//MonitoringCountrySpecificPageManager_Type1 #19
	this.getJobGrade = function () { return null; } //MonitoringCountrySpecificPageManager_Type1 #24
	this.getJobGradeInfoString = function () { return null; } //MonitoringCountrySpecificPageManager_Type1 #25
	this.handleStartStopDateChange = function () { };
};
//MonitoringCountrySpecificPageManager_Type1 End

//Proposal_Base_PageManager
Proposal_Base_PageManager = function () {
	var calculatorHeading = initReqPgNs.getResourceTypeName() + " FTE Calculator";
	this.Draw = function (withRegion) //Proposal_Base_PageManager #1
	{
		resetBrush = new ResetBrush();
		resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.

		var selectedResourceTypeId = initReqPgNs.getResourceTypeId();
		if (selectedResourceTypeId == ResourceTypeName_E.DTE_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.DTE_Pharmacy_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.Non_DTE_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.Non_DTE_Pharmacy_CRA_Project_Country) {
			$(initReqPgNs.txtProposalFteSelector).attr("formating", "2,2").attr("from", 0.01).attr("to", 20).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 20.0.");
		}

		$('.initiateFieldPreferredRegion').show();
		$(initReqPgNs.lblProposalFteSelector).show();
		$(initReqPgNs.divNotesSelector).show();
		$('.initiateFieldPreferredCountry').show();
		$('.initiateFieldStartDate').show();
		$('.initiateFieldStopDate').show();
		$('#SpanStart').show();
		$('#SpanStop').show();
		$("#txtStartDate,#txtStopDate").qDatepicker();
		//$('.initiateFieldNeedByDate').show();
		handleNeedByDateVisibility();
		$('.initiateNewRequestFields').show();
		setButton();
		$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
		if (withRegion) {
			$.Dropdown.PreferredRegion();
		}
		$.GenericFTECalculator.countrySelector = "#ddlPreferredCountry";

	};

	this.Validate = function () //Proposal_Base_PageManager #2
	{
		var isValid = CommonValidate();
		var txtFte = $(initReqPgNs.txtProposalFteSelector);

		if (!$.q.rangeValidate(txtFte)) { isValid = false; }

		return isValid;
	};

	this.CleanError = function () { CleanDurationError(); };//Proposal_Base_PageManager #3
	this.ChangeFrameSize = function () //Proposal_Base_PageManager #4
	{
		ChangeFrameSize(true);
	};
	this.GetCountryByResourceType = function () { PopulateRegionAndCountry(false); };
	this.GetOtherByResourceType = function () { };
	this.GetOtherByResourceTypeCountry = function () //Proposal_Base_PageManager #7
	{
		$.Dropdown.AddItemsToDropdownByIdName($.InitiateRequest.GetAllCountries());
		HideDateIcon();
		HideDateCountryIcon();
	};
	this.GetPreferredCountryByPreferredRegion = function () //Proposal_Base_PageManager  #8
	{
		$.Dropdown.PreferredCountry();
	};
	//this.GetSite = function () { };//Proposal_Base_PageManager #9
	this.DrawCalculator = function (withCountry, onRequest, pageManager) //Proposal_Base_PageManager #10
	{
		DrawCalculator(withCountry, onRequest, '#ddlCountry', calculatorHeading, pageManager);
		$.Calculator._interimFrequencyEnabled = false;
	};
	this.GetConnectedStartStopDateValues = function (selectedProjectDetails) { };//Proposal_Base_PageManager #11
	this.SetConnectedStartStopDateAttributes = function (startDate, stopDate, imDate, craTrainingDate) { };//Proposal_Base_PageManager #11

	this.SetStartStopDateImage = function (hiddenJson, pageManager) //Proposal_Base_PageManager #12  even the date is not populating from PPM but need this method to set Site Status readonly textbax.
	{
		pageManager.GetOtherByResourceType();
	};
	//this.SetCalculatorValues = function (FTE, totalHours) { };//Proposal_Base_PageManager #14
	this.SaveRequest = function () { SaveNewInitiateRequest(); };//Proposal_Base_PageManager #15
	this.UpdateRequest = function () { UpdateRequestCommon(); };//Proposal_Base_PageManager #16

	this.GetFTECalculator = function (selector, pageManager) { };//Proposal_Base_PageManager //AI: called this function on country change dropdown #17
	this.CountryRegion = function () { };//Proposal_Base_PageManager #19
	//this.SetCountryRegion = function (pageManager) { }; //Proposal_Base_PageManager #21
	this.getJobGrade = function () { return null; } //Proposal_Base_PageManager #24
	this.getJobGradeInfoString = function () { return null; } //Proposal_Base_PageManager #25

	this.handleStartStopDateChange = function () { };

	this.SetDefaultProposalDates = function (selectedProjectDetails) //Proposal_Base_PageManager #24
	{
		var startDate = rm.date.maxDate(rm.date.today(), rm.date.getDateFromQDateString(selectedProjectDetails.ExpectedStartDate));
		$("#txtStartDate").val(rm.date.getQDateStringFromDate(startDate));
		$("#txtStopDate").val(rm.date.addMonthsToQdate(rm.date.getQDateStringFromDate(startDate), 6));
	};

};
//Proposal_Base_PageManager
// Validation start
CheckStartStopDate = function (checkStartDate, checkStopDate) {
	var isValid = true;
	if (checkStartDate) {
		if ($.trim($("#txtStartDate").val()) == "") {
			rm.validation.addError("#txtStartDate", Resources.StartDateIsBlank);
			isValid = false;
		}
		//else
		//{
		//	$.InitiateRequest._startDate = $.trim($("#txtStartDate").val());
		//}
	}
	//else
	//{
	//	$.InitiateRequest._startDate = "";
	//}

	if (checkStopDate) {
		if ($.trim($("#txtStopDate").val()) == "") {
			rm.validation.addError("#txtStopDate", Resources.StopDateIsBlank);
			isValid = false;
		}
		//else
		//{
		//	$.InitiateRequest._stopDate = $.trim($("#txtStopDate").val());
		//}
	}
	//else
	//{
	//	$.InitiateRequest._stopDate = "";
	//}
	return isValid;
};

CheckIMDate = function () {
	return true;
	//var isValid = true;
	//$.InitiateRequest._imDate = $.trim($("#txtIMDate").val());
	//return isValid;
};

CheckCRATrainingDate = function () {
	return true;
	//var isValid = true;
	//$.InitiateRequest._craTrainingDate = $.trim($("#txtCRATrainingDate").val());
	//return isValid;
};

CheckRequestBlinded = function () {
	var isValid = true;
	if ($('#initiateFieldBlindedSpan').is(":visible")) {
		if (!$("#radioblindedYes").is(":checked") && !$("#radioblindedNo").is(":checked")) {
			rm.validation.addError("#spanBlindedYes", Resources.RequestBlindedRequired);
			rm.validation.addError("#spanBlindedNo", Resources.RequestBlindedRequired);
			isValid = false;
		}
		else if ($("#radioblindedYes").is(":checked")) {
			$.InitiateRequest._requestUnblinded = "Yes";
			rm.validation.clearError($("#spanBlindedYes"));
			rm.validation.clearError($("#spanBlindedNo"));
		}
		else if ($("#radioblindedNo").is(":checked")) {
			$.InitiateRequest._requestUnblinded = "No";
			rm.validation.clearError($("#spanBlindedYes"));
			rm.validation.clearError($("#spanBlindedNo"));
		}
	}
	return isValid;
};


CheckRequestBudgeted = function () {
	var isValid = true;

	if ($("#initiateFieldRequestBudgetedSpan").is(":visible")) {
		if (!$("#radioRequestBudgetedYes").is(":checked") && !$("#radioRequestBudgetedNo").is(":checked")) {
			rm.validation.addError("#spanYes", Resources.RequestBudgetedRequired);
			rm.validation.addError("#spanNo", Resources.RequestBudgetedRequired);
			isValid = false;
		}
		else if ($("#radioRequestBudgetedYes").is(":checked")) {
			$.InitiateRequest._requestBudgeted = "Yes";
			rm.validation.clearError($("#spanYes"));
			rm.validation.clearError($("#spanNo"));
		}
		else if ($("#radioRequestBudgetedNo").is(":checked")) {
			$.InitiateRequest._requestBudgeted = "No";
			rm.validation.clearError($("#spanYes"));
			rm.validation.clearError($("#spanNo"));
		}

		if ($("#radioRequestBudgetedNo").is(":checked")) {
			if ($.trim($("#txtReason").val()) == "") {
				rm.validation.addError("#txtReason", Resources.ReasonRequired);
				isValid = false;
			}
			else {
				if ($("#radioRequestBudgetedNo").is(":checked")) {
					$.InitiateRequest._reason = $("#txtReason").val();
				}
			}
		}
	}
	return isValid;
};

CommonValidate = function () {
	$.InitiateRequest._projectCode = -1;
	//$.InitiateRequest._resourceRequestType = -1;
	$.InitiateRequest._Organization = -1;
	$.InitiateRequest._country = -1;
	$.InitiateRequest._regionId = -1;
	$.InitiateRequest._preferredRegion = -1;
	$.InitiateRequest._siteId = -1;
	$.InitiateRequest._visitType = -1;
	$.InitiateRequest._SSVType = -1;
	$.InitiateRequest._reason = "";
	$.InitiateRequest._duration = -1;
	$.InitiateRequest._requestBudgeted = "";

	var isValid = true;
	if ($('#txtProjectName').val() == null || $('#txtProjectName').val() == "") {
		rm.validation.addError("#ddlProjectName", Resources.ProjectCodeRequired);
		isValid = false;
	}
	else {
		rm.validation.clearError($("#txtProjectName"));
		$.InitiateRequest._projectCode = $.InitiateRequest._selectedProjectID;
	}

	if ($('#ddlResourceType').val() == null || $('#ddlResourceType').val() == -1) {
		rm.validation.addError("#ddlResourceType", Resources.ResourceRequestTypeRequired);
		isValid = false;
	}
	else {
		rm.validation.clearError($("#ddlResourceType"));
		//$.InitiateRequest._resourceRequestType = $('#ddlResourceType').val();

	}
	if ($('#ddlOrganization').val() == null || $('#ddlOrganization').val() == -1) {
		rm.validation.addError("#ddlOrganization", Resources.OrganizationRequired);
		isValid = false;
	}
	else {
		rm.validation.clearError($("#ddlOrganization"));
		$.InitiateRequest._Organization = $('#ddlOrganization').val();

	}

	if ($('.initiateFieldCountry').is(":visible")) {
		if ($('#ddlCountry').val() == null || $('#ddlCountry').val() == -1) {
			rm.validation.addError("#ddlCountry", Resources.CountryRequired);
			isValid = false;
		}
		else {
			rm.validation.clearError($("#ddlCountry"));
			$.InitiateRequest._country = $('#ddlCountry').val();
			//$.InitiateRequest._countryName = $('#ddlCountry option:selected').text();
		}
	}

	if ($('.initiateFieldPreferredRegion').is(":visible")) {
		if ($('#ddlPreferredRegion').val() == null || $('#ddlPreferredRegion').val() == -1) {
			rm.validation.addError("#ddlPreferredRegion", Resources.PreferredRegionRequired);
			isValid = false;
		}
		else {
			$.InitiateRequest._preferredRegion = $('#ddlPreferredRegion').val();
			$.InitiateRequest._region = $('#ddlPreferredRegion option:selected').text();
			$.InitiateRequest._regionId = $('#ddlPreferredRegion').val();
			rm.validation.clearError($("#ddlPreferredRegion"));
		}
	}

	if ($('.initiateFieldPreferredCountry').is(":visible")) {
		if ($('#ddlPreferredCountry').val() == null || $('#ddlPreferredCountry').val() == -1) {
			rm.validation.addError("#ddlPreferredCountry", Resources.PreferredCountryRequired);
			isValid = false;
		}
		else {
			$.InitiateRequest._country = $('#ddlPreferredCountry').val();
			rm.validation.clearError($("#ddlPreferredCountry"));
		}
	}

	if ($('.initiateFieldSiteID').is(":visible")) {
		if ($('#ddlSiteId').val() == null || $('#ddlSiteId').val() == -1) {
			rm.validation.addError("#ddlSiteId", Resources.SiteIdRequired);
			isValid = false;
		}
		else {
			rm.validation.clearError($("#ddlSiteId"));
			$.InitiateRequest._siteId = $('#ddlSiteId').val();
		}
	}

	if ($('.initiateFieldAssignedRegionList').is(":visible")) {
		if ($.InitiateRequest._regionIds == "") {
			rm.validation.addError("#spanAssignedRegionList", Resources.AssignedRegionRequired);
			isValid = false;
		}
		else {
			$("#spanAssignedRegionList").removeClass(rm.validation.errorClass)
			rm.qtip.clear("#spanAssignedRegionList");
		}
	}

	if ($('.initiateFieldAssignedCountryList').is(":visible")) {
		if ($.InitiateRequest._countryIds == "") {
			rm.validation.addError("#spanAssignedCountryList", Resources.CountryRegionRequired);
			isValid = false;
		}
		else {
			$("#spanAssignedCountryList").removeClass(rm.validation.errorClass)
			rm.qtip.clear("#spanAssignedCountryList");
		}
	}

	if ($('.initiateFieldTotalSites').is(":visible")) {
		var totalSitesTextBox = $(initReqPgNs.txtTotalSitesSelector);
		if (totalSitesTextBox.is(":visible") && !rm.validation.range.validate(totalSitesTextBox)) {
			isValid = false;
		}
	}

	if ($('.initiateFieldCountryRegion').is(":visible")) {
		if (!ValidateCountryRegion()) { isValid = false; }
	}

	if ($('.initiateFieldVisitType').is(":visible")) {
		if (!ValidateVisitType()) { isValid = false; }
	}

	if (!CheckStartStopDate(true, true)) { isValid = false; }

	if ($('.initiateFieldIMDate').is(":visible")) {
		if (!CheckIMDate()) { isValid = true; } //AI: make IM Date optional
	}

	if ($('.initiateFieldCRATrainingDate').is(":visible")) {
		if (!CheckCRATrainingDate()) { isValid = true; } //AI: make IM Date optional
	}

	if ($('.initiateFieldSSVType').is(":visible")) {
		if (!ValidateSSVType()) { isValid = false; }
	}

	if (!CheckRequestBudgeted()) { isValid = false; }
	if (!CheckRequestBlinded()) { isValid = false; }

	if ($('.initiateFieldDuration').is(":visible")) {
		if ($.trim($("#txtDuration").val()) == "") {
			rm.validation.addError("#txtDuration", Resources.DurationRequired);
			isValid = false;
		}
		else {
			rm.validation.clearError($("#txtDuration"));
			$.InitiateRequest._duration = $("#txtDuration").val();
		}
	}

	return isValid;
};

ValidateCountryRegion = function () {
	var isValid = true;
	if ($('#ddlCountryRegion').val() == -1 && !initReqPgNs.isCountryRegionOptional) {
		rm.validation.addError("#ddlCountryRegion", Resources.CountryRegionRequired);
		isValid = false;
	}
	else {
		$.InitiateRequest._countryRegion = $('#ddlCountryRegion').val();
		isValid = true;
	}
	return isValid;
};

ValidateVisitType = function () {
	var isValid = true;
	if ($('#ddlVisitType').val() == -1) {
		rm.validation.addError("#ddlVisitType", Resources.VisitTypeRequired);
		isValid = false;
	}
	else {
		$.InitiateRequest._visitType = $('#ddlVisitType').val();
		isValid = true;
	}
	return isValid;
};

ValidateSSVType = function () {
	var isValid = true;
	if ($('#ddlSSVType').val() == -1) {
		rm.validation.addError("#ddlSSVType", Resources.SSVTypeRequired);
		isValid = false;
	}
	else {
		$.InitiateRequest._SSVType = $('#ddlSSVType').val();
		isValid = true;
	}
	return isValid;
};
// Validation end

CleanAllError = function () {
	$.InitiateRequest._duration = -1;
	rm.validation.clearAllErrors(".q_validation_error");
	rm.validation.clearError("#txtStartDate");

	rm.grid.clearGridError("#listRequest", "Message");
	rm.ui.messages.clearAllMessages();
};

CleanDurationError = function () {
	rm.validation.clearError($("#txtDuration"));
	$.InitiateRequest._duration = -1;
};
CleanValidationErrors = function () {
	$.InitiateRequest._duration = -1;
	rm.validation.clearAllErrors(".q_validation_error");
};
setButton = function () {
	if (initReqPgNs.isInEditMode()) {
		$.InitiateRequest._isModifyRequest = true;
		$(document).on("change keypress click", "#divCalculator input,#divCalculator select,.initiateNewRequestFields input, .initiateNewRequestFields select, .imgDeleteGenericRow, .imgStartMilestone, .imgEndMilestone, .imgDeleteGenereicAdhoc", function () {
			if ((this.className == "imgDeleteGenericRow" || this.className == "imgDeleteGenereicAdhoc") && $.GenericFTECalculator._enableSaveButton)//SS:dont enable the update button if only one stage calculator is available and user clicked on delete image. 
				SetCancelUpdateButtonEnabled();
			else if (this.className != "imgDeleteGenericRow" && this.className != "imgDeleteGenereicAdhoc")
				SetCancelUpdateButtonEnabled();
		});
	}
	else {
		$.InitiateRequest._isModifyRequest = false;
	}
	$.Calculator._interimFrequencyEnabled = false;
	$.GenericFTECalculator._interimFrequencyEnabled = false;
};

SetCancelUpdateButtonEnabled = function () {
	rm.ui.ribbon.refresh();
};

PopulateRegionAndCountry = function (populateAssignRegion) {
	$.rm.Ajax_Utility("Geography/GetRegions", "", function (data) {
		$.Dropdown.Fill("#ddlPreferredRegion", $.parseJSON(data), "Id Name");

		var postData = {
			regionIds: initReqPgNs.getRegionId()// hiddenJson.RegionId
		};

		$.rm.Ajax_Utility("GetAllCountriesByRegion", postData, function (data) {
			$.Dropdown.Fill("#ddlPreferredCountry", data, "key value");

			if (populateAssignRegion) {
				$.Dropdown.GetAssignedRegionCountry(initReqPgNs.getRequestId());
			}
		}, true, true);
	}, true, true);
};

ChangeFrameSize = function (hideReason) {
	if ($("#radioRequestBudgetedYes").is(":checked") || hideReason) {
		$("#txtReason").empty();
		rm.validation.clearError($("#txtReason"));
		$("#lblRemainingLength").html("250");
		$('.initiateFieldReason').hide();
	}
	else if ($("#radioRequestBudgetedNo").is(":checked")) {
		$('.initiateFieldReason').show();
	}
};

DrawSsvCountrySpecificCalculator = function (withCountry, onRequest, selector, caption, pageManager) {
	if ($.Calculator._countryId != null) {
		$(".FTE_Calculator").hide();
		$(".GenericFTE_Calculator").hide();
		$(".Small_FTE_Calculator").hide();
		$(".SSVCountry_FTE_Calculator").show();
		if (onRequest) {
			SSVCountryCalculatorNs.renderCalculator(initReqPgNs.getRequestId(), null, $("#ddlResourceType").val(), null, caption);

		}
		else if (withCountry) {
			SSVCountryCalculatorNs.renderCalculator(null, $.InitiateRequest._selectedProjectID, $("#ddlResourceType").val(), $(selector).val(), caption);
		}
	}
};

DrawSmallFteCalculator = function (withCountry, onRequest, selector, caption, pageManager) {
	smallCalculator.getCountryIdForFteCalculation = initReqPgNs.getCountryId;
	smallCalculator.getJobRoleIdForFteCalculation = function () { return ResourceTypeDetails[initReqPgNs.getResourceTypeId()].JobRoleId; };
	if ($.Calculator._countryId != null) {
		$(".FTE_Calculator").hide();
		$(".GenericFTE_Calculator").hide();
		$(".SSVCountry_FTE_Calculator").hide();
		$(".Small_FTE_Calculator").show();
		if (onRequest) {
			$.SmallFTECalculator.renderCalculator(initReqPgNs.getRequestId(), null, $("#ddlResourceType").val(), null, caption);

		}
		else if (withCountry) {
			$.SmallFTECalculator.renderCalculator(null, $.InitiateRequest._selectedProjectID, $("#ddlResourceType").val(), $(selector).val(), caption);
		}
	}
};
DrawGenericCalculator = function (withCountry, onRequest, selector, caption, pageManager) {
	$.GenericFTECalculator._resourceId = $("#ddlResourceType").val();
	$.GenericFTECalculator._countryId = $(selector).val();
	genericCalculator.getRequestStopDateFromUi = initReqPgNs.getStopDate;
	genericCalculator.getCountryIdForFteCalculation = initReqPgNs.getCountryId;
	genericCalculator.getJobRoleIdForFteCalculation = function () { return ResourceTypeDetails[initReqPgNs.getResourceTypeId()].JobRoleId; };

	$(".FTE_Calculator").hide();
	$(".GenericFTE_Calculator").show();
	$(".Small_FTE_Calculator").hide();
	$(".SSVCountry_FTE_Calculator").hide();
	$.GenericFTECalculator._interimFrequencyEnabled = true;
	$.Calculator._fireChangeEvent = true;
	if (onRequest) {
		$.GenericFTECalculator.renderCalculator(initReqPgNs.getRequestId(), $.InitiateRequest._selectedProjectID, $("#ddlResourceType").val(), $(selector).val(), caption, true, $('#ddlOrganization').val());
	}
	else if (withCountry) {
		$.GenericFTECalculator.renderCalculator(null, $.InitiateRequest._selectedProjectID, $("#ddlResourceType").val(), $(selector).val(), caption, true, $('#ddlOrganization').val());
	}
	else {
		$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) {
			$.InitiateRequest.OnCountryPopulate = function () {
				if (countryId != -1) {
					$("#ddlPreferredCountry").val(countryId);
					ShowDatesOnCountryOrPreferredCountryChange(pageManager);
					$.Calculator._countryId = countryId;
				}
			};
			if (regionId != -1) {
				$("#ddlPreferredRegion").val(regionId);
				$("#ddlPreferredRegion").change();
			}
			$.Calculator.OnCalculatorRenderComplete = function () { };
		};

		$.Calculator.renderCalculator(null, $.InitiateRequest._selectedProjectID, $("#ddlResourceType").val(), 0, caption, true, null, null);
	}
	rm.ui.ribbon.refresh();
};
DrawPhaseCalculator = function (withCountry, onRequest, selector, caption, pageManager) {
	$(".FTE_Calculator").show();
	$(".GenericFTE_Calculator").hide();
	$(".Small_FTE_Calculator").hide();
	$(".SSVCountry_FTE_Calculator").hide();
	$.Calculator._interimFrequencyEnabled = true;
	$.Calculator._fireChangeEvent = true;
	if (onRequest) {
		$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) {
			initReqPgNs.phaseCalculatorRenderCompleteHandlerForProposal(regionId, countryId, qipData);
			$.Calculator.OnCalculatorRenderComplete = function () { };
		};
		$.Calculator.renderCalculator(initReqPgNs.getRequestId(), null, $("#ddlResourceType").val(), null, caption, true, initReqPgNs.getRegionIdFromUi(), initReqPgNs.getRequestId());
	}
	else if (withCountry) {
		$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) {
			initReqPgNs.phaseCalculatorRenderCompleteHandlerForProposal(regionId, countryId, qipData);
			$.Calculator.OnCalculatorRenderComplete = function () { };
		};
		$.Calculator.renderCalculator(null, $.InitiateRequest._selectedProjectID, $("#ddlResourceType").val(), $(selector).val(), caption, true, null, initReqPgNs.getRequestId());
	}
	else {
		$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) {
			$.InitiateRequest.OnCountryPopulate = function () {
				if (countryId != -1) {
					$("#ddlPreferredCountry").val(countryId);
					ShowDatesOnCountryOrPreferredCountryChange(pageManager);
					$.Calculator._countryId = countryId;
				}
			};
			if (regionId != -1) {
				$("#ddlPreferredRegion").val(regionId);
				$("#ddlPreferredRegion").change();
			}
			initReqPgNs.phaseCalculatorRenderCompleteHandlerForProposal(regionId, countryId, qipData);
			$.Calculator.OnCalculatorRenderComplete = function () { };
		};

		$.Calculator.renderCalculator(null, $.InitiateRequest._selectedProjectID, $("#ddlResourceType").val(), 0, caption, true, null, initReqPgNs.getRequestId());
	}
	rm.ui.ribbon.refresh();
};

DrawCalculator = function (withCountry, onRequest, selector, caption, pageManager) {
	qipOtherCalculator.isRegionBasedCalculator = false;
	qipOtherCalculator.isGlobalCalculator = false;
	qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return initReqPgNs.isProposalProjectSelected(); };
	qipOtherCalculator.getRequestStopDateFromUi = initReqPgNs.getStopDate;
	qipOtherCalculator.getCountryIdForFteCalculation = initReqPgNs.getCountryId;
	qipOtherCalculator.getJobRoleIdForFteCalculation = function () { return ResourceTypeDetails[initReqPgNs.getResourceTypeId()].JobRoleId; };

	$.Calculator._resourceTypeId = $("#ddlResourceType").val();
	$.Calculator._countryId = $(selector).val();

	if ($.Calculator._PageManager != "") {
		if ($.Calculator._PageManager == "Co_monitoring_PageManager" || $.Calculator._PageManager == "FlatFteCalculatorPageManager_Type1") {
			DrawSmallFteCalculator(withCountry, onRequest, selector, caption, pageManager);
		}
		else if ($.Calculator._PageManager == "Generic_PageManager") {
			DrawGenericCalculator(withCountry, onRequest, selector, caption, pageManager);
		}
		else {
			DrawPhaseCalculator(withCountry, onRequest, selector, caption, pageManager);
		}
	}
};
DrawGlobalCalculator = function (onRequest, caption, pageManager) {
	$.Calculator._resourceTypeId = initReqPgNs.getResourceTypeId();
	qipOtherCalculator.getOrganizationIdFromUi = initReqPgNs.getOrganizationId;
	qipOtherCalculator.isRegionBasedCalculator = false;
	qipOtherCalculator.isGlobalCalculator = true;
	qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return initReqPgNs.isProposalProjectSelected(); };
	qipOtherCalculator.getRequestStopDateFromUi = initReqPgNs.getStopDate;

	if ($.Calculator._PageManager != "") {
		$(".FTE_Calculator").show();
		$(".GenericFTE_Calculator").hide();
		$(".Small_FTE_Calculator").hide();
		$(".SSVCountry_FTE_Calculator").hide();
		$.Calculator._interimFrequencyEnabled = true;
		$.Calculator._fireChangeEvent = true;

		$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) {
			initReqPgNs.phaseCalculatorRenderCompleteHandlerForProposal(regionId, countryId, qipData);
			$.Calculator.OnCalculatorRenderComplete = function () { };
		};

		if (onRequest) {
			$.Calculator.renderCalculator(initReqPgNs.getRequestId(), null, initReqPgNs.getResourceTypeId(), null, caption, true, initReqPgNs.getRegionIdFromUi(), initReqPgNs.getRequestId(), initReqPgNs.getOrganizationId());
		}
		else {
			$.Calculator.renderCalculator(null, $.InitiateRequest._selectedProjectID, initReqPgNs.getResourceTypeId(), null, caption, true, initReqPgNs.getRegionIdFromUi(), initReqPgNs.getRequestId(), initReqPgNs.getOrganizationId());
		}
		rm.ui.ribbon.refresh();
	}
};
DrawRegionBasedCalculator = function (onRequest, caption, pageManager) {
	$.Calculator._resourceTypeId = initReqPgNs.getResourceTypeId();
	qipOtherCalculator.isRegionBasedCalculator = true;
	qipOtherCalculator.isGlobalCalculator = false;
	qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return initReqPgNs.isProposalProjectSelected(); };
	qipOtherCalculator.getRequestStopDateFromUi = initReqPgNs.getStopDate;

	if ($.Calculator._PageManager != "") {
		$(".FTE_Calculator").show();
		$(".GenericFTE_Calculator").hide();
		$(".Small_FTE_Calculator").hide();
		$(".SSVCountry_FTE_Calculator").hide();
		$.Calculator._interimFrequencyEnabled = true;
		$.Calculator._fireChangeEvent = true;

		$.Calculator.OnCalculatorRenderComplete = function (regionId, countryId, qipData) {
			initReqPgNs.phaseCalculatorRenderCompleteHandlerForProposal(regionId, countryId, qipData);
			$.Calculator.OnCalculatorRenderComplete = function () { };
		};
		if (onRequest) {
			$.Calculator.renderCalculator(initReqPgNs.getRequestId(), null, initReqPgNs.getResourceTypeId(), null, caption, true, initReqPgNs.getRegionIdFromUi(), initReqPgNs.getRequestId());
		}
		else {
			$.Calculator.renderCalculator(null, $.InitiateRequest._selectedProjectID, initReqPgNs.getResourceTypeId(), null, caption, true, initReqPgNs.getRegionIdFromUi(), initReqPgNs.getRequestId());
		}
		rm.ui.ribbon.refresh();
	}

};

GetOtherByResourceTypeCountry = function () {
	for (var i = 0; i < $.InitiateRequest._initiateRequestJSON.MonitoringAttributeList.length; i++) {
		if ($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList[i].CountryId == $("#ddlCountry").val()) {
			$("#txtDuration").val("");
			$.InitiateRequest._region = $.InitiateRequest._initiateRequestJSON.MonitoringAttributeList[i].RegionName;
			$.InitiateRequest._requestLocation = "";
			break;
		}
	}
};


SetDateCountryImageByFlag = function (connectFlag, selector) {
	if (RequestConnect_E.Disconnected == connectFlag) {
		$.InitiateRequest.AppendDisconnectedCountryImage(selector);
	}
	else {
		$.InitiateRequest.AppendConnectedCountryImage(selector);
	}
};

SetDateImageByFlag = function (connectFlag, selector) {
	if (RequestConnect_E.Disconnected == connectFlag) {
		$.InitiateRequest.AppendDisconnectedImage(selector);
	}
	else {
		$.InitiateRequest.AppendConnectedImage(selector);
	}
};

SetStartStopCountryDateImage = function (hiddenJson) {
	SetDateCountryImageByFlag(hiddenJson.StartDateStatus.connected, $("#txtStartDate"));
	SetDateCountryImageByFlag(hiddenJson.StopDateStatus.connected, $("#txtStopDate"));
	SetDateCountryImageByFlag(hiddenJson.IMDateStatus.connected, $("#txtIMDate"));
	SetDateCountryImageByFlag(hiddenJson.CRADateStatus.connected, $("#txtCRATrainingDate"));
};

SetStartStopDateImage = function (hiddenJson) {
	SetDateImageByFlag(hiddenJson.StartDateStatus.connected, $("#txtStartDate"));
	SetDateImageByFlag(hiddenJson.StopDateStatus.connected, $("#txtStopDate"));
};

SetIMDateImage = function (hiddenJson) {
	SetDateImageByFlag(hiddenJson.IMDateStatus.connected, $("#txtIMDate"));
};

SetCRATrainingDateImage = function (hiddenJson) {
	SetDateImageByFlag(hiddenJson.CRADateStatus.connected, $("#txtCRATrainingDate"));
};

SetIMDateCountryImage = function (hiddenJson) {
	SetDateCountryImageByFlag(hiddenJson.IMDateStatus.connected, $("#txtIMDate"));
};

SetCRATrainingDateCountryImage = function (hiddenJson) {
	SetDateCountryImageByFlag(hiddenJson.CRADateStatus.connected, $("#txtCRATrainingDate"));
};

ShowDatesOnCountryOrPreferredCountryChange = function (pageManager) {
	var startDateControl = $("#txtStartDate");
	var stopDateControl = $("#txtStopDate");

	if (!initReqPgNs.isProposalProjectSelected()) {
		var selectedProjectDetails = $.Dropdown.GetSelectedProjectDetails();
		var connectedValues = RunMethod(pageManager, "GetConnectedStartStopDateValues", selectedProjectDetails);
		var startDateValue = connectedValues.startDate;

		$.InitiateRequest.SetConnectedStartStopDateAttributes(connectedValues.startDate, connectedValues.stopDate, "", "");

		if (connectedValues.startDate != "") {
			if (rm.date.isQDateDateInPast(connectedValues.startDate)) {
				startDateValue = rm.date.getQDateStringFromDate(new Date());
				$.InitiateRequest.AppendDisconnectedImage(startDateControl);
			}
			else {
				$.InitiateRequest.AppendConnectedImage(startDateControl);
			}
		}
		else {
			$.InitiateRequest.AppendDisconnectedImage(startDateControl);
		}

		if (connectedValues.stopDate != "") {
			$.InitiateRequest.AppendConnectedImage(stopDateControl);
		}
		else {
			$.InitiateRequest.AppendDisconnectedImage(stopDateControl);
		}
		startDateControl.val(startDateValue);
		stopDateControl.val(connectedValues.stopDate);
		setNeedByDate(startDateValue, initReqPgNs.getResourceTransitionTimeInDays());

		rm.validation.clearError($("#txtStartDate"));
		rm.validation.clearError($("#txtStopDate"));
	}
};

ShowConnectDisconnectPPMIcon = function () {
	if (!ResourceTypeDetails[initReqPgNs.getResourceTypeId()].ShowStartDateConnectDisconnectIcon)
		$("#txtStartDate").parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
	if (!ResourceTypeDetails[initReqPgNs.getResourceTypeId()].ShowStopDateConnectDisconnectIcon)
		$("#txtStopDate").parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
};

SetDatesOnCountryOrPreferredCountryChangeFromSsvAttribute = function (countryId) {
	if ($.InitiateRequest._initiateRequestJSON != null) {
		for (var i = 0; i < $.InitiateRequest._initiateRequestJSON.SSVAttributeList.length; i++) {
			var connectedValues = $.InitiateRequest._initiateRequestJSON.SSVAttributeList[i];
			if (connectedValues.CountryId == countryId) {
				var startDateControl = $("#txtStartDate");
				var stopDateControl = $("#txtStopDate");
				var craTrainingDateControl = $("#txtCRATrainingDate");

				$.InitiateRequest.SetConnectedStartStopDateAttributes(connectedValues.SSVAttrbuteStartDate, connectedValues.SSVAttrbuteStopDate, "", connectedValues.CRATrainingDate);

				$.InitiateRequest.SetDateCountryImage(connectedValues.SSVAttrbuteStartDate, startDateControl);
				$.InitiateRequest.SetDateCountryImage(connectedValues.SSVAttrbuteStopDate, stopDateControl);
				$.InitiateRequest.SetDateCountryImage(connectedValues.CRATrainingDate, craTrainingDateControl);

				break;
			}
		}
	}
};

ShowDatesOnCountryOrPreferredCountryChangeFromSsvAttribute = function (countryId) {
	$("#txtCRATrainingDate").val("");

	if ($.InitiateRequest._initiateRequestJSON != null) {
		for (var i = 0; i < $.InitiateRequest._initiateRequestJSON.SSVAttributeList.length; i++) {
			var connectedValues = $.InitiateRequest._initiateRequestJSON.SSVAttributeList[i];
			if (connectedValues.CountryId == countryId) {
				var startDateControl = $("#txtStartDate");
				var stopDateControl = $("#txtStopDate");
				var craTrainingDateControl = $("#txtCRATrainingDate");
				var startDateValue = connectedValues.SSVAttrbuteStartDate;

				$.InitiateRequest.SetConnectedStartStopDateAttributes(connectedValues.SSVAttrbuteStartDate, connectedValues.SSVAttrbuteStopDate, "", connectedValues.CRATrainingDate);

				if (connectedValues.SSVAttrbuteStartDate != "") {
					if (rm.date.isQDateDateInPast(connectedValues.SSVAttrbuteStartDate)) {
						startDateValue = rm.date.getQDateStringFromDate(new Date());
						$.InitiateRequest.AppendDisconnectedCountryImage(startDateControl);
					}
					else {
						$.InitiateRequest.AppendConnectedCountryImage(startDateControl);
					}
				}
				else {
					$.InitiateRequest.AppendDisconnectedCountryImage(startDateControl);
				}

				if (connectedValues.SSVAttrbuteStopDate != "") {
					$.InitiateRequest.AppendConnectedCountryImage(stopDateControl);
				}
				else {
					$.InitiateRequest.AppendDisconnectedCountryImage(stopDateControl);
				}

				//Always show CRA Training date connected
				$.InitiateRequest.AppendConnectedCountryImage(craTrainingDateControl);

				startDateControl.val(startDateValue);
				stopDateControl.val(connectedValues.SSVAttrbuteStopDate);
				setNeedByDate(startDateValue, initReqPgNs.getResourceTransitionTimeInDays());
				craTrainingDateControl.val(connectedValues.CRATrainingDate);

				rm.validation.clearError($("#txtStartDate"));
				rm.validation.clearError($("#txtStopDate"));
				rm.validation.clearError($("#txtCRATrainingDate")); //Always clear CRA Training date error

				break;
			}
		}
	}
};

SetDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute = function (countryId) {
	var bindStartDateFromMonitoringAttribute = true;
	if ($('#ddlResourceType').val() == ResourceTypeName.DTESite_Monitoring ||
		$('#ddlResourceType').val() == ResourceTypeName.Standard_Monitoring ||
		$('#ddlResourceType').val() == ResourceTypeName.DTEPharmacy_Monitoring ||
		$('#ddlResourceType').val() == ResourceTypeName.Pharmacy_Monitoring ||
		$('#ddlResourceType').val() == ResourceTypeName.iCRA_Monitoring) {
		bindStartDateFromMonitoringAttribute = false;
	}
	if ($.InitiateRequest._initiateRequestJSON != null) {
		for (var i = 0; i < $.InitiateRequest._initiateRequestJSON.MonitoringAttributeList.length; i++) {
			var connectedValues = $.InitiateRequest._initiateRequestJSON.MonitoringAttributeList[i];
			if (connectedValues.CountryId == countryId) {
				var startDateControl = $("#txtStartDate");
				var stopDateControl = $("#txtStopDate");
				var imDateControl = $("#txtIMDate");
				var craTrainingDateControl = $("#txtCRATrainingDate");

				$.InitiateRequest.SetConnectedStartStopDateAttributes(connectedValues.MonAttrbuteStartDate, connectedValues.MonAttrbuteStopDate, connectedValues.IMDate, connectedValues.CRATrainingDate);
				if (bindStartDateFromMonitoringAttribute) {
					$.InitiateRequest.SetDateCountryImage(connectedValues.MonAttrbuteStartDate, startDateControl);
				}
				$.InitiateRequest.SetDateCountryImage(connectedValues.MonAttrbuteStopDate, stopDateControl);
				$.InitiateRequest.SetDateCountryImage(connectedValues.IMDate, imDateControl);
				$.InitiateRequest.SetDateCountryImage(connectedValues.CRATrainingDate, craTrainingDateControl);

				break;
			}
		}
	}
};

ShowDatesOnCountryOrPreferredCountryChangeFromMonitoringAttribute = function (countryId) {
	var bindStartDateFromMonitoringAttribute = true;
	if ($('#ddlResourceType').val() == ResourceTypeName.DTESite_Monitoring ||
		$('#ddlResourceType').val() == ResourceTypeName.Standard_Monitoring ||
		$('#ddlResourceType').val() == ResourceTypeName.DTEPharmacy_Monitoring ||
		$('#ddlResourceType').val() == ResourceTypeName.Pharmacy_Monitoring ||
		$('#ddlResourceType').val() == ResourceTypeName.iCRA_Monitoring) {
		bindStartDateFromMonitoringAttribute = false;
	}

	$("#txtIMDate").val("");
	$("#txtCRATrainingDate").val("");
	if ($.InitiateRequest._initiateRequestJSON != null) {
		for (var i = 0; i < $.InitiateRequest._initiateRequestJSON.MonitoringAttributeList.length; i++) {
			var connectedValues = $.InitiateRequest._initiateRequestJSON.MonitoringAttributeList[i];
			if (connectedValues.CountryId == countryId) {
				var startDateControl = $("#txtStartDate");
				var stopDateControl = $("#txtStopDate");
				var imDateControl = $("#txtIMDate");
				var craTrainingDateControl = $("#txtCRATrainingDate");
				var startDateValue = connectedValues.MonAttrbuteStartDate;

				$.InitiateRequest.SetConnectedStartStopDateAttributes(connectedValues.MonAttrbuteStartDate, connectedValues.MonAttrbuteStopDate, connectedValues.IMDate, connectedValues.CRATrainingDate);
				if (bindStartDateFromMonitoringAttribute) {
					if (connectedValues.MonAttrbuteStartDate != "") {
						if (rm.date.isQDateDateInPast(connectedValues.MonAttrbuteStartDate)) {
							startDateValue = rm.date.getQDateStringFromDate(new Date());
							$.InitiateRequest.AppendDisconnectedCountryImage(startDateControl);
						}
						else {
							$.InitiateRequest.AppendConnectedCountryImage(startDateControl);
						}
					}
					else {
						$.InitiateRequest.AppendDisconnectedImagSsvCalculatore(startDateControl);
					}
				}
				if (connectedValues.MonAttrbuteStopDate != "") {
					$.InitiateRequest.AppendConnectedCountryImage(stopDateControl);
				}
				else {
					$.InitiateRequest.AppendDisconnectedCountryImage(stopDateControl);
				}

				//Always show IM date connected
				$.InitiateRequest.AppendConnectedCountryImage(imDateControl);

				//Always show CRA Training date connected
				$.InitiateRequest.AppendConnectedCountryImage(craTrainingDateControl);

				if (bindStartDateFromMonitoringAttribute) {
					startDateControl.val(startDateValue);
					setNeedByDate(startDateValue, initReqPgNs.getResourceTransitionTimeInDays());
				}
				stopDateControl.val(connectedValues.MonAttrbuteStopDate);
				craTrainingDateControl.val(connectedValues.CRATrainingDate);
				imDateControl.val(connectedValues.IMDate);
				break;
			}
		}
	}

	rm.validation.clearError($("#txtStartDate"));
	rm.validation.clearError($("#txtStopDate"));
	rm.validation.clearError($("#txtCRATrainingDate")); //Always clear CRA Training date error
	rm.validation.clearError($("#txtIMDate")); //Always clear IM date error
};

CalculateNeedByDate = function () {
	setTimeout(function () {
		if ($.q.isValid("#txtStartDate")) {
			setNeedByDate($("#txtStartDate").val(), initReqPgNs.getResourceTransitionTimeInDays());
		}
		else {
			$("#txtNeedByDate").val("");
		}
	}, 20);
};

RenderCalculatorContainerGroupForNewSsvMonitoringRequest = function (countryId, projectId, attributeTypeId) {
	var postData =
	{
		countryId: countryId,
		projectId: projectId,
		attributeType: attributeTypeId
	};

	rm.ui.block();
	setTimeout(function () {
		$.rm.Ajax_Calculator("RenderCalculatorContainerGroupForNewSsvMonitoringRequest", postData, function (data) {
			if (data.ContainsValidationErrors) {
				$.validationHelper.ShowErrorMessages(data.ValidationErrors);
			}
			else {
				$("#divCalculator").html(data.RequestExecutionStatus.AdditionalData.CalculatorHtml);
				calculatorGroup.countryWeeklyHours = data.RequestExecutionStatus.AdditionalData.CountryWeeklyHours;
				setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(null); }, 50);
			}
		}, true, false);
	}, 10);
};

RenderCalculatorContainerGroupForNewStandardMonitoringRequest = function (countryId, projectId) {
	var postData =
	{
		countryId: countryId,
		projectId: projectId
	};
	rm.ui.block();
	setTimeout(function () {
		$.rm.Ajax_Calculator("RenderCalculatorContainerGroupForNewStandardMonitoringRequest", postData, function (data) {
			if (data.ContainsValidationErrors) {
				$.validationHelper.ShowErrorMessages(data.ValidationErrors);
			}
			else {
				$("#divCalculator").html(data.RequestExecutionStatus.AdditionalData.CalculatorHtml);
				calculatorGroup.countryWeeklyHours = data.RequestExecutionStatus.AdditionalData.CountryWeeklyHours;
				setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(countryId); }, 50);
			}
		}, true, false);
	}, 10);
};

OnNoCalculatorFound = function () {
	alert(Resources.NoCalculatorDataFound);
	initReqPgNs.resetPage();
};

RenderCalculatorContainerGroupForNewPharmacyMonitoringRequest = function (countryId, projectId) {
	var postData =
	{
		countryId: countryId,
		projectId: projectId
	};

	rm.ui.block();
	setTimeout(function () {
		$.rm.Ajax_Calculator("RenderCalculatorContainerGroupForNewPharmacyMonitoringRequest", postData, function (data) {
			if (data.ContainsValidationErrors) {
				$.validationHelper.ShowErrorMessages(data.ValidationErrors);
			}
			else {
				$("#divCalculator").html(data.RequestExecutionStatus.AdditionalData.CalculatorHtml);
				calculatorGroup.countryWeeklyHours = data.RequestExecutionStatus.AdditionalData.CountryWeeklyHours;
				setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(-1, OnNoCalculatorFound); }, 50);
			}
		}, true, false);
	}, 10);
};

RenderCalculatorContainerGroupForNewIcraRequest = function (countryId, projectId) {
	var postData =
	{
		countryId: countryId,
		projectId: projectId
	};

	rm.ui.block();
	setTimeout(function () {
		$.rm.Ajax_Calculator("RenderCalculatorContainerGroupForNewIcraRequest", postData, function (data) {
			if (data.ContainsValidationErrors) {
				$.validationHelper.ShowErrorMessages(data.ValidationErrors);
			}
			else {
				$("#divCalculator").html(data.RequestExecutionStatus.AdditionalData.CalculatorHtml);
				calculatorGroup.countryWeeklyHours = data.RequestExecutionStatus.AdditionalData.CountryWeeklyHours;
				setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(-1, OnNoCalculatorFound); }, 50);
			}
		}, true, false);
	}, 10);
};

RenderCalculatorContainerGroupByRequestId = function (requestId, siteId, projectId, countryId, resourceType) {
	var postData = {
		requestId: requestId,
		siteId: siteId,
		projectId: projectId,
		countryId: countryId,
		resourceType: resourceType
	};
	calculatorHelper.getRequestStopDateFromUi = initReqPgNs.getStopDate;
	rm.ui.block();
	setTimeout(function () {
		$.rm.Ajax_Calculator("RenderCalculatorContainerGroupByRequestId", postData, function (data) {
			$("#divCalculator").html(data.CalculatorHtml);
			calculatorGroup.countryWeeklyHours = data.CountryWeeklyHours;
			if (data.SiteInformation != null && data.SiteInformation.SiteSchedule.HasError) {
				alert(data.SiteInformation.SiteSchedule.ErrorMessage);
			}

			setTimeout(function () {
				if (data.SiteInformation != null) {
					var calculatorTypeId = (resourceType == ResourceTypeName.Standard_Monitoring || resourceType == ResourceTypeName.DTESite_Monitoring) ? CalculatorType_E.SS_SIV : CalculatorType_E.SIV;
					var frequencyRow = calculatorHelper.getFrequencyDateDetailsByCalculatorTypeId(data.SiteInformation.SiteSchedule, calculatorTypeId);
					RunMethod(objPageManager, "SetRequestStartDateFromCalculatedSIVFrequencyDate", frequencyRow != undefined ? frequencyRow.StartDate : "", false);
					calculatorHelper.callHandleSiteChangeFromGroup(data.SiteInformation.SiteSchedule);
					calculatorHelper.covSiteVisitCount = data.SiteInformation.NumberOfCovVisits;
					calculatorHelper.lastCovVisitDate = data.SiteInformation.LastCovVisitDate;
					calculatorHelper.connectedStopDate = data.SiteInformation.ConnectedStopDate;
				}
				calculatorHelper.handleCovByCountryId(countryId);
			}, 10);
		}, true, false);
	}, 10);
};

ShowDateIcon = function (requestId) {
	$("#txtStartDate,#txtStopDate, #txtIMDate, #txtCRATrainingDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
	$(".disconnectedFromPpm, .connectedToPpm").attr("style", "display:block"); //AI: Show PPM connect disconnect date image.
};

HideDateIcon = function (requestId) {
	$("#txtStartDate,#txtStopDate, #txtIMDate, #txtCRATrainingDate").unbind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);
	$(".disconnectedFromPpm, .connectedToPpm").attr("style", "display:none"); //AI: Hide PPM connect disconnect date image.
};

ShowDateCountryIcon = function (requestId) {
	$("#txtStartDate,#txtStopDate, #txtIMDate, #txtCRATrainingDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);
	$(".disconnectedFromCountry, .connectedToCountry").attr("style", "display:block"); //AI: Show Country connect disconnect date image.
};

HideDateCountryIcon = function (requestId) {
	$("#txtStartDate,#txtStopDate, #txtIMDate, #txtCRATrainingDate").unbind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChangeCountry);
	$(".disconnectedFromCountry, .connectedToCountry").attr("style", "display:none"); //AI: Hide Country connect disconnect date image.
};

Short_term_SWAT_Monitoring_Draw = function (withCountry) {
	resetBrush = new ResetBrush();
	resetBrush.Reset(); // reset or hide all element which is part of dynamic UI.
	$('.initiateFieldCountry').show();
	$('.initiateFieldSiteID').show();
	$('.initiateFieldSiteStatus').show();
	$('.initiateFieldVisitType').show();
	$('.initiateFieldStartDate').show();
	$('.initiateFieldStopDate').show();
	$('#SpanStart').show();
	$('#SpanStop').show();
	$('#txtStartDate').removeClass("disabledTextBox").removeAttr("readonly");
	$('#txtStopDate').removeClass("disabledTextBox").removeAttr("readonly");
	//$('.initiateFieldNeedByDate').show();
	handleNeedByDateVisibility();
	$('.initiateFieldRequestBudgeted').show();
	$('.initiateNewRequestFields').show();
	setButton();
	$(".initiateNewRequestFloatEdit").removeClass("initiateNewRequestFloatEdit").addClass("initiateNewRequestFloat");
	if (withCountry) {
		$.Dropdown.Country();
	}
	$("#txtStartDate,#txtStopDate").bind('change.connectDisconnect', $.InitiateRequest.HandleStartStopDateChange);

	$.Dropdown.GetVisitType($("#ddlResourceType").val(), !initReqPgNs.isInEditMode());

};

Short_term_SWAT_Monitoring_Validate = function () {
	var isValid = true;
	if (!CommonValidate()) { isValid = false; }
	return isValid;
};

Short_term_SWAT_Monitoring_GetOtherByResourceType = function () {
	SetSiteDetails();
};

Short_term_SWAT_Monitoring_GetOtherByResourceTypeCountry = function () {
	$.Dropdown.VisitType($("#ddlCountry").val());
	GetSiteDetails();
	ShowAndOpenCalculator();
	HideDateIcon();
	HideDateCountryIcon();
};

Validate_Short_term_SWAT_Monitoring = function () {
	var isValid = true;
	return isValid;
};

SaveRequestCommon = function () {
	setTimeout(function () {
		if ($.Calculator.IsPromptRequiredForConnectDisconnectStatus()) {
			$.Calculator.DialogOkClickHandler = SaveNewInitiateRequest;
			$.Calculator.ShowConnectDisconnectChoiceDialog(true);
		}
		else {
			$.Calculator.save(true);
			SaveNewInitiateRequest();
		}
	}, 100);
};

UpdateRequestCommon = function () {
	setTimeout(function () {
		if (($.Calculator._PageManager != undefined) && ($.Calculator._PageManager == "Generic_PageManager")) {
			if ($.GenericFTECalculator.IsPromptRequiredForConnectDisconnectStatus()) {
				$.GenericFTECalculator.DialogOkClickHandler = SaveUpdatedRequest;
				$.GenericFTECalculator.ShowConnectDisconnectChoiceDialog(false);
			}
			else {
				$.GenericFTECalculator.save(false);
				SaveUpdatedRequest();
			}
		}
		else {
			if ($.Calculator.IsPromptRequiredForConnectDisconnectStatus()) {
				$.Calculator.DialogOkClickHandler = SaveUpdatedRequest;
				$.Calculator.ShowConnectDisconnectChoiceDialog(false);
			}
			else {
				$.Calculator.save(false);
				SaveUpdatedRequest();
			}
		}
	}, 100);
};

//AI: Call GetFTECalculator() function for resource type: 1, Clinical Project Support
//2, Co-Monitoring
//3, CRS
//4, CTA
//5, Global CPM
//6, Regional CPM
//7, TSS,
//8, iCRS,
//9, iCTA,
//10, Regional RSUL
GetFTECalculator = function (selector, resourceTypeId, pageManager) {
	//$.Calculator._resourceTypeId = resourceTypeId;
	//$.Calculator._countryId = $(selector).val();

	if ($.Calculator._PageManager != undefined && $.Calculator._PageManager == "Generic_PageManager") {
		if ($(".GenericFTE_Calculator").is(':visible') == true) {
			if (confirm('You are changing the' + (selector.id == "#ddlCountry" ? " " : " preferred ") + 'country location. Please select OK to retain the current start, stop date and weekly hours. Click Cancel to reset and load the values for the new country.')) {
				pageManager._isDisconnectedFTECalculator = true;
				$.GenericFTECalculator._resourceId = initReqPgNs.getResourceTypeId();
				$.GenericFTECalculator._countryId = initReqPgNs.getCountryIdFromUi();
				$.GenericFTECalculator.disconnectAll(); // AI: this may moved to AjaxStop
				$.GenericFTECalculator.RecalculateFTEValues();

				// Reload milestones picklist
				$.GenericFTECalculator.RepopulateMilestoneDataForCountry($.InitiateRequest._selectedProjectID, 0, initReqPgNs.getCountryIdFromUi(), initReqPgNs.getOrganizationId(), initReqPgNs.getResourceTypeId());
				$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {

					// Repopulate old dates and milestones
					var startMilestoneOld = $.grep(oldLocalData, function (el) {
						return el.Id == $(ele).find('[id^=milestone_start]').val();
					});

					//var startMilestoneOld = oldLocalData.filter(function (el) {
					// return el.Id == $(ele).find('[id^=milestone_start]').val();
					// });

					var stopMilestoneOld = $.grep(oldLocalData, function (el) {
						return el.Id == $(ele).find('[id^=milestone_end]').val();
					});

					// Fill FromMilestone picklist
					if (startMilestoneOld.length > 0) {
						// Select new milestone id from new localdata
						var startMilestoneNew = $.grep(LocalData, function (el) {
							return el.ProjectMilestoneId == startMilestoneOld[0].ProjectMilestoneId && el.MilestoneType == startMilestoneOld[0].MilestoneType;
						});

						if (startMilestoneNew.length > 0) {
							// Old milestone reset
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, startMilestoneNew[0].ProjectMilestoneId, startMilestoneNew[0].MilestoneType);
							$.GenericFTECalculator.CheckImageForCountryMilestone($(ele).find('[id^=dtStart_]').val(), startMilestoneNew, $(ele).find('[id^=Image_start_]').attr('id'), true);
						}
						else {
							// Manual milestone set
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, 0, "M");
							$('#' + $(ele).find('[id^=Image_start_]').attr('id')).hide();
						}
					}
					else {
						if ($(ele).find('[id^=milestone_start]').val() != -1)//Sham:QRPM-4736 FIX check for dropdown value if it is not selected skip this part
						{
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, 0, "M");
							$('#' + $(ele).find('[id^=Image_start_]').attr('id')).hide();
						}
					}

					// Fill ToMilestone picklist
					if (stopMilestoneOld.length > 0) {
						// Select new milestone id from new localdata
						var stopMilestoneNew = $.grep(LocalData, function (el) {
							return el.ProjectMilestoneId == stopMilestoneOld[0].ProjectMilestoneId && el.MilestoneType == stopMilestoneOld[0].MilestoneType;
						});

						if (stopMilestoneNew.length > 0) {
							// Old milestone reset
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, stopMilestoneNew[0].ProjectMilestoneId, stopMilestoneNew[0].MilestoneType);

							$.GenericFTECalculator.CheckImageForCountryMilestone($(ele).find('[id^=dtEnd_]').val(), stopMilestoneNew, $(ele).find('[id^=Image_end_]').attr('id'), false);
						}
						else {
							// Manual milestone set
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, 0, "M");
							$('#' + $(ele).find('[id^=Image_end_]').attr('id')).hide();

						}
					}
					else {
						if ($(ele).find('[id^=milestone_end]').val() != -1)//Sham:QRPM-4736 FIX check for dropdown value if it is not selected skip this part
						{
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, 0, "M");
							$('#' + $(ele).find('[id^=Image_end_]').attr('id')).hide();
						}
					}
				});
			}
			else {
				pageManager._isDisconnectedFTECalculator = true;
				$.GenericFTECalculator._resourceId = initReqPgNs.getResourceTypeId();
				$.GenericFTECalculator._countryId = initReqPgNs.getCountryIdFromUi();
				$.GenericFTECalculator.disconnectAll(); // AI: this may moved to AjaxStop
				$.GenericFTECalculator.RecalculateFTEValues();

				// Reload milestones picklist
				$.GenericFTECalculator.RepopulateMilestoneDataForCountry($.InitiateRequest._selectedProjectID, 0, initReqPgNs.getCountryIdFromUi(), initReqPgNs.getOrganizationId(), initReqPgNs.getResourceTypeId());

				var previousStageToDate = null;
				$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
					//AB find current, prev and Next row
					var row = $(this).closest('tr');
					var prev = row.prev();
					var next = row.next();

					// Repopulate old dates and milestones
					var startMilestoneOld = $.grep(oldLocalData, function (el) {
						return el.Id == $(ele).find('[id^=milestone_start]').val();
					});

					var stopMilestoneOld = $.grep(oldLocalData, function (el) {
						return el.Id == $(ele).find('[id^=milestone_end]').val();
					});

					// Fill FromMilestone picklist
					if (startMilestoneOld.length > 0) {
						// Select new milestone id from new localdata
						var startMilestoneNew = $.grep(LocalData, function (el) {
							return el.ProjectMilestoneId == startMilestoneOld[0].ProjectMilestoneId && el.MilestoneType == startMilestoneOld[0].MilestoneType;
						});

						if (startMilestoneNew.length > 0) {
							// Old milestone reset
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, startMilestoneNew[0].ProjectMilestoneId, startMilestoneNew[0].MilestoneType);
							$.GenericFTECalculator.CheckImageForCountryMilestone($(ele).find('[id^=dtStart_]').val(), startMilestoneNew, $(ele).find('[id^=Image_start_]').attr('id'), true);

							//AB update Next StartMilestone Date + 1         
							if (prev.length > 0) {
								$.GenericFTECalculator.UpdateNextSatge(prev, row);
							}
							else {
								if (startMilestoneNew[0].MilestoneType != "M") {
									$(ele).find('[id^=dtStart_]').val(startMilestoneNew[0].MilestoneDate);
								}
							}
						}
						else {
							// Manual milestone set
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, 0, "M");
							$('#' + $(ele).find('[id^=Image_start_]').attr('id')).hide();

						}
					}
					else {
						$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_start]'), LocalData, 0, "M");
						$('#' + $(ele).find('[id^=Image_start_]').attr('id')).hide();

					}

					if (previousStageToDate != null && previousStageToDate != '') {
						// Set previous date + 1 as from stage date
						var CurrentDate = rm.date.getDateFromQDateString(previousStageToDate);
						CurrentDate.setDate(CurrentDate.getDate() + 1);
						$(ele).find('[id^=dtStart_]').val(rm.date.getQDateStringFromDate(CurrentDate));
					}

					// Fill ToMilestone picklist
					if (stopMilestoneOld.length > 0) {
						// Select new milestone id from new localdata
						var stopMilestoneNew = $.grep(LocalData, function (el) {
							return el.ProjectMilestoneId == stopMilestoneOld[0].ProjectMilestoneId && el.MilestoneType == stopMilestoneOld[0].MilestoneType;
						});

						if (stopMilestoneNew.length > 0) {
							// Old milestone reset
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, stopMilestoneNew[0].ProjectMilestoneId, stopMilestoneNew[0].MilestoneType);
							if (stopMilestoneNew[0].MilestoneType != "M") {
								$(ele).find('[id^=dtEnd_]').val(stopMilestoneNew[0].MilestoneDate);
							}
							$.GenericFTECalculator.CheckImageForCountryMilestone($(ele).find('[id^=dtEnd_]').val(), stopMilestoneNew, $(ele).find('[id^=Image_end_]').attr('id'), false);
						}
						else {
							// Manual milestone set
							$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, 0, "M");
							$('#' + $(ele).find('[id^=Image_end_]').attr('id')).hide();
						}
					}
					else {
						$.GenericFTECalculator.Fill($(ele).find('[id^=milestone_end]'), LocalData, 0, "M");
						$('#' + $(ele).find('[id^=Image_end_]').attr('id')).hide();
					}

					previousStageToDate = $(ele).find('[id^=dtEnd_]').val();
				});
				$("#txtStartDate").val("");
				$("#txtStopDate").val("");
				RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
				RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
			}
		}
		else {
			RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
			RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
		}
	}
	else {
		if ($(".FTE_Calculator").is(':visible') == true) {
			if (initReqPgNs.isProposalProjectSelected()) {
				//#### update here
				$.Calculator.save(true); //need all values
				RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
				setTimeout($.Calculator.RecalculateFTEValues, 10);
			}
			else if (confirm('You are changing the' + (selector.id == "#ddlCountry" ? " " : " preferred ") + 'country location. Please select OK to retain the current start, stop date and weekly hours. Click Cancel to reset and load the values for the new country.')) {
				pageManager._isDisconnectedFTECalculator = true;
				$.Calculator.disconnectAll(); // AI: this may moved to AjaxStop
				$.Calculator.UpdatedConnedtedValues(initReqPgNs.getRequestId(), $.InitiateRequest._selectedProjectID, initReqPgNs.getResourceTypeId(), initReqPgNs.getCountryId());
				setTimeout($.Calculator.RecalculateFTEValues, 10);
				RunMethod(pageManager, "ShowDisconnectedIconsForStartAndStopDates", pageManager);
			}
			else {
				$.Calculator.DeleteAllAdHocRow();
				pageManager._isDisconnectedFTECalculator = false;
				RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
				RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
			}
		}
		else {
			RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
			RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
		}

		var connectedValues = RunMethod(pageManager, "GetConnectedStartStopDateValues", $.Dropdown.GetSelectedProjectDetails());
		$("#txtStartDate").attr("connectedDateValue", connectedValues.startDate);
		$("#txtStopDate").attr("connectedDateValue", connectedValues.stopDate);
	}
	getCustomFieldDefaultvalues();
};

//AI: Call GetSSVCalculator() function for resource type: 1, SSV_Monitoring
//2, Short_term_SWAT_Monitoring_OnSite_Visit
//3, Short_term_SWAT_Monitoring_Phone_Visit
//4, Standard_Monitoring
//5, Pharmacy_Monitoring
//6, iCRA_Monitoring
GetSSVCalculator = function (selector, resourceTypeId, pageManager) {
	$(".FTE_Calculator").hide();
	$(".Small_FTE_Calculator").hide();
	$(".GenericFTE_Calculator").hide();
	$(".SSVCountry_FTE_Calculator").hide();
	$.Calculator._interimFrequencyEnabled = false;
	$("#txtSiteStatus").val("");
	calculatorHelper.getRequestStopDateFromUi = initReqPgNs.getStopDate;

	var countryId = $(selector).val();

	if (countryId && countryId != -1) {
		//if ($.InitiateRequest._requestId != null)
		if (initReqPgNs.isInEditMode()) {
			var attr = RunMethod(pageManager, "GetAttribute", countryId);
			$.InitiateRequest._attributeLastModifiedOn = (attr == undefined) ? null : attr.AttributeLastModifiedOn;
		}

		if ($.trim($("#divCalculator").html()).length > 0 &&
			ResourceTypeName.Short_term_SWAT_Monitoring_OnSite_Visit != resourceTypeId &&
			ResourceTypeName.Short_term_SWAT_Monitoring_Phone_Visit != resourceTypeId &&
			confirm('You are changing the country location. Please select OK to retain the current values. Click Cancel to reset and load the values for the new country.')) {
			if (ResourceTypeName.SSV_Monitoring == resourceTypeId || ResourceTypeName.Standard_Monitoring == resourceTypeId || ResourceTypeName.Pharmacy_Monitoring == resourceTypeId || ResourceTypeName.iCRA_Monitoring == resourceTypeId) {
				if (calculatorHelper.handleCountryChange($.InitiateRequest._selectedProjectID, $(selector).val(), AttributeType_E.SsvAttribute)) {
					RunMethod(pageManager, "SetDatesAttributeForNewCountry", countryId);
					calculatorHelper.handleEmptySite();
				}
				else {
					OnNoCalculatorFound();
				}
				if (ResourceTypeName.Standard_Monitoring == resourceTypeId || ResourceTypeName.Pharmacy_Monitoring == resourceTypeId || ResourceTypeName.iCRA_Monitoring == resourceTypeId) {
					$.Calculator._interimFrequencyEnabled = true;
				}
			}
			else if (ResourceTypeName.DTESite_Monitoring == resourceTypeId || ResourceTypeName.DTEPharmacy_Monitoring == resourceTypeId) {
				if (calculatorHelper.handleCountryChange($.InitiateRequest._selectedProjectID, $(selector).val(), AttributeType_E.SsvAttribute, true)) {
					RunMethod(pageManager, "SetDatesAttributeForNewCountry", countryId);
					calculatorHelper.handleEmptySite(true);
				}
				else {
					OnNoCalculatorFound();
				}
			}
			else if (ResourceTypeName.Co_monitoring_SiteSpecific == resourceTypeId || ResourceTypeName.Non_Standard_Monitoring_SiteSpecific == resourceTypeId) {
				setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(null); }, 50);
			}
			if (ResourceTypeName.DTESite_Monitoring == resourceTypeId || ResourceTypeName.DTEPharmacy_Monitoring == resourceTypeId) {
				//here if calculator is DTE the dropdown should be set to default
				var postData = {
					calculatorTypeId: ResourceTypeName.DTESite_Monitoring == resourceTypeId ? CalculatorGroup_E.DTEMonitoringCalculator : CalculatorGroup_E.DTEPharmacyCalculator,
					projectId: $.InitiateRequest._selectedProjectID,
					countryId: countryId
				};
				$.rm.Ajax_Calculator("GetDefaultTier", postData, function (data) {
					if (ResourceTypeName.DTESite_Monitoring == resourceTypeId) {
						$.Dropdown.Fill(".ddltier_freq1", data[0].Value.FrequencyTiers, "Key Value", data[0].Value.DefaultTier.Key, false);
						$.Dropdown.Fill(".ddltier_freq2", data[1].Value.FrequencyTiers, "Key Value", data[1].Value.DefaultTier.Key, false);

						// Re-bind tooltip ** REQUIRED FOR JAPAN ** - remember to destroy the old_title to enable resetting.
						$("#" + $('.ddltier_freq1').attr('id')).qtip('destroy');
						$("#" + $('.ddltier_freq2').attr('id')).qtip('destroy');
						rm.qtip.showInfo("#" + $('.ddltier_freq1').attr('id'), "The selected Tier will set the Visit Frequency");
						rm.qtip.showInfo("#" + $('.ddltier_freq2').attr('id'), "The selected Tier will set the Visit Frequency");
					}
					else {
						$.Dropdown.Fill(".ddltier_pharma", data[0].Value.FrequencyTiers, "Key Value", data[0].Value.DefaultTier.Key, false);

						// QRPM-6687: TL: Trigger the onchange event to set the Visit Frequency Weeks.
						$(".ddltier_pharma").trigger("change");

						// Re-bind tooltip ** REQUIRED FOR JAPAN ** - remember to destroy the old_title to enable resetting.
						$("#" + $('.ddltier_pharma').attr('id')).qtip('destroy');
						rm.qtip.showInfo("#" + $('.ddltier_pharma').attr('id'), "The selected Tier will set the Visit Frequency");
					}
				}, true, false);
			}
		}
		else {
			if (ResourceTypeName.SSV_Monitoring == resourceTypeId) {
				RenderCalculatorContainerGroupForNewSsvMonitoringRequest($(selector).val(), $.InitiateRequest._selectedProjectID, AttributeType_E.SsvAttribute);
				RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
			}
			else if (ResourceTypeName.Short_term_SWAT_Monitoring_OnSite_Visit == resourceTypeId) {
				var postData = {
					calculatorGroup: CalculatorGroup_E.InitiateCalculator,
					countryId: countryId,
					projectId: $.InitiateRequest._selectedProjectID
				};

				$.rm.Ajax_Calculator("RenderCalculatorContainerGroupForNewOnSiteVisitRequest", postData, function (data) {
					//$("#divCalculator").html(data);
					$("#divCalculator").html(data.CalculatorHtml);
					calculatorGroup.countryWeeklyHours = data.CountryWeeklyHours;
					setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(null); }, 50);
				}, true);
			}
			else if (ResourceTypeName.Co_monitoring_SiteSpecific == resourceTypeId) {
				var postData = {
					calculatorGroup: CalculatorGroup_E.MonitoringSiteSpecific,
					countryId: countryId,
					projectId: $.InitiateRequest._selectedProjectID
				};

				$.rm.Ajax_Calculator("RenderCalculatorContainerGroupForNewCoMonitoringSiteSpecificRequest", postData, function (data) {
					//$("#divCalculator").html(data);
					$("#divCalculator").html(data.CalculatorHtml);
					calculatorGroup.countryWeeklyHours = data.CountryWeeklyHours;
					setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(null); }, 50);
				}, true);
			}
			else if (ResourceTypeName.Non_Standard_Monitoring_SiteSpecific == resourceTypeId) {
				var postData = {
					calculatorGroup: CalculatorGroup_E.MonitoringSiteSpecific,
					countryId: countryId,
					projectId: $.InitiateRequest._selectedProjectID
				};

				$.rm.Ajax_Calculator("RenderCalculatorContainerGroupForNewNonStandardMonitoringSiteSpecificRequest", postData, function (data) {
					//$("#divCalculator").html(data);
					$("#divCalculator").html(data.CalculatorHtml);
					calculatorGroup.countryWeeklyHours = data.CountryWeeklyHours;
					setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(null); }, 50);
				}, true);
			}
			else if (ResourceTypeName.Short_term_SWAT_Monitoring_Phone_Visit == resourceTypeId) {
				var postData = {
					calculatorGroup: CalculatorGroup_E.InitiateCalculator,
					countryId: countryId,
					projectId: $.InitiateRequest._selectedProjectID
				};

				$.rm.Ajax_Calculator("RenderCalculatorContainerGroupForNewPhoneVisitRequest", postData, function (data) {
					//$("#divCalculator").html(data);
					$("#divCalculator").html(data.CalculatorHtml);
					calculatorGroup.countryWeeklyHours = data.CountryWeeklyHours;
					setTimeout(function () { calculatorGroup.calculatorRedrawnAfterCountryChange(null); }, 50);
				}, true);
			}
			else if (ResourceTypeName.Standard_Monitoring == resourceTypeId) {
				if (typeof calculatorHelper != "undefined") {
					$.InitiateRequest._adhocCalcIdsToDelete = $.InitiateRequest._adhocCalcIdsToDelete.concat(calculatorHelper.getAdhocCalculatorIds());
				}
				RenderCalculatorContainerGroupForNewStandardMonitoringRequest($(selector).val(), $.InitiateRequest._selectedProjectID);
				RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
				$.Calculator._interimFrequencyEnabled = true;
			}
			else if (ResourceTypeName.DTESite_Monitoring == resourceTypeId) {
				if (typeof calculatorHelper != "undefined") {
					$.InitiateRequest._adhocCalcIdsToDelete = $.InitiateRequest._adhocCalcIdsToDelete.concat(calculatorHelper.getAdhocCalculatorIds());
				}
				RenderCalculatorContainerGroupForNewStandardMonitoringRequest($(selector).val(), $.InitiateRequest._selectedProjectID);
				RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
				$.Calculator._interimFrequencyEnabled = true;
			}
			else if (ResourceTypeName.Pharmacy_Monitoring == resourceTypeId) {
				if (typeof calculatorHelper != "undefined") {
					$.InitiateRequest._adhocCalcIdsToDelete = $.InitiateRequest._adhocCalcIdsToDelete.concat(calculatorHelper.getAdhocCalculatorIds());
				}
				RenderCalculatorContainerGroupForNewPharmacyMonitoringRequest($(selector).val(), $.InitiateRequest._selectedProjectID);
				RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
				$.Calculator._interimFrequencyEnabled = true;
			}
			else if (ResourceTypeName.DTEPharmacy_Monitoring == resourceTypeId) {
				if (typeof calculatorHelper != "undefined") {
					$.InitiateRequest._adhocCalcIdsToDelete = $.InitiateRequest._adhocCalcIdsToDelete.concat(calculatorHelper.getAdhocCalculatorIds());
				}
				RenderCalculatorContainerGroupForNewPharmacyMonitoringRequest($(selector).val(), $.InitiateRequest._selectedProjectID);
				RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
				$.Calculator._interimFrequencyEnabled = true;
			}
			else if (ResourceTypeName.iCRA_Monitoring == resourceTypeId) {
				if (typeof calculatorHelper != "undefined") {
					$.InitiateRequest._adhocCalcIdsToDelete = $.InitiateRequest._adhocCalcIdsToDelete.concat(calculatorHelper.getAdhocCalculatorIds());
				}
				RenderCalculatorContainerGroupForNewIcraRequest($(selector).val(), $.InitiateRequest._selectedProjectID);
				RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
				$.Calculator._interimFrequencyEnabled = true;
			}
		}
	}
	getCustomFieldDefaultvalues();
	rm.ui.ribbon.refresh();
};

handleRegionChange = function (resourceTypeId, regionId, pageManager) {
	if ($(".FTE_Calculator").is(':visible') == true) {
		if (initReqPgNs.isProposalProjectSelected()) {
			//#### update here
			RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
			setTimeout($.Calculator.RecalculateFTEValues, 10);
		}
		else if (confirm('You are changing the preferred region location. Please select OK to retain the current start, stop date and weekly hours. Click Cancel to reset and load the values for the new region.')) {
			pageManager._isDisconnectedFTECalculator = true;
			$.Calculator.disconnectAll(); // AI: this may moved to AjaxStop
			$.Calculator.UpdatedRegionalConnedtedValues(initReqPgNs.getRequestId(), $.InitiateRequest._selectedProjectID, initReqPgNs.getResourceTypeId(), regionId);
			setTimeout($.Calculator.RecalculateFTEValues, 10);
		}
		else {
			$.Calculator.DeleteAllAdHocRow();
			pageManager._isDisconnectedFTECalculator = false;
			RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
			RunMethod(pageManager, "UpdateRequestStopDate", resourceTypeId, regionId, pageManager);
		}
	}
	else {
		RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
	}
};

//AI: Call GetSmallFTECalculator() function for resource type: 1, Co_monitoring,
//2, Regional RSU Lead																											
GetSmallFTECalculator = function (pageManager, ResourceType) {
	if (ResourceType == ResourceTypeName.Co_monitoring || ResourceType == ResourceTypeName.Generic) {
		if ($(".Small_FTE_Calculator").is(':visible') == true && confirm("You are changing the country location. Please click OK to recalculate the Total Hours in FTE calculator. Otherwise, click Cancel and the system will remove the data from all fields with the exception of country.")) {
			$.SmallFTECalculator.CalculateTotalHours();
		}
		else {
			RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
			$("#txtStartDate").val("");
			$("#txtStopDate").val("");
			$("#txtNeedByDate").val("");
			$.SmallFTECalculator.ClearCalculator();
		}
	}
	else if (ResourceType == ResourceTypeName.Global_RSUL) {
		if ($(".Small_FTE_Calculator").is(':visible') == false) {
			RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
		}
		RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
	}
	else if (ResourceType == ResourceTypeName.SSVMonitoring_CountrySpecific) {
		RunMethod(pageManager, "DrawCalculator", true, false, pageManager);
		$("#txtStartDate").val("");
		$("#txtStopDate").val("");
		$("#txtNeedByDate").val("");
		SSVCountryCalculatorNs.ClearCalculator();
		RunMethod(pageManager, "ShowDatesOnCountryOrPreferredCountryChange", pageManager);
	}
	getCustomFieldDefaultvalues();
};

ShowAndOpenCalculator = function () {
	$("#divAccordionCalculator").show();
	if (!$("#divCalculator").is(":visible")) {
		$("#divAccordionCalculator").accordion("option", "active", 0);
	}
	$("#divCalculator").show();
};

GetMonitoringAttribute = function (countryId) {
	var attribute = null;
	if ($.InitiateRequest._initiateRequestJSON != null) {
		$.each($.InitiateRequest._initiateRequestJSON.MonitoringAttributeList, function (index, ele) {
			if (ele.CountryId == countryId) {
				attribute = ele;
				return false;
			}
		});
	}
	return attribute;
};

GetSsvAttribute = function (countryId) {
	var attribute = null;
	if ($.InitiateRequest._initiateRequestJSON != null) {
		$.each($.InitiateRequest._initiateRequestJSON.SSVAttributeList, function (index, ele) {
			if (ele.CountryId == countryId) {
				attribute = ele;
				return false;
			}
		});
	}
	return attribute;
};

RunMethod = function (pageManager, methodName) {
	if (pageManager != undefined && $.isFunction(pageManager[methodName])) {
		return pageManager[methodName].apply(pageManager, Array.prototype.slice.call(arguments, 2));
	}
};

GetSiteDetails = function () {
	var postData =
	{
		RequestDetails:
		{
			ProjectId: $.InitiateRequest._selectedProjectID,
			CountryId: $("#ddlCountry").val(),
			ResourceTypeId: $('#ddlResourceType').val(),
			RequestId: initReqPgNs.getRequestId()// $.InitiateRequest._requestId == '' ? null : $.InitiateRequest._requestId
		}
	};

	$.rm.Ajax_RequestSynchronous("GetSiteDetails", postData, function (data) {
		$("#ddlSiteId").data("siteData", data);
		$.Dropdown.SiteFromJSON(data);
	}, false);
};

SetSiteDetails = function () {
	GetOtherByResourceTypeCountry();
	var siteData = $("#ddlSiteId").data("siteData");

	$.each(siteData, function (index, ele) {
		if (ele.SiteId == $("#ddlSiteId").val()) {
			$.InitiateRequest._piName = ele.PrincipalInvestigatorName;
			$.InitiateRequest._requestLocation = ele.Location;
			$.InitiateRequest._sponsorSite = ele.SponsorSite;
			$("#txtSiteStatus").val(ele.SiteStatusName);
			$.InitiateRequest._siteStatus = ele.SiteStatusName;
			$.InitiateRequest._countryRegionName = ele.CountryRegionName;
			$.InitiateRequest._countryRegion = ele.CountryRegionId;
			return false;
		}
	});
};

ValidateSsvCalculator = function () {
	var isValid = true;

	if ($('#divAccordionCalculator').is(":visible") && typeof calculatorHelper != "undefined") {
		if (calculatorHelper.areAdhocDatesBeyondRequestStopDate()) { isValid = false; }
		if (!calculatorHelper.isCalculatorValid(calculatorIdJson, calculatorHelper.getSelectedTabIndex())) { isValid = false; }
	}
	return isValid;
};

GetDistinctCountryIds = function () {
	$.rm.Ajax_Request("GetDistinctCountryIds", {}, function (data) {
		$("#txtProjectName").data("DistinctCountryIds", data);
	}, true);
};

handleProposalResourceVisibility = function () {
	if (initReqPgNs.selectedRequestDetails &&
		initReqPgNs.selectedRequestDetails.requestTypeId == RequestType_E.AutogeneratedFromProposal &&
		initReqPgNs.selectedRequestDetails.requestStatusId != RequestStatusName.Assigned) {
		$('.initiateFieldProposalResource').show();
	}
	else {
		$('.initiateFieldProposalResource').hide();
	}
};

Co_Monitoring_SiteSpecific_GetOtherByResourceType = function () {
	SetSiteDetails();
};

Co_Monitoting_SiteSpecific_GetOtherByResourceTypeCountry = function () {
	$.Dropdown.VisitType($("#ddlCountry").val());
	GetSiteDetails();
	ShowAndOpenCalculator();
	HideDateIcon();
	HideDateCountryIcon();
};

Non_Standard_Monitoring_SiteSpecific_GetOtherByResourceType = function () {
	SetSiteDetails();
};

Non_Standard_Monitoring_SiteSpecific_GetOtherByResourceTypeCountry = function () {
	$.Dropdown.VisitType($("#ddlCountry").val());
	GetSiteDetails();
	ShowAndOpenCalculator();
	HideDateIcon();
	HideDateCountryIcon();
};

SetRequestStartDateFromCalculatedSIVFrequencyDate = function (startDate, populateStartDate) {
	var startDateControl = $("#txtStartDate");
	startDateControl.attr("connectedDateValue", startDate);

	if (populateStartDate) {
		$("#txtStartDate").parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		var startDateValue = startDate;
		if (startDate == "" || rm.date.isQDateDateInPast(startDate)) {
			startDateValue = rm.date.getQDateStringFromDate(new Date());
			$.InitiateRequest.AppendDisconnectedCountryImage(startDateControl);
		}
		else {
			$.InitiateRequest.AppendConnectedCountryImage(startDateControl);
		}
		startDateControl.val(startDateValue);
		var selectedProjectDetails = $.Dropdown.GetSelectedProjectDetails();
		setNeedByDate(startDateValue, initReqPgNs.getResourceTransitionTimeInDays());
	}
	rm.validation.clearError($("#txtStartDate"));
};

displayCustomFields = function () {
	if (!initReqPgNs.isProposalProjectSelected()) {
		var requestId = initReqPgNs.isInEditMode() ? initReqPgNs.getRequestId() : -1;
		rm.serviceCalls.getCustomFieldsByResourceTypeId(initReqPgNs.getResourceTypeId(), requestId, initReqPgNs.getProjectId(), function (response) {
			rm.customFields.renderResourceTypeCustomfields(response, $("#DynamicContent"), true, 1);
		});
	}
}

handleNeedByDateVisibility = function () {
	$(initReqPgNs.txtNeedByDateSelector).val("");
	var selector = ".initiateFieldNeedByDate";
	if (ResourceTypeDetails[initReqPgNs.getResourceTypeId()].ShowNeedByDate) { $(selector).show(); }
	else { $(selector).hide(); }
};

getCustomFieldDefaultvalues = function () {
	if (!initReqPgNs.isProposalProjectSelected()) {
		if (!initReqPgNs.isInEditMode() && initReqPgNs.getResourceTypeId() != -1) { initReqPgNs.getCustomFieldDefaultvalues(initReqPgNs.getResourceTypeId(), initReqPgNs.getProjectId(), initReqPgNs.getCountryId()); }
	}
};

updateRequestStopDateFromComputedRequestMilestone = function (resourceTypeId, regionId) {
	if (ResourceTypeDetails[resourceTypeId].RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Request) {
		var milestoneList = initReqPgNs.getComputedReqestMilestoneDaysToAdd();
		$.each(milestoneList, function (index, item) {
			if ((ResourceTypeDetails[resourceTypeId].IsRegionBased && item.ResourceTypeId == resourceTypeId && item.RegionId == regionId) ||
				(!ResourceTypeDetails[resourceTypeId].IsRegionBased && item.ResourceTypeId == resourceTypeId)) {
				rm.validation.clearError($("#txtStopDate"));
				$("#txtStopDate").val(rm.date.addDaysToQdate($("#txtStartDate").val(), item.DaysToAdd));
				CalculateNeedByDate();
				return false;
			}
		});
	}
}

SetCountryRegionOptional = function () {
	initReqPgNs.isCountryRegionOptional = true;
	$("#spanCountryRegonReq").remove();
}


unbindEvent = function (selector, nameSpace, eventType) {
	//nameSpace = (nameSpace == null) ? "" : nameSpace.toLowerCase();
	//var fullyQualifiedEventName = (nameSpace == "") ? eventType : eventType + "." + nameSpace;
	//var events = $(selector).data('events')[eventType.toLowerCase()];
	//if (events && events.length > 0) {
	//	$.each(events, function (index, eventHandler) {
	//		if (eventHandler.namespace.toLowerCase() == nameSpace) {
	//			$(selector).unbind(fullyQualifiedEventName);
	//		}
	//	});
	//}
};


var showHideTierWarning = function (isPharmacy) {
	var selectedProjectDetails = $.Dropdown.GetSelectedProjectDetails();
	if (selectedProjectDetails.DTE && !selectedProjectDetails.HasUserDefinedSchema) {
		rm.ui.messages.addWarningAsBlock(Resources.UserDefinedSchemaMsgForCalculator);
	}
	if (selectedProjectDetails && (selectedProjectDetails.CustomSchemaValuesRequired && !selectedProjectDetails.CustomSchemaValuesConfigured))/*values required in porj config page and not configured then throw error*/ {
		rm.ui.messages.addError(Resources.CustomSchemaValuesRequired);
		initReqPgNs.resetPage();
		return false;
	}
	else if (isPharmacy && selectedProjectDetails.DTE && !selectedProjectDetails.PharmacySchemaEnabled) {
		rm.ui.messages.addError(Resources.PharmacySchemaNotEnabled);
		initReqPgNs.resetPage();
		return false;
	}
};



