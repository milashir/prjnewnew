﻿/// <reference path="../common/rm.common.js"/>

//MR: No spaces allowed and must match search filter db values (ResourceTypeSearchFilter)
var SPONSOR_KEY = "Sponsor";
var ORGANIZATION_KEY = "Organization";
var LANGUAGE_KEY = 'Language';
var REGION_KEY = 'Region';
var SUBREGION_KEY = 'Subregion';
var COUNTRY_KEY = 'Country';
var COUNTRY_REGION_KEY = 'CountryRegion';
var STATE_KEY = "StateProvince";

var PROJECT_KEY = "Project";
var SKILL_KEY = "Skill";
var AREA_KEY = "TherapeuticArea";
var JOBROLE_KEY = "JobRole";
var INDICATION_KEY = "Indication";
var STUDY_PHASE_KEY = "StudyPhase";
var STUDY_PHASE_NOTQ_KEY = "StudyPhaseNotQ";
var COMPETENCY_BAND_KEY = "CompetencyBand";
var TMF_PLATFORM_KEY = "TmfPlatform";
var competencyBandTooltip = "Minimum Competency Band - ";
var projectAssigmentTitle = "Project Assignments";
var programAssigmentTitle = "Program Assignments";
var projectProgramAddedTitle = " for the Program ";

var ORDINAL_TMF_KEY = "OrdinalTmf";


var keyList = [
	SPONSOR_KEY,
	ORGANIZATION_KEY, LANGUAGE_KEY,
	REGION_KEY, SUBREGION_KEY, COUNTRY_KEY, COUNTRY_REGION_KEY, STATE_KEY,
	PROJECT_KEY, SKILL_KEY,
	AREA_KEY, JOBROLE_KEY, INDICATION_KEY,
    STUDY_PHASE_KEY, STUDY_PHASE_NOTQ_KEY, COMPETENCY_BAND_KEY, TMF_PLATFORM_KEY, ORDINAL_TMF_KEY
];
var resourcingRequirementProjectList = [];
var firewalledProjectList = [];
var selectedProjectIdList = [];
var selectedResourceTypeIds = [];
var selectedShowUnBlindedColumnList = [];
var projectRoles = [];
//var isBookResourceAssignment = false;
var jobRoles = [];
var organizations = { items: [] };
var jobGradeSliderId = "#jobGrade_slider";
var jobGrades = [];
var imgPath = '/_Layouts/SPUI/images/';
var checkedIcon = 'checkIcon.png';
var uncheckedIcon = 'uncheckIcon.png';
var resourcesAssignedToBadRequests = "";
var $tabs = null;
var experienctTypesByResourceTypesHash = {};
var MakeSingleCallForRequests = false;
var isDisableGridCheckbox = false;
var resourceTypeJobRoleList = [];
var uniqueSelectedCountryIdList = [];
var uniqueSelectedShowSiteList = [];
var projectFireWalledMessage = "Assigning these project requests would generate a potentital Conflict Of Interest (COI) for those resources marked with a red triangle. Hover over each triangle to see details.";
var reSubmitHardBookLocalData = [];

$(document).ajaxStop(function () { rm.ui.unblock(); });
$(document).ajaxStart(function () { rm.ui.block(); });

$(document).ready(function () {
	rm.runtimeValues.gridOffsetWidth = 237;
	$("#ChartResContainer").width(rm.ui.getContentContainerWidth() - rm.runtimeValues.gridOffsetWidth);
	jobGrades = JobGradeList; //Array definition loads from rm.dynamic
	$(document).on("click", "[name=hlSoftbookResource]", function () {
		$.rm.searchResults.SoftBooking([$(this).attr("requestId")], [$(this).attr("resourceId")], false)
	});
	$(document).on("click", "[name=hlFireWalledResourceBooking]", function () {
		if ($(this).attr("isSoftBook") == 1) {
			$.rm.searchResults.SoftBooking([$(this).attr("requestId")], [$(this).attr("resourceId")], false)
		}
		else {
			reSubmitHardBookLocalData = {
				selectedRequestIds: [$(this).attr("requestId")],
				resourceId: $(this).attr("resourceId"),
				bidDefenseResult: reSubmitHardBookLocalData.bidDefenseResult,
				validateFirewalledProject: false,
			};
			$.rm.searchResults.SubmitHardBooking(null, false);
		}
	});
	$.rm.search.hideAsignToJapanRibbonButton();
	var LocalData;
	$("#RequestScheduleAccord").accordion({ collapsible: true });
	$.rm.search.addScrollToTabs();
	GetRequestTypeResourceTypeGroupAndResourceTypeList();
	ResourceGroupChange();
	DisableAllsearchFilterOnLoad();
	SelectAllClick();
	$.rm.Ajax_Utility("GetExperienceTypesForAllResourceTypes", {}, function (data) {
		if (data && data.length > 0) {
			var expTypeArray;
			$.each(data, function (index, ele) {
				expTypeArray = experienctTypesByResourceTypesHash[ele.ResourceTypeId];
				if (!expTypeArray) {
					expTypeArray = new Array();
					experienctTypesByResourceTypesHash[ele.ResourceTypeId] = expTypeArray;
				}
				expTypeArray.push(ele);
			});
		}
	}, true, true);


	$('#ddlResourceGroup').change(function () {
		$.rm.search._bviewEnabled = false;
		$.rm.search._bFirewalledStudiesViewEnabled = false;
		rm.ui.ribbon.refresh();
	}),

	$("#MyLinks_ResourcingWorkList").addClass("left-static-selected-menu");
	$tabs = $('#tabs').tabs();
	rm.ui.tabs.disableByIndex("#tabs", rmSearchNs.tabIndex.SearchResults);
	rm.ui.tabs.disableByIndex("#tabs", rmSearchNs.tabIndex.SelectedProfile);
	$("#divResMatchAvail_accordeon").accordion({ collapsible: true, active: true });
	$("#divSearchPlanAccordion").accordion({
		collapsible: true,
		animated: true,
		autoHeight: false,
		active: false
	});
	// Handle Tab change event for buttons enable/disable status
	$tabs.tabs({
		activate: function (event, ui) {
			var rmSearch = $.rm.search;
			var prevSearchEnabled = rmSearch._bSearchEnabled;
			var prevHardBookEnabled = rmSearch._bHardBookEnabled;
			var prevSoftBookEnabled = rmSearch._bSoftBookEnabled;

			//if (ui.index == 0) {
			if (ui.newPanel.selector == "#tabs-1") {
				var grid = $("#queueRequests");
				rmSearch._bSearchEnabled = grid && grid.getGridParam && grid.getGridParam('selarrrow') && (grid.getGridParam('selarrrow').length > 0);
				rmSearch._bSoftBookEnabled = false;
				rmSearch._bHardBookEnabled = false;
				rmSearch.showRegularResourcingButtons();
				rmSearchNs.handleSearchFilterVisibility();
			}
				//else if (ui.index == 1) {
			else if (ui.newPanel.selector == "#tabs-2") {
				rmSearch._bSearchEnabled = true;
				var grid = $("#searchResults");
				var selCount = grid && grid.getGridParam && grid.getGridParam('selarrrow') ? grid.getGridParam('selarrrow').length : 0;
				rmSearch._bSoftBookEnabled = (selCount > 0);
				rmSearch._bHardBookEnabled = (selCount == 1);
				rmSearch.showRegularResourcingButtons();
				rmSearchNs.handleSearchFilterVisibility();
			}
				//else if (ui.index == 2) {
			else if (ui.newPanel.selector == "#tabs-3") {
				rmSearch.buildCompareResourceChart();
				rmSearch._bSearchEnabled = false;
				rmSearch._bSoftBookEnabled = false;
				rmSearch._bHardBookEnabled = false;
				rmSearch.showRegularResourcingButtons();
				rmSearchNs.handleSearchFilterVisibility();
			}
			if ((prevSearchEnabled != rmSearch._bSearchEnabled) || (prevSoftBookEnabled != rmSearch._bSoftBookEnabled) || (prevHardBookEnabled != rmSearch._bHardBookEnabled))
				rm.ui.ribbon.refresh();
		}
	}); // catch show event

	$.rm.search.SetupSearchFilters();
	$.rm.search.InitJobGradeSlider();
	nameChange();

	rm.grid.bindEventsToResizeGrid("#queueRequests", "#searchResults");
	rm.qtip.showInfoOnGridColumn("#SpanFTE_Id", "Display projected actual monthly workload for each Request");
	rm.qtip.showInfoOnGridColumn("#SpanHours_Id", "Display projected actual monthly workload for each Request");
	rm.qtip.showInfoOnGridColumn("#SpanAverageFTE_Id", "Display projected workload averaged across each Request's remaining duration");
	rm.qtip.showInfoOnGridColumn("#SpanAverageHours_Id", "Display projected workload averaged across each Request's remaining duration");
	rm.qtip.showInfoOnGridColumn("#SpanFTE_Id1", "Display selected Resource's projected availability per month");
	rm.qtip.showInfoOnGridColumn("#SpanHours_Id1", "Display selected Resource's projected availability per month");
	rm.qtip.showInfoOnGridColumn("#SpanAverageFTE_Id1", "Display selected Resource's projected Availability averaged across each Request's remaining duration");
	rm.qtip.showInfoOnGridColumn("#SpanAverageHours_Id1", "Display selected Resource's projected Availability averaged across each Request's remaining duration");
});

/**
* @original author Colin Boatwright
*   the rest you can blame on Matt
*/

var rmSearchNs = {
	tabIndex: { ResourceingWorklist: 0, SearchResults: 1, SelectedProfile: 2 },

	defaultFilterContainerSelector: "#SearchCriteria",//"#SearchCriteria_SearchResourceName,#SearchCriteria_SearchLineManager,#SearchCriteria_Sponsor,#SearchCriteria_StudyPhase,#SearchCriteria_JobGrade,#SearchCriteria_JobRole,#SearchCriteria_Projects,#SearchCriteria_Geographical,#SearchCriteria_Organization,#SearchCriteria_Languages,#SearchCriteria_Skill,#SearchCriteria_Area,#SearchCriteria_Indication",

	showSearchFilters: function () { $(rmSearchNs.defaultFilterContainerSelector).show(); },

	hideSearchFilters: function () { $(rmSearchNs.defaultFilterContainerSelector).hide(); },

	handleSearchFilterVisibility: function () {
		if ($("#queueRequests").getGridParam('selarrrow').length > 0) {
			rmSearchNs.showSearchFilters();
		}
	},

	getSelectedRequestIdList: function () {
		return $("#queueRequests").getGridParam('selarrrow');
	},

	showProjectBookings: function (resourceId) {
		rmSearchNs.showMatchingBookingModalWindow(resourceId, "GetProjectBookingsByRequestIdListAndResorceId", "divPrjBooking" + resourceId, projectAssigmentTitle);
	},

	showProgramBookings: function (resourceId) {
		rmSearchNs.showMatchingBookingModalWindow(resourceId, "GetProgramBookingsByRequestIdListAndResorceId", "divProgBooking" + resourceId, programAssigmentTitle);
	},

	showMatchingBookingModalWindow: function (resourceId, webserviceName, divId, title) {
		var matchingBookingDiv = $("#" + divId);
		var multipleProjWithSameProg = "";
		if (matchingBookingDiv.length == 0) {
			$.rm.Ajax_Request(webserviceName, { requestIdList: rmSearchNs.getSelectedRequestIdList(), resourceId: resourceId }, function (data) {
				var html = "<table class='validationTable'><tr class='headerRow'><td style='max-width:115px;'>Project</td><td>Resource Request Type</td><td style='width:115px;'>Assignment Status</td><td style='width:80px;'>Start Date</td><td style='width:80px;'>Stop Date</td></tr>";
				$.each(data.BookingList, function (index, element) {
					if (title == projectAssigmentTitle) {
						if (index == 0) {
							multipleProjWithSameProg = element.Program;
						}
					}
					html += "<tr><td>" + element.Project + "</td><td>" + element.ResourceType + "</td><td>" + element.RequestStatus + "</td><td>" + element.StartDate + "</td><td>" + element.StopDate + "</td></tr>";
				});
				html += "</table>";

				matchingBookingDiv = $("<div id='" + divId + "'/>");
				$("body").append(matchingBookingDiv);
				matchingBookingDiv.html(html).dialog({ modal: true, height: 350, width: 650, title: multipleProjWithSameProg != "" ? title + projectProgramAddedTitle + "'" + multipleProjWithSameProg + "'" : title });
			});
		}
		else {
			matchingBookingDiv.dialog("open");
		}
	},

	drawProjectMatchIndicator: function (cellvalue, options, rowObject) {
		var imageHtml = "";
		if (cellvalue === true) {
			imageHtml = "<div class='programProjectMatch' title='Please click to see additional information' style='cursor: pointer;' onclick='rmSearchNs.showProjectBookings(" + options.rowId + ")'/>";
		}
		else {
			imageHtml = "<div class='programProjectNoMatch' title='No matching Project bookings' />";
		}
		return imageHtml;
	},

	drawProjectFireWalledIndicator: function (cellvalue, options, rowObject) {
		var imageHtml = "";
		if (cellvalue === true) {
			imgdivid = "img" + rowObject.ResourceId;
			imageHtml = "<div id='" + imgdivid + "' src='/_layouts/SPUI/images/firewall.png' tooltiptextdata='" + rowObject.ResourceFireWalledDetailsHtml + "'  class='resourceFireWallMatch'/>";
		}
		else {
			imageHtml = "<div class='resourceFireWallNoMatch' title='Not FireWalled.' />";
		}
		return imageHtml;
	},


	drawProgramMatchIndicator: function (cellvalue, options, rowObject) {
		var imageHtml = "";
		if (cellvalue === true) {
			imageHtml = "<div class='programProjectMatch' title='Please click to see additional information' onclick='rmSearchNs.showProgramBookings(" + options.rowId + ")'/>";
		}
		else {
			if (!rowObject.ProjectMatch)
				imageHtml = "<div class='programProjectNoMatch' title='No matching Program bookings' />";
		}
		return imageHtml;
	},

	drawRequestUnBlindedIndicator: function (cellvalue, options, rowObject) {
		var imageHtml = "";
		if (cellvalue == BlindedUnblindedStatus_E.Green_Flag) {
			imageHtml = "<div title='" + Resources.ProgramProjectMatch.replace(/'/g, "&#39;") + "'>Yes<div/>";
		}
		else if (cellvalue == BlindedUnblindedStatus_E.Red_Flag) {
			imageHtml = "<div  title='" + Resources.ProgramProjectNoMatch.replace(/'/g, "&#39;") + "'>No<div/>";
		}
		else if (cellvalue == BlindedUnblindedStatus_E.OpenLabel) {
			imageHtml = "<div  title='" + Resources.ProgramProjectOpenLabel.replace(/'/g, "&#39;") + "'>OL<div/>";
		}
		else {
			imageHtml = "<div  title='" + Resources.ProgramBlindedNoMatch.replace(/'/g, "&#39;") + "'>Unknown<div/>";
		}
		return imageHtml;
	},
	showTmfPlatformColumn: function () {
		var showColumn = false;
		var gridSelector = "#queueRequests";
		var selectedRequestIds = rm.grid.getSelectedIdArray(gridSelector);
		$.each(selectedRequestIds, function (index, requestId) {
			var gridRowData = rm.grid.rowData.getById(gridSelector, requestId);
			if (ResourceTypeDetails[gridRowData.ResourceTypeId].ShowTmfPlatform) {
				showColumn = true;
				return false;
			}
		});
		return showColumn;
	},
	fetchingRequestWorklistDataFromServer: true

};

$.rm.search =
{
	startMonthYear: 0,
	endMonthYear: 0,
	arTotalMonthlyHours: null,
	arTotalMonthlyFTE: null,

	_searchPlan: null,
	_bCompareSelectedEnabled: false,
	_bSoftBookEnabled: false,
	_bHardBookEnabled: false,
	_bSearchEnabled: false,
	_bResetFiltersEnabled: false,
	_bViewProfileMatchEnabled: false,
	_bAssignToJapanEnabled: false,
	_bViewEnabled: false,
	_bFirewalledStudiesViewEnabled: false,

	SetNotes: function (data, projectId, jobRoleGroupId) {
		notesheadinglabelid = "#NotesLabel" + projectId;
		var labeltxtforJobRole = "";
		if (jobRoleGroupId == 1)
			labeltxtforJobRole = "CRA Notes :";
		else
			if (jobRoleGroupId == 2)
				labeltxtforJobRole = "Project Leadership Notes :";
		$(notesheadinglabelid).text('');
		$(notesheadinglabelid).text(labeltxtforJobRole);


		var notesId = "#Notes" + projectId;
		$(notesId).text('');
		if (data.length > 0) {
			$(notesId).text(data[0].Notes);
		}
	},
	ShowViewDisabledHoverOverMessage: function (message) {
		var resRefreshButton = $("[id*=ViewResourcingRequirementsNotExist]");
		if (resRefreshButton.length > 0) {
			var position = resRefreshButton.offset();
			var spinnerTop = position.top;
			var spinnerLeft = position.left;
			var html = "<img id='resSpacer' title='" + Resources.ResourceSearchViewDisabledToolTip + "'  src='/_layouts/spui/images/spacer.gif' width='80' height='80' style='z-index:10;position:fixed;top:" + spinnerTop + "px;left:" + spinnerLeft + "px;' alt='" + message + "' />";
			$(resRefreshButton).append(html);
		}
	},
	ShowViewDisabledHoverOverMessageForFirewalledbutton: function (message) {
		var resRefreshButton = $("[id*=FirewalledProjectsNotExist]");
		if (resRefreshButton.length > 0) {
			var position = resRefreshButton.offset();
			var spinnerTop = position.top;
			var spinnerLeft = position.left;
			var html = "<img id='resSpacerFirewall' title='" + Resources.NoFirewalledProjects + "'  src='/_layouts/spui/images/spacer.gif' width='80' height='80' style='z-index:10;position:fixed;top:" + spinnerTop + "px;left:" + spinnerLeft + "px;' alt='" + message + "' />";
			$(resRefreshButton).append(html);
		}
	},

	showRegularResourcingButtons: function () {
		$("[id$=SearchActions]").show();
		$("[title='Hard Book']").show();
		$("[title='Soft Book']").show();
		$.rm.search.hideAsignToJapanRibbonButton();
	},

	hideAsignToJapanRibbonButton: function () { $("[title='Assign to Japan']").hide(); },

	showSpecialResourcingButtons: function () {
		$("[id$=SearchActions]").hide();
		$("[title='Hard Book']").hide();
		$("[title='Soft Book']").hide();
		$("[title='Assign to Japan']").show();
	},

	AssignToJapan: function () {
		var selectedRequestIds = $("#queueSpecialRequests").getGridParam('selarrrow');

		if (selectedRequestIds.length == 0) {
			rm.ui.messages.addError('Select request(s) from Resourcing Worklist.');
			return false;
		}

		$.rm.Ajax_Request("AssignToJapan", { requestIds: selectedRequestIds }, function (data) {
			var allFailed = true;
			var atLeastOneFailed = false;

			$.each(data, function (index, element) {
				if (element.Status) {
					rm.grid.removeRow("#queueSpecialRequests", element.RequestId);
					allFailed = false;
				}
				else {
					rm.grid.showErrorIconInMessageColumn("#queueSpecialRequests", element.RequestId, "Message", element.Message);
					atLeastOneFailed = true;
				}
			});
			$.rm.searchResults.ShowMessageOnAjaxComplete(allFailed, atLeastOneFailed, "#queueSpecialRequests");
		});
	},

	AssignToJapanEnabled: function () { return this._bAssignToJapanEnabled; },

	/**
* Setup the UI (accordion stuff, event binding, etc.)
*
* @author Colin Boatwright
*/
	initUi: function () {
		$('.accordion').accordion({ collapsible: true, active: false });

		// Because each accordion's content might have a select which grows/shrinks confusing the height of the
		$('.accordion').each(function () {
			$(this).on("accordionactivate", function (event, ui) {
				$(".ui-accordion-content-active").css({ 'height': 'auto' });
			});
		});
		$("#SearchCriteria span.ui-accordion-header-icon").css({ "position": "absolute", "margin": "3px 5px" });
		// accordion itelf, take away that CSS style altogether.
		$('.ui-accordion .ui-accordion-content').each(function () { $(this).css({ 'padding-left': '15px' }); });
		$('.ui-accordion .ui-accordion-content').each(function () { $(this).css({ 'padding-right': '3px' }); });

		$('#SearchCriteria').css('visibility', 'visible');
	},

	ResetRibbonIcons: function () {
		this._bCompareSelectedEnabled = false;
		this._bSoftBookEnabled = false;
		this._bHardBookEnabled = false;
		this._bSearchEnabled = false;
		this._bAssignToJapanEnabled = false;
		rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SearchResults]);
		this._bResetFiltersEnabled = false;
		this._bViewProfileMatchEnabled = false;
		rm.ui.ribbon.refresh();
	},

	InitJobGradeSlider: function () {
		var minValue = 0;
		var maxValue = jobGrades.length - 1;

		$(jobGradeSliderId).slider({
			//animate: true,
			min: 0,
			max: jobGrades.length - 1,
			values: [minValue, maxValue],
			range: true,
			step: 1
		});

		//MR: detect change in slider position and update values
		//  pass in vars via event.data to avoid closure/scope problems
		$(jobGradeSliderId).bind('slidechange',
						{
							sliderId: jobGradeSliderId, sliderValueId: '#jobGrade_sliderValue', sliderValues: jobGrades
						},
						function (event, ui) {
							var tooltip = "";
							var values = $(event.data.sliderId).slider("option", "values");
							var minSelected = jobGrades[values[0]];
							var maxSelected = jobGrades[values[1]];

							if (values[0] === values[1]) {
								tooltip = minSelected;
								$(event.data.sliderValueId).html(minSelected);
							} else {
								tooltip = minSelected + " ... " + maxSelected;
								$(event.data.sliderValueId).html(minSelected + " ... " + maxSelected);
							}

							$("#h3JobGrade").attr("title", tooltip);
						}
					);

		//MR: initialize the values being displayed
		$(jobGradeSliderId).trigger('slidechange');
	},

	ResetJobGradeSlider: function () {
		var minValue = 0;
		var maxValue = jobGrades.length - 1;

		$(jobGradeSliderId).slider("values", 0, minValue);
		$(jobGradeSliderId).slider("values", 1, maxValue);
		$(jobGradeSliderId).trigger('slidechange');
	},

	Close: function () {
		rm.ui.dialog.showWaitModalWithNoClose("Opening Open Resoure Request List");
		document.location = "/_Layouts/SPUI/MyLinks/OpenRequests.aspx";
	},

	/**
* Setup all the one clicks data for the filter and then apply the 'oneclick' plugin to the geography-based filters
*
* @author Colin Boatwright
*/
	initOneClicks: function (g) {

		var sponsors = { items: [] };
		var countries = { items: [] };
		var subregions = { items: [] };
		var regions = { items: [] };
		var countryRegions = { items: [] };
		var states = { items: [] };
		var projects = { items: [] };
		var languages = { items: [] };
		var skills = { items: [] };
		var areas = { items: [] };
		var jobRoles = { items: [] };
		var indications = { items: [] };
		var studyphases = { items: [] };
		var studyphasesnotq = { items: [] };
		var competencyBands = { items: [] };
		var tmfPlatforms = { items: [] };

		//MR: I switched this all around to optimize the Region -> Language object graph and JSON traffic
		if (g != null) {
			var r = g.geography;

			//regions
			for (var i = 0; i < r.length; i++) {
				var region = { Id: r[i].Id, Name: r[i].Name };
				regions.items[regions.items.length] = {
					Id: region.Id,
					Name: region.Name,
					selected: false,
					parentId: null
				};

				//subregions
				for (var j = 0; j < r[i].srs.length; j++) {
					var subregion = { Id: r[i].srs[j].Id, Name: r[i].srs[j].Name };
					subregions.items[subregions.items.length] = {
						Id: subregion.Id,
						Name: subregion.Name,
						selected: false,
						parentId: region.Id
					};

					//countries
					for (var k = 0; k < r[i].srs[j].cs.length; k++) {
						var country = { Id: r[i].srs[j].cs[k].Id, Name: r[i].srs[j].cs[k].Name };
						countries.items[countries.items.length] = {
							Id: country.Id,
							Name: country.Name,
							selected: false,
							parentId: subregion.Id
						};

						//languages
						// languages are loaded separately and then filtered by selected requests

						//country regions
						//KM: made default value to false for the country region.
						for (var x = 0; x < r[i].srs[j].cs[k].crs.length; x++) {
							var countryRegion = { Id: r[i].srs[j].cs[k].crs[x].Id, Name: r[i].srs[j].cs[k].crs[x].Name };
							countryRegions.items[countryRegions.items.length] = {
								Id: countryRegion.Id, Name: countryRegion.Name, selected: false, parentId: country.Id
							};

							//states
							for (var y = 0; y < r[i].srs[j].cs[k].crs[x].States.length; y++) {
								var state = { Id: r[i].srs[j].cs[k].crs[x].States[y].Id, Name: r[i].srs[j].cs[k].crs[x].States[y].Name };
								states.items[states.items.length] = {
									Id: state.Id,
									Name: state.Name,
									selected: false,
									parentId: country.Id
								};
							} //states
						} //country regions
					} //countries
				} //subregions
			} //regions
		} //g

		$('#g_oneclicks').oneclick({
			label: REGION_KEY,
			position: 'last',
			data: regions
		});
		$('#g_oneclicks').oneclick({
			label: SUBREGION_KEY,
			position: 'last',
			parentDataKey: REGION_KEY,
			redactBasedOnParent: true,
			data: subregions
		});

		$('#g_oneclicks').oneclick({
			label: COUNTRY_KEY,
			position: 'last',
			parentDataKey: SUBREGION_KEY,
			redactBasedOnParent: true,
			data: countries
		});

		$('#g_oneclicks').oneclick({
			label: "Country Region",
			Name: COUNTRY_REGION_KEY,
			position: 'last',
			parentDataKey: COUNTRY_KEY,
			redactBasedOnParent: true,
			data: countryRegions
		});

		$('#g_oneclicks').oneclick({
			label: "State/Province",
			Name: STATE_KEY,
			position: 'last',
			parentDataKey: COUNTRY_KEY,
			redactBasedOnParent: true,
			data: states
		});

		// $('#SearchCriteria_Geographical').css('display', 'inline');



		$.ajax({
			type: "GET",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.utilitySvcUrl + "Master/GetUsedLanguages",
			dataType: "json",
			success: function (result) {
				//result should be a native json object that is a list of languages used by resources in Elvis

				//Languages
				for (var i = 0; i < result.length; i++) {
					var language = { Id: result[i].Id, Name: result[i].Name };
					languages.items[languages.items.length] = {
						Id: language.Id,
						Name: language.Name,
						selected: false,
						parentId: null
					};
				}

				//$('#SearchCriteria_Languages').css('display', 'inline');
				$('#lang_oneclicks').oneclick({
					label: LANGUAGE_KEY,
					showLabel: false,
					position: 'last',
					data: languages
				});

			},
			error: function (errMsg) { }
		});

		$('#p_oneclicks').oneclick({
			label: PROJECT_KEY,
			showLabel: false,
			position: 'last',
			data: projects,
			dialogBox:
	{
		enabled: true,
		modal: true,
		resizable: false,
		width: 550,
		cache: false,
		title: 'Contractual Agreements Defined Criteria',
		height: 525,
		position: [window.screen.height / 2, (window.screen.width / 2) - 650],
		close: HandleProjectModalClose,
		open: HandleProjectModalOpen,
		beforeClose: HandleProjectModalBeforeClose,
		eventName: 'click',
		divIdPrefix: '#hoverTip_',
		dataKeyPrefix: 'MSAData',
		dialogContainerId: '#dialogContainer'
	}
		});

		$('#competencyBand_oneclicks').oneclick({
			label: COMPETENCY_BAND_KEY,
			showLabel: false,
			position: 'last',
			data: competencyBands,
		});

		$('#skill_oneclicks').oneclick({
			label: SKILL_KEY,
			showLabel: false,
			position: 'last',
			showSlider: true,
			data: skills
		});

		$('#sponsor_oneclicks').oneclick({
			label: SPONSOR_KEY,
			showLabel: false,
			position: 'last',
			showSlider: true,
			data: sponsors
		});


		$.ajax({
			type: "GET",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.utilitySvcUrl + "OneClick/GetTherapeuticAreas",
			dataType: "json",
			success: function (result) {
				//result should be a native json object that is a list of therapeutic areas

				//Areas
				for (var i = 0; i < result.length; i++) {
					var area = { Id: result[i].Id, Name: result[i].Name };
					areas.items[areas.items.length] = {
						Id: area.Id,
						Name: area.Name,
						selected: false,
						parentId: null
					};

					//Indications
					for (var j = 0; j < result[i].Indications.length; j++) {
						var indication = { Id: result[i].Indications[j].Id, Name: result[i].Indications[j].Name };
						indications.items[indications.items.length] = {
							Id: indication.Id,
							Name: indication.Name,
							selected: false,
							parentId: area.Id
						};
					}
				}

				//				$('#SearchCriteria_Area').css('display', 'inline');
				$('#area_oneclicks').oneclick({
					label: AREA_KEY,
					showLabel: false,
					position: 'last',
					showSlider: true,
					data: areas
				});


				//				$('#SearchCriteria_Indication').css('display', 'inline');
				$('#indication_oneclicks').oneclick({
					label: INDICATION_KEY,
					showLabel: false,
					position: 'last',
					showSlider: true,
					parentDataKey: AREA_KEY,
					redactBasedOnParent: true,
					data: indications
				});


			},
			error: function (errMsg) { }
		});

		$.ajax({
			type: "GET",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.utilitySvcUrl + "OneClick/GetTmfPlatforms",
			dataType: "json",
			success: function (result) {
				for (var i = 0; i < result.length; i++) {
					tmfPlatforms.items.push({
						Id: result[i].Id,
						Name: result[i].Name,
						selected: false,
						parentId: null
					});
				}
				$('#tmfplatform_oneclicks').oneclick({
					label: TMF_PLATFORM_KEY,
					showLabel: false,
					position: 'last',
					showSlider: true,
					data: tmfPlatforms
				});
			},
			error: function (errMsg) { }
        });

		$('#ordinaltmf_oneclicks').oneclick({
			label: ORDINAL_TMF_KEY,
			showLabel: false,
			position: 'last',
			showSlider: true,
			data: { items: [{ Id: "IsPrimary", Name: "Primary TMF" }, { Id: "IsSecondary", Name: "Secondary TMF" }, { Id: "IsTertiary", Name: "Tertiary TMF" }] }
        });

		//For job role, load a global set
		$.rm.Ajax_Utility("GetJobRoleResourceTypeList", {}, function (data) {
			resourceTypeJobRoleList = data;
		}, true, true);

		$('#jobrole_oneclicks').oneclick({
			label: JOBROLE_KEY,
			showLabel: false,
			position: 'last',
			showSlider: true,
			data: jobRoles
		});


		/*
$.ajax({
	type: "GET",
	contentType: "application/json; charset=utf-8",
	url: rm.ajax.utilitySvcUrl + "Master/GetJobRoles",
	dataType: "json",
	success: function (result)
	{

		for (var i = 0; i < result.length; i++)
		{
			var jobRole = result[i];
			jobRoles.items.push({
				Id: jobRole.Id,
				Name: jobRole.DisplayName,
				selected: false,
				parentId: null
			});
		}
		

		$('#jobrole_oneclicks').oneclick({
			label: JOBROLE_KEY,
			showLabel: false,
			position: 'last',
			showSlider: true,
			data: jobRoles
		});
	},
	error: function (errMsg) { }
});
*/


		//For organizations, load a global set
		$.ajax({
			type: "GET",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.utilitySvcUrl + "Master/GetOrganizationalUnits",
			dataType: "json",
			success: function (result) {
				//MR: Organizations
				for (var i = 0; i < result.length; i++) {
					var org = { Id: result[i].Id, Name: result[i].Name };
					organizations.items[organizations.items.length] = {
						Id: org.Id,
						Name: org.Name,
						selected: false,
						parentId: null
					};
				}
				//$('#SearchCriteria_Organization').css('display', 'inline');
				$('#org_oneclicks').oneclick({
					label: ORGANIZATION_KEY,
					showLabel: false,
					position: 'last',
					dataNameProperty: 'Name',
					data: organizations
				});
			},
			error: function (errMsg) { }
		});

		$.ajax({
			type: "GET",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.utilitySvcUrl + "OneClick/GetStudyPhases",
			dataType: "json",
			success: function (result) {
				//result should be a native json object that is a list of therapeutic areas

				//MR: Study Phases
				for (var i = 0; i < result.length; i++) {
					var studyphase = { Id: result[i].Id, Name: result[i].Name };
					studyphases.items[studyphases.items.length] = {
						Id: studyphase.Id,
						Name: studyphase.Name,
						selected: false,
						parentId: null
					};
					studyphasesnotq.items[studyphasesnotq.items.length] = {
						Id: studyphase.Id,
						Name: studyphase.Name,
						selected: false,
						parentId: null
					};
				}

				//$('#SearchCriteria_StudyPhase').css('display', 'inline');
				$('#studyphase_oneclicks').oneclick({
					label: "Quintiles",
					Name: STUDY_PHASE_KEY,
					showSlider: true,
					data: studyphases
				});
				$('#studyphase_oneclicks').oneclick({
					label: "Non-Quintiles",
					Name: STUDY_PHASE_NOTQ_KEY,
					position: 'last',
					showSlider: true,
					data: studyphasesnotq
				});

			},
			error: function (errMsg) { }
		});

	},
	ResetJobRoles: function () {
		var selectedrows = $("#queueRequests").getGridParam('selarrrow');
		selectedResourceTypeIds = [];
		for (var i = 0; i < selectedrows.length; i++) {
			var hiddenJson = $.parseJSON($("#queueRequests").getCell(selectedrows[i], "ExperienceTypes"));

			if ($.inArray(hiddenJson.ResourceTypeId, selectedResourceTypeIds) == -1) {
				selectedResourceTypeIds.push(hiddenJson.ResourceTypeId);
			}
		}


		//For job rold, load a global set
		jobRoles.items = [];
		for (var i = 0; i < resourceTypeJobRoleList.length; i++) {
			if ($.inArray(resourceTypeJobRoleList[i].ResourceTypeId, selectedResourceTypeIds) !== -1) {
				var jList = resourceTypeJobRoleList[i].JobRoles;
				for (var j = 0; j < jList.length; j++) {
					var jr = jList[j];
					jobRoles.items.push({
						Id: jr.Key,
						Name: jr.Value,
						selected: false,
						parentId: null
					});
				}

				$.fn.oneclick('setData', JOBROLE_KEY, jobRoles);

			}
		}
	},
	AdjustFilters: function (reset) {
		$("#searchPlan").hide();

		var preselectedOrganizationIds = [];
		var preselectedOrganizationMap = [];

		var selectedLanguageIds = [];
		var selectedLanguageMap = [];

		var selectedRegionIds = [];
		var selectedSubregionIds = [];
		var selectedCountryIds = [];
		var selectedCountryRegionIds = [];
		var selectedStateProvinceIds = [];

		var selectedProjectMap = [];
		var projectProtocol = "";

		var selectedCompetencyBand = [];
		var projectCompetencyBand = "";

		projectRoles.length = 0;
		var skills = { items: [] };
		var sponsors = { items: [] };

		var preselectedStudyPhaseIds = [];
		var selectedStudyPhaseMap = [];
		var preselectedTmfPlatofrmMap = [];

		var selectedSkillIds = [];

		var preselectedTAIds = [];
		var preselectedIndicationIds = [];
		var preselectedTAMap = [];
		var preselectedIndicationMap = [];
		var preselectedCustomerIds = [];
		var isMultipleRequestComptencBand = true;

		//MR: For the selected requests, aggregate all the various id's we'll need to set default options in filters
		var selectedrows = $("#queueRequests").getGridParam('selarrrow');
		for (var i = 0; i < selectedrows.length; i++) {
			//TODO: convert the hidden columns into a single anonymous JSON object

			//Sponsor name 'choices' defined by selected Requests
			var sponsor = $("#queueRequests").getCell(selectedrows[i], "Sponsor");
			var sponsorId = $("#queueRequests").getCell(selectedrows[i], "SponsorId");


			if (sponsor != '') {
				var hasSponsorAlready = false;
				$.each(sponsors.items, function (index, element) {
					if (element.Id == sponsorId) hasSponsorAlready = true;
				});
				if (!hasSponsorAlready) {
					sponsors.items[sponsors.items.length] = {
						Id: sponsorId,
						Name: sponsor,
						selected: false
					};
				}
			}

			var hiddenJson = $.parseJSON($("#queueRequests").getCell(selectedrows[i], "ExperienceTypes"));

			//RMK Added for getting the studyphase map
			if ($('#SearchCriteria_StudyPhase').css('display') != 'none') {

				var studyPhaseId = $("#queueRequests").getCell(selectedrows[i], "StudyPhaseId");
				selectedStudyPhaseMap[selectedStudyPhaseMap.length] = studyPhaseId;
			}

			if ($('#SearchCriteria_TmfPlatform').css('display') != 'none') {
				var tmfPlatformId = rm.grid.rowData.getById("#queueRequests", selectedrows[i]).TmfPlatformId;
				if (tmfPlatformId != null) {
					preselectedTmfPlatofrmMap.push(tmfPlatformId);
				}
			}
			//RMK Added to get the PROJECT TA
			if ($('#SearchCriteria_Area').css('display') != 'none' && $.rm.search.CheckIsFilter("SearchCriteria_Area") == true) {

				var TAIds = ($("#queueRequests").getCell(selectedrows[i], "ProjectTA")).split(",");
				$.each(TAIds, function (i, id) {
					preselectedTAMap[id] = id;
				});

			}
			//RMK Added to get project indication
			if ($('#SearchCriteria_Indication').css('display') != 'none' && $.rm.search.CheckIsFilter("SearchCriteria_Indication") == true) {

				var indicationIds = ($("#queueRequests").getCell(selectedrows[i], "ProjectIndication")).split(",");
				$.each(indicationIds, function (i, id) {
					preselectedIndicationMap[id] = id;
				});
			}

			if ($('#SearchCriteria_Organization').css('display') != 'none' && $.rm.search.CheckIsFilter("SearchCriteria_Organization")) {
				var requestOrgIds = ($("#queueRequests").getCell(selectedrows[i], "OrganizationalUnitIds")).split("|");
				$.each(requestOrgIds, function (i, id) {
					preselectedOrganizationMap[id] = id;
				});
			}


			if ($('#SearchCriteria_Languages').css('display') != 'none') {
				//var Language = $('#SearchCriteria_Languages');
				//Pre-selected Languages
				var listOfSelectedLanguageIds = ($('#queueRequests').getCell(selectedrows[i], 'LanguageIds')).split("|");
				$.each(listOfSelectedLanguageIds, function (i, id) {
					selectedLanguageMap[id] = id;
				});
			}

			//Pre-selected Region, Subregion, Country
			if ($('#SearchCriteria_Geographical').css('display') != 'none') {
				var listOfGeographyIds = ($('#queueRequests').getCell(selectedrows[i], 'GeographyIds')).split("|");
				selectedRegionIds[selectedRegionIds.length] = parseInt(listOfGeographyIds[0]);
				selectedSubregionIds[selectedSubregionIds.length] = parseInt(listOfGeographyIds[1]);
				selectedCountryIds[selectedCountryIds.length] = parseInt(listOfGeographyIds[2]);

				//Pre-selected CountryRegion
				if (listOfGeographyIds.length >= 4) {
					selectedCountryRegionIds[selectedCountryRegionIds.length] = parseInt(listOfGeographyIds[3]);
				}

				//Pre-selected StateProvince
				if (listOfGeographyIds.length == 5) {
					selectedStateProvinceIds[selectedStateProvinceIds.length] = listOfGeographyIds[4];
				}
			}

			//Projects are always pre-selected (for MSA inclusion as a filter)
			selectedProjectMap[$('#queueRequests').getCell(selectedrows[i], 'ProjectCode') + '-' + $('#queueRequests').getCell(selectedrows[i], 'Protocol')] =
			parseInt($('#queueRequests').getCell(selectedrows[i], 'ProjectId'));

			if (selectedrows.length > 1 && i != 0) {
				if (isMultipleRequestComptencBand) {
					if (parseInt($('#queueRequests').getCell(selectedrows[i - 1], 'ProjectId')) == parseInt($('#queueRequests').getCell(selectedrows[i], 'ProjectId'))) {
						isMultipleRequestComptencBand = true;
					} else {
						isMultipleRequestComptencBand = false;
					}
				}
			}
			if (isMultipleRequestComptencBand) {
				if (!isNaN(parseInt($('#queueRequests').getCell(selectedrows[i], 'CompetencyBandId'))))
					selectedCompetencyBand[competencyBandTooltip + $('#queueRequests').getCell(selectedrows[i], 'CompetencyBandName')] = parseInt($('#queueRequests').getCell(selectedrows[i], 'CompetencyBandId'));
			}
			else { selectedCompetencyBand = [] }

			// Projects
			//var experienceTypes = experienceJobRole.ExperienceTypes;
			projectRoles.push({
				'ProjectCode': hiddenJson.ProjectCode,
				'ProjectJobRoleId': hiddenJson.JobRoleId,
				'ProjectId': hiddenJson.ProjectId,
				'ResourceTypeId': hiddenJson.ResourceTypeId
			});

			//MR: Get resourceTypeId so we can figure out the experience types to load into Skills accordian...
			//      var resourceTypeId = $("#queueRequests").getCell(selectedrows[i], "ResourceTypeId");
			var experienceTypes = experienctTypesByResourceTypesHash[hiddenJson.ResourceTypeId];

			if (experienceTypes) {
				$.each(experienceTypes, function (index, et) {
					//only add if not already in the list...
					var hasSkillAlready = false;
					$.each(skills.items, function (index, element) {
						if (element.Id == et.Id) hasSkillAlready = true;
					});
					if (!hasSkillAlready) {

						skills.items[skills.items.length] = {
							Id: et.Id,
							Name: et.Name,
							isRange: et.IsRange,
							rangeValues: et.RangeValues.split('|'),
							selected: false,
							applyInFilter: et.ApplyInFilter,
							minSelected: $.rm.search.GetMinValueForSkill(et.RangeValues, et.FilterSkill, et.IsRange)
						};
					}
				});
			}
		}


		// Clear the currently selected
		if (reset) {
			this.ResetOneClicks();
			this.ResetJobGradeSlider();
		}

		//Study Phase, Quintiles and Non-Quintiles
		if ($('#SearchCriteria_StudyPhase').css('display') != 'none') {
			if ($.rm.search.CheckIsFilter("SearchCriteria_StudyPhase")) {
				//for (var id in selectedStudyPhaseMap) preselectedStudyPhaseIds[preselectedStudyPhaseIds.length] = id;
				SetDataListSelect($.fn.oneclick('getSettings', STUDY_PHASE_KEY).data, selectedStudyPhaseMap);
				SetDataListSelect($.fn.oneclick('getSettings', STUDY_PHASE_NOTQ_KEY).data, selectedStudyPhaseMap);
			}
			$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', STUDY_PHASE_KEY), false);
			$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', STUDY_PHASE_NOTQ_KEY), false);
		}
		//using the org map, create set of all selected org id's
		if ($('#SearchCriteria_Organization').css('display') != 'none') {
			for (var orgId in preselectedOrganizationMap) preselectedOrganizationIds[preselectedOrganizationIds.length] = orgId;
			SetDataListSelect($.fn.oneclick('getSettings', ORGANIZATION_KEY).data, preselectedOrganizationIds);
			$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', ORGANIZATION_KEY), false);
		}

		if ($('#SearchCriteria_TmfPlatform').css('display') != 'none') {
			if ($.rm.search.CheckIsFilter("SearchCriteria_TmfPlatform")) {
				SetDataListSelect($.fn.oneclick('getSettings', TMF_PLATFORM_KEY).data, preselectedTmfPlatofrmMap);
				$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', TMF_PLATFORM_KEY), false);
			}
		}

		if ($('#SearchCriteria_OrdinalTmf').css('display') != 'none') {
			if ($.rm.search.CheckIsFilter("SearchCriteria_OrdinalTmf")) {
				var selectedOrdinalTmfIdList = preselectedTmfPlatofrmMap.length == 0 ? [] : ["IsPrimary"];

				SetDataListSelect($.fn.oneclick('getSettings', ORDINAL_TMF_KEY).data, selectedOrdinalTmfIdList);
				$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', ORDINAL_TMF_KEY), false);
			}
		}

		if ($('#SearchCriteria_Languages').css('display') != 'none') {
			//RMK Added to check is filter
			if ($.rm.search.CheckIsFilter("SearchCriteria_Languages")) {
				for (var langId in selectedLanguageMap) selectedLanguageIds[selectedLanguageIds.length] = langId;
				SetDataListSelect($.fn.oneclick('getSettings', LANGUAGE_KEY).data, selectedLanguageIds);
			}
			$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', LANGUAGE_KEY), false);
		}
		// Region is the "top most" parent and will automatically update the sub-geographies - except state, which is handled separately
		SetDataListSelect($.fn.oneclick('getSettings', REGION_KEY).data, selectedRegionIds);
		SetDataListSelect($.fn.oneclick('getSettings', SUBREGION_KEY).data, selectedSubregionIds);
		SetDataListSelect($.fn.oneclick('getSettings', COUNTRY_KEY).data, selectedCountryIds);
		$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', COUNTRY_KEY), false);
		SetDataListSelect($.fn.oneclick('getSettings', COUNTRY_REGION_KEY).data, selectedCountryRegionIds);
		$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', REGION_KEY), false);
		SetDataListSelect($.fn.oneclick('getSettings', STATE_KEY).data, selectedStateProvinceIds);
		$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', STATE_KEY), false);

		//Projects
		//This gets all the project data specific to a job role selected in grid
		//TODO: MR: probably a race condition that needs to be addressed
		GetMSAContent();
		var projects = { items: [] };
		for (var p in selectedProjectMap) {
			projectProtocol = p;
			var style;
			if ($('#hoverTip_' + selectedProjectMap[p]).data("MSAData") != undefined && $($($('#hoverTip_' + selectedProjectMap[p]).data("MSAData").HtmlString).html()).html() != "") {
				projectProtocol = p;
				style = "color:green";
			}
			else {
				style = "";
			}

			//var experienceTypes = experienceJobRole.ExperienceTypes;
			if ($('#SearchCriteria_Projects').css('display') != 'none') {
				if ($.rm.search.CheckIsFilter("SearchCriteria_Projects")) {
					projects.items[projects.items.length] = {
						Id: parseInt(selectedProjectMap[p]),
						Name: projectProtocol,
						selected: true,
						style: style
					};
				}
				else {
					projects.items[projects.items.length] = {
						Id: parseInt(selectedProjectMap[p]),
						Name: projectProtocol,
						selected: false,
						style: style
					};
				}
			}
			else {
				projects.items[projects.items.length] = {
					Id: parseInt(selectedProjectMap[p]),
					Name: projectProtocol,
					selected: false,
					style: style
				};
			}
		}
		$.fn.oneclick('setData', PROJECT_KEY, projects);
		$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', PROJECT_KEY), false);

		//SearchCriteria_CompetencyBand
		var competencyBands = { items: [] };
		for (var p in selectedCompetencyBand) {
			projectCompetencyBand = p;
			//var experienceTypes = experienceJobRole.ExperienceTypes;
			if ($('#SearchCriteria_CompetencyBand').css('display') != 'none') {
				if ($.rm.search.CheckIsFilter("SearchCriteria_CompetencyBand")) {
					competencyBands.items[competencyBands.items.length] = {
						Id: parseInt(selectedCompetencyBand[p]),
						Name: projectCompetencyBand,
						selected: true,
					};
				}
				else {
					competencyBands.items[competencyBands.items.length] = {
						Id: parseInt(selectedCompetencyBand[p]),
						Name: projectCompetencyBand,
						selected: false,
					};
				}
			}
			else {
				competencyBands.items[competencyBands.items.length] = {
					Id: parseInt(selectedCompetencyBand[p]),
					Name: projectCompetencyBand,
					selected: false,
				};
			}
		}
		$.fn.oneclick('setData', COMPETENCY_BAND_KEY, competencyBands);
		$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', COMPETENCY_BAND_KEY), false);
		//SearchCriteria_CompetencyBand

		//Skills

		$.fn.oneclick('setData', SKILL_KEY, skills);

		if ($.rm.search.CheckIsFilter("SearchCriteria_Skill")) {

			$.each(skills.items, function (index, element) {
				if (element.applyInFilter == true) {
					selectedSkillIds[selectedSkillIds.length] = element.Id

				}
			});
			SetDataListSelect($.fn.oneclick('getSettings', SKILL_KEY).data, selectedSkillIds);
		}
		$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', SKILL_KEY), false);


		//Sponsor
		if ($('#SearchCriteria_Sponsor').css('display') != 'none') {

			$.fn.oneclick('setData', SPONSOR_KEY, sponsors);
			//RMK Added to preset the project customer
			if ($.rm.search.CheckIsFilter("SearchCriteria_Sponsor")) {
				$.each(sponsors.items, function (index, element) {
					preselectedCustomerIds[preselectedCustomerIds.length] = element.Id;
				});
				SetDataListSelect($.fn.oneclick('getSettings', SPONSOR_KEY).data, preselectedCustomerIds);

			}
			$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', SPONSOR_KEY), false);
		}



		//JobRole
		$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', JOBROLE_KEY), false);

		//RMK Modified Areas and Indications
		if ($('#SearchCriteria_Area').css('display') != 'none') {
			for (var TAId in preselectedTAMap) preselectedTAIds[preselectedTAIds.length] = TAId;
			SetDataListSelect($.fn.oneclick('getSettings', AREA_KEY).data, preselectedTAIds);
			$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', AREA_KEY), false);
		}

		if ($('#SearchCriteria_Indication').css('display') != 'none') {
			for (var indId in preselectedIndicationMap) preselectedIndicationIds[preselectedIndicationIds.length] = indId;
			SetDataListSelect($.fn.oneclick('getSettings', INDICATION_KEY).data, preselectedIndicationIds);
			$.fn.oneclick('populateItems', $.fn.oneclick('getSettings', INDICATION_KEY), false);
		}


		$.fn.oneclick('setTooltip', "UpdateAllTooltip");
	},

	GetMinValueForSkill: function (rangeValues, skillValue, isRange) {
		var getValueIndex;
		if (isRange) {
			var valueArray = rangeValues.split("|");
			for (var i = 0; i < valueArray.length; i++) {
				var valueToCheck = $.trim(valueArray[i]);
				var valueToCompare = $.trim(skillValue);
				if (valueToCheck == valueToCompare) {
					getValueIndex = i;
				}

			}
		}
		return getValueIndex;
	},

	ResetOneClicks: function () {
		for (var key = 0; key < keyList.length; key++) {
			//alert(keyList[key]);
			var dataItems = $.fn.oneclick('getSettings', keyList[key]).data.items;
			for (var x = 0; x < dataItems.length; x++)
				dataItems[x].selected = false;
		}
	},

	CheckGridRows: function () {
		this._bSearchEnabled = $("#queueRequests").getGridParam('selarrrow').length > 0;
		if (this._bSearchEnabled) { rm.ui.tabs.enableByIndex("#tabs", rmSearchNs.tabIndex.SearchResults); }
		else { rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SearchResults]); }
		rm.ui.ribbon.refresh();
	},


	CheckSearchGridRows: function () {
		this._bCompareSelectedEnabled = $("#searchResults").getGridParam('selarrrow').length > 0;
		if (this._bCompareSelectedEnabled) { rm.ui.tabs.enableByIndex("#tabs", rmSearchNs.tabIndex.SearchResults); }
		else { rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SearchResults]); }

		this._bViewProfileMatchEnabled = $("#searchResults").getGridParam('selarrrow').length == 1;
		this._bHardBookEnabled = $("#searchResults").getGridParam('selarrrow').length == 1;
		this._bSoftBookEnabled = $("#searchResults").getGridParam('selarrrow').length > 0;
		rm.ui.ribbon.refresh();
	},

	CheckIsFilter: function (divId) {
		var returnValue = false;
		if (typeof LocalData != 'undefined') {
			$.each(LocalData, function (index, ele) {
				if (ele["DivId"] == divId) {
					if (ele["IsFilter"] == true) {
						returnValue = true;
					}
					else {
						returnValue = false;
					}
				}

			});
		}
		return returnValue;
	},

	CheckResourceTypeFilter: function () {
		var resourceTypeId = [];
		var projectIdList = [];
		var countryIdList = [];
		var showSiteList = [];
		selectedShowUnBlindedColumnList = [];
		var selectedrows = $("#queueRequests").getGridParam('selarrrow');
		for (var i = 0; i < selectedrows.length; i++) {
			//ResourceTypeId defined by selected Requests
			var projectIds = $("#queueRequests").getCell(selectedrows[i], "ProjectId");
			projectIdList.push(projectIds);
			var ResourceTypeIdList = $("#queueRequests").getCell(selectedrows[i], "ResourceTypeId");
			resourceTypeId.push(ResourceTypeIdList);
			selectedShowUnBlindedColumnList.push($("#queueRequests").getCell(selectedrows[i], "ShowUnBlindedColumn"));
			var countryIds = $("#queueRequests").getCell(selectedrows[i], "CountryId");
			countryIdList.push(countryIds);
			showSiteList.push($("#queueRequests").getCell(selectedrows[i], "ShowSiteList"));
		}
		projectIdList = $.rm.search.GetUniqueProjectList(projectIdList);
		selectedProjectIdList = projectIdList;
		uniqueSelectedCountryIdList = $.rm.search.GetUniqueProjectList(countryIdList);
		uniqueSelectedShowSiteList = $.rm.search.GetUniqueProjectList(showSiteList);

		var postData = {
			resourceTypeId: resourceTypeId
		};
		if (selectedrows.length > 0) {
            $.rm.Ajax_ResourceSynchronous("GetResourceSearchCriteriaById", postData, function (data) {
                LocalData = data;
				rmSearchNs.showSearchFilters();
				$.each(data, function (index, ele) {
					if (ele["IsDisplay"] != true) {

                        $('#' + ele["DivId"]).hide();
					}
					else {
                        $('#' + ele["DivId"]).show(); 
					}
				});
			}, false);

			var experienceType = $("#queueRequests").getCell(selectedrows[0], "ExperienceTypes");
			var projectData = {
				projectIdList: projectIdList,
				jobRoleId: (experienceType) ? $.parseJSON(experienceType).JobRoleId : -1
			};
			$.rm.search.GetProjectListWhichHasContractualRequirements(projectData);
			$.rm.search.GetProjectsWhichHasFirewalledStudies({ projectIds: projectIdList });
		}
		else {
			resourcingRequirementProjectList = [];
			firewalledProjectList = [];
			$.rm.search._bviewEnabled = false;
			$.rm.search._bFirewalledStudiesViewEnabled = false;
			DisableAllsearchFilterOnLoad();
		}
		rm.ui.ribbon.refresh();
	},

	GetProjectListWhichHasContractualRequirements: function (projectData) {
		resourcingRequirementProjectList = [];
		$.rm.Ajax_ProjectSynchronous("GetProjectListWhichHasContractualRequirements", projectData, function (data) {
			if (data.length > 0) {
				$.each(data, function (index, element) {
					resourcingRequirementProjectList.push({ id: element["projectId"], projectCodeProtocolNumber: element["projectCodeProtocolNumber"], jobRoleId: projectData.jobRoleId });
					$.rm.search._bviewEnabled = true;
				});
			}
			else {
				resourcingRequirementProjectList = [];
				$.rm.search._bviewEnabled = false;
			}

		}, false);
	},

	GetProjectsWhichHasFirewalledStudies: function (projectData) {
		$.rm.Ajax_ProjectSynchronous("GetProjectsWhichHasFirewalledStudies", projectData, function (data) {
			if (data.length > 0) {
				firewalledProjectList = data;
				$.rm.search._bFirewalledStudiesViewEnabled = true;
			}
			else {
				firewalledProjectList = [];
				$.rm.search._bFirewalledStudiesViewEnabled = false;
			}

		}, false);
	},

	GetUniqueProjectList: function (projectList) {
		var uniqueProjectList = [];
		for (var i = 0; i < projectList.length; i++) {
			if ((jQuery.inArray(projectList[i], uniqueProjectList)) == -1) {
				uniqueProjectList.push(projectList[i]);
			}
		}
		return uniqueProjectList;
	},

	CheckSearchGridRows: function () {
		this._bCompareSelectedEnabled = $("#searchResults").getGridParam('selarrrow').length > 0;
		if (this._bCompareSelectedEnabled) { rm.ui.tabs.enableByIndex("#tabs", rmSearchNs.tabIndex.SearchResults); }
		else { rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SearchResults]); }

		this._bViewProfileMatchEnabled = $("#searchResults").getGridParam('selarrrow').length == 1;
		this._bHardBookEnabled = $("#searchResults").getGridParam('selarrrow').length == 1;
		this._bSoftBookEnabled = $("#searchResults").getGridParam('selarrrow').length > 0;
		rm.ui.ribbon.refresh();
	},

	viewResourcingRequirement: function () {
		$('#resourcingRequirementDiv').removeClass('hidden');
		$.rm.search.GetResourcingRequirementDetails();
	},

	viewFirewalledProjects: function () {
		$('#firewalledStudiesDiv').removeClass('hidden');
		$.rm.search.GetFirewalledProjectDetails();
	},

	GetResourcingRequirementDetails: function () {
		$("#resourcingRequirementDiv").tabs();
		rm.ui.tabs.removeAllTabs("#resourcingRequirementDiv");
		if (resourcingRequirementProjectList.length > 0) {
			for (var i = 0; i < resourcingRequirementProjectList.length; i++) {

				$.rm.search.addResourcingRequirementTab(resourcingRequirementProjectList[i]);
				$.rm.search.buildResourcingRequirementGrid(resourcingRequirementProjectList[i].id, resourcingRequirementProjectList[i].jobRoleId);
			}
			$.rm.search.addScrollToTabs();
			rm.ui.dialog.showModal("#resourcingRequirementDiv", "Resourcing Requirements", "", true, 1047, 470);
			rm.ui.tabs.activateByIndex(0);
		}
	},

	GetFirewalledProjectDetails: function () {
		$("#firewalledStudiesDiv").tabs();
		rm.ui.tabs.removeAllTabs("#firewalledStudiesDiv");
		if (firewalledProjectList.length > 0) {
			for (var i = 0; i < firewalledProjectList.length; i++) {
				$.rm.search.addFirewalledProjectTab(firewalledProjectList[i]);
				$.rm.search.BuildFirewalledProjectTable(firewalledProjectList[i]);
			}
			$.rm.search.addScrollToTabs();
			rm.ui.dialog.showModal("#firewalledStudiesDiv", "Firewalled Projects", "", true, 600, 350);
			rm.ui.tabs.activateByIndex(0);
		}
	},

	buildResourcingRequirementGrid: function (projectId, jobRoleId) {
		var postData = {
			projectId: projectId,
			jobRoleId: jobRoleId
		}

		var tableId = "#listExperience" + projectId;
		$(tableId).jqGrid({
		    url: rm.ajax.projectSvcUrl + "GetReadOnlyResourcingRequirements",
			datatype: 'json',
			mtype: 'POST',
			postData: JSON.stringify(postData),
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(true),
			jsonReader: rm.grid.getJqGridJsonReader(),
			//Grid options
			loadonce: true,
			height: '230',
			width: 966,
			rowNum: 9999,
			autowidth: false,
			shrinkToFit: false,
			//Column definitions
			colModel: [
			{ name: 'JobRole', index: 'JobRole', label: 'Job Role', width: 70, classes: 'ui-ellipsis', sortable: false },
			{ name: 'AppliesTo', index: 'AppliesTo', label: 'Applies To', width: 250, sortable: false },
			{ name: 'ResourceRequirementType', index: 'ResourceRequirementType', label: 'Requirement Type', width: 150, classes: 'ui-ellipsis', sortable: false },
			{ name: 'ExperienceCategory', index: 'ExperienceCategory', label: 'Experience Category', width: 180, sortable: false },
			{ name: 'Experience', index: 'Experience', label: 'Experience', width: 291 },
			{ name: 'Notes', index: 'Notes', label: 'Notes', hidden: true },
			{ name: 'JobRoleId', index: 'JobRoleId', label: 'JobRoleId', hidden: true }
			],
			loadComplete: function () {
				var rowIDs = jQuery(tableId).getDataIDs();
				for (var i = 0; i < rowIDs.length; i = i + 1) {
					rowData = jQuery(tableId).getRowData(rowIDs[i]);
					var trElement = jQuery("#" + rowIDs[i], jQuery(tableId));

					if (rowData.ResourceRequirementType == 'Contractual') {
						trElement.removeClass('ui-widget-content');
						trElement.addClass("gridRowBlueBackground");
					}
				}
				var data = jQuery(tableId).jqGrid("getRowData");
				$.rm.search.SetNotes(data, projectId, data[0].JobRoleId);
			},
		});
	},

	BuildFirewalledProjectTable: function (projectObject) {
		var tableId = "#firewalledStudies" + projectObject.Key
		$(projectObject.Value.fireWalledProjects).each(function (index, firwalledProject) {
			$(tableId + ' tbody').last().after('<tr><td>' + firwalledProject.ProjectCode + ' - ' + firwalledProject.ProtocolNumber + '</td></tr>');
		});
	},

	addResourcingRequirementTab: function (projectObject) {
		var tableId = "listExperience" + projectObject.id;
		notesspanid = "Notes" + projectObject.id;
		notesheadinglabelid = "NotesLabel" + projectObject.id;
		var tabId = "resReq" + projectObject.id;
		var tabSelector = "#" + tabId;

		if ($(tabSelector).length == 0) {
			var tabBody = "<div id='" + tabId + "'>" + "<table id='" + tableId + "'> </table>"
											+ "<label style='width=200px;'><span id='" + notesheadinglabelid + "'></span></label> <label class='DisplayNotesInDialog' id='" + notesspanid + "'> </label> </div>";

			rm.ui.tabs.add("#resourcingRequirementDiv", tabSelector, projectObject.projectCodeProtocolNumber, tabBody);
		}
	},

	addFirewalledProjectTab: function (projectObject) {
		var tableId = "firewalledStudies" + projectObject.Key;
		var tabId = "firewalledTab" + projectObject.Key;
		var tabSelector = "#" + tabId;

		if ($(tabSelector).length == 0) {
			var projectCodeProtocolNumber = projectObject.Value.project.ProjectCode + '-' + projectObject.Value.project.ProtocolNumber;
			var tabBody = "<div id='" + tabId + "'><table class= \"tblMatch table-RMProject\" id='" + tableId + "'><thead><tr><th>Project Code - Protocol Number</th></tr></thead><tbody></tbody></table></div>";

			rm.ui.tabs.add("#firewalledStudiesDiv", tabSelector, projectCodeProtocolNumber, tabBody);
		}

		//var projectCodeProtocolNumber = projectObject.Value.project.ProjectCode + '-' + projectObject.Value.project.ProtocolNumber;
		//$("div#firewalledStudiesDiv ul").append(
		//			 "<li><a href='#firewallTabDiv" + projectObject.Key + "'>" + projectCodeProtocolNumber + "</a></li>"
		//	 );
		//var tableId = "firewalledStudies" + projectObject.Key;
		//$("#firewallTabDiv" + projectObject.Key).remove();
		//$("div#firewalledStudiesDiv").append(
		//						"<div id='" + "firewallTabDiv" + projectObject.Key + "'><table class= \"tblMatch table-RMProject\" id='" + tableId + "'><thead><tr><th>Project Code - Protocol Number</th></tr></thead><tbody></tbody></table></div>"
		//	);
	},

	addScrollToTabs: function (tabDiv) {
		$("#resourcingRequirementDiv")
		.find('.ui-tabs-nav')
    .css('white-space', 'nowrap')
    .css('overflow-x', 'auto')
    .css('overflow-y', 'hidden')
    .find('li')
    .css('display', 'inline-block')
    .css('float', 'none')
    .css('vertical-align', 'bottom');

		$("#firewalledStudiesDiv")
		.find('.ui-tabs-nav')
    .css('white-space', 'nowrap')
    .css('overflow-x', 'auto')
    .css('overflow-y', 'hidden')
    .find('li')
    .css('display', 'inline-block')
    .css('float', 'none')
    .css('vertical-align', 'bottom');
	},

	// Clear all Results, usually because user has changed Request or Filter
	ClearResult: function () {
		// Set flags
		// this.ResetRibbonIcons(); // doesn't work well here
		this._bCompareSelectedEnabled = false;
		this._bSoftBookEnabled = false;
		this._bHardBookEnabled = false;
		rm.ui.ribbon.refresh();
		// Clear Charts
		rmChart.clearChart(rmChart.chartType.Request);
		// Move to first Tab and Invalid 2 next ones
		rm.ui.tabs.activateByIndex("#tabs", 0);
		rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SearchResults, rmSearchNs.tabIndex.SelectedProfile]);

	},

	// onclick Event Handler on 'Soft Book' button
	SoftBook: function () {
		var SelectedRequestIds = $("#queueRequests").getGridParam('selarrrow');
		var SelectedResourceIds = $("#searchResults").getGridParam('selarrrow');
		$.rm.searchResults.SoftBooking(SelectedRequestIds, SelectedResourceIds, true);
		//RMK:Added to set the soft booking count at left side panel
		rm.serviceCalls.getRequestCounts();
	},

	// onclick Event Handler on 'Hard Book' button
	HardBook: function () {
		$.rm.searchResults.HardBooking();
		//RMK:Added to set  the count(Resourcing worklist) at left side panel
		rm.serviceCalls.getRequestCounts();
	},

	buildCompareResourceChart: function () {
		var jqGrid = $("#searchResults"),
arRows = jqGrid.getGridParam('selarrrow');

		for (var i = 0, arSel = []; i < arRows.length; i++)
			arSel.push({
				resourceId: jqGrid.getCell(arRows[i], "ResourceId"),
				chartHeading: 'Name:' + jqGrid.getCell(arRows[i], "ResourceName") + ' QID:' + jqGrid.getCell(arRows[i], "QId")
			});

		this.resourceSelected = arSel;

		rm.ui.block('Loading charts');
		rm_timeOut(this.buildCompareResourceChart2, 50, this, arSel);
	},

	buildCompareResourceChart2: function (arSel) {
		//BuildResourceTimingChart(arSel, this.startMonthYear, this.endMonthYear);
		rmChart.selectedProfile.buildChart(arSel, this.startMonthYear, this.endMonthYear);
		rm.ui.unblock();
	},

	ViewProfileMatch: function () {
		this.DisplayViewProfileMatch();
	},

	//*** Run Search
	Search: function () {
		if (IsPopulateZLoaderRunning()) {
			alert(Resources.SearchIsDown);
			return false;
		}

		this._startSearchTime = (new Date()).getTime();
		var selectedrows = $("#queueRequests").getGridParam('selarrrow');
		var customerSelectedInSkills;
		//TODO: create a bigger object that keeps track of all the ids + the names + a method to print the search plan as well
		//   as emit this datacontract object
		var query = {
			customerIds: [],
			studyPhaseIds: [],
			studyPhaseNotQIds: [],
			jobGrades: [],
			jobRoleIds: [],
			regionIds: [],
			subRegionIds: [],
			countryIds: [],
			countryRegionIds: [],
			stateIds: [],
			languageIds: [],
			requestsIds: [],
			organizationIds: [],
			skills: [],
			areaIds: [],
			indicationIds: [],
			msaData: [],
			projectIds: selectedProjectIdList,
			resourceName: $.trim($("#q_search_ResourceName").val()),
			lineManager: $.trim($("#q_search_LineManager").val()),
			minimumCampetencyBandId: null,
			tmfPlatformIds: []
		};

		var sponsors = $.fn.oneclick('getSettings', SPONSOR_KEY).data;
		$(sponsors.items).each(function () { if (this.selected) { query.customerIds[query.customerIds.length] = this.Id; } });

		var studyphases = $.fn.oneclick('getSettings', STUDY_PHASE_KEY).data;
		$(studyphases.items).each(function () { if (this.selected) { query.studyPhaseIds[query.studyPhaseIds.length] = this.Id; } });

		var studyphasesNotQ = $.fn.oneclick('getSettings', STUDY_PHASE_NOTQ_KEY).data;
		$(studyphasesNotQ.items).each(function () { if (this.selected) { query.studyPhaseNotQIds[query.studyPhaseNotQIds.length] = this.Id; } });

		var values = $(jobGradeSliderId).slider("option", "values");
		query.jobGrades = jobGrades.slice(values[0], values[1] + 1);

		var regions = $.fn.oneclick('getSettings', REGION_KEY).data;
		var subregions = $.fn.oneclick('getSettings', SUBREGION_KEY).data;
		$(regions.items).each(function () { if (this.selected) { query.regionIds[query.regionIds.length] = this.Id; } });
		$(subregions.items).each(function () { if (this.selected) { query.subRegionIds[query.subRegionIds.length] = this.Id; } });

		var countries = $.fn.oneclick('getSettings', COUNTRY_KEY).data;
		$(countries.items).each(function () { if (this.selected) { query.countryIds[query.countryIds.length] = this.Id; } });

		var countryRegions = $.fn.oneclick('getSettings', COUNTRY_REGION_KEY).data;
		$(countryRegions.items).each(function () { if (this.selected) { query.countryRegionIds[query.countryRegionIds.length] = this.Id; } });

		var states = $.fn.oneclick('getSettings', STATE_KEY).data;
		$(states.items).each(function () { if (this.selected) { query.stateIds[query.stateIds.length] = this.Id; } });

		var languages = $.fn.oneclick('getSettings', LANGUAGE_KEY).data;
		$(languages.items).each(function () { if (this.selected) { query.languageIds[query.languageIds.length] = this.Id; } });

		var organizations = $.fn.oneclick('getSettings', ORGANIZATION_KEY).data;
		$(organizations.items).each(function () { if (this.selected) { query.organizationIds[query.organizationIds.length] = this.Id; } });

		var skills = $.fn.oneclick('getSettings', SKILL_KEY).data;
		//MR: this uses the oneclick data structure and not the checkboxes themselves
		//  we could just add the min and max values to the datastructure too...
		$(skills.items).each(function () {
			if (this.selected) {
				if (!(this.Id == 83 || this.Id == 317))//SS-check if Experience type id is either customer or Worked on customers reporting system in last five years? checkbox
				{
					query.skills[query.skills.length] = {
						Id: this.Id,
						minValue: this.minSelected == undefined ? -1 : this.minSelected,
						maxValue: this.maxSelected == undefined ? -1 : this.maxSelected
					};
				}
				else {
					customerSelectedInSkills = true;
				}
			}
		});

		var areas = $.fn.oneclick('getSettings', AREA_KEY).data;
		$(areas.items).each(function () { if (this.selected) { query.areaIds[query.areaIds.length] = this.Id; } });

		var jobRoles = $.fn.oneclick('getSettings', JOBROLE_KEY).data;
		$(jobRoles.items).each(function () { if (this.selected) { query.jobRoleIds[query.jobRoleIds.length] = this.Id; } });

		var indications = $.fn.oneclick('getSettings', INDICATION_KEY).data;
		$(indications.items).each(function () { if (this.selected) { query.indicationIds[query.indicationIds.length] = this.Id; } });

		var projects = $.fn.oneclick('getSettings', PROJECT_KEY).data;
		//MR: only check the MSA items where the Project is selected
		$(projects.items).each(function () {
			if (this.selected) {
				var element = $("#hoverTip_" + this.Id);
				if ($(element).data("MSAData") != undefined) {
					query.msaData.push($(element).data("MSAData").MSAViewData);
				}
			}
		});
		var competencyBands = $.fn.oneclick('getSettings', COMPETENCY_BAND_KEY).data;
		$(competencyBands.items).each(function () { if (this.selected) { query.minimumCampetencyBandId = this.Id; } });

		var tmfPlatforms = $.fn.oneclick('getSettings', TMF_PLATFORM_KEY).data;
		$(tmfPlatforms.items).each(function () { if (this.selected) { query.tmfPlatformIds.push(this.Id); } });

		var ordinalTmf = $.fn.oneclick('getSettings', ORDINAL_TMF_KEY).data;
		query.ordinalTmf = {};
		$(ordinalTmf.items).each(function () {
			query.ordinalTmf[this.Id] = !!this.selected;
		});

		//Get all the selected requests...
		for (var x = 0; x < selectedrows.length; x++) {
			query.requestsIds[query.requestsIds.length] = parseInt($('#queueRequests').getCell(selectedrows[x], 'RequestId'));
		}

		if ($.trim($("#q_search_ResourceName").val()) == "" && $.trim($("#q_search_LineManager").val()) == "") {
			//MR: 'Slightly' friendlier way to handle the mutually exclusive search filters
			//  TODO: only allow selection of one at a time
			//  TODO: for multiple requests, how do we handle it wanting to selecting multiple countries for instance?
			var duplicateMsg = "Two or more ### have been selected as part of the search criteria, therefore no search results can be displayed.  Please adjust the selected ###, either by changing the search filters on the left of the screen or by selecting requests that share common ###.";

			if (query.stateIds.length > 1) {
				alert(duplicateMsg.replace(/###/g, "State/Provinces"));
				return;
			}
			if (query.countryRegionIds.length > 1) {
				alert(duplicateMsg.replace(/###/g, "Country Regions"));
				return;
			}
			if (query.countryIds.length > 1) {
				alert(duplicateMsg.replace(/###/g, "Countries"));
				return;
			}
			if (query.subRegionIds.length > 1) {
				alert(duplicateMsg.replace(/###/g, "Subregions"));
				return;
			}
			if (query.regionIds.length > 1) {
				alert(duplicateMsg.replace(/###/g, "Regions"));
				return;
			}
			if (query.organizationIds.length > 1) {
				alert(duplicateMsg.replace(/###/g, "Organizations"));
				return;
			}
			if (query.jobRoleIds.length > 2) {
				var msg = "Can only select up to two Job Roles at a time.";
				alert(msg);
				return;
			}
		}

		if (query.customerIds.length == 0 && customerSelectedInSkills)//SS-Add customer id since either checkbox is selected in skills accordian
		{
			$(sponsors.items).each(function () { if (this) { query.customerIds[query.customerIds.length] = this.Id; } });
		}

		var searchCriteria = JSON.stringify(query);
		$("#divLog").html(searchCriteria);

		$.rm.search.BuildSearchResultsGrid(query);
		$.rm.search.bindSearchResultsGridLabelQtip();
	},



	SetupSearchFilters: function (SearchFilters) {

		$.ajax({
			type: "GET",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.utilitySvcUrl + "Geography/GetRegionsLite",
			dataType: "text",
			cache: false,
			success: function (result) {
				var g = { geography: $.parseJSON(result) };

				$.rm.search.initOneClicks(g);
				$.rm.search.initUi();

			},
			error: function (errMsg) { }
		});
	},

	ResetFilters: function () {
		this.AdjustFilters(true);
	},

	CompareSelectedEnabled: function () { return this._bCompareSelectedEnabled; },
	SoftBookEnabled: function () { return this._bSoftBookEnabled; },
	HardBookEnabled: function () { return this._bHardBookEnabled; },
	SearchEnabled: function () { return this._bSearchEnabled; },
	ResetFiltersEnabled: function () { return this._bSearchEnabled; },
	ViewProfileMatchEnabled: function () { return this._bViewProfileMatchEnabled; },
	viewEnabled: function () {
		var resReqListViewButton = $("[id*=ViewResourcingRequirements]");
		var resReqListNEViewButton = $("[id*=ViewResourcingRequirementsNotExist]");
		if ($.rm.search._bviewEnabled) {
			resReqListViewButton.show();
			resReqListNEViewButton.hide();
		}
		else {
			resReqListViewButton.hide();
			resReqListNEViewButton.show();
			if ($('#resSpacer').length > 0) {
				$('#resSpacer').remove();
			}
			if ($("#queueRequests").getGridParam('selarrrow') != undefined && $("#queueRequests").getGridParam('selarrrow').length > 0) {
				$.rm.search.ShowViewDisabledHoverOverMessage();
			}
		}
		return $.rm.search._bviewEnabled;
	},
	firewalledProjectViewEnabled: function () {
		var firewalledProjects = $("[id*=FirewalledProjects]");
		var firewalledProjectsNotExist = $("[id*=FirewalledProjectsNotExist]");
		if ($.rm.search._bFirewalledStudiesViewEnabled) {
			firewalledProjects.show();
			firewalledProjectsNotExist.hide();
		}
		else {
			firewalledProjects.hide();
			firewalledProjectsNotExist.show();
			if ($('#resSpacerFirewall').length > 0) {
				$('#resSpacerFirewall').remove();
			}
			if ($("#queueRequests").getGridParam('selarrrow') != undefined && $("#queueRequests").getGridParam('selarrrow').length > 0) {
				$.rm.search.ShowViewDisabledHoverOverMessageForFirewalledbutton();
			}
		}
		return $.rm.search._bFirewalledStudiesViewEnabled;
	},
	isSiteListEnabled: function () {
		if (rm.grid.hasRowsSelected("#queueRequests")) {
			if (uniqueSelectedCountryIdList.length == 1 && selectedProjectIdList.length == 1 && uniqueSelectedShowSiteList.length == 1)
				return uniqueSelectedShowSiteList[0] == "true";
		}

	},
	viewSiteListDetials: function () {
		$("#divSiteListDetails").load("../SiteListDetailsDialog.aspx?projectId=" + selectedProjectIdList[0] + "&countryId=" + uniqueSelectedCountryIdList[0] + "").dialog({
			autoOpen: false,
			draggable: false,
			modal: true,
			resizable: true,
			width: 1240,
			title: "Site List",
			height: 500,
			open: function (event, ui) {
				//hide close button.
				$(this).parent().children().children('.ui-dialog-titlebar-close').hide();
			},
			buttons: {
				"Close": function () {
					$(this).dialog("close");
				}
			}
		});
		$("#divSiteListDetails").dialog('open');
	},
	editSelectedRowEnabled: function () {
		return rm.grid.hasSingleRowSelected("#queueRequests") && uniqueSelectedShowSiteList[0] == "true";
	},
	editSelectedRow: function () {
		var selectedrows = $("#queueRequests").getGridParam('selarrrow');
		document.location.href = "/_layouts/SPUI/Requests/EditRequestNew.aspx?requestId=" + selectedrows[0] + "&rmPageLink=" + $.rm.search.GetRmPageLinkId() + "&RequestGroupId=" + $("#ddlResourceGroup").val();
	},
	GetRmPageLinkId: function () {
		return 13; // Resourcing Worklist
	},
	BuildResourcingWorklistGrid: function () {
		var gridDataFromServer = null;
		var gridSelector = "#queueRequests";
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ResourcingWorklist };
		rm.grid.showGridTools(gridSelector, gridToolsConfig);

		$(gridSelector).jqGrid({
		    url: rm.ajax.requestSvcUrl + "GetOpenRequestsFromQueue",
			datatype: 'json',
			postData: { RequestTypeResourceTypeGroupId: $("#ddlResourceGroup").val() == null ? "-1" : $("#ddlResourceGroup").val() },
			mtype: 'POST',
			loadonce: true,
			pager: '#queueRequestsPager',
			height: 250,
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false, "GetOpenRequestsFromQueue", false, false),
			multiselect: true,
			autowidth: false,
			shrinkToFit: false,
			width: rm.ui.getContentContainerWidth() - rm.runtimeValues.gridOffsetWidth,
			forceFit: true,
			viewsortcols: [true, 'vertical', true],
			sortname: 'NeedDate',
			sortorder: 'asc',
			jsonReader: rm.grid.getJqGridJsonReader(),
			colModel: [
			{ name: 'ExperienceTypes', index: 'ExperienceTypes', label: 'Experience Types', hidden: true },
			{ name: 'Message', index: 'Message', label: ' ', hidden: false, formatter: rm.grid.drawIndicator, search: false, width: 30, searchoptions: { sopt: ['cn'] } },
			{ name: 'MonthlySched', index: 'MonthlySched', label: 'MonthlySched', hidden: true },
			{ name: 'RequestId', index: 'RequestId', label: '', hidden: false, width: 70 },
			{ name: 'DateSubmittedAsDateTime', index: 'DateSubmittedAsDateTime', label: 'Submitted<br />Date', search: false, width: 80, formatter: 'date', datefmt: 'd-M-Y', formatoptions: { newformat: 'd-M-Y' }, classes: 'CssToUpper' },
			{ name: 'GeographyIds', index: 'GeographyIds', label: '', hidden: true },
			{ name: 'LanguageIds', index: 'LanguageIds', label: '', hidden: true },
			{ name: 'StudyPhaseId', index: 'StudyPhaseId', label: '', hidden: true },
			{ name: 'ProjectTA', index: 'ProjectTA', label: '', hidden: true },//RMK Added
			{ name: 'ProjectIndication', index: 'ProjectIndication', label: '', hidden: true },//RMK Added
			{ name: 'OrganizationalUnitIds', index: 'OrganizationalUnitIds', label: '', hidden: true },
			{ name: 'IconColumn', index: 'IconColumn', label: 'Request Status <br />Indicator', width: 120, search: true, sortable: false, hidden: false, stype: 'select', searchoptions: { sopt: ['cn'], value: ":All;" + rm.grid.filterOptions.iconSearch_ClientSide } },
			{ name: 'NeedDate', index: 'NeedDate', label: 'Need by<br/>Date', width: 85, search: true, sorttype: function (cellValue, rowObject) { return rowObject.NeedDateSort; } },
			{ name: 'Region', index: 'Region', label: 'Region', resizable: false, width: 50, searchoptions: { sopt: ['cn'] } },
			{ name: 'Country', index: 'Country', label: 'Country', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'CountryRegion', index: 'CountryRegion', label: 'Country Region', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'AssignedRegions', index: 'AssignedRegions', label: 'Assigned Regions', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'AssignedCountries', index: 'AssignedCountries', label: 'Assigned Countries', width: 125, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'ProposalResource', index: 'ProposalResource', label: 'Proposal Resource<br/>Name', width: 120, classes: 'ui-ellipsis', search: true, searchoptions: { sopt: ['cn'] } },
			{ name: 'Sponsor', index: 'Sponsor', label: 'Customer', width: 60, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'SponsorId', index: 'SponsorId', label: '', hidden: true },
			{ name: 'Program', index: 'Program', label: 'Program', width: 60, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'ProjectCode', index: 'ProjectCode', label: 'Project<br/>Code', width: 65, search: true, searchoptions: { sopt: ['cn'] } },
			{ name: 'ProjectId', index: 'ProjectId', label: '', hidden: true },
			{ name: 'Protocol', index: 'Protocol', label: 'Protocol', width: 100, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'ProjectDteType', index: 'ProjectDteType', label: 'RBM Project', width: 100, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 3 } } },
			{ name: 'SiteStatus', index: 'SiteStatus', label: 'Site Status', width: 100, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'SponsorSiteId', index: 'SponsorSiteId', label: 'Sponsor Site Id', width: 100, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'PrincipalInvestigator', index: 'PrincipalInvestigator', label: 'PI', width: 75, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'Location', index: 'Address', label: 'Location', width: 75, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'VisitType', index: 'VisitType', label: 'Visit<br />Type', width: 60, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'], attr: { maxlength: 255 } } },
			{ name: 'SSVType', index: 'SSVType', label: 'SSV Type', width: 70, searchoptions: { sopt: ['cn'] } },
			{ name: 'Cluster', index: 'Cluster', label: 'Cluster', width: 75, search: true, classes: 'ui-ellipsis', searchoptions: { sopt: ['cn'] } },
			{ name: 'ResourceType', index: 'ResourceType', label: 'Resource<br/>Request Type', hidden: true },
			{ name: 'RequestBlinded', index: 'RequestBlinded', label: 'Request<br />Blinded', width: 100, classes: 'ui-ellipsis', sortable: true, search: true },
			{ name: 'SearchResourceType', index: 'SearchResourceType', label: 'Resource<br/>Request Type', width: 200, search: true, classes: 'ui-ellipsis', stype: 'select', searchoptions: { sopt: ['eq'], value: "-1:All" } },
			{ name: 'ResourceTypeId', index: 'ResourceTypeId', label: '', hidden: true },
			{ name: 'RequestTypeId', index: 'RequestTypeId', label: '', hidden: true },
			{ name: 'ShowUnBlindedColumn', index: 'ShowUnBlindedColumn', label: '', hidden: true },
			{ name: 'NeedDateSort', index: 'NeedDateSort', label: 'Need Date Sort', sorttype: 'date', hidden: true },
			{ name: 'FTE', index: 'FTE', label: 'FTE', width: 30, search: true, cellsformat: 'F3' },
			{
				name: 'CRATrainingDate', index: 'CRATrainingDate', label: 'CRA<br/>Training Date', width: 95, search: true,
				sorttype: function (cellValue, rowObject) { return rowObject.CRATrainingDateSort; }
			},
			{ name: 'CRATrainingDateSort', index: 'CRATrainingDateSort', label: '', sorttype: 'date', hidden: true },

			{
				name: 'StartDate', index: 'StartDate', label: 'Start Date', width: 85, search: true,
				sorttype: function (cellValue, rowObject) { return rowObject.StartDateSort; }
			},
			{ name: 'StartDateSort', index: 'StartDateSort', label: '', sorttype: 'date', hidden: true },
			{
				name: 'StopDate', index: 'StopDate', label: 'Stop Date', width: 85, search: true,
				sorttype: function (cellValue, rowObject) { return rowObject.StopDateSort; }
			},
			{ name: 'StopDateSort', index: 'StopDateSort', label: '', sorttype: 'date', hidden: true },
			{ name: 'Notes', index: 'Notes', label: 'Notes', sortable: false, align: 'center', width: 50, search: false },
			{ name: 'CompetencyBandId', index: 'CompetencyBandId', label: '', sorttype: 'CompetencyBandId', hidden: true },
			{ name: 'CompetencyBandName', index: 'CompetencyBandName', label: '', sorttype: 'CompetencyBandName', hidden: true },
			{ name: 'SiteId', index: 'SiteId', label: 'SiteId', sorttype: 'SiteId', hidden: true },
			{ name: 'CountryId', index: 'CountryId', label: 'CountryId', sorttype: 'CountryId', hidden: true },
			{ name: 'ShowSiteList', index: 'ShowSiteList', label: 'ShowSiteList', sorttype: 'ShowSiteList', hidden: true },
			],
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			onSelectRow: function (id, status) {
				$.rm.search.ResetJobRoles();
				if (!MakeSingleCallForRequests) {
					rm.ui.block('Loading charts');
					rm_timeOut(this.p.onSelectRow2, 50, this, id, status);
				}
				if ($("#queueRequests").getGridParam('selarrrow').length == 0) {
					$('#chkSelectAll').removeAttr('checked');
				}
				$.rm.search.CheckResourceTypeFilter();

			},
			onSelectRow2: function (id, status) {
				$.rm.search.CheckGridRows();
				$.rm.search.AdjustFilters(!status);

				rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SearchResults, rmSearchNs.tabIndex.SelectedProfile]);
				var jqTblQueueRequests = $("#queueRequests");
				var reqID = jqTblQueueRequests.getCell(id, 'RequestId');
				var projId = jqTblQueueRequests.getCell(id, 'ProjectId');
				var projectCode = jqTblQueueRequests.getCell(id, 'ProjectCode');

				if (status) {
					var reqeustIdProjectMap = {};
					reqeustIdProjectMap[reqID] = projectCode;
					rmChart.addRequestsToGraph([reqID], "#queueRequests", "Message", reqeustIdProjectMap);
				}
				else {
					rmChart.removeRequestFromGraph(reqID);
				}
				// Keep the "check all" checkbox in sync (why isn't this done by default?!?)
				$('#cb_queueRequests').attr('checked', ($("#queueRequests").getGridParam('selarrrow').length == $("#queueRequests").getGridParam('records')));
				rm.ui.unblock();
			},
			beforeSelectRow: function (rowid, e) // return false to not allow row selection
			{
				var cbsdis = $("tr#" + rowid + ".jqgrow > td > input.cbox:disabled", $("#queueRequests")[0]);
				return (cbsdis.length === 0);
			},
			onSelectAll: function (rowIdxArray, status) {
				$.rm.search.CheckGridRows();
				$.rm.search.AdjustFilters(!status);
			},
			onPaging: function () {
				$.rm.search.ResetRibbonIcons();
				$('#chkSelectAll').removeAttr('checked');
			},
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("queueRequests"); },
			caption: 'Resourcing Worklist',
			serializeGridData: function (data) {
				data.RequestTypeResourceTypeGroupId = $("#ddlResourceGroup").val();
				return rm.grid.serializeGridData(data);
			},
			loadComplete: function (data) {
				if (rmSearchNs.fetchingRequestWorklistDataFromServer) {
					gridDataFromServer = data;
					rm.grid.rowData.attachAllRowsData("#queueRequests", data);
					rmSearchNs.fetchingRequestWorklistDataFromServer = false;
				}
				else {
					rm.grid.rowData.attachAllRowsData("#queueRequests", gridDataFromServer);
				}
			},
			gridComplete: function () {
				rm.grid.addTitlesOnIconColumn();
				rmChart.clearRequestChartSeries();

				rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SearchResults, rmSearchNs.tabIndex.SelectedProfile]);

				$.rm.requestCommon.BindFTECalculatorClick(".calcImage");
				rm.ui.notes.bindNotesIconClick();
				if ($("#chkSelectAll").size() == 0) {
					$("#jqgh_queueRequests_cb").prepend("<input type='checkbox' id='chkSelectAll' style='disabled: true;' />")
				}
				if (!isDisableGridCheckbox) {
					handleGridCheckbox(true);
				}
				else {
					handleGridCheckbox(false);
				}
				setTimeout($.rm.search.bindLabelQtip, 20);
			}
		});

		$("#queueRequests").jqGrid('filterToolbar',
		{
			searchOnEnter: true,
			autosearch: true,
			afterSearch: function () {
				$.rm.search.AdjustFilters(true);
			}
		});
		$("#cb_queueRequests").hide();
	},

	BuildSearchResultsGrid: function (searchCriteria) {
		//SD:TODO: find out how to check if grid fired search or sort command
		var fetchingDataFromServer = true;
		var serverData = {};

		//This is creating a huge postData object that the search filters cannot use to filter the search results
		//   Shrirang and I hacked the jqGrid source to convert the postData to JSON object before extending with search filter
		//TODO: Will need to test again when we attempt to get server side paging working
		if ($("#queueRequests").getGridParam('selarrrow').length == 0 && searchCodeValues.showGraphErrors) {
			alert(Resources.NoReqeustsSelectedForSearch);
			return;
		}
		rm.ui.block("Searching Resources");
		if (!this.isResMatchAccordeon) {
			this.isResMatchAccordeon = true;
		}

		rmChart.clearResourceChartSeries();

		var jsonText = JSON.stringify({ searchCriteria: searchCriteria });
		var random = Math.random() * 1000000;

		$("[id^=divPrjBooking],[id^=divProgBooking]").remove();

		$("#searchResults").jqGrid('GridUnload');

		$("#searchResults").jqGrid(
		{
			//override default of 25
			rowNum: 100,

			url: rm.ajax.requestSvcUrl + "Search?rand=" + random,
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false, "Search", true), // VG: handle error
			datatype: 'json',
			mtype: 'POST',
			postData: jsonText,
			loadonce: true,
			pager: '#searchResultsPager',
			height: 250,
			width: rm.ui.getContentContainerWidth() - rm.runtimeValues.gridOffsetWidth,
			multiselect: true,
			autowidth: false,
			shrinkToFit: false,
			forceFit: true,
			viewsortcols: [true, 'vertical', true],
			sortname: 'MatchPercent',
			sortorder: 'desc',
			caption: 'Search Results',

			jsonReader: rm.grid.getJqGridJsonReader(),
			colModel: [
				{ name: 'ResourceId', index: 'ResourceId', label: 'PK', hidden: true },
				{ name: 'Message', index: 'Message', label: ' ', hidden: false, formatter: rm.grid.drawIndicator, search: false, width: 30 },
				{ name: 'ProjectMatch', index: 'ProjectMatch', label: 'Project', hidden: false, formatter: rmSearchNs.drawProjectMatchIndicator, search: false, width: 53 },
				{ name: 'ProgramMatch', index: 'ProgramMatch', label: 'Program', hidden: false, formatter: rmSearchNs.drawProgramMatchIndicator, search: false, width: 57 },
				{ name: 'ProgramUnblinded', index: 'ProgramUnblinded', label: 'Program <br> Unblinded', formatter: rmSearchNs.drawRequestUnBlindedIndicator, width: 65, search: false },
				{ name: 'ResourceFireWalled', index: 'ResourceFireWalled', classes: 'resourceFireWalledClass', label: 'ResourceFireWalled', formatter: rmSearchNs.drawProjectFireWalledIndicator, search: false, sortable: false, width: 57 },
				{ name: 'ResourceFireWalledDetailsHtml', index: 'ResourceFireWalledDetailsHtml', label: 'ResourceFireWalledDetailsHtml', hidden: true },
				{ name: 'MonthlyHours', index: 'MonthlyHours', label: '', hidden: true },
				{ name: 'Availability', index: 'Availability', label: '% Avail', width: 60, search: true, sorttype: 'float', searchoptions: { sopt: ['cn'] } },
				{ name: 'MaxOverbook', index: 'MaxOverbook', label: 'Max Over', width: 60, search: true, sorttype: 'float', hidden: true },
				{ name: 'AvailPercent', index: 'AvailPercent', label: '% AvailHidden', width: 60, search: true, sorttype: 'float', hidden: true },
				{ name: 'QId', index: 'QId', label: 'QId', width: 80, search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'ResourceName', index: 'ResourceName', label: 'Resource Name', width: 150, search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'TmfPlatform', index: 'TmfPlatform', label: 'TMF Platform', width: 150, search: true, hidden: !rmSearchNs.showTmfPlatformColumn() },
				{ name: 'ResourceJobRoleName', index: 'ResourceJobRoleName', label: 'Job Role', width: 150, search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'CompetencyBandName', index: 'CompetencyBandName', label: 'Competency Band', width: 150, search: true, hidden: true },
				{ name: 'Organization', index: 'Organization', label: 'Organization', width: 150, search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'EmpStatus', index: 'EmpStatus', label: 'Emp Status', width: 80, search: true, hidden: true },
				{ name: 'CountryRegionName', index: 'CountryRegionName', label: 'Home<br/>Country Region', width: 150, search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'Location', index: 'Location', label: 'Home Location', width: 125, search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'WorkCountry', index: 'WorkCountry', label: 'Work Country', width: 125, search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'LineManager', index: 'LineManager', label: 'Manager', width: 125, search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'Notes', index: 'Notes', label: 'Notes', width: 80, search: false },
						//MR: Do not remove these hidden fields - they are required for profile match popup
						{ name: 'JobTitle', index: 'JobTitle', label: 'Job Title', width: 125, hidden: true },
						{ name: 'JobGrade', index: 'JobGrade', label: 'Job Grade', width: 125, hidden: true },
						{ name: 'StudyPhaseListNotQ', index: 'StudyPhaseListNotQ', label: 'Not Q Phase(s)', width: 100, hidden: true },
						{ name: 'StudyPhaseListQ', index: 'StudyPhaseListQ', label: 'Q Phase(s)', width: 100, hidden: true },
						{ name: 'LanguageList', index: 'LanguageList', label: 'Language(s)', width: 100, hidden: true },
						{ name: 'SkillList', index: 'SkillList', label: 'Skill(s)', width: 100, hidden: true },
						{ name: 'IndicationList', index: 'IndicationList', label: 'Indication(s)', width: 100, hidden: true },
						{ name: 'AreaList', index: 'AreaList', label: 'Area(s)', width: 100, hidden: true },
						{ name: 'Education', index: 'Education', label: 'Education', width: 100, hidden: true },
						{ name: 'SponsorList', index: 'SponsorList', label: 'SponsorList', width: 100, hidden: true },
						{ name: 'SpecialPopulatationQ', index: 'SpecialPopulatationQ', label: 'Q Special Populatation', width: 100, hidden: true },
						{ name: 'SpecialPopulatationNotQ', index: 'SpecialPopulatationNotQ', label: 'Not Q Special Populatation', width: 100, hidden: true },
						{ name: 'DrugClassQ', index: 'DrugClassQ', label: 'Q Drug Class', width: 100, hidden: true },
						{ name: 'DrugClassNotQ', index: 'DrugClassNotQ', label: 'Not Q Drug Class', width: 100, hidden: true },
						{ name: 'RoleQ', index: 'RoleQ', label: 'Q Role', width: 100, hidden: true },
						{ name: 'RoleNotQ', index: 'RoleNotQ', label: 'Not Q Role', width: 100, hidden: true },
						{ name: 'IndustryTypeNotQ', index: 'IndustryTypeNotQ', label: 'Not Q Industry Type', width: 100, hidden: true },
						{ name: 'RegionNotQ', index: 'RegionNotQ', label: 'Not Q Region', width: 100, hidden: true },
						{ name: 'IndicationQ', index: 'IndicationQ', label: 'Q Indication', width: 100, hidden: true },
						{ name: 'IndicationNotQ', index: 'IndicationNotQ', label: 'Not Q Indication', width: 100, hidden: true },
						{ name: 'SkillValues', index: 'SkillValues', label: 'SkillValues', width: 100, hidden: true },
						{ name: 'MatchPercent', index: 'MatchPercent', label: '% Match', width: 70, search: true, hidden: true, sorttype: 'float' }
			],
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			onSelectRow: function (id, status) {
				rm.ui.block('Loading charts');
				rm_timeOut(this.p.onSelectRow2, 50, this, id, status);
			},
			onSelectRow2: function (id, status) {
				var rowJson = rm.grid.rowData.getById("#searchResults", id)
				if (rowJson.ResReqErrors !== null && rowJson.ResReqErrors.length > 0 && searchCodeValues.showGraphErrors && status) {
					resourcesAssignedToBadRequests += rowJson.ResourceName + ",";
					alert("For " + rowJson.ResourceName + " , the RM system was not able to display the Resource Profile graph due to errors.  Please refer to the People and Project report to view details of the error or click on ‘help’ for more information.");
				}
				var rmSearch = $.rm.search;
				rmSearch.CheckSearchGridRows();

				var jqTblQueueRequests = $("#searchResults");
				var resourceName = jqTblQueueRequests.getCell(id, 'ResourceName');
				var reqData = jqTblQueueRequests.getCell(id, 'MonthlyHours');
				if (!reqData && searchCodeValues.showGraphErrors) {
					alert('MonthlyHours data not found in Grid for ResourceName=' + resourceName);
					return;
				}

				if (rmSearch._bCompareSelectedEnabled) { rm.ui.tabs.enableByIndex("#tabs", rmSearchNs.tabIndex.SelectedProfile); }
				else { rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SelectedProfile]); }
				if (status) {
					rmChart.addResourceToGraph(resourceName, id, reqData);
				}
				else {
					rmChart.removeResourceFromGraph(id);
				}
				//***
				// Keep the "check all" checkbox in sync (why isn't this done by default?!?)
				$('#cb_searchResults').attr('checked', ($("#searchResults").getGridParam('selarrrow').length == $("#searchResults").getGridParam('records')));
				rm.ui.unblock();
			},
			onSelectAll: function (rowIdxArray, status) {
				var gridInstance = this;
				$.each(rowIdxArray, function (index, id) {
					rm_timeOut(gridInstance.p.onSelectRow2, 50, gridInstance, id, status);
				});
			},
			loadComplete: function (data) {
				rm.ui.unblock();
				//User data should be set only when data is fetched from server. Do not overwrite user data when grid gets filteres or sorted
				if (fetchingDataFromServer) {
					serverData = data;
					rm.grid.rowData.attachAllRowsData("#searchResults", data);
					var $this = $(this);
					if ($this.jqGrid('getGridParam', 'datatype') === 'json')/*SS:first time data type would be json, second time this wont get exectued, even if it does datatype would have changed to local*/ {
						if ($this.jqGrid('getGridParam', 'sortname') !== '') {
							//SS: we need to reload grid only if we use sortname parameter,
							//SS: but the server returned unsorted data
							setTimeout(function () {
								$this.triggerHandler('reloadGrid');
							}, 50);
						}
					}
					fetchingDataFromServer = false;
				}
				else {
					rm.grid.rowData.attachAllRowsData("#searchResults", serverData);
				}

				if ($('#searchResults tr').find('.resourceFireWallMatch').length <= 0)
					$("#searchResults").jqGrid("hideCol", "ResourceFireWalled");
				else
					$("#searchResults").jqGrid("showCol", "ResourceFireWalled");

				//Hide Blinded Columns
				if ($.inArray("Yes", selectedShowUnBlindedColumnList) != -1) {
					$("#searchResults").jqGrid("showCol", "ProgramUnblinded");
				}
				else {
					$("#searchResults").jqGrid("hideCol", "ProgramUnblinded");
				}
				if ($('#SearchCriteria_CompetencyBand').css('display') != 'none') {
					$("#searchResults").jqGrid("showCol", "CompetencyBandName");
				}
				else {
					$("#searchResults").jqGrid("hideCol", "CompetencyBandName");
				}

				//MR: on subsequent filters, sorts, these properties of data are lost
				if (data.JsClientData) {
					//Get the Search Plan data structure and render
					if (data.JsClientData.HardBookError && searchCodeValues.showGraphErrors) {
						alert("Hardbook Error\n" + data.JsClientData.HardBookError);
						RefreshPage();
						return;
					}
					else {
						rm.ui.tabs.enableByIndex("#tabs", 0);
						rm.ui.tabs.enableByIndex("#tabs", 1);
						rm.ui.tabs.activateByIndex("#tabs", 1);
						$("#divResMatchAvail_accordeon").accordion("option", "active", 0);
						if (data.JsClientData.AvailabilityError && searchCodeValues.showGraphErrors) {
							alert("Availability Error\n" + data.JsClientData.AvailabilityError);
						}

						// Display timing info
						//var timeTotal = (new Date()).getTime() - $.rm.search._startSearchTime; // in ms
						//if (!timeTotal) timeTotal = 1;
						/*alert("Search Time Total = " + (timeTotal / 1000).toPrecision(2) + " sec\n" +
		"Server = " + data.TotalSearchTimeInSec.toPrecision(2) + " sec = " + Math.round(100 * 1000 * data.TotalSearchTimeInSec / timeTotal) + "%\n" +
		"     Filter = " + data.FilterTime + '\n' +
		"     Availability=" + data.AvailabilityTime + '\n' +
		"     MatchTime=" + data.MatchTime + "\n");
		*/
						$.rm.search._searchPlan = data.JsClientData.SearchPlan;

						$.rm.search.startMonthYear = data.JsClientData.StartMonthYear;
						$.rm.search.endMonthYear = data.JsClientData.EndMonthYear;

						$.rm.search.arTotalMonthlyHours = data.JsClientData.TotalMonthlyHours;
						$.rm.search.arTotalMonthlyFTE = data.JsClientData.TotalMonthlyFTE;

						//***
						$.rm.search.PrintSearchPlan($.rm.search._searchPlan);
					}
					$("#jqgh_searchResults_Availability").attr("title", "Percentage Resource Availability");
					$("#jqgh_searchResults_MatchPercent").attr("title", "Percentage Desired Experience Match");
					$("#jqgh_searchResults_MaxOverbook").attr("title", "Max Over Book");
					$("#jqgh_searchResults_ResourceFireWalled").attr("title", "One or more returned Resources are Booked to a Firewalled Project");

				}
			},
			gridComplete: function () {
				rmChart.clearResourceChartSeries();
				rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SelectedProfile]);
				rm.ui.notes.bindNotesIconClick();
				$("#searchResults").find("[id^=img]").each(function (index, element) {
					rm.qtip.showInfo(element, $(element).attr("tooltiptextdata"), { width: "auto" })
				});
			}
		});

		$('#jqgh_searchResults_ResourceFireWalled').text(''); //To hide the column label.
		$("#searchResults").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
		$("#cb_searchResults").hide();
	},
	bindSearchResultsGridLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn("#searchResults_CompetencyBandName", "PM Competency Band");
	},

	PrintMSA: function (msaData, divSelector) {
		var arealist = [];
		var indicationlist = [];
		var br = "<br />";
		var kelist = [];

		$.each(msaData, function (i, msa) {
			if (msa.HasData) {
				$.each(msa.TherapeuticAreas, function (a, area) {
					if (area.Checked) arealist[arealist.length] = area.Name;
				});
				$.each(msa.IndicationAreas, function (indIndex, indication) {
					if (indication.Checked) indicationlist[indicationlist.length] = indication.Name;
				});

				//Education not included in search
				if (msa.Education != null && msa.Education.Enabled && msa.Education.Checked) {
					kelist[kelist.length] = "Education: " + msa.Education.Value;
				}

				//Global Project Experience
				if (msa.GlobalProjectExperience != null && msa.GlobalProjectExperience.Enabled && msa.GlobalProjectExperience.Checked) {
					kelist[kelist.length] = "Global Project Experience: " + (msa.GlobalProjectExperience.ValueAdjusted == "-1" ?
						$.rm.search.GetExpTypeRangeValue(msa.ExpTypes, 10, msa.GlobalProjectExperience.Value) :
						$.rm.search.GetExpTypeRangeValue(msa.ExpTypes, 10, msa.GlobalProjectExperience.ValueAdjusted));
				}

				//InHouse
				if (msa.InHouse != null && msa.InHouse.Enabled && msa.InHouse.Checked) {
					kelist[kelist.length] = msa.InHouse.ValueAdjusted == "-1" ?
						$.rm.search.GetExpTypeName(msa.ExpTypes, msa.InHouse.Value) : $.rm.search.GetExpTypeName(msa.ExpTypes, msa.InHouse.ValueAdjusted);
				}
				//OnSite
				if (msa.OnSite != null && msa.OnSite.Enabled && msa.OnSite.Checked) {
					kelist[kelist.length] = msa.OnSite.ValueAdjusted == "-1" ?
						$.rm.search.GetExpTypeName(msa.ExpTypes, msa.OnSite.Value) : $.rm.search.GetExpTypeName(msa.ExpTypes, msa.OnSite.ValueAdjusted);
				}
			}
		});

		$(divSelector).html(kelist.join(br) + "<br />Areas: [" + arealist.join(", ") + "], Indications: [" + indicationlist.join(", ") + "]");

	},


	GetExpTypeRangeValue: function (expTypes, id, index) {
		//return the id if we can't find the name
		var name = index;
		$.each(expTypes, function (i, et) {
			if (et.Id == id) {
				rangeValues = et.RangeValues.split("|");
				name = rangeValues[index];
			}
		});
		return name;
	},

	GetExpTypeName: function (expTypes, id) {
		//return the id if we can't find the name
		var name = id;
		$.each(expTypes, function (i, et) {
			if (et.Id == id) {
				name = et.Name;
			}
		});
		return name;
	},

	PrintSearchPlan: function (searchPlan) {
		//Required
		this.PrintSearchItems(searchPlan.RequiredStudyPhasesNotQ, "#searchPlan #search_studyphasesnotq");
		this.PrintSearchItems(searchPlan.RequiredStudyPhases, "#searchPlan #search_studyphasesq");
		this.PrintSearchItems(searchPlan.OrganizationalUnits, "#searchPlan #search_organizations");
		this.PrintSearchItems(searchPlan.Regions, "#searchPlan #search_regions");
		this.PrintSearchItems(searchPlan.Subregions, "#searchPlan #search_subregions");
		this.PrintSearchItems(searchPlan.Countries, "#searchPlan #search_countries");
		this.PrintSearchItems(searchPlan.CountryRegions, "#searchPlan #search_countryregions");
		this.PrintSearchItems(searchPlan.StateProvinces, "#searchPlan #search_states");
		this.PrintSearchItems(searchPlan.JobGrades, "#searchPlan #search_jobgrades");
		this.PrintSearchItems(searchPlan.Languages, "#searchPlan #search_languages");
		this.PrintSearchItems(searchPlan.Skills, "#searchPlan #search_skills");
		this.PrintSearchItems(searchPlan.Indications, "#searchPlan #search_indications");
        this.PrintSearchItems(searchPlan.TherapeuticAreas, "#searchPlan #search_areas");
        this.PrintSearchItems(searchPlan.OrdinalTmf, "#searchPlan #search_ordinaltmf");
        
		this.PrintMSA(searchPlan.MSAViews, "#searchPlan #search_msa");

		//$("#searchPlan").show();
	},

	PrintSearchItems: function (itemList, divSelector) {
		var list = [];
		$(itemList).each(function (index, item) {
			list[list.length] = item.Name;
		});
		$(divSelector).html(list.join(", "));
	},

	//MR: This should pull data from the resource row and integrate with the overall search plan to display the results in a pop up of some kind
	DisplayViewProfileMatch: function (resourceId, divWrapper) {
		var searchPlan = $.rm.search._searchPlan;
		var selectedRows = $("#searchResults").getGridParam('selarrrow');

		var selectedRow = null;

		for (var i = 0; i < selectedRows.length; i++) {
			if ($("#searchResults").getCell(selectedRows[i], "ResourceId") == resourceId) {
				selectedRow = selectedRows[i];
			}
		}

		if (selectedRow == null) return;

		var qId = $("#searchResults").getCell(selectedRow, "QId");
		var resourceName = $("#searchResults").getCell(selectedRow, "ResourceName");

		//Grab the html snippet, but don't copy the ID
		var displayPanel = $("#ProfileTemplate").clone().removeAttr("id");

		//populate searchPlan components
		var percentMatchValue = $("#searchResults").getCell(selectedRow, "MatchPercent");
		var jobGradeValue = $("#searchResults").getCell(selectedRow, "JobGrade");
		if (percentMatchValue === "NA") {
			displayPanel.find(".profileMatchPercent").html(percentMatchValue);

		} else {
			displayPanel.find(".profileMatchPercent").html(percentMatchValue + "%");

		}

		displayPanel.find(".profileJobGrade").html(jobGradeValue);

		//Sponsors
		var sponsorIdList = $("#searchResults").getCell(selectedRow, 'SponsorList').split('|');
		$.rm.search.showMatchList(displayPanel, ".tblMatch", sponsorIdList, searchPlan.DesiredCustomers, "Match");

		//Therapeutic Areas
		var areaIdList = $("#searchResults").getCell(selectedRow, 'AreaList').split('|');
		$.rm.search.showMatchList(displayPanel, ".tblMatch", areaIdList, searchPlan.DesiredTherapeuticAreas, "Match");

		//Indications
		var indicationIdList = $("#searchResults").getCell(selectedRow, 'IndicationList').split('|');
		$.rm.search.showMatchList(displayPanel, ".tblMatch", indicationIdList, searchPlan.DesiredIndications, "Match");

		//Skills
		var skillIdList = $("#searchResults").getCell(selectedRow, 'SkillList').split('|');
		var SkillValuesList = $("#searchResults").getCell(selectedRow, 'SkillValues').split('|');
		//$.rm.search.showMatchListSkills(displayPanel, ".tblMatch", skillIdList, SkillValuesList, searchPlan.DesiredSkills, "Match");
		$.rm.search.showMatchList(displayPanel, ".tblMatch", skillIdList, searchPlan.DesiredSkills, "Match", "", SkillValuesList);

		//Study Phase Not Q
		var phaseIdListNotQ = $("#searchResults").getCell(selectedRow, 'StudyPhaseListNotQ').split('|');
		$.rm.search.showMatchList(displayPanel, ".tblMatch", phaseIdListNotQ, searchPlan.DesiredStudyPhasesQ, "Match", "(Non-Quintiles)");

		//Study Phase Q
		var phaseIdListQ = $("#searchResults").getCell(selectedRow, 'StudyPhaseListQ').split('|');
		$.rm.search.showMatchList(displayPanel, ".tblMatch", phaseIdListQ, searchPlan.DesiredStudyPhasesQ, "Match", "(Quintiles)");

		//Languages
		var languageList = $("#searchResults").getCell(selectedRow, 'LanguageList').split('|');
		$.rm.search.showMatchList(displayPanel, ".tblMatch", languageList, searchPlan.DesiredLanguages, "Match");


		$(divWrapper).append(displayPanel);

		$(displayPanel).show();

	},

	showMatchList: function (displayPanel, tblClassName, idList, searchPlanItems, idPrefix, namePrefix, skillValueList) {
		if (idList[0] == "Exclude") return;   //don't display a match row, since resourcetypes included in search don't require this one to appear

		var tbl = displayPanel.find(tblClassName);
		if (namePrefix == undefined)
			namePrefix = '';

		$(searchPlanItems).each(function (index, item) {
			var newRow = tbl.find("#" + idPrefix + "TemplateRow").clone().removeAttr("id").show();
			newRow.find(".clsname").attr("id", idPrefix + item.Id).html(item.Name + namePrefix).attr("title", newRow.find(".clsname").attr("id", idPrefix + item.Id).text());
			if ($.inArray(item.Id + '', idList) != -1) {
				if (skillValueList) {
					if (item.SkillValue == "0" || item.SkillValue == "N/A") {
						newRow.find(".match > img").attr("src", imgPath + checkedIcon);
					}
					else if (item.SkillValue != null && item.SkillValue != "") {
						var skillValue = item.Id + '~' + item.SkillValue;
						if ($.inArray(skillValue + '', skillValueList) != -1) {
							newRow.find(".match > img").attr("src", imgPath + checkedIcon);
						}
					}
					else {
						newRow.find(".match > img").attr("src", imgPath + checkedIcon);
					}
				}
				else {
					newRow.find(".match > img").attr("src", imgPath + checkedIcon);
				}
			}

			tbl.find('tbody').append(newRow);
		});
	},

	bindLabelQtip: function () {
		rm.qtip.showInfoOnGridColumn("div[id$=_RequestId]", "Request Id.");
		rm.qtip.showInfoOnGridColumn("div[id$=_IconColumn]", "Request Status Indicator.");
		rm.qtip.showInfoOnGridColumn("#jqgh_queueRequests_Country", "May be the preferred resource location or the country where the study is taking place.");
		rm.qtip.showInfoOnGridColumn("#jqgh_queueRequests_CountryRegion", "The region of the country.");
		rm.qtip.showInfoOnGridColumn("div[id$=_AssignedRegions]", "The region where the study occurs.");
		rm.qtip.showInfoOnGridColumn("div[id$=_AssignedCountries]", "The country where the study occurs.");


		rm.qtip.showInfoOnGridColumn("div[id$=oneclick_Region]:first", "Matched against resource's work region.");
		rm.qtip.showInfoOnGridColumn("div[id$=oneclick_Subregion]:first", "Matched against subregion derived from resource's work country.");
		rm.qtip.showInfoOnGridColumn("div[id$=oneclick_Country]:first", "Matched against resource's work country.");
		rm.qtip.showInfoOnGridColumn("div[id$=oneclick_CountryRegion]:first", "The region of the country. Matched against country region derived from resource's home state/province.");
		rm.qtip.showInfoOnGridColumn("div[id$=oneclick_StateProvince]:first", "Matched against resource's home state/province.");

		rm.qtip.showInfoOnGridColumn("div[id=jqgh_queueRequests_Sponsor]", "Customer.");
		rm.qtip.showInfoOnGridColumn("div[id$=_Program]", "Program.");
		rm.qtip.showInfoOnGridColumn("div[id$=_ProjectCode]", "Project Code.");
		rm.qtip.showInfoOnGridColumn("div[id$=_Protocol]", "Protocol.");
		rm.qtip.showInfoOnGridColumn("div[id$=_ProjectDteType]", "RBM Project");
		rm.qtip.showInfoOnGridColumn("div[id$=_SiteStatus]", "Site Status.");
		rm.qtip.showInfoOnGridColumn("div[id$=_SponsorSiteId]", "Sponsor Site ID.");
		rm.qtip.showInfoOnGridColumn("div[id$=_PrincipalInvestigator]", "Principal Investigator.");
		rm.qtip.showInfoOnGridColumn("div[id$=_Location]", "Location of the site.");
		rm.qtip.showInfoOnGridColumn("div[id$=_VisitType]", "Visit description or reason for the visit. Applicable to some request types.");
		rm.qtip.showInfoOnGridColumn("div[id$=_SSVType]", "Visit description (On-site or Phone) applicable to SSV requests.");
		rm.qtip.showInfoOnGridColumn("div[id$=_Cluster]", "Currently not applicable in QRPM.");

		rm.qtip.showInfoOnGridColumn("div[id$=_ResourceType]", "Resource Request Type.");
		rm.qtip.showInfoOnGridColumn("div[id$=_SearchResourceType]", "Resource Request Type.");
		rm.qtip.showInfoOnGridColumn("div[id$=_NeedDate]", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn("div[id$=_FTE]", "Provides the details of the resource request and takes into account the country working hours and % utilization.");
		rm.qtip.showInfoOnGridColumn("div[id$=_CRATrainingDate]", "CRA Training Date.");
		rm.qtip.showInfoOnGridColumn("div[id$=_StartDate]", "The date when the work begins for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("div[id$=_StopDate]", "The date when the work ends for the resource request, generally determined from the Project Schedule.");
		rm.qtip.showInfoOnGridColumn("div[id$=_NeedDate]", "Driven by the resource transition time which may be set at the resource level or at the project level.");
		rm.qtip.showInfoOnGridColumn("div[id$=_Notes]", "Use to add/view comments about the particular project/request.");
		rm.qtip.showInfoOnGridColumn("div[id$=_DateSubmittedAsDateTime]", "Date request was submitted");
	}

};

$.rm.searchResults =
{
	//	_successCount: 0,
	//	_errorCount: 0,
	HardBooking: function () {
		//isBookResourceAssignment = false;
		var SelectedRequestIds = rm.grid.getSelectedIds("#queueRequests");
		var SelectedResourceIds = rm.grid.getSelectedIds("#searchResults");

		if (SelectedRequestIds.length == 0) {
			rm.ui.messages.addError('Select request(s) to from Resourcing Worklist.');
			return false;
		}
		if (SelectedResourceIds.length == 0) {
			rm.ui.messages.addError('Select resource(s) to from search results.');
			return false;
		}
		var isProposalSelected = false;
		$.each($("#queueRequests").getGridParam('selarrrow'), function (index, ele) {
			if ($("#queueRequests").getCell(ele, "RequestTypeId") == RequestType_E.Proposal) {
				isProposalSelected = true;
				return false;
			}
		});

		if (isProposalSelected) {
			if (!confirm(Resources.CanAttendBidDefense + " If Yes Press OK. If No Press Cancel.")) {
				$.ajax({
					url: "/_Layouts/SPUI/Requests/BidDefenseDialog.aspx?source=ResourceSearch",
					type: "POST",
					success: function (data) {
						var container = $("#dialogBidDefense");
						if (container.length == 0) {
							container = $("<div id='dialogBidDefense' />");
							$('body').append(container);
						}
						container.html(data).dialog({
							modal: true,
							cache: false,
							title: "Select reason",
							resizable: false,
							width: 350,
							height: 200
						});
					},
					error: function (x, e) {
						alert(x.responseText);
					}
				});
			}
			else {
				$.rm.searchResults.SubmitHardBooking({ CanAttendBidDefense: true }, true);
			}
		}
		else {
			$.rm.searchResults.SubmitHardBooking(null, true);
		}
	},

	SubmitHardBooking: function (bidDefenseResult, ValidateFirewalledProject) {
		var selectedRequestGridIds = $("#queueRequests").getGridParam('selarrrow');
		var selectedResourceGridId = $("#searchResults").getGridParam('selarrrow')[0];

		if (ValidateFirewalledProject) {
			reSubmitHardBookLocalData = {
				selectedRequestIds: null,
				resourceId: null,
				bidDefenseResult: bidDefenseResult,
				validateFirewalledProject: true,
			};
		}
		else {
			selectedRequestGridIds = reSubmitHardBookLocalData.selectedRequestIds;
			selectedResourceGridId = reSubmitHardBookLocalData.resourceId;
			bidDefenseResult = reSubmitHardBookLocalData.bidDefenseResult;
		}

		var postData = {
			selectedRequestIds: selectedRequestGridIds,
			resourceId: selectedResourceGridId,
			bidDefenseResult: bidDefenseResult,
			validateFirewalledProject: ValidateFirewalledProject,
		};
		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.requestSvcUrl + "HardBookResource",
			dataType: "json",
			data: JSON.stringify(postData),
			success: function (data) {
				$("#dialogBidDefense").dialog('close');
				var allFailed = true;
				var atLeastOneFailed = false;
				var projectFireWalledCount = false;
				$.each(data, function (index, element) {
					if (element.Status) {
						rm.grid.removeRow("#queueRequests", element.RequestId);
						allFailed = false;
					}
					else {
						rm.grid.showErrorIconInMessageColumn("#searchResults", element.ResourceId, "Message", element.Message);
						rm.grid.showErrorIconInMessageColumn("#queueRequests", element.RequestId, "Message", element.Message);
						atLeastOneFailed = true;
					}
					if (ValidateFirewalledProject && element.Message.indexOf('hlFireWalledResourceBooking') != -1)
						projectFireWalledCount = true;
				});

				$.rm.searchResults.ShowMessageOnAjaxComplete(allFailed, atLeastOneFailed, "#queueRequests");
				resetAllCharts();
				if (projectFireWalledCount) {
					rmCommon.showDialogWithButtons("Message from web page", projectFireWalledMessage, null, [{ text: "Close", click: function () { $(this).dialog("close"); } }]);
				}
			},
			error: function (errmsg) {
				rm.ui.messages.addError('Failed to save Hard Booking.');
			}

		});
	},
	SoftBooking: function (SelectedRequestIds, SelectedResourceIds, ValidateFirewalledProject) {
		if (SelectedRequestIds.length == 0) {
			rm.ui.messages.addError('Select request(s) to from Resourcing Worklist.');
			return false;
		}

		if (SelectedResourceIds.length == 0) {
			rm.ui.messages.addError('Select resource(s) to from search results.');
			return false;
		}
		var postData = {
			selectedRequestIds: SelectedRequestIds,
			selectedResources: SelectedResourceIds,
			validateFirewalledProject: ValidateFirewalledProject
		};
		rm.ui.block();
		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url: rm.ajax.requestSvcUrl + "SoftBookResource",
			dataType: "json",
			data: JSON.stringify(postData),
			success: function (data) {
				var allFailed = true;
				var atLeastOneFailed = false;
				var projectFireWalledCount = false;
				$.each(data, function (index, element) {
					if (element.Status) {
						rm.grid.removeRow("#queueRequests", element.RequestId);
						$('#searchResults').find('#' + element.ResourceId + ' input[type=checkbox]').attr('checked', false)
						allFailed = false;
					}
					else {
						rm.grid.showErrorIconInMessageColumn("#searchResults", element.ResourceId, "Message", element.Message);
						rm.grid.showErrorIconInMessageColumn("#queueRequests", element.RequestId, "Message", element.Message);
						atLeastOneFailed = true;
					}
					if (ValidateFirewalledProject && element.Message.indexOf('hlFireWalledResourceBooking') != -1)
						projectFireWalledCount = true;
				});
				$.rm.searchResults.ShowMessageOnAjaxComplete(allFailed, atLeastOneFailed, "#queueRequests");
				resetAllCharts(!atLeastOneFailed);
				if (projectFireWalledCount) {
					rmCommon.showDialogWithButtons("Message from web page", projectFireWalledMessage, null, [{ text: "Close", click: function () { $(this).dialog("close"); } }]);
				}
			},
			error: function (errmsg) {
				rm.ui.messages.addError('Failed to save Soft Booking.');
			}
		});
	},

	ShowMessageOnAjaxComplete: function (allFailed, atLeastOneFailed, gridSelector) {
		if (allFailed) {
			rm.ui.messages.addError('Error found. No requests have been booked.');
		}
		else if (atLeastOneFailed) {
			rm.ui.messages.addError('Data submitted with some errors found.');
		}
		else {
			rm.ui.messages.clearAllMessages();
			rm.ui.messages.showSuccess('Request(s) assigned successfully.');
		}

		if (!allFailed) {
			rm.serviceCalls.getRequestCounts();
		}
	},

};

/**
* Takes a dataSet with a 'list' member and sets the items.selected value to true if the id matches on the in the selectedIds array
*
* @author Colin Boatwright
*/
function SetDataListSelect(dataSet, selectedIds) {
	for (var i = 0; i < selectedIds.length; i++) {
		for (var x = 0; x < dataSet.items.length; x++) {
			if (dataSet.items[x].Id == selectedIds[i]) {
				dataSet.items[x].selected = true;
				break;
			}
		}
	}
}


//Get all the MSA HTML DIV elements and add to DOM that we'll be popping up when hovering over the Project labels in accordians
var GetMSAContent = function () {

	if (projectRoles.length === 0) return;

	var jobProjectRoleList = JSON.stringify(projectRoles);

	$.ajax({
		type: "POST",
		contentType: "application/json; charset=utf-8",
		url: rm.ajax.utilitySvcUrl + "Geography/GetJobRoles",
		dataType: "json",
		async: false,
		data: jobProjectRoleList,
		cache: false,
		success: function (result) {
			var response = $.parseJSON(result);

			//These are in the dom so we can attach 'data' json objects to them
			$("#MSAContent").html('');
			$("#MSAContent").html(response.HtmlString);

			$.each(response.EcList, function (index, et) {
				$('#hoverTip_' + et.ProjectId).data("MSAData", response.EcList[index]);
			});

		},
		error: function (errMsg) {
			alert("failed to fetch MSA data");
		}
	});
};


function HandleProjectModalBeforeClose(event, ui) {
	if (!ValidateEntry() && searchCodeValues.showGraphErrors) {
		alert("Errors found.  Hover over fields highlighted in red to see the problem.");
		return false;
	}
	return true;
};

//callback for after MSA dialog box is closed
var HandleProjectModalClose = function () {
	var textBoxList = $("#dialogContainer").find(".hoverTipRow .hoverTipElementsInputText");
	var projectId = $("#dialogContainer .hoverTipContainer").attr("projectId");
	var element = textBoxList[0];

	var jsonData = $('#hoverTip_' + projectId).data("MSAData");
	var msaViewId = jsonData.MSAViewData.Id;

	//Make sure you always check for the existence of every field, because depending on the project/resource type
	//  there may be no data at all...

	if ($("#dialogContainer .chk_education").length == 1) {
		var checkBoxEducation = $("#dialogContainer .chk_education");
		jsonData.MSAViewData.Education.Checked = $(checkBoxEducation).attr("checked") == "checked";
	}

	$.each(jsonData.MSAViewData.IndicationAreas, function (index, element) {
		var indicationid = element.Id;
		var checkBoxIndication = $("#dialogContainer #chk_i" + indicationid);
		var textBoxIndication = $("#dialogContainer #txt_i" + indicationid);
		var ddlIndicationExperience = $("#dialogContainer #ddl_" + msaViewId + "_Ind" + indicationid);

		element.Checked = $(checkBoxIndication).attr("checked") == "checked";
		if (textBoxIndication.length > 0) {
			element.AdjustedValue = $.trim(textBoxIndication.val()) === '' ? null : textBoxIndication.val();
		}
		if (ddlIndicationExperience.length > 0) {
			element.AdjustedValue = $.trim(ddlIndicationExperience.val()) === '-1' ? null : ddlIndicationExperience.val();
		}
	});

	$.each(jsonData.MSAViewData.TherapeuticAreas, function (index, element) {
		var therapeuticid = element.Id;
		var checkBoxTherapeutic = $("#dialogContainer #chk_t" + therapeuticid);
		var textBoxTherapeutic = $("#dialogContainer #txt_t" + therapeuticid);
		var ddlTherapeuticExperience = $("#dialogContainer #ddl_" + msaViewId + "_TA" + therapeuticid);

		element.Checked = $(checkBoxTherapeutic).attr("checked") == "checked";
		if (textBoxTherapeutic.length > 0) {
			element.AdjustedValue = $.trim(textBoxTherapeutic.val()) === '' ? null : textBoxTherapeutic.val();
		}
		if (ddlTherapeuticExperience.length > 0) {
			element.AdjustedValue = $.trim(ddlTherapeuticExperience.val()) === '-1' ? null : ddlTherapeuticExperience.val();
		}
	});

	var ddlGlobalProjectExperience = $("#dialogContainer #ddl_" + msaViewId + "_exp10");
	if (ddlGlobalProjectExperience.length == 1) {
		var cbxGlobalProjectExperience = $("#dialogContainer #chk_" + msaViewId + "_exp10");
		jsonData.MSAViewData.GlobalProjectExperience.ValueAdjusted = $(ddlGlobalProjectExperience).val();
		jsonData.MSAViewData.GlobalProjectExperience.Checked = $(cbxGlobalProjectExperience).attr("checked") == "checked";
	}

	var ddlInHouse = $("#dialogContainer #ddl_" + msaViewId + "_InHouse");
	if (ddlInHouse.length == 1) {
		var cbxInHouse = $("#dialogContainer #chk_" + msaViewId + "_InHouse");
		jsonData.MSAViewData.InHouse.ValueAdjusted = $(ddlInHouse).val();
		jsonData.MSAViewData.InHouse.Checked = $(cbxInHouse).attr("checked") == "checked";
	}

	var ddlOnSite = $("#dialogContainer #ddl_" + msaViewId + "_OnSite");
	if (ddlOnSite.length == 1) {
		var cbxOnSite = $("#dialogContainer #chk_" + msaViewId + "_OnSite");
		jsonData.MSAViewData.OnSite.Checked = $(cbxOnSite).attr("checked") == "checked";
		jsonData.MSAViewData.OnSite.ValueAdjusted = $(ddlOnSite).val();
	}
	//dialog is removed from DOM in dialog close event handler within oneclick
}

//callback for after MSA modal dialog is opened
var HandleProjectModalOpen = function () {
	//MR: abort if can't find anything in dialog
	var element = $("#dialogContainer .hoverTipRow .hoverTipElementsInputText")[0];
	var projectId = $("#dialogContainer .hoverTipContainer").attr("projectId");

	var jsonData = $('#hoverTip_' + projectId).data("MSAData");
	var msaViewId = jsonData.MSAViewData.Id;

	//Make sure you always check for the existence of every field, because depending on the project/resource type
	//  there may be no data at all...

	if ($("#dialogContainer .chk_education").length == 1) {
		$("#dialogContainer .chk_education").attr("checked", jsonData.MSAViewData.Education.Checked);
	}

	$.each(jsonData.MSAViewData.IndicationAreas, function (index, element) {
		var indicationid = element.Id;
		var checkBoxIndication = $("#dialogContainer #chk_i" + indicationid);
		var textBoxIndication = $("#dialogContainer #txt_i" + indicationid);
		var ddlIndicationExperience = $("#dialogContainer #ddl_" + msaViewId + "_Ind" + indicationid);

		$(checkBoxIndication).attr("checked", element.Checked);
		if (textBoxIndication.length > 0) {
			$(textBoxIndication).val(element.AdjustedValue === null ? '' : element.AdjustedValue);
		}
		if (ddlIndicationExperience.length > 0) {
			$(ddlIndicationExperience).val(element.AdjustedValue === null ? '-1' : element.AdjustedValue);
		}
	});

	$.each(jsonData.MSAViewData.TherapeuticAreas, function (index, element) {
		var therapeuticid = element.Id;
		var checkBoxTherapeutic = $("#dialogContainer #chk_t" + therapeuticid);
		var textBoxTherapeutic = $("#dialogContainer #txt_t" + therapeuticid);
		var ddlTherapeuticExperience = $("#dialogContainer #ddl_" + msaViewId + "_TA" + therapeuticid);

		$(checkBoxTherapeutic).attr("checked", element.Checked);
		if (textBoxTherapeutic.length > 0) {
			$(textBoxTherapeutic).val(element.AdjustedValue === null ? '' : element.AdjustedValue);
		}
		if (ddlTherapeuticExperience.length > 0) {
			$(ddlTherapeuticExperience).val(element.AdjustedValue === null ? '-1' : element.AdjustedValue);
		}
	});

	var ddlGlobalProjectExperience = $("#dialogContainer #ddl_" + msaViewId + "_exp10");
	if (ddlGlobalProjectExperience.length == 1) {
		var cbxGlobalProjectExperience = $("#dialogContainer #chk_" + msaViewId + "_exp10");
		$(cbxGlobalProjectExperience).attr("checked", jsonData.MSAViewData.GlobalProjectExperience.Checked);
		$(ddlGlobalProjectExperience).val(jsonData.MSAViewData.GlobalProjectExperience.ValueAdjusted);
	}

	var ddlInHouse = $("#dialogContainer #ddl_" + msaViewId + "_InHouse");
	if (ddlInHouse.length == 1) {
		var cbxInHouse = $("#dialogContainer #chk_" + msaViewId + "_InHouse");
		$(cbxInHouse).attr("checked", jsonData.MSAViewData.InHouse.Checked)
		$(ddlInHouse).val(jsonData.MSAViewData.InHouse.ValueAdjusted);
	}

	var ddlOnSite = $("#dialogContainer #ddl_" + msaViewId + "_OnSite");
	if (ddlOnSite.length == 1) {
		var cbxOnSite = $("#dialogContainer #chk_" + msaViewId + "_OnSite");
		$(cbxOnSite).attr("checked", jsonData.MSAViewData.OnSite.Checked);
		$(ddlOnSite).val(jsonData.MSAViewData.OnSite.ValueAdjusted);
	}

	if ($.trim($('#dialogContainer .hoverTipContainer .hoverProject').html()) == "") {
		$(".ui-dialog-titlebar-close").trigger("click");
		rm.ui.messages.showSuccess(Resources.ContractualRequirementsDataNotFound);
	}
}

var ValidateEntry = function () {
	isValid = true;

	var allInputs = $(".ui-draggable .forvalidate");
	allInputs.trigger('change');

	if ($(".ui-draggable .q_validation_error").size() == 0) {
		var isValid = true;
	}
	else {
		return false;
	}

	return isValid;
}

var hoverMessages = function () {
	var styleConfig = { width: '225px' };
	rm.qtip.showInfo("#SIVFSI", "Site Initiation Visit - First Subject In", styleConfig);
	rm.qtip.showInfo("#FSILSI", "First Subject In - Last Subject In", styleConfig);
	rm.qtip.showInfo("#LSILSO", "Last Subject In - Last Subject Out", styleConfig);
	rm.qtip.showInfo("#LSILSO34", "Last Subject In - Last Subject Out", styleConfig);
};

var nameChange = function () {
	$(".searchName").bind("keyup", function (event) {
		showNameIcon(this);
		setNameTooltip(this);
	});
}


//Filter cnditions


function DisableAllsearchFilterOnLoad() {
	rmSearchNs.hideSearchFilters();
}

SearchConditionCriterion = function () {
	var resourceGroupId = $("#ddlResourceGroup option:selected").val();
	var isGroup = true;
	var postData = {
		resourceGroupId: resourceGroupId,
		isGroup: isGroup
	};
	if (resourceGroupId != "-1") {
		$.rm.Ajax_Resource("GetResourceSearchCriteria", postData, function (data) {

			$.each(data, function (index, ele) {
				if (ele["IsDisplay"] != true) {

					$('#' + ele["DivId"]).hide();
				}
				else {
					$('#' + ele["DivId"]).show();
				}

			}
			);
		}, false);
	}
	else { DisableAllsearchFilterOnLoad(); }
};

var ResourceGroupChange = function () {
	$("#ddlResourceGroup").bind("change", function (event) {
		DisableAllsearchFilterOnLoad();
		rmChart.clearResourceChartSeries();
		//$.rm.search.ClearResult();
		if ($(this).val() == "-1") {
			isDisableGridCheckbox = false;
			setTimeout(function () { RefereshResourceTypeDropdown(true); }, 10);
			$.rm.search._bSearchEnabled = false;
			$.rm.search._bResetFiltersEnabled = false;
			rm.ui.ribbon.refresh();
		}
		else {
			isDisableGridCheckbox = true;
		}
		$('#chkSelectAll').removeAttr('checked');
		rmSearchNs.fetchingRequestWorklistDataFromServer = true;
		$("#queueRequests").setGridParam({ datatype: 'json', page: 1 }).trigger('reloadGrid');
		$.rm.search.ResetFilters();
		RefereshResourceTypeDropdown(false);
		$("#gs_SearchResourceType").val(-1);
	});
}

var ResourceRequestTypeChange = function () {
	$("#gs_SearchResourceType").bind("change", function (event) {
		var requestTypeResourceTypeGroupId;
		if ($(this).val() != "") {
			handleGridCheckbox(false);
			var requestTypeResourceTypeGroupAndResourceTypeList = $("#ddlResourceGroup").data("RequestTypeResourceTypeGroupAndResourceTypeList");
			$.each(requestTypeResourceTypeGroupAndResourceTypeList, function (index, element) {
				$.each(element.ResourceTypeList, function (i, e) {
					if (e.Value == $("#gs_SearchResourceType").val()) {
						requestTypeResourceTypeGroupId = element.GroupId;
						return;
					}
				});
			});
			$("#ddlResourceGroup").val(requestTypeResourceTypeGroupId);
		}
		else {
			$("#queueRequests").setGridParam({ datatype: 'json', page: 1 }).trigger('reloadGrid');
			RefereshResourceTypeDropdown(false);
		}
		$('#chkSelectAll').removeAttr('checked');
	});
}

var showNameIcon = function (selector) {
	if ($.trim($(selector).val()) != "") {
		$("#h3" + $(selector).attr("id")).find("img").removeClass("ui-iconHide").addClass("ui-iconNew");
	}
	else {
		$("#h3" + $(selector).attr("id")).find("img").removeClass("ui-iconNew").addClass("ui-iconHide");
	}

	if ($.trim($(selector).val()) == "") {
		$(selector).val("");
	}
}

var setNameTooltip = function (selector) {
	var tooltip = "";

	if ($.trim($(selector).val()) != "") {
		if ($(selector).attr("id").indexOf("ResourceName") >= 0) {
			tooltip = "<b>Name/QID:</b> ";
		}
		else if ($(selector).attr("id").indexOf("LineManager") >= 0) {
			tooltip = "<b>Line Manager:</b> ";
		}
		tooltip = tooltip + $.trim($(selector).val());
	}

	if (tooltip == "") {
		tooltip = "Nothing selected.";
	}

	$("#h3" + $(selector).attr("id")).attr("title", tooltip);
}
var GetRequestTypeResourceTypeGroupAndResourceTypeList = function () {
	$.rm.Ajax_Resource("GetRequestTypeResourceTypeGroupAndResourceTypeList", {}, function (data) {
		$("#ddlResourceGroup").empty().append($("<option>").val("-1").html("--Select--"));
		$.rm.search.BuildResourcingWorklistGrid();
		$("#gs_SearchResourceType").empty().append($("<option>").val("").html("--Select--"));
		if (data != undefined) {
			$.each(data, function (index, element) {
				$("#ddlResourceGroup").append($("<option>").val(element.GroupId).html(element.GroupDescription));
				$.each(element.ResourceTypeList, function (i, e) {
					$("#gs_SearchResourceType").append($("<option>").val(e.Value).html(e.Value));
				});
				if (data.length == 1) // Select the first group if there is only one group available in the dropdown and enable the grid check box.
				{
					$("#ddlResourceGroup").val(element.GroupId);
					isDisableGridCheckbox = true;
					handleGridCheckbox(false);
				}
			});
		}
		$("#ddlResourceGroup").data("RequestTypeResourceTypeGroupAndResourceTypeList", data);
		//$.rm.search.BuildResourcingWorklistGrid(); // Let the Request Group dropdown load first QRPM-13668
		ResourceRequestTypeChange();
		if (rm.queryString.getValue("RequestGroupId") != null) {
			$("#ddlResourceGroup").val(rm.queryString.getValue("RequestGroupId"));
			$("#ddlResourceGroup").trigger("change");
			//$.rm.search.BuildResourcingWorklistGrid();
		}
	}, true);
};

var RefereshResourceTypeDropdown = function (allResourceRequestType) {
	var requestTypeResourceTypeGroupAndResourceTypeList = $("#ddlResourceGroup").data("RequestTypeResourceTypeGroupAndResourceTypeList");
	$("#gview_queueRequests").find("select").val(-1);
	$("#gview_queueRequests").find("input:text").val("");
	$("#gs_SearchResourceType").empty().append($("<option>").val("").html("All"));
	$.each(requestTypeResourceTypeGroupAndResourceTypeList, function (index, element) {
		if (allResourceRequestType) {
			$.each(element.ResourceTypeList, function (i, e) {
				$("#gs_SearchResourceType").append($("<option>").val(e.Value).html(e.Value));
			});
		}
		else {
			if (element.GroupId == $("#ddlResourceGroup").val()) {
				$.each(element.ResourceTypeList, function (i, e) {
					$("#gs_SearchResourceType").append($("<option>").val(e.Value).html(e.Value));
				});
			}
		}
	});
}

var SelectAllClick = function () {
	$(document).on('click', "#chkSelectAll", function () {
		if ($(this).is(':checked')) {
			setTimeout(function () {
				MakeSingleCallForRequests = true;
				var selectedIds = new Array();
				var idList = new Array();
				selectedIds = $("#queueRequests").getGridParam('selarrrow');
				var alreadySelectedRowCount = selectedIds.length;
				var noOfRowsToSelect = searchCodeValues.maxRowsToSelect - alreadySelectedRowCount;
				var requetIdProjectCodeMap = {};

				var ids = $("#queueRequests").getDataIDs();  //all the rowids
				for (var i = 0; i < ids.length; i++) {
					var hasError = $.trim($("#queueRequests").getCell(ids[i], "Message")) != "";
					if (!hasError && noOfRowsToSelect > 0 && jQuery.inArray(ids[i], selectedIds) == -1) // check if the selected ids is already present in the cache
					{
						idList.push(ids[i]);
						requetIdProjectCodeMap[ids[i]] = $("#queueRequests").getCell(ids[i], "ProjectCode");
						rm.grid.checkRowById("#queueRequests", ids[i]);
						noOfRowsToSelect--;
					}
				}
				rmChart.addRequestsToGraph(idList, "#queueRequests", "Message", requetIdProjectCodeMap);
				MakeSingleCallForRequests = false;
				$.rm.search.AdjustFilters(true);
				$.rm.search._bSearchEnabled = true;
				$.rm.search._bResetFiltersEnabled = true;
				rm.ui.ribbon.refresh();
			}, 10);
		}
		else {
			MakeSingleCallForRequests = false;
			var ids = $("#queueRequests").getDataIDs();  //all the rowids
			rmChart.clearRequestChartSeries();
			rm.grid.uncheckAllGridRows("#queueRequests");
			$.rm.search.ClearResult();
		}
	});
}

var handleGridCheckbox = function (isEnable) {
	if (isEnable) {
		$("#queueRequests").find("input:checkbox").attr("disabled", true);
		$("#chkSelectAll").attr("disabled", true);
	}
	else {
		$("#queueRequests").find("input:checkbox").attr("disabled", false);
		$("#chkSelectAll").attr("disabled", false);
	}
};

var resetAllCharts = function (switchTabs) {
	rmChart.clearResourceChartSeries();
	rmChart.clearRequestChartSeries();
	if (switchTabs === true || switchTabs == undefined) {
		rm.ui.tabs.enableByIndex("#tabs", 0);
		rm.ui.tabs.activateByIndex("#tabs", 0);
		rm.ui.tabs.disableByIndex("#tabs", [rmSearchNs.tabIndex.SearchResults, rmSearchNs.tabIndex.SelectedProfile]);
	}
};