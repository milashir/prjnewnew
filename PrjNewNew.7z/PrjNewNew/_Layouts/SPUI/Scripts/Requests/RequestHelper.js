﻿var requestHelper = {
	connectClick: function () { },

	showConnectDisconnectIconPpm: function (jqElement, onClickFunctionString) {
		var connectStatus = jqElement.attr("connectStatus");

		if (connectStatus == RequestConnect_E.Connected) {
			requestHelper.appendConnectedImagePpm(jqElement);
		}
		else {
			requestHelper.appendDisconnectedImagePpm(jqElement, onClickFunctionString);
		}
	},

	showConnectDisconnectIconCountry: function (jqElement, calculateNeedByDate, onClickFunctionString) {
		var connectStatus = jqElement.attr("connectStatus");

		if (connectStatus == RequestConnect_E.Connected) {
			requestHelper.appendConnectedImageCountry(jqElement, calculateNeedByDate);
		}
		else {
			requestHelper.appendDisconnectedImageCountry(jqElement, onClickFunctionString);
		}
	},

	showMultipleConnectDisconnectIconCountry: function (jqElement, calculateNeedByDate, onClickFunctionString) {
		var connectStatus = jqElement.attr("connectStatus");

		if (connectStatus == RequestConnect_E.Connected) {
			requestHelper.appendMultipleConnectedImageCountry(jqElement, calculateNeedByDate);
		}
		else {
			requestHelper.appendMultipleDisconnectedImageCountry(jqElement, onClickFunctionString);
		}
	},

	showMultipleConnectDisconnectIconPpm: function (jqElement, calculateNeedByDate) {
		var connectStatus = jqElement.attr("connectStatus");

		if (connectStatus != RequestConnect_E.Connected) {
			requestHelper.appendMultipleDisconnectedImagePpm(jqElement);
		}
	},

	handleStartStopDateChangePpm: function (jqElement, changeNeedByDate, onClickFunctionString) {
		var connectedAttr = jqElement.attr("connectedDateValue");
		if (connectedAttr || connectedAttr == "") {
			if (changeNeedByDate) {
				editRequest.calculateNeedByDate();
			}

			if (connectedAttr == jqElement.val()) {
				requestHelper.appendConnectedImagePpm(jqElement);
			}
			else {
				requestHelper.appendDisconnectedImagePpm(jqElement, onClickFunctionString);
			}
		}
	},

	appendConnectedImagePpm: function (textBoxObject) {
		textBoxObject.parent().find(".disconnectedFromPpm,.connectedToPpm").remove();
		var connectedImage = $("<img>").attr("class", "connectedToPpm marginLeft35").attr("src", "/_layouts/SPUI/images/ppmLinkIcon.png");
		textBoxObject.parent().append(connectedImage);
		editRequest.ShowConnectDisconnectPPMIcon();
		editRequest.onAfterConnectIconClick();
	},

	appendDisconnectedImagePpm: function (textBoxObject, onClickFunctionString) {
		if (onClickFunctionString == undefined || !onClickFunctionString) {
			onClickFunctionString = "";
		}

		textBoxObject.parent().find(".disconnectedFromPpm,.connectedToPpm").remove();
		var disconnectedImageHtml = "<img src='/_layouts/SPUI/images/ppmUnLinkIcon.png' class='disconnectedFromPpm marginLeft35 cursorHand' onclick='requestHelper.connectToPpmDate(\"" + textBoxObject.attr("id") + "\");" + onClickFunctionString + "; return false;' title='Reconnect to PPM milestone date' >";
		textBoxObject.parent().append(disconnectedImageHtml);
		editRequest.ShowConnectDisconnectPPMIcon();
		editRequest.onAfterConnectIconClick();
	},

	connectToPpmDate: function (controlId) {
		var control = $("#" + controlId);
		if (control.attr("connectedDateValue") != "") {
			control.val(control.attr("connectedDateValue"));
			requestHelper.appendConnectedImagePpm(control);

			if (control.attr("dateType") == "start") {
				editRequest.calculateNeedByDate();
			}

			rm.validation.clearError($(control));
			editRequest.updateRequestStopDateFromComputedRequestMilestone(editRequest.getResourceTypeId(), 0);
		}
		else {
			alert("You are not able to connect to PPM milestone date since the PPM milestone date is not available.");
		}
	},

	handleMultipleStartStopDateChangePpm: function (jqElement, changeNeedByDate, onClickFunctionString) {
		var connectedAttr = jqElement.attr("connectedDateValue");
		if (connectedAttr || connectedAttr == "") {
			if (connectedAttr != jqElement.val()) {
				requestHelper.appendMultipleDisconnectedImagePpm(jqElement);
			}
		}
	},

	appendMultipleDisconnectedImagePpm: function (textBoxObject) {
		textBoxObject.parent().find(".disconnectedFromPpm,.connectedToPpm").remove();
		var disconnectedImageHtml = "<img src='/_layouts/SPUI/images/ppmUnLinkIcon.png' class='disconnectedFromPpm marginLeft35 cursorHand' onclick='requestHelper.connectToMultiplePpmDate(\"" + textBoxObject.attr("id") + "\"); return false;' title='Reconnect to PPM milestone date' >";
		textBoxObject.parent().append(disconnectedImageHtml);
		editRequest.ShowConnectDisconnectPPMIcon();
		editRequest.onAfterConnectIconClick();
	},

	connectToMultiplePpmDate: function (controlId) {
		var control = $("#" + controlId);
		control.val("");
		requestHelper.appendConnectedImagePpm(control, true);
		rm.validation.clearError($(control));
		var imgControl = control.parent().find('.connectedToPpm');
		imgControl.attr("disabled", "true");
		imgControl.attr("title", "Connected");
		imgControl.addClass("disabledImage");
		requestHelper.updateDateConnectStatus(controlId);
		if (requestHelper.connectClick && $.isFunction(requestHelper.connectClick)) {
			requestHelper.connectClick();
		}
	},

	handleStartStopDateChangeCountry: function (jqElement, isStartDate) {
		var connectedAttr = jqElement.attr("connectedDateValue");
		if (connectedAttr || connectedAttr == "") {
			if (isStartDate) {
				editRequest.calculateNeedByDate();
			}

			if (connectedAttr == jqElement.val()) {
				requestHelper.appendConnectedImageCountry(jqElement, isStartDate);
			}
			else {
				requestHelper.appendDisconnectedImageCountry(jqElement);
			}
		}
	},

	handleMultipleStartStopDateChangeCountry: function (jqElement, isStartDate) {
		var connectedAttr = jqElement.attr("connectedDateValue");
		if (connectedAttr || connectedAttr == "") {
			if (connectedAttr != jqElement.val()) {
				requestHelper.appendMultipleDisconnectedImageCountry(jqElement);
			}
		}
	},

	appendConnectedImageCountry: function (textBoxObject, calculateNedByDate) {
		textBoxObject.parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		var connectedImage = $("<img>").attr("class", "connectedToCountry marginLeft35").attr("src", "/_layouts/SPUI/images/conncted.png");
		textBoxObject.parent().append(connectedImage);
		editRequest.ShowConnectDisconnectPPMIcon();
		if (calculateNedByDate) {
			editRequest.calculateNeedByDate();
		}
		editRequest.onAfterConnectIconClick();
	},

	appendDisconnectedImageCountry: function (textBoxObject) {
		var resourceTypeId = editRequest.getResourceTypeId();
		var titleText = 'Reconnect to Country milestone date.';
		if (resourceTypeId == ResourceTypeName.DTESite_Monitoring ||
				resourceTypeId == ResourceTypeName.Standard_Monitoring ||
				resourceTypeId == ResourceTypeName.DTEPharmacy_Monitoring ||
				resourceTypeId == ResourceTypeName.Pharmacy_Monitoring ||
				resourceTypeId == ResourceTypeName.iCRA_Monitoring) {
			if (textBoxObject.data().datepicker.id.endsWith('txtStopDate')) {
				titleText = 'Reconnect to calculated Site COV date.';
			}
			else {
				if (resourceTypeId == ResourceTypeName.DTESite_Monitoring || resourceTypeId == ResourceTypeName.Standard_Monitoring) {
					titleText = 'Reconnect to calculated Site Selection date.';
				}
				else { titleText = 'Reconnect to calculated Site SIV date.'; }
			}
		}
		textBoxObject.parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		var disconnectedImageHtml = "<img src='/_layouts/SPUI/images/reconnect.png' class='disconnectedFromCountry marginLeft35 cursorHand' onclick='requestHelper.connectToCountryDate(\"" + textBoxObject.attr("id") + "\"); return false;' title='" + titleText + "' >";
		textBoxObject.parent().append(disconnectedImageHtml);
		editRequest.ShowConnectDisconnectPPMIcon();
		editRequest.onAfterConnectIconClick();
	},

	connectToCountryDate: function (controlId) {
		var control = $("#" + controlId);
		control.val(control.attr("connectedDateValue"));
		requestHelper.appendConnectedImageCountry(control, true);
		rm.validation.clearError($(control));
	},

	appendMultipleConnectedImageCountry: function (textBoxObject, calculateNedByDate) {
	},

	appendMultipleDisconnectedImageCountry: function (textBoxObject) {
		textBoxObject.parent().find(".disconnectedFromCountry,.connectedToCountry").remove();
		var disconnectedImageHtml = "<img src='/_layouts/SPUI/images/reconnect.png' class='disconnectedFromCountry marginLeft35 cursorHand' onclick='requestHelper.connectToMultipleCountryDate(\"" + textBoxObject.attr("id") + "\"); return false;' title='Selecting this icon will reconnect each selected Request to its respective Country milestone date' >";
		textBoxObject.parent().append(disconnectedImageHtml);
		editRequest.ShowConnectDisconnectPPMIcon();
		editRequest.onAfterConnectIconClick();
	},

	connectToMultipleCountryDate: function (controlId) {
		var control = $("#" + controlId);
		control.val("");
		requestHelper.appendConnectedImageCountry(control, true);
		rm.validation.clearError($(control));
		var imgControl = control.parent().find('.connectedToCountry');
		imgControl.attr("disabled", "true");
		imgControl.attr("title", "Connected");
		imgControl.addClass("disabledImage");
		requestHelper.updateDateConnectStatus(controlId);
	},

	updateDateConnectStatus: function (controlId) {
		if (controlId.indexOf("txtStartDate") != -1) {
			$("[id$=StartDateConnectStatus]").val("1");
		} else if (controlId.indexOf("txtStopDate") != -1) {
			$("[id$=StopDateConnectStatus]").val("1");
		} else if (controlId.indexOf("txtCRATrainingDate") != -1) {
			$("[id$=CraTrainingDateConnectStatus]").val("1");
		}
	},

	handleInterimFrequencyClick: function (resourceTypeId, isGenericType) {
		var resourceTypeDetails = ResourceTypeDetails[resourceTypeId];

		if (resourceTypeDetails) {
			if (resourceTypeDetails.IsClinical) {
				var calculatorGroupId = -1;
				if (resourceTypeId == ResourceTypeName.Standard_Monitoring) { calculatorGroupId = CalculatorGroup_E.MonitoringCalculator; }
				else if (resourceTypeId == ResourceTypeName.Pharmacy_Monitoring) { calculatorGroupId = CalculatorGroup_E.PharmacyCalculator; }
				else if (resourceTypeId == ResourceTypeName.iCRA_Monitoring) { calculatorGroupId = CalculatorGroup_E.ICraCalculator; }
				else if (resourceTypeId == ResourceTypeName.DTESite_Monitoring) { calculatorGroupId = CalculatorGroup_E.DTEMonitoringCalculator; }
				else if (resourceTypeId == ResourceTypeName.DTEPharmacy_Monitoring) { calculatorGroupId = CalculatorGroup_E.DTEPharmacyCalculator; }

				calculatorGroup.addAdhocCalculator(calculatorGroupId);
			}
			else if (resourceTypeDetails.IsGeneric) { $.GenericFTECalculator.InterimFrequency(); }
			else if (resourceTypeDetails.IsOthers || resourceTypeDetails.IsRegionBased || resourceTypeDetails.IsGlobal) { $.Calculator.InterimFrequency(); }
		}
	}
};