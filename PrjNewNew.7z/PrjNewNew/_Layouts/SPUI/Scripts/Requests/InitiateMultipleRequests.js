﻿///<reference path="../Common/RmHelper.js"/>
$(document).ready(function () {
	rm.utilities.setSelectedNavLinkAndHelpUrl(GetRmPageLinkId());
	initMultiReq.initUi();
});

var initMultiReq = {
	resourceTypeResourceLookup: {},
	resourcesForSpecialAssignmentNeedsLookup: {},
	rowIdentity: 0,
	pageManagerLookup: {},
	projectLookupArray: null,
	regionConnectedMilestoneDetails: {},
	styleConfig: { width: '250px' },
	stylePosition: { my: 'bottom center', at: 'top center' },
	classHideMe: "hideMe",
	classCustomFieldContainerSelector: ".customFieldContainer",
	classHoursSelector: ".hours",
	classFteSelector: ".fte",
	stageNameCellSelector: ".stageNameCell",
	stageIdCellSelector: ".stageIdCell",
	milestoneNameCellSelector: ".milestoneNameCell",
	milestoneDateCellSelector: ".milestoneDateCell",
	startMilestoneCellSelector: ".startMilestoneCell",
	stopMilestoneCellSelector: ".stopMilestoneCell",
	classSavedSuccessfully: "savedSuccessfully",
	classStatusDivSelector: ".statusDiv",
	classMultiSelectRegionDropdownContainerSelector: ".multiselectDropdownContainerInitMulti.region",
	classMultiSelectCountryDropdownContainerSelector: ".multiselectDropdownContainerInitMulti.country",
	calculatorCellSelector: ".calculatorCell",
	phaseRowSelector: "tr.phaseRow",
	genericRowSelector: "tr.genericRow",
	phaseConnectStatusCellSelector: ".phaseConnectStatusCell",
	assignedRegionContainerIdPrefix: "assignedRegionContainer_",
	assignedCountryContainerIdPrefix: "assignedCountryContainer_",

	attrSelectedProject: "selectedProject",
	attrSelectedResource: "selectedResource",
	attrRowIdentity: "rowId",
	attrIsStartDate: "isStartDate",
	attrMilestoneData: "attrMilestoneData",
	attrConnectedDate: "connectedDate",
	attrFteTypeFteMilestoneTypeId: "fteTypeFteMilestoneTypeId",
	attrCalcTimestamp: "calcTimestamp",
	attrAllowQipConnection: "allowQipConnection",
	attrQipConnectedValue: "attrQipConnectedValue",
	attrUpdated: "updated",
	attrMaxLength: "maxLength",
	attrIsSaved: "isSaved",
	attrJobGradeInfoStr: "jobGradeInfoStr",
	attrJobGrade: "jgeobGrade",
	attrResourceTypeCustomFieldId: "ResourceTypeCustomFieldId",
	imgDeleteRequestRowSelector: ".imgDeleteRequestRow",
	successContainerSelector: ".rowSuccessContainer",
	errorContainerSelector: ".rowErrorContainer",
	errorIconSelector: ".errorIcon",
	datePickerSelector: ".ui-datepicker-trigger",
	tblGenericCalculatorLayoutSelector: "#tblGenericCalculatorLayout",
	tblPhaseCalculatorLayoutSelector: "#tblPhaseCalculatorLayout",
	tblFlatFteValueCalculatorLayoutSelector: "#tblFlatFteValueCalculatorLayout",
	tblFlatFteValueNoTotalHoursCalculatorLayoutSelector: "#tblFlatFteValueNoTotalHoursCalculatorLayout",
	tblPhaseCalculatorTemplateRowSelector: "#tblPhaseCalculatorTemplateRow",
	tblGenericCalculatorTemplateRowSelector: "#tblGenericCalculatorTemplateRow",
	addGenericRowButtonSelector: "input[name=btnGenericFirstAdd]",
	deleteGenericRowImageSelector: "img.imgDeleteGenericRow",
	genericStartMilestoneSelector: "[name=genericStartMilestone]",
	genericStopMilestoneSelector: "[name=genericStopMilestone]",
	genericStartMilestoneDateSelector: "[name=genericStartMilestoneDate]",
	genericStopMilestoneDateSelector: "[name=genericStopMilestoneDate]",
	tblTemplateRequestRowSelector: "#tblTemplateRequestRow",
	tblRequestsSelector: "#tblRequests",
	tblRequestsGridHeader: "#initiateMultipleRequestsGridHeader",
	txtProjectNameSelector: "[name=txtProjectName]",
	ddlOrganizationSelector: "[name=ddlOrganization]",
	ddlOrganizationalUnitSelector: "[name=ddlOrganizationalUnit]",
	ddlResourceTypeSelector: "[name=ddlResourceType]",
	ddlRegionSelector: "[name=ddlPreferredRegion]",
	ddlCountrySelector: "[name=ddlPreferredCountry]",
	imgSiteCountPopUpSelector: ".imgSiteCountPopUp",
	divSiteCountPopUpContainerSelector: "#divSiteCountPopUpContainer",
	txtStartDateSelector: "[name=txtStartDate]",
	txtStopDateSelector: "[name=txtStopDate]",
	txtNeedByDateSelector: "[name=txtNeedByDate]",
	txtTotalSitesSelector: "[name=txtTotalSites]",
	ddlRequestBudgetedSelector: "[name=ddlRequestBudgeted]",
	txtReasonSelector: "[name=txtReason]",
	txtNotesSelector: "[name=txtNotes]",
	ddlRequestBlindedSelector: "[name=ddlRequestBlinded]",
	ddlCountryRegionSelector: "[name=ddlCountryRegion]",
	txtResourceNameSelector: "[name=txtResourceName]",
	chkSelectSelector: ".chkSelect",
	errorKeyLookup: {},
	organizationOrganizationalUnitRRTData: {},
	anyOrganizationalUnit: 0,

	qipConnectConfig: {
		connectedImage: {
			class: "imgConnected",
			title: "",
			alt: "",
			src: "/_layouts/SPUI/images/ConnectedBudget.png"
		},
		disConnectedImage: {
			class: "imgReconnect",
			title: "Reconnect to Budget",
			alt: "",
			src: "/_layouts/SPUI/images/DisconnectedBudget.png"
		}
	},
	_computedReqestMilestoneDaysToAdd: null,
	getComputedReqestMilestoneDaysToAdd: function () {
		if (initMultiReq._computedReqestMilestoneDaysToAdd == null) {
			initMultiReq._computedReqestMilestoneDaysToAdd = rm.serviceCalls.getAllComputedReqestMilestoneDaysToAdd();
		}
		return initMultiReq._computedReqestMilestoneDaysToAdd;
	},
	getRowSelectorByRowId: function (rowId) { return "{0} tr[{1}={2}]".replace("{0}", initMultiReq.tblRequestsSelector).replace("{1}", initMultiReq.attrRowIdentity).replace("{2}", rowId); },
	getUnsavedRowSelector: function () { return initMultiReq.tblRequestsSelector + " tr[" + initMultiReq.attrIsSaved + "=0]"; },
	resizeGrid: function () {
		var windowHeight = $(window).height();
		var documentHeight = $(document).height();
		var tableWidth = rm.ui.getMaxGridWidth() - 50;
		var tableBodyHeight = (documentHeight > windowHeight ? windowHeight : documentHeight) - 298;

		if (!allowHardbooking) {
			var headerCell = $("#thHardBookResoruce").hide();
			var dataCell = $(".tdHardBookResoruce").hide();
			$("#initiateMultipleRequestsGridHeader").width($("#initiateMultipleRequestsGridHeader").width() - headerCell.width());
			$("#initiateMultipleRequestsGrid").width($("#initiateMultipleRequestsGrid").width() - dataCell.width());
		}

		$(".headerContainer").width(tableWidth);
		$(".bodyContainer").width(tableWidth).height(tableBodyHeight);
	},
	initUi: function () {
		initMultiReq.resizeGrid();
		$(window).resize(function () { setTimeout(initMultiReq.resizeGrid, 10); });
		rm.qtip.showInfo($("a[id*=HardBookSubmit]"), allowHardbooking ? "Submit or Submit & Hard Book Requests" : "Submit");
		window.onbeforeunload = function () {
			if (initMultiReq.isCancelEnabled()) {
				return (Resources.UnsavedChangesOnThePageShort);
			}
		};
		$("[hoverText]").each(function (index, element) { rm.qtip.showInfo($(element), $(element).attr("hoverText")); });
		$(document).ajaxStop(function () { rm.ui.unblock(); });
		$(document).ajaxStart(function () { rm.ui.block(); });

		$(document).bind("click keyup", function () { rm.ui.ribbon.refresh(); });
		initMultiReq.addNewRow();
		initMultiReq.initErrorKeyLookup();
		rm.serviceCalls.getResourcableResourcesForSpecialResourcingNeed(function (response) { initMultiReq.resourcesForSpecialAssignmentNeedsLookup = response; });
		$(".bodyContainer").scroll(function () {
			$(".headerContainer").scrollLeft($(".bodyContainer").scrollLeft());
		});
		$(document).on("click", "[name=hlFireWalledResourceBooking]", function () {
			var requestRowId = $(this).attr("requestId");
			initMultiReq.saveMultipleRequests(false, requestRowId)
			$("#errorIcon_" + requestRowId).qtip("hide");
		});
	},
	initErrorKeyLookup: function () {
		initMultiReq.errorKeyLookup = {
			Project: initMultiReq.txtProjectNameSelector,
			Organization: initMultiReq.ddlOrganizationSelector,
			ResourceType: initMultiReq.ddlResourceTypeSelector,
			Region: initMultiReq.ddlRegionSelector,
			Country: initMultiReq.ddlCountrySelector,
			AssignedRegion: "#" + initMultiReq.assignedRegionContainerIdPrefix,
			AssignedCountry: "#" + initMultiReq.assignedCountryContainerIdPrefix,
			Start: initMultiReq.txtStartDateSelector,
			Stop: initMultiReq.txtStopDateSelector,
			ReqeustBudgeted: initMultiReq.ddlRequestBudgetedSelector,
			ReqeustBudgetedReason: initMultiReq.txtReasonSelector,
			ReqeustBlinded: initMultiReq.ddlRequestBlindedSelector,
			Resource: initMultiReq.txtResourceNameSelector,
			CountryRegion: initMultiReq.ddlCountryRegionSelector,
			TotalSites: initMultiReq.txtTotalSitesSelector
		};
	},
	getRowIdentity: function (parentRow) { return parentRow.attr(initMultiReq.attrRowIdentity); },
	setSelectedProjectOnRow: function (parentRow, project) { parentRow.data(initMultiReq.attrSelectedProject, project); },
	getSelectedProjectFromRow: function (parentRow) { return parentRow.data(initMultiReq.attrSelectedProject); },
	getSelectedProjectIdFromRow: function (parentRow) { return initMultiReq.getSelectedProjectFromRow(parentRow).id; },
	getSelectedProjectNameFromRow: function (parentRow) { return initMultiReq.getSelectedProjectFromRow(parentRow).value; },
	getSelectedProjectOrganizationIdFromRow: function (parentRow) { return initMultiReq.getProjectDetailsFromRow(parentRow).OrganizationId; },
	isProposalProject: function (projectDetails) { return projectDetails.ExternalSource == ProjectSource.SES; },
	getIsProposalProjetSelectedFromRow: function (parentRow) { return initMultiReq.isProposalProject(initMultiReq.getProjectDetailsFromRow(parentRow)); },
	setSelectedResourceOnRow: function (parentRow, resource) { parentRow.data(initMultiReq.attrSelectedResource, resource); },
	removeSelectedResourceFromRow: function (parentRow) { parentRow.data(initMultiReq.attrSelectedResource, null) },
	getSelectedResourceFromRow: function (parentRow) { return parentRow.data(initMultiReq.attrSelectedResource); },
	getSelectedResourceIdFromRow: function (parentRow) { var resource = initMultiReq.getSelectedResourceFromRow(parentRow); return (resource == null ? null : resource.id); },
	getSelectedOrganizationIdFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlOrganizationSelector)).val(); },
	getSelectedOrganizationalUnitIdFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlOrganizationalUnitSelector)).val(); },
	getSelectedResourceTypeIdFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlResourceTypeSelector)).val(); },
	getSelectedJobRoleIdFromRow: function (parentRow) { return ResourceTypeDetails[initMultiReq.getSelectedResourceTypeIdFromRow(parentRow)].JobRoleId; },
	getSelectedOrganizationIdFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlOrganizationSelector)).val(); },
	getSelectedResourceTypeDetails: function (parentRow) { return ResourceTypeDetails[initMultiReq.getSelectedResourceTypeIdFromRow(parentRow)]; },
	getProjectIdFromRow: function (parentRow) { return initMultiReq.getSelectedProjectFromRow(parentRow).id; },
	getIsSelectedResourceTypeGlobalFromRow: function (parentRow) { return !parentRow.find((initMultiReq.ddlRegionSelector)).is(":visible") && !parentRow.find((initMultiReq.ddlCountrySelector)).is(":visible"); },
	getIsSelectedResourceTypeRegionalFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlRegionSelector)).is(":visible") && !parentRow.find((initMultiReq.ddlCountrySelector)).is(":visible"); },
	getIsSelectedResourceTypeCountryBasedFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlCountrySelector)).is(":visible"); },
	getSelectedRegionIdFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlRegionSelector)).val(); },
	getSelectedCountryIdFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlCountrySelector)).val(); },
	getSelectedCountryNameFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlCountrySelector + " option:selected")).text(); },
	getSelectedCountryRegionFromRow: function (parentRow) { var contorl = parentRow.find((initMultiReq.ddlCountryRegionSelector + ":visible")); return contorl.length > 0 ? contorl.val() : -1; },
	getSelectedRequestBudgetedValueFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlRequestBudgetedSelector)).val(); },
	getSelectedRequestBlindedValueFromRow: function (parentRow) { return parentRow.find((initMultiReq.ddlRequestBlindedSelector)).val(); },
	getSelectedRequestBlindedValueFromRowForSave: function (parentRow) { var ddlBlindedControl = parentRow.find(initMultiReq.ddlRequestBlindedSelector + ":visible"); return (ddlBlindedControl.length == 0 ? "" : ddlBlindedControl.val()); },
	getSelectedRequestNotBudgetedReasonFromRow: function (parentRow) { return (initMultiReq.getSelectedRequestBudgetedValueFromRow(parentRow) == "Yes" ? "" : $.trim(parentRow.find(initMultiReq.txtReasonSelector).val())); },
	getNotesFromRow: function (parentRow) { return $.trim(parentRow.find(initMultiReq.txtNotesSelector).val()); },
	getStartDateFromRow: function (parentRow) { return $.trim(parentRow.find((initMultiReq.txtStartDateSelector)).val()); },
	getStopDateFromRow: function (parentRow) { return $.trim(parentRow.find((initMultiReq.txtStopDateSelector)).val()); },
	getStartDateConnectStatusFromRow: function (parentRow) { return parentRow.find(initMultiReq.txtStartDateSelector).closest("div").find(".connectedToPpm,.connectedToCountry").length == 1 ? RequestConnect_E.Connected : RequestConnect_E.Disconnected; },
	getStopDateConnectStatusFromRow: function (parentRow) { return parentRow.find(initMultiReq.txtStopDateSelector).closest("div").find(".connectedToPpm,.connectedToCountry").length == 1 ? RequestConnect_E.Connected : RequestConnect_E.Disconnected; },
	getNeedByDateFromRow: function (parentRow) { return $.trim(parentRow.find((initMultiReq.txtNeedByDateSelector)).val()); },
	getTotalSitesFromRow: function (parentRow) {
		var totalSites = $.trim(parentRow.find((initMultiReq.txtTotalSitesSelector)).val());
		return (totalSites == "") ? null : totalSites;
	},
	getPageManagerFromRow: function (parentRow) { return initMultiReq.pageManagerLookup[initMultiReq.getRowIdentity(parentRow)]; },
	getJobGradeFromRow: function (parentRow) { return parentRow.attr(initMultiReq.attrJobGrade) ? parentRow.attr(initMultiReq.attrJobGrade) : null; },
	getJobGradeInfoStringFromRow: function (parentRow) { return parentRow.attr(initMultiReq.attrJobGradeInfoStr) ? parentRow.attr(initMultiReq.attrJobGradeInfoStr) : null; },
	getProjectLastModifiedOnFromRow: function (parentRow) { return initMultiReq.getProjectDetailsFromRow(parentRow).ProjectLastModifiedOn; },
	getCalculatorValuesFromRow: function (parentRow) {
		var pageManager = initMultiReq.getPageManagerFromRow(parentRow);
		return (pageManager == null) ? {} : pageManager.getCalculatorData();
	},
	setStartStopDateFromQip: function (pageManager, qipStartStopDates) {
		if (initMultiReq.getIsProposalProjetSelectedFromRow(pageManager.parentRow)) {
			if (qipStartStopDates.hasQipData) {
				pageManager.parentRow.find(initMultiReq.txtStartDateSelector).val(qipStartStopDates.startDate);
				pageManager.parentRow.find(initMultiReq.txtStopDateSelector).val(qipStartStopDates.stopDate);
				setTimeout(function () {
					initMultiReq.getPageManagerFromRow(pageManager.parentRow).calculateNeedByDate();
					if (qipStartStopDates.stopDate == null || qipStartStopDates.stopDate == "") {
						pageManager.updateRequestStopDateComputedRequestMilestone(initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), initMultiReq.getSelectedRegionIdFromRow(pageManager.parentRow));
					}
				}, 10);
			}
			else {
				pageManager.parentRow.find(initMultiReq.txtStartDateSelector).val(qipStartStopDates.defaultStartDate);
				pageManager.parentRow.find(initMultiReq.txtStopDateSelector).val("");
				if (qipStartStopDates.defaultStartDate) {
					setTimeout(function () {
						initMultiReq.getPageManagerFromRow(pageManager.parentRow).calculateNeedByDate();
						pageManager.updateRequestStopDateComputedRequestMilestone(initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), initMultiReq.getSelectedRegionIdFromRow(pageManager.parentRow));
					}, 10);
				}
			}
		} else if (qipStartStopDates.defaultStartDate) {
			pageManager.parentRow.find(initMultiReq.txtStartDateSelector).val(qipStartStopDates.defaultStartDate);
			setTimeout(function () {
				initMultiReq.getPageManagerFromRow(pageManager.parentRow).calculateNeedByDate();
				pageManager.updateRequestStopDateComputedRequestMilestone(initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), initMultiReq.getSelectedRegionIdFromRow(pageManager.parentRow));
			}, 10);
		}
	},
	isResourceTypeSelected: function (parentRow) {
		var selectedResourceTypeId = initMultiReq.getSelectedResourceTypeIdFromRow(parentRow);
		return selectedResourceTypeId != null && selectedResourceTypeId != -1 && selectedResourceTypeId != "";
	},
	fillOrganizationDropdown: function (parentRow, projectId) {
		rm.dropdown.fill(parentRow.find(initMultiReq.ddlOrganizationSelector), rm.serviceCalls.getOrganizationsOrganizationalUnitsRRTsWithActiveResourceTypesByProjectId(projectId, true), "organizationId", "organizationName");
	},
	fillOrganizationalUnitDropdown: function (parentRow) {
		var organizationalUnitsKVList = rm.serviceCalls.getAllOrganizationalUnitForOrganizationalId($(parentRow.find(initMultiReq.ddlOrganizationSelector)).val(), initMultiReq.organizationOrganizationalUnitRRTData);
		rm.dropdown.fill(parentRow.find(initMultiReq.ddlOrganizationalUnitSelector), organizationalUnitsKVList, "organizationalUnitId", "organizationalUnitName", {}, false, true);
		$(parentRow.find(initMultiReq.ddlOrganizationalUnitSelector)).val($(parentRow.find("[name = ddlOrganizationalUnit] option")).eq(0).val());
		$(parentRow.find(initMultiReq.ddlOrganizationalUnitSelector)).trigger("change");
		if (organizationalUnitsKVList.length <= 1) {
			$(parentRow.find(initMultiReq.ddlOrganizationalUnitSelector)).prop('disabled', 'disabled');
		}
		else {
			$(parentRow.find(initMultiReq.ddlOrganizationalUnitSelector)).prop('disabled', false);
		}
	},
	fillResourceTypeDropdown: function (parentRow) {
		var rrtList = rmCommon.arrUniqueFilterResourceType(rm.serviceCalls.getRRTForOrganizationalUnit($(parentRow.find(initMultiReq.ddlOrganizationSelector)).val(), initMultiReq.getSelectedOrganizationalUnitIdFromRow(parentRow)));
		rm.dropdown.fill(parentRow.find(initMultiReq.ddlResourceTypeSelector), rrtList, "resourceTypeId", "resourceTypeName");
	},
	fillRegionDropdown: function (parentRow) {
		var resourceTypeDetails = initMultiReq.getSelectedResourceTypeDetails(parentRow);
		rm.dropdown.fill(parentRow.find(initMultiReq.ddlRegionSelector), rm.bizRules.getRegionListByResourceTypeId(resourceTypeDetails.Id), "Key", "Value", "", true, false);
	},

	fillCountryDropdownWithActiveMonitoringCountries: function (parentRow) {
		var projectDetails = initMultiReq.getProjectDetailsFromRow(parentRow);
		rm.dropdown.fill(parentRow.find(initMultiReq.ddlCountrySelector), projectDetails.MonitoringAttributes, "CountryId", "CountryName", "", true);
	},
	fillCountryDropdownWithActiveSsvCountries: function (parentRow) {
		var projectDetails = initMultiReq.getProjectDetailsFromRow(parentRow);
		rm.dropdown.fill(parentRow.find(initMultiReq.ddlCountrySelector), projectDetails.SsvAttributes, "CountryId", "CountryName", "", true);
	},
	getAllCountries: function () {
		var allCountries = new Array();
		$.each(CountriesByRegion, function (index, item) {
			allCountries = allCountries.concat(item.CountryList);
		});

		if (allCountries) {
			allCountries = allCountries.sort(function (a, b) {
				if (a.Value < b.Value) { return -1; }
				else if (a.Value > b.Value) { return 1; }
				else { return 0; }
			});
		}
		return allCountries;
	},
	fillCountryDropdownFromProjectCountries: function (parentRow) {
		var projectDetails = initMultiReq.getProjectDetailsFromRow(parentRow);
		if (rmCommon.DisplayAllContries(projectDetails)) { rm.dropdown.fill(parentRow.find(initMultiReq.ddlCountrySelector), initMultiReq.getAllCountries(), "Key", "Value", "", true); }
		else { rm.dropdown.fill(parentRow.find(initMultiReq.ddlCountrySelector), projectDetails.MonitoringAttributes, "CountryId", "CountryName", "", true); }
	},
	bindProjectSmartSearch: function (textboxObj, parentRow) {
		if (initMultiReq.projectLookupArray == null) {
			initMultiReq.projectLookupArray = rm.serviceCalls.getAwardedAndProposalProjectList();
		}

		var eventHandled = false;
		//bind the autocomplete plugin to the search box
		textboxObj.autocomplete({
			source: initMultiReq.projectLookupArray,
			matchContains: false,
			select: function (event, ui) {
				//event is not already handled by keydown handler
				if (!eventHandled && !initMultiReq.allowProjectChange(ui.item.id, parentRow)) {
					event.stopPropagation();
					event.preventDefault();
				}
				eventHandled = true;
			}
		}).keydown(function (e) {
			//event is not already handled by select handler and either enter or tab is pressed
			if (!eventHandled && (e.keyCode === 13 || e.keyCode === 9)) {
				eventHandled = true;
				initMultiReq.checkForValidProjectSelection($(this).val(), parentRow);
			} else {
				eventHandled = false;
			}
		});
	},
	getResoruceFromLookupArray: function (parentRow, resourceTypeId, resourceLookupString) {
		var resourceItem = null;
		var fulfillableResources = { resourceList: [] };
		if (!initMultiReq.isSpecialAssignmentNeedExistForRow(parentRow, fulfillableResources) && initMultiReq.resourceTypeResourceLookup != null && initMultiReq.resourceTypeResourceLookup[resourceTypeId] != null) {
			fulfillableResources.resourceList = initMultiReq.resourceTypeResourceLookup[resourceTypeId];
		}

		if (fulfillableResources.resourceList != null) {
			$.each(fulfillableResources.resourceList, function (index, item) {
				if (item.value == resourceLookupString) {
					resourceItem = item;
					return false;
				}
			});

		}
		return resourceItem;
	},
	checkForValidResoruceSelection: function (resourceValue, parentRow) {
		if (resourceValue != "") {
			var resourceItem = initMultiReq.getResoruceFromLookupArray(parentRow, initMultiReq.getSelectedResourceTypeIdFromRow(parentRow), resourceValue);
			parentRow.data("resourceItem", resourceItem);
			if (resourceItem != null) {
				initMultiReq.handleResourceChange(resourceItem, parentRow);
			}
			else {
				initMultiReq.removeSelectedResourceFromRow(parentRow);
				alert("Invalid Resource Selected.");
			}
		}
		else {
			initMultiReq.setSelectedResourceOnRow(parentRow, null);
		}
	},
	handleResourceChange: function (resource, parentRow) {
		initMultiReq.setSelectedResourceOnRow(parentRow, resource);
		rm.validation.clearError(parentRow.find(initMultiReq.txtResourceNameSelector));
		parentRow.find(initMultiReq.errorContainerSelector).addClass(initMultiReq.classHideMe);
	},
	handleResourceNameEmptyChange: function (parentRow) {
		var txtResourceNameControl = parentRow.find(initMultiReq.txtResourceNameSelector);
		if (txtResourceNameControl.val().length == 0) {
			parentRow.find(initMultiReq.errorContainerSelector).addClass(initMultiReq.classHideMe);
			initMultiReq.removeSelectedResourceFromRow(parentRow);
		}
	},
	isSpecialAssignmentNeedExistForRow: function (parentRow, outJson) {
		var hasSpecialAssignmentNeed = false;
		outJson = outJson || {};
		var selectedCountryId = initMultiReq.getSelectedCountryIdFromRow(parentRow);
		var selectedResourceTypeId = initMultiReq.getSelectedResourceTypeIdFromRow(parentRow);
		$.each(initMultiReq.resourcesForSpecialAssignmentNeedsLookup, function (index, item) {
			if (item.CountryId == selectedCountryId && item.ResourceTypeId == selectedResourceTypeId) {
				outJson.resourceList = item.ResourceList;
				hasSpecialAssignmentNeed = true;
				return false;
			}
		});

		return hasSpecialAssignmentNeed;
	},
	getFulfillableResources: function (parentRow) {
		var selectedResourceTypeId = initMultiReq.getSelectedResourceTypeIdFromRow(parentRow);
		var fulfillableResources = { resourceList: [] };
		if (initMultiReq.resourceTypeResourceLookup == null || initMultiReq.resourceTypeResourceLookup[selectedResourceTypeId] == null) {
			initMultiReq.resourceTypeResourceLookup[selectedResourceTypeId] = rm.serviceCalls.getFulfillableResourcesByResourceTypeId(selectedResourceTypeId);
		}

		if (!initMultiReq.isSpecialAssignmentNeedExistForRow(parentRow, fulfillableResources)) {
			fulfillableResources.resourceList = initMultiReq.resourceTypeResourceLookup[selectedResourceTypeId];
		}
		return fulfillableResources.resourceList;
	},
	bindResourceSmartSearch: function (textboxObj, parentRow) {
		textboxObj.unbind("keydown");
		if (textboxObj.data("ui-autocomplete") != undefined) { textboxObj.autocomplete("destroy"); }
		var eventHandled = false;
		//bind the autocomplete plugin to the search box
		textboxObj.autocomplete({
			source: initMultiReq.getFulfillableResources(parentRow),
			matchContains: false,
			select: function (event, ui) {
				//event is not already handled by keydown handler
				if (!eventHandled) {
					initMultiReq.handleResourceChange(ui.item, parentRow);
				}
				eventHandled = true;
			}
		}).keydown(function (e) {
			//event is not already handled by select handler and either enter or tab is pressed
			if (!eventHandled && (e.keyCode === 13 || e.keyCode === 9)) {
				eventHandled = true;
				initMultiReq.checkForValidResoruceSelection($(this).val(), parentRow);
			} else {
				eventHandled = false;
			}
		});
	},
	calculateFte: function (parentRow, hoursControl) {
		var jqHoursObj = $(hoursControl);
		var jqFteObj = jqHoursObj.closest("tr").find(initMultiReq.classFteSelector);
		if (rm.validation.range.validate(hoursControl)) {
			jqFteObj.val(rm.serviceCalls.calculateWeeklyFte(initMultiReq.getSelectedCountryIdFromRow(parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(parentRow), jqHoursObj.val(), initMultiReq.getSelectedJobRoleIdFromRow(parentRow)));
			jqFteObj.removeAttr(initMultiReq.attrUpdated);
			jqHoursObj.removeAttr(initMultiReq.attrUpdated);
			rm.validation.clearError(jqFteObj);
			rm.validation.clearError(jqHoursObj);
		}
	},
	calculateHours: function (parentRow, fteControl) {
		var jqFteObj = $(fteControl);
		var jqHoursObj = jqFteObj.closest("tr").find(initMultiReq.classHoursSelector);
		if (rm.validation.range.validate(fteControl)) {
			jqHoursObj.val(rm.serviceCalls.calculateWeeklyHours(initMultiReq.getSelectedCountryIdFromRow(parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(parentRow), jqFteObj.val(), initMultiReq.getSelectedJobRoleIdFromRow(parentRow)));
			jqFteObj.removeAttr(initMultiReq.attrUpdated);
			jqHoursObj.removeAttr(initMultiReq.attrUpdated);
			rm.validation.clearError(jqFteObj);
			rm.validation.clearError(jqHoursObj);
		}
	},
	calculateRegionalFte: function (parentRow, hoursControl) {
		var jqHoursObj = $(hoursControl);
		var jqFteObj = jqHoursObj.closest("tr").find(initMultiReq.classFteSelector);
		if (rm.validation.range.validate(hoursControl)) {
			jqFteObj.val(rm.serviceCalls.calculateRegionalWeeklyFte(initMultiReq.getSelectedRegionIdFromRow(parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(parentRow), jqHoursObj.val(), initMultiReq.getSelectedJobRoleIdFromRow(parentRow)));
			jqFteObj.removeAttr(initMultiReq.attrUpdated);
			jqHoursObj.removeAttr(initMultiReq.attrUpdated);
			rm.validation.clearError(jqFteObj);
			rm.validation.clearError(jqHoursObj);
		}
	},
	calculateRegionalHours: function (parentRow, fteControl) {
		var jqFteObj = $(fteControl);
		var jqHoursObj = jqFteObj.closest("tr").find(initMultiReq.classHoursSelector);
		if (rm.validation.range.validate(fteControl)) {
			jqHoursObj.val(rm.serviceCalls.calculateRegionalWeeklyHours(initMultiReq.getSelectedRegionIdFromRow(parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(parentRow), jqFteObj.val(), initMultiReq.getSelectedJobRoleIdFromRow(parentRow)));
			jqFteObj.removeAttr(initMultiReq.attrUpdated);
			jqHoursObj.removeAttr(initMultiReq.attrUpdated);
			rm.validation.clearError(jqFteObj);
			rm.validation.clearError(jqHoursObj);
		}
	},
	calculateGlobalFte: function (parentRow, hoursControl) {
		var jqHoursObj = $(hoursControl);
		var jqFteObj = jqHoursObj.closest("tr").find(initMultiReq.classFteSelector);
		if (rm.validation.range.validate(hoursControl)) {
			jqFteObj.val(rm.serviceCalls.calculateGlobalWeeklyFte(initMultiReq.getSelectedProjectOrganizationIdFromRow(parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(parentRow), jqHoursObj.val(), initMultiReq.getSelectedJobRoleIdFromRow(parentRow)));
			jqFteObj.removeAttr(initMultiReq.attrUpdated);
			jqHoursObj.removeAttr(initMultiReq.attrUpdated);
			rm.validation.clearError(jqFteObj);
			rm.validation.clearError(jqHoursObj);
		}
	},
	calculateGlobalHours: function (parentRow, fteControl) {
		var jqFteObj = $(fteControl);
		var jqHoursObj = jqFteObj.closest("tr").find(initMultiReq.classHoursSelector);
		if (rm.validation.range.validate(fteControl)) {
			jqHoursObj.val(rm.serviceCalls.calculateGlobalWeeklyHours(initMultiReq.getSelectedProjectOrganizationIdFromRow(parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(parentRow), jqFteObj.val(), initMultiReq.getSelectedJobRoleIdFromRow(parentRow)));
			jqFteObj.removeAttr(initMultiReq.attrUpdated);
			jqHoursObj.removeAttr(initMultiReq.attrUpdated);
			rm.validation.clearError(jqFteObj);
			rm.validation.clearError(jqHoursObj);
		}
	},
	bindEventsToControls: function (rowToReset) {
		//	var lastRow = $(initMultiReq.tblRequestsSelector + " tr").last();
		var lastRow = rowToReset;

		lastRow.find(initMultiReq.imgDeleteRequestRowSelector).click(initMultiReq.deleteRow);
		lastRow.find(initMultiReq.txtProjectNameSelector).focus();
		initMultiReq.bindProjectSmartSearch(lastRow.find(initMultiReq.txtProjectNameSelector), lastRow);
		lastRow.find(initMultiReq.ddlOrganizationSelector).change(function () { initMultiReq.handleOrganizationChange(lastRow); });
		lastRow.find(initMultiReq.ddlOrganizationalUnitSelector).change(function () { initMultiReq.handleOrganizationalUnitChange(lastRow); });
		lastRow.find(initMultiReq.ddlResourceTypeSelector).change(function () { initMultiReq.handleResourceTypeChange(lastRow); });
		lastRow.find(initMultiReq.ddlRegionSelector).change(function () { initMultiReq.handleRegionChange(lastRow); });
		lastRow.find(initMultiReq.ddlCountrySelector).change(function () { initMultiReq.handleCountryChangeChange(lastRow); });
		lastRow.find(initMultiReq.ddlRequestBudgetedSelector).change(function () { initMultiReq.handleRequestBudgetedChange(lastRow, $(this)); });
		lastRow.find(initMultiReq.ddlRequestBlindedSelector).change(function () { initMultiReq.handleRequestBlindedChange(lastRow, $(this)); });
		lastRow.find(initMultiReq.ddlCountryRegionSelector).change(function () { initMultiReq.handleCountryRegionChange(lastRow, $(this)); });
		lastRow.find(initMultiReq.imgSiteCountPopUpSelector).click(function () { initMultiReq.handleImgSiteCountClick(lastRow); });
		lastRow.find(initMultiReq.txtResourceNameSelector).change(function () { initMultiReq.handleResourceNameEmptyChange(lastRow) });
	},
	handleImgSiteCountClick: function (parentRow) {
		var countryId = initMultiReq.getSelectedCountryIdFromRow(parentRow);
		if (countryId == -1) {
			alert("Select country and try again.");
		}
		else {
			var title = "Site Status Counts - " + initMultiReq.getSelectedProjectNameFromRow(parentRow) + " - " + initMultiReq.getSelectedCountryNameFromRow(parentRow);
			ucscbsNs.render(initMultiReq.getSelectedProjectIdFromRow(parentRow), countryId, false);
			rm.ui.dialog.showModalWithButtons(initMultiReq.divSiteCountPopUpContainerSelector, title, "", false, 450, "auto", [rm.ui.dialog.standardButtons.cancel]);
		}
	},
	handleCountryRegionChange: function (parentRow, jqCountryRegionDdl) {
		if (jqCountryRegionDdl.val() != "-1") { rm.validation.clearError(jqCountryRegionDdl); }
	},
	handleRequestBlindedChange: function (parentRow, jqControlRequestBlindedDdl) {
		if (jqControlRequestBlindedDdl.val() != "-1") { rm.validation.clearError(jqControlRequestBlindedDdl); }
	},
	calculateTotalHoursForFlatFteCalculator: function (parentRow) {
		var txtFteControl = parentRow.find(initMultiReq.classFteSelector);
		var txtHoursControl = parentRow.find(initMultiReq.classHoursSelector);
		var startDateControl = parentRow.find(initMultiReq.txtStartDateSelector);
		var stopDateControl = parentRow.find(initMultiReq.txtStopDateSelector);
		var pageManager = initMultiReq.getPageManagerFromRow(parentRow);

		if (txtFteControl.length > 0 &&
			rm.validation.range.validate(txtFteControl) &&
			rm.date.isValidDate(startDateControl.val(), false) &&
			rm.date.isValidDate(stopDateControl.val(), false) &&
			pageManager.isStartDateLessThanOrEqualToStopDate(startDateControl, stopDateControl)) {
			var postData = {
				FTE: txtFteControl.val(),
				countryId: initMultiReq.getSelectedCountryIdFromRow(parentRow),
				resourceTypeId: initMultiReq.getSelectedResourceTypeIdFromRow(parentRow),
				jobRoleId: initMultiReq.getSelectedJobRoleIdFromRow(parentRow),
				startDate: startDateControl.val(),
				stopDate: stopDateControl.val()
			};
			rm.serviceCalls.calculateTotalHours(postData, function (data) { txtHoursControl.val(data); });
		}
	},
	handlePhaseFteHoursChange: function (parentRow, control, calculateFunction) {
		initMultiReq.handleFteHoursChange(parentRow, control, calculateFunction, function () { initMultiReq.showQipConnectDisconnectIcon(parentRow, control.closest("tr")); });
	},
	handleQipRegionalFteHoursChange: function (parentRow, control, calculateFunction) {
		initMultiReq.handleFteHoursChange(parentRow, control, calculateFunction, function () { initMultiReq.showQipConnectDisconnectIcon(parentRow, control.closest("tr")); });
	},
	handleQipGlobalFteHoursChange: function (parentRow, control, calculateFunction) {
		initMultiReq.handleFteHoursChange(parentRow, control, calculateFunction, function () { initMultiReq.showQipConnectDisconnectIcon(parentRow, control.closest("tr")); });
	},
	handleGenericFteHoursChange: function (parentRow, control, calculateFunction) { initMultiReq.handleFteHoursChange(parentRow, control, calculateFunction); },
	handleFteHoursChange: function (parentRow, control, calculateFunction, calculationSuccessFunction) {
		if (rm.validation.range.validate(control)) {
			control.val(rm.utilities.formatNumberString(control.val(), control.attr("formating")));
			setTimeout(function () {
				calculateFunction(parentRow, control);
				if (calculationSuccessFunction) {
					setTimeout(function () { calculationSuccessFunction(); }, 10);
				}
			}, 10);
		}
	},
	markControlAsUpdated: function (parentRow, control) {
		control.attr(initMultiReq.attrUpdated, initMultiReq.attrUpdated);
		setTimeout(function () { initMultiReq.showQipConnectDisconnectIcon(parentRow, control.closest("tr")); }, 10);
	},
	isValidProjectSelected: function (parentRow) {
		var isValid = true;
		var jqProjectObj = parentRow.find(initMultiReq.txtProjectNameSelector);
		var projectFormTextBox = initMultiReq.getProjectFromLookupArrayByProjectCodeProtocol(jqProjectObj.val());
		var projectFormRow = initMultiReq.getSelectedProjectFromRow(parentRow);
		if (projectFormTextBox == null) {
			isValid = false;
			rm.validation.addError(jqProjectObj, "invalid Project selected. Please select a Project from the lookup list.");
		}
		else if (projectFormRow != null && projectFormRow.id != projectFormTextBox.id) {
			isValid = false;
			rm.validation.addError(jqProjectObj, "Project has been changed after valid selection. To prevent this error from occuring, always change the Project by selecting a Reosurce from Project lookup list.");
		}
		else {
			rm.validation.clearError(jqProjectObj);
		}
		return isValid;
	},
	isValidOrganizationSelected: function (parentRow) {
		var jqOrgUnitDdl = parentRow.find(initMultiReq.ddlOrganizationSelector);
		var isValid = initMultiReq.getSelectedOrganizationIdFromRow(parentRow) != "-1";

		if (isValid) { rm.validation.clearError(jqOrgUnitDdl); }
		else { rm.validation.addError(jqOrgUnitDdl, Resources.OrganizationRequired); }

		return isValid;
	},
	isValidResourceTypeSelected: function (parentRow) {
		var isValid = initMultiReq.getSelectedResourceTypeIdFromRow(parentRow) != "-1";

		var jqResourceTypeDdl = parentRow.find(initMultiReq.ddlResourceTypeSelector);
		if (isValid) { rm.validation.clearError(jqResourceTypeDdl); }
		else { rm.validation.addError(jqResourceTypeDdl, "Please select Resource Request Type"); }


		return isValid;
	},
	hardBookAndSubmit: function () {

		$.each($(initMultiReq.getUnsavedRowSelector() + " input.hours[updated]"), function (index, hoursControl) {
			var jqHoursObj = $(hoursControl);
			initMultiReq.calculateFte($(jqHoursObj.closest("tr[rowid]")), jqHoursObj);
		});

		$.each($(initMultiReq.getUnsavedRowSelector() + " input.fte[updated]"), function (index, fteControl) {
			var jqFteObj = $(fteControl);
			initMultiReq.calculateHours($(jqFteObj.closest("tr[rowid]")), jqFteObj);
		});
		setTimeout(function () {
			initMultiReq.saveMultipleRequests(true);
		}, 5);
	},
	hasUnsavedRows: function () { return ($(initMultiReq.getUnsavedRowSelector()).length > 0); },
	isAddRowEnabled: function () { return true; },
	isCloneRowEnabled: function () { return $(initMultiReq.chkSelectSelector + ":checked:visible").length > 0; },
	isHardBookAndSubmitEnabled: function () { return initMultiReq.hasUnsavedRows(); },
	cancel: function () { if (confirm(Resources.UnsavedChangesOnThePage)) { window.onbeforeunload = null; rm.utilities.reloadPage(); } },
	isCancelEnabled: function () { return $(initMultiReq.getUnsavedRowSelector()).find("input[value!='']:visible,textarea[value!='']:visible,select[value!='-1']:visible").length > 0; },
	getAssignedCountryRegionsFromRow: function (parentRow) {
		return {
			CountryList: initMultiReq.getSelectedAssignedCountriesFromRow(parentRow),
			RegionList: initMultiReq.getSelectedAssignedRegionsFromRow(parentRow)
		};
	},
	getCustomFieldsFromRow: function (parentRow) {
		return rm.customFields.getCustomFieldUserEnteredValues(parentRow.find(initMultiReq.classCustomFieldContainerSelector));
	},
	getPostDataFromRow: function (parentRow, validateFirewalledProject) {
		var calculatorData = initMultiReq.getCalculatorValuesFromRow(parentRow);
		var pageManager = initMultiReq.getPageManagerFromRow(parentRow);
		var resourceTypeDetails = (pageManager == null) ? null : pageManager.resourceTypeDetails;
		return {
			ProjectName: initMultiReq.getSelectedProjectNameFromRow(parentRow),
			RowId: initMultiReq.getRowIdentity(parentRow),
			ProjectId: initMultiReq.getSelectedProjectIdFromRow(parentRow),
			RegionId: initMultiReq.getSelectedRegionIdFromRow(parentRow),
			CountryId: initMultiReq.getSelectedCountryIdFromRow(parentRow),
			ResourceTypeId: initMultiReq.getSelectedResourceTypeIdFromRow(parentRow),
			OrganizationId: initMultiReq.getSelectedOrganizationIdFromRow(parentRow),
			OrganizationalUnitId: initMultiReq.getSelectedOrganizationalUnitIdFromRow(parentRow),
			StartDate: initMultiReq.getStartDateFromRow(parentRow),
			StartDateStatus: initMultiReq.getStartDateConnectStatusFromRow(parentRow),
			StopDate: initMultiReq.getStopDateFromRow(parentRow),
			StopDateStatus: initMultiReq.getStopDateConnectStatusFromRow(parentRow),
			NeedByDate: (resourceTypeDetails == null) ? null : (resourceTypeDetails.ShowNeedByDate ? initMultiReq.getNeedByDateFromRow(parentRow) : null),
			TotalSites: initMultiReq.getTotalSitesFromRow(parentRow),
			RequestBudgeted: initMultiReq.getSelectedRequestBudgetedValueFromRow(parentRow),
			Reason: initMultiReq.getSelectedRequestNotBudgetedReasonFromRow(parentRow),
			RequestBlinded: initMultiReq.getSelectedRequestBlindedValueFromRowForSave(parentRow),
			AssignedCountryRegions: initMultiReq.getAssignedCountryRegionsFromRow(parentRow),
			StaticInitiateCalculator: calculatorData.phaseCalculatorRowList,
			StaticInitiateCalcTimestamp: calculatorData.phaseCalculatorRowTimestampList,
			GenericInitiateCalculatorPhaseDate: calculatorData.genericCalculatorRowList,
			GenericInitiateCalcTimestamp: calculatorData.genericCalculatorRowTimestampList,
			DynamicCustomFieldsData: initMultiReq.getCustomFieldsFromRow(parentRow),
			JobGrade: initMultiReq.getJobGradeFromRow(parentRow),
			JobGradeInfoStr: initMultiReq.getJobGradeInfoStringFromRow(parentRow),
			ResourceId: initMultiReq.getSelectedResourceIdFromRow(parentRow),
			Notes: initMultiReq.getNotesFromRow(parentRow),
			RequestTimestamp: {
				ProjectLastModifiedOn: initMultiReq.getProjectLastModifiedOnFromRow(parentRow),
				RequestLastModifiedOn: null,
				AttributeLastModifiedOn: null,
				SiteLastModifiedOn: null,
				AddressLastModifiedOn: null,
				PiLastModifiedOn: null
			},
			SSVType: SSVType_E.NA,
			IMDateStatus: RequestConnect_E.Disconnected,
			CRATrainingDateStatus: RequestConnect_E.Disconnected,
			IMDate: null,
			Duration: 0,
			VisitType: -1,
			AdhocInitiateCalculator: null,
			AdhocInitiateCalcTimestamp: null,
			CountryRegion: initMultiReq.getSelectedCountryRegionFromRow(parentRow),
			FTE: calculatorData.FTE,
			TotalHours: calculatorData.TotalHours,
			CRATrainingDate: null,
			calculatorGroupData: null,
			SiteId: -1,
			Location: null,
			RequestId: null,
			ValidateFirewalledProject: validateFirewalledProject
		};
	},
	saveMultipleRequests: function (checkForFirewallConflict, requestRowId) {
		var postData = { requestList: new Array() };
		var atLeastOneRowInvalid = false;
		$.each($(initMultiReq.getUnsavedRowSelector()), function (index, row) {
			var parentRow = $(row);
			//When requestRowId is null, we want to process all requests. Otherwise, process 
			//only 1 request identified by reqeustRowId
			if (requestRowId == null || requestRowId == initMultiReq.getRowIdentity(parentRow)) {
				var isRowValid = true;
				var pageManager = initMultiReq.getPageManagerFromRow(parentRow);
				if (pageManager) { isRowValid = pageManager.isValid(); }
				else {
					isRowValid = initMultiReq.isValidProjectSelected(parentRow) && isRowValid;
					isRowValid = initMultiReq.isValidOrganizationSelected(parentRow) && isRowValid;
					isRowValid = initMultiReq.isValidResourceTypeSelected(parentRow) && isRowValid;
				}
				if (isRowValid) {
					postData.requestList.push(initMultiReq.getPostDataFromRow(parentRow, checkForFirewallConflict));
				} else { atLeastOneRowInvalid = true; }
			}
		});

		if (atLeastOneRowInvalid) { rm.ui.messages.addError("Please fix the highlighted errors and try again."); }
		else { rm.ui.messages.clearAllMessages(); }

		if (postData.requestList.length > 0) {
			rm.ajax.requestSvcAsyncPost("SaveMultipleInitiateRequests", postData, function (response) { initMultiReq.handleSaveResponse(response, false); });
		}
	},
	handleSaveResponse: function (response, checkForFirewallConflict) {
		if (response) {
			var hasFailureResponse = false;
			var hasSuccessResponse = false;
			var firstErrorControlFocused = false;
			$.each(response, function (index, data) {
				if (data.ContainsValidationErrors) {
					hasFailureResponse = true;
					firstErrorControlFocused = initMultiReq.showErrorsInRow(data, firstErrorControlFocused);
				}
				else {
					hasSuccessResponse = true;
					initMultiReq.makeRowReadonly(data);
				}
			});

			if (!hasFailureResponse && hasSuccessResponse) { rm.ui.messages.showSuccess('Request(s) submitted ' + (allowHardbooking ? 'or hardbooked' : '') + ' successfully.'); }//all success
			else if (hasFailureResponse && !hasSuccessResponse) { rm.ui.messages.addError('Request(s) cannot be submitted ' + (allowHardbooking ? 'or hardbooked' : '') + ' . Hover over error indicator for more details'); }//all failure
			else if (hasFailureResponse && hasSuccessResponse) { rm.ui.messages.addError('Some request(s) cannot be submitted ' + (allowHardbooking ? 'or hardbooked' : '') + ' . Hover over error indicator for more details'); }//Some failed some succeeded
		}
		rm.ui.ribbon.delayedRefresh();
	},
	makeRowReadonly: function (rowResponse) {
		if (rowResponse) {
			var requestId = rowResponse.RowJson.id;
			var tableRowId = rowResponse.RowJson.UiRowId;

			var parentRow = $(initMultiReq.getRowSelectorByRowId(tableRowId));
			parentRow.find("[hideInReadonlyMode=1]").remove();
			parentRow.find("table[showBorderInReadonlyMode=1]").addClass("readonlyTable");
			$.each(parentRow.find("input:visible,select:visible,textarea:visible"), function (index, element) {
				var jqElement = $(element);
				if (jqElement[0].nodeName == "SELECT") {
					jqElement.parent().html(jqElement.find("option:selected").text());
				}
				else if (jqElement.is(":checkbox") || jqElement.is(":radio")) {
					jqElement.parent().html(jqElement.is(":checked") ? jqElement.attr("dataValue") : "");
				}
				else { jqElement.parent().html(jqElement.val()); }
			});

			$.each(parentRow.find(".multiselectDropdownContainerInitMulti .multiSelectDropDownText:visible"), function (index, element) {
				var jqElement = $(element);
				jqElement.closest("td").html(jqElement.text());
			});

			parentRow.find("img[excludeFromUnbind!=1]").unbind("click").css({ cursor: "auto" });
			parentRow.attr(initMultiReq.attrIsSaved, "1").addClass(initMultiReq.classSavedSuccessfully);
			parentRow.find(initMultiReq.successContainerSelector).removeClass(initMultiReq.classHideMe);
			parentRow.find(initMultiReq.errorContainerSelector).hide();

			parentRow.find(".chkSelect").remove();
			//var editLink = parentRow.find(initMultiReq.successContainerSelector + " a");
			//editLink.attr("href", editLink.attr("href").replace("{0}", requestId)).html(editLink.html().replace("{0}", requestId));
			setTimeout(function () { parentRow.fadeOut(); }, 3000);
		}
	},
	showErrorsInRow: function (rowResponse, firstErrorControlFocused) {
		var errorMessages = "";
		if (rowResponse) {
			var parentRow = $(initMultiReq.getRowSelectorByRowId(rowResponse.RowJson.UiRowId));
			var consolidatedRowErrors = "Please fix the highlighted errors and try again<br/>";
			var firstErrorControl;
			$.each(rowResponse.ValidationErrors, function (index, errorObj) {
				if (errorObj.MessageType == MessageType_E.AlertMessage || errorObj.MessageType == MessageType_E.GridIcon) {
					consolidatedRowErrors += errorObj.Value + "<br />";
					if (!firstErrorControl) { firstErrorControl = parentRow.find(initMultiReq.errorIconSelector); }
				}
				else {
					var jqControl = parentRow.find(initMultiReq.errorKeyLookup[errorObj.Key]);
					if (jqControl.length == 0) {
						jqControl = parentRow.find(initMultiReq.errorKeyLookup[errorObj.Key] + rowResponse.RowJson.UiRowId);
					}
					if (jqControl) {
						rm.validation.addError(jqControl, errorObj.Value);
						if (!firstErrorControl) { firstErrorControl = jqControl; }
					}
				}
			});
			if (!firstErrorControlFocused && firstErrorControl && firstErrorControl.length == 1) {
				var controlPosition = firstErrorControl.position();
				$("#s4-workspace").scrollTop(controlPosition.top - 50).scrollLeft(controlPosition.left - 50);
				firstErrorControlFocused = true;
			}
			parentRow.find(initMultiReq.errorContainerSelector).removeClass(initMultiReq.classHideMe);
			var errorIcon = parentRow.find(initMultiReq.errorIconSelector);

			consolidatedRowErrors += "<input type='button' value='Ok' onclick='$(&#39;#errorIcon_" + rowResponse.RowJson.UiRowId + "&#39;).qtip(&#39;hide&#39;);' style='float: right;'>";;
			rm.qtip.showError("#errorIcon_" + rowResponse.RowJson.UiRowId, consolidatedRowErrors, null, null, null, { event: "click unfocus" });
		}
		return firstErrorControlFocused;
	},
	allowAddingRow: function () {
		return ($(initMultiReq.getUnsavedRowSelector() + " " + initMultiReq.txtProjectNameSelector).filter(function (idx, ele) { return $(ele).val() == ""; }).length == 0);
	},
	allowCloningRow: function (rowToClone) {
		return initMultiReq.isCloneRowEnabled() && (initMultiReq.getSelectedProjectFromRow(rowToClone) != null);
		//var isGlobalRrt = initMultiReq.getIsSelectedResourceTypeRegionalFromRow(rowToClone);
		//var isRegionalRrt = initMultiReq.getIsSelectedResourceTypeCountryBasedFromRow(rowToClone);
		//var isCountryBasedRrt = initMultiReq.getSelectedRegionIdFromRow(rowToClone);

		//var allowCloning = (initMultiReq.getSelectedProjectFromRow(rowToClone) != null && initMultiReq.getSelectedResourceTypeIdFromRow(rowToClone) != "-1");
		//if (allowCloning && !isGlobalRrt) {
		//	if (isRegionalRrt && initMultiReq.getSelectedRegionIdFromRow(rowToClone) == "-1") {
		//		allowCloning = false;
		//	}
		//	else if (isCountryBasedRrt && initMultiReq.getSelectedCountryIdFromRow(rowToClone) == "-1") {
		//		allowCloning = false;
		//	}
		//}
		//return allowCloning;
	},
	addNewRow: function (forCloning, appendAfterRow) {
		if (forCloning || initMultiReq.allowAddingRow()) {
			initMultiReq.rowIdentity++;
			var newRow = $(initMultiReq.tblTemplateRequestRowSelector + " tr:eq(0)").clone().attr(initMultiReq.attrRowIdentity, initMultiReq.rowIdentity).attr(initMultiReq.attrIsSaved, "0");
			newRow.find(initMultiReq.classMultiSelectRegionDropdownContainerSelector).attr("id", initMultiReq.assignedRegionContainerIdPrefix + initMultiReq.rowIdentity);
			newRow.find(initMultiReq.classMultiSelectCountryDropdownContainerSelector).attr("id", initMultiReq.assignedCountryContainerIdPrefix + initMultiReq.rowIdentity);
			newRow.find(initMultiReq.errorIconSelector).attr("id", "errorIcon_" + initMultiReq.rowIdentity);
			if (appendAfterRow == null) {
				$(initMultiReq.tblRequestsSelector).append(newRow);
			}
			else {
				var rowIndex = appendAfterRow.index();
				rowIndex = (rowIndex == 0) ? 1 : (rowIndex + 1);
				$(initMultiReq.tblRequestsSelector + " > tr:nth-child(" + rowIndex + ")").after(newRow);
			}
			setTimeout(function () { initMultiReq.bindEventsToControls(newRow); }, 10);
			rm.ui.ribbon.delayedRefresh();
			return newRow;
		} else {
			alert("Please enter data in existing rows before adding new one.");
		}
	},
	cloneSelectedRows: function () {
		$.each($(initMultiReq.chkSelectSelector + ":checked"), function (index, chkBoxEle) {
			initMultiReq.cloneSingleRow($(chkBoxEle).closest("tr"));
		});
	},
	cloneSingleRow: function (rowToClone) {
		if (initMultiReq.allowCloningRow(rowToClone)) {
			var clonedRow = initMultiReq.addNewRow(true, rowToClone);
			var userData = initMultiReq.getPostDataFromRow(rowToClone, false);
			var isGlobalRrt = initMultiReq.getIsSelectedResourceTypeRegionalFromRow(rowToClone);
			var isRegionalRrt = initMultiReq.getIsSelectedResourceTypeCountryBasedFromRow(rowToClone);

			setTimeout(function () {
				initMultiReq.allowProjectChange(userData.ProjectId, clonedRow);
				clonedRow.find(initMultiReq.txtProjectNameSelector).val(userData.ProjectName);
				clonedRow.find(initMultiReq.ddlOrganizationSelector).val(userData.OrganizationId);
				initMultiReq.handleOrganizationChange(clonedRow);

				setTimeout(function () {
					if (userData.OrganizationalUnitId != -1) {
						clonedRow.find(initMultiReq.ddlOrganizationalUnitSelector).val(userData.OrganizationalUnitId);
						initMultiReq.handleOrganizationalUnitChange(clonedRow);
					}

					setTimeout(function () {
						clonedRow.find(initMultiReq.ddlResourceTypeSelector).val(userData.ResourceTypeId);
						initMultiReq.handleResourceTypeChange(clonedRow);

						setTimeout(function () {
							if (userData.RegionId != -1) {
								clonedRow.find(initMultiReq.ddlRegionSelector).val(userData.RegionId);
								initMultiReq.handleRegionChange(clonedRow);
								clonedRow.find(initMultiReq.ddlRegionSelector).trigger("change.pm35");

							}

							setTimeout(function () {
								if (userData.CountryId != -1) {
									clonedRow.find(initMultiReq.ddlCountrySelector).val(userData.CountryId);
									initMultiReq.handleCountryChangeChange(clonedRow);
									clonedRow.find(initMultiReq.ddlCountrySelector).trigger("change.pm34");
								}

								setTimeout(function () {
									initMultiReq.copyDataToClonedRow(clonedRow, userData);
									initMultiReq.copyCustomFieldsDataToClonedRow(clonedRow, userData);
									initMultiReq.copyCalculatorDataToClonedRow(clonedRow, userData);
								}, 10);

							}, 10);

						}, 10);

					}, 10);

				}, 10);

			}, 10);
		}
		else {
			alert("Row cannot be cloned until Project Code is selected");
		}
	},
	copyDataToClonedRow: function (clonedRow, dataToCopy) {
		clonedRow.find(initMultiReq.txtStartDateSelector).val(dataToCopy.StartDate);
		clonedRow.find(initMultiReq.txtStopDateSelector).val(dataToCopy.StopDate);

		setTimeout(function () {
			//required to set connect disconnect status image
			clonedRow.find(initMultiReq.txtStartDateSelector).trigger("change");
			clonedRow.find(initMultiReq.txtStopDateSelector).trigger("change");
		}, 10);

		clonedRow.find(initMultiReq.txtNeedByDateSelector).val(dataToCopy.NeedByDate);
		clonedRow.find(initMultiReq.ddlRequestBudgetedSelector).val(dataToCopy.RequestBudgeted);
		clonedRow.find(initMultiReq.txtNotesSelector).val(dataToCopy.Notes);
		clonedRow.find(initMultiReq.txtTotalSitesSelector).val(dataToCopy.TotalSites);

		initMultiReq.handleRequestBudgetedChange(clonedRow, clonedRow.find(initMultiReq.ddlRequestBudgetedSelector));
		setTimeout(function () { clonedRow.find(initMultiReq.txtReasonSelector).val(dataToCopy.Reason); }, 10);
		clonedRow.find(initMultiReq.ddlRequestBlindedSelector).val(dataToCopy.RequestBlinded);

		initMultiReq.copyAssignedCountryRegionToClonedRow(clonedRow, dataToCopy);
		setTimeout(function () { clonedRow.find(initMultiReq.ddlCountryRegionSelector).val(dataToCopy.CountryRegion); }, 10);

	},
	copyAssignedCountryRegionToClonedRow: function (clonedRow, dataToCopy) {
		if (clonedRow && dataToCopy && dataToCopy.AssignedCountryRegions && Array.isArray(dataToCopy.AssignedCountryRegions.RegionList)) {
			var regionCollection = clonedRow.find("#" + initMultiReq.getAssignedRegionContainIdFromRow(clonedRow)).dropdownV2("selectItemsByIdArray", dataToCopy.AssignedCountryRegions.RegionList);

			if (Array.isArray(dataToCopy.AssignedCountryRegions.CountryList)) {
				initMultiReq.handleAssignedRegionChange(clonedRow, regionCollection);
				setTimeout(function () {
					clonedRow.find("#" + initMultiReq.getAssignedCountryContainIdFromRow(clonedRow)).dropdownV2("selectItemsByIdArray", dataToCopy.AssignedCountryRegions.CountryList);
				}, 10);
			}
		}
		;
	},
	copyCustomFieldsDataToClonedRow: function (clonedRow, userData) {
		if (clonedRow && userData && Array.isArray(userData.DynamicCustomFieldsData)) {
			userData.DynamicCustomFieldsData.forEach(function (customField) {
				var customFieldControl = clonedRow.find("[ResourceTypeCustomFieldId=" + customField.ResourceTypeCustomFieldId + "]");
				if (customFieldControl.is("input[type=text]") || customFieldControl.is("select") || customFieldControl.is("textarea")) {
					customFieldControl.val(customField.Value);
				}
				else {
					clonedRow.find("[ResourceTypeCustomFieldId=" + customField.ResourceTypeCustomFieldId + "][datavalue=" + customField.Value + "]").attr("checked", true);
				}
			});
		}
	},
	copyCalculatorDataToClonedRow: function (clonedRow, dataToCopy) {
		var pageManager = initMultiReq.getPageManagerFromRow(clonedRow);
		if (pageManager != null) {
			pageManager.copyCalculatorDataToClonedRow(dataToCopy);
		}
	},
	deleteRow: function () {
		var rowCount = $(initMultiReq.tblRequestsSelector + ' tr').length;
		if (rowCount == 1) {
			alert("You cannot Delete all the rows in this Table!");
		}
		else if (confirm('Are you sure you want to delete this request row?')) {
			$(this).closest("tr").remove();
			rm.ui.ribbon.delayedRefresh();
		}
	},
	checkForValidProjectSelection: function (projectCodeProtocol, parentRow) {
		var projectItem = initMultiReq.getProjectFromLookupArrayByProjectCodeProtocol(projectCodeProtocol);
		parentRow.data("projectItem", projectItem);
		if (projectItem != null) {
			initMultiReq.allowProjectChange(projectItem.id, parentRow);
		}
		else {
			alert("Invalid Project Selected.");
		}
	},
	getProjectFromLookupArrayByProjectId: function (projectId) {
		var projectItem = null;
		if (initMultiReq.projectLookupArray != null) {
			$.each(initMultiReq.projectLookupArray, function (index, item) {
				if (item.id == projectId) {
					projectItem = item;
					return false;
				}
			});
		}
		return projectItem;
	},
	getProjectFromLookupArrayByProjectCodeProtocol: function (projectLookupString) {
		var projectItem = null;
		if (initMultiReq.projectLookupArray != null) {
			$.each(initMultiReq.projectLookupArray, function (index, item) {
				if (item.value == projectLookupString) {
					projectItem = item;
					return false;
				}
			});
		}
		return projectItem;
	},
	allowProjectChange: function (projectId, parentRow) {
		var projectItem = initMultiReq.getProjectFromLookupArrayByProjectId(projectId);
		var projectCodeProtocol = projectItem.value;
		var isResourceTypeSelected = initMultiReq.isResourceTypeSelected(parentRow);

		if (!isResourceTypeSelected || (isResourceTypeSelected && confirm('The project code has been changed, if you wish to proceed with changing the project code all data entered will be reset. Click OK to change the project code and reset the resource request form, or Cancel to keep the original project code and entered data'))) {
			initMultiReq.handleProjectChange(projectId, parentRow);
			initMultiReq.setSelectedProjectOnRow(parentRow, projectItem);
			setTimeout(function () { initMultiReq.handleProposalProjectIndicatorVisibility(parentRow); }, 10);
			var projectDetailsFromRow = initMultiReq.getProjectDetailsFromRow(parentRow);
			if (!projectDetailsFromRow.IsMilestoneSequenceValid) {
				rm.ui.messages.showWarningAndFadeAway(Resources.ProjectMilestoneSequenceValidationError);
			}
			return true;
		}
		else {
			parentRow.find(initMultiReq.txtProjectNameSelector).val(initMultiReq.getSelectedProjectFromRow(parentRow).value);
			return false;
		}
	},
	handleProjectChange: function (projectId, parentRow) {
		initMultiReq.resetRowData(parentRow);
		initMultiReq.fillOrganizationDropdown(parentRow, projectId);
	},
	handleOrganizationChange: function (parentRow) {
		//This method was named as OrganizationalUnitDropdown previously. Changed it to Organization since there was a requirement to add OrgUnit also to this grid.
		initMultiReq.resetRowOnOrganizationChange(parentRow);
		initMultiReq.fillOrganizationalUnitDropdown(parentRow);
	},
	handleOrganizationalUnitChange: function (parentRow) {
		//For 12765 added a new Method called OrganizationalUnitChange, Previously the same method name was used for Organization Selector.
		initMultiReq.resetRowOnOrganizationalUnitChange(parentRow);
		initMultiReq.fillResourceTypeDropdown(parentRow);
	},
	handleProposalProjectIndicatorVisibility: function (parentRow) {
		var imageName = "imgProposal"
		var imageSelector = "[name=" + imageName + "]";
		parentRow.find(imageSelector).remove();

		if (initMultiReq.getIsProposalProjetSelectedFromRow(parentRow)) {
			var img = $("<img>", { name: imageName, src: "/_layouts/spui/images/proposalicon.png", alt: "Proposal Project", title: "Proposal Project", style: "position:relative;top:-17px;float:right;padding-right:1px;" });
			parentRow.find(initMultiReq.txtProjectNameSelector).parent().append(img);
		}

	},
	getProjectDetailsFromRow: function (parentRow) { return rm.serviceCalls.getProjectDetailsByProjectId(initMultiReq.getProjectIdFromRow(parentRow)); },
	getAssignedRegionContainIdFromRow: function (parentRow) { return initMultiReq.assignedRegionContainerIdPrefix + parentRow.attr(initMultiReq.attrRowIdentity); },
	getAssignedCountryContainIdFromRow: function (parentRow) { return initMultiReq.assignedCountryContainerIdPrefix + parentRow.attr(initMultiReq.attrRowIdentity); },
	handleRequestBudgetedChange: function (parentRow, ddlRequestBudgetedControl) {
		if (ddlRequestBudgetedControl.val() != "-1") { rm.validation.clearError(ddlRequestBudgetedControl); }

		if (initMultiReq.getSelectedRequestBudgetedValueFromRow(parentRow) == "No") {
			parentRow.find(initMultiReq.txtReasonSelector).show().removeClass(initMultiReq.classHideMe);
		}
		else {
			parentRow.find(initMultiReq.txtReasonSelector).hide().val("");
			rm.validation.clearError(parentRow.find(initMultiReq.txtReasonSelector));
		}
	},
	resetRowData: function (parentRow) {
		initMultiReq.setSelectedProjectOnRow(parentRow, null);
		initMultiReq.setSelectedResourceOnRow(parentRow, null);
		rm.dropdown.emptyWithSelect(parentRow.find(initMultiReq.ddlResourceTypeSelector));
		initMultiReq.bindAssignedRegionMultiSelect(parentRow, null, initMultiReq.getAssignedRegionContainIdFromRow(parentRow));

		$.each(parentRow.find("select,input,textarea"), function (index, element) {
			var ele = $(element);
			if (!ele.hasClass("doNotClear")) {
				if (ele.is(":text") || ele.is("textarea")) { ele.val(""); }
				else if (ele.is(":radio") || ele.is(":checkbox")) { ele.prop("checked", false); }
				else if (ele.is("select")) {
					if (ele.hasClass("staticData")) { ele.val(ele.find("option:eq(0)").val()); }
					else { rm.dropdown.emptyWithSelect(ele); }
				}
			}
		});
		initMultiReq.clearAllErrors(parentRow);
	},
	resetRowOnOrganizationChange: function (parentRow) {
		initMultiReq.resetRowOnResourceTypeChange(parentRow);
	},
	resetRowOnOrganizationalUnitChange: function (parentRow) {
		initMultiReq.resetRowOnResourceTypeChange(parentRow);
	},
	resetRowOnResourceTypeChange: function (parentRow) {
		var budgetedDdl = parentRow.find(initMultiReq.ddlRequestBudgetedSelector);
		budgetedDdl.val(budgetedDdl.find("option:eq(0)").val());

		var blindedDdl = parentRow.find(initMultiReq.ddlRequestBlindedSelector);
		blindedDdl.val(blindedDdl.find("option:eq(0)").val());

		var countryDdl = parentRow.find(initMultiReq.ddlCountrySelector).hide().unbind("change.pm34");
		rm.dropdown.emptyWithSelect(countryDdl);

		var ddlRegion = parentRow.find(initMultiReq.ddlRegionSelector).hide();
		rm.dropdown.emptyWithSelect(ddlRegion);

		var txtStartDateCtrl = parentRow.find(initMultiReq.txtStartDateSelector).unbind("change.pm34").val("").removeClass("disabledTextBox").attr("readonly", false);
		var txtStopDateCtrl = parentRow.find(initMultiReq.txtStopDateSelector).unbind("change.pm34").val("").removeClass("disabledTextBox").attr("readonly", false);
		parentRow.find(initMultiReq.txtNeedByDateSelector).val("");

		var countryRegionDdl = parentRow.find(initMultiReq.ddlCountryRegionSelector).hide();
		rm.dropdown.empty(countryRegionDdl);

		parentRow.find(initMultiReq.txtReasonSelector).hide();
		initMultiReq.bindAssignedRegionMultiSelect(parentRow, null, initMultiReq.getAssignedRegionContainIdFromRow(parentRow));
		initMultiReq.bindAssignedCountryMultiSelect(parentRow, null, initMultiReq.getAssignedCountryContainIdFromRow(parentRow));
		parentRow.find(initMultiReq.txtNotesSelector).val("");
		parentRow.find(initMultiReq.txtReasonSelector).val("").hide();
		initMultiReq.clearCalculatorCell(parentRow);
		initMultiReq.clearCustomFieldsCell(parentRow);
		initMultiReq.clearAllErrors(parentRow);
	},
	clearCalculatorCell: function (parentRow) { parentRow.find(initMultiReq.calculatorCellSelector).html(""); },
	clearCustomFieldsCell: function (parentRow) { parentRow.find(initMultiReq.classCustomFieldContainerSelector).html(""); },
	clearAllErrors: function (parentRow) {
		$.each(parentRow.find("input,select"), function (index, element) { rm.validation.clearError(element); });
	},
	handleResourceTypeChange: function (parentRow) {
		var resourceTypeDetails = initMultiReq.getSelectedResourceTypeDetails(parentRow);
		if (resourceTypeDetails) {
			var additionalProjectData = initMultiReq.getProjectDetailsFromRow(parentRow);
			if (!initMultiReq.isProposalProject(additionalProjectData) && resourceTypeDetails.DteCheckRequired && additionalProjectData.ProjectDteType.toUpperCase() == "UNKNOWN") {
				alert(Resources.ProjectDteTypeIsUnknown.replace("{Project}", parentRow.find(initMultiReq.txtProjectNameSelector).val()));
				initMultiReq.resetRowOnOrganizationChange(parentRow);
				$(this).val("-1");
				return false;
			}
			initMultiReq.bindResourceSmartSearch(parentRow.find(initMultiReq.txtResourceNameSelector), parentRow);

			initMultiReq.resetRowOnResourceTypeChange(parentRow);
			if (initMultiReq.getSelectedResourceTypeDetails(parentRow) != null) {
				var pageManager = initMultiReq.getPageManager(initMultiReq.getSelectedResourceTypeDetails(parentRow), parentRow, initMultiReq.getProjectDetailsFromRow(parentRow));
				initMultiReq.pageManagerLookup[initMultiReq.getRowIdentity(parentRow)] = pageManager;
				pageManager.draw();

				parentRow.find(initMultiReq.txtStartDateSelector).unbind("keyup.needBy").unbind("change.needBy").bind("keyup.needBy change.needBy", function () {
					setTimeout(function () {
						pageManager.calculateNeedByDate.apply(pageManager);
					}, 10);
				});

			}
			initMultiReq.fillRegionDropdown(parentRow);
		}
	},
	handleRegionChange: function (parentRow) {
		var ddlRegionControl = parentRow.find(initMultiReq.ddlRegionSelector);
		if (ddlRegionControl.val() != "-1") { rm.validation.clearError(ddlRegionControl); }
		var resourceTypeId = initMultiReq.getSelectedResourceTypeIdFromRow(parentRow);
		var projectId = initMultiReq.getSelectedProjectIdFromRow(parentRow);
		var regionId = initMultiReq.getSelectedRegionIdFromRow(parentRow);

		rm.dropdown.fill(parentRow.find(initMultiReq.ddlCountrySelector), rm.bizRules.getCountryListByResourceTypeId(resourceTypeId, projectId, regionId), "Key", "Value", "", true);
	},
	handleCountryChangeChange: function (parentRow) {
		var ddlCountryControl = parentRow.find(initMultiReq.ddlCountrySelector);
		if (ddlCountryControl.val() != "-1") { rm.validation.clearError(ddlCountryControl); }
		var pageManager = initMultiReq.getPageManagerFromRow(parentRow);
		pageManager.renderCalculator();
		pageManager.initDateConnectDisconnect();

		setTimeout(function () {
			if (initMultiReq.getIsProposalProjetSelectedFromRow(parentRow)) { pageManager.calculateNeedByDate(); }
			initMultiReq.showCustomFieldDefaultvalues(parentRow);
		}, 10);
	},
	showQipConnectDisconnectIcon: function (parentRow, phaseRow) {
		var qipConnectDisconnectImageCell = phaseRow.find(initMultiReq.phaseConnectStatusCellSelector);
		var allowQipConnection = qipConnectDisconnectImageCell.attr(initMultiReq.attrAllowQipConnection) == "1";
		if (allowQipConnection) {
			var fteControl = phaseRow.find(initMultiReq.classFteSelector);
			var hoursControl = phaseRow.find(initMultiReq.classHoursSelector);
			var isDisconnected = fteControl.attr(initMultiReq.attrQipConnectedValue) != fteControl.val() || hoursControl.attr(initMultiReq.attrQipConnectedValue) != hoursControl.val() || fteControl.val() == "" || hoursControl.val() == "";
			var imageConfig = isDisconnected ? initMultiReq.qipConnectConfig.disConnectedImage : initMultiReq.qipConnectConfig.connectedImage;
			qipConnectDisconnectImageCell.find("." + initMultiReq.qipConnectConfig.connectedImage.class + ",." + initMultiReq.qipConnectConfig.disConnectedImage.class).remove();
			var image = $("<img>", { class: imageConfig.class, title: imageConfig.title, alt: imageConfig.alt, src: imageConfig.src });
			qipConnectDisconnectImageCell.prepend(image);

			if (isDisconnected) {
				image.click(function () { initMultiReq.handleQipConnectClick(parentRow, phaseRow); });
			}
		}
	},
	handleQipConnectClick: function (parentRow, phaseRow) {
		var qipConnectDisconnectImageCell = phaseRow.find(initMultiReq.phaseConnectStatusCellSelector);
		var fteControl = phaseRow.find(initMultiReq.classFteSelector);
		var connectedFteValue = fteControl.attr(initMultiReq.attrQipConnectedValue);

		if (connectedFteValue == "") {
			alert("Reconnection is not possible as there are no values entered into budget.");
		}
		else {
			fteControl.val(connectedFteValue);
			var hoursControl = phaseRow.find(initMultiReq.classHoursSelector);
			hoursControl.val(hoursControl.attr(initMultiReq.attrQipConnectedValue));
			setTimeout(function () { initMultiReq.showQipConnectDisconnectIcon(parentRow, phaseRow); }, 10);
		}
	},
	showCustomFields: function (parentRow, resourceTypeId) {
		rm.serviceCalls.getCustomFieldsByResourceTypeId(resourceTypeId, -1, initMultiReq.getProjectIdFromRow(parentRow), function (response) {
			initMultiReq.handleCusotmFieldResponse(response, parentRow.find(initMultiReq.classCustomFieldContainerSelector), false, parentRow.attr("rowId"));
		});
	},
	handleCusotmFieldResponse: function (response, containerObject, showHeader, rowId) {
		rm.customFields.renderResourceTypeCustomfields(response, containerObject, showHeader, rowId);
	},
	bindAssignedRegionMultiSelect: function (parentRow, regionData, containerId) {
		var dropdownOptions = {
			items: regionData,
			ContainerId: containerId,
			itemClick: function (key, value, isChecked, itemCollection) {
				if (itemCollection) {
					$.each(itemCollection, function (index, region) {
						if (!region.isChecked) {
							$.each(region.Countries, function (index, country) { country.isChecked = false; });
						}
					});
				}
			},
			onCollapse: function (itemCollection) {
				initMultiReq.handleAssignedRegionChange(parentRow, itemCollection);
			},
			css: { widht: 150 }
		};
		parentRow.find("#" + dropdownOptions.ContainerId).dropdownV2(dropdownOptions);
		rm.validation.clearError($("#" + dropdownOptions.ContainerId));
		initMultiReq.handleAssignedRegionChange(parentRow, null)
	},
	handleAssignedRegionChange: function (parentRow, itemCollection) {
		var countryData = new Array();
		if (itemCollection) {
			$.each(itemCollection, function (index, region) {
				if (region.isChecked) {
					countryData = countryData.concat(region.Countries)
				}
			});
			initMultiReq.bindAssignedCountryMultiSelect(parentRow, countryData, initMultiReq.getAssignedCountryContainIdFromRow(parentRow));
		}
	},
	bindAssignedCountryMultiSelect: function (parentRow, countryData, containerId) {
		if (countryData) {
			countryData = countryData.sort(function (a, b) {
				if (a.value < b.value) { return -1; }
				else if (a.value > b.value) { return 1; }
				else { return 0; }
			});
		}
		var dropdownOptions = {
			items: countryData,
			ContainerId: containerId,
			onCollapse: function (itemCollection) {
				if (initMultiReq.getPageManagerFromRow(parentRow).showCountryRegion) {
					initMultiReq.handleAssignedCountryChange(parentRow, itemCollection);
				}
			}
		};
		parentRow.find("#" + dropdownOptions.ContainerId).dropdownV2(dropdownOptions);
		rm.validation.clearError($("#" + dropdownOptions.ContainerId));
	},
	handleAssignedCountryChange: function (parentRow, itemCollection) {
		var countryIdList = new Array();
		$.each(itemCollection, function (index, country) { if (country.isChecked) { countryIdList.push(country.key); } });
		initMultiReq.handleCountryRegionVisibility(parentRow, countryIdList);
	},
	handleCountryRegionVisibility: function (parentRow, countryIdArray) {
		var countryRegionCtrl = parentRow.find(initMultiReq.ddlCountryRegionSelector);
		if (countryIdArray.length > 0) {
			rm.serviceCalls.getCountryRegionsByCountryIdListSync({ countryIds: countryIdArray.join("|") }, function (response) {
				if (response.length > 0) {
					rm.dropdown.fill(countryRegionCtrl, response, "Id", "Name", -1, true);
					rm.validation.clearError(countryRegionCtrl);
					countryRegionCtrl.removeClass(initMultiReq.classHideMe).show();
				}
				else {
					countryRegionCtrl.hide();
					rm.dropdown.empty(countryRegionCtrl);
				}
			});
		} else {
			rm.validation.clearError(countryRegionCtrl);
			countryRegionCtrl.hide();
			rm.dropdown.empty(countryRegionCtrl);
		}
	},
	clearAssignedRegionAndCountry: function (parentRow) {
		var conuntryRegionContainerId = initMultiReq.assignedRegionContainerIdPrefix + parentRow.attr(initMultiReq.attrRowIdentity)
		var conuntryCountryContainerId = initMultiReq.assignedCountryContainerIdPrefix + parentRow.attr(initMultiReq.attrRowIdentity)

		parentRow.find("#" + conuntryRegionContainerId).dropdownV2({ items: null, ContainerId: conuntryRegionContainerId });
		parentRow.find("#" + conuntryCountryContainerId).dropdownV2({ items: null, ContainerId: conuntryCountryContainerId });
	},
	getSelectedAssignedRegionsFromRow: function (parentRow) {
		return parentRow.find("#" + initMultiReq.getAssignedRegionContainIdFromRow(parentRow)).dropdownV2("getSelectedValues");
	},
	getSelectedAssignedCountriesFromRow: function (parentRow) {
		return parentRow.find("#" + initMultiReq.getAssignedCountryContainIdFromRow(parentRow)).dropdownV2("getSelectedValues");
	},
	getRegionConnectedMilestones: function (resourceTypeId, projectId, regionId) {
		//Do not make ajax call if resource type has no connected dates
		var regionConnectedMilestoneDetails;
		if (initMultiReq.regionConnectedMilestoneDetails[resourceTypeId] &&
			initMultiReq.regionConnectedMilestoneDetails[resourceTypeId][projectId] &&
			initMultiReq.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId]) {
			regionConnectedMilestoneDetails = initMultiReq.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId];
		}
		else {
			regionConnectedMilestoneDetails = rm.serviceCalls.getRegionConnectedMilestoneDetailsFromDb(resourceTypeId, projectId, regionId);
			if (!initMultiReq.regionConnectedMilestoneDetails[resourceTypeId]) { initMultiReq.regionConnectedMilestoneDetails[resourceTypeId] = {}; }
			if (!initMultiReq.regionConnectedMilestoneDetails[resourceTypeId][projectId]) { initMultiReq.regionConnectedMilestoneDetails[resourceTypeId][projectId] = {}; }
			initMultiReq.regionConnectedMilestoneDetails[resourceTypeId][projectId][regionId] = regionConnectedMilestoneDetails;
		}
		return regionConnectedMilestoneDetails;
	},
	getPageManager: function (resourceTypeDetails, parentRow, projectDetails) {
		var pageManagerType = initMultiReq.isProposalProject(projectDetails) ? resourceTypeDetails.ProposalPagemanagerType : resourceTypeDetails.PagemanagerType;
		switch (pageManagerType) {
			case 9:
				return new pageManagerType_9(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 20:
				return new pageManagerType_20(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 33: return new pageManagerType_33(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 25: return new pageManagerType_Generic(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 34: return new pageManagerType_34(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 35: return new pageManagerType_35(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 36: return new pageManagerType_36(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 37: return new pageManagerType_37(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 38: return new pageManagerType_38(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 22: return new pageManagerType_22(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 26: return new pageManagerType_26(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 41: return new pageManagerType_41(parentRow, resourceTypeDetails, projectDetails);
				break;
			case 42: return new pageManagerType_42(parentRow, resourceTypeDetails, projectDetails);
				break;
			default: alert("Invalid pagemenager type requested: " + pageManagerType);
		}
	},
	showCustomFieldDefaultvalues: function (parentRow) {
		if (!initMultiReq.getIsProposalProjetSelectedFromRow(parentRow)) {
			rm.serviceCalls.getCustomFieldDefaultvalues(initMultiReq.getSelectedResourceTypeIdFromRow(parentRow), initMultiReq.getSelectedProjectIdFromRow(parentRow), initMultiReq.getSelectedCountryIdFromRow(parentRow),
				function (data) {
					if (data && data.length > 0) {
						$.each(data, function (index, item) { $("[resourcetypecustomfieldid=" + item.FieldId + "]").val(item.Default); });
					}
				});
		}
	},
	getStageMilestoneInfoIconText: function (stageInfo) {
		var infoIconText = " ";
		if (stageInfo) {
			var infoIconText = "<b>Start Date: </b>" + stageInfo.StartDate +
				"<br /><b>Start Date Source: </b>" + stageInfo.StartDateSource +
				"<br /><b>Stop Date: </b>" + stageInfo.StopDate +
				"<br /><b>Stop Date Source: </b>" + stageInfo.StopDateSource;
		}
		return infoIconText;
	}
};

//9:	CRS_PageManager
var pageManagerType_9 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.showCountryRegion = true;
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();

		this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);

		if (!initMultiReq.getIsProposalProjetSelectedFromRow(this.parentRow)) {
			this.parentRow.find(initMultiReq.classMultiSelectRegionDropdownContainerSelector).show().removeClass(initMultiReq.classHideMe);
			this.parentRow.find(initMultiReq.classMultiSelectCountryDropdownContainerSelector).show().removeClass(initMultiReq.classHideMe);
			this.populateAssignedRegionMultiSelect(rm.serviceCalls.getAssignedRegionAndCountriesByProjectId(initMultiReq.getSelectedProjectIdFromRow(this.parentRow)));
		}
	};
	this.renderCalculator = function () { this.renderPhaseCalculator(); };
	this.getCalculatorData = function () {
		return {
			phaseCalculatorRowList: this.getPhaseCalculatorData(),
			phaseCalculatorRowTimestampList: this.parentRow.data(initMultiReq.attrCalcTimestamp)
		};
	};
	this.isValid = function () {
		var isValid = this.isValidAssignedRegionSelected();
		isValid = this.isValidAssignedCountrySelected() && isValid;
		isValid = this.isValidCountryRegionSelected() && isValid;
		isValid = pageManagerType_9.prototype.isValid.call(this) && isValid;
		isValid = pageManagerType_9.prototype.isPhaseCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_9.prototype.copyPhaseCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//20:	Regional_CPM_PageManager
var pageManagerType_20 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();
		this.handleBlindedColumnVisibility();

		this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);

		if (!initMultiReq.getIsProposalProjetSelectedFromRow(this.parentRow)) {
			this.parentRow.find(initMultiReq.classMultiSelectRegionDropdownContainerSelector).show().removeClass(initMultiReq.classHideMe);
			this.parentRow.find(initMultiReq.classMultiSelectCountryDropdownContainerSelector).show().removeClass(initMultiReq.classHideMe);
			this.populateAssignedRegionMultiSelect(rm.serviceCalls.getAssignedRegionAndCountriesByProjectId(initMultiReq.getSelectedProjectIdFromRow(this.parentRow)));
		}

	};
	this.renderCalculator = function () { this.renderPhaseCalculator(); };
	this.getCalculatorData = function () {
		return {
			phaseCalculatorRowList: this.getPhaseCalculatorData(),
			phaseCalculatorRowTimestampList: this.parentRow.data(initMultiReq.attrCalcTimestamp)
		};
	};
	this.isValid = function () {
		var isValid = this.isValidAssignedRegionSelected();
		isValid = this.isValidAssignedCountrySelected() && isValid;
		isValid = pageManagerType_20.prototype.isValid.call(this) && isValid;
		isValid = pageManagerType_20.prototype.isPhaseCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_20.prototype.copyPhaseCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//33:	PhaseCalculatorPageManager_Type1
var pageManagerType_33 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();
		this.handleBlindedColumnVisibility();

		this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);
	};
	this.renderCalculator = function () { this.renderPhaseCalculator(); };
	this.getCalculatorData = function () {
		return {
			phaseCalculatorRowList: this.getPhaseCalculatorData(),
			phaseCalculatorRowTimestampList: this.parentRow.data(initMultiReq.attrCalcTimestamp)
		};
	};
	this.isValid = function () {
		var isValid = pageManagerType_33.prototype.isValid.call(this);
		isValid = pageManagerType_33.prototype.isPhaseCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_33.prototype.copyPhaseCalculatorDataToClonedRow.call(this, dataToCopy); };
};

var pageManagerType_Generic = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();

		this.parentRow.find(initMultiReq.txtNeedByDateSelector).hide().html("");
		this.parentRow.find(initMultiReq.txtStartDateSelector).attr("disabled", "disabled").datepicker('destroy').closest("div").show().removeClass(initMultiReq.classHideMe).find(".disconnectedFromPpm,.disconnectedFromCountry,.connectedToPpm,.connectedToCountry").remove();
		this.parentRow.find(initMultiReq.txtStopDateSelector).attr("disabled", "disabled").datepicker('destroy').closest("div").show().removeClass(initMultiReq.classHideMe).find(".disconnectedFromPpm,.disconnectedFromCountry,.connectedToPpm,.connectedToCountry").remove();
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);
	};
	this.renderCalculator = function () { this.renderGenericCalculator(); };
	this.getCalculatorData = function () {
		var calculatorData = this.getGenericCalculatorData();
		return {
			genericCalculatorRowList: calculatorData.calculatorValues,
			genericCalculatorRowTimestampList: calculatorData.calculatorTimestamps
		};
	};
	this.isValid = function () {
		var isValid = pageManagerType_Generic.prototype.isValid.call(this)
		isValid = pageManagerType_Generic.prototype.isGenericCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_Generic.prototype.copyGenericCalculatorDataToClonedRow.call(this, dataToCopy); };

};

//34:	FlatFteCalculatorPageManager_Type1
var pageManagerType_34 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		var pageManager = this;
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();
		initMultiReq.fillCountryDropdownFromProjectCountries(this.parentRow);

		var txtStartDateCtrl = this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker().bind("change.pm34", function () { initMultiReq.calculateTotalHoursForFlatFteCalculator(pageManager.parentRow); });
		var txtStopDateCtrl = this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().bind("change.pm34", function () { initMultiReq.calculateTotalHoursForFlatFteCalculator(pageManager.parentRow); });;
		txtStartDateCtrl.closest("div").show().removeClass(initMultiReq.classHideMe);
		txtStopDateCtrl.closest("div").show().removeClass(initMultiReq.classHideMe);

		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe).bind("change.pm34", function () { initMultiReq.handleCountryRegionVisibility(pageManager.parentRow, [$(this).val()]); });
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);
	};
	this.renderCalculator = function () { this.renderFlatFteCalculator(); };
	this.getCalculatorData = function () { return this.getFlatFteCalculatorData(); };
	this.isValid = function () {
		var isValid = pageManagerType_34.prototype.isValid.call(this);
		isValid = this.isValidCountryRegionSelected() && isValid;
		isValid = pageManagerType_34.prototype.isFlatFteCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_34.prototype.copyFlatFteCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//35:	RegionCalculatorPageManager_Type1
var pageManagerType_35 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		var pageManager = this;
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();

		var txtStartDateCtrl = this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker();
		var txtStopDateCtrl = this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker();
		txtStartDateCtrl.closest("div").show().removeClass(initMultiReq.classHideMe);
		txtStopDateCtrl.closest("div").show().removeClass(initMultiReq.classHideMe);
		txtStartDateCtrl.bind("change.rsul", function () { pageManager.updateRequestStopDateComputedRequestMilestone(initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), initMultiReq.getSelectedRegionIdFromRow(pageManager.parentRow)); });


		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe).bind("change.pm35", function () { pageManager.renderCalculator.call(pageManager); });
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);
	};
	this.renderCalculator = function () { this.renderRegionBasedCalculator(); };
	this.getCalculatorData = function () {
		return {
			phaseCalculatorRowList: this.getQipRegionalCalculatorData(),
			phaseCalculatorRowTimestampList: this.parentRow.data(initMultiReq.attrCalcTimestamp)
		};
	};
	this.isValid = function () {
		var isValid = pageManagerType_35.prototype.isValidIgnoreCountry.call(this);
		isValid = pageManagerType_35.prototype.isQipRegionalCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_35.prototype.copyPhaseCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//36:	PhaseCalculatorPageManager_Type2
var pageManagerType_36 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();

		if (initMultiReq.getIsProposalProjetSelectedFromRow(this.parentRow)) {
			this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		} else {
			initMultiReq.fillCountryDropdownWithActiveMonitoringCountries(parentRow);
		}

		this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);

	};
	this.renderCalculator = function () { this.renderPhaseCalculator(); };
	this.getCalculatorData = function () {
		return {
			phaseCalculatorRowList: this.getPhaseCalculatorData(),
			phaseCalculatorRowTimestampList: this.parentRow.data(initMultiReq.attrCalcTimestamp)
		};
	};
	this.isValid = function () {
		var isValid = pageManagerType_36.prototype.isValid.call(this);
		isValid = pageManagerType_36.prototype.isPhaseCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_36.prototype.copyPhaseCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//37:	PhaseCalculatorPageManager_Type3
var pageManagerType_37 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();
		if (initMultiReq.getIsProposalProjetSelectedFromRow(this.parentRow)) {
			this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		} else {
			initMultiReq.fillCountryDropdownWithActiveSsvCountries(parentRow);
		}

		this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);

	};
	this.renderCalculator = function () { this.renderPhaseCalculator(); };
	this.getCalculatorData = function () {
		return {
			phaseCalculatorRowList: this.getPhaseCalculatorData(),
			phaseCalculatorRowTimestampList: this.parentRow.data(initMultiReq.attrCalcTimestamp)
		};
	};
	this.isValid = function () {
		var isValid = pageManagerType_36.prototype.isValid.call(this);
		isValid = pageManagerType_36.prototype.isPhaseCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_37.prototype.copyPhaseCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//38:	GlobalCalculatorPageManager_Type1
var pageManagerType_38 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		var pageManager = this;
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();

		var txtStartDateCtrl = this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker();
		txtStartDateCtrl.closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);
		txtStartDateCtrl.bind("change.rsul", function () { pageManager.updateRequestStopDateComputedRequestMilestone(initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), initMultiReq.getSelectedRegionIdFromRow(pageManager.parentRow)); });

		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);

		this.renderCalculator();
		this.initDateConnectDisconnect();

	};
	this.renderCalculator = function () { this.renderGlobalCalculator(); };
	this.getCalculatorData = function () {
		return {
			phaseCalculatorRowList: this.getPhaseCalculatorData(),
			phaseCalculatorRowTimestampList: this.parentRow.data(initMultiReq.attrCalcTimestamp)
		};
	};
	this.isValid = function () {
		var isValid = pageManagerType_36.prototype.isValidIgnoreCountryAndRegion.call(this);
		isValid = pageManagerType_36.prototype.isPhaseCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_38.prototype.copyPhaseCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//22:	SSV_Monitoring_PageManager
var pageManagerType_22 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();

		this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);
	};
	this.renderCalculator = function () { this.renderFlatFteNoTotalHoursCalculator(); };
	this.getCalculatorData = function () { return this.getFlatFteNoTotalHoursCalculatorData(); };
	this.isValid = function () {
		var isValid = pageManagerType_22.prototype.isValid.call(this)
		isValid = pageManagerType_22.prototype.isFlatFteCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_22.prototype.copyFlatFteNoTotalHoursCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//26:	Proposal_Base_PageManager
var pageManagerType_26 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();

		var startDate = rm.date.maxDate(rm.date.today(), rm.date.getDateFromQDateString(projectDetails.ExpectedStartDate));
		this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").val(rm.date.getQDateStringFromDate(startDate)).qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").val(rm.date.addMonthsToQdate(rm.date.getQDateStringFromDate(startDate), 6)).qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);
	};
	this.renderCalculator = function () { this.renderFlatFteNoTotalHoursCalculator(); };
	this.getCalculatorData = function () { return this.getFlatFteNoTotalHoursCalculatorData(); };
	this.isValid = function () {
		var isValid = pageManagerType_26.prototype.isValid.call(this)
		isValid = pageManagerType_26.prototype.isFlatFteCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_26.prototype.copyFlatFteNoTotalHoursCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//41:	PhaseCalculatorPageManager_Type4
var pageManagerType_41 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();
		this.handleImgSiteCountPopUpVisibility();

		this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker().closest("div").show().removeClass(initMultiReq.classHideMe);
		//this.parentRow.find(initMultiReq.txtNeedByDateSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtTotalSitesSelector).show().removeClass(initMultiReq.classHideMe);
	};
	this.renderCalculator = function () { this.renderPhaseCalculator(); };
	this.getCalculatorData = function () {
		return {
			phaseCalculatorRowList: this.getPhaseCalculatorData(),
			phaseCalculatorRowTimestampList: this.parentRow.data(initMultiReq.attrCalcTimestamp)
		};
	};
	this.isValid = function () {
		var isValid = pageManagerType_41.prototype.isValid.call(this);
		isValid = pageManagerType_41.prototype.isPhaseCalculatorValid.call(this) && isValid;
		isValid = pageManagerType_41.prototype.isTotalSitesValid.call(this) && isValid;

		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_41.prototype.copyPhaseCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//42:	FlatFteCalculatorPageManager_Type2
var pageManagerType_42 = function (parentRow, resourceTypeDetails, projectDetails) {
	this.parentRow = parentRow;
	this.resourceTypeDetails = resourceTypeDetails;
	this.projectDetails = projectDetails;
	this.draw = function () {
		var pageManager = this;
		this.resetUi();
		this.handleBlindedColumnVisibility();
		this.handleCustomFieldColumnVisibility();
		this.handleNeedByDateVisibility();
		this.handleImgSiteCountPopUpVisibility();

		initMultiReq.fillCountryDropdownFromProjectCountries(this.parentRow);

		var txtStartDateCtrl = this.parentRow.find(initMultiReq.txtStartDateSelector).removeAttr("disabled").qDatepicker();
		var txtStopDateCtrl = this.parentRow.find(initMultiReq.txtStopDateSelector).removeAttr("disabled").qDatepicker();
		txtStartDateCtrl.closest("div").show().removeClass(initMultiReq.classHideMe);
		txtStopDateCtrl.closest("div").show().removeClass(initMultiReq.classHideMe);

		this.parentRow.find(initMultiReq.txtStartDateSelector).val(rm.date.getTodayAsQDateString());
		setTimeout(function () { pageManager.calculateNeedByDate(); }, 10);

		this.parentRow.find(initMultiReq.txtNotesSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRegionSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlCountrySelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector).show().removeClass(initMultiReq.classHideMe);
		this.parentRow.find(initMultiReq.txtResourceNameSelector).show().removeClass(initMultiReq.classHideMe);
	};
	this.renderCalculator = function () { this.renderFlatFteNoTotalHoursCalculator(); };
	this.getCalculatorData = function () { return this.getFlatFteNoTotalHoursCalculatorData(); };
	this.isValid = function () {
		var isValid = pageManagerType_42.prototype.isValid.call(this);
		isValid = pageManagerType_42.prototype.isFlatFteCalculatorValid.call(this) && isValid;
		return isValid;
	};
	this.copyCalculatorDataToClonedRow = function (dataToCopy) { pageManagerType_42.prototype.copyFlatFteCalculatorDataToClonedRow.call(this, dataToCopy); };
};

//SD:prototype makes this possible. Add common methods to basePagemanager and call it in page manager.
var basePageManager = {
	showCountryRegion: false,
	connectedQStartDate: "",
	connectedQStopDate: "",
	connectedStartDate: null,
	connectedStopDate: null,
	hasQipData: false,
	connectDisconnectConfigPpm: {
		classDisconnected: "disconnectedFromPpm",
		classConnected: "connectedToPpm",
		imageConnected: "/_layouts/SPUI/images/ppmLinkIcon.png",
		imageDisconnected: "/_layouts/SPUI/images/ppmUnLinkIcon.png",
		getImageSelectorsForRemoval: function () { return "." + this.classDisconnected + ",." + this.classConnected },
		connectDate: function (img, pageManager) {
			image = $(img);
			txtDate = image.parent().find("input");
			txtDate.val(txtDate.attr(initMultiReq.attrConnectedDate));
			pageManager.showDateConnectDisconnectIcons(txtDate, pageManager.connectDisconnectConfigPpm);
			pageManager.updateRequestStopDateComputedRequestMilestone(initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), 0);
		},
		connectGenericDate: function (img, pageManager) {
			image = $(img);
			dateJqControl = image.parent().find("input");
			var milestoneDetails = dateJqControl.data(initMultiReq.attrMilestoneData);
			dateJqControl.val(milestoneDetails ? milestoneDetails.ConnectedDate : "");
			pageManager.showGenericRowDateConnectDisconnectIcon.call(pageManager, dateJqControl);
		}
	},
	connectDisconnectConfigCountry: {
		classDisconnected: "disconnectedFromCountry",
		classConnected: "connectedToCountry",
		imageConnected: "/_layouts/SPUI/images/conncted.png",
		imageDisconnected: "/_layouts/SPUI/images/reconnect.png",
		getImageSelectorsForRemoval: function () { return "." + this.classDisconnected + ",." + this.classConnected },
		connectDate: function (img, pageManager) {
			image = $(img);
			txtDate = image.parent().find("input");
			txtDate.val(txtDate.attr(initMultiReq.attrConnectedDate));
			pageManager.showDateConnectDisconnectIcons(txtDate, pageManager.connectDisconnectConfigCountry);
		},
		connectGenericDate: function (img, pageManager) {
			image = $(img);
			dateJqControl = image.parent().find("input");
			var milestoneDetails = dateJqControl.data(initMultiReq.attrMilestoneData);
			dateJqControl.val(milestoneDetails ? milestoneDetails.ConnectedDate : "");
			pageManager.showGenericRowDateConnectDisconnectIcon.call(pageManager, dateJqControl);
		}
	},
	resetUi: function () {
		this.showCountryRegion = false;
		rm.dropdown.emptyWithSelect(this.parentRow.find(initMultiReq.ddlRegionSelector).hide());
		rm.dropdown.emptyWithSelect(this.parentRow.find(initMultiReq.ddlCountrySelector).hide());

		this.parentRow.find(initMultiReq.classMultiSelectRegionDropdownContainerSelector).hide();
		this.parentRow.find(initMultiReq.classMultiSelectCountryDropdownContainerSelector).hide();
		this.parentRow.find(initMultiReq.ddlCountryRegionSelector).hide();
		this.parentRow.find(initMultiReq.txtTotalSitesSelector).hide();
		this.parentRow.find(initMultiReq.imgSiteCountPopUpSelector).hide();
		this.parentRow.find(initMultiReq.ddlRegionSelector).unbind("change.pm35");
		this.parentRow.find(initMultiReq.txtStopDateSelector).unbind("change.rsul");

		initMultiReq.clearAssignedRegionAndCountry(this.parentRow);
	},
	renderFlatFteCalculator: function () {
		var pageManager = this;
		var calculatorLayout = $(initMultiReq.tblFlatFteValueCalculatorLayoutSelector).clone().attr("id", null).removeClass(initMultiReq.classHideMe);
		var fteControl = calculatorLayout.find(initMultiReq.classFteSelector);
		calculatorLayout.find(initMultiReq.classFteSelector).change(function () { initMultiReq.calculateTotalHoursForFlatFteCalculator(pageManager.parentRow); });

		var calculatorCell = pageManager.parentRow.find(initMultiReq.calculatorCellSelector).html("").append(calculatorLayout);
	},
	renderFlatFteNoTotalHoursCalculator: function () {
		var pageManager = this;
		var calculatorLayout = $(initMultiReq.tblFlatFteValueNoTotalHoursCalculatorLayoutSelector).clone().attr("id", null).removeClass(initMultiReq.classHideMe);
		var fteControl = calculatorLayout.find(initMultiReq.classFteSelector);

		var calculatorCell = pageManager.parentRow.find(initMultiReq.calculatorCellSelector).html("").append(calculatorLayout);
	},
	renderPhaseCalculator: function () {
		var pageManager = this;
		var calculatorLayout = $(initMultiReq.tblPhaseCalculatorLayoutSelector).clone().attr("id", null).removeClass(initMultiReq.classHideMe);
		var calculatorCell = pageManager.parentRow.find(initMultiReq.calculatorCellSelector).html("").append(calculatorLayout);

		var qipDataList = rm.serviceCalls.getQipOthersData(initMultiReq.getSelectedProjectIdFromRow(pageManager.parentRow), initMultiReq.getSelectedCountryIdFromRow(pageManager.parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow));

		var qipStartStopDates = { hasQipData: false };
		if (!this.resourceTypeDetails.ShowStartDateConnectDisconnectIcon) {
			qipStartStopDates.defaultStartDate = rm.date.getTodayAsQDateString();
		}
		$.each(qipDataList.staticInitiateCalculatorList, function (index, dataItem) {
			var phaseRow = $(initMultiReq.tblPhaseCalculatorTemplateRowSelector + " tr").clone().attr("id", null).removeClass(initMultiReq.classHideMe);
			phaseRow.attr(initMultiReq.attrFteTypeFteMilestoneTypeId, dataItem.FTETypeFTEMilestoneTypeId);

			phaseRow.find(initMultiReq.classFteSelector).val(dataItem.FTE).attr(initMultiReq.attrQipConnectedValue, (dataItem.QipFTE == null) ? "" : dataItem.QipFTE);
			phaseRow.find(initMultiReq.stageNameCellSelector).text(dataItem.Phase);
			phaseRow.find(initMultiReq.milestoneNameCellSelector).text(dataItem.Milestones);
			phaseRow.find(initMultiReq.milestoneDateCellSelector).attr("id", dataItem.FTETypeFTEMilestoneTypeId);
			phaseRow.find(initMultiReq.classHoursSelector).val(dataItem.WeeklyHours).attr(initMultiReq.attrQipConnectedValue, (dataItem.QipWeeklyHours == null) ? "" : dataItem.QipWeeklyHours);
			phaseRow.find(initMultiReq.phaseConnectStatusCellSelector).attr(initMultiReq.attrAllowQipConnection, (dataItem.AllowQipConnection ? 1 : 0));

			//if ((initMultiReq.getIsProposalProjetSelectedFromRow(pageManager.parentRow) && dataItem.Status == 1) || !dataItem.AllowQipConnection) {
			if (!dataItem.AllowQipConnection) {
				phaseRow.find("input[type=text]").attr("disabled", "disabled").addClass("grayed");
			}
			calculatorLayout.append(phaseRow);
			rm.qtip.showInfo(phaseRow.find(initMultiReq.milestoneDateCellSelector), initMultiReq.getStageMilestoneInfoIconText(dataItem), initMultiReq.styleConfig, initMultiReq.stylePosition);
			qipStartStopDates.hasQipData = qipStartStopDates.hasQipData || (dataItem.QipFTE != null && dataItem.QipFTE.toString() != "");
			if (index == 0) { qipStartStopDates.startDate = dataItem.StartDate; }
			if (index + 1 == qipDataList.staticInitiateCalculatorList.length) { qipStartStopDates.stopDate = dataItem.StopDate; }
		});
		calculatorCell.attr(initMultiReq.attrJobGrade, qipDataList.JobGrade);
		calculatorCell.attr(initMultiReq.attrJobGradeInfoStr, qipDataList.JobGradeInfoStr);
		this.parentRow.data(initMultiReq.attrCalcTimestamp, qipDataList.StaticInitiateCalcTimestamp);
		pageManager.hasQipData = qipStartStopDates.hasQipData;

		setTimeout(function () {
			$.each(calculatorCell.find(initMultiReq.phaseRowSelector), function (index, row) {
				var phaseRow = $(row);
				initMultiReq.showQipConnectDisconnectIcon(pageManager.parentRow, phaseRow);
				var hoursControl = phaseRow.find(initMultiReq.classHoursSelector);
				hoursControl.change(function () { initMultiReq.handlePhaseFteHoursChange(pageManager.parentRow, $(this), initMultiReq.calculateFte); }).bind("keyup", function () { initMultiReq.markControlAsUpdated(pageManager.parentRow, $(this)); });
				var fteControl = phaseRow.find(initMultiReq.classFteSelector);
				fteControl.change(function () { initMultiReq.handlePhaseFteHoursChange(pageManager.parentRow, $(this), initMultiReq.calculateHours); }).bind("keyup", function () { initMultiReq.markControlAsUpdated(pageManager.parentRow, $(this)); });
			});
			initMultiReq.setStartStopDateFromQip(pageManager, qipStartStopDates);
		}, 10);
	},
	renderRegionBasedCalculator: function () {
		var pageManager = this;
		var calculatorLayout = $(initMultiReq.tblPhaseCalculatorLayoutSelector).clone().attr("id", null).removeClass(initMultiReq.classHideMe);
		var calculatorCell = pageManager.parentRow.find(initMultiReq.calculatorCellSelector).html("").append(calculatorLayout);

		var qipDataList = rm.serviceCalls.getQipRegionalData(initMultiReq.getSelectedProjectIdFromRow(pageManager.parentRow), initMultiReq.getSelectedRegionIdFromRow(pageManager.parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), rm.date.getTodayAsQDateString());

		var qipStartStopDates = { hasQipData: false, defaultStartDate: rm.date.getTodayAsQDateString() };
		$.each(qipDataList.staticInitiateCalculatorList, function (index, dataItem) {
			var phaseRow = $(initMultiReq.tblPhaseCalculatorTemplateRowSelector + " tr").clone().attr("id", null).removeClass(initMultiReq.classHideMe);
			phaseRow.attr(initMultiReq.attrFteTypeFteMilestoneTypeId, dataItem.FTETypeFTEMilestoneTypeId);
			phaseRow.find(initMultiReq.classFteSelector).val(dataItem.FTE).attr(initMultiReq.attrQipConnectedValue, (dataItem.QipFTE == null) ? "" : dataItem.QipFTE);
			phaseRow.find(initMultiReq.stageNameCellSelector).text(dataItem.Phase);
			phaseRow.find(initMultiReq.milestoneNameCellSelector).text(dataItem.Milestones);
			phaseRow.find(initMultiReq.classHoursSelector).val(dataItem.WeeklyHours).attr(initMultiReq.attrQipConnectedValue, (dataItem.QipWeeklyHours == null) ? "" : dataItem.QipWeeklyHours);

			rm.qtip.showInfo(phaseRow.find(initMultiReq.milestoneDateCellSelector), initMultiReq.getStageMilestoneInfoIconText(dataItem), initMultiReq.styleConfig, initMultiReq.stylePosition); phaseRow.find(initMultiReq.phaseConnectStatusCellSelector).attr(initMultiReq.attrAllowQipConnection, (dataItem.AllowQipConnection ? 1 : 0));

			//if (initMultiReq.getIsProposalProjetSelectedFromRow(pageManager.parentRow) && dataItem.Status == 1) {
			//	phaseRow.find("input[type=text]").attr("disabled", "disabled").addClass("grayed");
			//}

			calculatorLayout.append(phaseRow)
			qipStartStopDates.hasQipData = qipStartStopDates.hasQipData || (dataItem.QipFTE != null && dataItem.QipFTE.toString() != "");
			if (index == 0) { qipStartStopDates.startDate = dataItem.StartDate; }
			if (index + 1 == qipDataList.staticInitiateCalculatorList.length) { qipStartStopDates.stopDate = dataItem.StopDate; }
		});
		calculatorCell.attr(initMultiReq.attrJobGrade, qipDataList.JobGrade);
		calculatorCell.attr(initMultiReq.attrJobGradeInfoStr, qipDataList.JobGradeInfoStr);
		this.parentRow.data(initMultiReq.attrCalcTimestamp, qipDataList.StaticInitiateCalcTimestamp);
		pageManager.hasQipData = qipStartStopDates.hasQipData;

		setTimeout(function () {
			$.each(calculatorCell.find(initMultiReq.phaseRowSelector), function (index, row) {
				var phaseRow = $(row);
				initMultiReq.showQipConnectDisconnectIcon(pageManager.parentRow, phaseRow);
				var hoursControl = phaseRow.find(initMultiReq.classHoursSelector);
				hoursControl.change(function () { initMultiReq.handleQipRegionalFteHoursChange(pageManager.parentRow, $(this), initMultiReq.calculateRegionalFte); }).bind("keyup", function () { initMultiReq.markControlAsUpdated(pageManager.parentRow, $(this)); });
				var fteControl = phaseRow.find(initMultiReq.classFteSelector);
				fteControl.change(function () { initMultiReq.handleQipRegionalFteHoursChange(pageManager.parentRow, $(this), initMultiReq.calculateRegionalHours); }).bind("keyup", function () { initMultiReq.markControlAsUpdated(pageManager.parentRow, $(this)); });
			});
			initMultiReq.setStartStopDateFromQip(pageManager, qipStartStopDates);
		}, 10);

	},
	renderGlobalCalculator: function () {
		var pageManager = this;
		var calculatorLayout = $(initMultiReq.tblPhaseCalculatorLayoutSelector).clone().attr("id", null).removeClass(initMultiReq.classHideMe);
		var calculatorCell = pageManager.parentRow.find(initMultiReq.calculatorCellSelector).html("").append(calculatorLayout);
		var startDate = "";
		var stopDate = "";
		if (!initMultiReq.getIsProposalProjetSelectedFromRow(pageManager.parentRow)) {
			var startDate = this.getConnectedDateByMilestoneType(true, this.resourceTypeDetails.RequestStartDateConnectedMilestoneId, -1, -1);
			var stopDate = this.getConnectedDateByMilestoneType(false, this.resourceTypeDetails.RequestStopDateConnectedMilestoneId, -1, -1);
		}
		var qipDataList = rm.serviceCalls.getQipGlobalData(initMultiReq.getSelectedProjectIdFromRow(pageManager.parentRow), initMultiReq.getSelectedProjectOrganizationIdFromRow(pageManager.parentRow), initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), startDate, stopDate);

		var qipStartStopDates = { hasQipData: false };
		$.each(qipDataList.staticInitiateCalculatorList, function (index, dataItem) {
			var phaseRow = $(initMultiReq.tblPhaseCalculatorTemplateRowSelector + " tr").clone().attr("id", null).removeClass(initMultiReq.classHideMe);
			phaseRow.attr(initMultiReq.attrFteTypeFteMilestoneTypeId, dataItem.FTETypeFTEMilestoneTypeId);
			phaseRow.find(initMultiReq.classFteSelector).val(dataItem.FTE).attr(initMultiReq.attrQipConnectedValue, (dataItem.QipFTE == null) ? "" : dataItem.QipFTE);
			phaseRow.find(initMultiReq.stageNameCellSelector).text(dataItem.Phase);
			if ((dataItem.Milestones).indexOf("<br/>") >= 0) {
				var str = (dataItem.Milestones).split("<br/>");
				phaseRow.find(initMultiReq.milestoneNameCellSelector).append('<span>' + str[0] + '</span><br/>');
				phaseRow.find(initMultiReq.milestoneNameCellSelector).append('<span>' + str[1] + '</span>');
			} else {
				phaseRow.find(initMultiReq.milestoneNameCellSelector).text(dataItem.Milestones);
			}
			phaseRow.find(initMultiReq.classHoursSelector).val(dataItem.WeeklyHours).attr(initMultiReq.attrQipConnectedValue, (dataItem.QipWeeklyHours == null) ? "" : dataItem.QipWeeklyHours);
			phaseRow.find(initMultiReq.phaseConnectStatusCellSelector).attr(initMultiReq.attrAllowQipConnection, (dataItem.AllowQipConnection ? 1 : 0));
			phaseRow.find(initMultiReq.milestoneDateCellSelector).attr("id", dataItem.FTETypeFTEMilestoneTypeId);

			rm.qtip.showInfo(phaseRow.find(initMultiReq.milestoneDateCellSelector), initMultiReq.getStageMilestoneInfoIconText(dataItem), initMultiReq.styleConfig, initMultiReq.stylePosition);
			//if (initMultiReq.getIsProposalProjetSelectedFromRow(pageManager.parentRow) && dataItem.Status == 1) {
			//	phaseRow.find("input[type=text]").attr("disabled", "disabled").addClass("grayed");
			//}

			calculatorLayout.append(phaseRow)
			qipStartStopDates.hasQipData = qipStartStopDates.hasQipData || (dataItem.QipFTE != null && dataItem.QipFTE.toString() != ""); //without toString() js considers numeric 0 = "" (emply value)
			if (index == 0) { qipStartStopDates.startDate = dataItem.StartDate; }
			if (index + 1 == qipDataList.staticInitiateCalculatorList.length) { qipStartStopDates.stopDate = dataItem.StopDate; }
		});
		calculatorCell.attr(initMultiReq.attrJobGrade, qipDataList.JobGrade);
		calculatorCell.attr(initMultiReq.attrJobGradeInfoStr, qipDataList.JobGradeInfoStr);
		this.parentRow.data(initMultiReq.attrCalcTimestamp, qipDataList.StaticInitiateCalcTimestamp);
		pageManager.hasQipData = qipStartStopDates.hasQipData;

		setTimeout(function () {
			$.each(calculatorCell.find(initMultiReq.phaseRowSelector), function (index, row) {
				var phaseRow = $(row);
				initMultiReq.showQipConnectDisconnectIcon(pageManager.parentRow, phaseRow);
				var hoursControl = phaseRow.find(initMultiReq.classHoursSelector);
				hoursControl.change(function () { initMultiReq.handleQipGlobalFteHoursChange(pageManager.parentRow, $(this), initMultiReq.calculateGlobalFte); }).bind("keyup", function () { initMultiReq.markControlAsUpdated(pageManager.parentRow, $(this)); });
				var fteControl = phaseRow.find(initMultiReq.classFteSelector);
				fteControl.change(function () { initMultiReq.handleQipGlobalFteHoursChange(pageManager.parentRow, $(this), initMultiReq.calculateGlobalHours); }).bind("keyup", function () { initMultiReq.markControlAsUpdated(pageManager.parentRow, $(this)); });
			});
			initMultiReq.setStartStopDateFromQip(pageManager, qipStartStopDates);
		}, 10);
	},

	copyFlatFteCalculatorDataToClonedRow: function (dataToCopy) {
		if (dataToCopy) {
			this.parentRow.find("input[name=txtTotalHours]").val(dataToCopy.TotalHours);
			this.parentRow.find("input[name=txtFte]").val(dataToCopy.FTE);
		}
	},
	copyFlatFteNoTotalHoursCalculatorDataToClonedRow: function (dataToCopy) {
		if (dataToCopy) {
			this.parentRow.find("input[name=txtFte]").val(dataToCopy.FTE);
		}
	},
	copyPhaseCalculatorDataToClonedRow: function (dataToCopy) {
		if (dataToCopy && Array.isArray(dataToCopy.StaticInitiateCalculator)) {
			var localParentRow = this.parentRow;

			for (var index = 0; index < dataToCopy.StaticInitiateCalculator.length; index++) {
				var calculatorDataInContext = dataToCopy.StaticInitiateCalculator[index];
				var calculatorRow = this.parentRow.find("tr.phaseRow[FTETypeFTEMilestoneTypeId=" + calculatorDataInContext.FTETypeFTEMilestoneTypeId + "]");
				calculatorRow.find("input[name=txtHours]").val(calculatorDataInContext.WeeklyHours);
				//we can simply copy FTE.  However, this does not guarantee correct connected status. For connected status to be correct, we need to trigger chagne event of eith weeklyHours or FTE.
				//calculatorRow.find("input[name=txtFte]").val(calculatorDataInContext.FTE);
			}

			setTimeout(function () {
				for (var index = 0; index < dataToCopy.StaticInitiateCalculator.length; index++) {
					var calculatorDataInContext = dataToCopy.StaticInitiateCalculator[index];
					localParentRow.find("tr.phaseRow[FTETypeFTEMilestoneTypeId=" + calculatorDataInContext.FTETypeFTEMilestoneTypeId + "]").find("input[name=txtHours]").trigger("change");
				}
			}, 20);
		}
	},
	copyGenericCalculatorDataToClonedRow: function (dataToCopy) {
		if (dataToCopy && dataToCopy.GenericInitiateCalculatorPhaseDate) {
			var localParentRow = this.parentRow;

			for (var index = 0; index < dataToCopy.GenericInitiateCalculatorPhaseDate.length; index++) {
				var calculatorDataInContext = dataToCopy.GenericInitiateCalculatorPhaseDate[index];
				var calculatorRow = this.parentRow.find("tr.genericRow:eq(" + index + ")");
				calculatorRow.find("input[name=txtHours]").val(calculatorDataInContext.WeeklyHours);
				calculatorRow.find("input[name=txtFte]").val(calculatorDataInContext.FTE);
				calculatorRow.find("select[name=genericStartMilestone]").val(calculatorDataInContext.FromMilestoneUiId).trigger("change");
				calculatorRow.find("select[name=genericStopMilestone]").val(calculatorDataInContext.ToMilestoneUiId).trigger("change");
				calculatorRow.find("input[name=genericStartMilestoneDate]").val(calculatorDataInContext.FromMilestoneDate);
				calculatorRow.find("input[name=genericStopMilestoneDate]").val(calculatorDataInContext.ToMilestoneDate);
			}

			setTimeout(function () {
				for (var index = 0; index < dataToCopy.GenericInitiateCalculatorPhaseDate.length; index++) {
					var calculatorRow = localParentRow.find("tr.genericRow:eq(" + index + ")");
					calculatorRow.find("input[name=genericStartMilestoneDate]").trigger("change");
					calculatorRow.find("input[name=genericStopMilestoneDate]").trigger("change");
				}
			}, 20);
		}
	},
	getQipRegionalCalculatorData: function () { return this.getPhaseCalculatorData(); },
	getPhaseCalculatorData: function () {
		var calculatorValues = new Array();
		$.each(this.parentRow.find(initMultiReq.phaseRowSelector), function (inex, row) {
			var phaseRow = $(row);
			calculatorValues.push({
				FTETypeFTEMilestoneTypeId: phaseRow.attr(initMultiReq.attrFteTypeFteMilestoneTypeId),
				Status: (phaseRow.find("img.imgConnected").length == 0) ? 0 : 1,
				WeeklyHours: phaseRow.find(initMultiReq.classHoursSelector).val(),
				FTE: phaseRow.find(initMultiReq.classFteSelector).val()
			});
		});
		return calculatorValues;
	},
	renderGenericCalculator: function () {
		var pageManager = this;
		this.milestoneList = rm.serviceCalls.getAllMilestonesByProjectId(initMultiReq.getSelectedProjectIdFromRow(this.parentRow), initMultiReq.getSelectedCountryIdFromRow(this.parentRow), 0, true, initMultiReq.getSelectedOrganizationIdFromRow(this.parentRow), this.resourceTypeDetails.Id);

		var calculatorLayout = $(initMultiReq.tblGenericCalculatorLayoutSelector).clone().attr("id", null).removeClass(initMultiReq.classHideMe);
		var calculatorCell = this.parentRow.find(initMultiReq.calculatorCellSelector).html("").append(calculatorLayout);
		if (this.resourceTypeDetails.GenericDefaultMilestoneList && this.resourceTypeDetails.GenericDefaultMilestoneList.length > 0) {
			for (var index = 0; index < this.resourceTypeDetails.GenericDefaultMilestoneList.length; index++) {
				this.addNewGenericRow(this.resourceTypeDetails.GenericDefaultMilestoneList[index], this.milestoneList[0].Utilization, this.milestoneList[0].WeeklyHours);
			}
		}
		else { this.addNewGenericRow(); }

		calculatorLayout.find(initMultiReq.addGenericRowButtonSelector).click(function () {
			if (pageManager.isGenericCalculatorValid.call(pageManager)) { pageManager.addNewGenericRow.call(pageManager); }
		});
	},
	getMilestoneDetailsByMilestoneId: function (milestoneId) {
		var milestoneDetails = null;
		$.each(this.milestoneList, function (index, milestone) {
			if (milestone.ProjectMilestoneId == milestoneId) {
				milestoneDetails = milestone;
				return false;
			}
		});
		return milestoneDetails;
	},
	addNewGenericRow: function (defaultMilestoneDetails, utilization, weeklyWorks) {
		var pageManager = this;
		var genericRow = $(initMultiReq.tblGenericCalculatorTemplateRowSelector + " tr").clone().attr("id", null).removeClass(initMultiReq.classHideMe);//get template row
		genericRow.find(".stageIdCell").text(this.parentRow.find(initMultiReq.genericRowSelector).length + 1);//display stage number
		genericRow.find(initMultiReq.deleteGenericRowImageSelector).click(function () { pageManager.removeGenericRow.call(pageManager, this); });//attach click handler to delete image

		var lastGenericRow = this.parentRow.find(initMultiReq.genericRowSelector).last();//find out last generic row in the calculator

		var previousStopMilestoneValue = lastGenericRow.find(initMultiReq.genericStopMilestoneSelector).val();//find out stop milestone from last row
		var stopDateCtrl = lastGenericRow.find(initMultiReq.genericStopMilestoneDateSelector);//find out stop milestone date control from previous row
		var stopDate = stopDateCtrl.val();//get stop milestone date from previous row

		var genericStartMilestoneDropdown = genericRow.find(initMultiReq.genericStartMilestoneSelector);//find out start milestone from new row
		var genericStartMilestoneDate = genericRow.find(initMultiReq.genericStartMilestoneDateSelector).qDatepicker();//find out start milestone date from new row
		var genericStopMilestoneDropdown = genericRow.find(initMultiReq.genericStopMilestoneSelector);//find out stop milestone from new row
		var genericStopMilestoneDate = genericRow.find(initMultiReq.genericStopMilestoneDateSelector).qDatepicker();//find out stop milestone date from new row
		var hoursControl = genericRow.find(initMultiReq.classHoursSelector);
		var fteControl = genericRow.find(initMultiReq.classFteSelector);

		if (rm.date.isValidDate(stopDate, false)) {
			genericStartMilestoneDate.val(rm.date.addDaysToQdate(stopDate, 1)).data(initMultiReq.attrMilestoneData, stopDateCtrl.data(initMultiReq.attrMilestoneData));
		}

		rm.dropdown.fill(genericStartMilestoneDropdown, this.milestoneList, "Id", "MilestoneName", previousStopMilestoneValue, true);//fill start milestone dropdown
		rm.dropdown.fill(genericStopMilestoneDropdown, this.milestoneList, "Id", "MilestoneName", -1, true);//fill stop milestone dropdown

		hoursControl.change(function () { initMultiReq.handleGenericFteHoursChange(pageManager.parentRow, $(this), initMultiReq.calculateFte); }).bind("keyup", function () { initMultiReq.markControlAsUpdated(pageManager.parentRow, $(this)); });
		fteControl.change(function () { initMultiReq.handleGenericFteHoursChange(pageManager.parentRow, $(this), initMultiReq.calculateHours); }).bind("keyup", function () { initMultiReq.markControlAsUpdated(pageManager.parentRow, $(this)); });
		genericStartMilestoneDropdown.change(function () { pageManager.handleGenericStartMilestoneChange.call(pageManager, $(this)); });
		genericStartMilestoneDate.change(function () { pageManager.handleGenericStartMilestoneDateChange.call(pageManager, $(this)); });
		genericStopMilestoneDropdown.change(function () { pageManager.handleGenericStopMilestoneChange.call(pageManager, $(this)); });
		genericStopMilestoneDate.change(function () { pageManager.handleGenericStopMilestoneDateChange.call(pageManager, $(this)); });

		//Set default milestones for the first row if this is the first row that is being added
		if (defaultMilestoneDetails) {
			if (defaultMilestoneDetails.DefaultFromMilestoneId != null) {
				var milestoneDetails = this.getMilestoneDetailsByMilestoneId(defaultMilestoneDetails.DefaultFromMilestoneId);
				if (milestoneDetails) { genericStartMilestoneDropdown.val(milestoneDetails.Id); }
			}
			if (defaultMilestoneDetails.DefaultToMilestoneId != null) {
				var milestoneDetails = this.getMilestoneDetailsByMilestoneId(defaultMilestoneDetails.DefaultToMilestoneId);
				if (milestoneDetails) { genericStopMilestoneDropdown.val(milestoneDetails.Id); }
			}
			if (defaultMilestoneDetails.DefaultFTE != null) {
				hoursControl.val(parseFloat((weeklyWorks * (utilization / 100) * defaultMilestoneDetails.DefaultFTE).toFixed(2)));
				fteControl.val(defaultMilestoneDetails.DefaultFTE);
			}
		}
		//Disable start milestone controls for subsequentgeneric rows
		if (lastGenericRow.length > 0) {
			genericStartMilestoneDropdown.attr("disabled", "disabled");
			genericStartMilestoneDate.attr("disabled", "disabled");
		}

		this.parentRow.find(initMultiReq.calculatorCellSelector).find("tr[addnewrow=1]").before(genericRow);//add generic row to UI

		//Set default milestones for the first row if this is the first row that is being added
		if (defaultMilestoneDetails) {
			setTimeout(function () {
				if (lastGenericRow.length == 0) {
					pageManager.handleGenericStartMilestoneChange.call(pageManager, genericStartMilestoneDropdown);
				}
				pageManager.handleGenericStopMilestoneChange.call(pageManager, genericStopMilestoneDropdown);
			}, 10);
		}
	},
	isFirstGenericRow: function (genericRow) { return genericRow.find(initMultiReq.stageIdCellSelector).text() == "1"; },
	isLastGenericRow: function (genericRow) { return genericRow.find(initMultiReq.stageIdCellSelector).text() == genericRow.closest("table").find(initMultiReq.genericRowSelector).last().find(initMultiReq.stageIdCellSelector).text(); },
	updateRequestDateInUi: function (genericRow, sourceDateSelector, targetDateSelector) {
		var updatedDate = genericRow.find(sourceDateSelector).val();
		if (rm.date.isValidDate(updatedDate, false)) {
			var targetJqCtrl = this.parentRow.find(targetDateSelector).val(updatedDate);
			if (targetJqCtrl.attr(initMultiReq.attrIsStartDate) == "1") {
				var pageManager = this;
				setTimeout(function () { pageManager.calculateNeedByDate.call(pageManager); }, 10);
			}
		}
	},
	updateNextGenericStageDateInUi: function (genericRow, sourceDateSelector, targetDateSelector) {
		var sourceDateCtrl = genericRow.find(sourceDateSelector);
		var updatedDate = sourceDateCtrl.val();
		if (rm.date.isValidDate(updatedDate, false)) {
			genericRow.next(initMultiReq.genericRowSelector).find(targetDateSelector).val(rm.date.addDaysToQdate(updatedDate, 1)).data(initMultiReq.attrMilestoneData, sourceDateCtrl.data(initMultiReq.attrMilestoneData));
		}
	},
	updateNextGenericStageStatMilestoneInUi: function (genericRow, stopMilestoneDdlJqCtrl) {
		genericRow.next(initMultiReq.genericRowSelector).find(initMultiReq.genericStartMilestoneSelector).val(stopMilestoneDdlJqCtrl.val());
	},
	getMilestoneDetailsFromSelectedMilestone: function (milestoneDdlJqCtrl) {
		var selectedMilestoneId = milestoneDdlJqCtrl.val();
		var milestoneDetails;
		$.each(this.milestoneList, function (index, milestone) {
			if (milestone.Id == selectedMilestoneId) {
				milestoneDetails = milestone;
				return false;
			}
		});
		return milestoneDetails;
	},
	showGenericRowDateConnectDisconnectIcon: function (dateJqControl) {
		var pageManager = this;
		var milestoneDetails = dateJqControl.data(initMultiReq.attrMilestoneData);
		var imageConfig = null;
		if (milestoneDetails) {
			if (milestoneDetails.MilestoneType == "P") { imageConfig = this.connectDisconnectConfigPpm; }
			else if (milestoneDetails.MilestoneType == "C" || milestoneDetails.MilestoneType == "S" || milestoneDetails.MilestoneType == "O") { imageConfig = this.connectDisconnectConfigCountry; }

			dateJqControl.closest("div").find(this.connectDisconnectConfigPpm.getImageSelectorsForRemoval() + "," + this.connectDisconnectConfigCountry.getImageSelectorsForRemoval()).remove();

			if (imageConfig != null) {
				var isConnected = milestoneDetails.ConnectedDate == dateJqControl.val();
				var image = $("<img>", {
					"class": isConnected ? imageConfig.classConnected : imageConfig.classDisconnected,
					src: isConnected ? imageConfig.imageConnected : imageConfig.imageDisconnected,
					style: "cursor:pointer;"
				});

				if (!isConnected) {
					image.click(function () {
						imageConfig.connectGenericDate(this, pageManager);
						dateJqControl.change();
						if (dateJqControl.attr(initMultiReq.attrIsStartDate) == "1") {
							setTimeout(function () { pageManager.calculateNeedByDate.apply(pageManager); }, 50);
						}
					});
				}
				dateJqControl.closest("div").append(image);
				pageManager.ShowConnectDisconnectPPMIcon(pageManager);
			}
		}
	},
	handleGenericStartMilestoneChange: function (startMilestoneDdlJqCtrl) {
		var pageManager = this;
		var genericRow = startMilestoneDdlJqCtrl.closest("tr");
		var milestoneDetails = this.getMilestoneDetailsFromSelectedMilestone(startMilestoneDdlJqCtrl);
		var genericStartMilestoneDateCtrl = genericRow.find(initMultiReq.genericStartMilestoneDateSelector)
		if (milestoneDetails) {
			genericStartMilestoneDateCtrl.val(milestoneDetails.MilestoneDate).data(initMultiReq.attrMilestoneData, milestoneDetails);
		}
		else { genericStartMilestoneDateCtrl.val("").data(initMultiReq.attrMilestoneData, null); }
		this.showGenericRowDateConnectDisconnectIcon(genericStartMilestoneDateCtrl);

		if (this.isFirstGenericRow(genericRow)) {
			setTimeout(function () {
				pageManager.updateRequestDateInUi.call(pageManager, genericRow, initMultiReq.genericStartMilestoneDateSelector, initMultiReq.txtStartDateSelector);
			}, 10);
		}
	},
	handleGenericStopMilestoneChange: function (stopMilestoneDdlJqCtrl) {
		var pageManager = this;
		var genericRow = stopMilestoneDdlJqCtrl.closest("tr");
		var milestoneDetails = this.getMilestoneDetailsFromSelectedMilestone(stopMilestoneDdlJqCtrl);
		var genericStopMilestoneDateCtrl = genericRow.find(initMultiReq.genericStopMilestoneDateSelector);
		if (milestoneDetails) {
			genericStopMilestoneDateCtrl.val(milestoneDetails.MilestoneDate).data(initMultiReq.attrMilestoneData, milestoneDetails);
		}
		else { genericStopMilestoneDateCtrl.val("").data(initMultiReq.attrMilestoneData, null); }
		this.showGenericRowDateConnectDisconnectIcon(genericStopMilestoneDateCtrl);


		setTimeout(function () {
			if (pageManager.isLastGenericRow(genericRow)) {
				pageManager.updateRequestDateInUi.call(pageManager, genericRow, initMultiReq.genericStopMilestoneDateSelector, initMultiReq.txtStopDateSelector);
			}
			pageManager.updateNextGenericStageDateInUi.call(pageManager, genericRow, initMultiReq.genericStopMilestoneDateSelector, initMultiReq.genericStartMilestoneDateSelector);
			pageManager.updateNextGenericStageStatMilestoneInUi.call(pageManager, genericRow, stopMilestoneDdlJqCtrl);
		}, 10);
	},
	handleGenericStartMilestoneDateChange: function (startMilestoneDateJqCtrl) {
		var genericRow = startMilestoneDateJqCtrl.closest("tr");
		this.showGenericRowDateConnectDisconnectIcon(startMilestoneDateJqCtrl);
		if (this.isFirstGenericRow(genericRow)) {
			this.updateRequestDateInUi(genericRow, initMultiReq.genericStartMilestoneDateSelector, initMultiReq.txtStartDateSelector);
		}
	},
	handleGenericStopMilestoneDateChange: function (stopMilestoneDateCtrl) {
		var genericRow = stopMilestoneDateCtrl.closest("tr");
		this.showGenericRowDateConnectDisconnectIcon(stopMilestoneDateCtrl);
		if (this.isLastGenericRow(genericRow)) {
			this.updateRequestDateInUi(genericRow, initMultiReq.genericStopMilestoneDateSelector, initMultiReq.txtStopDateSelector);
		}
		this.updateNextGenericStageDateInUi(genericRow, initMultiReq.genericStopMilestoneDateSelector, initMultiReq.genericStartMilestoneDateSelector);
	},
	removeGenericRow: function (eventTarget) {
		if (this.parentRow.find(initMultiReq.genericRowSelector).length > 1) {
			if (confirm('Are you sure you want to delete this frequency?')) {
				var genericRowToDelete = $(eventTarget).closest("tr");
				previousRow = genericRowToDelete.prev(initMultiReq.genericRowSelector);
				nextRow = genericRowToDelete.next(initMultiReq.genericRowSelector);

				//First row is getting deleted. Update request start date
				if (previousRow.length == 0 && nextRow.length > 0) {
					this.updateRequestDateInUi(nextRow, initMultiReq.genericStartMilestoneDateSelector, initMultiReq.txtStartDateSelector);
				}
				//Last row is getting deleted. Update request stop date
				else if (previousRow.length > 0 && nextRow.length == 0) {
					this.updateRequestDateInUi(previousRow, initMultiReq.genericStopMilestoneDateSelector, initMultiReq.txtStopDateSelector);
				}
				if (previousRow.length > 0) {
					nextRow.find(initMultiReq.genericStartMilestoneSelector).val(previousRow.find(initMultiReq.genericStopMilestoneSelector).val());
					var stopDate = previousRow.find(initMultiReq.genericStopMilestoneDateSelector).val();
					if (rm.date.isValidDate(stopDate, false)) {
						nextRow.find(initMultiReq.genericStartMilestoneDateSelector).val(rm.date.addDaysToQdate(stopDate, 1));
					}
				}

				genericRowToDelete.remove();
				var pageManager = this;
				setTimeout(function () {
					$.each(pageManager.parentRow.find(initMultiReq.genericRowSelector + " " + initMultiReq.stageIdCellSelector), function (index, stageIdCell) {
						if (index == 0) {
							$(stageIdCell).closest("tr").find(initMultiReq.genericStartMilestoneSelector).removeAttr("disabled");
							$(stageIdCell).closest("tr").find(initMultiReq.genericStartMilestoneDateSelector).removeAttr("disabled");
						}
						$(stageIdCell).text(index + 1)
					});
				}, 10);
			}
		}
		else {
			alert("Stage cannot be deleted.");
		}
	},
	getGenericCalculatorData: function () {
		var calculatorData = {
			calculatorValues: new Array(),
			calculatorTimestamps: new Array()
		};

		$.each(this.parentRow.find(initMultiReq.genericRowSelector), function (inex, row) {
			var genericRow = $(row);
			var startMilestoneDetails = genericRow.find(initMultiReq.genericStartMilestoneDateSelector).data(initMultiReq.attrMilestoneData);
			var stopMilestoneDetails = genericRow.find(initMultiReq.genericStopMilestoneDateSelector).data(initMultiReq.attrMilestoneData);
			var connectedImageSelector = "img.connectedToCountry,img.connectedToPpm";
			calculatorData.calculatorValues.push({
				Id: 0, //Always 0 for new requests
				DMLOperation: DMLOperation_E.Insert, //Always insert for new calculators
				FTE: genericRow.find(initMultiReq.classFteSelector).val(),
				WeeklyHours: genericRow.find(initMultiReq.classHoursSelector).val(),
				FromMilestoneConnected: (genericRow.find(initMultiReq.startMilestoneCellSelector).find(connectedImageSelector).length == 0) ? 0 : 1,
				FromMilestoneDate: genericRow.find(initMultiReq.genericStartMilestoneDateSelector).val(),
				FromMilestoneId: ((startMilestoneDetails == null) ? null : startMilestoneDetails.ProjectMilestoneId),
				FromMilestoneType: ((startMilestoneDetails == null) ? null : startMilestoneDetails.MilestoneType),
				ToMilestoneConnected: (genericRow.find(initMultiReq.stopMilestoneCellSelector).find(connectedImageSelector).length == 0) ? 0 : 1,
				ToMilestoneDate: genericRow.find(initMultiReq.genericStopMilestoneDateSelector).val(),
				ToMilestoneId: ((stopMilestoneDetails == null) ? null : stopMilestoneDetails.ProjectMilestoneId),
				ToMilestoneType: ((stopMilestoneDetails == null) ? null : stopMilestoneDetails.MilestoneType),
				FromMilestoneUiId: genericRow.find(initMultiReq.genericStartMilestoneSelector).val(),
				ToMilestoneUiId: genericRow.find(initMultiReq.genericStopMilestoneSelector).val(),
			});

			calculatorData.calculatorTimestamps.push({
				RequestCalculatorId: 0, //Always 0 for new requests
				RequestCalculatorTimestamp: null, //Always null for new requests
				FromMilestoneId: ((startMilestoneDetails == null) ? null : startMilestoneDetails.ProjectMilestoneId),
				FromMilestoneTimestamp: ((startMilestoneDetails == null) ? null : startMilestoneDetails.MilestoneLastModifiedOn),
				FromMilestoneType: ((startMilestoneDetails == null) ? null : startMilestoneDetails.MilestoneType),
				ToMilestoneId: ((stopMilestoneDetails == null) ? null : stopMilestoneDetails.ProjectMilestoneId),
				ToMilestoneTimestamp: ((stopMilestoneDetails == null) ? null : stopMilestoneDetails.MilestoneLastModifiedOn),
				ToMilestoneType: ((stopMilestoneDetails == null) ? null : stopMilestoneDetails.MilestoneType),
			});
		});
		return calculatorData;
	},
	getFlatFteCalculatorData: function () { return { FTE: this.parentRow.find(".flatFteCalculatorContainer " + initMultiReq.classFteSelector).val(), TotalHours: this.parentRow.find(".flatFteCalculatorContainer " + initMultiReq.classHoursSelector).val() }; },
	getFlatFteNoTotalHoursCalculatorData: function () { return { FTE: this.parentRow.find(".flatFteCalculatorContainer " + initMultiReq.classFteSelector).val(), TotalHours: null }; },
	calculateNeedByDate: function () {
		var txtNeedByDate = this.parentRow.find(initMultiReq.txtNeedByDateSelector);
		var txtStartDate = this.parentRow.find(initMultiReq.txtStartDateSelector);
		var startDateValue = txtStartDate.val();
		if (txtNeedByDate.is(":visible")) {
			if (rm.date.isValidDate(startDateValue, false)) { txtNeedByDate.val(rm.bizRules.getNeedByDate(startDateValue, this.resourceTypeDetails.ResourceTransitionTimeInDays)); }
			else { txtNeedByDate.val("Not Available"); }
		}
	},
	getConnectedDateByMilestoneType: function (isStartDate, milestoneId, countryId, regionId) {
		var connectedMilestoneType = isStartDate ? this.resourceTypeDetails.RequestStartDateConnectedMilestoneType : this.resourceTypeDetails.RequestStopDateConnectedMilestoneType;
		var connectedDate = "";
		if (this.resourceTypeDetails.IsRegionBased) {
			var regionConnectedMilestones = initMultiReq.getRegionConnectedMilestones(this.resourceTypeDetails.Id, this.projectDetails.Id, regionId);
			connectedDate = isStartDate ? regionConnectedMilestones.startDate : regionConnectedMilestones.stopDate;
		}
		else if (connectedMilestoneType == RequestMilestoneType_E.Project) {
			$.each(this.projectDetails.Milestones, function (index, kvp) {
				if (kvp.key == milestoneId) {
					connectedDate = kvp.value;
					return false;
				}
			});
		}
		else if (connectedMilestoneType == RequestMilestoneType_E.Monitoring ||
			connectedMilestoneType == RequestMilestoneType_E.Ssv) {
			$.each(this.projectDetails.CountryMilestones, function (index, countryMilestone) {
				if (countryMilestone.CountryId == countryId && countryMilestone.MilestoneId == milestoneId) {
					connectedDate = countryMilestone.MilestoneDate;
					return false;
				}
			});
		}

		return connectedDate;
	},
	handleBlindedColumnVisibility: function () {
		if (this.resourceTypeDetails.DisplayBlindedField && !initMultiReq.getIsProposalProjetSelectedFromRow(this.parentRow) && !initMultiReq.getProjectDetailsFromRow(this.parentRow).IsOpenLabel) {
			this.parentRow.find(initMultiReq.ddlRequestBlindedSelector).removeClass(initMultiReq.classHideMe).show();
		} else { this.parentRow.find(initMultiReq.ddlRequestBlindedSelector).hide(); }
	},
	handleCustomFieldColumnVisibility: function () {
		if (this.resourceTypeDetails.HasCustomFields && !initMultiReq.getIsProposalProjetSelectedFromRow(this.parentRow)) {
			initMultiReq.showCustomFields(this.parentRow, this.resourceTypeDetails.Id);
			this.parentRow.find(initMultiReq.classCustomFieldContainerSelector).removeClass(initMultiReq.classHideMe).show();
		} else {
			this.parentRow.find(initMultiReq.classCustomFieldContainerSelector).hide().html("");
		}
	},
	handleNeedByDateVisibility: function () {
		if (this.resourceTypeDetails.ShowNeedByDate) {
			this.parentRow.find(initMultiReq.txtNeedByDateSelector).removeClass(initMultiReq.classHideMe).show();
		} else {
			this.parentRow.find(initMultiReq.txtNeedByDateSelector).hide().html("");
		}
	},
	handleImgSiteCountPopUpVisibility: function () {
		if (this.resourceTypeDetails.ShowSiteCountBySiteStatus) {
			this.parentRow.find(initMultiReq.imgSiteCountPopUpSelector).removeClass(initMultiReq.classHideMe).show();
		} else {
			this.parentRow.find(initMultiReq.imgSiteCountPopUpSelector).hide();
		}
	},


	showDateConnectDisconnectIcons: function (jqElementObj, connectDisconnectConfig) {
		if (initMultiReq.getIsProposalProjetSelectedFromRow(this.parentRow)) {
			jqElementObj.closest("div").find("." + this.connectDisconnectConfigPpm.classDisconnected + ",." + this.connectDisconnectConfigPpm.classConnected + ",." + this.connectDisconnectConfigCountry.classDisconnected + ",." + this.connectDisconnectConfigCountry.classConnected).remove();
		} else {
			var pageManager = this;
			var isConnected = jqElementObj.attr(initMultiReq.attrConnectedDate) == jqElementObj.val();

			jqElementObj.closest("div").find("." + connectDisconnectConfig.classDisconnected + ",." + connectDisconnectConfig.classConnected).remove();
			var image = $("<img>", {
				"class": "connectDisconnectImage " + (isConnected ? connectDisconnectConfig.classConnected : connectDisconnectConfig.classDisconnected),
				src: isConnected ? connectDisconnectConfig.imageConnected : connectDisconnectConfig.imageDisconnected,
				style: "cursor:pointer;"
			});
			if (!isConnected) {
				image.click(function () {
					connectDisconnectConfig.connectDate(this, pageManager);
					if (jqElementObj.attr(initMultiReq.attrIsStartDate)) {
						setTimeout(function () { pageManager.calculateNeedByDate.apply(pageManager); }, 50);
					}
				});
			}
			jqElementObj.closest("div").append(image);
			pageManager.ShowConnectDisconnectPPMIcon(pageManager);

			jqElementObj.unbind("keyup").unbind("change").bind("keyup change", function () {
				setTimeout(function () {
					if (jqElementObj.attr(initMultiReq.attrConnectedDate) != jqElementObj.val()) {
						pageManager.showDateConnectDisconnectIcons(jqElementObj, connectDisconnectConfig);
						if (jqElementObj[0].name == 'txtStartDate')
							pageManager.updateRequestStopDateComputedRequestMilestone(initMultiReq.getSelectedResourceTypeIdFromRow(pageManager.parentRow), 0);
					}
				}, 10);
			});

			if (jqElementObj.attr(initMultiReq.attrIsStartDate)) {
				setTimeout(function () { pageManager.calculateNeedByDate.apply(pageManager); }, 10);
			}
		}
	},
	showDateConnectDisconnectIconsPpm: function (jqElementObj) { this.showDateConnectDisconnectIcons(jqElementObj, this.connectDisconnectConfigPpm); },
	showDateConnectDisconnectIconsCountry: function (jqElementObj) { this.showDateConnectDisconnectIcons(jqElementObj, this.connectDisconnectConfigCountry); },
	populateAssignedRegionMultiSelect: function (assignedRegionCountries) {
		initMultiReq.bindAssignedRegionMultiSelect(this.parentRow, assignedRegionCountries, (initMultiReq.assignedRegionContainerIdPrefix + this.parentRow.attr(initMultiReq.attrRowIdentity)));
	},
	initDateConnectDisconnect: function () {
		if (!initMultiReq.getIsProposalProjetSelectedFromRow(this.parentRow)) {
			var startDateObj = this.parentRow.find(initMultiReq.txtStartDateSelector);
			var stopDateObj = this.parentRow.find(initMultiReq.txtStopDateSelector);
			var countryId = initMultiReq.getSelectedCountryIdFromRow(this.parentRow);
			var regionId = initMultiReq.getSelectedRegionIdFromRow(this.parentRow);

			this.connectedQStartDate = this.getConnectedDateByMilestoneType(true, this.resourceTypeDetails.RequestStartDateConnectedMilestoneId, countryId, regionId);
			this.connectedQStopDate = this.getConnectedDateByMilestoneType(false, this.resourceTypeDetails.RequestStopDateConnectedMilestoneId, countryId, regionId);
			this.connectedStartDate = rm.date.getDateFromQDateString(this.connectedQStartDate);
			this.connectedStopDate = rm.date.getDateFromQDateString(this.connectedQStopDate);

			if (this.resourceTypeDetails.RequestStartDateConnectedMilestoneType == null) {
				startDateObj.closest("div").find(".connectDisconnectImage").remove();
			}
			if (this.resourceTypeDetails.RequestStopDateConnectedMilestoneType == null) {
				stopDateObj.closest("div").find(".connectDisconnectImage").remove();
			}
			if (this.resourceTypeDetails.RequestStartDateConnectedMilestoneType != null || this.resourceTypeDetails.RequestStopDateConnectedMilestoneType != null) {
				startDateObj.attr(initMultiReq.attrConnectedDate, this.connectedQStartDate).val((this.connectedStartDate >= rm.date.today()) ? this.connectedQStartDate : rm.date.getTodayAsQDateString());
				stopDateObj.attr(initMultiReq.attrConnectedDate, this.connectedQStopDate).val(this.connectedQStopDate);

				if (this.resourceTypeDetails.RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Project) {
					this.showDateConnectDisconnectIconsPpm(startDateObj);
				}
				else if (this.resourceTypeDetails.RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Monitoring ||
					this.resourceTypeDetails.RequestStartDateConnectedMilestoneType == RequestMilestoneType_E.Ssv) {
					this.showDateConnectDisconnectIconsCountry(startDateObj);
				}

				if (this.resourceTypeDetails.RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Project) {
					this.showDateConnectDisconnectIconsPpm(stopDateObj);
				}
				else if (this.resourceTypeDetails.RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Monitoring ||
					this.resourceTypeDetails.RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Ssv) {
					this.showDateConnectDisconnectIconsCountry(stopDateObj);
				}
				this.updateRequestStopDateComputedRequestMilestone(initMultiReq.getSelectedResourceTypeIdFromRow(this.parentRow), 0);
			}
		}
	},
	updateRequestStopDateComputedRequestMilestone: function (resourceTypeId, regionId) {
		var pageManager = this;
		if (pageManager.resourceTypeDetails.RequestStopDateConnectedMilestoneType == RequestMilestoneType_E.Request) {
			var milestoneList = initMultiReq.getComputedReqestMilestoneDaysToAdd();
			$.each(milestoneList, function (index, item) {
				if ((pageManager.resourceTypeDetails.IsRegionBased && item.ResourceTypeId == resourceTypeId && item.RegionId == regionId) ||
					(!pageManager.resourceTypeDetails.IsRegionBased && item.ResourceTypeId == resourceTypeId)) {
					rm.validation.clearError(pageManager.parentRow.find(initMultiReq.txtStopDateSelector));
					pageManager.parentRow.find(initMultiReq.txtStopDateSelector).val(rm.date.addDaysToQdate(pageManager.parentRow.find(initMultiReq.txtStartDateSelector).val(), item.DaysToAdd));
					return false;
				}
			});
		}
	},
	ShowConnectDisconnectPPMIcon: function (pageManager) {
		var startDateObj = pageManager.parentRow.find(initMultiReq.txtStartDateSelector);
		var stopDateObj = pageManager.parentRow.find(initMultiReq.txtStopDateSelector);
		if (!pageManager.resourceTypeDetails.ShowStartDateConnectDisconnectIcon) { startDateObj.closest("div").find(".connectDisconnectImage").remove(); }
		if (!pageManager.resourceTypeDetails.ShowStopDateConnectDisconnectIcon) { stopDateObj.closest("div").find(".connectDisconnectImage").remove(); }
	},
	isValidProjectSelected: function () {
		return initMultiReq.isValidProjectSelected(this.parentRow);
	},
	isValidResourceSelected: function () {
		var isValid = true;
		var jqResourceObj = this.parentRow.find(initMultiReq.txtResourceNameSelector);

		if (jqResourceObj.val() != "") {
			//Check if Resource from the text box is a valid Resource.
			var resourceFromTextBox = initMultiReq.getResoruceFromLookupArray(this.parentRow, initMultiReq.getSelectedResourceTypeIdFromRow(this.parentRow), jqResourceObj.val());
			var resourceFromRow = initMultiReq.getSelectedResourceFromRow(this.parentRow);
			if (resourceFromTextBox == null) {
				isValid = false;
				rm.validation.addError(jqResourceObj, "Invalid Resource selected. Please select a Resource from the lookup list.");
			}
			else {
				initMultiReq.handleResourceChange(resourceFromTextBox, this.parentRow);
			}
			//	//Check if Resource from the text box is same as Resource associated with the row.
			//else if (resourceFromRow != null && resourceFromRow.id != resourceFromTextBox.id) {
			//	isValid = false;
			//	rm.validation.addError(jqResourceObj, "Resource has been changed after valid selection. To prevent this error from occuring, always change the Resource by selecting a Reosurce from Resource lookup list.");
			//}
		}

		if (isValid) {
			rm.validation.clearError(jqResourceObj);
		}
		return isValid;
	},
	isValidOrganizationSelected: function () { return initMultiReq.isValidOrganizationSelected(this.parentRow); },
	isValidResourceTypeSelected: function () { return initMultiReq.isValidResourceTypeSelected(this.parentRow); },
	isValidAssignedRegionSelected: function () {
		var regionContainerSelector = "#" + initMultiReq.getAssignedRegionContainIdFromRow(this.parentRow);
		var isValid = true;
		if ($(regionContainerSelector).is(":visible")) {
			var selectedRegions = initMultiReq.getSelectedAssignedRegionsFromRow(this.parentRow);
			isValid = selectedRegions && selectedRegions.length > 0;

			if (isValid) { rm.validation.clearError($(regionContainerSelector)); }
			else { rm.validation.addError($(regionContainerSelector), "Please select Assigned Region"); }
		}

		return isValid;
	},
	isValidAssignedCountrySelected: function () {
		var countryContainerSelector = "#" + initMultiReq.getAssignedCountryContainIdFromRow(this.parentRow);
		var isValid = true;
		if ($(countryContainerSelector).is(":visible")) {
			var selectedCountries = initMultiReq.getSelectedAssignedCountriesFromRow(this.parentRow);
			isValid = selectedCountries && selectedCountries.length > 0;

			if (isValid) { rm.validation.clearError($(countryContainerSelector)); }
			else { rm.validation.addError($(countryContainerSelector), "Please select Assigned Countries"); }

		}
		return isValid;
	},
	isValidRegionSelected: function () {
		var jqRegionDdl = this.parentRow.find(initMultiReq.ddlRegionSelector);
		var isValid = !jqRegionDdl.is(":visible") || (jqRegionDdl.is(":visible") && initMultiReq.getSelectedRegionIdFromRow(this.parentRow) != "-1");

		if (isValid) { rm.validation.clearError(jqRegionDdl); }
		else { rm.validation.addError(jqRegionDdl, "Please select Region"); }

		return isValid;
	},
	isValidCountryRegionSelected: function () {
		if (!(this.parentRow.find((initMultiReq.ddlCountryRegionSelector)).is(":visible"))) {
			rm.validation.clearError(jqCountryRegionDdl);
			return true;
		}
		isValid = initMultiReq.getSelectedCountryRegionFromRow(this.parentRow) != "-1";
		var jqCountryRegionDdl = this.parentRow.find(initMultiReq.ddlCountryRegionSelector);
		if (isValid) { rm.validation.clearError(jqCountryRegionDdl); }
		else { rm.validation.addError(jqCountryRegionDdl, Resources.CountryRegionRequired); }

		return isValid;
	},
	isValidCountrySelected: function () {
		var isValid = initMultiReq.getSelectedCountryIdFromRow(this.parentRow) != "-1";

		var jqCountryDdl = this.parentRow.find(initMultiReq.ddlCountrySelector);
		if (isValid) { rm.validation.clearError(jqCountryDdl); }
		else { rm.validation.addError(jqCountryDdl, Resources.CountryRequired); }

		return isValid;
	},
	isTotalSitesValid: function () { return rm.validation.range.validate(this.parentRow.find(initMultiReq.txtTotalSitesSelector)); },
	isValidRequestStartDateSelected: function () {
		return this.isStartDateControlValid(this.parentRow.find(initMultiReq.txtStartDateSelector));
	},
	isValidRequestStopDateSelected: function () {
		return this.isStopDateControlValid(this.parentRow.find(initMultiReq.txtStopDateSelector));
	},
	isRequestStartDateLessThanOrEqualToStopDate: function () {
		return this.isStartDateLessThanOrEqualToStopDate(this.parentRow.find(initMultiReq.txtStartDateSelector), this.parentRow.find(initMultiReq.txtStopDateSelector));
	},
	isValidRequestBudgetedSelected: function () {
		var isValid = true;

		var jqRequestBudgetedDdl = this.parentRow.find(initMultiReq.ddlRequestBudgetedSelector);
		if (jqRequestBudgetedDdl.is(":visible")) {
			isValid = initMultiReq.getSelectedRequestBudgetedValueFromRow(this.parentRow) != "-1";
		}
		if (isValid) { rm.validation.clearError(jqRequestBudgetedDdl); }
		else { rm.validation.addError(jqRequestBudgetedDdl, Resources.RequestBudgetedRequired); }

		return isValid;
	},
	isValidRequestNotBudgetedReasonEntered: function () {
		var jqRequestNotBudgetedreasonControl = this.parentRow.find(initMultiReq.txtReasonSelector);
		var reasonValue = initMultiReq.getSelectedRequestNotBudgetedReasonFromRow(this.parentRow);
		var isReasonRequired = jqRequestNotBudgetedreasonControl.is(":visible");
		var isValid = true;

		if (!isReasonRequired) {
			rm.validation.clearError(jqRequestNotBudgetedreasonControl);
		}
		else {
			var maxAllowedLength = jqRequestNotBudgetedreasonControl.attr(initMultiReq.attrMaxLength);
			if (reasonValue.length == 0) {
				isValid = false;
				rm.validation.addError(jqRequestNotBudgetedreasonControl, Resources.ReasonRequired);
			}
			else if (reasonValue.length > maxAllowedLength) {
				isValid = false;
				rm.validation.addError(jqRequestNotBudgetedreasonControl, "Reason length " + reasonValue.length + " is more than max allowed length of " + maxAllowedLength + " characters.");
			}
			else { rm.validation.clearError(jqRequestNotBudgetedreasonControl); }
		}

		return isValid;
	},
	isValidRequestBlindedSelected: function () {
		var isValid = true;

		if (this.resourceTypeDetails.DisplayBlindedField && this.parentRow.find((initMultiReq.ddlRequestBlindedSelector)).is(":visible")) {
			isValid = initMultiReq.getSelectedRequestBlindedValueFromRow(this.parentRow) != "-1";

			var jqRequestBlindedDdl = this.parentRow.find(initMultiReq.ddlRequestBlindedSelector);
			if (isValid) { rm.validation.clearError(jqRequestBlindedDdl); }
			else { rm.validation.addError(jqRequestBlindedDdl, Resources.RequestBlindedRequired); }
		}

		return isValid;
	},
	isValidFteHoursEntered: function () {
		var isValid = true;
		$.each(this.parentRow.find(initMultiReq.classHoursSelector + ":visible," + initMultiReq.classFteSelector + ":visible"), function (index, element) {
			isValid = rm.validation.range.validate($(element)) && isValid;
		});
		return isValid && (this.parentRow.find(initMultiReq.classHoursSelector + "." + rm.validation.errorClass + ":visible," + initMultiReq.classFteSelector + "." + rm.validation.errorClass + ":visible").length == 0);
	},
	areCustomFieldsValid: function () {
		return rm.customFields.areCustomFieldsValid(this.parentRow.find(initMultiReq.classCustomFieldContainerSelector));
	},
	isValidValueSelectedFromDropdown: function (ddlJqCtrl, errorMessage) {
		var isValid = ddlJqCtrl.val() != "-1";
		if (isValid) { rm.validation.clearError(ddlJqCtrl); }
		else { rm.validation.addError(ddlJqCtrl, errorMessage); }
		return isValid;
	},
	isStartDateControlValid: function (jqStartDateCtrl) {
		var isValid = true;
		var dateToValidate = jqStartDateCtrl.val();
		if (dateToValidate == "") {
			rm.validation.addError(jqStartDateCtrl, Resources.StartDateIsBlank);
			isValid = false;
		}
		else if (!rm.date.isValidDate(dateToValidate, false)) {
			rm.validation.addError(jqStartDateCtrl, Resources.InvalidDateFormat);
		}
		else if (rm.date.isQDateDateInPast(dateToValidate)) {
			rm.validation.addError(jqStartDateCtrl, Resources.StartDateInPast);
			isValid = false;
		}
		else { rm.validation.clearError(jqStartDateCtrl); }
		return isValid;
	},
	isStopDateControlValid: function (jqStopDateCtrl) {
		var isValid = true;
		var dateToValidate = jqStopDateCtrl.val();

		if (dateToValidate == "") {
			rm.validation.addError(jqStopDateCtrl, Resources.StopDateIsBlank);
			isValid = false;
		}
		else if (!rm.date.isValidDate(dateToValidate, false)) {
			rm.validation.addError(jqStopDateCtrl, Resources.InvalidDateFormat);
			isValid = false;
		}
		else { rm.validation.clearError(jqStopDateCtrl); }
		return isValid;
	},
	isStartDateLessThanOrEqualToStopDate: function (jqStartDateCtrl, jqStopDateCtrl) {
		var isValid = rm.date.isValidDate(jqStartDateCtrl.val(), false) &&
			rm.date.isValidDate(jqStopDateCtrl.val(), false) &&
			rm.date.getDateFromQDateString(jqStartDateCtrl.val()) <= rm.date.getDateFromQDateString(jqStopDateCtrl.val());
		if (isValid) {
			if (!rm.date.isQDateDateInPast(jqStartDateCtrl.val())) { rm.validation.clearError(jqStartDateCtrl); }
			rm.validation.clearError(jqStopDateCtrl);
		}
		else {
			rm.validation.addError(jqStartDateCtrl, Resources.StartDateGreaterThanStopDate);
			rm.validation.addError(jqStopDateCtrl, Resources.StopDateLessThanStartDate);
		}
		return isValid;
	},
	isNotesFieldValid: function () {
		var isValid = true;
		var jqNotesCtrl = this.parentRow.find(initMultiReq.txtNotesSelector);
		var maxAllowedLength = jqNotesCtrl.attr(initMultiReq.attrMaxLength);
		var notesValue = jqNotesCtrl.val();
		if (notesValue.length > maxAllowedLength) {
			isValid = false;
			rm.validation.addError(jqNotesCtrl, "Notes length " + notesValue.length + " is more than max allowed length of " + maxAllowedLength + " characters.");
		}
		else { rm.validation.clearError(jqNotesCtrl); }

		return isValid;
	},
	isPhaseCalculatorValid: function () { return this.isValidFteHoursEntered(); },
	isQipRegionalCalculatorValid: function () { return this.isValidFteHoursEntered(); },
	isGenericCalculatorValid: function () {
		var isValid = true;
		var genericRows = this.parentRow.find(initMultiReq.genericRowSelector);
		for (var index = 0; index < genericRows.length; index++) {
			var genericRow = $(genericRows[index]);
			var genericStartMilestoneDropdown = genericRow.find(initMultiReq.genericStartMilestoneSelector);
			var genericStartMilestoneDate = genericRow.find(initMultiReq.genericStartMilestoneDateSelector);
			var genericStopMilestoneDropdown = genericRow.find(initMultiReq.genericStopMilestoneSelector);
			var genericStopMilestoneDate = genericRow.find(initMultiReq.genericStopMilestoneDateSelector);

			if (!this.isValidValueSelectedFromDropdown(genericStartMilestoneDropdown, "Please select the milestone")) { isValid = false; }
			if (!this.isValidValueSelectedFromDropdown(genericStopMilestoneDropdown, "Please select the milestone")) { isValid = false; }
			var startDateValid = this.isStartDateControlValid(genericStartMilestoneDate);
			var stopDateValid = this.isStopDateControlValid(genericStopMilestoneDate);
			if (!startDateValid) { isValid = false; }
			if (!stopDateValid) { isValid = false; }
			if (startDateValid && stopDateValid && !this.isStartDateLessThanOrEqualToStopDate(genericStartMilestoneDate, genericStopMilestoneDate)) { isValid = false; }
			if (!this.isValidFteHoursEntered()) { isValid = false; }
		}

		return isValid;
	},
	isFlatFteCalculatorValid: function () {
		var isFteControlVisible = this.parentRow.find(initMultiReq.classFteSelector).is(":visible");
		return (!isFteControlVisible || isFteControlVisible && rm.validation.range.validate(this.parentRow.find(initMultiReq.classFteSelector)));
	},
	isValid: function () {
		var isValid = this.isValidProjectSelected();
		isValid = this.isValidOrganizationSelected() && isValid;
		isValid = this.isValidResourceTypeSelected() && isValid;
		isValid = this.isValidRegionSelected() && isValid;
		isValid = this.isValidCountrySelected() && isValid;
		isValid = this.isValidRequestStartDateSelected() && isValid;
		isValid = this.isValidRequestStopDateSelected() && isValid;
		isValid = this.isRequestStartDateLessThanOrEqualToStopDate() && isValid;
		isValid = this.isValidRequestBudgetedSelected() && isValid;
		isValid = this.isValidRequestNotBudgetedReasonEntered() && isValid;
		isValid = this.isValidRequestBlindedSelected() && isValid;
		isValid = this.isValidResourceSelected() && isValid;
		isValid = this.areCustomFieldsValid() && isValid;
		isValid = this.isNotesFieldValid() && isValid;

		return isValid;
	},
	isValidIgnoreCountry: function () {
		var isValid = this.isValidProjectSelected();
		isValid = this.isValidOrganizationSelected() && isValid;
		isValid = this.isValidResourceTypeSelected() && isValid;
		isValid = this.isValidRegionSelected() && isValid;
		isValid = this.isValidRequestStartDateSelected() && isValid;
		isValid = this.isValidRequestStopDateSelected() && isValid;
		isValid = this.isRequestStartDateLessThanOrEqualToStopDate() && isValid;
		isValid = this.isValidRequestBudgetedSelected() && isValid;
		isValid = this.isValidRequestNotBudgetedReasonEntered() && isValid;
		isValid = this.isValidRequestBlindedSelected() && isValid;
		isValid = this.isValidResourceSelected() && isValid;
		isValid = this.areCustomFieldsValid() && isValid;
		isValid = this.isNotesFieldValid() && isValid;

		return isValid;
	},
	isValidIgnoreCountryAndRegion: function () {
		var isValid = this.isValidProjectSelected();
		isValid = this.isValidOrganizationSelected() && isValid;
		isValid = this.isValidResourceTypeSelected() && isValid;
		isValid = this.isValidRequestStartDateSelected() && isValid;
		isValid = this.isValidRequestStopDateSelected() && isValid;
		isValid = this.isRequestStartDateLessThanOrEqualToStopDate() && isValid;
		isValid = this.isValidRequestBudgetedSelected() && isValid;
		isValid = this.isValidRequestNotBudgetedReasonEntered() && isValid;
		isValid = this.isValidRequestBlindedSelected() && isValid;
		isValid = this.isValidResourceSelected() && isValid;
		isValid = this.areCustomFieldsValid() && isValid;
		isValid = this.isNotesFieldValid() && isValid;

		return isValid;
	}
};

//SD:Methods have to be declared first before updating prototype
pageManagerType_9.prototype = basePageManager;
pageManagerType_20.prototype = basePageManager;
pageManagerType_33.prototype = basePageManager;
pageManagerType_34.prototype = basePageManager;
pageManagerType_35.prototype = basePageManager;
pageManagerType_36.prototype = basePageManager;
pageManagerType_37.prototype = basePageManager;
pageManagerType_38.prototype = basePageManager;
pageManagerType_22.prototype = basePageManager;
pageManagerType_26.prototype = basePageManager;
pageManagerType_Generic.prototype = basePageManager;
pageManagerType_41.prototype = basePageManager;
pageManagerType_42.prototype = basePageManager;