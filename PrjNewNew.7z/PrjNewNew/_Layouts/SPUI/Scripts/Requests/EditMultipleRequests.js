﻿var pageManager;
var objPageManager;

$(document).ready(function () {
	rm.utilities.setSelectedNavLinkAndHelpUrl(editRequest.getRmPageLinkId());
	$(editRequest.fteSelector).bind('blur', function () { $.q.formatText(this); rm.ui.ribbon.delayedRefresh(); });

	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });

	editRequest.bindDatePicker();
	editRequest.bindRegionChange();
	editRequest.bindCountryChange();
	editRequest.bindRequestBudgetedChange();
	editRequest.bindMaxLengthOnReason();
	editRequest.bindLabelQtip();
	calculatorGroup.countryWeeklyHours = $(editRequest.countryWeeklyHoursSelector).val();

	editRequest.handleRequestBudgetedChange(true);
	editRequest.bindRequestBlindedChange();
	$('#radioblindedYes').click(function () {
		editRequest.handleRequestBlindedChange(true);
	});
	$('#radioblindedNo').click(function () {
		editRequest.handleRequestBlindedChange(true);
	});
	calculatorHelper.selectedCountryId = editRequest.getCoutryId();
	calculatorHelper.selectedResourceTypeId = editRequest.getResourceTypeId();

	pageManager = editRequest.getPageManager(editRequest.getRequestTypeId(), editRequest.getResourceTypeId());
	pageManager.draw();

	rm.ui.ribbon.delayedRefresh();

	if ($("[id$=hdnIsOpenLabel]").val() == 'True') {
		$(editRequest.requestBlindedMainContainerSelector).addClass(editRequest.hideClass);
	}
	if (editRequest.isDteProject() && !editRequest.hasUserdefinedSchemaForProject() && editRequest.isDteCheckRequiredForResoruceType()) {
		rm.ui.messages.addWarningAsBlock(Resources.UserDefinedSchemaMsgForCalculator);
	}
});

var editRequest = {
	hdnHasUserDefinedSchemaSelector: "[id$=hdnHasUserDefinedSchema]",
	getRequestId: function () { alert("not allowed. refactore the code"); },
	accordionSettings: { collapsible: true },
	getRmPageLinkId: function () { return (1 * $("[id$=RmPageLinkId]").val()); },
	getRequestTypeId: function () { return (1 * $("[id$=RequestTypeId]").val()); },
	getRequestLastModifiedOn: function () { return ($(editRequest.requestLastModifiedOnSelector).val()); },
	getAttributeLastModifiedOn: function () { return ($(editRequest.attributeLastModifiedOnSelector).val() == "0" ? null : $(editRequest.attributeLastModifiedOnSelector).val()); },
	getSiteLastModifiedOn: function () { return ($(editRequest.siteLastModifiedOnSelector).val() == "0" ? null : $(editRequest.siteLastModifiedOnSelector).val()); },
	getAddressLastModifiedOn: function () { return ($(editRequest.addressLastModifiedOnSelector).val() == "0" ? null : $(editRequest.addressLastModifiedOnSelector).val()); },
	getPiLastModifiedOn: function () { return ($(editRequest.piLastModifiedOnSelector).val() == "0" ? null : $(editRequest.piLastModifiedOnSelector).val()); },
	getProjectLastModifiedOn: function () { return ($(editRequest.projectLastModifiedOnSelector).val()); },
	getResourceTypeId: function () { return (1 * $(editRequest.resourceTypeSelector).val()); },
	getRegionId: function () { return (1 * $(editRequest.regionIdSelector).val()); },
	getProjectId: function () { return (1 * $("[id$=ProjectId]").val()); },
	getSiteId: function () { return (1 * $("[id$=HdnSiteId]").val()); },
	getCoutryId: function () { return (1 * $(editRequest.countrySelector).val()); },
	isBackfillRequest: function () { return ($("[id$=IsBackfillRequest]").val() == "1"); },
	isGenericResourceType: function () { return ($("[id$=IsGenericResourceType]").val() == "1"); },
	isPermanentBackfillRequest: function () { return ($("[id$=IsPermanentBackfillRequest]").val() == "1"); },
	isProposalRequest: function () { return ($("[id$=IsProposalRequest]").val() == "1"); },
	isHardBooked: function () { return ($("[id$=IsHardBooked]").val() == "1"); },
	allowFteCalculatorEdits: function () { return true; },
	getStartDateConnectStatus: function () { return $("[id$=StartDateConnectStatus]").val(); },
	getStopDateConnectStatus: function () { return $("[id$=StopDateConnectStatus]").val(); },
	getImDateConnectStatus: function () { return $("[id$=ImDateConnectStatus]").val(); },
	getCraTrainingDateConnectStatus: function () { return $("[id$=CraTrainingDateConnectStatus]").val(); },
	getResourceTransitionTimeinDays: function () { return $("[id$=ResourceTransitionTimeinDays]").val(); },
	getGenericResourceTransitionTimeinDays: function () { return $("[id$=GenericResourceTransitionTimeinDays]").val(); },
	showCountryRegion: function () { return ($("[id$=ShowCountryRegion]").val() == "1"); },
	getTotalHours: function () { return $("[id$=TotalHours]").val(); },
	showOriginalResourceStopDate: function () { return (editRequest.isBackfillRequest() && editRequest.getRmPageLinkId() == RmPageLink_E.BackfillRequests); },
	isUnassignedProposal: function () { return (editRequest.isProposalRequest() && !editRequest.isHardBooked()); },
	isDteProject: function () { return $("[id$=isDteProject]").val() == "1"; },
	hasUserdefinedSchemaForProject: function () { return $(editRequest.hdnHasUserDefinedSchemaSelector).val() == "1"; },
	isDteCheckRequiredForResoruceType: function () { return ResourceTypeDetails[editRequest.getResourceTypeId()].DteCheckRequired; },

	getFteValueOrNull: function () {
		var fte = $.trim($(editRequest.fteSelector).val());
		return fte == "" ? null : fte;
	},
	requestLastModifiedOnSelector: "[id$=RequestLastModifiedOn]",
	attributeLastModifiedOnSelector: "[id$=AttributeLastModifiedOn]",
	projectLastModifiedOnSelector: "[id$=ProjectLastModifiedOn]",
	siteLastModifiedOnSelector: "[id$=SiteLastModifiedOn]",
	addressLastModifiedOnSelector: "[id$=AddressLastModifiedOn]",
	piLastModifiedOnSelector: "[id$=PiLastModifiedOn]",
	resourceTypeSelector: "[id$=ResourceTypeId]",
	regionIdSelector: "[id$=RegionId]",
	countrySelector: "[id$=CountryId]",
	startDateSelector: "[id$=txtStartDate]",
	stopDateSelector: "[id$=txtStopDate]",
	imDateSelector: "[id$=txtIMDate]",
	craTrainingDateSelector: "[id$=txtCRATrainingDate]",
	originalResourceStopDateSelector: "[id$=txtOriginalResourceStopDate]",
	needByDateSelector: "[id$=txtNeedByDate]",
	nextVisitDateSelector: "[id$=txtNextVisitDate]",
	lblSiteStatus: "[id$=lblSiteStatus]",
	radioRequestBudgetedNoChangeSelector: "[id$=radioRequestBudgetedNoChange]",
	radioRequestBudgetedNoSelector: "[id$=radioRequestBudgetedNo]",
	radioRequestBudgetedYesSelector: "[id$=radioRequestBudgetedYes]",
	radioRequestBudgetedSpanNoSelector: "#spanNo",
	radioRequestBudgetedSpanYesSelector: "#spanYes",
	radioRequestBudgetedSpanNoChangeSelector: "spanNoChange",
	radioRequestBlindedNoChangeSelector: "[id$=radioRequestBlindedNoChange]",
	radioRequestBlindedNoSelector: "[id$=radioblindedNo]",
	radioRequestBlindedYesSelector: "[id$=radioblindedYes]",
	fteSelector: "[id$=txtFte]",
	txtReasonSelector: "[id$=txtReason]",
	regionDropdownSelector: "[id$=ddlRegion]",
	countryDropdownSelector: "[id$=ddlCountry]",
	isDirtySelector: "[id$=IsDirty]",
	countryWeeklyHoursSelector: "[id$=CountryWeeklyHours]",
	lblRemainingLengthSelector: "#lblRemainingLength",
	hideClass: "hideMe",
	originalResourceStopDateContainerSelector: "#OriginalResourceStopDateContainer",
	preferredLocationContainerSelector: "#PreferredLocationContainer",
	proposalRegionContainerSelector: "#ProposalRegionContainer",
	proposalCountryContainerSelector: "#ProposalCountryContainer",
	regionContainerSelector: "#RegionContainer",
	countryContainerSelector: "#CountryContainer",
	siteContainerSelector: "#SiteContainer",
	fieldDurationContainerSelector: "#FieldDurationContainer",
	piContainerSelector: "#PIContainer",
	visitTypeContainerSelector: "#VisitTypeContainer",
	craDateContainerSelector: "#CRADateContainer",
	imDateContainerSelector: "#IMDateContainer",
	startDateContainerSelector: "#StartDateContainer",
	stopDateContainerSelector: "#StopDateContainer",
	needByDateContainerSelector: "#NeedByDateContainer",
	fteContainerSelector: "#FteContainer",
	requestBudgetedMainContainerSelector: "#RequestBudgetedMainContainer",
	requestBlindedMainContainerSelector: "#RequestBlindedContainer",
	qipClinicalCalculatorInnerContainer: "#calculatorContainer",
	qipOtherFteCalcContainerSelector: "#QipOtherFteCalcContainer",
	coMonFteCalcContainerSelector: "#CoMonFteCalcContainer",
	qipClinicalFteCalcContainerSelector: "#qipClinicalFteCalcContainer",
	genericFteCalcContainerSelector: "#GenericFTECalculatorContainer",
	siteStatusContainerSelector: "#SiteStatusContainer",
	reasonContainerSelector: "#ReasonContainer",
	SsvTypeContainerSelector: "#SsvTypeContainer",
	requestIdListSelector: "[id$=RequestIdList]",
	resourceTypeNameSelector: "[id$=HdnResourceTypeName]",
	isSaveButtonEnabled: function () { return editRequest.isDirty(); },
	isCancelButtonEnabled: function () { return editRequest.isDirty(); },
	isCloseButtonEnabled: function () { return true; },
	isInterimFrequencyButtonEnabled: function () {
		return editRequest.allowFteCalculatorEdits();
	},
	dateEventsToBind: "keyup change cut paste drop",
	isDateConnected: function (selector) {
		return $(selector).parent().find(".connectedToCountry,.connectedToPpm").length == 1 ? RequestConnect_E.Connected : RequestConnect_E.Disconnected;
	},

	changeRequestBudgeted: function () { return $(editRequest.requestBudgetedMainContainerSelector).is(":visible") && !$(editRequest.radioRequestBudgetedNoChangeSelector).is(":checked"); },
	changeRequestBlinded: function () { return $(editRequest.requestBlindedMainContainerSelector).is(":visible") && !$(editRequest.radioRequestBlindedNoChangeSelector).is(":checked"); },
	handleOriginalResourceStopDateVisibility: function () {
		if (editRequest.showOriginalResourceStopDate()) {
			$(editRequest.originalResourceStopDateContainerSelector).removeClass(editRequest.hideClass)
			$(editRequest.originalResourceStopDateSelector).qDatepicker();
		}
	},
	getResourceTypeName: function () { return $(editRequest.resourceTypeNameSelector).val(); },
	getCalculatorHeading: function () { return editRequest.getResourceTypeName() + " FTE Calculator"; },
	getRequestIdList: function () {
		return $(editRequest.requestIdListSelector).val().split(",");
	},
	getFlatFteValue: function () {
		if ($(editRequest.fteSelector).is(":visible")) {
			var fte = $.trim($(editRequest.fteSelector).val());
			return fte == "" ? null : fte;
		}
		else if ($.SmallFTECalculator != null) {
			return $.SmallFTECalculator.GetValues().FTE;
		}
		else { null; }
	},
	getTotalHoursFromUi: function () {
		return ($.SmallFTECalculator != null) ? $.SmallFTECalculator.GetValues().TotalHours : null;
	},
	getPostData: function () {
		var bigCalculatorData = (typeof calculatorHelper != "undefined") ? calculatorHelper.getCalculatorGroupData(calculatorHelper.getSelectedTabIndex(), false, new Array()) : null;
		var _adhocInitiateCalculator;
		var _adhocInitiateCalculatorTimestamp;
		if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
			_adhocInitiateCalculator = $.GenericFTECalculator ? $.GenericFTECalculator._adHocValues : null;
			_adhocInitiateCalculatorTimestamp = $.GenericFTECalculator ? $.GenericFTECalculator._adHocTimestampValues : null;
		}
		else {
			_adhocInitiateCalculator = $.Calculator ? $.Calculator._adHocValues : null;
			_adhocInitiateCalculatorTimestamp = $.Calculator ? $.Calculator._adHocTimestampValues : null;
		}

		var resourceTypeId = editRequest.getResourceTypeId();
		var selectedResourceTypeDetails = ResourceTypeDetails[resourceTypeId];
		var postData = {
			requestCommonData: {
				RequestIdList: editRequest.getRequestIdList(),
				StartDate: $(editRequest.startDateSelector).val(),
				StartDateStatus: editRequest.isDateConnected(editRequest.startDateSelector),
				StopDate: $(editRequest.stopDateSelector).val(),
				StopDateStatus: editRequest.isDateConnected(editRequest.stopDateSelector),
				RequestBudgeted: editRequest.changeRequestBudgeted() ? $(editRequest.radioRequestBudgetedYesSelector).is(":checked") : null,
				RequestBlinded: editRequest.changeRequestBlinded() ? $(editRequest.radioRequestBlindedYesSelector).is(":checked") : null,
				Reason: editRequest.changeRequestBudgeted() && $(editRequest.radioRequestBudgetedNoSelector).is(":checked") ? $(editRequest.txtReasonSelector).val() : null,

				//FTE: ((editRequest.isProposalRequest() && selectedResourceTypeDetails.ProposalRequestSchedulerType == RequestSchedulerType_E.FlatFteValue) || selectedResourceTypeDetails.RequestSchedulerType == RequestSchedulerType_E.MonitoringCountrySpecificCalculator) ?
				//			editRequest.getFteValueOrNull() :
				//		 	(resourceTypeId == ResourceTypeName.Co_monitoring || resourceTypeId == ResourceTypeName.Co_monitoring_NonSiteSpecific || resourceTypeId == ResourceTypeName.Non_Standard_Monitoring_NonSiteSpecific ?
				//		 		$.SmallFTECalculator.GetValues().FTE :
				//		 		null),
				//TotalHours: (resourceTypeId == ResourceTypeName.Co_monitoring || resourceTypeId == ResourceTypeName.Co_monitoring_NonSiteSpecific || resourceTypeId == ResourceTypeName.Global_RSUL || resourceTypeId == ResourceTypeName.Non_Standard_Monitoring_NonSiteSpecific) ? $.SmallFTECalculator.GetValues().TotalHours : null,
				FTE: editRequest.getFlatFteValue(),
				TotalHours: editRequest.getTotalHoursFromUi(),

				StaticInitiateCalculator: $.Calculator ? $.Calculator._staticValues : null,
				AdhocInitiateCalculator: _adhocInitiateCalculator,
				StaticInitiateCalcTimestamp: $.Calculator ? $.Calculator._staticTimestampValues : null,
				AdhocInitiateCalcTimestamp: _adhocInitiateCalculatorTimestamp,
				GenericInitiateCalculatorPhaseData: $.GenericFTECalculator ? $.GenericFTECalculator._genericRowsValues : null,
				GenericInitiateCalcTimestamp: $.GenericFTECalculator ? $.GenericFTECalculator._genericRowTimestampValues : null,
				calculatorGroupData: bigCalculatorData,

				CraTrainingDate: $(editRequest.craTrainingDateSelector).is(":visible") ? $(editRequest.craTrainingDateSelector).val() : null,
				CraTrainingDateStatus: $(editRequest.craTrainingDateSelector).is(":visible") ? editRequest.isDateConnected(editRequest.craTrainingDateSelector) : RequestConnect_E.Disconnected,
				IMDate: $(editRequest.imDateSelector).is(":visible") ? $(editRequest.imDateSelector).val() : null,
				IMDateStatus: $(editRequest.imDateSelector).is(":visible") ? editRequest.isDateConnected(editRequest.imDateSelector) : RequestConnect_E.Disconnected,
				OriginalResourceStopDate: editRequest.isBackfillRequest() ? $(editRequest.originalResourceStopDateSelector).val() : null
			}
		};
		return postData;
	},

	save: function () {
		if (pageManager.isValid()) {
			if (!$.validationHelper.isAnyMilestoneDeactivated) {
				pageManager.updateRequest();
				rm.validation.clearError($(editRequest.fteSelector));
			}
		}
		else {
			rm.ui.messages.addError(Resources.NoDataSaved);
		}
	},

	saveQipClinicalReqeust: function () {
		calculatorHelper.connectStatusDialogOnOkClick = editRequest.makeSaveAjaxCall;
		calculatorGroup.saveCalculator(false);
	},

	saveQipGlobalReqeust: function () { editRequest.saveQipOtherReqeust(); },
	saveQipRegionalReqeust: function () { editRequest.saveQipOtherReqeust(); },
	saveQipOtherReqeust: function () {
		if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
			$.GenericFTECalculator.CalculateWeeklyHoursOrFteOnRibbonClick();

			setTimeout(function () {

				$.GenericFTECalculator.save(false);
				editRequest.makeSaveAjaxCall();

			}, 100);
		}
		else {
			$.Calculator.CalculateWeeklyHoursOrFteOnRibbonClick();

			setTimeout(function () {
				if ($.Calculator.IsPromptRequiredForConnectDisconnectStatus()) {
					$.Calculator.DialogOkClickHandler = editRequest.makeSaveAjaxCall;
					$.Calculator.ShowConnectDisconnectChoiceDialog();
				}
				else {
					$.Calculator.save(false);
					editRequest.makeSaveAjaxCall();
				}
			}, 100);
		}
	},

	saveReqeustWithNoCalculator: function () {
		editRequest.makeSaveAjaxCall();
	},

	makeSaveAjaxCall: function () {

		if (editRequest.isBackfillRequest() &&
			editRequest.showOriginalResourceStopDate() &&
			rm.date.getDateFromQDateString($(editRequest.originalResourceStopDateSelector).val()) < rm.date.getDateFromQDateString($(editRequest.startDateSelector).val()) &&
			!confirm(Resources.ResourceStopDateLessThanBackfillStartDate)) {
			return false;
		}

		var postData = editRequest.getPostData();
		$.rm.Ajax_Request("UpdateMultipleRequests", postData, function (data) {
			if (data.ContainsValidationErrors) {
				rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
				editRequest.showErrorsInDialog(data)
			}
			else {
				rm.ui.messages.clearAllMessages();
				pageManager.onSaveSuccess(data.QipCliniclaCalculatorStatus);
				editRequest.onSaveSuccess();
				//editRequest.clearDirty();
				//$(editRequest.requestLastModifiedOnSelector).val(data.RequestStatus.RequestTimeStamp);
				//$(editRequest.attributeLastModifiedOnSelector).val(data.RequestStatus.AttributeTimeStamp);
				//$(editRequest.projectLastModifiedOnSelector).val(data.RequestStatus.ProjectTimeStamp);
				rm.ui.messages.showSuccess(Resources.DataSavedSuccessfully);
				$(editRequest.isDirtySelector).val("0");

				setTimeout(function () {
					editRequest.bindDirty();
					rm.ui.ribbon.delayedRefresh();
				}, 10);

			}
		}, false);
	},

	cancel: function () {
		var isDirty = editRequest.isDirty();

		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			RefreshPage();
		}
	},

	close: function () {
		var isDirty = editRequest.isDirty();

		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null; //Prevent prompt
			var rmPageLinkId = editRequest.getRmPageLinkId();

			if (RmPageLink_E.SSVRequests == rmPageLinkId ||
				RmPageLink_E.Autogenerated_SsvRequests == rmPageLinkId ||
				RmPageLink_E.MonitoringSsvAttributesAllZero_All_Ssv == rmPageLinkId ||
				RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Ssv == rmPageLinkId) {
				document.location.href = "/_layouts/SPUI/Notification/SSVRequest.aspx?rmPageLink=" + rmPageLinkId;
			}
			else if (RmPageLink_E.MonitoringRequests == rmPageLinkId ||
				RmPageLink_E.Autogenerated_MonitoringRequests == rmPageLinkId ||
				RmPageLink_E.MonitoringSsvAttributesAllZero_All_Monitoring == rmPageLinkId ||
				RmPageLink_E.MonitoringSsvAttributesAllZero_DirectReport_Monitoring == rmPageLinkId) {
				document.location.href = "/_layouts/SPUI/Notification/PermanentRequest.aspx?rmPageLink=" + rmPageLinkId;
			}
			else {
				document.location.href = "/_layouts/SPUI/Requests/SubmittedRequest.aspx?rmPageLink=" + rmPageLinkId;
			}
		}
	},

	onSaveSuccess: function () {
		if (editRequest.isPermanentBackfillRequest()) {
			alert("Please go back to Modify Submitted to update the original request's FTE appropriately.");
		}
	},

	onDrawComplete: function () {
		editRequest.bindDirty();
	},

	handleStartDateChange: function () {
		editRequest.calculateNeedByDate();
		editRequest.onAfterConnectIconClick();
	},

	handleStartDateChangePpm: function (event) {
		var checkConnectStatus = true;
		if (event) {
			var keyCode = event.which || event.keyCode;
			checkConnectStatus = !$.q.isNonPrintableKey(keyCode);
		}

		if (checkConnectStatus) {
			var txtBox = $(this);
			setTimeout(function () {
				requestHelper.handleMultipleStartStopDateChangePpm(txtBox, true);
				editRequest.onAfterConnectIconClick();
			}, 5);
		}
	},

	handleOtherDateChangePpm: function () {
		requestHelper.handleMultipleStartStopDateChangePpm($(this), false);
		editRequest.onAfterConnectIconClick();
	},

	handleStartDateChangePpmImageClick: function (context, onClickFunctionString) {
		requestHelper.handleMultipleStartStopDateChangePpm($(context), true, onClickFunctionString);
		editRequest.onAfterConnectIconClick();
	},

	handleOtherDateChangePpmImageClick: function (context, onClickFunctionString) {
		requestHelper.handleMultipleStartStopDateChangePpm($(context), false, onClickFunctionString);
		editRequest.onAfterConnectIconClick();
	},

	handleStartDateChangeCountry: function (event) {
		var checkConnectStatus = true;
		if (event) {
			var keyCode = event.which || event.keyCode;
			checkConnectStatus = !$.q.isNonPrintableKey(keyCode);
		}

		if (checkConnectStatus) {
			var txtBox = $(this);
			setTimeout(function () {
				requestHelper.handleMultipleStartStopDateChangeCountry(txtBox, true);
				editRequest.onAfterConnectIconClick();
			}, 5);
		}
	},

	handleOtherDateChangeCountry: function () {
		requestHelper.handleMultipleStartStopDateChangeCountry($(this), false);
		editRequest.onAfterConnectIconClick();
	},

	onAfterConnectIconClick: function () {
		rm.ui.ribbon.delayedRefresh();
	},

	setPageIsDirty: function () {
		$(editRequest.isDirtySelector).val("1");
		rm.ui.ribbon.delayedRefresh();
	},

	bindDirty: function () {
		setTimeout(function () {
			pageManager.clearDirty();
			$.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, editRequest.getJsonObjectForDirtyCheck());
			$(editRequest.getJsonObjectForDirtyCheck().items[0].selector).unbind('change', editRequest.handleChangeRangeValidateTextBox).change(editRequest.handleChangeRangeValidateTextBox).unbind('keyup', editRequest.handleChangeRangeValidateTextBox).keyup(editRequest.handleChangeRangeValidateTextBox).unbind('cut', editRequest.handleChangeRangeValidateTextBox).bind("cut", editRequest.handleChangeRangeValidateTextBox).unbind('paste', editRequest.handleChangeRangeValidateTextBox).bind("paste", editRequest.handleChangeRangeValidateTextBox);
		}, 10);
	},

	handleChangeRangeValidateTextBox: function () {
		editRequest.setPageIsDirty();
		rm.ui.ribbon.delayedRefresh();
	},

	clearDirty: function () {
		$.formStatus.clearDirty(editRequest.getJsonObjectForDirtyCheck());
	},

	isDirty: function () {
		return $.formStatus.isDirty(editRequest.getJsonObjectForDirtyCheck());
	},

	getJsonObjectForDirtyCheck: function () {
		return { items: [{ selector: "#RequestContent input:text:not([readonly]),#RequestContent select:visible,#RequestContent textarea:visible,#RequestContent radio:visible,#RequestContent [type=hidden]", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},

	initializeQipGlobalCalculator: function (calculatorHeading) {
		qipOtherCalculator.isRegionBasedCalculator = false;
		qipOtherCalculator.isGlobalCalculator = true;
		qipOtherCalculator.getOrganizationIdFromUi = function () { return $(editRequest.projectOrganizationIdSelector).val(); };
		qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return editRequest.isProposalRequest(); };
		qipOtherCalculator.getCountryIdFromUi = function () { return null; };

		$.Calculator.ClearCalculatorDirty();
		$.Calculator.OnConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnCalculatorEdit = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.AfterCalculatorDraw = function () {
			$.Calculator.ClearCalculatorDirty();
		};
		$.Calculator.AllowEditing = editRequest.allowFteCalculatorEdits();
		qipOtherCalculator.multiEditMode = true;
		qipOtherCalculator.resourceTypeId = editRequest.getResourceTypeId();
		qipOtherCalculator.regionId = editRequest.getRegionId();
		qipOtherCalculator.isRegionBasedCalculator = ResourceTypeDetails[qipOtherCalculator.resourceTypeId].IsRegionBased;
		qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return editRequest.isProposalRequest(); };

		$.Calculator.renderCalculator(null, null, $.Calculator._resourceTypeId, null, calculatorHeading, false);
	},

	initializeQipRegionalCalculator: function (calculatorHeading) {
		qipOtherCalculator.isRegionBasedCalculator = true;
		qipOtherCalculator.getRegionIdFromUi = editRequest.getRegionId;
		qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return editRequest.isProposalRequest(); };

		$.Calculator.ClearCalculatorDirty();
		$.Calculator.OnConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnCalculatorEdit = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.AfterCalculatorDraw = function () {
			$.Calculator.ClearCalculatorDirty();
		};
		$.Calculator.AllowEditing = editRequest.allowFteCalculatorEdits();
		qipOtherCalculator.multiEditMode = true;
		qipOtherCalculator.resourceTypeId = editRequest.getResourceTypeId();
		qipOtherCalculator.regionId = editRequest.getRegionId();
		qipOtherCalculator.isRegionBasedCalculator = ResourceTypeDetails[qipOtherCalculator.resourceTypeId].IsRegionBased;

		$.Calculator.renderCalculator(null, null, $.Calculator._resourceTypeId, null, calculatorHeading, false);
	},

	initializeQipOtherCalculator: function (calculatorHeading) {
		qipOtherCalculator.isRegionBasedCalculator = false;
		qipOtherCalculator.isGlobalCalculator = false;
		qipOtherCalculator.getCountryIdFromUi = editRequest.getCoutryId;
		qipOtherCalculator.isProposalReqeustOrProjectSelected = function () { return editRequest.isProposalRequest(); };

		$.Calculator.ClearCalculatorDirty();
		$.Calculator.OnConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.OnCalculatorEdit = function () { rm.ui.ribbon.refresh(); };
		$.Calculator.AfterCalculatorDraw = function () {
			$.Calculator.ClearCalculatorDirty();
		};
		$.Calculator.AllowEditing = editRequest.allowFteCalculatorEdits();
		qipOtherCalculator.multiEditMode = true;
		qipOtherCalculator.resourceTypeId = editRequest.getResourceTypeId();
		$.Calculator.renderCalculator(null, editRequest.getProjectId(), $.Calculator._resourceTypeId, editRequest.getCoutryId(), calculatorHeading, false);
	},

	initializeGenericCalculator: function (calculatorHeading) {
		$.GenericFTECalculator.ClearCalculatorDirty();
		$.GenericFTECalculator.OnConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		$.GenericFTECalculator.OnDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		$.GenericFTECalculator.OnCalculatorEdit = function () { rm.ui.ribbon.refresh(); };
		$.GenericFTECalculator.AfterCalculatorDraw = function () {
			$.GenericFTECalculator.ClearCalculatorDirty();
		};
		genericCalculator.multiEditMode = true;
		$.GenericFTECalculator._countryId = editRequest.getCoutryId();
		$.GenericFTECalculator._resourceId = editRequest.getResourceTypeId();
		$.GenericFTECalculator.AllowEditing = editRequest.allowFteCalculatorEdits();
		$.GenericFTECalculator.renderCalculator(null, editRequest.getProjectId(), $.GenericFTECalculator._resourceId, $.GenericFTECalculator._countryId, calculatorHeading, false);
	},

	previousValuesShown: function () {
		return $(".oldValue:visible").length > 0;
	},

	updatePreviousValuesIfVisible: function () {
		if (editRequest.previousValuesShown()) {
			calculatorGroup.showPreviousValues();
		}
	},
	initializeQipClinicalCalculator: function () {
		calculatorHelper.onConnectImageClick = function () { rm.ui.ribbon.refresh(); };
		calculatorHelper.onDeleteAdhocClick = function () { rm.ui.ribbon.refresh(); };
		calculatorHelper.onAdhocDateEdit = function () { rm.ui.ribbon.refresh(); };
		calculatorHelper.handleDirty = false;
		calculatorHelper.onTabReady = function () { calculatorHelper.handleCovByCountryId(editRequest.getCoutryId()); };
	},

	clearDirtyCoMonitoirngCalculator: function () {
		$.SmallFTECalculator.ClearCalculatorDirty();
	},

	isCoMonitoringCalculatorValid: function () {
		return $.SmallFTECalculator.IsValid();
	},

	isQipOtherCalculatorValid: function () {
		if (editRequest.isGenericResourceType() && !editRequest.isProposalRequest()) {
			return $.GenericFTECalculator.IsValid();
		}
		else {
			return $.Calculator.isValid();
		}
	},

	isQipClinicalCalculatorValid: function () {
		var isValid = true;

		if (typeof calculatorHelper != "undefined" &&
			!calculatorHelper.isCalculatorValid(calculatorIdJson, calculatorHelper.getSelectedTabIndex())) {
			isValid = false;

			if (!$(editRequest.qipClinicalCalculatorInnerContainer).is(":visible")) {
				$(editRequest.qipClinicalFteCalcContainerSelector).accordion("option", "active", 0);
			}
		}

		return isValid;
	},

	isBaseValid: function () {
		var isValid = true;


		if (!editRequest.isDateValid($(editRequest.startDateSelector)))// validate Start Date
		{
			isValid = false;
		}

		if (!editRequest.isDateValid($(editRequest.stopDateSelector)))// validate Stop Date
		{
			isValid = false;
		}

		var imDate = $(editRequest.imDateSelector);
		if (imDate.is(":visible") && imDate.val() != "" && !editRequest.isDateValid(imDate)) // validate IM Date
		{
			isValid = false;
		}

		var craTrainingDate = $(editRequest.craTrainingDateSelector);
		if (craTrainingDate.is(":visible") && craTrainingDate.val() != "" && !editRequest.isDateValid(craTrainingDate)) // Validate Cra Training Date
		{
			isValid = false;
		}

		var nextVisitDate = $(editRequest.nextVisitDateSelector)
		if (nextVisitDate.is(":visible") && !nextVisitDate.isDateValid(nextVisitDate)) // Validate Next Visit Date
		{
			isValid = false;
		}

		if (editRequest.showOriginalResourceStopDate()) {
			var originalResourceStopDate = $(editRequest.originalResourceStopDateSelector);
			if (!editRequest.isDateValid(originalResourceStopDate)) // Validate original resource's Stop Date
			{
				isValid = false;
			}
		}

		if ($(editRequest.requestBudgetedMainContainerSelector).is(":visible")) {

			var rbYes = $(editRequest.radioRequestBudgetedYesSelector);
			var rbNo = $(editRequest.radioRequestBudgetedNoSelector);
			var rbNochange = $(editRequest.radioRequestBudgetedNoChangeSelector);
			var reason = $(editRequest.txtReasonSelector);
			if (!rbNo.is(":checked") && !rbYes.is(":checked") && !rbNochange.is(":checked")) {
				rm.validation.addError(editRequest.radioRequestBudgetedSpanYesSelector, Resources.RequestBudgetedRequired);
				rm.validation.addError(editRequest.radioRequestBudgetedSpanNoSelector, Resources.RequestBudgetedRequired);
				rm.validation.addError(editRequest.radioRequestBudgetedSpanNoChangeSelector, Resources.RequestBudgetedRequired);
				isValid = false;
			}
			else if (rbNo.is(":checked")) // Validate reason
			{
				if ($.trim(reason.val()) == "") {
					rm.validation.addError(editRequest.txtReasonSelector, Resources.ReasonRequired);
					isValid = false;
				}
				else if (!editRequest.isMaxLengthWithinRange(reason)) {
					isValid = false;
				}
			}
		}
		return isValid;
	},

	isProposalRequestValid: function () {
		var isValid = true;

		var regionDropdown = $(editRequest.regionDropdownSelector);
		if (regionDropdown.is(":visible") && regionDropdown.val() == "-1") {
			regionDropdown.attr("title", Resources.RegionRequired);
			isValid = false;
		}

		var countryDropdown = $(editRequest.countryDropdownSelector);
		if (countryDropdown.is(":visible") && countryDropdown.val() == "-1") {
			countryDropdown.attr("title", Resources.CountryRequired);
			isValid = false;
		}

		var fteTextBox = $(editRequest.fteSelector);
		if (fteTextBox.is(":visible") && $.trim(fteTextBox.val()) != '' && !$.q.rangeValidate(fteTextBox)) {
			isValid = false;
		}

		return isValid;
	},

	setNeedByDate: function (startDateValue, resourceTransitionTimeInDays) {
		$(editRequest.needByDateSelector).val("");
		if (startDateValue != "") {
			$(editRequest.needByDateSelector).val(rm.bizRules.getNeedByDate(startDateValue, resourceTransitionTimeInDays));
		}
	},

	bindLabelQtip: function () {
		rm.qtip.showInfo("#imgUnblindedResource", "Will the resource assigned to this study request be 'Unblinded' ? If you are requesting an Unblinded resource, then your project must have an unblinded component");
	},
	bindDatePicker: function () {
		$(editRequest.startDateSelector).qDatepicker();
		$(editRequest.stopDateSelector).qDatepicker();
		$(editRequest.imDateSelector).qDatepicker();
		$(editRequest.craTrainingDateSelector).qDatepicker();
	},

	bindRequestBudgetedChange: function () {
		$(editRequest.radioRequestBudgetedNoSelector + "," + editRequest.radioRequestBudgetedYesSelector + "," + editRequest.radioRequestBudgetedNoChangeSelector).bind("change", function () { editRequest.handleRequestBudgetedChange(false) });
	},

	bindRequestBlindedChange: function () {
		$(editRequest.radioRequestBlindedNoSelector + "," + editRequest.radioRequestBlindedYesSelector + "," + editRequest.radioRequestBlindedNoChangeSelector).bind("change", function () { editRequest.handleRequestBlindedChange(false) });
	},

	bindRegionChange: function () {
		var ddlRegionObject = $(editRequest.regionDropdownSelector);
		ddlRegionObject.change(function () {
			editRequest.setPageIsDirty();
			var regionId = ddlRegionObject.val();
			var countryDropdown = $(editRequest.countryDropdownSelector).empty().append($("<option>").val("-1").html("--Select--"));
			if (regionId != "-1") {
				rm.validation.clearError(ddlRegionObject);
				rm.validation.clearError(countryDropdown);
				var postData = { regionIds: regionId };
				$.rm.Ajax_Utility("GetAllCountriesByRegion", postData, function (data) {
					$.each(data, function (index, element) {
						countryDropdown.append($("<option>").val(element.key).html(element.value));
					});
				}, true, true);
			}
		});
	},

	bindCountryChange: function () {
		var ddlCountryObject = $(editRequest.countryDropdownSelector);
		ddlCountryObject.change(function () {
			editRequest.setPageIsDirty();
			if (ddlCountryObject.val() != "-1") {
				rm.validation.clearError(ddlCountryObject);
			}
		});
	},

	handleRequestBudgetedChange: function (fromDocumentReady) {
		if (!fromDocumentReady) {
			editRequest.setPageIsDirty();
		}
		rm.validation.clearError($(editRequest.radioRequestBudgetedSpanNoSelector));
		rm.validation.clearError($(editRequest.radioRequestBudgetedSpanYesSelector));
		if ($(editRequest.radioRequestBudgetedNoSelector).is(":checked")) {
			$(editRequest.reasonContainerSelector).removeClass(editRequest.hideClass).show();
		}
		else {
			$(editRequest.reasonContainerSelector).hide();
			$(editRequest.txtReasonSelector).val("");
			rm.validation.clearError($(editRequest.txtReasonSelector));
			setTimeout(function () { $.q.textCounter($(editRequest.txtReasonSelector).get(0), $(editRequest.txtReasonSelector).attr("maxLength"), editRequest.lblRemainingLengthSelector); }, 5);
		}
		rm.ui.ribbon.refresh();
	},

	handleRequestBlindedChange: function (fromDocumentReady) {
		if (!fromDocumentReady) {
			editRequest.setPageIsDirty();
		}
		rm.ui.ribbon.refresh();
	},

	bindMaxLengthOnReason: function () {
		var reason = $(editRequest.txtReasonSelector);
		var maxLength = reason.attr("maxLength");

		$.q.textCounter(reason.get(0), maxLength, editRequest.lblRemainingLengthSelector);
		$(editRequest.txtReasonSelector).keyup(function () {
			editRequest.setPageIsDirty();
			reason = $(this);
			$.q.textCounter(this, maxLength, editRequest.lblRemainingLengthSelector);
			editRequest.isMaxLengthWithinRange(reason);
		});
	},

	isMaxLengthWithinRange: function (jqReason) {
		var isWithinRange = true;
		var maxLength = jqReason.attr("maxLength");
		if (maxLength < jqReason.val().length) {
			rm.validation.addError(editRequest.txtReasonSelector, "Maximum character limit:" + maxLength);
			isWithinRange = false;
		}
		else {
			rm.validation.clearError(jqReason);
		}

		return isWithinRange;
	},

	calculateNeedByDate: function () {
		//do not delete. need empty handler
	},

	isDateValid: function (jqObject) {
		var isValid = true;

		if (!rm.date.isValidDate(jqObject.val(), true)) {
			jqObject.addClass("q_validation_error");
			isValid = false;
		}
		else {
			rm.validation.clearError(jqObject);
		}

		return isValid;
	},

	handleNeedByDateVisibility: function () {
		if (ResourceTypeDetails[editRequest.getResourceTypeId()].ShowNeedByDate) { $(editRequest.needByDateContainerSelector).removeClass(editRequest.hideClass); }
		else { $(editRequest.needByDateContainerSelector).addClass(editRequest.hideClass); }
	},

	getPageManagerDetails: function (resourceTypeId, isProposalRequest) {
		$.rm.Ajax_RequestSynchronous("GetPageManagerTypeName", { resourceTypeId: resourceTypeId, isProposalRequest: isProposalRequest }, function (data) {
			objPageManager = data;
		}, false);
	},

	getPageManager: function (requestTypeId, resourceTypeId) {
		editRequest.getPageManagerDetails(resourceTypeId, (requestTypeId == RequestType_E.Proposal));
		$.rm.SetRequestBlindedFieldVisibility(objPageManager.DisplaysBlindedField);
		if (jQuery.isFunction(eval(objPageManager.Name))) {
			return eval("new " + objPageManager.Name + "()");
		}
		else {
			alert("Invalid resource type " + resourceTypeId);
			return null;
		}
	},

	navigateBackToGrid: function (requestList) {
		$.cookie("multiEditFailedIds", JSON.stringify(requestList), { path: "/" });
		editRequest.clearDirty();
		setTimeout(function () { editRequest.close(); }, 50);
	},

	showErrorsInDialog: function (response) {
		var htmlMessage = "<table class='validationTable'><tr class='headerRow'><td>Request Id</td><td valign='top'>Validaton Error</td></tr>";
		$.each(response.ValidationErrors, function (index, message) {
			htmlMessage += "<tr><td>" + message.Key + "</td><td>" + message.Value + "</td></tr>";
		});
		htmlMessage += "</table>";
		rmCommon.showDialogWithOkButton("Unable to save some or all requests", htmlMessage, (!response.AllRequestFailed ? function () { editRequest.navigateBackToGrid(response.FailedRequestList); } : null));
	},

	ShowConnectDisconnectPPMIcon: function () {
		if (!ResourceTypeDetails[editRequest.getResourceTypeId()].ShowStartDateConnectDisconnectIcon)
			$(editRequest.startDateSelector).parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
		if (!ResourceTypeDetails[editRequest.getResourceTypeId()].ShowStopDateConnectDisconnectIcon)
			$(editRequest.stopDateSelector).parent().find(".disconnectedFromPpm,.connectedToPpm,.disconnectedFromCountry,.connectedToCountry").remove();
	}
};

// for Standard_Monitoring start
Standard_Monitoring_PageManager = function () {
	this.draw = function () {
		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.craTrainingDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.imDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Standard_Monitoring end

// for Generic start
Generic_PageManager = function () {
	$.GenericFTECalculator.requestInDraftMode = false;
	this.draw = function () {
		$.GenericFTECalculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		$(editRequest.regionContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.genericFteCalcContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		$.GenericFTECalculator.resourceTypeSelector = editRequest.resourceTypeSelector;
		$.GenericFTECalculator.countrySelector = editRequest.countrySelector;
		$.GenericFTECalculator.startDateSelector = editRequest.startDateSelector;
		$.GenericFTECalculator.stopDateSelector = editRequest.stopDateSelector;

		editRequest.initializeGenericCalculator(editRequest.getCalculatorHeading());
		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipOtherCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.clearDirty = function () { $.GenericFTECalculator.ClearCalculatorDirty(); };
	this.onSaveSuccess = function (data) { genericCalculator.multieditSaveDone(); };
};
// for Genric end

// for Pharmacy_Monitoring start
Pharmacy_Monitoring_PageManager = function () {
	this.draw = function () {
		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.craTrainingDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.imDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Pharmacy_Monitoring end

// for CRS start
CRS_PageManager = function () {
	this.draw = function () {
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		qipOtherCalculator.connectClick = editRequest.setPageIsDirty;
		requestHelper.connectClick = editRequest.setPageIsDirty;

		$(editRequest.preferredLocationContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.regionContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.startDateSelector));
		requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.stopDateSelector));
		requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.craTrainingDateSelector));

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);

		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeading());

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipOtherCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) { };
};
// for CRS end


// for iCRA_Monitoring start
iCRA_Monitoring_PageManager = function () {
	this.draw = function () //iCRA_Monitoring
	{
		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.craTrainingDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.imDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	}; //iCRA_Monitoring
};
// for iCRA_Monitoring end

// for Co-Monitoring Site Specific start
Co_monitoring_SiteSpecific_PageManager = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChange);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.clearDirty = function () { };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Co-Monitoring Site Specific end

// for Non-Standard monitoring Site Specific start
Non_Standard_Monitoring_SiteSpecific_PageManager = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChange);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.clearDirty = function () { };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Non-Standard monitoring Site Specific end

// for Short_term_SWAT_Monitoring_OnSite_Visit start
Short_term_SWAT_Monitoring_OnSite_Visit_PageManager = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.visitTypeContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChange);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Short_term_SWAT_Monitoring_OnSite_Visit end

// for Short_term_SWAT_Monitoring_Phone_Visit start
Short_term_SWAT_Monitoring_Phone_Visit_PageManager = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.visitTypeContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChange);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for Short_term_SWAT_Monitoring_Phone_Visit end

// for Regional_CPM start
Regional_CPM_PageManager = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();
		qipOtherCalculator.connectClick = editRequest.setPageIsDirty;
		requestHelper.connectClick = editRequest.setPageIsDirty;

		$(editRequest.preferredLocationContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.regionContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.startDateSelector));
		requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.stopDateSelector));
		requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.craTrainingDateSelector));

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);

		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeading());

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipOtherCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) { };
};
// for Regional_CPM end

// for SSV_Monitoring start
SSV_Monitoring_PageManager = function () {
	this.draw = function () //SSV_Monitoring
	{
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.SsvTypeContainerSelector).removeClass(editRequest.hideClass);

		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.craTrainingDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, function () { requestHelper.handleMultipleStartStopDateChangeCountry($(this), true); editRequest.onAfterConnectIconClick(); });
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for SSV_Monitoring end

// for Proposal_Base_PageManager start
Proposal_Base_PageManager = function () {
	this.draw = function () {
		var selectedResourceTypeId = editRequest.getResourceTypeId();
		if (selectedResourceTypeId == ResourceTypeName_E.DTE_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.DTE_Pharmacy_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.Non_DTE_CRA_Project_Country ||
			selectedResourceTypeId == ResourceTypeName_E.Non_DTE_Pharmacy_CRA_Project_Country) {
			$(editRequest.fteSelector).attr("formating", "2,2").attr("from", 0.01).attr("to", 20).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 20.0.");
		}

		editRequest.handleOriginalResourceStopDateVisibility();
		if (editRequest.isHardBooked()) {
			$(editRequest.regionContainerSelector).removeClass(editRequest.hideClass);
			$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		}
		else {
			$(editRequest.proposalRegionContainerSelector).removeClass(editRequest.hideClass);
			$(editRequest.proposalCountryContainerSelector).removeClass(editRequest.hideClass);
		}

		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.fteContainerSelector).removeClass(editRequest.hideClass);

		editRequest.onDrawComplete();
	};
	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isProposalRequestValid(); };
	this.updateRequest = function () { editRequest.saveReqeustWithNoCalculator(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) { };
};
// for Proposal_Base_PageManager end

// for DTESite_Monitoring_PageManager start
DTESite_Monitoring_PageManager = function () {
	this.draw = function () //DTESite Monitoring
	{
		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.craTrainingDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.imDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for DTESite_Monitoring_PageManager end

// for DTEPharmacy_Monitoring start
DTEPharmacy_Monitoring_PageManager = function () {
	this.draw = function () //DTEPharmacy_Monitoring
	{
		calculatorHelper.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.imDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.craDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.qipClinicalFteCalcContainerSelector).removeClass(editRequest.hideClass).accordion(editRequest.accordionSettings);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.piContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.siteStatusContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);
		if (editRequest.showCountryRegion()) { $(editRequest.countryRegionContainerSelector).removeClass(editRequest.hideClass); }

		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.craTrainingDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.imDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.imDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
		$(editRequest.craTrainingDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);

		editRequest.initializeQipClinicalCalculator();

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipClinicalCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipClinicalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	};
};
// for DTEPharmacy_Monitoring end

//PhaseCalculatorPageManager_Type1
PhaseCalculatorPageManager_Type1 = function () {
	this.draw = function () {
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		qipOtherCalculator.connectClick = editRequest.setPageIsDirty;
		requestHelper.connectClick = editRequest.setPageIsDirty;

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		if (!editRequest.isProposalRequest()) {
			requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.startDateSelector));
			requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.stopDateSelector));
			requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.craTrainingDateSelector));

			$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
			$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);

		}
		editRequest.initializeQipOtherCalculator(editRequest.getCalculatorHeading());

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipOtherCalculatorValid(); };
	this.updateRequest = function () { editRequest.saveQipOtherReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) { };
};
//PhaseCalculatorPageManager_Type1

//PhaseCalculatorPageManager_Type2: on edit page type1 and type2 are exactly the same
PhaseCalculatorPageManager_Type2 = PhaseCalculatorPageManager_Type1;
//PhaseCalculatorPageManager_Type2

//PhaseCalculatorPageManager_Type3: on edit page type1 and type2 are exactly the same
PhaseCalculatorPageManager_Type3 = PhaseCalculatorPageManager_Type1;
//PhaseCalculatorPageManager_Type3

//PhaseCalculatorPageManager_Type4: on edit page type1 and type2 are exactly the same
PhaseCalculatorPageManager_Type4 = PhaseCalculatorPageManager_Type1;
//PhaseCalculatorPageManager_Type1

//FlatFteCalculatorPageManager_Type1
FlatFteCalculatorPageManager_Type1 = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.coMonFteCalcContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		$.SmallFTECalculator.resourceTypeSelector = editRequest.resourceTypeSelector;
		$.SmallFTECalculator.countrySelector = editRequest.countrySelector;
		$.SmallFTECalculator.startDateSelector = editRequest.startDateSelector;
		$.SmallFTECalculator.stopDateSelector = editRequest.stopDateSelector;
		$.SmallFTECalculator.multiEditMode = true;

		$.SmallFTECalculator.SetCalculatorValues($(editRequest.fteSelector).val(), editRequest.getTotalHours());
		$.SmallFTECalculator.renderCalculator(null, null, editRequest.getResourceTypeId(), null, editRequest.getCalculatorHeading());

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && $.SmallFTECalculator.IsValid(); };
	this.updateRequest = function () { editRequest.makeSaveAjaxCall(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) {
		editRequest.clearDirtyCoMonitoirngCalculator();
		if (editRequest.previousValuesShown()) {
			$.SmallFTECalculator.ShowPreviousPhaseValues();
		}
	};
};
//FlatFteCalculatorPageManager_Type1 End

//FlatFteCalculatorPageManager_Type2
FlatFteCalculatorPageManager_Type2 = function () {
	this.draw = function () {
		editRequest.handleOriginalResourceStopDateVisibility();

		$(editRequest.fteSelector).attr("from", 0.01).attr("to", 1.5).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 1.5.");
		$(editRequest.countryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.fteContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid(); };
	this.updateRequest = function () { editRequest.makeSaveAjaxCall(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) { };
};
//FlatFteCalculatorPageManager_Type2 End

RegionCalculatorPageManager_Type1 = function () {
	this.draw = function () {
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		qipOtherCalculator.connectClick = editRequest.setPageIsDirty;
		requestHelper.connectClick = editRequest.setPageIsDirty;

		$(editRequest.regionContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		editRequest.initializeQipRegionalCalculator(editRequest.getCalculatorHeading());
		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipOtherCalculatorValid() };
	this.updateRequest = function () { editRequest.saveQipRegionalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) { };
};

//MonitoringCountrySpecificPageManager_Type1
MonitoringCountrySpecificPageManager_Type1 = function () {
	this.draw = function () //Standard_Monitoring
	{
		$(editRequest.fteSelector).attr("formating", "2,2").attr("from", 0.01).attr("to", 20).attr("errormessage", "The value entered is not within expected range.  Correct range is 0.01 – 20.0.");
		editRequest.handleOriginalResourceStopDateVisibility();
		$(editRequest.editableCountryContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.fteContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleProposalStartDateChangeCountry);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		editRequest.onDrawComplete();


		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.startDateSelector), false);
		requestHelper.showMultipleConnectDisconnectIconCountry($(editRequest.stopDateSelector), false);

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangeCountry);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangeCountry);
	};

	this.isValid = function () //MonitoringCountrySpecificPageManager_Type1
	{
		var isValid = editRequest.isBaseValid();
		isValid = editRequest.isProposalRequestValid() && isValid;
		return isValid;
	};

	this.updateRequest = function () { editRequest.saveReqeustWithNoCalculator(); }; //MonitoringCountrySpecificPageManager_Type1
	this.onSaveSuccess = function (data) {
		calculatorHelper.handlSaveResponse(data);
		editRequest.updatePreviousValuesIfVisible();
	}; //MonitoringCountrySpecificPageManager_Type1 
	this.GetConnectedStartStopDateValues = function () { return editRequest.getConnectedDates(editRequest.getResourceTypeId(), editRequest.getProjectId(), editRequest.getCountryIdFromDropdown()); };
	this.ShowDatesOnCountryOrPreferredCountryChange = function () { editRequest.showDatesOnCountryOrPreferredCountryChange(); };
	this.clearDirty = function () { };
};
// MonitoringCountrySpecificPageManager_Type1 end


GlobalCalculatorPageManager_Type1 = function () {
	this.draw = function () {
		$.Calculator.requestInDraftMode = false;
		editRequest.handleOriginalResourceStopDateVisibility();
		qipOtherCalculator.connectClick = editRequest.setPageIsDirty;
		requestHelper.connectClick = editRequest.setPageIsDirty;

		$(editRequest.startDateContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.stopDateContainerSelector).removeClass(editRequest.hideClass);
		editRequest.handleNeedByDateVisibility();
		$(editRequest.qipOtherFteCalcContainerSelector).removeClass(editRequest.hideClass);
		$(editRequest.requestBudgetedMainContainerSelector).removeClass(editRequest.hideClass);

		requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.startDateSelector));
		requestHelper.showMultipleConnectDisconnectIconPpm($(editRequest.stopDateSelector));

		$(editRequest.startDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleStartDateChangePpm);
		$(editRequest.stopDateSelector).bind(editRequest.dateEventsToBind, editRequest.handleOtherDateChangePpm);

		editRequest.initializeQipGlobalCalculator(editRequest.getCalculatorHeading());

		editRequest.onDrawComplete();
	};

	this.isValid = function () { return editRequest.isBaseValid() && editRequest.isQipOtherCalculatorValid() };
	this.updateRequest = function () { editRequest.saveQipGlobalReqeust(); };
	this.clearDirty = function () { };
	this.onSaveSuccess = function (data) { };
};
UpdateRequestCommon = function () {
	alert("Save not implemented");
};