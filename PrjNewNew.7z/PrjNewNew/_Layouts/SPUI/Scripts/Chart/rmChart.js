﻿var rmChart = {
	selectedRequestDisplayValueType: 0,
	selectedMyStaffDisplayType: 0,
	selectedMyStaffHardBookingDisplayType: 0,
	selectedResourceDisplayType: 0,
	selectedProfileDisplayType: 0,
	selectedResourceId: 0,
	digitsAfterDecimalForFte: 3,
	digitsAfterDecimalForHours: 0,

	monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],

	displayValues: {
		Fte: 0,
		Hours: 1,
		AverageFte: 2,
		AverageHours: 3
	},

	chartType: {
		Request: 0,
		Resource: 1,
		SelectedProfile: 2,
		MyStaff: 3,
		MyStaffHardBookings: 4
	},

	graphContext: {
		Request: 0,
		Resource: 1,
		Cache: 3
	},

	chartInstance: {}, //{chartType1: instance1, chartType2: instance2}
	requestScheduleCache: {}, //{requestId1: scheduleData, requestId2: scheduleData}
	resourceScheduleCache: {}, //{resourceId1: scheduleData, resourceId2: scheduleData}
	resourceHardbookingScheduleCache: {}, //{resourceId1: scheduleData, resourceId2: scheduleData}
	searchedResourceAvailabilityCache: {},
	dateToMonthNumber: function (date) { return date.getFullYear() * 12 + date.getMonth() + 1; },

	addRequestsToGraph: function (requestIdArray, gridSelector, iconColumnName, requestProjectMap) {
		var idsNotInCache = new Array();

		$.each(requestIdArray, function (index, requestId) {
			var cachedData = rmChart.requestScheduleCache[requestId]; //Try Cache
			if (cachedData) {
				cachedData.isSelected = true;
			}
			else {
				idsNotInCache.push(requestId);
			}
		});

		if (idsNotInCache.length == 0) //all requests are in cache. Just draw the graph
		{
			rmChart.drawRequestChart(rmChart.requestScheduleCache, rmChart.chartType.Request, rmChart.selectedRequestDisplayValueType);
		}
		else {
			$.rm.Ajax_Request("GetRequestSchedule", { reqID: idsNotInCache, isExecPathRequired: "false", graphContext: 0 }, function (requestScheduler) {
				var requestSchedulerLength = requestScheduler.ReqMonthlyHours.length;
				var errorCount = 0;
				for (var i = 0; i < requestSchedulerLength; i++) {
					var requestCalendar = requestScheduler.ReqMonthlyHours[i];
					if (requestCalendar.Error) {
						errorCount++;

						if (searchCodeValues.showGraphErrors) {
							alert(requestCalendar.Error.replace(/\<br\s*\/?\>/g, " "));
						}

						if (gridSelector) {
							if (requestCalendar.Error.indexOf("have either been soft or hard booked") != -1) {
								RefreshPage();
								return;
							}
							$.validationHelper.ShowErrorMessages([{ Key: requestCalendar.ReqID, Value: requestCalendar.Error, MessageType: MessageType_E.GridIcon }], gridSelector, iconColumnName); // validationErrors, gridSelector, iconColumnName
							$(gridSelector).jqGrid('setSelection', requestCalendar.ReqID);
							var cbsdis = $("tr#" + requestCalendar.ReqID + ".jqgrow > td > input.cbox").attr("disabled", "disabled");
						}
					}
					else {
						//no errors found for the request. Clear error if any
						$(gridSelector).setCell(requestCalendar.ReqID, iconColumnName, "", "", "", true);

						var requestData = {
							hoursArray: rmChart.getFormattedArray(requestCalendar.Hours, rmChart.digitsAfterDecimalForHours),
							fteArray: rmChart.getFormattedArray(requestCalendar.FTE, rmChart.digitsAfterDecimalForFte),
							requestId: requestCalendar.ReqID,
							startMonthYear: requestCalendar.StartMonthNumber,
							endMonthYear: requestCalendar.StopMonthNumber,
							isSelected: true,
							averageHoursArray: rmChart.getFormattedArray(requestCalendar.AverageHours, rmChart.digitsAfterDecimalForHours),
							averageFteArray: rmChart.getFormattedArray(requestCalendar.AverageFTE, rmChart.digitsAfterDecimalForFte),
							projectCode: requestProjectMap[requestCalendar.ReqID]
						};

						rmChart.requestScheduleCache[requestCalendar.ReqID] = requestData; //Add request to cache
					}
				}
				if (requestSchedulerLength != errorCount) {
					rmChart.drawRequestChart(rmChart.requestScheduleCache, rmChart.chartType.Request, rmChart.selectedRequestDisplayValueType);
				}
			});
		}
	},

	getFormattedArray: function (arrayToProcess, digitsAfterDecimal, customPointToolTipData) {
		//if (arrayToProcess) {
		//	for (var index = 0, length = arrayToProcess.length; index < length; index++) {
		//		arrayToProcess[index] = customPointToolTipData ?
		//															{ y: rmChart.getFormattedNumber(arrayToProcess[index], digitsAfterDecimal), custom: customPointToolTipData } :
		//															rmChart.getFormattedNumber(arrayToProcess[index], digitsAfterDecimal);
		//	}
		//}

		//return arrayToProcess;
		var formattedArray = new Array();
		if (arrayToProcess) {
			for (var index = 0, length = arrayToProcess.length; index < length; index++) {
				formattedArray.push(customPointToolTipData ?
					{ y: rmChart.getFormattedNumber(arrayToProcess[index], digitsAfterDecimal), custom: customPointToolTipData } :
					rmChart.getFormattedNumber(arrayToProcess[index], digitsAfterDecimal));
			}
		}

		return formattedArray;
	},

	getFormattedNumber: function (numberToFormat, digitsAfterDecimal) {
		return parseFloat(numberToFormat.toFixed(digitsAfterDecimal));
	},

	removeRequestFromGraph: function (requestId) {
		var cachedData = rmChart.requestScheduleCache[requestId];
		//Do not redraw graph if the request id is not found in the cache. This happens when selected reqeust has errors and schedule cannot be calculated.
		if (cachedData) {
			cachedData.isSelected = false;
			rmChart.drawRequestChart(rmChart.requestScheduleCache, rmChart.chartType.Request, rmChart.selectedRequestDisplayValueType);
		}
	},

	drawRequestChart: function (requestScheduleData, chartType, displayValueType) {
		var selectedRequestsJson = rmChart.getSelectedRequests(requestScheduleData);
		var chartDataList = rmChart.getAligedRequestSeriesForChart(selectedRequestsJson.minStartMonthYear, selectedRequestsJson.maxStopMonthYear, selectedRequestsJson.selectedItems, displayValueType);
		var xLabelList = rmChart.getXAxisLabelList(selectedRequestsJson.minStartMonthYear, selectedRequestsJson.maxStopMonthYear);

		if (chartDataList == null || chartDataList.length == 0) { rm.ui.unblock(); return; }

		highChartInstance = rmChart.chartInstance[chartType];

		var displayFte = displayValueType == rmChart.displayValues.Fte;
		var yAxisTextVal;
		switch (displayValueType) {
			case rmChart.displayValues.Fte:
				yAxisTextVal = "FTE";
				break;
			case rmChart.displayValues.Hours:
				yAxisTextVal = "Hours";
				break;
			case rmChart.displayValues.AverageFte:
				yAxisTextVal = "Flatlined FTE";
				break;
			case rmChart.displayValues.AverageHours:
				yAxisTextVal = "Flatlined Hours";
				break;
		}

		if (!highChartInstance) {
			var chartConfiguration = {
				renderTo: "ChartReqContainer",
				chartTitle: "",
				yAxisText: yAxisTextVal,
				digitsAfterDecimal: displayFte ? 2 : 0,
				stacking: "normal"
			};

			highChartInstance = rmChart.createChart(xLabelList, chartDataList, chartConfiguration, chartType);
			rmChart.chartInstance[chartType] = highChartInstance;
			setTimeout(function () { rmChart.updateRequestGraph(highChartInstance, xLabelList, chartDataList, yAxisTextVal); }, 20);
		}
		else {
			rmChart.updateRequestGraph(highChartInstance, xLabelList, chartDataList, yAxisTextVal);
		}
	},

	updateRequestGraph: function (highChartInstance, xLabelList, chartDataList, yAxisTextVal) {
		highChartInstance.xAxis[0].update({ categories: xLabelList });

		var currentSeries;
		var outSeries = {};
		for (var index = highChartInstance.series.length - 1; index >= 0; index--) {
			currentSeries = highChartInstance.series[index];

			if (rmChart.containsId(chartDataList, currentSeries.name, outSeries)) {
				highChartInstance.series[index].update({ data: outSeries.value.data, name: currentSeries.name }, false);
			}
			else {
				highChartInstance.series[index].remove(false);
			}
		}

		$(highChartInstance.yAxis[0].axisTitle.element).text(yAxisTextVal);

		for (var index = 0; index < chartDataList.length; index++) {
			if (!rmChart.containsId(highChartInstance.series, chartDataList[index].name, outSeries)) {
				highChartInstance.addSeries(chartDataList[index], false, false);
			}
		}

		//hack to force graph to fix the xlables.
		if (highChartInstance.series.length == 0) {
			highChartInstance.addSeries({ data: [], name: " " }, false, false);
			highChartInstance.series[0].remove(false);
		}

		rmChart.checkChartZoom(highChartInstance, xLabelList.length);

		highChartInstance.redraw();
		rm.ui.unblock();
	},

	checkChartZoom: function (highChartInstance, totalMonths) {
		$('.highcharts-reset-zoom').remove();

		if (totalMonths > 12) {
			highChartInstance.xAxis[0].setExtremes(0, 11);
			highChartInstance.showResetZoom();
		}
		else {
			highChartInstance.xAxis[0].setExtremes(0, totalMonths == 0 ? 0 : totalMonths - 1);
		}
	},

	changeDisplayHoursFte: function (spanClicked, evt, chartType, isFte, isAverage) {
		// Stop bubble to avoid Accordeon process
		if (evt) {
			if (evt.stopPropagation) { evt.stopPropagation(); }
			else { evt.cancelBubble = true; }
		}

		// Highlight button-span clicked
		$(spanClicked).parent().find(".graphActionButton").removeClass("graphActiveButton");
		$(spanClicked).addClass("graphActiveButton");

		var resourceId = spanClicked.getAttribute('rm_resourceId'); // only used if chart type = 3

		rm.ui.block("Loading Chart");
		var chartDisplayType = isFte ? (isAverage ? rmChart.displayValues.AverageFte : rmChart.displayValues.Fte)
			: (isAverage ? rmChart.displayValues.AverageHours : rmChart.displayValues.Hours);
		if (chartType == rmChart.chartType.Request) {
			rmChart.selectedRequestDisplayValueType = chartDisplayType;
			rm_timeOut(rmChart.drawRequestChart, 10, this, rmChart.requestScheduleCache, rmChart.chartType.Request, rmChart.selectedRequestDisplayValueType);
		}
		else if (chartType == rmChart.chartType.Resource) {
			rmChart.selectedResourceDisplayType = chartDisplayType;
			rm_timeOut(rmChart.drawResourceChart, 10, this, rmChart.searchedResourceAvailabilityCache, rmChart.chartType.Resource, rmChart.selectedResourceDisplayType);
		}
		else if (chartType == rmChart.chartType.MyStaff) {
			rmChart.selectedMyStaffDisplayType = isFte ? rmChart.displayValues.Fte : rmChart.displayValues.Hours;
			rm_timeOut(rmChart.drawMyStaffChart, 10, this, rmChart.resourceScheduleCache[rmChart.selectedResourceId], rmChart.chartType.MyStaff, '', rmChart.selectedMyStaffDisplayType);
		}
		else if (chartType == rmChart.chartType.SelectedProfile) {
			rmChart.selectedProfileDisplayType = isFte ? rmChart.displayValues.Fte : rmChart.displayValues.Hours;
			rm_timeOut(rmChart.drawMyStaffChart, 10, this, rmChart.resourceScheduleCache[resourceId], rmChart.chartType.SelectedProfile, '', rmChart.selectedProfileDisplayType);
		}
		else if (chartType == rmChart.chartType.MyStaffHardBookings) {
			rmChart.selectedMyStaffHardBookingDisplayType = isFte ? rmChart.displayValues.Fte : rmChart.displayValues.Hours;
			rm_timeOut(rmChart.drawMyStaffHardBookingsChart, 10, this, rmChart.resourceHardbookingScheduleCache[resourceId], rmChart.chartType.MyStaffHardBookings, '', rmChart.selectedMyStaffHardBookingDisplayType);
		}
	},

	getSelectedRequests: function (objectToProcess) //{id1:{isSelected:true}, id2:{isSelected:false}}
	{
		var returnValue = {
			minStartMonthYear: 0,
			maxStopMonthYear: 0,
			selectedItems: new Array()
		};

		var currentObject;
		for (var key in objectToProcess) {
			if (objectToProcess.hasOwnProperty(key) && objectToProcess[key].isSelected) {
				currentObject = objectToProcess[key];
				returnValue.selectedItems.push(currentObject);

				if (returnValue.minStartMonthYear == 0 || returnValue.minStartMonthYear > currentObject.startMonthYear) {
					returnValue.minStartMonthYear = currentObject.startMonthYear;
				}

				if (returnValue.maxStopMonthYear == 0 || returnValue.maxStopMonthYear < currentObject.endMonthYear) {
					returnValue.maxStopMonthYear = currentObject.endMonthYear;
				}
			}
		}

		return returnValue;
	},

	getXAxisLabelList: function (minStartMonthYear, maxStopMonthYear) {
		var labelList = new Array();

		for (var monthYearNumber = minStartMonthYear; monthYearNumber <= maxStopMonthYear; monthYearNumber++) {
			var year = Math.floor((monthYearNumber - 1) / 12);
			labelList.push(rmChart.monthNames[monthYearNumber - year * 12 - 1] + ' ' + year);
		}

		return labelList;
	},

	getAligedRequestSeriesForChart: function (minStartMonthYear, maxStopMonthYear, selectedItems, displayValueType) {
		var alignedSeriesForChart = new Array();
		var seriesForChart;

		var currentItem;
		for (var index = 0, itemLength = selectedItems.length; index < itemLength; index++) {
			currentItem = selectedItems[index];

			seriesForChart = { name: currentItem.requestId, data: new Array() };

			if (currentItem.startMonthYear > minStartMonthYear) {
				//If there are less number of items in the current array, add 0 at the begining of the array so that all selected items start in same month
				for (var startMonthYear = minStartMonthYear; startMonthYear < currentItem.startMonthYear; startMonthYear++) {
					seriesForChart.data.push(0);
				}
			}

			//Based on the values to display, use either FTE or Hours array
			var sourceArray;

			switch (displayValueType) {
				case rmChart.displayValues.Fte:
					sourceArray = currentItem.fteArray;
					break;
				case rmChart.displayValues.Hours:
					sourceArray = currentItem.hoursArray;
					break;
				case rmChart.displayValues.AverageFte:
					sourceArray = currentItem.averageFteArray;
					break;
				case rmChart.displayValues.AverageHours:
					sourceArray = currentItem.averageHoursArray;
					break;
			}

			//Dump all values from the sourceArray to array for chart (seriesForChart)
			for (var sourceArrayIndex = 0, sourceArrayLength = sourceArray.length; sourceArrayIndex < sourceArrayLength; sourceArrayIndex++) {
				seriesForChart.data.push(sourceArray[sourceArrayIndex]);
			}

			alignedSeriesForChart.push(seriesForChart);
		}

		return alignedSeriesForChart;
	},

	containsId: function (selectedItems, idToCheck, outSeries) {
		var containsId = false;
		if (selectedItems) {
			for (var index = 0, length = selectedItems.length; index < length; index++) {
				if (selectedItems[index].name == idToCheck) {
					outSeries.value = selectedItems[index];
					containsId = true;
					break;
				}
			}
		}
		return containsId;
	},

	createChart: function (xLabelList, chartDataList, chartConfiguration, chartType) {
		var isDetailedChart = rmChart.chartType.SelectedProfile == chartType || rmChart.chartType.MyStaff == chartType;

		var chartWidth;

		switch (chartType) {
			case rmChart.chartType.SelectedProfile:
				chartWidth = null;
				break;
			case rmChart.chartType.Resource:
				chartWidth = rm.ui.getContentContainerWidth() - 237;
				break;
			case rmChart.chartType.Request:
				chartWidth = $(window).width() - 220;
				break;
			default:
				chartWidth = null;
				break;

		}
		return new Highcharts.Chart({
			chart: {
				renderTo: chartConfiguration.renderTo,
				zoomType: 'x',
				animation: false,
				height: 300,
				width: chartWidth,//rmChart.chartType.SelectedProfile == chartType ? null : $(window).width() - 120,
				marginTop: (isDetailedChart ? 70 : 20),
				defaultSeriesType: 'column',
				resetZoomButton: {
					position: {
						x: -115,
						y: isDetailedChart ? 35 : 0
					},
					theme: {
						fill: 'white',
						stroke: 'silver',
						r: 5
					},
					relativeTo: 'chart'
				}
			},
			title: {
				text: chartConfiguration.chartTitle
			},
			xAxis: {
				categories: xLabelList, //['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
				labels: {
					rotation: -45,
					align: 'right'
				}
			},
			yAxis: {
				min: 0,
				title: {
					text: chartConfiguration.yAxisText
				},
				stackLabels: {
					enabled: false,
					//formatter: function () { return this.total ? this.total.toFixed(chartConfiguration.digitsAfterDecimal) : this.total; },
					style: {
						fontWeight: 'bold',
						color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
					}
				}
			},
			credits: { enabled: false },
			legend: {
				align: (isDetailedChart ? 'top' : 'right'),
				x: (isDetailedChart ? 0 : -100),
				verticalAlign: 'top',
				y: (isDetailedChart ? -10 : 30),
				floating: false,
				layout: (isDetailedChart ? 'horizontal' : 'vertical'),
				backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColorSolid) || 'white',
				borderColor: '#CCC',
				borderWidth: 1,
				shadow: false,
				symbolRadius: 3,
				labelFormatter: function () {
					return rmChart.getProjectCodeFromScheduleCache(this.name, chartType) + this.name;
				}
			},
			tooltip: {
				formatter: function () {
					// 	return '<b>' + this.x + '</b><br/>' +
					//this.series.name + ': ' + (this.y ? this.y.toFixed(chartConfiguration.digitsAfterDecimal) : this.y) +
					//(chartType == rmChart.chartType.Request ? '<br/>' + 'Total: ' + (this.point.stackTotal ? this.point.stackTotal.toFixed(chartConfiguration.digitsAfterDecimal) : this.point.stackTotal) : '');

					return '<b>' + this.x + '</b><br/>' + (this.point.custom || '') + this.series.name + ': ' + this.y +
						(chartType == rmChart.chartType.Request ?
							'<br/>' + 'Total: ' + this.point.stackTotal :
							'');
				}
			},

			plotOptions: {
				series: {
					dataLabels: {
						enabled: false,
						rotation: -90,
						align: 'center'
						//formatter: function () { return this.y ? this.y.toFixed(chartConfiguration.digitsAfterDecimal) : this.y; }
					}
				},
				column: {
					stacking: chartConfiguration.stacking,
					dataLabels: {
						color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
					}
				},
				spline: {
					zIndex: 10
				}
			},
			series: chartDataList
		});
	},

	clearChart: function (chartType, redraw) {
		var highChart = rmChart.chartInstance[chartType];
		rmChart.searchedResourceAvailabilityCache = {};//Purge resource cache since the resource availability data may have changed
		if (highChart) {
			highChart.xAxis[0].update({ categories: [" ", " ", " ", " ", " "] });
			rmChart.checkChartZoom(highChart, 6);

			while (highChart.series.length > 0) {
				highChart.series[0].remove(false);
			}

			if (redraw) {
				highChartInstance.redraw();
			}
		}
	},

	resetIsSelectedInCache: function (chartType) {
		var objectToProcess;
		switch (chartType) {
			case rmChart.chartType.Request:
				objectToProcess = rmChart.requestScheduleCache;
				break;
			case rmChart.chartType.Resource:
				objectToProcess = rmChart.searchedResourceAvailabilityCache;
				break;
			case rmChart.chartType.SelectedProfile:
				objectToProcess = rmChart.resourceScheduleCache;
				break;
		}

		if (objectToProcess) {
			//Mark all requests as not selected
			for (var key in objectToProcess) {
				if (objectToProcess.hasOwnProperty(key) && objectToProcess[key].isSelected) {
					objectToProcess[key].isSelected = false;
				}
			}
		}
	},

	clearRequestChartSeries: function () {
		rmChart.clearChart(rmChart.chartType.Request, true);
		rmChart.resetIsSelectedInCache(rmChart.chartType.Request);
	},

	clearResourceChartSeries: function () {
		rmChart.clearChart(rmChart.chartType.Resource, true);
		rmChart.resetIsSelectedInCache(rmChart.chartType.SelectedProfile);
		rmChart.resetIsSelectedInCache(rmChart.chartType.Resource);
	},

	clearMyStaffHardBookingChartSeries: function () {
		rmChart.clearChart(rmChart.chartType.MyStaffHardBookings, false);
	},

	clearMyStaffChartSeries: function () { rmChart.clearChart(rmChart.chartType.MyStaff, false); },

	showMyStaffChart: function (chartType, resourceDetails, divChartResource, chartResourceTitleContainer, isRefreshCache) {
		$("#" + chartResourceTitleContainer).html(resourceDetails.chartHeading);
		rmChart.selectedResourceId = resourceDetails.resourceId;
		var resourceScheduleData = isRefreshCache ? null : rmChart.resourceScheduleCache[resourceDetails.resourceId];
		if (!resourceScheduleData) {
			var start = new Date();
			start.setMonth(start.getMonth() - 1);
			resourceScheduleData = rmChart.getResourceSchedule([resourceDetails], rmChart.dateToMonthNumber(start))[resourceDetails.resourceId];//send selected resource only 
			rmChart.resourceScheduleCache[resourceDetails.resourceId] = resourceScheduleData;
		}

		var displayType = chartType == rmChart.chartType.MyStaff ? rmChart.selectedMyStaffDisplayType : rmChart.selectedProfileDisplayType;

		rmChart.drawMyStaffChart(resourceScheduleData, chartType, divChartResource, displayType);
	},
	getProjectCodeFromScheduleCache: function (seriesName, chartType) {
		switch (chartType) {
			case rmChart.chartType.Request:
				return (rmChart.requestScheduleCache[seriesName] == null) ? "" : rmChart.requestScheduleCache[seriesName].projectCode + " - ";

			case rmChart.chartType.MyStaffHardBookings:
				//Loop through the resource booking cache to find out the request Id. This is bette than implementing convoluted way of passing resourceId to the chart functions.
				for (var resourceId in rmChart.resourceHardbookingScheduleCache) {
					if (rmChart.resourceHardbookingScheduleCache.hasOwnProperty(resourceId)) {
						for (var requestId in rmChart.resourceHardbookingScheduleCache[resourceId]) {
							if (requestId == seriesName) {
								return (rmChart.resourceHardbookingScheduleCache[resourceId][seriesName] == null) ? "" : rmChart.resourceHardbookingScheduleCache[resourceId][seriesName].projectCode + " - ";
							}
						}
					}
				}
				return "";
			default:
				return "";
		}
	},
	drawMyStaffChart: function (resourceScheduleData, chartType, renderToControlId, displayValueType) {
		if (resourceScheduleData == null) { return; }

		var displayFte = displayValueType == rmChart.displayValues.Fte;
		//Avoid passing schedule data by reference. Serializing and then deserializing data creates new instance of the object and prevents chart from updating original copy of the data.
		var chartDataList = JSON.parse(JSON.stringify(displayFte ? resourceScheduleData.fteSchedule : resourceScheduleData.hourSchedule));
		var xLabelList = rmChart.getXAxisLabelList(resourceScheduleData.startMonthYear, resourceScheduleData.endMonthYear);
		var chartInstanceId = chartType == rmChart.chartType.MyStaff ? chartType : chartType + "_" + resourceScheduleData.resourceId;

		highChartInstance = rmChart.chartInstance[chartInstanceId];

		if (!highChartInstance) {
			var chartConfiguration = {
				renderTo: renderToControlId,
				chartTitle: "",
				yAxisText: displayFte ? "FTE" : "Hours",
				digitsAfterDecimal: displayFte ? 2 : 0,
				stacking: "normal"
			};

			highChartInstance = rmChart.createChart(xLabelList, chartDataList, chartConfiguration, chartType);
			rmChart.chartInstance[chartInstanceId] = highChartInstance;
			//setTimeout(function () { rmChart.updateMyStaffChart(highChartInstance, xLabelList, chartDataList, displayFte); }, 20);
		}
		else {
			rmChart.updateMyStaffChart(highChartInstance, xLabelList, chartDataList, displayFte);
		}
	},

	updateMyStaffChart: function (highChartInstance, xLabelList, chartDataList, displayFte) {
		highChartInstance.xAxis[0].update({ categories: xLabelList });

		var currentSeries;
		var currentData;
		var outSeries = {};

		for (var index = chartDataList.length - 1; index >= 0; index--) {
			currentData = chartDataList[index];
			for (var chartSeriesIndex = 0, length = highChartInstance.series.length; chartSeriesIndex < length; chartSeriesIndex++) {
				currentSeries = highChartInstance.series[chartSeriesIndex];
				if (currentSeries.name == currentData.name) {
					currentSeries.update({ data: currentData.data, name: currentData.name }, false);
					break;
				}
			}
		}

		$(highChartInstance.yAxis[0].axisTitle.element).text(displayFte ? "FTE" : "Hours");

		//rmChart.checkChartZoom(highChartInstance, xLabelList.length);

		highChartInstance.redraw();
		rm.ui.unblock();
	},

	showMyStaffHardBookingsChart: function (chartType, resourceDetails, divChartResource, chartResourceTitleContainer, isRefreshCache) {
		$("#" + chartResourceTitleContainer).html(resourceDetails.chartHeading);
		rmChart.selectedResourceId = resourceDetails.resourceId;
		var resourceScheduleData = isRefreshCache ? null : rmChart.resourceHardbookingScheduleCache[resourceDetails.resourceId];
		if (!resourceScheduleData) {
			resourceScheduleData = rmChart.getResourceHardBookingSchedule(resourceDetails.resourceId);
			rmChart.resourceHardbookingScheduleCache[resourceDetails.resourceId] = resourceScheduleData;
		}

		rmChart.drawMyStaffHardBookingsChart(resourceScheduleData, chartType, divChartResource, rmChart.selectedMyStaffHardBookingDisplayType);
	},

	drawMyStaffHardBookingsChart: function (resourceScheduleData, chartType, renderToControlId, displayValueType) {
		var displayFte = displayValueType == rmChart.displayValues.Fte;

		var selectedRequestsJson = rmChart.getSelectedRequests(resourceScheduleData);
		//Avoid passing schedule data by reference. Serializing and then deserializing data creates new instance of the object and prevents chart from updating original copy of the data.
		var chartDataList = JSON.parse(JSON.stringify(rmChart.getAligedRequestSeriesForChart(selectedRequestsJson.minStartMonthYear, selectedRequestsJson.maxStopMonthYear, selectedRequestsJson.selectedItems, displayValueType)));
		var xLabelList = rmChart.getXAxisLabelList(selectedRequestsJson.minStartMonthYear, selectedRequestsJson.maxStopMonthYear);
		var chartInstanceId = rmChart.chartType.MyStaffHardBookings;

		highChartInstance = rmChart.chartInstance[chartInstanceId];

		if (!highChartInstance) {
			var chartConfiguration = {
				renderTo: renderToControlId,
				chartTitle: "",
				yAxisText: displayFte ? "FTE" : "Hours",
				digitsAfterDecimal: displayFte ? 2 : 0,
				stacking: "normal"
			};
			if (chartDataList.length == 0) { chartDataList.push({ name: " ", data: [] }); }

			highChartInstance = rmChart.createChart(xLabelList, chartDataList, chartConfiguration, chartType);
			if (chartDataList.length != 0) {
				rmChart.chartInstance[chartInstanceId] = highChartInstance;
			}
		}
		else {
			rmChart.updateMyStaffHardBookingsChart(highChartInstance, xLabelList, chartDataList, displayFte);
		}
	},

	updateMyStaffHardBookingsChart: function (highChartInstance, xLabelList, chartDataList, displayFte) {
		highChartInstance.xAxis[0].update({ categories: xLabelList });

		//var currentSeries;
		//var outSeries = {};
		//for (var index = highChartInstance.series.length - 1; index >= 0; index--)
		//{
		//	currentSeries = highChartInstance.series[index];

		//	if (rmChart.containsId(chartDataList, currentSeries.name, outSeries))
		//	{
		//		highChartInstance.series[index].update({ data: outSeries.value.data, name: currentSeries.name }, false);
		//	}
		//	else
		//	{
		//		highChartInstance.series[index].remove(false);
		//	}
		//}

		for (var index = 0; index < chartDataList.length; index++) {
			var currentSeries = chartDataList[index];
			var outSeries = {};
			if (rmChart.containsId(highChartInstance.series, currentSeries.name, outSeries)) {
				outSeries.value.update({ data: currentSeries.data, name: currentSeries.name }, false);
			}
			else {
				highChartInstance.addSeries(chartDataList[index], false, false);
			}
		}

		for (var index = highChartInstance.series.length - 1; index >= 0; index--) {
			var currentSeries = highChartInstance.series[index];

			if (!rmChart.containsId(chartDataList, currentSeries.name, outSeries)) {
				highChartInstance.series[index].remove(false);
			}
		}

		$(highChartInstance.yAxis[0].axisTitle.element).text(displayFte ? "FTE" : "Hours");

		//for (var index = 0; index < chartDataList.length; index++)
		//{
		//	if (!rmChart.containsId(highChartInstance.series, chartDataList[index].name, outSeries))
		//	{
		//		highChartInstance.addSeries(chartDataList[index], false, false);
		//	}
		//}

		//hack to force graph to fix the xlables.
		if (highChartInstance.series.length == 0) {
			highChartInstance.addSeries({ data: [], name: " " }, false, false);
			highChartInstance.series[0].remove(false);
		}

		rmChart.checkChartZoom(highChartInstance, xLabelList.length);

		highChartInstance.redraw();
		rm.ui.unblock();
	},

	getResourceSchedule: function (resourceDetailsArray, startMonth) {
		var resourceSchedule = {};
		for (var j = 0, resourceIdList = []; j < resourceDetailsArray.length; j++) {
			resourceIdList.push(resourceDetailsArray[j].resourceId);
		}

		var data = {
			resourceIdList: resourceIdList,
			minDate: startMonth ? startMonth : 0,
			maxDate: 0,
			isExecPathRequired: false,
			graphContext: rmChart.graphContext.Resource
		};

		$.rm.Ajax_ResourceSynchronous("GetResourceSchedule", data, function (response) {
			var resourceScheduleList = response.ResourcesSched;

			// Update Request Schedule local Cache
			if (resourceScheduleList.length != resourceIdList.length && searchCodeValues.showGraphErrors) {
				//alert('Error: # Resources returned =' + resourceScheduleList.length + ' != ' + resourceScheduleList.length);
				return;
			}

			var resourcesAssignedToBadRequests = "";
			for (var k = 0; k < resourceScheduleList.length; k++) {
				if (resourceScheduleList[k].ResReqErrors != null && resourceScheduleList[k].ResReqErrors.length > 0) {
					resourcesAssignedToBadRequests += resourceScheduleList[k].ResourceName + ",";
				}
			}
			if (resourcesAssignedToBadRequests.length > 0 && searchCodeValues.showGraphErrors) {
				alert("For " + resourcesAssignedToBadRequests.substring(0, resourcesAssignedToBadRequests.length - 1) + " , the RM system was not able to display the Resource Profile graph due to errors.  Please refer to the People and Project report to view details of the error or click on ‘help’ for more information.");
			}

			var currentResourceScheduleResponse;
			var currentResourceSchedule;
			for (var k = 0; k < resourceScheduleList.length; k++) {
				var currentResourceScheduleResponse = resourceScheduleList[k];

				currentResourceSchedule = {
					hourSchedule: [
						{ data: rmChart.getFormattedArray(currentResourceScheduleResponse.SoftBookProposal, rmChart.digitsAfterDecimalForHours), name: "Proposal Soft Booking" },
						{ data: rmChart.getFormattedArray(currentResourceScheduleResponse.HardBookProposal, rmChart.digitsAfterDecimalForHours), name: "Proposal Hard Booking" },
						{ data: rmChart.getFormattedArray(currentResourceScheduleResponse.SoftBook, rmChart.digitsAfterDecimalForHours), name: "Soft Book" },
						{ data: rmChart.getFormattedArray(currentResourceScheduleResponse.HardBook, rmChart.digitsAfterDecimalForHours), name: "Hard Book" },
						{ data: rmChart.getFormattedArray(currentResourceScheduleResponse.HardBookPermanentBackfill, rmChart.digitsAfterDecimalForHours), name: "Perm. BackFill Hard Book" },
						{ data: rmChart.getFormattedArray(currentResourceScheduleResponse.SoftBookPermanentBackfill, rmChart.digitsAfterDecimalForHours), name: "Perm. BackFill Soft Book" },
						{ data: rmChart.getFormattedArray(currentResourceScheduleResponse.SpecialAssignment, rmChart.digitsAfterDecimalForHours), name: "Special Assignment" },
						{ data: rmChart.getFormattedArray(currentResourceScheduleResponse.Avt, rmChart.digitsAfterDecimalForHours), name: "AVT" }
					],
					fteSchedule: [
						{
							data: rmChart.getFteArrayFromHoursArray(false, currentResourceScheduleResponse.TargetUtil, currentResourceScheduleResponse.FullTimeWorkingHours, currentResourceScheduleResponse.SoftBookProposal),
							name: "Proposal Soft Booking"
						},
						{
							data: rmChart.getFteArrayFromHoursArray(false, currentResourceScheduleResponse.TargetUtil, currentResourceScheduleResponse.FullTimeWorkingHours, currentResourceScheduleResponse.HardBookProposal),
							name: "Proposal Hard Booking"
						},
						{
							data: rmChart.getFteArrayFromHoursArray(false, currentResourceScheduleResponse.TargetUtil, currentResourceScheduleResponse.FullTimeWorkingHours, currentResourceScheduleResponse.SoftBook),
							name: "Soft Book"
						},
						{
							data: rmChart.getFteArrayFromHoursArray(false, currentResourceScheduleResponse.TargetUtil, currentResourceScheduleResponse.FullTimeWorkingHours, currentResourceScheduleResponse.HardBook),
							name: "Hard Book"
						},
						{
							data: rmChart.getFteArrayFromHoursArray(false, currentResourceScheduleResponse.TargetUtil, currentResourceScheduleResponse.FullTimeWorkingHours, currentResourceScheduleResponse.HardBookPermanentBackfill),
							name: "Perm. BackFill Hard Book"
						},
						{
							data: rmChart.getFteArrayFromHoursArray(false, currentResourceScheduleResponse.TargetUtil, currentResourceScheduleResponse.FullTimeWorkingHours, currentResourceScheduleResponse.SoftBookPermanentBackfill),
							name: "Perm. BackFill Soft Book"
						},
						{
							data: rmChart.getFteArrayFromHoursArray(false, currentResourceScheduleResponse.TargetUtil, currentResourceScheduleResponse.FullTimeWorkingHours, currentResourceScheduleResponse.SpecialAssignment),
							name: "Special Assignment"
						},
						{
							data: rmChart.getFteArrayFromHoursArray(true, currentResourceScheduleResponse.TargetUtil, currentResourceScheduleResponse.FullTimeWorkingHours, currentResourceScheduleResponse.Avt),
							name: "AVT"
						}
					],
					resourceId: currentResourceScheduleResponse.ResID,
					resourceName: currentResourceScheduleResponse.ResourceName,
					startMonthYear: response.StartMonth,
					endMonthYear: response.EndMonth,
					isSelected: true
				};

				resourceSchedule[currentResourceScheduleResponse.ResID] = currentResourceSchedule;
			}
		}, false, true);

		return resourceSchedule;
	},

	getResourceHardBookingSchedule: function (resourceId) {
		var cachedData = rmChart.resourceHardbookingScheduleCache[resourceId]; //Try Cache

		if (!cachedData) {
			cachedData = {};
			$.rm.Ajax_RequestSynchronous("GetAssignedRequestScheduleByResourceId", { resourceId: resourceId, graphContext: 0 }, function (requestScheduler) {
				if (requestScheduler) {
					var requestSchedulerLength = requestScheduler.ReqMonthlyHours.length;
					var errorCount = 0;
					for (var i = 0; i < requestSchedulerLength; i++) {
						var requestCalendar = requestScheduler.ReqMonthlyHours[i];

						var requestData = {
							hoursArray: rmChart.getFormattedArray(requestCalendar.Hours, rmChart.digitsAfterDecimalForHours, requestCalendar.CustomPointToolTipData),
							fteArray: rmChart.getFormattedArray(requestCalendar.FTE, rmChart.digitsAfterDecimalForFte, requestCalendar.CustomPointToolTipData),
							requestId: requestCalendar.ReqID,
							startMonthYear: requestCalendar.StartMonthNumber,
							endMonthYear: requestCalendar.StopMonthNumber,
							isSelected: true,
							projectCode: requestCalendar.ProjectCode
						};
						if (requestData.hoursArray == null) {
							requestData.hoursArray = [];
						}
						if (requestData.fteArray == null) {
							requestData.fteArray = [];
						}

						cachedData[requestCalendar.ReqID] = requestData; //Add request to cache
					}
				}
				rmChart.resourceHardbookingScheduleCache[resourceId] = cachedData;
			});
		}
		return cachedData;
	},

	getFteArrayFromHoursArray: function (isAvt, targetUtilization, fullTimeWorkingHours, hoursArray) {
		var fteArray = new Array();

		if (hoursArray) {
			var fte;
			for (var index = 0, length = hoursArray.length; index < length; index++) {
				fte = rmChart.getFormattedNumber(rmChart.getFteFromHours(isAvt, targetUtilization, fullTimeWorkingHours[index], hoursArray[index]), rmChart.digitsAfterDecimalForFte);
				fteArray.push(fte);
			}
		}

		return fteArray;
	},

	getFteFromHours: function (isAvt, targetUtilization, fullTimeWorkingHours, hours) {
		return fullTimeWorkingHours == 0 ? 0 : (hours / fullTimeWorkingHours);
	},

	addResourceToGraph: function (resourceName, resourceId, resourceScheduleSerializedData) {
		var selectedProfile = rmChart.resourceScheduleCache[resourceId];
		if (selectedProfile) {
			selectedProfile.isSelected = true;
		}
		if (!rmChart.searchedResourceAvailabilityCache[resourceId]) {
			rmChart.searchedResourceAvailabilityCache[resourceId] = rmChart.getResourceAvailabilityFromMonthYearData(resourceName, resourceId, $.parseJSON(resourceScheduleSerializedData));
		}
		else {
			rmChart.searchedResourceAvailabilityCache[resourceId].isSelected = true;
		}

		rmChart.drawResourceChart(rmChart.searchedResourceAvailabilityCache, rmChart.chartType.Resource, rmChart.selectedResourceDisplayType);
	},

	removeResourceFromGraph: function (resourceId) {
		var selectedResourceSchedule = rmChart.searchedResourceAvailabilityCache[resourceId];
		if (selectedResourceSchedule) {
			selectedResourceSchedule.isSelected = false;
		}

		var selectedProfile = rmChart.resourceScheduleCache[resourceId];
		if (selectedProfile) {
			selectedProfile.isSelected = false;
		}
		rmChart.drawResourceChart(rmChart.searchedResourceAvailabilityCache, rmChart.chartType.Resource, rmChart.selectedResourceDisplayType);
	},

	drawResourceChart: function (searchedResourceAvailabilityData, chartType, displayValueType) {
		var selectedRequestsJson = rmChart.getSelectedRequests(rmChart.requestScheduleCache);
		var requestDataList = rmChart.getAligedRequestSeriesForChart(selectedRequestsJson.minStartMonthYear, selectedRequestsJson.maxStopMonthYear, selectedRequestsJson.selectedItems, displayValueType);
		var combinedRequestDataList = rmChart.sumRequestSeriesData(requestDataList);
		var chartDataList = [combinedRequestDataList];
		var xLabelList = rmChart.getXAxisLabelList(selectedRequestsJson.minStartMonthYear, selectedRequestsJson.maxStopMonthYear);
		rmChart.pushSelectedResourceDataToChartData(chartDataList, searchedResourceAvailabilityData, displayValueType);

		//Avoid passing schedule data by reference. Serializing and then deserializing data creates new instance of the object and prevents chart from updating original copy of the data.
		chartDataList = JSON.parse(JSON.stringify(chartDataList));

		highChartInstance = rmChart.chartInstance[chartType];

		var displayFte = displayValueType == rmChart.displayValues.Fte;

		var yAxisLabel = "FTE";
		var digitsAfterDecimal = 2;
		switch (displayValueType) {
			case rmChart.displayValues.Fte:
				yAxisLabel = "FTE";
				digitsAfterDecimal = 2;
				break;
			case rmChart.displayValues.Hours:
				yAxisLabel = "Hours";
				digitsAfterDecimal = 0;
				break;
			case rmChart.displayValues.AverageFte:
				yAxisLabel = "Average Based FTE";
				digitsAfterDecimal = 2;
				break;
			case rmChart.displayValues.AverageHours:
				yAxisLabel = "Average Based Hours";
				digitsAfterDecimal = 0;
				break;
		}

		if (!highChartInstance) {
			var chartConfiguration = {
				renderTo: "ChartResContainer",
				chartTitle: "",
				yAxisText: yAxisLabel,
				digitsAfterDecimal: digitsAfterDecimal
			};

			highChartInstance = rmChart.createChart(xLabelList, chartDataList, chartConfiguration, chartType);
			rmChart.chartInstance[chartType] = highChartInstance;
			setTimeout(function () { rmChart.updateResourceChart(highChartInstance, xLabelList, chartDataList, yAxisLabel); }, 20);
		}
		else {
			rmChart.updateResourceChart(highChartInstance, xLabelList, chartDataList, yAxisLabel);
		}
	},

	updateResourceChart: function (highChartInstance, xLabelList, chartDataList, yAxisLabel) {
		highChartInstance.xAxis[0].update({ categories: xLabelList });

		var currentSeries;
		var outSeries = {};
		for (var index = highChartInstance.series.length - 1; index >= 0; index--) {
			currentSeries = highChartInstance.series[index];

			if (rmChart.containsId(chartDataList, currentSeries.name, outSeries)) {
				highChartInstance.series[index].update({ data: outSeries.value.data, name: currentSeries.name }, false);
			}
			else {
				highChartInstance.series[index].remove(false);
			}
		}

		$(highChartInstance.yAxis[0].axisTitle.element).text(yAxisLabel);

		for (var index = 0; index < chartDataList.length; index++) {
			if (!rmChart.containsId(highChartInstance.series, chartDataList[index].name, outSeries)) {
				highChartInstance.addSeries(chartDataList[index], false, false);
			}
		}

		rmChart.checkChartZoom(highChartInstance, xLabelList.length);

		highChartInstance.redraw();
		rm.ui.unblock();
	},

	sumRequestSeriesData: function (dataList) {
		var summedData = { name: "Requests", data: new Array(), type: "spline" };

		if (dataList) {
			var currentRequest;
			for (var index = 0, length = dataList.length; index < length; index++) {
				currentRequest = dataList[index];
				for (var dataIndex = 0, dataLength = currentRequest.data.length; dataIndex < dataLength; dataIndex++) {
					if (summedData.data[dataIndex] == undefined) {
						summedData.data[dataIndex] = 0;
					}
					summedData.data[dataIndex] += currentRequest.data[dataIndex];//add data values for all requests
				}
			}
		}

		return summedData;
	},

	pushSelectedResourceDataToChartData: function (chartDataList, resourceScheduleData, displayValueType) {
		if (chartDataList && resourceScheduleData) {
			var currentResourceSchedule;

			var dataPropertyName = "fteArray";
			switch (displayValueType) {
				case rmChart.displayValues.Fte: dataPropertyName = "fteArray";
					break;
				case rmChart.displayValues.Hours: dataPropertyName = "hoursArray";
					break;
				case rmChart.displayValues.AverageFte: dataPropertyName = "averageFteArray";
					break;
				case rmChart.displayValues.AverageHours: dataPropertyName = "averageHoursArray";
					break;
			}

			for (var key in resourceScheduleData) {
				if (resourceScheduleData.hasOwnProperty(key) && resourceScheduleData[key].isSelected) {
					currentResourceSchedule = resourceScheduleData[key];

					chartDataList.push({
						type: "column",
						name: currentResourceSchedule.resourceName,
						data: currentResourceSchedule[dataPropertyName]
						//data: (displayValueType == rmChart.displayValues.Fte) ? currentResourceSchedule.fteArray : currentResourceSchedule.hoursArray
					});
				}
			}
		}
	},

	getResourceAvailabilityFromMonthYearData: function (resourceName, resourceId, resourceScheduleData) {
		var resourceAvailabilityData = { resourceName: resourceName, fteArray: new Array(), hoursArray: new Array(), isSelected: true, averageFteArray: new Array(), averageHoursArray: new Array() };

		if (resourceScheduleData) {
			var currentMonthSchedule;

			var fte;
			for (var index = 0, length = resourceScheduleData.length; index < length; index++) {
				currentMonthSchedule = resourceScheduleData[index];
				resourceAvailabilityData.hoursArray.push(rmChart.getFormattedNumber(currentMonthSchedule.AvailabilityHours, rmChart.digitsAfterDecimalForHours));
				fte = rmChart.getFteFromHours(false, 1, currentMonthSchedule.FullTimeWorkingHours, currentMonthSchedule.AvailabilityHours);
				resourceAvailabilityData.fteArray.push(rmChart.getFormattedNumber(fte, rmChart.digitsAfterDecimalForFte));

				resourceAvailabilityData.averageHoursArray.push(rmChart.getFormattedNumber(currentMonthSchedule.AverageAvailableHours, rmChart.digitsAfterDecimalForHours));
				averageFte = rmChart.getFteFromHours(false, 1, currentMonthSchedule.FullTimeWorkingHours, currentMonthSchedule.AverageAvailableHours);
				resourceAvailabilityData.averageFteArray.push(rmChart.getFormattedNumber(currentMonthSchedule.AverageAvailableFte, rmChart.digitsAfterDecimalForFte));
			}
		}

		return resourceAvailabilityData;
	},

	selectedProfile: {
		chartDivIdPrefix: "selectedProfileChartDiv_",
		chartTitleIdPrefix: "selectedProfileChartTitle_",
		chartAccordionDivIdPrefix: "divAccord_",
		lastSelectedRequestIds: "",
		buildChart: function (selectedResourceList, startMonthYearNumber, endMonthYearNumber) {
			if (selectedResourceList) {
				rmChart.selectedProfile.hideAllResourceCharts();

				var resourceDetails;
				//loop through all resources, and show the 
				for (var index = 0, length = selectedResourceList.length; index < length; index++) {
					resourceDetails = selectedResourceList[index];
					var chartDivId = rmChart.selectedProfile.chartDivIdPrefix + resourceDetails.resourceId;
					var chartTitleLinkId = rmChart.selectedProfile.chartTitleIdPrefix + resourceDetails.resourceId;
					var chartAccordionDivId = rmChart.selectedProfile.chartAccordionDivIdPrefix + resourceDetails.resourceId;

					var currentlySelectedRequestIds = rm.grid.getSelectedIds("#queueRequests");

					if (rmChart.selectedProfile.lastSelectedRequestIds != currentlySelectedRequestIds) {
						$("#" + chartAccordionDivId).remove();
					}

					if ($("#" + chartAccordionDivId).length == 0) {
						var divScore = rmChart.selectedProfile.buildContainerForSelectedProfile(resourceDetails.resourceId, chartDivId, chartTitleLinkId, resourceDetails.chartHeading);
						$.rm.search.DisplayViewProfileMatch(resourceDetails.resourceId, divScore);
						rmChart.selectedProfileDisplayType = rmChart.displayValues.Fte;
						rmChart.showMyStaffChart(rmChart.chartType.SelectedProfile, resourceDetails, chartDivId, chartTitleLinkId, false);

						rmChart.selectedProfile.lastSelectedRequestIds = currentlySelectedRequestIds;
					}
					else {
						$("#" + chartAccordionDivId).show();
					}
				}
			}
		},

		hideAllResourceCharts: function () {
			for (var key in rmChart.resourceScheduleCache) {
				if (rmChart.resourceScheduleCache.hasOwnProperty(key) && !rmChart.resourceScheduleCache[key].isSelected) {
					$("#" + rmChart.selectedProfile.chartAccordionDivIdPrefix + key).hide();
				}
			}
		},

		buildContainerForSelectedProfile: function (resourceId, chartDivId, chartTitleLinkId, chartTitle) {
			//<div id="RequestScheduleAccord" class="graphHeight">
			//	<h3  class="graphTitleHeight">
			//		<a href="#" id="a1">Request Schedule</a>&nbsp;&nbsp;
			//		<span id="SpanFTE_Id" class="resourceSearchFteButton graphActiveButton" onclick="rmChart.changeDisplayHoursFte(this, event, 0, true)">&nbsp;FTE&nbsp;</span>&nbsp;
			//		<span class="resourceSearchHoursButton" onclick="rmChart.changeDisplayHoursFte(this, event, 0, false)">Hours</span></h3>
			//	<div id="ChartReqContainer" class="ChartReqContainer graphInnerHeight2">&nbsp;</div>
			//</div>

			var accordionDiv = $("<div>", { id: rmChart.selectedProfile.chartAccordionDivIdPrefix + resourceId }).css({ paddingBottom: "25px" });
			var accordionTitle = $("<h3>").html('<a href="#" id="aResourceProfile_' + resourceId + '">' + chartTitle + '</a>&nbsp;&nbsp;' +
				'<span rm_resourceId="' + resourceId + '" class="resourceSearchFteButton leftFTEbuttonProfiles graphActiveButton graphActionButton" onclick="rmChart.changeDisplayHoursFte(this, event, rmChart.chartType.SelectedProfile, true)">&nbsp;FTE&nbsp;</span>&nbsp;' +
				'<span rm_resourceId="' + resourceId + '" class="resourceSearchHoursButton leftHoursbuttonProfiles graphActionButton" onclick="rmChart.changeDisplayHoursFte(this, event, rmChart.chartType.SelectedProfile, false)">Hours</span>');

			accordionDiv.append(accordionTitle);

			var chartDiv = $("<div>", { id: chartDivId });
			var chartCell = $("<td>", { valign: "top" }).css({ width: "79%" }).append(chartDiv);

			var scoreCell = $("<td>", { valign: "top", "class": "tdscore" }).css({ width: "20%" });
			var divScore = $("<div>").css({
				overflowX: 'hidden',
				overflowY: 'auto',
				position: 'relative',
				height: '290px'
			});

			scoreCell.append(divScore);

			var table = $("<table>").css({ width: "100%", height: "auto" }).append("<tr>").append(chartCell).append(scoreCell);
			var divContent = $("<div>").append(table);
			accordionDiv.append(divContent);

			$("#ChartCompContainer").append(accordionDiv);
			setTimeout(function () { accordionDiv.accordion({ collapsible: true }); }, 50);

			return divScore;
		}
	}
};