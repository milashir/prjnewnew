﻿///<reference path="../Common/RmHelper.js"/>
$(document).ready(function () {
    $(document).ajaxStop(function () { rm.ui.unblock(); });
    $(document).ajaxStart(function () { rm.ui.block(); });

    announcementNs.init();
});

var announcementNs = {
    changesContainerSelector: "#announcementChanges",
    changesGridSelector: "#tblChanges",
    gridSelector: "#tblData",
    formContainerSelector: "#formContainer",
    formHeaderSelector: "#formHeader",
    txtEffectiveDateSelector: "#txtEffectiveDate",
    txtExpiryDateSelector: "#txtExpiryDate",
    txtTitleSelector: "#txtTitle",
    formInputSelector: "#formContainer input,#formContainer textarea",
    jsonSelectorForDirtyForm: function () { return { items: [{ selector: announcementNs.formInputSelector, dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },
    rdbAnnouncementTypeSelector: "[name=rdbAnnouncementType]",
    rdbAnnouncementTypeCheckedSelector: function () { return announcementNs.rdbAnnouncementTypeSelector + ":checked"; },
    rdbAnnouncementTypeInformationSelector: function () { return announcementNs.rdbAnnouncementTypeSelector + "[value=" + AnnouncementType_E.Information + "]"; },
    errorClass: "q_validation_error",
    oldValueAttribute: "oldValue",
    cbOrganizationalUnitContainerSelector: "#divOrgUnit",
    getCbOrganizationalUnitSelector: function () { return announcementNs.cbOrganizationalUnitContainerSelector + " [type=checkbox]:checked" },
    cbSharepointRoleContainerSelector: "#divSharePointRole",
    getCbSharepointRoleSelector: function () { return announcementNs.cbSharepointRoleContainerSelector + " [type=checkbox]:checked" },
    cbRegionContainerSelector: "#divRegion",
    getCbRegionSelector: function () { return announcementNs.cbRegionContainerSelector + " [type=checkbox]:checked" },
    divFilterSectionSelector: "#divFilterSection",
    cbApplyFiltersSelector: "#cbApplyFilters",
    rbTypeContainerSelector: "#divType",
    _sharepointRoleList: null,
    _organizationanUnitList: null,
    _regionList: null,
    _editItem: null,

    showAnnouncementChagnes: function () {
        var dialogHeight = $(document).height() - 100;
        var dialogWidth = $(document).width() - 100;

        $(announcementNs.changesContainerSelector).dialog({
            modal: true,
            title: "Announcement History",
            width: dialogWidth,
            height: dialogHeight,
            resizable: true,
            position: {
                my: "center top",
                at: "center top",
                of: "#aspnetForm"
            }
        }).removeClass("hideMe");

        $(announcementNs.changesGridSelector).jqGrid({
            url: rm.ajax.adminSvcUrl + "GetAnnouncementChangeHistory",
            datatype: 'json',
            mtype: 'POST',
            ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
            jsonReader: rm.grid.getJqGridJsonReader(),
            loadonce: true,
            shrinkToFit: false,
            height: dialogHeight - 120,
            width: dialogWidth - 20,
            forceFit: true,
            pager: '#pagerChanges',
            multiselect: false,
            colModel: [
							{ name: 'SavedDate', index: 'SavedDate', label: 'Saved Date', width: 100 },
							{ name: 'Title', index: 'Title', label: 'Announcement Title', width: 400 },
							{ name: 'SavedBy', index: 'SavedBy', label: 'Saved By', width: 200 }
            ],
            viewsortcols: [true, 'vertical', true],
            sortname: 'SavedDate',
            sortorder: 'asc',
            beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); }
        });

        $(announcementNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });

    },

    isInEditMode: function () {
        return announcementNs._editItem != null;
    },

    getSharepointRoleList: function () {
        if (announcementNs._sharepointRoleList == null) {
            rm.ajax.utilitySvcSyncPost("GetSharepointRoleList", {}, function (data) { announcementNs._sharepointRoleList = data; });
        }

        return announcementNs._sharepointRoleList;
    },

    getRegionList: function () {
        if (announcementNs._regionList == null) {
            rm.ajax.utilitySvcSyncPost("GetRegionList", {}, function (data) { announcementNs._regionList = data; });
        }

        return announcementNs._regionList;
    },

    getOrganizationalUnitList: function () {
        if (announcementNs._organizationanUnitList == null) {
            rm.ajax.utilitySvcSyncGet("Master/GetOrganizationalUnits", {}, function (data) { announcementNs._organizationanUnitList = data; });
        }

        return announcementNs._organizationanUnitList;
    },

    bindClearError: function () {
        var selector = announcementNs.txtEffectiveDateSelector + "," + announcementNs.txtExpiryDateSelector + "," + announcementNs.txtTitleSelector + "," + announcementNs.txtTitleSelector;
        $(selector).keypress(function () { rm.validation.clearError($(this)); });
        $(selector).change(function () { rm.validation.clearError($(this)); });
        $(announcementNs.rbTypeContainerSelector + " > [type=radio]").change(function () { rm.validation.clearError($(announcementNs.rbTypeContainerSelector)); });
    },

    init: function () {
        $(announcementNs.txtEffectiveDateSelector).qDatepicker();
        $(announcementNs.txtExpiryDateSelector).qDatepicker();

        rm.validation.bindMaxLengthForTextArea();
        announcementNs.bindClearError(announcementNs.rbTypeContainerSelector);

        $("#AnnouncementsNav").addClass("left-static-selected-menu");
        rm.runtimeValues.helpPageUrl = "#";

        announcementNs.buildGrid();
        announcementNs.buildOrganizationalUnitCheckckBoxList();
        announcementNs.buildSharepointRoleCheckckBoxList();
        announcementNs.buildRegionCheckBoxList();
        announcementNs.bindApplyFilterClick();

        $(document).keypress(announcementNs.handleFormDirtyChange);
        $(document).click(announcementNs.handleFormDirtyChange);

        rm.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, announcementNs.jsonSelectorForDirtyForm());
    },

    handleFormDirtyChange: function () { rm.ui.ribbon.delayedRefresh(); },

    getSelectedGridRowIdArray: function () { return $(announcementNs.gridSelector).getGridParam('selarrrow'); },

    editViaRibbon: function () {
        var selectedIds = announcementNs.getSelectedGridRowIdArray();
        if (selectedIds.length == 0) {
            alert("Select an announcement to edit.");
        }
        else if (selectedIds.length == 1) {
            announcementNs.editAnnouncement(selectedIds[0]);
        }
        else {
            alert("Select only one announcement to edit.");
        }
    },

    editAnnouncement: function (id) {
        rm.ajax.adminSvcAsyncPost("GetAnnouncementDetailsById", { announcementId: id }, function (response) {
            announcementNs._editItem = response;
            announcementNs.showForm();
            announcementNs.showValuesToEdit(announcementNs._editItem);

            setTimeout(function () {
                rm.formStatus.clearDirty(announcementNs.jsonSelectorForDirtyForm());
                rm.ui.ribbon.delayedRefresh();
            }, 20);
        });
    },

    enableAndExpandFilters: function () {
        $(announcementNs.divFilterSectionSelector).accordion("enable");
        rm.ui.openCollapsiblePanel(announcementNs.divFilterSectionSelector);
    },

    disableAndCollapseFilters: function () {
        rm.ui.closeCollapsiblePanel(announcementNs.divFilterSectionSelector);
        $(announcementNs.divFilterSectionSelector).accordion("disable");
    },

    bindApplyFilterClick: function () {
        $(announcementNs.cbApplyFiltersSelector).click(function () {
            if ($(this).is(":checked")) {
                announcementNs.enableAndExpandFilters();
            }
            else {
                announcementNs.disableAndCollapseFilters();
                announcementNs.clearFilters();
            }
        });

    },

    addCheckboxesToUi: function (checkboxIdPrefix, containerSelector, fullItemList, checkedItemList) {
        $(containerSelector).empty();

        if (fullItemList && fullItemList.length > 0) {
            $.each(fullItemList, function (index, element) {
                var checkBoxId = checkboxIdPrefix + element.Id;

                $(containerSelector).append($("<input/>", { value: element.Id, id: checkBoxId, dataValue: element.Id, type: "checkbox" }));
                $(containerSelector).append($("<label/>", { "for": checkBoxId, text: element.Name })).append("<br/>");
            });
        }
    },

    checkCheckboxes: function (containerSelector, checkedItemList) {
        $.each($(containerSelector + " > [type=checkbox]"), function (index, element) {
            var checkbocObj = $(element);
            if ($.inArray(parseInt(checkbocObj.attr("dataValue")), checkedItemList) !== -1) {
                checkbocObj.prop("checked", true);
            }
        });
    },

    buildOrganizationalUnitCheckckBoxList: function () {
        announcementNs.addCheckboxesToUi("ou", announcementNs.cbOrganizationalUnitContainerSelector, announcementNs.getOrganizationalUnitList());
    },

    buildSharepointRoleCheckckBoxList: function () {
        announcementNs.addCheckboxesToUi("sr", announcementNs.cbSharepointRoleContainerSelector, announcementNs.getSharepointRoleList());
    },

    buildRegionCheckBoxList: function () {
        announcementNs.addCheckboxesToUi("reg", announcementNs.cbRegionContainerSelector, announcementNs.getRegionList());
    },

    isFormDirty: function () {
        return rm.formStatus.isDirty(announcementNs.jsonSelectorForDirtyForm());
    },

    isCreateButtonEnabled: function () { return !$(announcementNs.formContainerSelector).is(":visible"); },

    isUpdateButtonEnabled: function () { return !$(announcementNs.formContainerSelector).is(":visible") && rm.grid.hasSingleRowSelected(announcementNs.gridSelector); },

    isSaveButtonEnabled: function () { return !announcementNs.isCreateButtonEnabled() && announcementNs.isFormDirty(); },

    isCancelButtonEnabled: function () { return announcementNs.isSaveButtonEnabled(); },

    isCloseButtonEnabled: function () { return !announcementNs.isCreateButtonEnabled(); },

    isDeleteButtonEnabled: function () { return rm.grid.hasRowsSelected(announcementNs.gridSelector); },

    create: function () {
        rm.grid.uncheckAllGridRows(announcementNs.gridSelector);
        announcementNs.showForm();
        setTimeout(function () {
            rm.formStatus.clearDirty(announcementNs.jsonSelectorForDirtyForm());
            rm.ui.ribbon.delayedRefresh();
        }, 10);
    },

    showValuesToEdit: function (editItem) {
        $(announcementNs.txtTitleSelector).val(editItem.Title);
        $(announcementNs.txtEffectiveDateSelector).val(editItem.EffectiveDate);
        $(announcementNs.txtExpiryDateSelector).val(editItem.ExpiryDate);
        $(announcementNs.rdbAnnouncementTypeSelector + "[value=" + editItem.AnnouncementType + "]").prop("checked", true);

        announcementNs.checkCheckboxes(announcementNs.cbOrganizationalUnitContainerSelector, editItem.OrganizationalUnitIdList);
        announcementNs.checkCheckboxes(announcementNs.cbSharepointRoleContainerSelector, editItem.SharePointRoleIdList);
        announcementNs.checkCheckboxes(announcementNs.cbRegionContainerSelector, editItem.RegionIdList);

        if ((editItem.OrganizationalUnitIdList && editItem.OrganizationalUnitIdList.length > 0) ||
				(editItem.SharePointRoleIdList && editItem.SharePointRoleIdList.length > 0) ||
				(editItem.RegionIdList && editItem.RegionIdList.length > 0)
			) {
            $(announcementNs.cbApplyFiltersSelector).prop("checked", true);
            setTimeout(function () { announcementNs.enableAndExpandFilters(); }, 20);
        }
        else {
            $(announcementNs.cbApplyFiltersSelector).prop("checked", false);
            announcementNs.clearFilters();
            setTimeout(function () { announcementNs.disableAndCollapseFilters(); }, 20);
        }
    },

    showForm: function () {
        announcementNs.clearForm();
        $(announcementNs.formContainerSelector).removeClass("hideMe");
        $(announcementNs.formHeaderSelector).html(announcementNs.isInEditMode() ? "Modify Announcement:" : "Create Announcement:");

        $(announcementNs.divFilterSectionSelector).accordion({
            collapsible: true
        });

        if (!announcementNs.isInEditMode()) {
            setTimeout(function () { announcementNs.disableAndCollapseFilters(); }, 10);
        }
    },

    isFormValid: function () {
        var isValid = true;

        if ($.trim($(announcementNs.txtTitleSelector).val()) == "") {
            isValid = true;
        }
        return isValid;
    },

    getSelectedItemIdList: function (selector) {
        var selectedItemList = new Array();

        $.each($(selector), function (index, element) {
            selectedItemList.push($(element).attr("dataValue"));
        });

        return selectedItemList;
    },

    getOrganizationalUnitIdList: function () {
        return announcementNs.getSelectedItemIdList(announcementNs.getCbOrganizationalUnitSelector());
    },

    getSharepointRoleIdList: function () {
        return announcementNs.getSelectedItemIdList(announcementNs.getCbSharepointRoleSelector());
    },

    getRegionIdList: function () {
        return announcementNs.getSelectedItemIdList(announcementNs.getCbRegionSelector());
    },

    getFormData: function () {
        return {
            id: announcementNs.isInEditMode() ? announcementNs._editItem.id : null,
            Title: $(announcementNs.txtTitleSelector).val(),
            EffectiveDate: $(announcementNs.txtEffectiveDateSelector).val(),
            ExpiryDate: $(announcementNs.txtExpiryDateSelector).val(),
            AnnouncementType: $(announcementNs.rdbAnnouncementTypeCheckedSelector()).val(),
            OrganizationalUnitIdList: announcementNs.getOrganizationalUnitIdList(),
            SharePointRoleIdList: announcementNs.getSharepointRoleIdList(),
            RegionIdList: announcementNs.getRegionIdList()
        };
    },

    clearFilters: function () {
        $(announcementNs.cbOrganizationalUnitContainerSelector + " > [type=checkbox]").attr("checked", false);
        $(announcementNs.cbSharepointRoleContainerSelector + " > [type=checkbox]").attr("checked", false);
        $(announcementNs.cbRegionContainerSelector + " > [type=checkbox]").attr("checked", false);
    },

    closeForm: function () {
        $(announcementNs.formContainerSelector).addClass("hideMe");
        rm.ui.ribbon.delayedRefresh();
        announcementNs._editItem = null;
    },

    clearForm: function () {
        if (announcementNs.isInEditMode()) {
            $(announcementNs.txtTitleSelector).val($(announcementNs.txtTitleSelector).attr(announcementNs.oldValueAttribute)).removeClass(announcementNs.errorClass);
            $(announcementNs.txtEffectiveDateSelector).val($(announcementNs.txtEffectiveDateSelector).attr(announcementNs.oldValueAttribute)).removeClass(announcementNs.errorClass);
            $(announcementNs.txtExpiryDateSelector).val($(announcementNs.txtExpiryDateSelector).attr(announcementNs.oldValueAttribute)).removeClass(announcementNs.errorClass);
            $(announcementNs.rbTypeContainerSelector).removeClass(announcementNs.errorClass);
            setTimeout(function () { rm.validation.setCharactersLeftCount($(announcementNs.txtTitleSelector)); }, 10);
        }
        else {
            $(".CharLeftValue").html($(announcementNs.txtTitleSelector).attr("maxLength"));
            $(announcementNs.txtTitleSelector).val("").removeClass(announcementNs.errorClass);
            $(announcementNs.txtEffectiveDateSelector).val("").removeClass(announcementNs.errorClass);
            $(announcementNs.txtExpiryDateSelector).val("").removeClass(announcementNs.errorClass);
            $(announcementNs.rbTypeContainerSelector).removeClass(announcementNs.errorClass);
            $(announcementNs.rdbAnnouncementTypeInformationSelector()).prop("checked", true);
            $(announcementNs.cbApplyFiltersSelector).prop("checked", false);

            if ($(announcementNs.divFilterSectionSelector).hasClass("ui-accordion")) {
                announcementNs.disableAndCollapseFilters();
                announcementNs.clearFilters();
            }
        }
    },

    updateAnnouncementDataInGrid: function (data) {
        $(announcementNs.gridSelector).setRowData(data.id, {
            Title: data.Title,
            EffectiveDate: data.EffectiveDate,
            ExpiryDate: data.ExpiryDate,
            AnnouncementType: data.AnnouncementTypeName
        });
    },

    addNewAnnouncementToGrid: function (announcementData) {
        var grid = $(announcementNs.gridSelector);
        grid.addRowData(announcementData.id, [{
            Title: announcementData.Title,
            EffectiveDate: announcementData.EffectiveDate,
            ExpiryDate: announcementData.ExpiryDate,
            AnnouncementType: announcementData.AnnouncementTypeName
        }], "last");

        rm.grid.rowData.addData(announcementNs.gridSelector, announcementData);
    },

    handleFailedResponse: function (response) {
        if (response.ContainsValidationErrors) {
            rm.validation.processErrorMessages(response.ValidationErrors, "", "");
        }
        return response.ContainsValidationErrors;
    },

    save: function () {
        if (announcementNs.isFormValid()) {
            var wsMethodName = "";
            var successMessage = "";
            if (announcementNs.isInEditMode()) {
                wsMethodName = "UpdateAnnouncement";
                successMessage = "Announcement updated successfully.";
            }
            else {
                wsMethodName = "CreateAnnouncement";
                successMessage = "Announcement created successfully.";
            }

            rm.ajax.adminSvcAsyncPost(wsMethodName, { announcement: announcementNs.getFormData() }, function (response) {
                if (!announcementNs.handleFailedResponse(response)) {
                    if (announcementNs.isInEditMode()) {
                        announcementNs.updateAnnouncementDataInGrid(response.RequestExecutionStatus.AdditionalData);
                    }
                    else {
                        announcementNs.addNewAnnouncementToGrid(response.RequestExecutionStatus.AdditionalData);
                    }
                    announcementNs.clearForm();
                    announcementNs.closeForm();
                    setTimeout(function () {
                        rm.formStatus.clearDirty(announcementNs.jsonSelectorForDirtyForm());
                        rm.ui.ribbon.delayedRefresh();
                    }, 10);
                    rm.ui.messages.showSuccess(successMessage);
                }
            });
        }
    },

    cancel: function () {
        var isDirty = announcementNs.isFormDirty();
        if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
            announcementNs.clearForm();
            setTimeout(function () {
                rm.formStatus.clearDirty(announcementNs.jsonSelectorForDirtyForm());
                rm.ui.ribbon.refresh();
            }, 10);
        }
    },

    close: function () {
        var isDirty = announcementNs.isFormDirty();
        if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
            announcementNs.clearForm();
            announcementNs.closeForm();
        }
    },


    deleteAnnouncement: function () {
        if (confirm(Resources.ConfirmAnnouncementDelete)) {
            var selectedAnnouncementIds = $(announcementNs.gridSelector).getGridParam('selarrrow');
            if (selectedAnnouncementIds.length < 0) {
                alert("Please select at least one Announcement to delete.");
            }
            else {
                rm.ajax.adminSvcAsyncPost("DeleteAnnouncements", { announcementIdList: selectedAnnouncementIds }, function () {
                    rm.grid.removeAllCheckedRows(announcementNs.gridSelector);
                    rm.ui.messages.showSuccess('Announcement(s) deleted successfully.');
                });
            }
        }
    },

    buildGrid: function () {
        var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
        gridToolsConfig.showManageColumns = false;
        gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.Announcements };
        rm.grid.showGridTools(announcementNs.gridSelector, gridToolsConfig);
        $(announcementNs.gridSelector).jqGrid({
            url: rm.ajax.adminSvcUrl + "GetAllAnnouncements",
            datatype: 'json',
            mtype: 'POST',
            ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
            jsonReader: rm.grid.getJqGridJsonReader(),
            //Grid options
            loadonce: false,
            shrinkToFit: false,
            height: window.screen.height - 525,
            width: window.screen.width - 216,
            forceFit: true,
            pager: '#tblPager',
            multiselect: true,
            colModel: [
							{ name: 'Title', index: 'Title', label: 'Title', width: 400 },
							{ name: 'EffectiveDate', index: 'EffectiveDate', label: 'Effective Date', width: 100 },
							{ name: 'ExpiryDate', index: 'ExpiryDate', label: 'Expiry Date', width: 100 },
							{ name: 'AnnouncementType', index: 'AnnouncementType', label: 'Announcement Type', width: 140 },
            ],
            viewsortcols: [true, 'vertical', true],
            sortname: 'EffectiveDate',
            sortorder: 'asc',
            beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
            onPaging: function () { rm.ui.ribbon.delayedRefresh(); },
            ondblClickRow: function (id) {
                //announcementNs.editAnnouncement(id);
            },
            onSelectRow: function (id) {
                if (announcementNs.getSelectedGridRowIdArray().length != 1) {
                    announcementNs.clearForm();
                    announcementNs.closeForm();
                }
                rm.ui.ribbon.refresh();
            },
            onSelectAll: function (rowIdxArray, sts) { rm.ui.ribbon.refresh(); },
            gridComplete: function (data) {
                $("#tblData").find("a").click(function () {
                    window.open($(this).attr('href'));
                    return false;
                });
            },
            serializeGridData: function (postData) {
                return rm.grid.serializeGridData(postData);
            },
            beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("tblData"); },
            loadComplete: function (data) { rm.grid.rowData.attachAllRowsData(announcementNs.gridSelector, data); }
        });
        $(announcementNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
    }
};