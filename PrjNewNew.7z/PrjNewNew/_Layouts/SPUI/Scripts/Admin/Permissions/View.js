﻿$(document).ready(function () {
	permissionsNs.init();
	rm.runtimeValues.helpPageUrl = "Role Permissions.aspx";
});

var permissionsNs = {
	permissionGridSelector: "#tblData",
	functionGridSelector: "#tblDataFn",

	init: function () {
		rm.runtimeValues.helpPageUrl = "#";
		$("#Link_ViewPagePermissions").addClass("left-static-selected-menu");
		permissionsNs.buildPermissionGrid();
		permissionsNs.buildFunctionGrid();
	},
	getFilterFromJson: function (json) {
		var filter = "";
		var valueArray = new Array();
		for (var prop in json) {
			if (json.hasOwnProperty(prop)) {
				valueArray.push(json[prop]);
			}
		}
		valueArray.sort().forEach(function (value) { filter += ";" + value + ":" + value; });
		return filter;
	},
	getRoleFilter: function () {
		return ":All" + permissionsNs.getFilterFromJson(SharepointRole);
	},
	getFunctionFilter: function () {
		return ":All" + permissionsNs.getFilterFromJson(RmFunction);
	},
	getRuleFilter: function () {
		return permissionsNs.getRoleFilter() + permissionsNs.getFilterFromJson(CustomFunctionPermissionRules);
	},
	buildPermissionGrid: function () {
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ViewPagePermissions, GridId: 1 };
		rm.grid.showGridTools(permissionsNs.permissionGridSelector, gridToolsConfig);
		$(permissionsNs.permissionGridSelector).jqGrid({
		    url: rm.ajax.adminSvcUrl + "GetAllPagePermissions",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			//Grid options
			loadonce: true,
			shrinkToFit: false,
			height: rm.ui.getMaxGridHeight() - 80,
			width: 500,
			autowidth: false,
			forceFit: true,
			pager: '#tblPager',
			multiselect: false,
			colModel: [
				{ name: 'PageName', index: 'PageName', label: 'Page Name', width: 225, searchoptions: { sopt: ['bw'] } },
				{ name: 'UserRole', index: 'UserRole', label: 'RM Role', width: 200, stype: 'select', searchoptions: { sopt: ['eq'], value: permissionsNs.getRoleFilter() } }
			],
			viewsortcols: [true, 'vertical', true],
			sortorder: 'asc',
			serializeGridData: function (postData) {
				return rm.grid.serializeGridData(postData);
			},
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("tblData"); },
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData(permissionsNs.permissionGridSelector, data); }
		});
		$(permissionsNs.permissionGridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true, defaultSearch: "cn" });
	},
	buildFunctionGrid: function () {
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ViewPagePermissions, GridId: 2 };
		rm.grid.showGridTools(permissionsNs.functionGridSelector, gridToolsConfig);
		$(permissionsNs.functionGridSelector).jqGrid({
		    url: rm.ajax.adminSvcUrl + "GetAllRmFunctionPermissions",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			//Grid options
			loadonce: true,
			shrinkToFit: false,
			height: rm.ui.getMaxGridHeight() - 80,
			width: 430,
			autowidth: true,
			forceFit: false,
			pager: '#tblPagerFn',
			multiselect: false,
			colModel: [
				{ name: 'FunctionName', index: 'FunctionName', label: 'Function Name', width: 325, stype: 'select', searchoptions: { sopt: ['eq'], value: permissionsNs.getFunctionFilter() } },
				{ name: 'UserRole', index: 'UserRole', label: 'RM Role/<br/>Custom Rule', width: 350, stype: 'select', searchoptions: { sopt: ['eq'], value: permissionsNs.getRuleFilter() } }
			],
			viewsortcols: [true, 'vertical', true],
			sortorder: 'asc',
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			serializeGridData: function (postData) {
				return rm.grid.serializeGridData(postData);
			},
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("tblDataFn"); },
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData(permissionsNs.functionGridSelector, data); }
		});
		$(permissionsNs.functionGridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true, defaultSearch: "cn" });
	}
};