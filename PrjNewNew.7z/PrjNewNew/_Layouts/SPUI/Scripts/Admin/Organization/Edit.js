﻿///<reference path="../Common/RmHelper.js"/>
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });
	editOrgNs.init();
});

var editOrgNs = {
	qipDisconnectRRTOrgUnitCountryDataGridSelector: "#QipDisconnectRRTOrgUnitCountryData",
	hdnwasOUEnabledSelector: "[id$=hdnWasOrgUnitEnabled]",
	wasOUEnabled: false,
	initialValueDataAttribute: "initial",
	errorClass: "q_validation_error",
	txtOrgNameSelector: "[id$=txtOrgName]",
	cbIsOrgEnabledSelector: "[id$=cbIsOrgEnabled]",
	txtOrgShortNameSelector: "[id$=txtOrgShortName]",
	txtOrgUnitNameSelector: "[id$=txtOrgUnitName]",
	txtOrgUnitPpmNameSelector: "[id$=txtOrgUnitPpmName]",
	txtOrgUnitSuffixSelector: "[id$=txtOrgUnitSuffix]",
	txtGlobalWeeklyHoursSelector: "[id$=txtGlobalWeeklyHours]",
	cbIsOrgUnitEnabledSelector: "[id$=cbIsOrgUnitEnabled]",
	cbAllowProjectCreationSelector: "[id$=cbAllowProjectCreation]",
	cbProjOrgUnit: "[id$=cbProjOrgUnit]",
	hdnOrgIdSelector: "[id$=hdnOrgId]",
	hdnOrgUnitIdSelector: "[id$=hdnOrgUnitId]",
	hdnFancyTreeChangedSelector: "[id$=hdnFancyTreeChanged]",
	ddlResourceTypesSelector: "#ddlAllRRTs",
	ddlCountriesSelector: "#ddlAllCountries",
	txtMinQipVersionSelector: "[id$=txtMinQipVersion]",
	hdnHasAccessToEditOrgSelector: "[id$=HasAccessToEditOrg]",
	allResourceTypesData: [],
	allCountriesData: [],

	allowEdit: function () { return $(editOrgNs.hdnHasAccessToEditOrgSelector).val() == "1"; },
	getOrganizationId: function () {
		return $(editOrgNs.hdnOrgIdSelector).val()
	},
	removeError: function (elementSelector) {
		if (editOrgNs.getSelectedProjectMilestoneIds().length > 0) {
			var elem = $(elementSelector);
			elem.removeClass("q_validation_error");
			elem.attr("title", "");
		}
	},
	getOrganizationuUnitId: function () { return $(editOrgNs.hdnOrgUnitIdSelector).val() },
	formInputSelector: "#formContainer input,#formContainer select:visible,#hdnFancyTreeChanged,#ddlAllRRTs,#ddlAllCountries,#txtMinQipVersion",
	projectMilestonesMapFancyTreeDivSelector: "#divProjectMilestonesMapFancyTree",
	_orgMileStoneDataList: null,
	jsonSelectorForDirtyForm: function () {
		return { items: [{ selector: editOrgNs.formInputSelector, dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
	},

	isSaveButtonEnabled: function () {
		return editOrgNs.isFormDirty();
	},
	isDeleteButtonEnabled: function () {
		return $(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).getGridParam('selarrrow').length > 0;
	},

	isCloseButtonEnabled: function () {
		return true;
	},

	isCancelButtonEnabled: function () {
		return editOrgNs.isFormDirty();
	},
	bindClearError: function () {
		var selector = editOrgNs.txtOrgNameSelector + "," + editOrgNs.txtOrgShortNameSelector + "," + editOrgNs.txtOrgUnitNameSelector + "," + editOrgNs.txtOrgUnitSuffixSelector + "," + editOrgNs.txtOrgUnitPpmNameSelector + "," + editOrgNs.cbIsOrgUnitEnabledSelector + "," + editOrgNs.cbAllowProjectCreationSelector + "," + editOrgNs.cbIsOrgEnabledSelector + "," + editOrgNs.hdnFancyTreeChangedSelector + "," + editOrgNs.cbProjOrgUnit + "," + editOrgNs.txtGlobalWeeklyHoursSelector + "," + editOrgNs.ddlCountriesSelector + "," + editOrgNs.ddlResourceTypesSelector + "," + editOrgNs.txtMinQipVersionSelector;
		$(selector).bind("keydown change", function () { rm.validation.clearError($(this)); editOrgNs.handleFormDirtyChange(); });
		$(selector).bind("click", function () { editOrgNs.handleFormDirtyChange(); });
	},
	bindDirty: function () { $.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, editOrgNs.jsonSelectorForDirtyForm()); },
	isFormDirty: function () {
		return $.formStatus.isDirty(editOrgNs.jsonSelectorForDirtyForm()) || $(editOrgNs.hdnFancyTreeChangedSelector).val() == "1";
	},
	handleFormDirtyChange: function () { rm.ui.ribbon.delayedRefresh(); },
	clearDirty: function () {
		setTimeout(function () {
			$.formStatus.clearDirty(editOrgNs.jsonSelectorForDirtyForm());
			$(editOrgNs.hdnFancyTreeChangedSelector).val("0");
		}, 20);
	},
	isFormValid: function () {
		var isValid = true;
		//Clear error messages.
		rm.validation.clearError($(editOrgNs.txtMinQipVersionSelector));
		rm.validation.clearError($("#ddlAllRRTs").next('.ui-multiselect').find('span').last());
		rm.validation.clearError($("#ddlAllCountries").next('.ui-multiselect').find('span').last());
		$.each($("[IsMandatory]"), function (index, uiElement) {
			var elemetnObj = $(uiElement);
			if ($.trim(elemetnObj.val()) == "") {
				isValid = false;
				rm.validation.addError(elemetnObj, elemetnObj.attr("ErrorMessage"));
			}
		});
		if (!rmCommon.validateDecimal($(editOrgNs.txtGlobalWeeklyHoursSelector).val())) {
			rm.validation.addError($(editOrgNs.txtGlobalWeeklyHoursSelector), "Only Numerics upto 2 Decimal Points are allowed for this field.");
			isValid = false;
		}
		if ($(editOrgNs.txtOrgUnitSuffixSelector).val().indexOf(" ") != -1) {
			rm.validation.addError($(editOrgNs.txtOrgUnitSuffixSelector), "Blank spaces are not allowed in Organizational Unit Suffix");
			isValid = false;
		}
		var suffixObj = $(editOrgNs.txtOrgUnitSuffixSelector);
		if ($(editOrgNs.cbAllowProjectCreationSelector).is(":checked") && $.trim(suffixObj.val()) == "") {
			isValid = false;
			rm.validation.addError(suffixObj, suffixObj.attr("ErrorMessage"));
		}
		//Single Field Check and Alert
		if ($(editOrgNs.ddlResourceTypesSelector).val() == null || $(editOrgNs.ddlCountriesSelector).val() == null || $.trim($(editOrgNs.txtMinQipVersionSelector).val()) == "") {
			if (!($(editOrgNs.ddlResourceTypesSelector).val() == null && $(editOrgNs.ddlCountriesSelector).val() == null && $.trim($(editOrgNs.txtMinQipVersionSelector).val()) == "")) {
				var alertMessage = "";
				if ($(editOrgNs.ddlResourceTypesSelector).val() == null) {
					alertMessage = alertMessage + " ResourceType(s),";
					rm.validation.addError($("#ddlAllRRTs").next('.ui-multiselect').find('span').last(), "Please Select Resource Type(s).");
				}
				if ($(editOrgNs.ddlCountriesSelector).val() == null) {
					alertMessage = alertMessage + " Country(s),";
					rm.validation.addError($("#ddlAllCountries").next('.ui-multiselect').find('span').last(), "Please Select Country(s).");
				}
				if ($.trim($(editOrgNs.txtMinQipVersionSelector).val()) == "") {
					alertMessage = alertMessage + " MinQipVersion,";
					rm.validation.addError($(editOrgNs.txtMinQipVersionSelector), "Please Select Min Qip Version.");
				}
				alert("Please Select " + alertMessage.slice(1, -1) + " . "); //Alert since the error cant be bind to Multi Select Dropdown List
				isValid = false;
			}
		}
		//Validation when 2 fields out of 3 fields have value
		if ($(editOrgNs.ddlResourceTypesSelector).val() == null || $(editOrgNs.ddlCountriesSelector).val() == null) {
			if ($.trim($(editOrgNs.txtMinQipVersionSelector).val()) != "") {
				rm.validation.addError($(editOrgNs.txtMinQipVersionSelector), "When no Country(s) and ResourceType(s) is selected, this field must not have any value.");
				isValid = false;
			}
		}
		else {
			if ($(editOrgNs.ddlResourceTypesSelector).val().length > 0 && $(editOrgNs.ddlCountriesSelector).val().length > 0) {
				if (!rmCommon.validateDecimal($(editOrgNs.txtMinQipVersionSelector).val())) {
					rm.validation.addError($(editOrgNs.txtMinQipVersionSelector), "Only Float Values upto 2 Decimal Points are allowed for this field.");
					isValid = false;
				}

				if ($.trim($(editOrgNs.txtMinQipVersionSelector).val()) == "") {
					rm.validation.addError($(editOrgNs.txtMinQipVersionSelector), "Please specify MinQipVersion.");
					isValid = false;
				}
			}
		}
		if (editOrgNs.getSelectedProjectMilestoneIds().length < 1) {
			isValid = false;
			rm.validation.addError($(".fancytree-checkbox").slice(0, 1), "You must associate this organization with at least one milestone.");
		}
		else {
			editOrgNs.removeError($(".fancytree-checkbox").slice(0, 1));
		}
		return isValid;
	},
	getPostData: function (wasOrgUnitEnabled) {
		return {
			OrganizationId: editOrgNs.getOrganizationId(),
			OrganizationName: $.trim($(editOrgNs.txtOrgNameSelector).val()),
			OrganizationShortName: $.trim($(editOrgNs.txtOrgShortNameSelector).val()),
			OrganizationIsEnabled: $(editOrgNs.cbIsOrgEnabledSelector).is(":checked"),
			OrganizationalUnitId: editOrgNs.getOrganizationuUnitId(),
			OrganizationalUnitName: $.trim($(editOrgNs.txtOrgUnitNameSelector).val()),
			OrganizationalUnitPpmNameList: ouplNs.getControlValue(),
			OrganizationalUnitSuffix: $.trim($(editOrgNs.txtOrgUnitSuffixSelector).val()),
			OrganizationalUnitIsEnabled: $(editOrgNs.cbIsOrgUnitEnabledSelector).is(":checked"),
			AllowProjectCreationInRm: $(editOrgNs.cbAllowProjectCreationSelector).is(":checked"),
			IsProjectOrganizationalUnit: $(editOrgNs.cbProjOrgUnit).is(":checked"),
			GlobalWeeklyHours: $.trim($(editOrgNs.txtGlobalWeeklyHoursSelector).val()) == "" ? null : $.trim($(editOrgNs.txtGlobalWeeklyHoursSelector).val()),
			ProjectMilestoneIdsList: editOrgNs.getSelectedProjectMilestoneIds(),
			DisassociateOrganizationalUnit: wasOrgUnitEnabled,
			QipDisconnectResourceTypesList: $(editOrgNs.ddlResourceTypesSelector).val(),
			QipDisconnectCountriesList: $(editOrgNs.ddlCountriesSelector).val(),
			QipDisconnectMinQipVersion: $.trim($(editOrgNs.txtMinQipVersionSelector).val()) == "" ? null : $.trim($(editOrgNs.txtMinQipVersionSelector).val())
		};
	},
	Delete: function () {
		if (confirm("Are you sure , you want to delete the record(s) ?")) {
			var selectedRows = $(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).getGridParam('selarrrow')
			var QipDisconnectDataIdList = new Array();
			$.each(selectedRows, function (index, element) {
				var rowData = $(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).jqGrid('getRowData', element);
				QipDisconnectDataIdList.push({
					resourceTypeId: jQuery.parseJSON(rowData.ResourceTypeId),
					countryIdList: rowData.countryIdList.split(',')
				});
			});
			$.rm.Ajax_Administration("DeleteQipDisconnectGridData", { QipDisconnectDataIdList: QipDisconnectDataIdList }, true, false, function (response) {
				rm.ui.messages.showSuccess("Qip Data has been deleted successfully.");
				editOrgNs.clearDirty();
				editOrgNs.RefreshQipGridData();
				rm.ui.ribbon.delayedRefresh();
			});
		}
	},
	save: function () {
		if (editOrgNs.wasOUEnabled && !$(editOrgNs.cbIsOrgUnitEnabledSelector).is(":checked")) {
			if (confirm(Resources.ResourceOrgUnitDisassociateMessage)) {
				editOrgNs.saveOUData(true);
			}
		}
		else {
			editOrgNs.saveOUData(false);
		}
	},

	saveOUData: function (wasOrgUnitEnabled) {
		var postData = editOrgNs.getPostData(wasOrgUnitEnabled);
		if (editOrgNs.isFormValid() && ouplNs.isValid()) {
			$.rm.Ajax_Administration("UpdateOrganizationOrganizationUnit", { orgOrgUnit: postData }, true, false, function (response) {
				if (response.ContainsValidationErrors) {
					$.validationHelper.ShowErrorMessages(response.ValidationErrors, "", "");
				}
				else {
					rm.ui.messages.showSuccess("Organization has been updated successfully.");

					editOrgNs.clearDirty();
					ouplNs.onSaveSuccess(response.RequestExecutionStatus.AdditionalData.OrganizationalUnitPpmNameList);

					editOrgNs.wasOUEnabled = postData.OrganizationalUnitIsEnabled;
					editOrgNs.RefreshQipGridData();
					rm.ui.ribbon.delayedRefresh();
				}
			});
		}
	},
	clearForm: function () {
		$(editOrgNs.txtOrgNameSelector).val($(editOrgNs.txtOrgNameSelector).data(editOrgNs.initialValueDataAttribute)).removeClass(editOrgNs.errorClass);
		rm.validation.clearError($(editOrgNs.txtOrgNameSelector));
		$(editOrgNs.txtOrgShortNameSelector).val($(editOrgNs.txtOrgShortNameSelector).data(editOrgNs.initialValueDataAttribute)).removeClass(editOrgNs.errorClass);
		rm.validation.clearError($(editOrgNs.txtOrgShortNameSelector));
		$(editOrgNs.cbIsOrgEnabledSelector).prop("checked", $(editOrgNs.cbIsOrgEnabledSelector).data(editOrgNs.initialValueDataAttribute));

		$(editOrgNs.txtOrgUnitNameSelector).val($(editOrgNs.txtOrgUnitNameSelector).data(editOrgNs.initialValueDataAttribute)).removeClass(editOrgNs.errorClass);
		rm.validation.clearError($(editOrgNs.txtOrgUnitNameSelector));
		$(editOrgNs.txtOrgUnitSuffixSelector).val($(editOrgNs.txtOrgUnitSuffixSelector).data(editOrgNs.initialValueDataAttribute)).removeClass(editOrgNs.errorClass);
		rm.validation.clearError($(editOrgNs.txtOrgUnitSuffixSelector));
		$(editOrgNs.cbIsOrgUnitEnabledSelector).prop("checked", $(editOrgNs.cbIsOrgUnitEnabledSelector).data(editOrgNs.initialValueDataAttribute));
		$(editOrgNs.cbAllowProjectCreationSelector).prop("checked", $(editOrgNs.cbAllowProjectCreationSelector).data(editOrgNs.initialValueDataAttribute));
		$(editOrgNs.cbProjOrgUnit).prop("checked", $(editOrgNs.cbProjOrgUnit).data(editOrgNs.initialValueDataAttribute));
		$(editOrgNs.txtGlobalWeeklyHoursSelector).val($(editOrgNs.txtGlobalWeeklyHoursSelector).data(editOrgNs.initialValueDataAttribute)).removeClass(editOrgNs.errorClass);
		rm.validation.clearError($(editOrgNs.txtGlobalWeeklyHoursSelector));
		editOrgNs.bindorganizationProjectMilestonesCheckboxList(); //10547
		$(editOrgNs.hdnFancyTreeChangedSelector).val("0");
		$(".fancytree-checkbox").slice(0, 1).removeClass(editOrgNs.errorClass);
		editOrgNs.RefreshQipGridData();
		ouplNs.clearForm();
	},
	RefreshQipGridData: function () {
		$(editOrgNs.txtMinQipVersionSelector).val("");
		$(editOrgNs.ddlResourceTypesSelector).multiselect("uncheckAll");
		$(editOrgNs.ddlCountriesSelector).multiselect("uncheckAll");
		$(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).jqGrid('setGridParam', { datatype: 'json' }).trigger('reloadGrid');
	},

	cancel: function () {
		var isDirty = editOrgNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			editOrgNs.clearForm();
			setTimeout(function () {
				editOrgNs.clearDirty();
				rm.ui.ribbon.refresh();
			}, 10);
		}
	},
	close: function () {
		var isDirty = editOrgNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			document.location.href = "Manage.aspx";
		}
	},

	init: function () {
		$("#ManageOrganizationsNav").addClass("left-static-selected-menu");
		rm.runtimeValues.helpPageUrl = "#";

		$(editOrgNs.cbAllowProjectCreationSelector).click(function () { if (!$(this).is(":checked")) { rm.validation.clearError($(editOrgNs.txtOrgUnitSuffixSelector)); } });
		editOrgNs.bindDirty();
		editOrgNs.buildGrid();
		editOrgNs.initProjectMilestoneFancyTreeData(editOrgNs.getOrganizationId());
		editOrgNs.bindorganizationProjectMilestonesCheckboxList();
		editOrgNs.bindClearError();
		if ($(editOrgNs.hdnwasOUEnabledSelector).val() == "1") {
			editOrgNs.wasOUEnabled = true;
		}
		if (editOrgNs.allowEdit()) {
			$("#tblQipDisconnectMapping").show();
			editOrgNs.getAllResourceTypesCountriesData();
			editOrgNs.bindAllCountriesDropdown();
			editOrgNs.bindAllRRTsDropdown();
		}
		else {
			$(".rmMaincontent").find("input").attr("disabled", "disabled");
		}
	},

	initProjectMilestoneFancyTreeData: function (organizationId) {

		$.rm.Ajax_Utility("GetOrganizationProjectMileStones", { organizationId: organizationId }, function (response) {
			editOrgNs._orgMileStoneDataList = response.OrganizationPMData;
		}, true, false);
	},

	setCommaSeparatedSelectedProjectMilestoneIds: function () {
		return $(editOrgNs.projectMilestonesMapFancyTreeDivSelector).val(editOrgNs.getSelectedProjectMilestoneIds().sort().join(","));
	},

	bindorganizationProjectMilestonesCheckboxList: function () {
		$(editOrgNs.projectMilestonesMapFancyTreeDivSelector).fancytree({
			checkbox: true,
			selectMode: 3,
			disabled: !editOrgNs.allowEdit(),
			source: editOrgNs._orgMileStoneDataList.treeNodes,
			click: function (event, data) {
				// We should not toggle, if target was "checkbox", because this
				// would result in double-toggle (i.e. no toggle)
				if ($.ui.fancytree.getEventTargetType(event) === "title") {
					data.node.toggleSelected();
					data.node.toggleExpanded();
				}

				if (!data.node.unselectable) {
					setTimeout(editOrgNs.setCommaSeparatedSelectedProjectMilestoneIds, 10);
					rm.ui.ribbon.delayedRefresh();
				}
			},
			select: function (event, data) {
				$(editOrgNs.hdnFancyTreeChangedSelector).val("1");
				editOrgNs.removeError($(".fancytree-checkbox").slice(0, 1));
			}
		});
	},

	getSelectedProjectMilestoneIds: function () {
		var selectedProjectMilestoneIds = new Array();
		$.each($(editOrgNs.projectMilestonesMapFancyTreeDivSelector).fancytree("getTree").getSelectedNodes(), function (index, node) {
			if ($.isNumeric(node.key))
				selectedProjectMilestoneIds.push(parseInt(node.key));
		});
		return selectedProjectMilestoneIds;
	},

	bindAllRRTsDropdown: function () {
		var data = editOrgNs.allResourceTypesData;
		$(editOrgNs.ddlResourceTypesSelector).empty();
		$.each(data, function (index, item) {
			$(editOrgNs.ddlResourceTypesSelector).append($("<option>", { value: item.Id }).html(item.Name));
		});
		$(editOrgNs.ddlResourceTypesSelector).multiselect({
			selectedList: 2,
			selectedText: function (numChecked, numTotal, checkedItems) {
				var returnValue = "";
				for (var i = 0; i < checkedItems.length; i++) {
					returnValue = returnValue + $(checkedItems[i]).siblings().text() + ",";
				}
				if (checkedItems.length > 0 & returnValue.length < 49)
					return returnValue.slice(0, -1);
				else
					return checkedItems.length + " Resource Types Selected";
			}
		});
		$(editOrgNs.ddlResourceTypesSelector).multiselect('refresh');
	},

	getAllResourceTypesCountriesData: function () {
		$.rm.Ajax_Administration("GetAllRRTCountriesKeyValue", {}, false, true, function (response) {
			editOrgNs.allResourceTypesData = response.ResourceTypeIdList;
			editOrgNs.allCountriesData = response.CountryIdList;
		});
	},

	bindAllCountriesDropdown: function () {
		var data = editOrgNs.allCountriesData;
		$(editOrgNs.ddlCountriesSelector).empty();
		$.each(data, function (index, item) {
			$(editOrgNs.ddlCountriesSelector).append($("<option>", { value: item.Id }).html(item.Name));
		});
		$(editOrgNs.ddlCountriesSelector).multiselect({
			selectedList: 2,
			selectedText: function (numChecked, numTotal, checkedItems) {
				var returnValue = "";
				for (var i = 0; i < checkedItems.length; i++) {
					returnValue = returnValue + $(checkedItems[i]).siblings().text() + ",";
				}
				if (checkedItems.length > 0 & returnValue.length < 49)
					return returnValue.slice(0, -1);
				else
					return checkedItems.length + " Countries Selected";
			}
		});
		$(editOrgNs.ddlCountriesSelector).multiselect('refresh');
	},


	setResourceTypeAndCountryValuesFromGridSelection: function (selectedRows) {
		var selectedRRTList = [];
		var selectedCountryList = [];
		var minQipVersionList = [];
		$(editOrgNs.txtMinQipVersionSelector).val("");
		$.each(selectedRows, function (index, element) {
			rowData = $(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).jqGrid('getRowData', element);
			selectedRRTList.push({ resourceTypeId: rowData.ResourceTypeId, resourceTypeName: rowData.ResourceTypeName });
			//	selectedCountryList.push({ countryId: rowData.CountryId, countryName: rowData.CountryName });
			var countryList = rowData.countryIdList.split(",");
			$.each(countryList, function (index, countryId) {
				selectedCountryList.push({ countryId: $.trim(countryId) });
			});
			minQipVersionList.push({ minQipVersion: rowData.MinQipVersion });
		});

		selectedRRTList = editOrgNs.uniqueObjects(selectedRRTList, "resourceTypeId");
		selectedCountryList = editOrgNs.uniqueObjects(selectedCountryList, "countryId");
		minQipVersionList = editOrgNs.uniqueObjects(minQipVersionList, "minQipVersion");
		editOrgNs.bindGridDataToRRTDropdownList(selectedRRTList);
		editOrgNs.bindGridDataToCountryDropDownList(selectedCountryList);
		if (minQipVersionList.length == 1) {
			$(editOrgNs.txtMinQipVersionSelector).val(minQipVersionList[0]);
		}
	},
	bindGridDataToRRTDropdownList: function (selectedRRTList) {
		$(editOrgNs.ddlResourceTypesSelector).multiselect("uncheckAll");
		$.each(selectedRRTList, function (index, element) {
			$(editOrgNs.ddlResourceTypesSelector + " option[value='" + element + "']").prop("selected", "selected");
		});
		$(editOrgNs.ddlResourceTypesSelector).multiselect('refresh');
	},
	bindGridDataToCountryDropDownList: function (selectedCountryList) {
		$(editOrgNs.ddlCountriesSelector).multiselect("uncheckAll");
		$.each(selectedCountryList, function (index, element) {
			$(editOrgNs.ddlCountriesSelector + " option[value='" + element + "']").prop("selected", "selected");
		});
		$(editOrgNs.ddlCountriesSelector).multiselect('refresh');
	},

	uniqueObjects: function (arrayWithDuplicate, property) {
		uniqueList = [];
		$.each(arrayWithDuplicate, function (index, value) {
			if ($.inArray(value[property], uniqueList) === -1) {
				uniqueList.push(value[property]);
			}
		});
		return uniqueList;
	},

	// var uniqueName = list.uniqueObjects(["name"]);

	buildGrid: function () {
		var gridPost;
		gridPost = {
			sidx: "ResourceTypeName",
			sord: "asc",
			organizationalUnitId: $(editOrgNs.hdnOrgUnitIdSelector).val()
		};
		$(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).jqGrid({
		    url: rm.ajax.adminSvcUrl + "GetQipDisconnectDataByOrganizationId",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			postData: gridPost,
			loadonce: true,
			shrinkToFit: false,
			forceFit: true,
			pager: '#gridPager',
			multiselect: true,
			colModel: [
				{ name: 'ResourceTypeName', index: 'ResourceTypeName', label: 'ResourceTypeName', width: "150px", search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'ResourceTypeId', index: 'ResourceTypeId', label: 'ResourceTypeId', hidden: true },
        { name: 'countryNameList', index: 'countryNameList', label: 'Country(s)', width: "800px", search: true, searchoptions: { sopt: ['cn'] } },
				{ name: 'countryIdList', index: 'countryIdList', label: 'CountryIds', hidden: true },
        { name: 'MinQipVersion', index: 'MinQipVersion', label: 'MinQip<br/>Version', width: "80px", search: true, searchoptions: { sopt: ['bw'] } }
			],
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			onSelectRow: function (id, status, e) {
				var selectedRows = $(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).getGridParam('selarrrow');
				editOrgNs.setResourceTypeAndCountryValuesFromGridSelection(selectedRows);
			},
			onSelectAll: function (rowIdxArray, sts) {
				var selectedRows = $(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).getGridParam('selarrrow');
				editOrgNs.setResourceTypeAndCountryValuesFromGridSelection(selectedRows);
			},
			loadComplete: function (data) {
				rm.grid.rowData.attachAllRowsData($(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector), data);
				editOrgNs.RefreshQipGridData();
				$("#QipDisconnectRRTOrgUnitCountryData").setGridParam({ postData: gridPost });
				rm.ui.ribbon.delayedRefresh();
			},
			serializeGridData: function (postData) {
				var data = { organizationalUnitId: $(editOrgNs.hdnOrgUnitIdSelector).val() };
				return rm.grid.serializeGridData(postData, data);
			},
			serializeRowData: function (postData) {
				return JSON.stringify(postData);
			}
		});
		$(editOrgNs.qipDisconnectRRTOrgUnitCountryDataGridSelector).jqGrid('filterToolbar', {
			searchOnEnter: true,
			autosearch: true,
			stringResult: true,
			defaultSearch: "cn"
		});
	},
};