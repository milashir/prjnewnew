﻿///<reference path="../Common/RmHelper.js"/>
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });
	addOrgNs.init();
	addOrgNs.initBindFancyTreeElements();
});

var addOrgNs = {
	selectItemValue: "-1",
	newOrgInfoRowSelector: ".newOrgInfoRow",
	initialValueDataAttribute: "initial",
	errorClass: "q_validation_error",
	ddlOrganizationSelector: "[id$=ddlOrganization]",
	txtOrgNameSelector: "#txtOrgName",
	cbIsOrgEnabledSelector: "#cbIsOrgEnabled",
	txtOrgShortNameSelector: "#txtOrgShortName",
	txtOrgUnitNameSelector: "#txtOrgUnitName",
	txtOrgUnitPpmNameSelector: "#txtOrgUnitPpmName",
	txtOrgUnitSuffixSelector: "#txtOrgUnitSuffix",
	cbIsOrgUnitEnabledSelector: "#cbIsOrgUnitEnabled",
	cbAllowProjectCreationSelector: "#cbAllowProjectCreation",
	cbProjOrgUnit: "[id$=cbProjOrgUnit]",
	lnkAddNewOrgSelector: "#lnkAddNewOrg",
	lnkCancelNewOrgSelector: "#lnkCancelNewOrg",
	formContainer: "#formContainer",
	hdnFancyTreeChangedSelector: "[id$=hdnFancyTreeChanged]",
	getFormInputSelector: function () { return addOrgNs.formContainer + " input," + addOrgNs.formContainer + " select"; },
	jsonSelectorForDirtyForm: function () { return { items: [{ selector: addOrgNs.getFormInputSelector(), dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },
	getOrganizationId: function () { return $(addOrgNs.ddlOrganizationSelector).is(":visible") ? $(addOrgNs.ddlOrganizationSelector).val() : "-1"; },
	bindCustomErrorQtipToFancyTree: function () {
		rm.validation.addError($(".fancytree-checkbox").slice(0, 1), "You must associate this organization with at least one milestone.");
	},
	initBindFancyTreeElements: function () {
		$('#lnkAddNewOrg,#lnkCancelNewOrg').click(function () {
			addOrgNs.destroyFancyTree();
			$(addOrgNs.hdnFancyTreeChangedSelector).val("0");
		});

		$(addOrgNs.txtOrgNameSelector).change(function (e, isSubmit) {
			if ($(addOrgNs.txtOrgNameSelector).val() != "") {
				if ($(addOrgNs.projectMilestonesMapFancyTreeDivSelector).children().length == 0) {
					addOrgNs.initProjectMilestoneFancyTreeData(-1);
					addOrgNs.bindorganizationProjectMilestonesCheckboxList();
					var tree = $(addOrgNs.projectMilestonesMapFancyTreeDivSelector).fancytree('getTree');
					tree.reload(addOrgNs._orgMileStoneDataList.treeNodes);
					$($(".fancytree-checkbox").slice(0, 1)).trigger("click");
					if (isSubmit) {
						addOrgNs.bindCustomErrorQtipToFancyTree();
					}
				}
				else {
					addOrgNs.bindCustomErrorQtipToFancyTree();
				}
			}
			else {
				addOrgNs.removeError($(".fancytree-checkbox").slice(0, 1));
				addOrgNs.destroyFancyTree();
			}
		});

		$(addOrgNs.ddlOrganizationSelector).change(function () {
			if ($(addOrgNs.ddlOrganizationSelector).is(':visible') && $(addOrgNs.ddlOrganizationSelector).val() != "-1") {
				addOrgNs.initProjectMilestoneFancyTreeData($(addOrgNs.ddlOrganizationSelector).val());
				addOrgNs.bindorganizationProjectMilestonesCheckboxList();
				var tree = $(addOrgNs.projectMilestonesMapFancyTreeDivSelector).fancytree('getTree');
				tree.reload(addOrgNs._orgMileStoneDataList.treeNodes);
			}
			else { addOrgNs.destroyFancyTree(); }
		});
	},
	destroyFancyTree: function () {
		$('#fancyTreeLabel').hide();
		$('#fancyTreeLabel2').hide();
		if ($(addOrgNs.projectMilestonesMapFancyTreeDivSelector).data("uiFancytree") != null) {
			$(addOrgNs.projectMilestonesMapFancyTreeDivSelector).fancytree("destroy");
		}
	},
	removeError: function (elementSelector) {
		if (addOrgNs.getSelectedProjectMilestoneIds().length > 0) {
			var elem = $(elementSelector);
			elem.removeClass("q_validation_error");
			elem.attr("title", "");
		}
	},
	projectMilestonesMapFancyTreeDivSelector: "#divProjectMilestonesMapFancyTree",
	_orgMileStoneDataList: null,
	isSaveButtonEnabled: function () {
		return addOrgNs.isFormDirty();
	},
	isCloseButtonEnabled: function () {
		return true;
	},
	isCancelButtonEnabled: function () {
		return addOrgNs.isFormDirty();
	},
	bindClearError: function () {
		var selector = addOrgNs.ddlOrganizationSelector + "," + addOrgNs.txtOrgNameSelector + "," + addOrgNs.txtOrgShortNameSelector + "," + addOrgNs.txtOrgUnitNameSelector + "," + addOrgNs.txtOrgUnitSuffixSelector + "," + addOrgNs.txtOrgUnitPpmNameSelector + "," + addOrgNs.cbIsOrgUnitEnabledSelector + "," + addOrgNs.cbAllowProjectCreationSelector + "," + addOrgNs.cbIsOrgEnabledSelector + "," + addOrgNs.hdnFancyTreeChangedSelector + "," + addOrgNs.cbProjOrgUnit;
		$(selector).bind("keydown change", function () { rm.validation.clearError($(this)); addOrgNs.handleFormDirtyChange(); });
		$(selector).bind("click", function () { addOrgNs.handleFormDirtyChange(); });
	},
	bindDirty: function () { $.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, addOrgNs.jsonSelectorForDirtyForm()); },
	isFormDirty: function () {
		return $.formStatus.isDirty(addOrgNs.jsonSelectorForDirtyForm()) || $(addOrgNs.hdnFancyTreeChangedSelector).val() == "1";
	},
	handleFormDirtyChange: function () { rm.ui.ribbon.delayedRefresh(); },
	clearDirty: function () {
		setTimeout(function () {
			$.formStatus.clearDirty(addOrgNs.jsonSelectorForDirtyForm());
			$(addOrgNs.hdnFancyTreeChangedSelector).val("0");
		}, 20);
	},
	isFormValid: function () {
		if ($('#txtOrgName').is(":visible")) {
			$(addOrgNs.txtOrgNameSelector).trigger("change", [true]);
		}
		var isValid = true;
		$.each($("[IsMandatory]:visible"), function (index, uiElement) {
			var elemetnObj = $(uiElement);
			if ($.trim(elemetnObj.val()) == "" || (elemetnObj.val() == "-1" && elemetnObj.is("select"))) {
				isValid = false;
				rm.validation.addError(elemetnObj, elemetnObj.attr("ErrorMessage"));
			}
		});

		var suffixObj = $(addOrgNs.txtOrgUnitSuffixSelector);
		if ($(addOrgNs.cbAllowProjectCreationSelector).is(":checked") && $.trim(suffixObj.val()) == "") {
			isValid = false;
			rm.validation.addError(suffixObj, suffixObj.attr("ErrorMessage"));
		}
		if ($(addOrgNs.txtOrgUnitSuffixSelector).val().indexOf(" ") != -1) {
			rm.validation.addError($(addOrgNs.txtOrgUnitSuffixSelector), "Blank spaces are not allowed in Organizational Unit Suffix");
			isValid = false;
		}
		if ($(addOrgNs.ddlOrganizationSelector).is(":visible") && $.trim($(addOrgNs.ddlOrganizationSelector).val()) == "") {
			rm.validation.addError(elemetnObj, elemetnObj.attr("ErrorMessage"));
		}
		if (addOrgNs.getSelectedProjectMilestoneIds().length < 1) {
			isValid = false;
			rm.validation.addError($(".fancytree-checkbox").slice(0, 1), "You must associate this organization with at least one milestone.");
		}
		else {
			addOrgNs.removeError($(".fancytree-checkbox").slice(0, 1));
		}
		return isValid;
	},
	getPostData: function () {
		return {
			OrganizationalUnitId: -1, //Always add a new organizational unit.
			OrganizationId: addOrgNs.getOrganizationId(),
			OrganizationName: $.trim($(addOrgNs.txtOrgNameSelector).val()),
			OrganizationShortName: $.trim($(addOrgNs.txtOrgShortNameSelector).val()),
			OrganizationIsEnabled: $(addOrgNs.cbIsOrgEnabledSelector).is(":checked"),
			OrganizationalUnitName: $.trim($(addOrgNs.txtOrgUnitNameSelector).val()),
			OrganizationalUnitPpmNameList: ouplNs.getControlValue(),
			OrganizationalUnitSuffix: $.trim($(addOrgNs.txtOrgUnitSuffixSelector).val()),
			OrganizationalUnitIsEnabled: $(addOrgNs.cbIsOrgUnitEnabledSelector).is(":checked"),
			AllowProjectCreationInRm: $(addOrgNs.cbAllowProjectCreationSelector).is(":checked"),
			IsProjectOrganizationalUnit: $(addOrgNs.cbProjOrgUnit).is(":checked"),
			ProjectMilestoneIdsList: addOrgNs.getSelectedProjectMilestoneIds(),
		};
	},
	save: function () {
		if (addOrgNs.isFormValid() && ouplNs.isValid()) {
			$.rm.Ajax_Administration("AddOrganizationOrganizationUnit", { orgOrgUnit: addOrgNs.getPostData() }, true, false, function (response) {
				if (response.ContainsValidationErrors) {
					$.validationHelper.ShowErrorMessages(response.ValidationErrors, "", "");
				}
				else {
					window.onbeforeunload = null;
					rm.ui.messages.showSuccess("Organization has been added successfully.");
					document.location.href = "Manage.aspx";
				}
			});
		}
	},
	clearForm: function () {
		$(addOrgNs.ddlOrganizationSelector).val($(addOrgNs.ddlOrganizationSelector).data(addOrgNs.initialValueDataAttribute)).removeClass(addOrgNs.errorClass);
		rm.validation.clearError($(addOrgNs.ddlOrganizationSelector));
		$(addOrgNs.txtOrgNameSelector).val($(addOrgNs.txtOrgNameSelector).data(addOrgNs.initialValueDataAttribute)).removeClass(addOrgNs.errorClass);
		rm.validation.clearError($(addOrgNs.txtOrgNameSelector));
		$(addOrgNs.txtOrgShortNameSelector).val($(addOrgNs.txtOrgShortNameSelector).data(addOrgNs.initialValueDataAttribute)).removeClass(addOrgNs.errorClass);
		rm.validation.clearError($(addOrgNs.txtOrgShortNameSelector));
		$(addOrgNs.cbIsOrgEnabledSelector).prop("checked", $(addOrgNs.cbIsOrgEnabledSelector).data(addOrgNs.initialValueDataAttribute));

		$(addOrgNs.txtOrgUnitNameSelector).val($(addOrgNs.txtOrgUnitNameSelector).data(addOrgNs.initialValueDataAttribute)).removeClass(addOrgNs.errorClass);
		rm.validation.clearError($(addOrgNs.txtOrgUnitNameSelector));
		$(addOrgNs.txtOrgUnitSuffixSelector).val($(addOrgNs.txtOrgUnitSuffixSelector).data(addOrgNs.initialValueDataAttribute)).removeClass(addOrgNs.errorClass);
		rm.validation.clearError($(addOrgNs.txtOrgUnitSuffixSelector));
		$(addOrgNs.cbIsOrgUnitEnabledSelector).prop("checked", $(addOrgNs.cbIsOrgUnitEnabledSelector).data(addOrgNs.initialValueDataAttribute));
		$(addOrgNs.cbAllowProjectCreationSelector).prop("checked", $(addOrgNs.cbAllowProjectCreationSelector).data(addOrgNs.initialValueDataAttribute));
		$(addOrgNs.IsProjectOrganizationalUnit).prop("checked", $(addOrgNs.IsProjectOrganizationalUnit).data(addOrgNs.initialValueDataAttribute));
		//addOrgNs.bindorganizationProjectMilestonesCheckboxList();
		addOrgNs.destroyFancyTree();
		$(addOrgNs.hdnFancyTreeChangedSelector).val("0");
		$(".fancytree-title").removeClass(addOrgNs.errorClass);
		ouplNs.clearForm();
	},
	cancel: function () {
		var isDirty = addOrgNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			addOrgNs.clearForm();
			setTimeout(function () {
				addOrgNs.clearDirty();
				rm.ui.ribbon.refresh();
			}, 10);
		}
	},
	close: function () {
		var isDirty = addOrgNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			document.location.href = "Manage.aspx";
		}
	},
	init: function () {
		$("#ManageOrganizationsNav").addClass("left-static-selected-menu");
		rm.runtimeValues.helpPageUrl = "#";
		$(addOrgNs.lnkAddNewOrgSelector).click(addOrgNs.handleAddNewOrganizationClick);
		$(addOrgNs.lnkCancelNewOrgSelector).click(addOrgNs.handleCancelOrganizationClick);

		$(addOrgNs.cbAllowProjectCreationSelector).click(function () { if (!$(this).is(":checked")) { rm.validation.clearError($(addOrgNs.txtOrgUnitSuffixSelector)); } });
		addOrgNs.bindDirty();

		$('#fancyTreeLabel').hide();
		$('#fancyTreeLabel2').hide();
		addOrgNs.bindClearError();
	},

	handleAddNewOrganizationClick: function () {
		$(addOrgNs.ddlOrganizationSelector).val(addOrgNs.selectItemValue).hide();
		rm.validation.clearError($(addOrgNs.ddlOrganizationSelector));
		$(addOrgNs.lnkAddNewOrgSelector).hide();
		$(addOrgNs.newOrgInfoRowSelector).removeClass("hideMe").show();
		$(addOrgNs.lnkCancelNewOrgSelector).removeClass("hideMe").show();
	},

	handleCancelOrganizationClick: function () {
		var isPartialDirty = $(addOrgNs.txtOrgNameSelector).val() != "" || $(addOrgNs.txtOrgShortNameSelector).val() != "" || !$(addOrgNs.cbIsOrgEnabledSelector).is(":checked");

		if (!isPartialDirty || (isPartialDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			$(addOrgNs.ddlOrganizationSelector).show();
			$(addOrgNs.lnkAddNewOrgSelector).show();
			$(addOrgNs.newOrgInfoRowSelector).hide().find("input").each(function () {
				var control = $(this);
				if (control.attr("type") == "checkbox") {
					control.prop("checked", true);
				}
				else {
					rm.validation.clearError(control);
					control.val("");
				}
			});
			$(addOrgNs.lnkCancelNewOrgSelector).hide();
		}
	},

	initProjectMilestoneFancyTreeData: function (organizationId) {

		$.rm.Ajax_Utility("GetOrganizationProjectMileStones", { organizationId: organizationId }, function (response) {
			addOrgNs._orgMileStoneDataList = response.OrganizationPMData;
		}, true, false);
	},

	setCommaSeparatedSelectedProjectMilestoneIds: function () {
		return $(addOrgNs.projectMilestonesMapFancyTreeDivSelector).val(addOrgNs.getSelectedProjectMilestoneIds().sort().join(","));
	},

	refreshRibbonAfterDelay: function () { rm.ui.ribbon.delayedRefresh(); },

	bindorganizationProjectMilestonesCheckboxList: function () {
		$('#fancyTreeLabel').show();
		$('#fancyTreeLabel2').show();
		$(addOrgNs.projectMilestonesMapFancyTreeDivSelector).fancytree({
			checkbox: true,
			selectMode: 3,
			source: addOrgNs._orgMileStoneDataList.treeNodes,
			click: function (event, data) {
				// We should not toggle, if target was "checkbox", because this
				// would result in double-toggle (i.e. no toggle)
				if ($.ui.fancytree.getEventTargetType(event) === "title") {
					data.node.toggleSelected();
					data.node.toggleExpanded();
				}

				if (!data.node.unselectable) {
					setTimeout(addOrgNs.setCommaSeparatedSelectedProjectMilestoneIds, 10);
					addOrgNs.refreshRibbonAfterDelay();
				}
			},
			select: function (event, data) {
				$(addOrgNs.hdnFancyTreeChangedSelector).val("1");
				addOrgNs.removeError($(".fancytree-checkbox").slice(0, 1));
			}
		});
	},

	getSelectedProjectMilestoneIds: function () {
		var selectedProjectMilestoneIds = new Array();
		if ($(addOrgNs.projectMilestonesMapFancyTreeDivSelector).children().length > 0) {
			$.each($(addOrgNs.projectMilestonesMapFancyTreeDivSelector).fancytree("getTree").getSelectedNodes(), function (index, node) {
				if ($.isNumeric(node.key))
					selectedProjectMilestoneIds.push(parseInt(node.key));
			});
		}
		return selectedProjectMilestoneIds;
	},
};