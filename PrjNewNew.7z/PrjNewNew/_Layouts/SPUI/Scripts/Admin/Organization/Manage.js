﻿/// <reference path="../../common/RmHelper.js" />
$(document).ready(function () {
    $(document).ajaxStop(function () { rm.ui.unblock(); });
    $(document).ajaxStart(function () { rm.ui.block(); });
    manageOrgNs.init();
});

var manageOrgNs = {
    gridSelector: "#tblData",
    initialData: null,
    isAddButtonEnabled: function () { return !rm.grid.hasRowsSelected(manageOrgNs.gridSelector); },

    isModifyButtonEnabled: function () { return rm.grid.hasSingleRowSelected(manageOrgNs.gridSelector); },

    addNewOrganization: function () { document.location.href = "Add.aspx"; },

    editOrganization: function () {
        var gridJson = rm.grid.rowData.getById(manageOrgNs.gridSelector, $(manageOrgNs.gridSelector).getGridParam('selarrrow')[0]);
        document.location.href = "Edit.aspx?oid=" + gridJson.OrganizationId + "&ouid=" + gridJson.id;
    },

    init: function () {
        $("#ManageOrganizationsNav").addClass("left-static-selected-menu");
        rm.runtimeValues.helpPageUrl = "#";
        manageOrgNs.buildGrid();
    },

    buildGrid: function () {
        var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
        gridToolsConfig.showManageColumns = false;
        gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ManageOrganizations };
        rm.grid.showGridTools(manageOrgNs.gridSelector, gridToolsConfig);
        $(manageOrgNs.gridSelector).jqGrid({
            url: rm.ajax.adminSvcUrl + "GetAllOrganizations",
            datatype: 'json',
            mtype: 'POST',
            ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
            jsonReader: rm.grid.getJqGridJsonReader(),
            loadonce: true,
            autowidth: false,
            shrinkToFit: false,
            height: rm.ui.getMaxGridHeight() - 40,
            width: rm.ui.getMaxGridWidth() - 60,
            pager: '#tblPager',
            multiselect: true,
            colModel: [
				{ name: 'OrganizationName', index: 'OrganizationName', label: 'Organization', width: 300 },
				{ name: 'OrganizationalUnitName', index: 'OrganizationalUnitName', label: 'Organizational Unit', width: 300 }
            ],
            viewsortcols: [true, 'vertical', true],
            sortname: 'EffectiveDate',
            sortorder: 'asc',
            beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
            onPaging: function () { rm.ui.ribbon.delayedRefresh(); },
            onSelectRow: function (id) { rm.ui.ribbon.refresh(); },
            onSelectAll: function (rowIdxArray, sts) { rm.ui.ribbon.refresh(); },
            gridComplete: function () { },
            serializeGridData: function (postData) { return rm.grid.serializeGridData(postData); },
            beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("tblData"); },
            loadComplete: function (data) {
                if (manageOrgNs.initialData == null) { manageOrgNs.initialData = data; }
                rm.grid.rowData.attachAllRowsData(manageOrgNs.gridSelector, manageOrgNs.initialData);
            }
        });
        $(manageOrgNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true, defaultSearch: "cn" });
    }
};