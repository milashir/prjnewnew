﻿/// <reference path="../../common/rmhelper.js" />
$(document).ready(function () { uploadByCjgNs.init(); });

var uploadByCjgNs = {
	validateRangeSelector: ".validateRange:visible",
	requiredFieldFieldSelector: "[ismandatory=1]",
	btnSubmitSelector: "[id$=btnSubmit]",
	fileSelector: "[id$=fuCostingFile]",
	ddlYearSelector: "[id$=ddlYear]",
	dialogContainerSelector: "#dialogContainerForYear",
	GetRequiredFieldEmptyFieldSelector: function () { return uploadByCjgNs.requiredFieldFieldSelector + "[ismandatory=1][value='']"; },
	isUploadButtonEnabled: function () { return true; },
	isDownloadButtonEnabled: function () { return true; },
	isDownloadTemplateButtonEnabled: function () { return true; },
	init: function ()
	{
		$("#CostingNav").addClass("left-static-selected-menu");

		$(uploadByCjgNs.requiredFieldFieldSelector).bind("keypress change", function ()
		{
			rm.validation.clearError($(this));
		});
	},
	upload: function ()
	{
		if (uploadByCjgNs.isValid())
		{
			$(uploadByCjgNs.btnSubmitSelector).trigger('click');
		}
		else
		{
			rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
		}
	},
	isValid: function ()
	{
		var isValid = $(uploadByCjgNs.GetRequiredFieldEmptyFieldSelector()).length == 0;

		$.each($(uploadByCjgNs.validateRangeSelector), function () { if (!$.q.rangeValidate($(this))) { isValid = false; } });

		var fileSelector = $(uploadByCjgNs.fileSelector);
		var fileName = fileSelector.val();
		if (fileName == "" || !fileName.toUpperCase().endsWith(".XLSX"))
		{
			rm.validation.addError(fileSelector, fileSelector.attr("ErrorMessage"));
		}
		return isValid;
	},
	download: function ()
	{
		$(uploadByCjgNs.dialogContainerSelector).removeClass("hideMe").dialog({
			modal: true,
			cache: false,
			title: "Select year",
			resizable: false,
			width: 100,
			height: 120,
			buttons: [{
				text: "OK",
				click: function ()
				{
					uploadByCjgNs.downloadFile($(uploadByCjgNs.ddlYearSelector).val());
					$(this).dialog('close');
				}
			}
			]
		});

	},
	downloadFile: function (year) { window.location = "/ViewAttachment.ashx?ID=" + DownloadAction_E.CostingByCountryJobGrade + "&year=" + year; },
	downloadTemplate: function () { window.location = "JobGradeCostingTemplate.xlsx" }
};