﻿/// <reference path="../../common/rmhelper.js" />
$(document).ready(function () {
	svcSettingNs.init();
});

var svcSettingNs = {
	serviceSettingsGridSelector: "#tblData",

	init: function () {
		rm.runtimeValues.helpPageUrl = "#";
		$("#Link_ViewServiceSettings").addClass("left-static-selected-menu");
		svcSettingNs.buildServiceSettingsGrid();
		rm.grid.bindEventsToResizeGrid(svcSettingNs.serviceSettingsGridSelector);
	},
	getFilterFromJson: function (json, propName) {
		var filter = "";
		var uniqueValues = {};
		$.each(json, function (index, dataRow) { uniqueValues[dataRow[propName]] = dataRow[propName]; });
		var valueArray = new Array();
		for (var prop in uniqueValues) {
			valueArray.push(prop);
		}
		valueArray.sort().forEach(function (value) { filter += ";" + value + ":" + value; });
		return filter;
	},
	getWindowsServiceProcessFilter: function (serviceResponse) {
		return ":All" + svcSettingNs.getFilterFromJson(serviceResponse, "WindowsServiceProcess");
	},
	getServerNameFilter: function (serviceResponse) {
		return ":All" + svcSettingNs.getFilterFromJson(serviceResponse, "ServerName");
	},
	buildServiceSettingsGrid: function () {
		rm.ajax.adminSvcAsyncPost("GetWindowsServiceSettings", { gridSearch: { _search: false, nd: Math.random(), rows: 25, page: 1, sidx: "", sord: "asc" } }, function (serviceResponse) { svcSettingNs.bindServiceSettingsGrid(serviceResponse); });
	},
	bindServiceSettingsGrid: function (serviceResponse) {
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ViewWindowsServiceSettings };
		rm.grid.showGridTools(svcSettingNs.serviceSettingsGridSelector, gridToolsConfig);
		$(svcSettingNs.serviceSettingsGridSelector).jqGrid({
			datatype: 'local',
			data: serviceResponse.Records,
			ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			shrinkToFit: false,
			height: rm.ui.getMaxGridHeight() - 40,
			width: rm.ui.getMaxGridWidth() - 60,
			autowidth: false,
			forceFit: false,
			pager: '#tblPager',
			multiselect: false,
			colModel: [
									{ name: "ServerName", index: "ServerName", label: "Server Name", width: 151, stype: 'select', searchoptions: { sopt: ['eq'], value: svcSettingNs.getServerNameFilter(serviceResponse.Records) } },
									{ name: "ServerDescription", index: "ServerDescription", label: "Server<br/>Description", width: 120, searchoptions: { sopt: ['bw'] } },
									{ name: "IsProductionServer", index: "IsProductionServer", label: "Is Production<br/>Server", width: 89, stype: 'select', searchoptions: { sopt: ['eq'], value: rm.grid.filterOptions.yesNoString } },
									{ name: "IsServerActive", index: "IsServerActive", label: "Is Server<br/>Active", width: 65, stype: 'select', searchoptions: { sopt: ['eq'], value: rm.grid.filterOptions.yesNoString } },
									{ name: "WindowsServiceProcess", index: "WindowsServiceProcess", label: "Windows Service Process ", width: 370, stype: 'select', searchoptions: { sopt: ['eq'], value: svcSettingNs.getWindowsServiceProcessFilter(serviceResponse.Records) } },
									{ name: "IsProcessActive", index: "IsProcessActive", label: "Is Process<br/>Active", width: 76, stype: 'select', searchoptions: { sopt: ['eq'], value: rm.grid.filterOptions.yesNoString } },
									{ name: "AllowExecutionOnServer", index: "AllowExecutionOnServer", label: "Allow Execution<br/>On Server", width: 105, stype: 'select', searchoptions: { sopt: ['eq'], value: rm.grid.filterOptions.yesNoString } }
			],
			viewsortcols: [true, 'vertical', true],
			sortorder: 'asc',
			serializeGridData: function (postData) {
				return rm.grid.serializeGridData(postData);
			},
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("tblData"); },
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData(svcSettingNs.serviceSettingsGridSelector, data); }
		});
		$(svcSettingNs.serviceSettingsGridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true, defaultSearch: "cn" });
	}
};