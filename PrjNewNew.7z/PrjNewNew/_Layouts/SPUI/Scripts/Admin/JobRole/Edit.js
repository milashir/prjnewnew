﻿///<reference path="../Common/RmHelper.js"/>
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });
	editJrNs.init();
});

var editJrNs = {
	initialValueDataAttribute: "initial",
	errorClass: "q_validation_error",
	hdnJobRoleIdSelector: "[id$=hdnJobRoleId]",
	txtJobRoleNameSelector: "[id$=txtJobRoleName]",
	cbIsJobRoleEnabledSelector: "[id$=cbIsJobRoleEnabled]",
	cbIsProjectLeadershipSelector: "[id$=cbIsProjectLeadership]",
	cbShowCompetencyBandSelector: "[id$=cbShowCompetencyBand]",
	cbShowTmfPlatformSelector: "[id$=cbShowTmfPlatform]",
	hdnwasPLEnabledSelector: "[id$=hdnWasPlEnabled]",
	txtHrNameSelector: "[id$=txtHrName]",
	getJobRoleId: function () { return $(editJrNs.hdnJobRoleIdSelector).val() },
	formInputSelector: "#formContainer input",
	hdnHasAccessToEditJobRoleSelector: "[id$=hdnHasAccessToEditJobRole]",
	allowEdit: function () { return $(editJrNs.hdnHasAccessToEditJobRoleSelector).val() == "1"; },
	getWasJobRoleEnabledStatus: function () {
		//Check whether the JobRole was previously enabled using the hidden variable value.
		return ($("[id$=hdnWasJrEnabled]").val() == "1") ? true : false;
	},
	getWasProjectLeadershipEnabledStatus: function () {
		//Check whether the project leadership was previously enabled using the hidden variable value.
		return ($("[id$=hdnWasPlEnabled]").val() == "1") ? true : false;
	},

	jsonSelectorForDirtyForm: function () { return { items: [{ selector: editJrNs.formInputSelector, dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },

	isSaveButtonEnabled: function () { return editJrNs.isFormDirty(); },

	isCloseButtonEnabled: function () { return true; },

	isCancelButtonEnabled: function () { return editJrNs.isFormDirty(); },
	bindClearError: function () {
		var selector = editJrNs.txtJobRoleNameSelector + "," + editJrNs.txtHrNameSelector + "," + editJrNs.cbIsJobRoleEnabledSelector + "," + editJrNs.cbIsProjectLeadershipSelector + "," + editJrNs.cbShowCompetencyBandSelector + "," + editJrNs.cbShowTmfPlatformSelector;
		$(selector).bind("keydown change", function () { rm.validation.clearError($(this)); editJrNs.handleFormDirtyChange(); });
		$(selector).bind("click", function () { editJrNs.handleFormDirtyChange(); });
	},
	bindDirty: function () { $.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, editJrNs.jsonSelectorForDirtyForm()); },
	isFormDirty: function () {
		return $.formStatus.isDirty(editJrNs.jsonSelectorForDirtyForm());
	},
	handleFormDirtyChange: function () { rm.ui.ribbon.delayedRefresh(); },
	clearDirty: function () { setTimeout(function () { $.formStatus.clearDirty(editJrNs.jsonSelectorForDirtyForm()); }, 20); },
	isFormValid: function () {
		var isValid = true;
		$.each($("[IsMandatory]"), function (index, uiElement) {
			var elemetnObj = $(uiElement);
			if ($.trim(elemetnObj.val()) == "") {
				isValid = false;
				rm.validation.addError(elemetnObj, elemetnObj.attr("ErrorMessage"));
			}
		});
		return isValid;
	},
	getPostData: function (wasJobRoleEnabled) {
		return {
			Id: editJrNs.getJobRoleId(),
			Name: $.trim($(editJrNs.txtJobRoleNameSelector).val()),
			IsEnabled: $(editJrNs.cbIsJobRoleEnabledSelector).is(":checked"),
			IsProjectLeadership: $(editJrNs.cbIsProjectLeadershipSelector).is(":checked"),
			ShowCompetencyBand: $(editJrNs.cbShowCompetencyBandSelector).is(":checked"),
			ShowTmfPlatform: $(editJrNs.cbShowTmfPlatformSelector).is(":checked"),
			HrName: $.trim($(editJrNs.txtHrNameSelector).val()),
			DisassociateJobRole: wasJobRoleEnabled
		};
	},

	save: function () {
		if (editJrNs.getWasJobRoleEnabledStatus() && !$(editJrNs.cbIsJobRoleEnabledSelector).is(":checked")) {
			if (confirm(Resources.ResourceJobRoleDisassociateMessage)) {
				editJrNs.saveJRData(true);
			}
		}
		else {
			if (editJrNs.getWasProjectLeadershipEnabledStatus() && !$(editJrNs.cbIsProjectLeadershipSelector).is(":checked")) {
				if (confirm(Resources.ResourcingRequirementsJobRoleDisassociateMessage.replace("{0}", $.trim($(editJrNs.txtJobRoleNameSelector).val())))) {
					editJrNs.saveJRData(false);
				}
			} else {
				editJrNs.saveJRData(false);
			}
		}
	},

	saveJRData: function (wasJobRoleEnabled) {
		var postData = editJrNs.getPostData(wasJobRoleEnabled);
		if (editJrNs.isFormValid()) {
			$.rm.Ajax_Administration("UpdateJobRole", { jobRole: postData }, true, false, function (response) {
				if (response.ContainsValidationErrors) {
					$.validationHelper.ShowErrorMessages(response.ValidationErrors, "", "");
				}
				else {
					rm.ui.messages.showSuccess("Job Role has been updated successfully.");
					editJrNs.clearDirty();
					$("[id$=hdnWasJrEnabled]").val(postData.IsEnabled ? 1 : 0);
					$("[id$=hdnWasPlEnabled]").val(postData.IsProjectLeadership ? 1 : 0);

					rm.ui.ribbon.delayedRefresh();
				}
			});
		}
	},

	clearForm: function () {
		$(editJrNs.txtJobRoleNameSelector).val($(editJrNs.txtJobRoleNameSelector).data(editJrNs.initialValueDataAttribute)).removeClass(editJrNs.errorClass);
		$(editJrNs.txtHrNameSelector).val($(editJrNs.txtHrNameSelector).data(editJrNs.initialValueDataAttribute)).removeClass(editJrNs.errorClass);
		$(editJrNs.cbIsJobRoleEnabledSelector).prop("checked", $(editJrNs.cbIsJobRoleEnabledSelector).data(editJrNs.initialValueDataAttribute));
		$(editJrNs.cbIsProjectLeadershipSelector).prop("checked", $(editJrNs.cbIsProjectLeadershipSelector).data(editJrNs.initialValueDataAttribute));
		$(editJrNs.cbShowCompetencyBandSelector).prop("checked", $(editJrNs.cbShowCompetencyBandSelector).data(editJrNs.initialValueDataAttribute));
		$(editJrNs.cbShowTmfPlatformSelector).prop("checked", $(editJrNs.cbShowTmfPlatformSelector).data(editJrNs.initialValueDataAttribute));
	},
	cancel: function () {
		var isDirty = editJrNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			editJrNs.clearForm();
			setTimeout(function () {
				editJrNs.clearDirty();
				rm.ui.ribbon.refresh();
			}, 10);
		}
	},
	close: function () {
		var isDirty = editJrNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			document.location.href = "Manage.aspx";
		}
	},

	init: function () {
		if (!editJrNs.allowEdit()) { $(".rmMaincontent").find("input").attr("disabled", "disabled"); }
		$("#ManageJobRolesNav").addClass("left-static-selected-menu");
		rm.runtimeValues.helpPageUrl = "#";
		editJrNs.bindDirty();
		editJrNs.bindClearError();
	}
};