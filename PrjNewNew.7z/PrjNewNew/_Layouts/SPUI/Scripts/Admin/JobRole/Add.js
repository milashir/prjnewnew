﻿///<reference path="../Common/RmHelper.js"/>
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });
	addJrNs.init();
});

var addJrNs = {
	selectItemValue: "-1",
	initialValueDataAttribute: "initial",
	errorClass: "q_validation_error",
	txtJobRoleNameSelector: "#txtJobRoleName",
	cbIsJobRoleEnabledSelector: "#cbIsJobRoleEnabled",
	cbIsProjectLeadershipSelector: "[id$=cbIsProjectLeadership]",
	cbShowCompetencyBandSelector: "[id$=cbShowCompetencyBand]",
	cbShowTmfPlatformSelector: "[id$=cbShowTmfPlatform]",
	txtHrNameSelector: "#txtHrName",
	formContainer: "#formContainer",
	getFormInputSelector: function () { return addJrNs.formContainer + " input"; },
	jsonSelectorForDirtyForm: function () { return { items: [{ selector: addJrNs.getFormInputSelector(), dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] }; },
	isSaveButtonEnabled: function () { return addJrNs.isFormDirty(); },
	isCloseButtonEnabled: function () { return true; },
	isCancelButtonEnabled: function () { return addJrNs.isFormDirty(); },
	bindClearError: function () {
		var selector = addJrNs.txtJobRoleNameSelector + "," + addJrNs.txtHrNameSelector + "," + addJrNs.cbIsJobRoleEnabledSelector + "," + addJrNs.cbIsProjectLeadershipSelector + "," + addJrNs.cbShowCompetencyBandSelector + "," + addJrNs.cbShowTmfPlatformSelector;
		$(selector).bind("keypress change", function () { rm.validation.clearError($(this)); addJrNs.handleFormDirtyChange(); });
		$(selector).bind("click", function () { addJrNs.handleFormDirtyChange(); });
	},
	bindDirty: function () { $.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, addJrNs.jsonSelectorForDirtyForm()); },
	isFormDirty: function () {
		return $.formStatus.isDirty(addJrNs.jsonSelectorForDirtyForm());
	},
	handleFormDirtyChange: function () { rm.ui.ribbon.delayedRefresh(); },
	clearDirty: function () { setTimeout(function () { $.formStatus.clearDirty(addJrNs.jsonSelectorForDirtyForm()); }, 20); },
	isFormValid: function () {
		var isValid = true;
		$.each($("[IsMandatory]:visible"), function (index, uiElement) {
			var elemetnObj = $(uiElement);
			if ($.trim(elemetnObj.val()) == "" || (elemetnObj.val() == "-1" && elemetnObj.is("select"))) {
				isValid = false;
				rm.validation.addError(elemetnObj, elemetnObj.attr("ErrorMessage"));
			}
		});

		return isValid;
	},
	getPostData: function () {
		return {
			Id: -1, //Always add a new Job role
			Name: $.trim($(addJrNs.txtJobRoleNameSelector).val()),
			IsEnabled: $(addJrNs.cbIsJobRoleEnabledSelector).is(":checked"),
			IsProjectLeadership: $(addJrNs.cbIsProjectLeadershipSelector).is(":checked"),
			ShowCompetencyBand: $(addJrNs.cbShowCompetencyBandSelector).is(":checked"),
			ShowTmfPlatform: $(addJrNs.cbShowTmfPlatformSelector).is(":checked"),
			HrName: $.trim($(addJrNs.txtHrNameSelector).val())
		};
	},
	save: function () {
		if (addJrNs.isFormValid()) {
			$.rm.Ajax_Administration("AddJobRole", { jobRole: addJrNs.getPostData() }, true, false, function (response) {
				if (response.ContainsValidationErrors) {
					$.validationHelper.ShowErrorMessages(response.ValidationErrors, "", "");
				}
				else {
					window.onbeforeunload = null;
					rm.ui.messages.showSuccess("Job Role has been added successfully.");
					document.location.href = "Manage.aspx";
				}
			});
		}
	},
	clearForm: function () {
		$(addJrNs.txtJobRoleNameSelector).val($(addJrNs.txtJobRoleNameSelector).data(addJrNs.initialValueDataAttribute)).removeClass(addJrNs.errorClass);
		$(addJrNs.txtHrNameSelector).val($(addJrNs.txtHrNameSelector).data(addJrNs.initialValueDataAttribute)).removeClass(addJrNs.errorClass);
		$(addJrNs.cbIsJobRoleEnabledSelector).prop("checked", $(addJrNs.cbIsJobRoleEnabledSelector).data(addJrNs.initialValueDataAttribute));
		$(addJrNs.cbIsProjectLeadershipSelector).prop("checked", $(addJrNs.cbIsProjectLeadershipSelector).data(addJrNs.initialValueDataAttribute));
		$(addJrNs.cbShowCompetencyBandSelector).prop("checked", $(addJrNs.cbShowCompetencyBandSelector).data(addJrNs.initialValueDataAttribute));
		$(addJrNs.cbShowTmfPlatformSelector).prop("checked", $(addJrNs.cbShowTmfPlatformSelector).data(addJrNs.initialValueDataAttribute));
	},
	cancel: function () {
		var isDirty = addJrNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			addJrNs.clearForm();
			setTimeout(function () {
				addJrNs.clearDirty();
				rm.ui.ribbon.refresh();
			}, 10);
		}
	},
	close: function () {
		var isDirty = addJrNs.isFormDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			window.onbeforeunload = null;
			document.location.href = "Manage.aspx";
		}
	},
	init: function () {
		$("#ManageJobRolesNav").addClass("left-static-selected-menu");
		rm.runtimeValues.helpPageUrl = "#";

		addJrNs.bindDirty();
		addJrNs.bindClearError();
	}
};