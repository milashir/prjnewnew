﻿///<reference path="../Common/RmHelper.js"/>
$(document).ready(function () {
	$(document).ajaxStop(function () { rm.ui.unblock(); });
	$(document).ajaxStart(function () { rm.ui.block(); });
	manageJrNs.init();
});

var manageJrNs = {
	gridSelector: "#tblData",
	isAddButtonEnabled: function () { return !rm.grid.hasRowsSelected(manageJrNs.gridSelector); },
	isModifyButtonEnabled: function () { return rm.grid.hasSingleRowSelected(manageJrNs.gridSelector); },
	addNewJobRole: function () { document.location.href = "Add.aspx"; },
	editJobRole: function () {
		var selectedIds = $(manageJrNs.gridSelector).getGridParam('selarrrow');
		if (selectedIds && selectedIds.length > 0) {
			document.location.href = "Edit.aspx?jrid=" + selectedIds[0];
		}
	},
	init: function () {
		$("#ManageJobRolesNav").addClass("left-static-selected-menu");
		rm.runtimeValues.helpPageUrl = "#";
		manageJrNs.buildGrid();
	},
	buildGrid: function () {
		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ManageJobRoles };
		rm.grid.showGridTools(manageJrNs.gridSelector, gridToolsConfig);
		$(manageJrNs.gridSelector).jqGrid({
		    url: rm.ajax.adminSvcUrl + "GetAllJobRoles",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			loadonce: true,
			autowidth: false,
			shrinkToFit: false,
			height: rm.ui.getMaxGridHeight() - 40,
			width: rm.ui.getMaxGridWidth() - 60,
			pager: '#tblPager',
			multiselect: true,
			colModel: [
				{ name: 'Name', index: 'Name', label: 'Job Role', width: 300 },
				{ name: 'IsEnabled', index: 'IsEnabled', label: 'Is Enabled', width: 90 },
				{ name: 'HrName', index: 'HrName', label: 'Abbreviation', width: 270 }
			],
			viewsortcols: [true, 'vertical', true],
			sortorder: 'asc',
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			onPaging: function () { rm.ui.ribbon.delayedRefresh(); },
			onSelectRow: function (id) { rm.ui.ribbon.refresh(); },
			onSelectAll: function (rowIdxArray, sts) { rm.ui.ribbon.refresh(); },
			gridComplete: function () { },
			serializeGridData: function (postData) { return rm.grid.serializeGridData(postData); },
			beforeRequest: function () { rm.grid.setHeaderRowHeightDoubleLine("tblData"); },
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData(manageJrNs.gridSelector, data); }
		});
		$(manageJrNs.gridSelector).jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true, defaultSearch: "cn" });
	}
};