﻿///<reference path="../Common/RmHelper.js"/>
$(document).ajaxStop(function () { rm.ui.unblock(); });
$(document).ajaxStart(function () { rm.ui.block(); });

var resourceTypeAdmin = {
	customFieldDetails: null,
	organizationSelector: "#ddlOrganization",
	organizationalUnitSelector: "#ddlTDUOrganization",
	allOrganizationalUnitsSelector: "#ddlAllOrgUnits",
	btnAddCustomFieldSelector: "#btnAddCustomField",
	organizationaStructure: null,
	ddlCustomFieldSelector: "#ddlCustomField",
	resourceTypeNameSelector: "#txtResourceType",
	jobRoleSelector: "[id$=ddlJobRole]",
	showCompetencyBandSelector: "#ddlFilterCompetencyBandShow",
	defaultCompetencyBandSelector: "#ddlFilterCompetencyBandCheck",
	hdnHasAccessToEditResourceTypeSelector: "[id$=hdnHasAccessToEditResourceType]",
	allowEdit: function () { return $(resourceTypeAdmin.hdnHasAccessToEditResourceTypeSelector).val() == "1"; },
	hasMoreThanOneOrganizationalUnits: function () { return ($(resourceTypeAdmin.organizationSelector + " option:selected").attr("multiOrgUnit") == "true"); },
	isOrganizationSelected: function () { return resourceTypeAdmin.getOrganizationId() != "-1"; },
	isOrganizationalUnitSelected: function () { return resourceTypeAdmin.getOrganizationalUnitId() != "-1"; },
	getOrganizationId: function () { return $(resourceTypeAdmin.organizationSelector).val(); },
	getSingleOrganizationalUnitId: function () { return $(resourceTypeAdmin.organizationSelector + " option:selected").attr("OrganizationalUnitId"); },
	getOrganizationalUnitId: function () { return (resourceTypeAdmin.hasMoreThanOneOrganizationalUnits() ? $(resourceTypeAdmin.organizationalUnitSelector).val() : resourceTypeAdmin.getSingleOrganizationalUnitId()); },
	getResourceTypeName: function () { return $(resourceTypeAdmin.resourceTypeNameSelector).val(); },
	getJobRoleId: function () { return $(resourceTypeAdmin.jobRoleSelector).val(); },
	IsObsoletedByClinicalRedesign: function () { return $("#cbObsoletedByCrd").is(":checked"); },
	AllowResourcingRequirementMgmtToAsgnRes: function () { return $("#cbAllowResReqManagement").is(":checked"); },
	AdditionalOrganizationalUnitsList: [],
	bindOrganizationDropdown: function () {
		$.rm.Ajax_Administration("GetActiveOrganizations", {}, false, false, function (data) {
			resourceTypeAdmin.organizationaStructure = {};

			$(resourceTypeAdmin.organizationSelector).empty().append($("<option>", { value: -1 }).html("--Select--"));
			$.each(data, function (index, item) {
				var organization = resourceTypeAdmin.organizationaStructure[item.Id];
				if (organization == null) {
					organization = { organizationId: item.Id, organizationName: item.Name, multiOrgUnit: false, organizationalUnits: new Array() };
					resourceTypeAdmin.organizationaStructure[item.Id] = organization;
				}
				organization.organizationalUnits.push({ organizationalUnitId: item.OrganizationalUnitId, organizationalUnitName: item.OrganizationalUnitName });
				organization.multiOrgUnit = organization.organizationalUnits.length > 1;
			});

			for (var organizationId in resourceTypeAdmin.organizationaStructure) {
				var organization = resourceTypeAdmin.organizationaStructure[organizationId];
				$(resourceTypeAdmin.organizationSelector).append($("<option>", { value: organization.organizationId, multiOrgUnit: organization.multiOrgUnit, organizationalUnitId: organization.organizationalUnits[0].organizationalUnitId }).html(organization.organizationName));
			}

		});
	},
	getAdditionalOrganizationalUnitsList: function () { return $('#ddlAllOrgUnits').val(); },
	getAlwaysUnblindedValue: function () { return $("[name=AlwaysUnblinded]:checked").val() == "Yes"; },
	getDisplayBlindedFieldValue: function () { return resourceTypeAdmin.getAlwaysUnblindedValue() ? false : $("[name=DisplayBlinded]:checked").val() == "Yes"; },
	setAllAdditionalOrganizationalUnitForRRT: function () {
		$.rm.Ajax_Administration("GetAllAdditionalOrganizationalUnitNameListByRRT", { resourceTypeId: $.url().param("ResourceRequestTypeId") }, false, false, function (data) {
			resourceTypeAdmin.AdditionalOrganizationalUnitsList = [];
			$.each(data, function (index, item) {
				resourceTypeAdmin.AdditionalOrganizationalUnitsList.push({ Id: item.Id, Name: item.Name, IsSelected: item.IsSelected });
			});
		});
	},

	bindAllAdditionalOrganizationalUnitDropdown: function () {
		var data = resourceTypeAdmin.AdditionalOrganizationalUnitsList;
		$(resourceTypeAdmin.allOrganizationalUnitsSelector).empty();
		$.each(data, function (index, item) {
			if (item.Id != $(resourceTypeAdmin.organizationalUnitSelector).val()) {
				$(resourceTypeAdmin.allOrganizationalUnitsSelector).append($("<option>", { value: item.Id }).html(item.Name)).prop('checked', item.IsSelected);
				if (item.IsSelected)
					$(resourceTypeAdmin.allOrganizationalUnitsSelector + " option[value='" + item.Id + "']").prop("selected", "selected");
			}
		});
		$(resourceTypeAdmin.allOrganizationalUnitsSelector).multiselect({
			selectedList: 2, selectedText: function (numChecked, numTotal, checkedItems) {
				var returnValue = "";
				for (var i = 0; i < checkedItems.length; i++) {
					returnValue = returnValue + $(checkedItems[i]).siblings().text() + ",";
				}
				if (checkedItems.length > 0 & returnValue.length < 49)
					return returnValue.slice(0, -1);
				else
					return checkedItems.length + " Organizational Units Selected";
			}
		});
		$(resourceTypeAdmin.allOrganizationalUnitsSelector).multiselect('refresh');
		//$('.ui-multiselect').attr("style", "width:200px;");
	},

	populateOrganizationalUnitDropdown: function (organizationId) {
		var organizationalUnits = resourceTypeAdmin.organizationaStructure[organizationId].organizationalUnits
		$(resourceTypeAdmin.organizationalUnitSelector).empty().append($("<option>", { value: -1 }).html("--Select--"));
		$.each(organizationalUnits, function (index, item) {
			$(resourceTypeAdmin.organizationalUnitSelector).append($("<option>", { value: item.organizationalUnitId }).html(item.organizationalUnitName));
		});
	},

	handleOrganizationalUnitDropdownChange: function () {
		resourceTypeAdmin.bindAllAdditionalOrganizationalUnitDropdown();
	},

	handleOrganizationDropdownChange: function () {
		$(".adminItemList").empty();
		rm.validation.clearError($("#ddlTDUOrganization"));

		if (resourceTypeAdmin.isOrganizationSelected()) {
			rm.validation.clearError($("#ddlOrganization"));

			if (resourceTypeAdmin.hasMoreThanOneOrganizationalUnits()) {
				rm.validation.clearError($("#txtTargetUtlization"));
				rm.validation.clearError($("#txtTargetUtlization"));
				resourceTypeAdmin.showOrganizationalUnits();
				resourceTypeAdmin.populateOrganizationalUnitDropdown(resourceTypeAdmin.getOrganizationId());
				$("#ddlTDUOrganization").val("-1");
			}
			else {
				resourceTypeAdmin.hideOrganizationalUnits();
				$("#ddlTDUOrganization").val("-1");
				$(".adminItemList").empty();
			}
			resourceTypeAdmin.bindAllAdditionalOrganizationalUnitDropdown();
		}
	},
	bindOrganizationChangeEvent: function () {
		$(resourceTypeAdmin.organizationSelector).change(resourceTypeAdmin.handleOrganizationDropdownChange);
	},
	bindOrganizationalUnitChangeEvent: function () {
		$(resourceTypeAdmin.organizationalUnitSelector).change(resourceTypeAdmin.handleOrganizationalUnitDropdownChange);
	},

	bindJobRoleChangeEvent: function () {
		$(resourceTypeAdmin.jobRoleSelector).change(function () {
			if (resourceTypeAdmin.getJobRoleId() != -1) {
				rm.validation.clearError($(resourceTypeAdmin.jobRoleSelector));
			}
		});
	},

	hideOrganizationalUnits: function () { $("#tblRMAdminLayout .trMultiOrgUnit").fadeOut("normal"); },
	showOrganizationalUnits: function () { $("#tblRMAdminLayout .trMultiOrgUnit").fadeIn("normal"); },
	bindCustomFieldDropdown: function () {
		rm.ajax.adminSvcAsyncPost("GetCustomFieldList", {}, function (customFieldList) {
			resourceTypeAdmin.customFieldDetails = customFieldList;
			$(resourceTypeAdmin.ddlCustomFieldSelector).append($("<option>", { value: "-1", html: "--Select--" }));
			$.each(customFieldList, function (index, customField) {
				$(resourceTypeAdmin.ddlCustomFieldSelector).append($("<option>", { value: customField.FieldId, html: customField.FieldLabel }));
			});
		});
	},
	getSelectedCustomfieldDetails: function (customFieldId) {
		var details = null;
		if (resourceTypeAdmin.customFieldDetails != null) {
			$.each(resourceTypeAdmin.customFieldDetails, function (index, fieldDetail) {
				if (fieldDetail.FieldId == customFieldId) { details = fieldDetail; return false; }
			});
		}
		return details;
	},
	bindAssignUnblindedChange: function () { $("[name=AlwaysUnblinded]").change(resourceTypeAdmin.handleAssignUnblindedChange); },
	handleAssignUnblindedChange: function () {
		if (resourceTypeAdmin.getAlwaysUnblindedValue()) { $("#divBlindedField").hide(); }
		else { $("#divBlindedField").show(); }
	},

	customField: {
		classCustomFieldRow: "customFieldRow",
		attrCustomControlId: "CustomcontrolId",
		classEditRow: "elvisSkillsGridEditRow",
		attrUniqueId: "UniqueId",
		attrIsMandatory: "isMandatory",
		containerTableSelector: "#tblCustomFields",
		trCustomFieldTemplateRowSelector: "#trCustomFieldTemplateRow",
		cbCustFieldMandatorySelector: "#cbCustFieldMandatory",
		getControlTypeName: function (controlTypeId) {
			switch (controlTypeId) {
				case 1: return "Numeric";
				case 2: return "Date";
				case 3: return "Checkbox";
				case 4: return "Textbox";
				case 5: return "RadioButtonGroup";
				case 6: return "Dropdown";
				default: return "";
			}
		},
		isCustomFieldAddEnabled: function () { return !resourceTypeAdmin.customField.isInEditMode() && resourceTypeAdmin.customField.getSelectedCustomFieldId() != "-1"; },
		isCustomFieldEditEnabled: function () { return resourceTypeAdmin.customField.isInEditMode(); },
		isCustomFieldResetEnabled: function () { return resourceTypeAdmin.customField.isCustomFieldAddEnabled() || resourceTypeAdmin.customField.isCustomFieldEditEnabled(); },
		isInEditMode: function () {
			return $(resourceTypeAdmin.customField.containerTableSelector).find("." + resourceTypeAdmin.customField.classEditRow).length > 0;
		},
		jsonArrayToCommaSeparatedString: function (input) { return (input == null) ? "" : input.replace("[\"", "").replace("\"]", "").replace(/", "/g, ", "); },
		getSelectedCustomFieldId: function () { return $(resourceTypeAdmin.ddlCustomFieldSelector).val(); },
		isCustomFieldMandatory: function () { return $(resourceTypeAdmin.customField.cbCustFieldMandatorySelector).is(":checked"); },
		showTable: function () { $(resourceTypeAdmin.customField.containerTableSelector).show(); },
		add: function () {
			var fieldDetails = resourceTypeAdmin.getSelectedCustomfieldDetails(resourceTypeAdmin.customField.getSelectedCustomFieldId());
			if (fieldDetails != null) {
				if (resourceTypeAdmin.customField.addToTable(fieldDetails, resourceTypeAdmin.customField.isCustomFieldMandatory())) {
					resourceTypeAdmin.customField.reset();
					$.RMAdmin._isSaveButtonEnabled = true;
				}
				rm.ui.ribbon.delayedRefresh();
			}
		},
		alreadyAdded: function (cusotmFieldId) { return $(resourceTypeAdmin.customField.containerTableSelector).find("tr[" + resourceTypeAdmin.customField.attrCustomControlId + "=" + cusotmFieldId + "]").length != 0; },
		addToTable: function (fieldDetails, isMandatory) {
			if (resourceTypeAdmin.customField.alreadyAdded(fieldDetails.FieldId)) {
				alert("Customfield has already been added.");
				return false;
			}
			else {
				var templateRow = $(resourceTypeAdmin.customField.trCustomFieldTemplateRowSelector).clone();
				templateRow.removeAttr("id")
									 .attr(resourceTypeAdmin.customField.attrUniqueId, fieldDetails.ResourceTypeCustomFieldId)
									 .attr(resourceTypeAdmin.customField.attrIsMandatory, (isMandatory ? "1" : "0"))
									 .addClass(resourceTypeAdmin.customField.classCustomFieldRow);
				templateRow.find("td[key=label]").text(fieldDetails.FieldLabel);
				templateRow.find("td[key=isMandatory]").text(isMandatory ? "Yes" : "No");
				templateRow.find("td[key=controlType]").text(resourceTypeAdmin.customField.getControlTypeName(fieldDetails.ControlType));
				templateRow.find("td[key=valueList]").text(resourceTypeAdmin.customField.jsonArrayToCommaSeparatedString(fieldDetails.ValuesList));
				templateRow.find("td[key=defaultValue]").text(fieldDetails.DefaultValue);
				templateRow.find("td[key=isMultiSelect]").text(fieldDetails.IsMultipleSelect ? "Yes" : "No");
				templateRow.find("td[key=toolTip]").text(fieldDetails.ToolTip);
				templateRow.find("td[key=errorMessage]").text(fieldDetails.ErrorMessage);
				templateRow.attr(resourceTypeAdmin.customField.attrCustomControlId, fieldDetails.FieldId);
				if (fieldDetails.FieldUsedInRequest) {
					templateRow.find("td[key=commandColumn]").html("");
				}
				else {
					templateRow.find(".cmdEditCustField").click(function () { resourceTypeAdmin.customField.edit($(this.closest("tr"))); });
					templateRow.find(".cmdDeleteCustField").click(function () { resourceTypeAdmin.customField.deleteField($(this.closest("tr"))); });
				}
				templateRow.show();
				$(resourceTypeAdmin.customField.containerTableSelector).append(templateRow);
				return true;
			}
		},
		edit: function (editRow) {
			var customFieldId = editRow.attr(resourceTypeAdmin.customField.attrCustomControlId);
			var isMandatory = editRow.find("td[key=isMandatory]").attr("isMandatory") == "1"
			editRow.addClass(resourceTypeAdmin.customField.classEditRow);
			$(resourceTypeAdmin.ddlCustomFieldSelector).val(customFieldId).attr("disabled", "disabled");
			$(resourceTypeAdmin.customField.cbCustFieldMandatorySelector).attr("checked", isMandatory);
			$.RMAdmin._isSaveButtonEnabled = true;
			rm.ui.ribbon.delayedRefresh();
		},
		deleteField: function (deleteRow) {
			var customFieldId = deleteRow.attr(resourceTypeAdmin.customField.attrCustomControlId);
			if ($(resourceTypeAdmin.customField.containerTableSelector).find("." + resourceTypeAdmin.customField.classEditRow).length > 0) {
				alert('Please update/cancel the edited row before you continue deleting this row');
			}
			else {
				if (confirm("Are you sure you want to delete this custom field?")) {
					deleteRow.remove();
					$.RMAdmin._isSaveButtonEnabled = true;
				}
			}
			rm.ui.ribbon.delayedRefresh();
		},
		update: function () {
			var tableRow = $(resourceTypeAdmin.customField.containerTableSelector).find("." + resourceTypeAdmin.customField.classEditRow);
			var isMandatory = resourceTypeAdmin.customField.isCustomFieldMandatory();
			tableRow.find("td[key=isMandatory]").text(isMandatory ? "Yes" : "No").closest("tr").attr(resourceTypeAdmin.customField.attrIsMandatory, (isMandatory ? "1" : "0"));
			tableRow.removeClass(resourceTypeAdmin.customField.classEditRow);
			resourceTypeAdmin.customField.reset();
		},
		reset: function () {
			$(resourceTypeAdmin.ddlCustomFieldSelector).val("-1").removeAttr("disabled");
			$(resourceTypeAdmin.customField.cbCustFieldMandatorySelector).attr("checked", false);
			$(resourceTypeAdmin.customField.containerTableSelector).find("." + resourceTypeAdmin.customField.classEditRow).removeClass(resourceTypeAdmin.customField.classEditRow);
			rm.ui.ribbon.delayedRefresh();
		},
		getCustomfieldPostData: function () {
			var customFieldPostdata = [];

			$.each($(resourceTypeAdmin.customField.containerTableSelector).find("tr." + resourceTypeAdmin.customField.classCustomFieldRow), function (index, fieldRow) {
				customFieldPostdata.push({
					ResourceTypeCustomFieldId: $(fieldRow).attr(resourceTypeAdmin.customField.attrUniqueId),
					FieldId: $(fieldRow).attr(resourceTypeAdmin.customField.attrCustomControlId),
					IsMandatory: $(fieldRow).attr(resourceTypeAdmin.customField.attrIsMandatory) == "1"
				});
			});

			return customFieldPostdata;
		}
	}
};

var bindingObject = {
	spanAssignedCountryListClick: function () {
		$("#spanAssignedCountryList").bind("click", function (event) { return false; });
	},

	//SS:this function gets called when Region dropdown is clicked
	imgAssignedRegionListClick: function () {
		$("#imgAssignedRegionList").bind("click", function (event) {
			if ($("#imgAssignedRegionList").attr("isHideShow") == "show") {
				if ($.Utilization._regionIds == "") {
					$.Utilization.ClearAssignSubRegion();
					$.Utilization.ClearAssignCountry();
				}
				else {
					$.ajax({
					    url: rm.ajax.requestSvcUrl + "GetAllSubRegionsByRegion?regionIds=" + $.Utilization._regionIds,
						type: "GET",
						contentType: "application/json; charset=utf-8",
						dataType: "json",
						cache: false,
						async: false,
						success: function (data) {
							if (!data.ContainsValidationErrors) {
								$.Utilization.BindAssignedSubRegion($.parseJSON(data));
							}
						},
						error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: GetAllSubRegionsByRegion", data.responseText); }
					});
				}
			}
			if ($("#imgAssignedRegionList").attr("isHideShow") == "hide") {
				$("#imgAssignedRegionList").attr("isHideShow", "show");
			}
			else {
				$("#imgAssignedRegionList").attr("isHideShow", "hide");
			}

			if ($(".dropDownMenuUSubregionList").size() > 0) //hide subregion and country dropdowns if visible
			{
				$(".dropDownMenuUSubregionList").remove();
			}
			if ($(".dropDownMenuUCountryList").size() > 0) {
				$(".dropDownMenuUCountryList").remove();
			}
		});
	},

	//SS:this function gets called when SubRegion dropdown is clicked
	imgAssignedSubregionListClick: function () {
		$("#imgAssignedSubregionList").bind("click", function (event) {
			if ($("#imgAssignedSubregionList").attr("isHideShow") == "show") {
				if ($.Utilization._subRegionIds == "") {
					$.Utilization.ClearAssignCountry();
				}
				else {
					$.ajax({
					    url: rm.ajax.requestSvcUrl + "GetAllCountriesBySubRegion?subRegionIds=" + $.Utilization._subRegionsForPost,
						type: "GET",
						contentType: "application/json; charset=utf-8",
						dataType: "json",
						cache: false,
						async: false,
						success: function (data) {
							if (data.ContainsValidationErrors) {
								//alert($.Utilization._regionIds);
							}
							else {
								$.Utilization.BindAssignedCountry($.parseJSON(data));
							}
						},
						error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: GetAllSubRegionsByRegion", data.responseText); }
					});
				}
			}
			if ($("#imgAssignedSubregionList").attr("isHideShow") == "hide") {
				$("#imgAssignedSubregionList").attr("isHideShow", "show");
			}
			else {
				$("#imgAssignedSubregionList").attr("isHideShow", "hide");
			}

			if ($(".dropDownMenuURegionList").size() > 0)//SS:hide region and country dropdowns when subregion dropdown was clicked
			{
				$(".dropDownMenuURegionList").remove();
			}
			if ($(".dropDownMenuUCountryList").size() > 0) {
				$(".dropDownMenuUCountryList").remove();
			}
		});
	},

	//SS:this function gets called when country dropdown is clicked
	imgAssignedCountryListClick: function () {
		$('#imgAssignedCountryList').bind('click', function (event) {
			if ($("#imgAssignedCountryList").attr("isHideShow") == "hide") {
				$("#imgAssignedCountryList").attr("isHideShow", "show");
			}
			else {
				$("#imgAssignedCountryList").attr("isHideShow", "hide");

				if ($(".dropDownMenuUCountryList").size() > 0) {
					setTimeout(function () { $(".dropDownMenuUCountryList").remove(); }, 100);
				}
			}
			if ($(".dropDownMenuUSubregionList").size() > 0) {
				$(".dropDownMenuUSubregionList").remove();
			}
			if ($(".dropDownMenuURegionList").size() > 0) {
				$(".dropDownMenuURegionList").remove();
			}
		});
	},

	//SS:Click on regiondropdown span return nothing
	spanAssignedRegionListClick: function () {
		$("#spanAssignedRegionList").bind("click", function (event) { return false; });
	},

	//SS:Click on subregion span return nothing 
	spanAssignedSubregionListClick: function () {
		$("#spanAssignedSubregionList").bind("click", function (event) { return false; });
	},
};
$(document).ready(function () {
	rm.runtimeValues.helpPageUrl = "#";
	$("#Link_ResourceRequestList").addClass("left-static-selected-menu");

	var DefuaulMileStonesData;
	$("#tabs").tabs();
	$.RMAdmin.LoadDefaultMileStonesData();
	$.RMAdmin.HideMilestoneRows();
	resourceTypeAdmin.bindOrganizationChangeEvent();
	resourceTypeAdmin.bindOrganizationalUnitChangeEvent();
	resourceTypeAdmin.bindJobRoleChangeEvent();
	resourceTypeAdmin.bindCustomFieldDropdown();
	resourceTypeAdmin.bindAssignUnblindedChange();

	$("#dynamicContent").hide();
	$("#tableHolder").hide();
	$("#tblAdminFilter").hide();
	$("#divTgtUtilization").hide();
	$("#divCustomFieldContainer").hide();
	$.RMAdmin.ElvisPanelExpandAndCollapse();
	$.RMAdmin.RRTFilterExpandAndCollapse();
	$.RMAdmin.targetUtilizationExpandAndCollapse();
	$.RMAdmin.customFieldsExpandAndCollapse()
	$("#elvisSkillsContainer1, #elvisSkillsContainer2").click(function (e) {
		$("#dynamicContent").slideToggle('slow');
		$("#tableHolder").slideToggle('slow');
		setTimeout(function () { $.RMAdmin.ElvisPanelExpandAndCollapse() }, 650);
	});

	$("#rrtFilterContainer1, #rrtFilterContainer2").click(function (e) {
		$("#tblAdminFilter").slideToggle('slow');
		setTimeout(function () { $.RMAdmin.RRTFilterExpandAndCollapse() }, 650);
	});

	$("#tuContainer1, #tuContainer2").click(function (e) {
		$("#divTgtUtilization").slideToggle('slow');
		setTimeout(function () { $.RMAdmin.targetUtilizationExpandAndCollapse() }, 650);
	});

	$("#customFieldContainrer, #rrtCustomContainer").click(function (e) {
		$("#divCustomFieldContainer").slideToggle('slow');
		setTimeout(function () { $.RMAdmin.customFieldsExpandAndCollapse() }, 650);
	});

	$("#dynamicContent").on("change keypress", "input", function () {
		$.RMAdmin._isResetElvisButtonEnabled = true;
		var activeTabNumber = rm.ui.tabs.getSelecteTabIndex("#tabs") + 1;

		if ($("#hdnEdit").val() == "1" && activeTabNumber == $("#hdnUpdateTab").val().split("_")[0]) {
			if (activeTabNumber == 4 && $("#hdnUpdateTab").val().split("_")[1] != $("#ddlDepartment").val()) {
				$.RMAdmin._isAddButtonEnabled = true;
			} else {
				$.RMAdmin._isUpdateButtonEnabled = true;
			}
		} else {
			$.RMAdmin._isAddButtonEnabled = true;
		}
		rm.ui.ribbon.refresh();
	});

	$("#divCustomFieldContainer").on("click change keypress", "input,select", function (event) { rm.ui.ribbon.delayedRefresh(); });

	$("#tabsul").find("a").click(function (e) {
		$.SkillSet.SetAddUpdateButton($(this).closest('li')[0].id);
	});

	resourceTypeAdmin.bindOrganizationDropdown();
	resourceTypeAdmin.setAllAdditionalOrganizationalUnitForRRT();//At the time of Doc Load, this will get all the Additional Organizational Unit Details
	resourceTypeAdmin.bindAllAdditionalOrganizationalUnitDropdown();

	$.RMAdmin._isResetButtonEnabled = true;
	$.SkillSet.UpdateToolTipText();
	$.SkillSet.UpdateTooltipWithImage();
	$.SkillSet.DisableFilterControls();
	$.Utilization.AssignRegion();
	bindingObject.spanAssignedRegionListClick();
	bindingObject.spanAssignedSubregionListClick();
	bindingObject.spanAssignedCountryListClick();
	bindingObject.imgAssignedRegionListClick();
	bindingObject.imgAssignedSubregionListClick();
	bindingObject.imgAssignedCountryListClick();
	var NewResourceRequestType = $.url().param("NewResourceRequestType");
	$.ResourceRequest.resourceRequestTypeId = $.url().param("ResourceRequestTypeId");
	if (NewResourceRequestType && NewResourceRequestType == "false") {
		if ($.ResourceRequest.resourceRequestTypeId && $.ResourceRequest.resourceRequestTypeId != "0") {
			$.ResourceRequest.RefetchResourcetypeDetails();
			$.SkillSet.GenerateHtmlForEditFilter($.ResourceRequest.resourceRequestTypeId);//SS:Resource Request type is in Edit mode

			//RMK: Added to pre populate the skill filter summary table
			$.SkillSet.GetHtmlForSkillFilter($.ResourceRequest.resourceRequestTypeId);
		}
	}
	else {
		$.SkillSet.GetSkillsetFilterHtml(); //SS:Resource Request type is in Add mode
		$("#chkEnabled, #chkCanInitiate").attr("checked", "checked");
		$.RMAdmin.AddFirstGenericRow();
	}
	bindDirty();

	$("#skillsetFilterHtml").css("display", "none");

	$(":input[id$=txtStartDate]").qDatepicker({ 'allowBlank': false, 'validate': false })

	if (!resourceTypeAdmin.allowEdit()) {
		$(".adminFieldsetContainer").find("input,select").attr("disabled", "disabled");
	}
	bindEventHandlers();
})

//SS:trigger dropdown clicks manually
$(document).click(function () {
	if ($.Utilization._stillInEdit)//SS:When utilization is in edit mode this gets called on each item(unnecessary calls avoided).call this function only for last item by setting flag to true.
	{
		if ($(".dropDownMenuURegionList").size() > 0) {
			$("#imgAssignedRegionList").trigger('click');
			setTimeout(function () { $(".dropDownMenuURegionList").remove(); }, 100);
		}
		if ($(".dropDownMenuUCountryList").size() > 0) {
			$("#imgAssignedCountryList").trigger('click');
			setTimeout(function () { $(".dropDownMenuUCountryList").remove(); }, 100);
		}
		if ($(".dropDownMenuUSubregionList").size() > 0) {
			$("#imgAssignedSubregionList").trigger('click');
			setTimeout(function () { $(".dropDownMenuUSubregionList").remove(); }, 100);
		}
		$("#imgAssignedRegionList").attr("isHideShow", "hide");
		$("#imgAssignedSubregionList").attr("isHideShow", "hide");
		$("#imgAssignedCountryList").attr("isHideShow", "hide");
	}
});

$.ResourceRequest =
{
	ResourceRequestTypeId: 0,
	RefetchResourcetypeDetails: function () {

		if ($.ResourceRequest.resourceRequestTypeId != "0") {
			$.ajax({
			    url: rm.ajax.requestSvcUrl + "GetResourceRequestTypeDetails?resourceRequestTypeId=" + $.ResourceRequest.resourceRequestTypeId,
				type: "GET",
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				cache: false,
				async: false,
				success: function (data) {
					if (data.ContainsValidationErrors) {
						$.validationHelper.ShowErrorMessages(data.ValidationErrors);
					}
					else {
						var additionalData = data.RequestExecutionStatus[0].AdditionalData;
						$.ResourceRequest.MapResourceRequestTypeValuesToControls(additionalData);
						bindDirty();
					}
				},
				error: function (data, e) { $.rm.ShowHtmlPopup("Web Service Error: GetResourceRequestTypeDetails", data.responseText); }
			});
		}
	},
	MapResourceRequestTypeValuesToControls: function (data) {
		$.ResourceRequest.ResourceRequestTypeId = data.ResourceTypeId;
		$("#hdnWasResourceTypeEnabled").val(data.IsEnabled);
		$("#ddlOrganization").val(data.OrganizationId);
		$("#txtResourceType").val(data.ResourceRequestName);
		$(resourceTypeAdmin.jobRoleSelector).val(data.JobRoleId);
		$("#txtResourceTrasitionTime").val(data.ResourceTransitionTime);
		data.IsEnabled ? $("#chkEnabled").attr('checked', true) : $("#chkEnabled").attr('checked', false);
		data.CanInitiateNewRequests ? $("#chkCanInitiate").attr('checked', true) : $("#chkCanInitiate").attr('checked', false);
		if (data.EnableProposalRequest) {
			$('#chkProposal').attr('checked', 'checked');
		}

		$("#cbObsoletedByCrd").prop('checked', data.ObsoletedByClinicalRedesign);
		$("#cbAllowResReqManagement").prop('checked', data.AllowResourcingRequirementMgmtToAsgnRes);

		setTimeout(function () {
			resourceTypeAdmin.handleOrganizationDropdownChange();
			setTimeout(function () { $(resourceTypeAdmin.organizationalUnitSelector).val(data.OrganizationUnitId); }, 10);
			setTimeout(function () { resourceTypeAdmin.bindAllAdditionalOrganizationalUnitDropdown(); }, 10);
		}, 10);

		if (data.MatchingSkills)//SS:just check for "falsey" in jquery,this is equivalent to IsNullorEmpty in C#
		{
			$("#projectMilestone tr").remove();//clear the table
			$.SkillSet.AddTableHead();
			$(data.MatchingSkills).each(function (index) {
				if (this) {
					$.SkillSet.CreateTableForEdit((this));
				}
			});
		}
		if (data.listDispalyUtilization) {
			$.Utilization.AddTableHead();
			$(data.listDispalyUtilization).each(function (index) {
				if (this) {
					$.Utilization.CreateTableForEdit((this));
				}
			});
		}
		if (data.listCustomFields) {
			resourceTypeAdmin.customField.showTable();
			//CustomFields.AddTableHead();
			$(data.listCustomFields).map(function (index) {
				if (this) {
					resourceTypeAdmin.customField.addToTable(this, this.IsMandatory);
				}
			});
		}
		if (data.listDefaultMiltestones) {
			if (!($.RMAdmin.BindExistingMileStones(data.listDefaultMiltestones))) {
				$.RMAdmin.AddFirstGenericRow();
			}
		}
		$.SkillSet.PopulateMatchingSkills(data);
		$("[name=AlwaysUnblinded][value=" + (data.AssigneesAlwaysUnblinded ? "Yes" : "No") + "]").attr("checked", true);
		$("[name=DisplayBlinded][value=" + (data.DisplaysBlindedField ? "Yes" : "No") + "]").attr("checked", true);
		setTimeout(resourceTypeAdmin.handleAssignUnblindedChange, 10);
	}
};
var bindEventHandlers = function () {
	var inputSelector = resourceTypeAdmin.jobRoleSelector + ",#ddlAllOrgUnits,#ddlOrganization,#ddlTDUOrganization,#searchHrName,#txtResourceType,#txtTargetUtlization,#txtGlobalTargetUtilization,#searchDepartment,#searchFmCode,#searchJobCode,#chkProposal,#txtResourceTrasitionTime,#txtHrName,.default,.filter,.skill,#btnUtilizationUpdate,.deleteUtilization,#btnUtilizationAdd,#chkDefaultMilestone,#cbObsoletedByCrd,#cbAllowResReqManagement,#GenericFTETable select:visible,#GenericFTETable img,#GenericFTETable input,#btnGenericFirstAdd,#chkEnabled,#chkCanInitiate";
	$(document).on("keyup change cut paste click", inputSelector, function (event) {
		$.RMAdmin._isSaveButtonEnabled = true;
		$.RMAdmin._isCancelButtonEnabled = true;
		rm.ui.ribbon.refresh();
	});

	//SS:QRPM-4815-When RRT is in edit mode filter dropdown event is triggered,dont enable the save button if it was not a user action
	$(".filter").on("change", function (event) {
		if (event.which)//SS:Check if it was user who triggered the event
		{
			//user Change then enable the save button
			$.RMAdmin._isSaveButtonEnabled = true;
			$.RMAdmin._isCancelButtonEnabled = true;
			rm.ui.ribbon.refresh();
		}
	});

	$('input[name=AlwaysUnblinded],input[name=DisplayBlinded]').on("click", function () {
		$.RMAdmin._isSaveButtonEnabled = true;
		$.RMAdmin._isCancelButtonEnabled = true;
		rm.ui.ribbon.refresh();
	});

	$("#chkDefaultMilestone").on("change", function () {
		if ($.RMAdmin.IsDefaultMilestoneSelected()) {
			$.RMAdmin.ShowMilestoneRows();
		}
		else {
			$.RMAdmin.HideMilestoneRows();
			rm.validation.clearError($("#GenericFTECalculator").find('select'));
		}
	});

	$("#chkEnabled, #chkCanInitiate").on("change", function () {
		var isDirty = CheckPageDirty();
		if (!isDirty) {
			bindDirty();
		}
	});

	$("#utilizationResult").on("click", ".deleteUtilization", function (event) {
		if ($("#hdnUtilization").val() != "1") {
			if (confirm("Are you sure you want to delete this Utilization?")) {
				$(this).closest('tr').remove();
				if ($('#tblUtilization tbody tr').length == 0) {
					$('#tblUtilization').remove();
				}
			}
			else {
				return false;
			}
		}
		else {
			alert('A row is in edit mode,please update/cancel it before deleting this row');
			return;
		}
	});

	$("#utilizationResult").on("click", ".editUtilization", function (event) {
		if ($('#hdnUtilization').val() == "1") {
			alert('A row is in edit mode,please update/cancel it before editing this row');
			return;
		}
		$.Utilization.SetButtonsVisibilityForEdit(true);
		$('#btnUtilizationUpdate').attr('editedrow', $(this).closest('td').parent()[0].sectionRowIndex);	//Note:row index starts from 0.
		var _type = $(this).closest('tr').find('td:eq(0)').text();
		var rIds = $(this).closest('tr').find('td:eq(5)').text();
		var sIds = $(this).closest('tr').find('td:eq(6)').text();
		var cIds = $(this).closest('tr').find('td:eq(7)').text();
		$("#txtTargetUtlization").val($(this).closest('tr').find('td:eq(4)').text());
		if (_type.toLowerCase() == "c") {
			$.Utilization.CountryListClickForEdit(rIds, sIds, cIds);
		}
		else if (_type.toLowerCase() == "s") {
			$.Utilization.SubregionListClickForEdit(rIds, sIds);
		}
		else if (_type.toLowerCase() == "r") {
			$.Utilization.RegionListClickForEdit(rIds);
		}
		$("#hdnUtilization").val("1");//to set the form is in edit mode
	});

	$('#btnUtilizationCancel').on('click', function (event) {
		$('#hdnUtilization').val("0");
		$.Utilization.SetButtonsVisibilityForEdit(false);
		$.Utilization.ClearAssignSubRegion();//clear the saved variables
		$.Utilization.ClearAssignCountry();
		$.Utilization.AssignRegion();//Rebind the RegionList to clear off already selected values.
		$("#txtTargetUtlization").val("");
		//RMK: Added to reset the validation error
		$.Utilization.ClearErrorMessage();
	});

	$(document).on("change", "#ddlDepartment", function (event) {
		$.SkillSet.ChangeVisibility("#ddlDepartment", $("#ddlDepartment").val());
	});

	$(document).on("change", "#ddlDepartmentFilter", function (event) {
		var selectedValue = $("#ddlDepartmentFilter").val();
		$.SkillSet.ChangeVisibilityFilter("#ddlDepartmentFilter", selectedValue);
		if (selectedValue == "-1") {
			$("#btnFilterOk").attr("disabled", "disabled");
		}
		else {
			$("#btnFilterOk").removeAttr("disabled");
		}
	});

	$(".filter").on('change', function (event) {
		var selectedValue = $(this).val();
		var id = $(this).attr('id');
		var getIdToEnable = id.slice(0, -4);

		var idToEnable = "";
		if (id === "ddlFilterSkillsShow") {
			idToEnable = "#btnFilterSkillsCheck";
		}
		else {
			idToEnable = "#" + getIdToEnable + "Check";
		}

		if (selectedValue === "1") {
			$(idToEnable).removeAttr("disabled");
		}
		else {
			if ($(idToEnable).attr("type") != "button") {
				$(idToEnable).val("0");
			}
			$(idToEnable).attr("disabled", "disabled");
		}
	});

	$(document).on("change", ".getDisabledSkills", function (event) {
		var id = $(this).attr('id');
		var idArray = id.split("_");
		if ($(this).attr('checked')) {
			$(this).closest("tr").find("td:eq(2)").removeAttr("disabled");
		}
		else {
			if (idArray[0] == "chkrad") {
				var idToReset = "radFilter_" + idArray[1] + "_" + idArray[2];
				$("input[name='" + idToReset + "']").prop('checked', false);
			}
			else if (idArray[0] == "chkchk") {
				var idToReset = "chkFilter_" + idArray[1] + "_" + idArray[2];
				$("[id='" + idToReset + "']").attr('checked', false);
			}
			else if (idArray[0] == "chkddl") {
				var idToReset = "ddlFilter_" + idArray[1] + "_" + idArray[2];
				$("[id='" + idToReset + "']").val("-1");
			}

			$(this).closest("tr").find("td:eq(2)").attr("disabled", "disabled");
		}
	});

	$(document).on("click", "a.edit", function (event) {
		$.SkillSet.ResetControl();//to reset controls if another row was edited
		if ($("#hdnEdit").val() == "1") {
			alert('A row is in edit mode,please update/cancel it before editing this row');
			return;
		}
		var _rowNumber = $(this).closest('td').parent()[0].sectionRowIndex;	//Note:row index starts from 0.
		var _populateData = $(this).closest('tr').find('td:eq(4)').text();
		var _categoryId = $(this).closest('tr').find('td:eq(1)').text();
		var _departmentId = $(this).closest('tr').find('td:eq(5)').text();
		$("#hdnEdit").val("1");//to set the form is in edit mode
		$("#hdnEditRowId").val($(this).closest('td').parent()[0].sectionRowIndex);
		$("#hdnUpdateTab").val($(this).closest('tr').find('td:eq(1)').text() + "_" + $(this).closest('tr').find('td:eq(5)').text());
		$.SkillSet.SetFocusOnTab(_categoryId - 1);
		if (_departmentId != "0") {
			$("#ddlDepartment").val(_departmentId);
			$("#ddlDepartment").change();
			$('#btnUpdateDepartment_' + _departmentId + '_' + _categoryId).attr('editRow', _rowNumber);
		}
		else {
			$('#btnUpdate_' + _categoryId).attr('editRow', _rowNumber);//to track which row was edited
		}
		$.SkillSet.PreSelectSkillData(_populateData);
		$.SkillSet.IsUpdateButtonVisible(_departmentId, _categoryId, true);
		$("#dynamicContent").focus();
		$(this).closest('tr').addClass('elvisSkillsGridEditRow');
		$.RMAdmin._isResetElvisButtonEnabled = true;
		rm.ui.ribbon.refresh();
	});

	$(document).on("click", "a.delete", function (event) {
		if ($("#hdnEdit").val() != "1") {
			if (confirm("Are you sure you want to delete this skillset?")) {
				var _populateData = $(this).closest('tr').find('td:eq(4)').text();
				var arrayLevelOne = $.map(_populateData.split(';'), $.trim);
				for (var i = 0; i < arrayLevelOne.length; i++) {
					if (arrayLevelOne[i] != "") {
						var arrayLevelTwo = arrayLevelOne[i].split('~');
						if (arrayLevelTwo[0].indexOf("chk") >= 0) {
							$("[id='" + arrayLevelTwo[0] + "']").prop('checked', false).prop('disabled', false);//enable the checkbox and uncheck it.
						}
					}
				}
				$(this).closest('tr').remove();//delete the row as user requested.
			}
			else {
				return false;
			}
		}
		else {
			alert('Please update/cancel the edited row before you continue deleting this row');
			return false;
		}
	});

	$(document).on("mouseup", ".radioButton_Department", function (event) {
		var name = $(this).attr('name');
		var value = $("input[name='" + name + "']:radio:checked").val();
		$.SkillSet._selectedRadioButtonValue = value;

	});

	$(document).on("change", ".radioButton_Department", function (event) {
		var name = $(this).attr('name');
		var valueExists = 0;
		var valueNAExists = false;
		var valueZeroExists = false;
		var selectedValue = $.trim($("input[name='" + name + "']:radio:checked").val());
		$('#projectMilestone tbody tr').map(function (i) {
			var categoryString = $(this).find('td:nth-child(5)').text();
			var arrayLevelOne = categoryString.split(';');
			for (var i = 0; i < arrayLevelOne.length; i++) {
				if (arrayLevelOne[i] != "") {
					var arrayLevelTwo = arrayLevelOne[i].split('~');
					var radioButtonName = $.trim(arrayLevelTwo[0]);
					var radioButtonValue = arrayLevelTwo[1];
					if (radioButtonName == name && radioButtonValue != "N/A" && radioButtonValue != "0") {
						valueExists++;
					}
					if (radioButtonName == name && radioButtonValue == "N/A") {
						valueNAExists = true;
					}
					if (radioButtonName == name && radioButtonValue == "0") {
						valueZeroExists = true;
					}
				}
			}
		});

		if (valueExists == 1 && $("#hdnEdit").val() != "1") {
			if (selectedValue == "N/A" || selectedValue == "0") {
				$("input[name='" + name + "']").prop('checked', false);
				alert('Value cannot be selected as N/A Or 0.');
			}
		}
		if (valueExists > 1) {
			if (selectedValue == "N/A" || selectedValue == "0") {
				$("input[name='" + name + "']").prop('checked', false);
				if ($("#hdnEdit").val() == "1") {
					$("input[name='" + name + "'][value='" + $.SkillSet._selectedRadioButtonValue + "']").prop('checked', true);
				}
				alert('Value cannot be selected as N/A Or 0.');
			}
		}
		if (valueNAExists && $("#hdnEdit").val() != "1" && selectedValue != "N/A") {
			$("input[name='" + name + "']").prop('checked', false);
			alert('Value cannot be selected other than N/A Or 0.');
		}
		if (valueZeroExists && $("#hdnEdit").val() != "1" && selectedValue != "0") {
			$("input[name='" + name + "']").prop('checked', false);
			alert('Value cannot be selected other than N/A Or 0.');
		}
	});
};
bindDirty = function () {
	$.formStatus.bindDirty(Resources.UnsavedChangesOnThePageShort, getJsonObjectForDirtyCheck());
};

getJsonObjectForDirtyCheck = function () {
	return { items: [{ selector: resourceTypeAdmin.jobRoleSelector + ",#txtResourceType,#txtSecTerRoles,#txtTargetUtlization,#txtDepartment,#txtJobCode,#txtFmCode,#chkProposal,#txtResourceTrasitionTime,#cbObsoletedByCrd,#cbAllowResReqManagement,#GenericFTETable select:visible,#GenericFTETable img,#btnGenericFirstAdd,#chkEnabled,#chkCanInitiate", dirtyAlertMessage: Resources.UnsavedChangesOnThePageShort }] };
};

CheckPageDirty = function () {
	return $.formStatus.isDirty(getJsonObjectForDirtyCheck());
};

$(document).delegate(".imgDeleteGenericRow", 'click', function () {
	if ($('#GenericFTETable tbody tr').length > 1) {
		if (confirm('Are you sure you want to delete this milestone stage?')) {
			var row = $(this).closest('tr');
			var prev = row.prev();
			var next = row.next();
			$.RMAdmin.DeleteGenericRow(this);
			if (prev.length > 0) {
				$.RMAdmin.UpdateNextMileStoneSatge(prev, next);
			}
			$.RMAdmin.RebindStage();
			if ($('#GenericFTETable tbody tr').length == 1) {
				$("#GenericFTECalculator tr:first").find('[id^=milestone_start]').attr('disabled', false);
			}
		}
	}
	else {
		alert("Stage cannot be deleted.");
	}
	var chkDirty = CheckPageDirty();
	if (!chkDirty) {
		bindDirty();
		rm.ui.ribbon.refresh();
	}
});

$(document).delegate(".toMilestoneEndDate", 'change', function () {
	var Counter = this.getAttribute("data-value");
	var MilestoneEndId = $("#milestone_end_" + Counter).val();

	var row = $(this).closest('tr');
	var next = row.next();
	if (next.length > 0) {
		$.RMAdmin.UpdateNextMileStoneSatge(row, next);
	}
	var isDirty = CheckPageDirty();
	if (!isDirty) {
		bindDirty();
	}
});

$.RMAdmin =
{
	_organizationUnitName: null,
	_resourceTypeName: null,
	_organizationUnitId: null,
	_organizationId: null,
	_resourceTypeId: null,
	_department: null,
	_fmCode: null,
	_secTerRole: null,
	_jobCode: null,
	_utilization: null,
	_resourceTransitionTime: null,
	_enableinProposal: 0,
	_isSaveButtonEnabled: false,
	_isCancelButtonEnabled: false,
	_isResetButtonEnabled: false,
	_deletedDepartmentCodes: "",
	_deletedJobCodes: "",
	_deletedFmCodes: "",
	_deletedSecTerRoles: "",
	_departmentSmartSearchData: [],
	_jobCodeSmartSearchData: [],
	_fmCodeSmartSearchData: [],
	_startMilestone: 0,
	_stopMilestone: 0,
	_isAddButtonEnabled: false,
	_isUpdateButtonEnabled: false,
	_isResetElvisButtonEnabled: false,
	_newGenericRowID: 0,
	managePageUrl: "/_Layouts/SPUI/Admin/ResourceType/Manage.aspx",

	//For Cancel button functionality from the ribbon
	Cancel: function () {
		var isDirty = CheckPageDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			bindDirty();
			document.location.reload();
		}
	},

	Close: function () {
		var isDirty = CheckPageDirty();
		if (!isDirty || (isDirty && confirm(Resources.UnsavedChangesOnThePage))) {
			document.location.href = $.RMAdmin.managePageUrl;
		}
	},
	//Check smart search value already added or not
	IsExists: function (toText, fromText) {
		var isExists = false;
		var array = toText.split(",");
		$.each(array, function (i) {
			if (array[i].toUpperCase() === fromText.toUpperCase()) {
				isExists = true;
			}
		});

		return isExists;
	},

	RequestEnabled: function () {
		var submitEnabled = true;
		if ($.RMAdmin.WasResourceTypeEnabled() && !$("#chkEnabled").attr("checked")) {
			confirm(Resources.ResourceRequestEnabled) ? submitEnabled = true : submitEnabled = false;
		}
		return submitEnabled;
	},
	//Save the new resource type withe the selected organization,department,jobcode,FM Code etc.
	SaveData: function () {
		if ($.RMAdmin.Validate() && $.RMAdmin.RequestEnabled()) {
			var dataToSend = {
				ResourceTypeName: resourceTypeAdmin.getResourceTypeName(),
				OrganizationalUnitId: resourceTypeAdmin.isOrganizationalUnitSelected() ? resourceTypeAdmin.getOrganizationalUnitId() : null,
				OrganizationId: resourceTypeAdmin.getOrganizationId(),
				AdditionalOrganizationalUnitIds: resourceTypeAdmin.getAdditionalOrganizationalUnitsList(),
				JobRoleId: resourceTypeAdmin.getJobRoleId(),
				Utilization: $.RMAdmin._utilization,
				listRegionUtilization: $.Utilization.GetUtilizationData(),
				listDispalyUtilization: $.Utilization.GetDisplayUtilizationData(),
				MatchSkills: $.SkillSet.GetCategoryPostData(),
				ResourceTypeId: $.ResourceRequest.resourceRequestTypeId,
				StartMilestone: $.RMAdmin._startMilestone,
				StopMilestone: $.RMAdmin._stopMilestone,
				FilterSkillType: $.SkillSet.GetFilterCriteria(),
				FilterSkills: $.SkillSet.GetFilterSkillsPostData(),
				ResourceTrasitionTime: $.RMAdmin._resourceTransitionTime,
				EnableProposalRequest: $.RMAdmin._enableinProposal,
				listCustomFields: resourceTypeAdmin.customField.getCustomfieldPostData(),
				AssigneesAlwaysUnblinded: resourceTypeAdmin.getAlwaysUnblindedValue(),
				DisplaysBlindedField: resourceTypeAdmin.getDisplayBlindedFieldValue(),
				ObsoletedByClinicalRedesign: resourceTypeAdmin.IsObsoletedByClinicalRedesign(),
				AllowResourcingRequirementMgmtToAsgnRes: resourceTypeAdmin.AllowResourcingRequirementMgmtToAsgnRes(),
				listDefaultMilestones: $.RMAdmin.GetDefaultMilestonesData(),
				EnableResouceRequest: $("#chkEnabled").attr("checked") ? true : false,
				CanInitiateNewRequests: $("#chkCanInitiate").attr("checked") ? true : false
			}
			var postData = { newResourceType: dataToSend }
			if ($.validationHelper.IsFormValid()) {
				rm.ui.messages.clearAllMessages();
				rm.ajax.requestSvcSyncPost("SaveResourceType", postData, function (data) {
					if (data.IsExists) {
						rm.validation.addError("#txtResourceType", data.ErrorMessage);
					}
					else if (data.departmentCodeFmCodeAlreadyUsed) {
						rm.ui.dialog.showServiceErrorModal("Unable to save ResourceType", "<div style='font-family: verdana;font-size: 12px;'>" + data.ErrorMessage + "</div>");
					}
					else if ($.trim(data.ErrorMessage) != "") {
						rm.ui.messages.addError(data.ErrorMessage);
					}
					else {
						rm.ui.messages.showSuccess('Resource type data saved successfully.');
						bindDirty();
						setTimeout(function () { rm.utilities.redirectToUrl($.RMAdmin.managePageUrl); }, 50);
					}
				});
			}
		}
		else {
			rm.ui.messages.addError(Resources.CorrectErrorsTryAgain);
		}
	},

	//Reset the input controls in the form
	Reset: function () {
		$("#txtResourceType").val("");
		$("#searchHrName").val("");
		$("#txtTargetUtlization").val("");
		$("#searchDepartment").val("");
		$("#searchJobCode").val("");
		$("#searchFmCode").val("");
		$("#ddlOrganization").val("-1");
		$(resourceTypeAdmin.jobRoleSelector).val("-1");
		//BJL
		$(resourceTypeAdmin.jobRoleSelector).val("-1");
		$("#ddlTDUOrganization").val("-1");
		$.each($('#tblRMAdminLayout').find('input[type=text]'), function (index, element) {
			rm.validation.clearError($(element));
		});
		rm.validation.clearError($("#ddlTDUOrganization"));
		rm.validation.clearError($("#ddlOrganization"));
		$.RMAdmin.HideMilestoneRows();
	},

	//Validation of input controls
	Validate: function () {
		var isValid = true;

		$.RMAdmin._resourceTypeName = $.trim($("#txtResourceType").val());
		$.RMAdmin._utilization = $.trim($("#txtGlobalTargetUtlization").val());
		$.RMAdmin._resourceTransitionTime = $.trim($("#txtResourceTrasitionTime").val());
		if ($("#chkProposal").is(":checked")) {
			$.RMAdmin._enableinProposal = 1;
		}
		else {
			$.RMAdmin._enableinProposal = 0;
		}

		if (resourceTypeAdmin.getJobRoleId() == null || resourceTypeAdmin.getJobRoleId() == "-1") {
			rm.validation.addError(resourceTypeAdmin.jobRoleSelector, "Job Role is Required");//to be moved to Resource    
			isValid = false;
		}
		else {
			rm.validation.clearError($(resourceTypeAdmin.jobRoleSelector));

		}
		if ($("#ddlOrganization").val() == "-1") {
			rm.validation.addError("#ddlOrganization", "Select The Organization");//to be moved to Resource    
			isValid = false;
		}
		else {
			rm.validation.clearError($("#ddlOrganization"));
		}
		if ($("#txtGlobalTargetUtilization").val() == "") {
			rm.validation.addError("#txtGlobalTargetUtilization", "Enter the global target utilization");//to be moved to Resource    
			isValid = false;
		}
		else {
			//RMK: Added validation scenarios for global utilization
			$.RMAdmin._utilization = $("#txtGlobalTargetUtilization").val();
			if ($.RMAdmin._utilization < 1 || $.RMAdmin._utilization > 100) {
				rm.validation.addError("#txtGlobalTargetUtilization", "Value should be 1 to  100");//to be moved to Resource    
				isValid = false;
			}
			else if (!$.RMAdmin.IsNumeric($.RMAdmin._utilization)) {
				rm.validation.addError("#txtGlobalTargetUtilization", "Numeric value required ");//to be moved to Resource    
				isValid = false;
			}
			else {
				rm.validation.clearError($("#txtGlobalTargetUtilization"));
			}

		}

		if (resourceTypeAdmin.getResourceTypeName() === "") {
			rm.validation.addError("#txtResourceType", "Resource Type Name Required");//to be moved to Resource    
			isValid = false;
		}
		else {
			if (!$.RMAdmin.IsAlpha(resourceTypeAdmin.getResourceTypeName())) {
				rm.validation.addError("#txtResourceType", "Invalid Resource Type(Alpha characters only)");//to be moved to Resource    
				isValid = false;
			}
			else {
				rm.validation.clearError($("#txtResourceType"));
			}
		}

		if ($.RMAdmin._resourceTransitionTime === "") {
			rm.validation.addError("#txtResourceTrasitionTime", "Resource transition time Required");//to be moved to Resource    
			isValid = false;
		}
		else {
			if (!$.RMAdmin.IsNumeric($.RMAdmin._resourceTransitionTime)) {
				rm.validation.addError("#txtResourceTrasitionTime", "Numeric Value Required ");//to be moved to Resource    
				isValid = false;
			}
			else {
				rm.validation.clearError($("#txtResourceTrasitionTime"));
			}
		}

		if ($.RMAdmin.IsDefaultMilestoneSelected()) {
			isValid = $.RMAdmin.ValidateAddButton();
		}

		return isValid;
	},

	//Numeric validation
	IsNumeric: function (str) {
		var regx = /^[0-9]+$/;
		return regx.test(str);
	},

	//Alphabet validation- space allowed
	IsAlpha: function (str) {
		var regx = /^[a-zA-Z \-\(\)]+$/;
		return regx.test(str);
	},

	//Drop down list fill
	Fill: function (selector, data, keyValueName, selected) {
		$(selector).empty().append($("<option>").val("-1").html("--Select--"));
		$.each(data, function (index, element) {
			if (element.Id == selected) {
				$(selector).append($("<option selected>").val(element.Id).html(element.Name));
			}
			else {
				$(selector).append($("<option>").val(element.Id).html(element.Name));
			}
		});
	},

	IsDefaultMilestoneSelected: function () {
		return $("#chkDefaultMilestone").is(":checked");
	},

	ShowMilestoneRows: function () {
		$("#tblRMAdminLayout .trMilestone").fadeIn("normal");
	},

	HideMilestoneRows: function () {
		$("#tblRMAdminLayout .trMilestone").fadeOut("normal");
	},
	ElvisPanelExpandAndCollapse: function () {
		if ($("#dynamicContent").is(':visible')) {
			$("#elvisExpand").hide();
			$("#elvisCollapse").show();
		} else {
			$("#elvisExpand").show();
			$("#elvisCollapse").hide();
		}
	},
	RRTFilterExpandAndCollapse: function () {
		if ($("#tblAdminFilter").is(':visible')) {
			$("#filterExpand").hide();
			$("#filterCollapse").show();
		} else {
			$("#filterExpand").show();
			$("#filterCollapse").hide();
		}
	},
	targetUtilizationExpandAndCollapse: function () {
		if ($("#divTgtUtilization").is(':visible')) {
			$("#tuExpand").hide();
			$("#tuCollapse").show();
		} else {
			$("#tuExpand").show();
			$("#tuCollapse").hide();
		}
	},
	customFieldsExpandAndCollapse: function () {
		if ($("#divCustomFieldContainer").is(':visible')) {
			$("#customExpand").hide();
			$("#customCollapse").show();
		} else {
			$("#customExpand").show();
			$("#customCollapse").hide();
		}
	},
	LoadDefaultMileStonesData: function () {
		$.rm.Ajax_RequestSynchronous("GetDefaultMilestoneData", {}, function (data) {
			DefuaulMileStonesData = data;
		}, true);
	},
	BindExistingMileStones: function (data) {
		var ExistingData = false;
		var Id;
		var FromMilestoneId;
		var ToMilestoneId;
		$.each(data, function (index, item) {
			ExistingData = true;
			$.RMAdmin._newGenericRowID++;
			Id = item.ResourceTypeDefaultMilestonesId;
			FromMilestoneId = item.DefaultFromMilestoneId;
			ToMilestoneId = item.DefaultToMilestoneId;
			DefaultFTE = item.DefaultFTE;
			$.RMAdmin.AddNewGenericRow(Id, FromMilestoneId, ToMilestoneId, false, $.RMAdmin._newGenericRowID, DefaultFTE);
		});
		if (ExistingData) {
			$("#GenericFTETable tr").each(function (index, element) {
				if (index > 2) {
					$(this).find("[id^=milestone_start]").attr('disabled', 'disabled');
				}
			});
			$('#chkDefaultMilestone').attr('checked', 'checked');
			$.RMAdmin.ShowMilestoneRows();
		}
		else {
			$.RMAdmin.HideMilestoneRows();
		}
		return ExistingData;
	},
	AddFirstGenericRow: function () {
		$.RMAdmin._newGenericRowID++;
		$.RMAdmin.AddNewGenericRow(-1, -1, -1, true, -1, "");
	},
	AddNewProjectMileStone: function () {
		if ($.RMAdmin.ValidateAddButton()) {
			var MilestoneId = $("#GenericFTECalculator tr:last").find('[id^=milestone_end]').val();
			$.RMAdmin._newGenericRowID++;
			$.RMAdmin.AddNewGenericRow(-1, -1, -1, true, -1, "");
			$.RMAdmin.RebindStage();
			$("#GenericFTECalculator tr:last").find('[id^=milestone_start]').val(MilestoneId).attr('disabled', 'disabled');
		}
		var isDirty = CheckPageDirty();
		if (!isDirty) {
			bindDirty();
			rm.ui.ribbon.refresh();
		}

	},
	AddNewGenericRow: function (ResourceTypeDefaultMilestonesId, FromMilestoneId, ToMilestoneId, isNewStage, rowIndex, DefaultFTE) {
		var isNewAttribute = isNewStage ? "isNew='true'" : "";
		var rowIndexAttr = " rowIndex=" + rowIndex + " ";
		var addStaticRow = "<tr class='spaceUnder' " + isNewAttribute + ">" +
																		"<td style='width: 6%;text-align:center;vertical-align:top;>" +
																		" <label  class='Stage' id='stageNumber_" + $.RMAdmin._newGenericRowID + "' >" + $.RMAdmin._newGenericRowID + "</label>" +
																		"</td>" +
																		"<td style='width: 35%;' class='class_milestoneStart'>" +
																		 "    <select  allowBlank='true' id = 'milestone_start_" + $.RMAdmin._newGenericRowID + "' style='width:205px;' class='fromMilestoneStartDate' data-value='" + $.RMAdmin._newGenericRowID + " '/>" +
																		"</td>" +
																		"<td style='width: 35%;' class='class_milestoneEnd'>" +
																				 "    <select  allowBlank='true' id = 'milestone_end_" + $.RMAdmin._newGenericRowID + "' style='width:205px;' class='toMilestoneEndDate' data-value='" + $.RMAdmin._newGenericRowID + " '/>" +
																		"</td>" +
																		"<td style='width: 13%;' class='class_defaultFTE'>" +
																				 "    <input type='text' allowBlank='true' id = 'defaultFTE_" + $.RMAdmin._newGenericRowID + "' style='width:40px;' class='defaultFTE' data-value='" + $.RMAdmin._newGenericRowID + " '/>" +
																		"</td>" +
																		"<td style='width: 4%; vertical-align:top; text-align:left;'>" +
																						"<img id='imgDelete_New" + $.RMAdmin._newGenericRowID + "'" + rowIndexAttr + " genericRowId='" + ResourceTypeDefaultMilestonesId + "' src='/_layouts/SPUI/images/closeSmall.png' style= 'margin: 2px 0 0 10px;' alt='' class='imgDeleteGenericRow' />" +
																		 "</td>" +
																		 "</tr>";
		$("#GenericFTECalculator").append(addStaticRow);
		$.RMAdmin.Fill("#milestone_start_" + $.RMAdmin._newGenericRowID, DefuaulMileStonesData, -1, FromMilestoneId);
		$.RMAdmin.Fill("#milestone_end_" + $.RMAdmin._newGenericRowID, DefuaulMileStonesData, -1, ToMilestoneId);
		$("#defaultFTE_" + $.RMAdmin._newGenericRowID).val(DefaultFTE);
	},
	ValidateAddButton: function () {
		var isValid = true;
		if ($("#chkDefaultMilestone").attr("checked")) {
			$("#GenericFTETable tr").each(function (index, element) {
				if (index > 1) {
					//Drop down list(milestone name)
					var milestoneStartId = $(this).find(".fromMilestoneStartDate");
					var milestoneEndId = $(this).find(".toMilestoneEndDate");
					var defaultFTEId = $(this).find(".defaultFTE");
					//Validate the milestone name 
					if ($(milestoneStartId).val() == "-1") {
						rm.validation.addError($(milestoneStartId), Resources.SelectMilestone);
						isValid = false;
					}
					else {
						rm.validation.clearError($(milestoneStartId));
					}
					if ($(milestoneEndId).val() == "-1") {
						rm.validation.addError($(milestoneEndId), Resources.SelectMilestone);
						isValid = false;
					}
					else {
						rm.validation.clearError($(milestoneEndId));
					}
					if ($(this).find(".fromMilestoneStartDate option:selected").index() > $(this).find(".toMilestoneEndDate option:selected").index()) {
						$(milestoneEndId).val() != "-1" ? rm.validation.addError($(milestoneEndId), "Milestones must be defined in the same order as they appear in the 'Start Milestone'") : Resources.SelectMilestone;
						isValid = false;
					}

					/*validate for decimal value for Default FTE*/
					if (!rmCommon.validateDecimal($(defaultFTEId).val())) {
						rm.validation.addError($(defaultFTEId), Resources.DecimalRequired);
						isValid = false;
					} else {
						rm.validation.clearError($(defaultFTEId));
					}
				}
			})
			bindDirty();
			rm.ui.ribbon.refresh();
		}
		return isValid;
	},
	RebindStage: function () {
		//  var len = $('#GenericFTETable tr').length();
		$.each($("#GenericFTECalculator").find("tr"), function (index, ele) {
			index++;
			$(this).find("[id^=stageNumber]").text(index);
		});
	},
	DeleteGenericRow: function (obj) {
		var genericCalculatorRow = $(obj).parent().parent();
		genericCalculatorRow.remove();

	},
	UpdateNextMileStoneSatge: function (prev, nextRowToUpdate) {
		$(nextRowToUpdate).find('[id^=milestone_start_]').val($(prev).find('[id^=milestone_end_]').val());
	},
	GetDefaultMilestonesData: function () {
		var items = new Array();
		if ($("#chkDefaultMilestone").attr("checked")) {
			$("#GenericFTETable tr").each(function (index, element) {
				if (index > 1) {
					var ResourceTypeDefaultMilestonesId = $(this).find(".imgDeleteGenericRow").attr('genericRowId');
					var milestoneStartId = $(this).find(".fromMilestoneStartDate");
					var milestoneEndId = $(this).find(".toMilestoneEndDate");
					var defaultFTE = $(this).find(".defaultFTE");
					var buildObject = {
						ResourceTypeDefaultMilestonesId: ResourceTypeDefaultMilestonesId,
						DefaultFromMilestoneId: $(milestoneStartId).val(),
						DefaultToMilestoneId: $(milestoneEndId).val(),
						DefaultFTE: ($(defaultFTE).val() == '') ? null : $(defaultFTE).val()
					};
					items.push(buildObject);
				}
			});
		}
		return items;
	},
	WasResourceTypeEnabled: function () {
		return $("[id$=hdnWasResourceTypeEnabled]").val() == "true";
	}
},

//SS:For multiple country utilization
$.Utilization =
	{
		_stillInEdit: true,
		_subRegions: "",
		_countryRegions: "",
		_grdCountryList: "",
		_grdRegionList: "",
		_grdSubregionList: "",
		AssignRegion: function () {
			$("#spanUtilizationRegionList").html("Select all that apply").attr("title", "Select all that apply")

			$.rm.Ajax_RequestSynchronous("GetAllRegions", {}, function (data) {
				$.Utilization.BindAssignedRegion($.parseJSON(data));
				//update tooltip
				var regionsList = "Select all that apply";
				$.Utilization._regionIds = "";
				$.each($.parseJSON(data), function (k, v) {
					if (v.isChecked) {
						if ($.Utilization._regionIds != "") {
							$.Utilization._regionIds += ",";
							regionsList += ", ";
						}
						$.Utilization._regionIds += v.key;
						regionsList = regionsList == "Select all that apply" ? v.value : regionsList + v.value;
					}
				});
				$("#spanAssignedRegionList").html(regionsList.length > 39 ? regionsList.substring(0, 42) + "..." : regionsList);
				$("#spanAssignedRegionList").attr("title", regionsList);
			}, true);
		},

		BindAssignedRegion: function (data) {
			$('#assignedRegionList').uRegionList({
				items: data,
				itemClick: function (key, value, isChecked) {
					var regionsList = "Select all that apply";
					$.Utilization._regionIds = "";
					$.each(this.items, function (k, v) {
						if (v.isChecked && v.key != key) {
							if ($.Utilization._regionIds != "") {
								$.Utilization._regionIds += ",";
								regionsList += ", ";
							}
							$.Utilization._regionIds += v.key;
							regionsList = regionsList == "Select all that apply" ? v.value : regionsList + v.value;
						}
					});
					if (isChecked) {
						if ($.Utilization._regionIds != "") {
							$.Utilization._regionIds += ",";
							regionsList += ", ";
						}
						$.Utilization._regionIds += key;
						regionsList = regionsList == "Select all that apply" ? value : regionsList + value;
						$.Utilization.ClearErrorMessage();
					}

					$("#spanAssignedRegionList").html(regionsList.length > 39 ? regionsList.substring(0, 42) + "..." : regionsList);
					$("#spanAssignedRegionList").attr("title", regionsList);
					//update variable countryIds & tooltip
					var subRegionList = "";
					if ($.Utilization._subRegions != "") {
						var arrarCountry = $.Utilization._subRegions.split(',');
						$.Utilization._subRegionIds = "";
						$.Utilization._subRegionsForPost = "";
						$.Utilization._subRegions = "";
						for (var i = 0; i < arrarCountry.length; i++) {
							if (key != arrarCountry[i].split("|")[0]) // index 0 is regionid key
							{
								if ($.Utilization._subRegionIds != "") {
									$.Utilization._subRegionIds += "|";
									$.Utilization._subRegionsForPost += ",";
									subRegionList += ", ";
									$.Utilization._subRegions += ",";
								}
								$.Utilization._subRegionIds += arrarCountry[i].split("|")[1];
								$.Utilization._subRegionsForPost += arrarCountry[i].split("|")[1];// index 1 is countryid key
								subRegionList += arrarCountry[i].split("|")[2]; // index 2 is name of the country
								$.Utilization._subRegions += arrarCountry[i].split("|")[0] + "|" + arrarCountry[i].split("|")[1] + "|" + arrarCountry[i].split("|")[2];
								$.Utilization._grdSubregionList = subRegionList;
							}
						}
					}
					if (subRegionList == "") {
						//countryList = "Select all that apply";
						$.Utilization._subRegionIds = "";
						$.Utilization._subRegionsForPost = "";
						$.Utilization._subRegions = "";
						subRegionList = "Select all that apply";
					}
					var countryList = "";
					if ($.Utilization._countryRegions != "") {
						var arrarCountry = $.Utilization._countryRegions.split(',');
						$.Utilization._countryIds = "";
						$.Utilization._countryRegions = "";
						for (var i = 0; i < arrarCountry.length; i++) {
							if (key != arrarCountry[i].split("|")[0]) // index 0 is regionid key
							{
								if ($.Utilization._countryIds != "") {
									$.Utilization._countryIds += "|";
									countryList += ", ";
									$.Utilization._countryRegions += ",";
								}
								$.Utilization._countryIds += arrarCountry[i].split("|")[2];  // index 2 is countryid key
								countryList += arrarCountry[i].split("|")[3]; // index 3 is name of the country
								$.Utilization._countryRegions += arrarCountry[i].split("|")[0] + "|" + arrarCountry[i].split("|")[1] + "|" + arrarCountry[i].split("|")[2] + "|" + arrarCountry[i].split("|")[3];
								$.Utilization._grdCountryList = countryList;
							}
						}
					}
					if (countryList == "") {
						//countryList = "Select all that apply";
						$.Utilization._countryIds = "";
						$.Utilization._countryRegions = "";
					}
					$("#spanAssignedSubregionList").html(subRegionList.length > 39 ? subRegionList.substring(0, 42) + "..." : subRegionList);
					$("#spanAssignedSubregionList").attr("title", subRegionList);
					$("#spanAssignedCountryList").html(countryList.length > 39 ? countryList.substring(0, 42) + "..." : countryList);
					$("#spanAssignedCountryList").attr("title", countryList);
					$.Utilization._grdRegionList = regionsList;
				},
				controlId: "URegionList"
			});
		},

		BindAssignedSubRegion: function (data) {
			$('#assignedSubregionList').uSubregionList({
				items: data,
				itemClick: function (key, value, isChecked, regionId) {
					$.Utilization._subRegionIds = "";
					$.Utilization._subRegionsForPost = "";
					$.Utilization._subRegions = "";
					var subRegionList = "Select all that apply";
					$.each(this.items, function (k, v) {
						if (v.isChecked && v.key != key) {
							if ($.Utilization._subRegionIds != "") {
								$.Utilization._subRegionIds += "|";
								$.Utilization._subRegionsForPost += ",";
								subRegionList += ", ";
								$.Utilization._subRegions += ",";
							}
							$.Utilization._subRegionIds += v.key;
							$.Utilization._subRegionsForPost += v.key;
							subRegionList = subRegionList == "Select all that apply" ? v.value : subRegionList + v.value;
							$.Utilization._subRegions += v.regionId + "|" + v.key + "|" + v.value;
						}
					});
					if (isChecked) {
						if ($.Utilization._subRegionIds != "") {
							$.Utilization._subRegionIds += "|";
							$.Utilization._subRegionsForPost += ",";
							subRegionList += ", ";
							$.Utilization._subRegions += ",";
						}
						$.Utilization._subRegionIds += key;
						$.Utilization._subRegionsForPost += key;
						subRegionList = subRegionList == "Select all that apply" ? value : subRegionList + value;
						$.Utilization._subRegions += regionId + "|" + key + "|" + value;
					}

					countryList = "";
					if ($.Utilization._countryRegions != "") {
						var arrarCountry = $.Utilization._countryRegions.split(',');
						$.Utilization._countryIds = "";
						$.Utilization._countryRegions = "";
						for (var i = 0; i < arrarCountry.length; i++) {
							if (key != arrarCountry[i].split("|")[1]) // index 1 is subregionid key
							{
								if ($.Utilization._countryIds != "") {
									$.Utilization._countryIds += "|";
									countryList += ", ";
									$.Utilization._countryRegions += ",";
								}
								$.Utilization._countryIds += arrarCountry[i].split("|")[2];  // index 2 is countryid key
								countryList += arrarCountry[i].split("|")[3]; // index 3 is name of the country
								$.Utilization._countryRegions += arrarCountry[i].split("|")[0] + "|" + arrarCountry[i].split("|")[1] + "|" + arrarCountry[i].split("|")[2] + "|" + arrarCountry[i].split("|")[3];
								$.Utilization._grdCountryList = countryList;
							}
						}
					}
					if (countryList == "") {
						//countryList = "Select all that apply";
						$.Utilization._countryIds = "";
						$.Utilization._countryRegions = "";
						countryList = "Select all that apply";
					}
					$("#spanAssignedSubregionList").html(subRegionList.length > 39 ? subRegionList.substring(0, 42) + "..." : subRegionList);
					$("#spanAssignedSubregionList").attr("title", subRegionList);
					$("#spanAssignedCountryList").html(countryList.length > 39 ? countryList.substring(0, 42) + "..." : countryList);
					$("#spanAssignedCountryList").attr("title", countryList);
					$.Utilization._grdSubregionList = subRegionList;
					$.Utilization.ClearErrorMessage();
				},
				controlId: "USubregionList"
			});

			if ($("#spanAssignedSubregionList").html() == "Select all that apply") {
				$("#spanAssignedCountryList").empty();
				$("#spanAssignedCountryList").attr("title", "");
			}
		},

		BindAssignedCountry: function (data) {
			$('#assignedCountryList').uCountryList({
				items: data,
				itemClick: function (key, value, isChecked, regionId, subregionId) {
					$.Utilization._countryIds = "";
					$.Utilization._countryRegions = "";
					var countryList = "Select all that apply";
					$.each(this.items, function (k, v) {
						if (v.isChecked && v.key != key) {
							if ($.Utilization._countryIds != "") {
								$.Utilization._countryIds += "|";
								countryList += ", ";
								$.Utilization._countryRegions += ",";
							}
							$.Utilization._countryIds += v.key;
							countryList = countryList == "Select all that apply" ? v.value : countryList + v.value;
							$.Utilization._countryRegions += v.regionId + "|" + v.subregionId + "|" + v.key + "|" + v.value;
						}
					});
					if (isChecked) {
						if ($.Utilization._countryIds != "") {
							$.Utilization._countryIds += "|";
							countryList += ", ";
							$.Utilization._countryRegions += ",";
						}
						$.Utilization._countryIds += key;
						countryList = countryList == "Select all that apply" ? value : countryList + value;
						$.Utilization._countryRegions += regionId + "|" + subregionId + "|" + key + "|" + value;
					}
					$("#spanAssignedCountryList").html(countryList.length > 39 ? countryList.substring(0, 42) + "..." : countryList);
					$("#spanAssignedCountryList").attr("title", countryList);
					$.Utilization._grdCountryList = countryList;
					$.Utilization.ClearErrorMessage();
				},
				controlId: "UCountryList"
			});

			if ($("#spanAssignedRegionList").html() == "Select all that apply") {
				$("#spanAssignedCountryList").empty();
				$("#spanAssignedCountryList").attr("title", "");
			}
			else if ($.Utilization._countryRegions == "") {
				$("#spanAssignedCountryList").html("Select all that apply");
				$("#spanAssignedCountryList").attr("title", "Select all that apply");
			}
		},

		ClearAssignCountry: function () {
			$.Utilization.BindAssignedCountry($.parseJSON("{}"));
			$("#spanAssignedCountryList").empty();
			$("#spanAssignedCountryList").attr("title", "");
			$.Utilization._subRegionIds = "";
			//$.Utilization.subRegionList = "";
			//$.Utilization.countryList = "";
			$.Utilization._subRegions = "";
			$.Utilization._subRegionsForPost = "";
			$.Utilization._countryIds = "";
			$.Utilization._countryRegions = "";
			$.Utilization._grdCountryList = "";
		},

		ClearAssignSubRegion: function () {
			$.Utilization.BindAssignedSubRegion($.parseJSON("{}"));
			$("#spanAssignedSubregionList").empty();
			$("#spanAssignedSubregionList").attr("title", "");
			$.Utilization._regionIds = "";
			//$.Utilization.subRegionList = "";
			$.Utilization._subRegionIds = "";
			$.Utilization._subRegionsForPost = "";
			$.Utilization._subRegions = "";
			$.Utilization._countryIds = "";
			$.Utilization._countryRegions = "";
			$.Utilization._grdSubregionList = "";
		},
		//RMK: Added to validate the Region, sub region, country 

		ValidateRegionSubregionCountry: function () {

			var isValid = true;
			var columnIndex = null;
			var type = null;
			if ($.Utilization._countryIds) {

				columnIndex = 'td:eq(7)';
				var idArray = $.Utilization._countryIds.split('|');
				type = "Country";
				if ($.Utilization.IsEntryExists(type, columnIndex, idArray, "|")) {
					rm.validation.addError("#spanAssignedCountryList", "Country utilization already exists.");
					isValid = false;
				}
				else {
					$("#spanAssignedCountryList").removeClass(rm.validation.errorClass)
					rm.qtip.clear("#spanAssignedCountryList");
				}

			}
			else if ($.Utilization._subRegionIds) {

				columnIndex = 'td:eq(6)';
				type = "SubRegion";
				var idArray = $.Utilization._subRegionIds.split('|');
				if ($.Utilization.IsEntryExists(type, columnIndex, idArray, "|")) {
					rm.validation.addError("#spanAssignedSubregionList", "Sub region utilization already exists.");
					isValid = false;
				}
				else {
					$("#spanAssignedSubregionList").removeClass(rm.validation.errorClass)
					rm.qtip.clear("#spanAssignedSubregionList");
				}
			}
			else if ($.Utilization._regionIds) {

				columnIndex = 'td:eq(5)';
				type = "Region";
				var idArray = $.Utilization._regionIds.split(',');
				if ($.Utilization.IsEntryExists(type, columnIndex, idArray, ",")) {
					rm.validation.addError("#spanAssignedRegionList", "Region utilization already exists.");
					isValid = false;
				}
				else {
					$("#spanAssignedRegionList").removeClass(rm.validation.errorClass)
					rm.qtip.clear("#spanAssignedRegionList");
				}

			}

			return isValid;
		},

		IsEntryExists: function (type, searchColumn, idArray, spliter) {
			var isValid = false;

			var updateRowNumber = $('#btnUtilizationUpdate').attr('editedrow');
			for (var i = 0; i < idArray.length; i++) {
				$('#tblUtilization tbody tr').map(function (index) {
					if (index != updateRowNumber) {
						var typeToCheck = $(this).find('td:eq(2)').text();

						var array = $(this).find(searchColumn).text().split(spliter);

						for (var j = 0; j < array.length; j++) {
							if (array[j] == idArray[i] && type == typeToCheck) {
								isValid = true;
							}
						}
					}
				});
			}

			return isValid;
		},
		//RMK: Added to reset the validation error
		ClearErrorMessage: function () {

			if ($("#txtTargetUtlization").hasClass("q_validation_error")) {
				rm.validation.clearError($("#txtTargetUtlization"));
			}
			if ($("#spanAssignedRegionList").hasClass("q_validation_error")) {
				$("#spanAssignedRegionList").removeClass(rm.validation.errorClass)
				rm.qtip.clear("#spanAssignedRegionList");
			}
			if ($("#spanAssignedSubregionList").hasClass("q_validation_error")) {
				$("#spanAssignedSubregionList").removeClass(rm.validation.errorClass)
				rm.qtip.clear("#spanAssignedSubregionList");
			}
			if ($("#spanAssignedCountryList").hasClass("q_validation_error")) {
				$("#spanAssignedCountryList").removeClass(rm.validation.errorClass)
				rm.qtip.clear("#spanAssignedCountryList");
			}
		},
		//RMK: Addedfor validation
		ValdateUtilizationEntry: function () {
			var isValid = true;
			var utilization = $.trim($("#txtTargetUtlization").val());
			if ($("#txtTargetUtlization").hasClass("q_validation_error")) {
				rm.validation.clearError($("#txtTargetUtlization"));
			}
			if ($('#spanAssignedRegionList').html() == "Select all that apply") {
				rm.validation.addError("#spanAssignedRegionList", "Region is required");
				isValid = false;
			}
			else {
				$("#spanAssignedRegionList").removeClass(rm.validation.errorClass)
				rm.qtip.clear("#spanAssignedRegionList");

			}
			if (utilization === "") {
				rm.validation.addError("#txtTargetUtlization", "Target utilization required");//to be moved to Resource    
				isValid = false;
			}
			else {
				if (utilization < 1 || utilization > 100) {
					rm.validation.addError("#txtTargetUtlization", "Value should be 1 to  100");//to be moved to Resource    
					isValid = false;
				}
				else {
					if (!$.RMAdmin.IsNumeric(utilization)) {
						rm.validation.addError("#txtTargetUtlization", "Numeric value required ");//to be moved to Resource    
						isValid = false;
					}

				}

			}

			if (!$.Utilization.ValidateRegionSubregionCountry()) {
				isValid = false;
			}
			return isValid;
		},


		// called when Add button is clicked in utilization tab
		GetLastSelectedChildValue: function () {
			if ($.Utilization.ValdateUtilizationEntry()) {
				var tgtUtilization = $("#txtTargetUtlization").val();
				if ($.Utilization._countryIds) {
					$.Utilization.AddSelectedUtilization("C", "Country", $.Utilization._countryIds, $.Utilization._grdCountryList, tgtUtilization);
					return;
				}
				if ($.Utilization._subRegionIds) {
					$.Utilization.AddSelectedUtilization("S", "SubRegion", $.Utilization._subRegionIds, $.Utilization._grdSubregionList, tgtUtilization);
					return;
				}
				if ($.Utilization._regionIds) {
					$.Utilization.AddSelectedUtilization("R", "Region", $.Utilization._regionIds, $.Utilization._grdRegionList, tgtUtilization);
					return;
				}
			}
		},

		GetLastUpdatedChildValue: function () {
			if ($.Utilization.ValdateUtilizationEntry()) {
				$.Utilization.SetButtonsVisibilityForEdit(false);
				var tgtUtilization = $("#txtTargetUtlization").val();
				$('#hdnUtilization').val("0");
				if ($.Utilization._countryIds) {
					$.Utilization.UpdateSelectedUtilization("C", "Country", $.Utilization._countryIds, $.Utilization._grdCountryList, tgtUtilization);
					return;
				}
				if ($.Utilization._subRegionIds) {
					$.Utilization.UpdateSelectedUtilization("S", "SubRegion", $.Utilization._subRegionIds, $.Utilization._grdSubregionList, tgtUtilization);
					return;
				}
				if ($.Utilization._regionIds) {
					$.Utilization.UpdateSelectedUtilization("R", "Region", $.Utilization._regionIds, $.Utilization._grdRegionList, tgtUtilization);
					return;
				}
			}
		},

		AddTableHead: function () {
			var html = "<table id='tblUtilization' class='table-utilization'><thead><tr><th class='classHideColumn'>RowType</th><th class='classHideColumn'>TypeId</th><th  Style=\"Width:200px;\">Type</th><th>Area</th><th Style=\"Width:160px;\">Utilization</th><th class='classHideColumn'>RegionIds</th><th class='classHideColumn'>SubregionIds</th><th class='classHideColumn'>CountryIds</th><th Style=\"Width:160px;\">Edit/Delete</th></tr>" +
		"</thead> <tbody></tbody></table>";
			$("#utilizationResult").html(html);
		},

		AddSelectedUtilization: function (rowType, type, typeId, area, utilization) {
			if ($("#tblUtilization").length == 0) {
				$.Utilization.AddTableHead();
			}
			$("#tblUtilization tbody").append($.Utilization.AddDynamicUtilizationRow(rowType, type, typeId, area, utilization));/*rowType:specifies Short form of row eg:R,S,C*//* type :: eg:Region,Subregion*/
			$.Utilization.ClearAssignSubRegion();//clear the saved variables
			$.Utilization.ClearAssignCountry();
			$.Utilization.AssignRegion();//Rebind the RegionList to clear off already selected values.
			$("#txtTargetUtlization").val("");
		},

		UpdateSelectedUtilization: function (rowType, type, typeId, area, utilization) {
			$("#tblUtilization tbody").append($.Utilization.UpdateDynamicUtilizationRow(rowType, type, typeId, area, utilization));/*rowType:specifies Short form of row eg:R,S,C*//* type :: eg:Region,Subregion*/
			$.Utilization.ClearAssignSubRegion();//clear the saved variables
			$.Utilization.ClearAssignCountry();
			$.Utilization.AssignRegion();//Rebind the RegionList to clear off already selected values.
			$("#txtTargetUtlization").val("");
		},

		AddDynamicUtilizationRow: function (rowType, type, typeId, area, utilization)/*rowType:specifies Short form of row eg:R,S,C*//* type :: eg:Region,Subregion*/ {
			var newRow;
			newRow = "<tr>" +
	"<td class='classHideColumn'>" + rowType + "</td>" +
	"<td class='classHideColumn'>" + typeId + "</td>" +
	"<td>" + type + "</td>" +
	"<td>" + area + "</td>" +
	"<td >" + utilization + "</td>" +
	"<td class='classHideColumn'>" + $.Utilization._regionIds + "</td>" +
	"<td class='classHideColumn'>" + $.Utilization._subRegionIds + "</td>" +
	"<td class='classHideColumn'>" + $.Utilization._countryIds + "</td>" +
	"<td><a  class=\"editUtilization\" Style=\"margin-right:8px;\">Edit</a><a  class=\"deleteUtilization\">Delete</a></td>" +
	"</tr>";
			return newRow;
		},

		UpdateDynamicUtilizationRow: function (rowType, type, typeId, area, utilization) {
			var updateRowNumber = $('#btnUtilizationUpdate').attr('editedrow');
			var newRow;
			newRow = "<tr>" +
	"<td class='classHideColumn'>" + rowType + "</td>" +
	"<td class='classHideColumn'>" + typeId + "</td>" +
	"<td>" + type + "</td>" +
	"<td>" + area + "</td>" +
	"<td >" + utilization + "</td>" +
	"<td class='classHideColumn'>" + $.Utilization._regionIds + "</td>" +
	"<td class='classHideColumn'>" + $.Utilization._subRegionIds + "</td>" +
	"<td class='classHideColumn'>" + $.Utilization._countryIds + "</td>" +
	"<td><a  class=\"editUtilization\" Style=\"margin-right:8px;\">Edit</a><a  class=\"deleteUtilization\">Delete</a></td>" +
	"</tr>";
			$('#tblUtilization > tbody > tr').eq(updateRowNumber).replaceWith(newRow);
		},

		RegionListClickForEdit: function (regionIds) {
			$.Utilization.AssignRegion();
			$("#imgAssignedRegionList").click();
			$.Utilization._stillInEdit = false;//everytime the click event is called , document level click gets called avoid hiding div for each click.
			if (regionIds) {
				var rArr = regionIds.split(',');
				$.each(rArr, function (index, element) {
					if (index == rArr.length - 1) {
						$.Utilization._stillInEdit = true;
					}
					$('#' + this + '.optionCheckboxURegionList').click();
				});
			}
		},

		SubregionListClickForEdit: function (regionIds, subregionIds) {
			$.Utilization.RegionListClickForEdit(regionIds);
			$("#imgAssignedSubregionList").click();
			$.Utilization._stillInEdit = false;
			if (subregionIds) {
				var sArr = subregionIds.split('|');
				$.each(sArr, function (index, element) {
					if (index == sArr.length - 1) {
						$.Utilization._stillInEdit = true;
					}
					$('#' + this + '.optionCheckboxUSubregionList').click();
				});
			}
		},

		CountryListClickForEdit: function (regionIds, subregionIds, countryIds) {
			$.Utilization.SubregionListClickForEdit(regionIds, subregionIds);
			$("#imgAssignedCountryList").click();
			$.Utilization._stillInEdit = false;
			if (countryIds) {
				var cArr = countryIds.split('|');
				$.each(cArr, function (index, element) {
					if (index == cArr.length - 1) {
						$.Utilization._stillInEdit = true;
					}
					$('#' + this + '.optionCheckboxUCountryList').click();
				});
			}
		},

		SetButtonsVisibilityForEdit: function (isEdit) {
			if (isEdit) {
				$('.btnUtilizationAdd').hide();
				$('.btnUtilizationUpdate').show();
			}
			else {
				$('.btnUtilizationUpdate').hide();
				$('.btnUtilizationAdd').show();
			}
		},

		UtilizationTd: {
			Code: 1,
			ID: 2,
			Type: 3,
			Area: 4,
			Utilization: 5,
			RegionIds: 6,
			SubregionIds: 7,
			CountryIds: 8
		},

		GetUtilizationData: function () {
			var items = new Array();
			$('#tblUtilization tbody tr').map(function (i) {
				var buildObject = {
					Code: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.Code + ')').text(),
					ID: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.ID + ')').text().replace(/\|/g, ','),
					Utilization: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.Utilization + ')').text(),
				};
				items.push(buildObject);
			});
			return items;
		},

		GetDisplayUtilizationData: function () {
			var items = new Array();
			$('#tblUtilization tbody tr').map(function (i) {
				var buildObject = {
					BatchId: $(this).index() + 1,//SS:tr index starts from 0
					TypeCode: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.Code + ')').text(),
					FieldInformation: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.Area + ')').text(),
					Utilization: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.Utilization + ')').text(),
					RegionIds: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.RegionIds + ')').text(),
					SubRegionIds: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.SubregionIds + ')').text().replace(/\|/g, ','),
					CountryIds: $(this).find('td:nth-child(' + $.Utilization.UtilizationTd.CountryIds + ')').text().replace(/\|/g, ','),
				};
				items.push(buildObject);
			});
			/*SS:QRPM:4832:build global utilization row as G,hide it in UI
	this is just to prepopulate global utilization textbox.
	*/
			var globalObj = {
				BatchId: (items.length == 0 ? 1 : items[items.length - 1].BatchId + 1),//if array is null
				TypeCode: "G",
				FieldInformation: "Global Utilization",
				Utilization: $.RMAdmin._utilization,
				RegionIds: "",
				SubRegionIds: "",
				CountryIds: "",
			};
			items.push(globalObj);
			return items;
		},

		CreateTableForEdit: function (rowData) {
			var type;
			var typeId;
			var newRow;
			switch (rowData["TypeCode"]) {
				case 'R':
					type = "Region";
					typeId = rowData["RegionIds"];
					break;
				case 'S':
					type = "SubRegion";
					typeId = rowData["SubRegionIds"];
					break;
				case 'C':
					type = "Country";
					typeId = rowData["CountryIds"];
					break;
				case 'G':
					$("#txtGlobalTargetUtilization").val(rowData["Utilization"]);//SS:QRPM:4832:populate global TU here.
			}
			if (rowData["TypeCode"] != 'G')//SS:QRPM:4832:dont populate row in table if it is global, avoid it here 
			{
				newRow = "<tr>" +
	"<td class='classHideColumn'>" + rowData["TypeCode"] + "</td>" +
	"<td class='classHideColumn'>" + typeId + "</td>" +
	"<td>" + type + "</td>" +
	"<td>" + rowData["FieldInformation"] + "</td>" +
	"<td >" + rowData["Utilization"] + "</td>" +
	"<td class='classHideColumn'>" + rowData["RegionIds"] + "</td>" +
	"<td class='classHideColumn'>" + rowData["SubRegionIds"] + "</td>" +
	"<td class='classHideColumn'>" + rowData["CountryIds"] + "</td>" +
	"<td><a  class=\"editUtilization\" Style=\"margin-right:8px;\">Edit</a><a  class=\"deleteUtilization\">Delete</a></td>" +
	"</tr>";
				$("#tblUtilization tbody").append(newRow);
			}
		}
	}

$.SkillSet =
    {
    	_selectedFilterSkills: null,
    	_filterSkillsToPopulate: null,
    	_filterSkillsSelected: null,
    	_showFilterSkillsInGrid: null,
    	_departmentCategoryHtml: null,
    	_selectedRadioButtonValue: null,
    	_isPopupClosed: false,
    	UpdateToolTipText: function () {
    		var styleConfig = { width: '225px' };
    		$(".classShowToolTip").each(function (index, element) {
    			var title = $(element).attr('alt');
    			rm.qtip.showInfo(element, title, {}, {}, {}, styleConfig, {});
    		});

    	},

    	UpdateTooltipWithImage: function () {
    		var tooltipText = "Use on Resource Request Type - Entering 'Yes' will allow the filter to be available so that the search results can be filtered based on " +
		"the experience captured within ELVIS CV <br/><br/> Default for the Resource Request Type - Entering Entering 'Yes' or a specific skill or indication will automatically " +
		"apply the filter so that the search results will be based on the  applied filter from ELVIS CV";
    		var styleConfig = { width: '420px' };
    		rm.qtip.showInfo(".ToolTip", "<div><div style='width:225px;float:left;margin-right: 10px;'>" + tooltipText + "</div><div><img src='../../images/isymbol.png'/></div></div>", {}, {}, {}, styleConfig, {});
    	},

    	ResetControl: function (divSelector) {
    		$(divSelector).find(":input").each(function (index, element) {

    			if ($(element).attr('type') === 'checkbox') {
    				if (!$(element).is(':disabled'))
    					$(element).prop('checked', false);
    			}
    			else if (($(element).prop('type').toLowerCase().indexOf('select') >= 0)) {
    				$(element).val("-1")
    			}
    			else if ($(element).attr('type') === 'text') {
    				$(element).val('');
    			}
    			else if ($(element).attr('type') === 'radio') {
    				$(element).attr('checked', false);

    			}
    			rm.validation.clearError($(element));
    		});
    	},
    	//To perform reset functionality
    	Reset: function () {
    		var section = rm.ui.tabs.getSelecteTabIndex("#tabs") + 1;
    		var divSelector = '';
    		if (section == 4) {
    			var id = $("#ddlDepartment")[0].value;
    			divSelector = ".departmentClass" + id;
    		}
    		else {
    			divSelector = "#rootDiv" + section;
    		}
    		editRow = $("#hdnEditRowId").val();//this is not a 0 based index as of edit click event so increment the counter by 1
    		if (editRow != null && editRow != '' && section == $("#hdnUpdateTab").val().split("_")[0]) {
    			var populateData = $('#projectMilestone tr:eq(' + (parseInt(editRow) + 1) + ') td:eq(4)').text();
    			var arrayLevelOne = $.map(populateData.split(';'), $.trim);
    			for (var i = 0; i < arrayLevelOne.length; i++) {
    				if (arrayLevelOne[i] != "") {
    					var arrayLevelTwo = arrayLevelOne[i].split('~');
    					if (arrayLevelTwo[0].indexOf("chk") >= 0) {
    						$("[id='" + arrayLevelTwo[0] + "']").prop('checked', true).prop('disabled', true);//disable the checkbox and check it.
    					}
    				}
    			}
    			if ($('#hdnEdit').val() == "1") {
    				if (section == 4 && $("#hdnUpdateTab").val().split("_")[1] == $("#ddlDepartment").val()) {
    					$("#hdnUpdateTab").val('');
    				}
    			}
    			$('#hdnEdit').val('');
    			$('#projectMilestone').find('tr').removeClass('elvisSkillsGridEditRow');
    		}

    		$.SkillSet.ResetControl(divSelector);
    		$.RMAdmin._isAddButtonEnabled = false;
    		$.RMAdmin._isUpdateButtonEnabled = false;
    		$.RMAdmin._isResetElvisButtonEnabled = false;
    		rm.ui.ribbon.refresh();
    	},

    	GetCategoryValue: function () {
    		var section = rm.ui.tabs.getSelecteTabIndex("#tabs") + 1;
    		var divSelector = '';
    		var id = '';
    		var categoryId = '';
    		var usrDisplay = '';//string that will be displayed to user.
    		var grdSave = '';//string that will be used to save to database.
    		var radVisited = '';//bool variable to keep track if a radio button group value has been read. 
    		var current = '';//to keep track of currently selected pair
    		var label = '';
    		var flag = true;
    		var chkStatus;
    		var chkbxToDisable = [];
    		//var rowCounter = 0;
    		if (section == 4) {
    			var id = $("#ddlDepartment")[0].value;
    			categoryId = section;
    			divSelector = ".departmentClass" + id;
    		}
    		else {
    			categoryId = section;
    			divSelector = "#rootDiv" + categoryId;
    		}

    		if (this.AtleastOneInputSelected(divSelector)) {//check if atleast one control value is selected.
    			//rowCounter++;
    			var allInputs = $(divSelector).find(":input[type=checkbox]:checked:enabled,input[type=radio]:checked,select");
    			var idCount = 0;
    			var ifEnabled;
    			allInputs.each(function () {
    				var elementId = (this.id).split('_');
    				label = elementId[1];
    				if ($(this).attr('type') == 'checkbox') {
    					chkStatus = $(this).prop('checked');
    					ifDisabled = $("[id='" + this.id + "']").is(':disabled');
    					if (chkStatus == true && !ifDisabled) {
    						//string would be something like chkcustomer12 slice first three characters,remove the digits and read if checkbox is selected.
    						chkbxToDisable.push([this.id]);

    						usrDisplay += label + ";"; //+ ":" + chkStatus + ";";
    						if (categoryId == 4) {
    							grdSave += ("chk_" + label + "_" + elementId[2] + "~") + ((chkStatus == true) ? "true" : "false") + ";";
    						}
    						else {
    							grdSave += ("chk_" + label + "_" + elementId[2] + "~") + ((chkStatus == true) ? "1" : "0") + ";";
    						}
    					}
    				}
    				if ($(this).prop('type').toLowerCase().indexOf('select') >= 0) {
    					rm.validation.clearError($("[id='" + this.id + "']"));
    					if ($(this).val() != -1) {
    						current = "ddl_" + label + "_" + elementId[2] + "~" + $(this).val() + ";";
    						if ($.SkillSet.SelectionNotExist(current, categoryId)) {
    							//rm.validation.clearError($("[id='" + this.id + "']"));
    							grdSave += current;
    							usrDisplay += label + ":" + $(this).find('option:selected').text() + ";";
    						}
    						else {
    							rm.validation.addError("[id='" + this.id + "']", label + " already selected.");
    							flag = false;
    							//return flag;
    						}
    					}
    				}
    				if ($(this).attr('type') == 'radio') {
    					if (radVisited.indexOf(this.name) < 0) {
    						var radioId = (this.name.split('_'));
    						if ($("input[name='" + this.name + "']:radio").is(":checked")) {
    							current = "rad_" + radioId[1] + "_" + radioId[2] + "~" + $("input[name='" + this.name + "']:radio:checked").val() + ";";
    							if ($.SkillSet.SelectionNotExist(current, categoryId)) {
    								radVisited += this.name;
    								usrDisplay += radioId[1] + ":" + $("input[name='" + this.name + "']:radio:checked").val() + ";";
    								grdSave += current;
    							}
    						}
    					}
    				}
    				idCount++;
    			});
    			if (flag) {
    				$.each(chkbxToDisable, function (index, item) {
    					$("[id='" + this + "']").attr('disabled', true);
    				});
    				//reset the controls
    				$.SkillSet.ResetControl(divSelector);
    				if (usrDisplay)
    					$.SkillSet.BuildTable(idCount, categoryId, usrDisplay, grdSave);
    			}
    			$.RMAdmin._isAddButtonEnabled = false;
    			$.RMAdmin._isUpdateButtonEnabled = false;
    			$.RMAdmin._isResetElvisButtonEnabled = false;
    			$.RMAdmin._isSaveButtonEnabled = true;
    			$.RMAdmin._isCancelButtonEnabled = true;
    			rm.ui.ribbon.refresh();
    		}
    		else {
    			alert("Please select atleast one area");
    		}
    	},

    	GetUpdatedCategoryValue: function () //to update the table when record is edited
    	{
    		var section = rm.ui.tabs.getSelecteTabIndex("#tabs") + 1;
    		var editedRow = $("#hdnEditRowId").val();
    		var divSelector = '';
    		var id = -1;
    		var categoryId = '';
    		var usrDisplay = '';//string that will be displayed to user.
    		var grdSave = '';//string that will be used to save to database.
    		var radVisited = '';//bool variable to keep track if a radio button group value has been read. 
    		var current = '';//to keep track of currently selected pair
    		var label = '';
    		var flag = true;
    		var chkStatus;
    		var chkbxToDisable = [];
    		var rowCounter = 0;
    		if (section == 4) {
    			id = $("#ddlDepartment")[0].value;
    			categoryId = section;
    			divSelector = ".departmentClass" + id;
    		}
    		else {
    			categoryId = section;
    			divSelector = "#rootDiv" + categoryId;
    		}

    		if (this.AtleastOneInputSelected(divSelector)) {//check if atleast one control value is selected.
    			rowCounter++;
    			var allInputs = $(divSelector).find(":input[type=checkbox]:checked:enabled,input[type=radio]:checked,select");
    			var idCount = 0;
    			var ifEnabled;
    			allInputs.each(function () {
    				var elementId = (this.id).split('_');
    				label = elementId[1];
    				if ($(this).attr('type') == 'checkbox') {
    					chkStatus = $(this).prop('checked');
    					ifDisabled = $("[id='" + this.id + "']").is(':disabled');
    					if (chkStatus == true && !ifDisabled) {
    						//string would be something like chkcustomer12 slice first three characters,remove the digits and read if checkbox is selected.
    						chkbxToDisable.push([this.id]);

    						usrDisplay += label + ";";//+ ":" + chkStatus + ";";

    						if (categoryId == 4) {
    							grdSave += ("chk_" + label + "_" + elementId[2] + "~") + ((chkStatus == true) ? "true" : "false") + ";";
    						}
    						else {
    							grdSave += ("chk_" + label + "_" + elementId[2] + "~") + ((chkStatus == true) ? "1" : "0") + ";";
    						}
    					}
    				}
    				if ($(this).prop('type').toLowerCase().indexOf('select') >= 0) {
    					rm.validation.clearError($("[id='" + this.id + "']"));
    					if ($(this).val() != -1) {
    						current = "ddl_" + label + "_" + elementId[2] + "~" + $(this).val() + ";";
    						if ($.SkillSet.DoesSkillsetExistToUpdate(current, categoryId, editedRow)) {
    							//rm.validation.clearError($("[id='" + this.id + "']"));
    							grdSave += current;
    							usrDisplay += label + ":" + $(this).find('option:selected').text() + ";";
    						}
    						else {
    							rm.validation.addError("[id='" + this.id + "']", label + " already selected.");
    							flag = false;
    							//return flag;
    						}
    					}
    				}
    				if ($(this).attr('type') == 'radio') {
    					if (radVisited.indexOf(this.name) < 0) {
    						var radioId = (this.name.split('_'));
    						if ($("input[name='" + this.name + "']:radio").is(":checked")) {
    							current = "rad_" + radioId[1] + "_" + radioId[2] + "~" + $("input[name='" + this.name + "']:radio:checked").val() + ";";
    							if ($.SkillSet.DoesSkillsetExistToUpdate(current, categoryId, editedRow)) {
    								radVisited += this.name;
    								usrDisplay += radioId[1] + ":" + $("input[name='" + this.name + "']:radio:checked").val() + ";";
    								grdSave += current;
    							}
    						}
    					}
    				}
    				idCount++;
    			});
    			if (flag) {
    				$.each(chkbxToDisable, function (index, item) {
    					$("[id='" + this + "']").attr('disabled', true);
    				});
    				//reset the controls
    				$.SkillSet.ResetControl(divSelector);
    				if (usrDisplay) {
    					$.SkillSet.UpdateTable(editedRow/*the row which was edited*/, idCount, categoryId, usrDisplay, grdSave);
    				}
    				$('#hdnEdit').val('');
    				$.SkillSet.IsUpdateButtonVisible(id, categoryId, false);
    			}
    			$('#projectMilestone').find('tr').removeClass('elvisSkillsGridEditRow');
    			$.RMAdmin._isUpdateButtonEnabled = false;
    			$.RMAdmin._isAddButtonEnabled = false;
    			$.RMAdmin._isResetElvisButtonEnabled = false;
    			$.RMAdmin._isSaveButtonEnabled = true;
    			$.RMAdmin._isCancelButtonEnabled = true;
    			rm.ui.ribbon.refresh();
    			$("#hdnEdit").val("");
    			if (section == 4 && $("#hdnUpdateTab").val().split("_")[1] == $("#ddlDepartment").val()) {
    				$("#hdnUpdateTab").val('');
    			}
    		}
    		else {
    			alert("please select atleast one area");
    		}

    	},

    	AtleastOneInputSelected: function (selector) {
    		var bRv = false;
    		//note the space before "select"->it's ' select' and not 'select'
    		$(selector + ' select').each(function () {
    			if ($(this).val() != -1) {
    				bRv = true;
    			}
    		});
    		//note the space before "input"->it's ' input' and not 'input'
    		if ($(selector + ' input[type=checkbox]').length) {
    			if ($(selector + ' input[type=checkbox]:checked:enabled').length) {
    				bRv = true;
    			}
    		}
    		//note the space before "input"->it's ' input' and not 'input'
    		if ($(selector + ' input[type=radio]').length) {
    			if ($(selector + ' input[type=radio]:checked').length) {
    				bRv = true;
    			}
    		}
    		return bRv;
    	},

    	HideDepartmentDiv: function () {
    		$("#ddlDepartment option").each(function () {
    			$(".departmentClass" + $(this).attr('value')).css('display', 'none');
    		});
    	},

    	IsUpdateButtonVisible: function (itemId, categoryId, visible) {
    		if (visible) {
    			if (itemId != "0") {
    				$("#btnUpdateDepartment_" + itemId + "_" + categoryId).show();
    				$("#btnDepartment_" + itemId + "_" + categoryId).hide();
    			}
    			else {
    				$('#btn_' + categoryId).hide();
    				$('#btnUpdate_' + categoryId).show();
    			}
    		}
    		else {
    			if (itemId != "-1") {
    				$("#btnUpdateDepartment_" + itemId + "_" + categoryId).hide();
    				$("#btnDepartment_" + itemId + "_" + categoryId).show();
    			}
    			else {
    				$('#btn_' + categoryId).show();
    				$('#btnUpdate_' + categoryId).hide();
    			}
    		}
    	},

    	SetFocusOnTab: function (index) {
    		rm.ui.tabs.activateByIndex("#tabs", index);
    		$.SkillSet.SetAddUpdateButton(index);
    	},

    	SetAddUpdateButton: function (tabId) {
    		var divSelector = "#rootDiv" + tabId;
    		var IsEditDeptTab = true;
    		if (tabId == 4 && ($("#ddlDepartment").val() != $("#hdnUpdateTab").val().split("_")[1])) {
    			divSelector = ".departmentClass" + $("#ddlDepartment").val();
    			IsEditDeptTab = false;
    		}
    		if (($("#hdnEdit").val() == "1") && (tabId == $("#hdnUpdateTab").val().split("_")[0]) && IsEditDeptTab) {
    			$.RMAdmin._isUpdateButtonEnabled = true;
    			$.RMAdmin._isAddButtonEnabled = false;
    			$.RMAdmin._isResetElvisButtonEnabled = true;
    			rm.ui.ribbon.refresh();
    		} else if ($(divSelector).find(":input[type=checkbox]:checked:enabled,input[type=radio]:checked:enabled").length > 0) {
    			$.RMAdmin._isUpdateButtonEnabled = false;
    			$.RMAdmin._isAddButtonEnabled = true;
    			$.RMAdmin._isResetElvisButtonEnabled = true;
    			rm.ui.ribbon.refresh();
    		}
    		else {
    			$.RMAdmin._isUpdateButtonEnabled = false;
    			$.RMAdmin._isAddButtonEnabled = false;
    			$.RMAdmin._isResetElvisButtonEnabled = false;
    			rm.ui.ribbon.refresh();
    		}
    	},

    	HideDepartmentDivFilter: function () {
    		$("#ddlDepartmentFilter option").each(function () {
    			$(".departmentClassFilter" + $(this).attr('value')).css('display', 'none');
    		});
    	},

    	ChangeVisibility: function (selector, selectedValue) {
    		$("#ddlDepartment option").each(function () {
    			if (selectedValue == $(this).attr('value')) {
    				$(".departmentClass" + $(this).attr('value')).css('display', 'block');
    				$.SkillSet.SetAddUpdateButton(4);
    			}
    			else {
    				$(".departmentClass" + $(this).attr('value')).css('display', 'none');
    			}
    		});
    	},

    	ChangeVisibilityFilter: function (selector, selectedValue) {
    		$("#ddlDepartmentFilter option").each(function () {
    			if (selectedValue == $(this).attr('value')) {
    				$(".departmentClassFilter" + $(this).attr('value')).css('display', 'block');
    			}
    			else {
    				$(".departmentClassFilter" + $(this).attr('value')).css('display', 'none');
    			}
    		});
    	},

    	CheckIfRowExistsInTable: function (selectedValue) {
    		var bRv = false;
    		$('#projectMilestone tbody tr').map(function (i) {
    			// Find 4th table cell on this row.
    			$(this).find('td:nth-child(5)').each(function (i) {
    				if ($(this).text() == selectedValue) {
    					bRv = true;
    					return bRv;
    				}
    			});
    		});
    		return bRv;
    	},

    	CreateNewProjectMilestoneRow: function (newRowData) {
    		var newRow;
    		newRow = "<tr>" +
		"<td class='classHideColumn'>" + newRowData["BatchId"] + "</td>" +
		"<td class='classHideColumn'>" + newRowData["CatgoryId"] + "</td>" +
		"<td style='width:100px'>" + newRowData["CategoryName"] + "</td>" +
		"<td >" + newRowData["Summary"] + "</td>" +
		"<td class='classHideColumn'>" + newRowData["SelectedValues"] + "</td>" +
		"<td class='classHideColumn'>" + newRowData["DepartmentId"] + "</td>" +
		"<td><a  class=\"edit\" Style=\"margin-right:8px;\">Edit</a><a class=\"skill delete\">Delete</a></td>" +
		"</tr>";
    		return newRow;
    	},

    	DisableCheckboxForEdit: function (SelectedValues) {
    		var arrayLevelOne = $.map(SelectedValues.split(';'), $.trim);
    		for (var i = 0; i < arrayLevelOne.length; i++) {
    			if (arrayLevelOne[i] != "") {
    				var arrayLevelTwo = arrayLevelOne[i].split('~');
    				if (arrayLevelTwo[0].indexOf("chk") >= 0) {
    					$("[id='" + arrayLevelTwo[0] + "']").prop('checked', true).prop('disabled', true);
    				}
    			}
    		}
    	},

    	AddDynamicProjectMilestoneRow: function (id, categoryId, selectedText, selectedValue) {
    		var categoryName = $.SkillSet.GetSelectedTabText();
    		var Departmentid = 0;
    		if (categoryId == 4) {
    			categoryName = categoryName + "(" + $("#ddlDepartment option:selected").text() + ")";
    			Departmentid = $("#ddlDepartment option:selected").val();
    		}
    		var newRow;
    		newRow = "<tr>" +
		"<td class='classHideColumn'>" + id + "</td>" +
		"<td class='classHideColumn'>" + categoryId + "</td>" +
		"<td style='width:100px'>" + categoryName + "</td>" +
		"<td >" + selectedText + "</td>" +
		"<td class='classHideColumn'>" + selectedValue + "</td>" +
		"<td class='classHideColumn'>" + Departmentid + "</td>" +
		"<td><a  class=\"edit\" Style=\"margin-right:8px;\">Edit</a><a  class=\"skill delete\">Delete</a></td>" +
		"</tr>";

    		return newRow;
    	},

    	BuildTable: function (id, categoryId, summary, selectedValue) {
    		if ($("#projectMilestone").length == 0) {
    			$.SkillSet.AddTableHead();
    		}
    		//added by shamanth
    		if ($.SkillSet.CheckIfRowExistsInTable(selectedValue))
    			alert("Skillset already Exists");
    		else
    			$("#projectMilestone tbody").append($.SkillSet.AddDynamicProjectMilestoneRow(id, categoryId, summary, selectedValue));
    	},

    	CreateTableForEdit: function (rowData) {
    		$("#projectMilestone tbody").append($.SkillSet.CreateNewProjectMilestoneRow(rowData));
    		$.SkillSet.DisableCheckboxForEdit(rowData["SelectedValues"]);
    	},

    	AddTableHead: function () {
    		var html = "<table id='projectMilestone' class='table-milestone'><thead><tr><th class='classHideColumn'>Id</th><th class='classHideColumn'>CategoryId</th><th>Category</th><th>Summary<th class='classHideColumn'>SelectedValue</th><th class='classHideColumn'>DepartmentId</th><th Style=\"Width:100px;\">Edit/Delete</th></tr>" +
			"</thead> <tbody></tbody></table>";
    		$("#tableHolder").html(html);
    	},

    	UpdateTable: function (updateRowNumber, id, categoryId, summary, selectedValue) {
    		if ($.SkillSet.CheckIfRowExistsInTable(selectedValue))
    			alert("Skillset already Exists");
    		else {
    			var categoryName = $.SkillSet.GetSelectedTabText();
    			var Departmentid = 0;
    			if (categoryId == 4) {
    				categoryName = categoryName + "(" + $("#ddlDepartment option:selected").text() + ")";
    				Departmentid = $("#ddlDepartment option:selected").val();
    			}
    			var newRow;
    			newRow = "<tr>" +
		"<td class='classHideColumn'>" + id + "</td>" +
		"<td class='classHideColumn'>" + categoryId + "</td>" +
		"<td style='width:100px'>" + categoryName + "</td>" +
		"<td >" + summary + "</td>" +
		"<td class='classHideColumn'>" + selectedValue + "</td>" +
		"<td class='classHideColumn'>" + Departmentid + "</td>" +
		"<td><a  class=\"edit\" Style=\"margin-right:8px;\">Edit</a><a  class=\"skill delete\">Delete</a></td>" +
		"</tr>";
    			$('#projectMilestone > tbody > tr').eq(updateRowNumber).replaceWith(newRow);
    		}
    	},

    	SelectionNotExist: function (selection, catId) {
    		var flag = true;
    		$('#projectMilestone tbody tr').map(function (i) {
    			// Find 4th table cell on this row.
    			var tdSelectedText;
    			var tdCatId;
    			$(this).each(function (i) {
    				tdSelectedText = $(this).find('td:nth-child(5)').text();
    				tdCatId = $(this).find('td:nth-child(2)').text();
    				if (tdCatId == catId) {
    					if (tdSelectedText.indexOf(selection) >= 0) {
    						flag = false;
    						return false;
    					}
    				}
    			});
    		});
    		return flag;
    	},

    	DoesSkillsetExistToUpdate: function (selection, catId, editedRow) {
    		var flag = true;
    		$('#projectMilestone tbody tr').map(function (i) {
    			// Find 4th table cell on this row.
    			var tdSelectedText;
    			var tdCatId;
    			$(this).each(function (i) {
    				if ($(this).closest('tr').prevAll().length != editedRow) {
    					tdSelectedText = $(this).find('td:nth-child(5)').text();
    					tdCatId = $(this).find('td:nth-child(2)').text();
    					if (tdCatId == catId) {
    						if (tdSelectedText.indexOf(selection) >= 0) {
    							flag = false;
    							return false;
    						}
    					}
    				}
    			});
    		});
    		return flag;
    	},

    	GetFilterSkillsPostData: function () {
    		var idArray = new Array();
    		var batchCount = 1;
    		var categoryString = '';
    		if ($("#ddlFilterSkillsShow").val() == "1")//SS-to make sure categorystring is set to null if "Skills" dropdown value is set to No
    		{
    			if ($("#hdnFilter").val() == "true")//SS-QRPM-4662 start
    			{
    				categoryString = $.SkillSet._selectedFilterSkills;
    			}
    			else {
    				categoryString = $.SkillSet.GetSelectedFilterSkills(true).DataToSave;
    			}
    		}																		//SS-QRPM-4662 end
    		$("#hdnFilter").val(false);
    		//var categoryString = ($.SkillSet._selectedFilterSkills == null) ? $.SkillSet.GetSelectedFilterSkills(true).DataToSave : $.SkillSet._selectedFilterSkills;
    		var categoryId = 4;
    		if (categoryString != null) {
    			var arrayLevelOne = categoryString.split(';');
    			for (var i = 0; i < arrayLevelOne.length; i++) {
    				if (arrayLevelOne[i] != "") {
    					var arrayLevelTwo = arrayLevelOne[i].split('~');
    					var arrayLevelThree = arrayLevelTwo[1].split('_');
    					var skillValue = arrayLevelThree[0];

    					var adminPageMasterDataId = arrayLevelThree[1];
    					var isFilter = false;
    					if (arrayLevelThree[2] == "true") {
    						isFilter = true;
    					}
    					if (arrayLevelThree[2] == "false" && skillValue == "0") skillValue = null;

    					skillValue = skillValue == " " ? '' : skillValue;

    					var itemToSend = {
    						Id: 0,
    						ExperienceTypeId: adminPageMasterDataId,
    						CategoryId: categoryId,
    						SkillValue: skillValue,
    						ApplyInFilter: isFilter,
    						ApplyInMatch: false,
    						BatchId: batchCount,
    						FilterSkill: skillValue,

    					};
    					idArray.push(itemToSend);
    				}
    			}
    		}
    		return idArray;
    	},

    	GetCategoryPostData: function () {
    		var idArray = new Array();
    		var batchCount = 0;
    		$('#projectMilestone tbody tr').map(function (i) {
    			// Find 4th table cell on this row.
    			batchCount++;
    			var categoryString = $(this).find('td:nth-child(5)').text();
    			var categoryId = $(this).find('td:nth-child(2)').text();
    			var arrayLevelOne = categoryString.split(';');
    			for (var i = 0; i < arrayLevelOne.length; i++) {
    				if (arrayLevelOne[i] != "") {
    					var arrayLevelTwo = arrayLevelOne[i].split('_');
    					var arrayLevelThree = arrayLevelTwo[2].split('~');
    					var skillValue = arrayLevelThree[1];
    					var adminPageMasterDataId = arrayLevelThree[0];

    					var itemToSend = {
    						Id: 0,
    						ExperienceTypeId: adminPageMasterDataId,
    						CategoryId: categoryId,
    						SkillValue: skillValue,
    						ApplyInFilter: false,
    						ApplyInMatch: true,
    						BatchId: batchCount,
    						FilterSkill: '',
    					};
    					idArray.push(itemToSend);
    				}
    			}

    		});

    		return idArray;
    	},

    	InjectHtmlToPage: function (html) {
    		$.ajax({
    			url: html,
    			success: function (data) { $('body').append(data); },
    			dataType: 'html'
    		});
    	},

    	RemoveDivFromPage: function (divId) {
    		$(divId).remove();
    	},

    	GetSelectedTabText: function () {
    		var selected = rm.ui.tabs.getSelecteTabIndex("#tabs");
    		var selectedTab = $($("#tabs li")[selected]).text();
    		return selectedTab;
    	},

    	GetFilterCriteria: function () {
    		itemToSend = {
    			ShowCustomer: parseInt($("#ddlFilterCustomerShow").val()),
    			DefaultCustomer: parseInt($("#ddlFilterCustomerCheck").val()),
    			ShowStudyPhase: parseInt($("#ddlFilterStudyPhaseShow").val()),
    			DefaultStudyPhase: parseInt($("#ddlFilterStudyPhaseCheck").val()),
    			ShowLanguages: parseInt($("#ddlFilterLanguageShow").val()),
    			DefaultLanguages: parseInt($("#ddlFilterLanguageCheck").val()),
    			ShowTA: parseInt($("#ddlFilterTAShow").val()),
    			DefaultTA: parseInt($("#ddlFilterTACheck").val()),
    			ShowSkill: parseInt($("#ddlFilterSkillsShow").val()),
    			//FilterSkills: $.SkillSet.GetFilterSkillsPostData(),
    			ShowIndication: parseInt($("#ddlFilterIndicationShow").val()),
    			DefaultIndication: parseInt($("#ddlFilterIndicationCheck").val()),
    			ShowContractualRequirements: parseInt($("#ddlFilterContractualRequirementsShow").val()),
    			DefaultContractualRequirements: parseInt($("#ddlFilterContractualRequirementsCheck").val()),
    			ShowOrganizationalUnit: parseInt($("#ddlFilterOrgUnitShow").val()),
    			DefaultOrganizationalUnit: parseInt($("#ddlFilterOrgUnitCheck").val()),
    			ShowCompetencyBand: parseInt($(resourceTypeAdmin.showCompetencyBandSelector).val()),
    			DefaultCompetencyBand: parseInt($(resourceTypeAdmin.defaultCompetencyBandSelector).val())
    		};
    		return itemToSend;
    	},

    	GetSelectedFilterSkills: function (insertHtml) {
    		$.SkillSet._isPopupClosed = false;
    		var grdSave = '';
    		var populateData = '';
    		var showInGrid = '';
    		if (insertHtml)//inject html to page to read values.
    		{
    			$.SkillSet.OpenSkillsetDialog(false);
    		}
    		$(".getDisabledSkills:checked").each(function () {
    			var id = $(this).attr('id');
    			var idArray = id.split("_");
    			label = idArray[1];
    			if (idArray[0] == "chkrad") {
    				var idToReset = "radFilter_" + idArray[1] + "_" + idArray[2];
    				var isFilter = false;
    				var selectedValue = " ";
    				if ($("input[name='" + idToReset + "']").is(':checked')) {
    					selectedValue = $("input[name='" + idToReset + "']:radio:checked").val();
    					isFilter = true;
    				}
    				else {
    					//BJL 4756
    					if ($("input[name='" + idToReset + "']:radio").val() == "Yes " || $("input[name='" + idToReset + "']:radio").val() == "No") {
    						alert('Please select Yes or No Value for' + " " + label);
    						$.SkillSet._isPopupClosed = true;
    					}
    				}
    				populateData += id + "~~" + idToReset + "~" + selectedValue + ";";
    				grdSave += label + "~" + selectedValue + "_" + idArray[2] + "_" + isFilter + ";";
    				showInGrid += idArray[3] + "~" + label + ":" + selectedValue + ";";
    			}
    			else if (idArray[0] == "chkchk") {
    				var idToReset = "chkFilter_" + idArray[1] + "_" + idArray[2];
    				var status = $("[id='" + idToReset + "']").prop('checked');
    				//var chkStatus = $("#"+"+ idToReset).;
    				populateData += id + "~~" + idToReset + "~" + status + ";";
    				grdSave += (label + "~") + ((status == true) ? 1 : 0) + "_" + idArray[2] + "_" + status + ";";
    				showInGrid += idArray[3] + "~" + label + ";";
    			}
    			else if (idArray[0] == "chkddl") {
    				var idToReset = "ddlFilter_" + idArray[1] + "_" + idArray[2];
    				var isSelected = false;
    				if ($("[id='" + idToReset + "']").val() != "-1") {
    					isSelected = true;
    				}
    				populateData += id + "~~" + idToReset + "~" + $("[id='" + idToReset + "']").val() + ";";
    				grdSave += label + "~" + $("[id='" + idToReset + "']").val() + "_" + idArray[2] + "_" + isSelected + ";";
    				showInGrid += idArray[3] + "~" + label + ":" + $("[id='" + idToReset + "']").val() + ";";
    			}
    		});
    		if (insertHtml) {
    			$.SkillSet.RemoveDivFromPage("#divDialog");
    		}
    		var retObj = { DataToPopulate: populateData, DataToSave: grdSave, ShowInGrid: showInGrid };
    		return retObj;
    	},
    	onDialogOkClick: function () {
    		$("#hdnFilter").val(true);
    		var objFilter = $.SkillSet.GetSelectedFilterSkills(false);
    		$.SkillSet._selectedFilterSkills = objFilter.DataToSave;
    		$.SkillSet._filterSkillsToPopulate = objFilter.DataToPopulate;
    		$.SkillSet._filterSkillsSelected = true;
    		//RMK: Added
    		//Data to show in grid
    		$.SkillSet._showFilterSkillsInGrid = objFilter.ShowInGrid;
    		//Show grid as a new row
    		//Remove the existing row and add a new row
    		//BJL 4756
    		if (!$.SkillSet._isPopupClosed) {
    			$('#tblAdminFilter .dyanmicClass').remove();
    			$("#tblAdminFilter tbody").append($.SkillSet.GenerateFilterSkillTable($.SkillSet._showFilterSkillsInGrid));
    			$(this).dialog("close");
    		}
    	},

    	//Open a dialog window to add the new organization
    	OpenSkillsetDialog: function (Show) {
    		var htmlToShow = $.SkillSet._departmentCategoryHtml;
    		var d = "<div id='skillsetDialog' class='monitoringCalculatorPaddings'><form id='frmDialog'>" + htmlToShow + "</form></div>";


    		$("#divDialog").html(d);
    		$.SkillSet.HideDepartmentDivFilter();
    		if ($.SkillSet._filterSkillsSelected) {
    			//RMK:fix to clear the existing 
    			$.SkillSet.ResetControl("#filterDiv");
    			$("#filterDiv Table tr").find("td:eq(2)").attr("disabled", "disabled");
    		}
    		if ($.SkillSet._filterSkillsToPopulate) {
    			$.SkillSet.PreSelectFilterData($.SkillSet._filterSkillsToPopulate);//add preslect data here
    		}
    		setTimeout(function () {
    		}, 10);

    		if (Show) {
    			var btnArray = [{ text: "OK", click: $.SkillSet.onDialogOkClick }, rm.ui.dialog.standardButtons.cancel];
    			rm.ui.dialog.showModalWithButtons($("#divDialog"), "Skillset", "", false, 900, 530, btnArray);
    		}
    		else
    			$.SkillSet.InjectHtmlToPage(d);//inject html to page, in case user does not click the edit skills then we cant read the selected skills
    	},

    	//To disable the filter dropdown
    	DisableFilterControls: function () {
    		$("#ddlFilterCustomerCheck").attr("disabled", "disabled");
    		$("#ddlFilterStudyPhaseCheck").attr("disabled", "disabled");
    		$("#ddlFilterLanguageCheck").attr("disabled", "disabled");
    		$("#ddlFilterTACheck").attr("disabled", "disabled");
    		$("#btnFilterSkillsCheck").attr("disabled", "disabled");
    		$("#ddlFilterIndicationCheck").attr("disabled", "disabled");
    		$("#ddlFilterContractualRequirementsCheck").attr("disabled", "disabled");
    		$("#ddlFilterOrgUnitCheck").attr("disabled", "disabled");
    		$("#ddlFilterCompetencyBandCheck").attr("disabled", "disabled");
    	},

    	GetSkillsetFilterHtml: function () {
    		$.rm.Ajax_Utility("GetSkillsetFilterHtml", {}, function (data) {
    			$.SkillSet._departmentCategoryHtml = data;
    		}, true, true);
    	},

    	GenerateHtmlForEditFilter: function (resourceTypeId) {
    		$.rm.Ajax_Utility("GenerateHtmlForEditFilter", { resourceTypeId: resourceTypeId }, function (data) {
    			$.SkillSet._departmentCategoryHtml = data;
    		}, true, true);
    	},

    	PreSelectSkillData: function (dataToPrePopulate) {
    		var arrayLevelOne = $.map(dataToPrePopulate.split(';'), $.trim);
    		for (var i = 0; i < arrayLevelOne.length; i++) {
    			if (arrayLevelOne[i] != "") {
    				var arrayLevelTwo = arrayLevelOne[i].split('~');
    				if (arrayLevelTwo[0].indexOf("chk") >= 0) {
    					$("[id='" + arrayLevelTwo[0] + "']").prop('checked', true).prop('disabled', false);
    				}
    				else if (arrayLevelTwo[0].indexOf("rad") >= 0) {
    					$("input[name='" + arrayLevelTwo[0] + "'][value='" + arrayLevelTwo[1] + "']").prop('checked', true);
    				}
    				else if (arrayLevelTwo[0].indexOf("ddl") >= 0) {
    					$("[id='" + arrayLevelTwo[0] + "']").val(arrayLevelTwo[1]);
    				}
    			}
    		}
    	},

    	PreSelectFilterData: function (filterData) {

    		var arrayLevelOne = filterData.split(';');
    		for (var i = 0; i < arrayLevelOne.length; i++) {
    			if (arrayLevelOne[i] != "") {
    				var arrayLevelTwo = arrayLevelOne[i].split('~~');
    				var arrayLevelThree = arrayLevelTwo[1].split('~');
    				$("input[id='" + arrayLevelTwo[0] + "']").prop('checked', true);
    				$("input[id='" + arrayLevelTwo[0] + "']").change();
    				if (arrayLevelTwo[1].indexOf("chk") >= 0) {
    					if (arrayLevelThree[1] == "true") {
    						$("[id='" + arrayLevelThree[0] + "']").prop('checked', true);
    					}
    				}
    				else if (arrayLevelTwo[1].indexOf("rad") >= 0) {
    					$("input[name='" + arrayLevelThree[0] + "'][value='" + arrayLevelThree[1] + "']").prop('checked', true);
    				}
    				else if (arrayLevelTwo[1].indexOf("ddl") >= 0) {
    					$("[id='" + arrayLevelThree[0] + "']").val(arrayLevelThree[1]);
    				}
    			}
    		}
    	},

    	PopulateMatchingSkills: function (dropdownData) {
    		$("#ddlFilterCustomerShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowCustomer) + "')").attr('selected', 'selected');
    		if (dropdownData.ShowCustomer) {
    			$("#ddlFilterCustomerCheck option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.DefaultCustomer) + "')").attr('selected', 'selected');
    			$("#ddlFilterCustomerCheck").attr('disabled', false);
    		}

    		$("#ddlFilterStudyPhaseShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowStudyPhase) + "')").attr('selected', 'selected');
    		if (dropdownData.ShowStudyPhase) {
    			$("#ddlFilterStudyPhaseCheck option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.DefaultStudyPhase) + "')").attr('selected', 'selected');
    			$("#ddlFilterStudyPhaseCheck").attr('disabled', false);
    		}

    		$("#ddlFilterLanguageShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowLanguages) + "')").attr('selected', 'selected');
    		if (dropdownData.ShowLanguages) {
    			$("#ddlFilterLanguageCheck option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.DefaultLanguages) + "')").attr('selected', 'selected');
    			$("#ddlFilterLanguageCheck").attr('disabled', false);
    		}

    		$("#ddlFilterTAShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowTA) + "')").attr('selected', 'selected');
    		if (dropdownData.ShowTA) {
    			$("#ddlFilterTACheck option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.DefaultTA) + "')").attr('selected', 'selected');
    			$("#ddlFilterTACheck").attr('disabled', false);
    		}

    		$("#ddlFilterSkillsShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowSkill) + "')").attr('selected', 'selected');
    		$("#btnFilterSkillsCheck").prop('value', 'Edit Skills');
    		if (dropdownData.ShowSkill)
    			$("#btnFilterSkillsCheck").attr('disabled', false);

    		$("#ddlFilterIndicationShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowIndication) + "')").attr('selected', 'selected');
    		if (dropdownData.ShowIndication) {
    			$("#ddlFilterIndicationCheck option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.DefaultIndication) + "')").attr('selected', 'selected');
    			$("#ddlFilterIndicationCheck").attr('disabled', false);
    		}

    		$("#ddlFilterContractualRequirementsShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowContractualRequirements) + "')").attr('selected', 'selected');
    		if (dropdownData.ShowContractualRequirements) {
    			$("#ddlFilterContractualRequirementsCheck option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.DefaultContractualRequirements) + "')").attr('selected', 'selected');
    			$("#ddlFilterContractualRequirementsCheck").attr('disabled', false);
    		}

    		$("#ddlFilterOrgUnitShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowOrganizationalUnit) + "')").attr('selected', 'selected');
    		if (dropdownData.ShowOrganizationalUnit) {
    			$("#ddlFilterOrgUnitCheck option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.DefaultOrganizationalUnit) + "')").attr('selected', 'selected');
    			$("#ddlFilterOrgUnitCheck").attr('disabled', false);
    		}

    		$("#ddlFilterCompetencyBandShow option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.ShowCompetencyBand) + "')").attr('selected', 'selected');
    		if (dropdownData.ShowCompetencyBand) {
    			$("#ddlFilterCompetencyBandCheck option:contains('" + $.SkillSet.ReturnDropdownValue(dropdownData.DefaultCompetencyBand) + "')").attr('selected', 'selected');
    			$("#ddlFilterCompetencyBandCheck").attr('disabled', false);
    		}
    	},

    	ReturnDropdownValue: function (value) {
    		return value ? "Yes" : "No";
    	},

    	IsDepartmentExists: function (idArray, department) {
    		var isExists = false;
    		for (var i = 0; i < idArray.length; i++) {
    			if (department == idArray[i]) {
    				isExists = true;
    			}
    		}
    		return isExists;
    	},
    	//RMK:As part of QRPM-4676 added to generate skillset filter table below the add skill button
    	GenerateFilterSkillTable: function (selectedSkills) {
    		var idArray = new Array();
    		var filterDataArray = new Array();
    		var rowDataArray = new Array;
    		var arrayLevelOne = selectedSkills.split(';');
    		for (var i = 0; i < arrayLevelOne.length - 1; i++) {
    			var arrayLevelTwo = arrayLevelOne[i].split('~');
    			if (!$.SkillSet.IsDepartmentExists(idArray, arrayLevelTwo[0])) {
    				idArray.push(arrayLevelTwo[0])
    			}
    		}
    		for (var i = 0; i < arrayLevelOne.length - 1; i++) {
    			var arrayLevelTwo = arrayLevelOne[i].split('~');
    			var itemToSend = {
    				Id: arrayLevelTwo[0],
    				Data: arrayLevelTwo[1]

    			}
    			filterDataArray.push(itemToSend);
    		}
    		for (var i = 0; i < idArray.length; i++) {
    			var html = '';
    			for (var j = 0; j < filterDataArray.length; j++) {
    				if (idArray[i] == filterDataArray[j].Id) {
    					html += filterDataArray[j].Data + ';';
    				}
    			}
    			var rowData = "<tr><td>" + idArray[i] + "</td><td>" + html + "</td></tr>";
    			rowDataArray.push(rowData);

    		}
    		var htmlRow = "<tr class='dyanmicClass'><td colspan='3'>";
    		htmlRow = htmlRow + "<table id='tblShowSkillFilter' style='width:100%;' ><thead><tr><th>Department</th><th>Filter Summary</th></tr></thead>" +
			"<tbody>";
    		for (var i = 0; i < rowDataArray.length; i++) {
    			htmlRow += rowDataArray[i];
    		}
    		htmlRow = htmlRow + "</td></tr>";
    		return htmlRow;
    	},

    	GetHtmlForSkillFilter: function (resourceTypeId) {
    		$.rm.Ajax_Utility("GetHtmlForSkillFilterTable", { resourceTypeId: resourceTypeId }, function (data) {
    			$('#tblAdminFilter tbody tr:eq(9)').remove();
    			$("#tblAdminFilter tbody").append(data);
    		}, true, true);
    	},
    };