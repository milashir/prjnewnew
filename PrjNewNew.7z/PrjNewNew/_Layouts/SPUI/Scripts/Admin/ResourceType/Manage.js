﻿///<reference path="../Common/RmHelper.js"/>
$(document).ready(function () {
	rm.runtimeValues.helpPageUrl = "#";
	$("#Link_ResourceRequestList").addClass("left-static-selected-menu");

	resTypeListNs.BuildCountryMilestonesGrid();
});
resTypeListNs =
{
	baseUrl: "/_Layouts/SPUI/Admin/ResourceType/Edit.aspx?NewResourceRequestType=",
	getEditPageUrl: function (resourceTypeId) { return resTypeListNs.baseUrl + "false&ResourceRequestTypeId=" + resourceTypeId; },
	getAddPageUrl: function () { return resTypeListNs.baseUrl + "true"; },
	gridSelector: "#ResourceRequestList",
	hdnHasAccessToEditResourceTypeSelector: "[id$=hdnHasAccessToEditResourceType]",
	allowEdit: function () {
		return $(resTypeListNs.hdnHasAccessToEditResourceTypeSelector).val() == "1";
	},
	BuildCountryMilestonesGrid: function () {
		var gridPost;
		gridPost = {
			sidx: "",
			sord: ""
		};

		var gridToolsConfig = rm.grid.getGridToolDefaultConfig();
		gridToolsConfig.showManageColumns = false;
		gridToolsConfig.exportParameters = { rmPageLink: RmPageLink_E.ResourceTypeAdministration };
		rm.grid.showGridTools(resTypeListNs.gridSelector, gridToolsConfig);
		$(resTypeListNs.gridSelector).jqGrid({
			url: rm.ajax.requestSvcUrl + "GetGenericResourceTypes",
			datatype: 'json',
			mtype: 'POST',
			ajaxGridOptions: rm.grid.getJqGridAjaxOptions(false),
			ajaxRowOptions: { contentType: 'application/json; charset=utf-8' },
			jsonReader: rm.grid.getJqGridJsonReader(),
			postData: gridPost,
			loadonce: false,
			autowidth: false,
			shrinkToFit: false,
			height: rm.ui.getMaxGridHeight() - 10,
			width: rm.ui.getMaxGridWidth() - 60,
			pager: '#ResourceRequestListPager',
			multiselect: true,
			colModel: [
				{ name: 'OrganizationName', index: 'OrganizationName', label: 'Organization', width: 250, sortable: true, search: true, hidden: false },
				{ name: 'ResourceTypeName', index: 'ResourceTypeName', label: 'Resource Request Type', width: 250, sortable: true, search: true, hidden: false },
				{ name: 'IsEnabled', index: 'IsEnabled', label: 'Is Enabled', width: 100, sortable: true, search: true, hidden: false },
				{ name: 'CanInitiateNewRequests', index: 'CanInitiateNewRequests', label: 'Can Initiate', width: 100, sortable: true, search: true, hidden: false },
				{ name: 'OrganizationId', index: 'OrganizationId', label: 'OrganizationId', hidden: true },
				{ name: 'SearchSimulation', index: 'SearchSimulation', label: 'Search Simulation', width: 250, editable: false, sortable: false, search: false, hidden: false, formatter: resTypeListNs.LinkTextFormatter, formatoptions: { baseLinkUrl: 'javascript:', showAction: "SimulationReport('", addParam: "');" } },
			],
			sortname: gridPost.sidx,
			sortorder: gridPost.sord,
			multipleSearch: true,
			beforeSelectRow: function (id, event) { return rm.grid.allowRowSelection(event); },
			onPaging: function () { rm.ui.ribbon.delayedRefresh(); },
			onSelectRow: function (id) { rm.ui.ribbon.refresh(); },
			onSelectAll: function (rowIdxArray, sts) { rm.ui.ribbon.refresh(); },
			serializeRowData: function (postData) { return JSON.stringify(postData); },
			serializeGridData: function (postData) {
				var data = { Id: 0 };
				return rm.grid.serializeGridData(postData, data);
			},
			loadComplete: function (data) { rm.grid.rowData.attachAllRowsData("#ResourceRequestList", data); }
		});
		$("#ResourceRequestList").jqGrid('filterToolbar', { searchOnEnter: true, autosearch: true });
	},
	DeleteResoureceType: function () {
		if (confirm(Resources.DeleteResourceTypeConfirm)) {
			resTypeListNs.DeleteSelectedResourceTypes();
		}
	},
	SimulationReport: function (resourceTypeId) {
		var organizationId = $("#ResourceRequestList").getCell(resourceTypeId, 'OrganizationId');
		resTypeListNs.SimulateSearch(organizationId, resourceTypeId);
	},
	LinkTextFormatter: function (cellvalue, options, rowObject) {
		return "<a onclick='resTypeListNs.SimulationReport(" + options.rowId + ")' href='javascript:void(0);'>Simulation Report</a>";
	},
	AddResourceRequestType: function () {
		document.location.href = resTypeListNs.getAddPageUrl();
	},
	EditResourceRequestType: function () {
		var selectedRows = $("#ResourceRequestList").getGridParam('selarrrow');
		if (selectedRows.length > 1) {
			alert("Can only edit one request at a time.");
			return false;
		}

		if (selectedRows.length == 0) {
			alert("No request selected.");
			return false;
		}

		var resourceRequestTypeId = selectedRows[0];
		document.location.href = resTypeListNs.getEditPageUrl(resourceRequestTypeId);
	},
	DeleteSelectedResourceTypes: function () {
		var postData = { resourceTypeIds: $(resTypeListNs.gridSelector).getGridParam('selarrrow') };
		$.rm.Ajax_Request("HardDeleteResourceRequestType", postData, function (data) {
			if (data.IsSuccessfull == true) {
				rm.ui.messages.showSuccess(data.Message);
				$("#ResourceRequestList").trigger('reloadGrid');
				rm.ui.ribbon.refresh();
			}
			else {
				rm.ui.messages.addError(data.Message);
			}
		});
	},
	SimulateSearch: function (organizationId, resourceTypeId) {
		window.location = "ViewAttachment.ashx?ID=6&resourceTypeId=" + resourceTypeId + "&organizationId=" + organizationId;
	},
	IsAddResourceRequestTypeButtonEnabled: function () { return !rm.grid.hasRowsSelected(resTypeListNs.gridSelector); },
	IsEditResourceRequestTypeButtonEnabled: function () { return rm.grid.hasSingleRowSelected(resTypeListNs.gridSelector); },
	IsDeleteResourceRequestTypeButtonEnabled: function () { return rm.grid.hasRowsSelected(resTypeListNs.gridSelector); }
}
