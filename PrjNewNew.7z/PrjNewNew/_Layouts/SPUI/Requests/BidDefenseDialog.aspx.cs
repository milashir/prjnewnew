﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class BidDefenseDialog : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			QUI.UIUtility.BindDropDownList<BidDefenseReason>(ddlBidDefenseReason, CacheKey_E.BidDefenseReason, true);
		}
	}
}
