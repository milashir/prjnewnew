﻿using System;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class RejectSoftBookingDiaglog : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}