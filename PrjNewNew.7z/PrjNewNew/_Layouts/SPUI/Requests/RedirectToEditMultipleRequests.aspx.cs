﻿using System;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class RedirectToEditMultipleRequests : AbstractRmRibbonPageLayout
	{
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			var guid = CacheService.GetNewGuid();
			Session[guid] = Request.Form["selectedRequestIds"];

			Response.Redirect(string.Format("EditMultipleRequests.aspx?Key={0}&source={1}&rmPageLink={2}", guid, Request["source"], Request["rmPageLinkId"]));
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "Id",
				Title = "Title",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
