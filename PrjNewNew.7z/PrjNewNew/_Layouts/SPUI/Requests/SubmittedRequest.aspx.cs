﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class SubmittedRequest : AbstractRmRibbonPageLayout
	{
		private RmPageLink_E? _rmPageLink = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					_rmPageLink = (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), Request["rmPageLink"]);
					if (_rmPageLink == RmPageLink_E.BackfillRequests || _rmPageLink == RmPageLink_E.QueriedRequests)
					{
						_rmPageLink = RmPageLink_E.SubmittedRequests;
					}
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}
		public string UserName { get { return UserCache.Usr.Name; } }
		private bool? _hasAccessToAssignRequest = null;
		public bool HasAccessToAssignRequest
		{
			get
			{
				if (!_hasAccessToAssignRequest.HasValue)
				{
					_hasAccessToAssignRequest = (new RmLinkManager(RmUser, CurrentProject)).HasAccessToLink(RmPageLink_E.ResourcingWorklist);
				}
				return _hasAccessToAssignRequest.GetValueOrDefault();
			}
		}

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
		}

		public override TabDefinition GetTabDefinition()
		{
			return GetTabDefinitionForSubmitted();
		}

		public TabDefinition GetTabDefinitionForSubmitted()
		{
			AddActionsForSelectedRequests();
			AddActionsForUnassignedRequests();
			AddActionsForAssignedRequests();
			AddActionsForSoftBookedRequests();
			AddActionsForQueriedRequests();

			return new TabDefinition()
			{
				Id = "RequestRibbon",
				Title = "Submitted Requests",
				Groups = PageGroups.ToArray()
			};
		}

		private void AddActionsForAssignedRequests()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "BackfillAction",
				Title = "Assigned Resource Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
				{
				new ButtonDefinition() {
					Id="PermanentBackfill",
					Title="Create Backfill Request",
					CommandJavaScript = "subRqNs.createBackfill();",
					CommandEnableJavaScript = "subRqNs.isCreateBackfillEnabled();",
					Image=MapImageLibrary.GetFormatMapImage(2,5, revision)
					}
				}
			});
		}

		private void AddActionsForUnassignedRequests()
		{
			var buttons = new List<ControlDefinition>
			{
				new ButtonDefinition()
				{
		  Id="ReturnRequest",
		  Title="Query Request",
		  CommandJavaScript = "subRqNs.queryRequest();",
		  CommandEnableJavaScript = "subRqNs.isQueryRequestEnabled();",
		  Image=MapImageLibrary.GetPSImage(5,1, revision)
		}
			};

			if (HasAccessToAssignRequest)
			{
				buttons.Add(new ButtonDefinition
				{
					Id = "AssignResource",
					Title = "Assign Resource",
					CommandJavaScript = "subRqNs.assignResource();",
					CommandEnableJavaScript = "subRqNs.isAssignResourceEnabled();",
					Image = MapImageLibrary.GetFormatMapImage(1, 13, revision)
				});
			}

			PageGroups.Add(new GroupDefinition()
			{
				Id = "ReturnRequestAction",
				Title = "Unassigned Request Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = buttons.ToArray()
			});
		}

		private void AddActionsForSelectedRequests()
		{
			var buttonControlList = new List<ControlDefinition>
			{
				new ButtonDefinition() {
					Id="SaveGrid",
					Title="Save",
					CommandJavaScript = "subRqNs.saveRequestsInEditModeFromGrid();",
					CommandEnableJavaScript = "subRqNs.isSaveRequestsInEditModeFromGridEnabled();",
					Image=ImageLibrary.GetStandardImage(8,13, revision)
				},
				new ButtonDefinition() {
					Id="CancelGrid",
					Title="Cancel",
					CommandJavaScript = "subRqNs.cancelGridEditMode();",
					CommandEnableJavaScript = "subRqNs.isCancelGridEditModeEnabled();",
					Image=ImageLibrary.GetStandardImage(6,12, revision)
				},
				new ButtonDefinition() {
					Id="EditRow",
					Title="Modify Request",
					CommandJavaScript = "subRqNs.editSelectedRequest();",
					CommandEnableJavaScript = "subRqNs.isEditSelectedRequestEnabled();",
					Image=MapImageLibrary.GetPSImage(3,11, revision)
				},
				new ButtonDefinition() {
					Id="EditMultipleRow",
					Title="Modify Requests",
					CommandJavaScript = "subRqNs.editMultipleRequests();",
					CommandEnableJavaScript = "subRqNs.isEditMultipleRequestsEnabled();",
					Image=MapImageLibrary.GetPSImage(3,11, revision)
				},
				new ButtonDefinition() {
					Id="RemoveRow",
					Title="Delete Request",
					CommandJavaScript = "subRqNs.deleteSubmittedRequests();",
					CommandEnableJavaScript = "subRqNs.isDeleteSubmittedRequestsEnabled();",
					Image=MapImageLibrary.GetFormatMapImage(6,0, revision)
				},
				new ButtonDefinition() {
					Id="TerminateRow",
					Title="Terminate Request",
					CommandJavaScript = "subRqNs.terminateRequest();",
					CommandEnableJavaScript = "subRqNs.isTerminateRequestEnabled();",
					Image=MapImageLibrary.GetFormatMapImage(12,13, revision)
				}
			};

			if (RmFunction.HasPermissionToFunction(RmFunction_E.Split_Requests, UserCache.Usr, UserCache.Usr.QId, null))
			{
				buttonControlList.Add(new ButtonDefinition()
				{
					Id = "SplitAndAssign",
					Title = "Split And Assign",
					CommandJavaScript = "subRqNs.assignAndSplitRequest();",
					CommandEnableJavaScript = "subRqNs.isAssignAndSplitRequestEnabled();",
					Image = MapImageLibrary.GetFormatMapImage(5, 10, revision)
				});
			}

			PageGroups.Add(new GroupDefinition()
			{

				Id = "GridActions",
				Title = "Actions for Selected Requests",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = buttonControlList.ToArray()
			});
		}

		private void AddActionsForSoftBookedRequests()
		{
			if (RmFunction.HasPermissionToFunction(RmFunction_E.Soft_Book_Request, UserCache.Usr, UserCache.Usr.QId, null))
			{
				PageGroups.Add(
						new GroupDefinition
						{
							Id = "SoftBookingActions",
							Title = "Soft Booking Actions",
							Template = GroupTemplateLibrary.SimpleTemplate,
							Controls = new ControlDefinition[]
						{
							new ButtonDefinition()
							{
								Id = "RemoveSoftBook",
								Title = "Release Resource",
								CommandJavaScript = "subRqNs.showRemoveSoftBookDialog();",
								CommandEnableJavaScript = "subRqNs.isRemoveSoftBookEnabled();",
								Image = MapImageLibrary.GetFormatMapImage(4,14,revision)
							},
							new ButtonDefinition()
							{
								Id = "HardBook",
								Title = "Assign Resource",
								CommandJavaScript = "subRqNs.showAcceptSoftBookDialog();",
								CommandEnableJavaScript = "subRqNs.isAcceptSoftBookingEnabled();",
								Image = MapImageLibrary.GetFormatMapImage(2,13,revision)
							}
						}
						});
			}
		}

		private void AddActionsForQueriedRequests()
		{
			if (RmFunction.HasPermissionToFunction(RmFunction_E.Respond_To_Queried_Requests, UserCache.Usr, UserCache.Usr.QId, null))
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "GridActions",
					Title = "Queried Request Actions",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
					{
						new ButtonDefinition()
						{
							Id="ViewQueryDetails",
							Title="View Query Details",
							CommandJavaScript = "subRqNs.viewQueryDetails();",
							CommandEnableJavaScript = "subRqNs.isViewQueryDetailsEnabled();",
							Image=MapImageLibrary.GetPSImage(2,9, revision)
						},
						new ButtonDefinition()
						{
							Id="ResubmitRow",
							Title="Return Response",
							CommandJavaScript = "subRqNs.resubmitQueriedRequest();",
							CommandEnableJavaScript = "subRqNs.isResubmitQueriedRequestEnabled();",
							Image=MapImageLibrary.GetPSImage(9,7, revision)
						}
					}
				});
			}
		}
	}
}
