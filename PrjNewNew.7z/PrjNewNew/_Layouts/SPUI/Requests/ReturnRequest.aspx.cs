﻿using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class ReturnRequest : AbstractRmRibbonPageLayout
	{
		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition()
                            {
                                Id="SaveGrid",
                                Title="Save",
                                CommandEnableJavaScript = "$.returnRequest.SaveButtonEnabled()",
                                CommandJavaScript = "$.returnRequest.Save()",
                                Image=MapImageLibrary.GetFormatMapImage(8,13,revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="CancelGrid",
                                Title="Cancel",
                                CommandJavaScript = "$.returnRequest.Cancel()",
                                CommandEnableJavaScript = "$.returnRequest.CancelButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(6,12,revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="CloseGrid",
                                Title="Close",
                                CommandJavaScript = "$.returnRequest.Close()",
                                CommandEnableJavaScript = "$.returnRequest.CloseButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(9,14,revision)
                            }
                }
			});

			return new TabDefinition()
			{
				Id = "RequestRibbon",
				Title = "Modify Submitted Request",
				Groups = PageGroups.ToArray()
			};
		}
	}
}