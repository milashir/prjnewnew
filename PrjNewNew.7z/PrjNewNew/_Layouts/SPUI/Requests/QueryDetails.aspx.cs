﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using Quintiles.RPM.Common;
using domain = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class QueryDetails : Page
	{
		private int requestId;
		protected void Page_Load(object sender, EventArgs e)
		{
			requestId = Request["requestId"].ToInt().GetValueOrDefault();
			if (requestId == 0)
			{
				throw new Exception("Missing request Id");
			}
		}
		protected IList<domain.EntityComment> GetQueryDetails()
		{
			return domain.EntityComment.FindReturnDetails(requestId);
		}
	}
}
