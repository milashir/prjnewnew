﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.UI.UserControls;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class EditRequestNew : AbstractRmRibbonPageLayout
	{
		#region Properties
		protected global::Quintiles.RM.Clinical.UI.UserControls.CalculatorGroupContainer QipClinicalFteCalc;
		protected global::Quintiles.RM.Clinical.UI.UserControls.FTECalculator QipOtherFteCalc;
		protected global::Quintiles.RM.Clinical.UI.UserControls.GenericFTECalculator GenericFTECalculator;
		private RmPageLink_E? _rmPageLink = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					_rmPageLink = (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), Request["rmPageLink"]);
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}
		public string _projectDetailsJsonOnject { get; set; }
		public string _resourceType { get; set; }
		public int _resourceTypeId { get; set; }
		public int _isGeneric { get; set; }
		public bool _allowFteCalculatorEdits { get; set; }
		public bool _allowRequestEdit { get; set; }
		public bool _isProposalRequest { get; set; }
		public bool _allowAdhocAddEdit { get; set; }
		public bool _isBackfillRequest { get; set; }
		public bool _isPermanentBackfillRequest { get; set; }
		public bool _showAddAdhocButton { get; set; }
		public bool IsSubmitted { get { return RmPageLinkHelper.IsSubmittedPage(RmPageLink); } }
		public bool IsBackfill { get { return RmPageLinkHelper.IsBackfillPage(RmPageLink); } }
		public bool IsQueried { get { return RmPageLinkHelper.IsQueriedPage(RmPageLink); } }
		public bool IsSsv { get { return RmPageLinkHelper.IsSsvPage(RmPageLink); } }
		public bool IsMonitoring { get { return RmPageLinkHelper.IsMonitoringPage(RmPageLink); } }
		public bool IsMyStaff { get { return RmPageLinkHelper.IsMyStaffPage(RmPageLink); } }
		//public models.Request requestData = new models.Request();

		public string PageTitle
		{
			get
			{
				string title = string.Empty;

				if (IsSsv)
				{
					title = "Modify SSV Requests - {0}";
				}
				else if (IsMonitoring)
				{
					title = "Modify Monitoring Requests - {0}";
				}
				else if (IsSubmitted)
				{
					title = "Modify Submitted Requests - {0}";
				}
				else if (IsQueried)
				{
					title = "Modify Queried Requests - {0}";
				}
				else if (IsBackfill)
				{
					title = "Modify Backfill Requests - {0}";
				}
				else if (IsMyStaff)
				{
					title = "Modify My Staff Requests - {0}";
				}

				return string.Format(title, _resourceType);
			}
		}
		#endregion

		protected override void Page_Init(object sender, EventArgs e)
		{
			EnableGridSupport = true;
			base.Page_Init(sender, e);
		}

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			string requestId = HttpContext.Current.Request["requestId"];
			int id;
			if (!Int32.TryParse(requestId, out id))
			{
				throw new ArgumentException("Invalid request id");
			}

			var request = models.Request.Find(id);
			var assignedResource = ResourceRequestAssignment.GetAssignedResourceByRequestId(id);

			if (request == null)
			{
				throw new NullReferenceException("Request not found in database");
			}

			SetProperties(request);
			BindCalculators(request);
			SetHiddenControlValues(request, assignedResource);
			SetControlValues(request);

		}

		private void SetProperties(models.Request request)
		{
			_allowRequestEdit = request.AllowRequestEdit;
			_allowFteCalculatorEdits = request.AllowFteCalculatorEdit;
			_isProposalRequest = request.IsProposalRequest;
			_allowAdhocAddEdit = (!_isProposalRequest || (_isProposalRequest && (RmUser.IsAdmin || RmUser.IsSupport || RmUser.IsResourcingCenterAdmin || RmUser.IsDemandPlanner)));
			_isBackfillRequest = request.IsBackfillRequest;
			_isPermanentBackfillRequest = request.IsBackfillRequest && request.BackfillTypeId == (int)BackfillTypeName.Permanent;
			_resourceType = request.ResourceType.Name;
			_resourceTypeId = request.ResourceType.Id;
			_isGeneric = request.ResourceType.IsGeneric ? 1 : 0;
		}

		private void SetControlValues(models.Request request)
		{
			if (!_allowRequestEdit)
			{
				MakePageReadonly();
			}

			#region Dates
			txtCRATrainingDate.Text = request.CRATrainingDate.ToQDateString();
			txtIMDate.Text = request.IMDate.ToQDateString();
			txtStartDate.Text = request.StartDate.ToQDateString();
			txtStopDate.Text = request.StopDate.ToQDateString();
			txtOriginalResourceStopDate.Text = request.OriginalResourceStopDate.ToQDateString();
			txtNeedByDate.Text = request.NeedByDate.ToQDateString();
			txtTotalSites.Text = (request.TotalSites != null) ? request.TotalSites.ToString() : string.Empty;
			txtStartDate.Attributes.Add("connectedDateValue", request.PpmConnectedDates.StartDate.ToQDateString());
			txtStartDate.Attributes.Add("connectStatus", ((int)request.StartDateStatus).ToString());
			txtStopDate.Attributes.Add("connectedDateValue", request.PpmConnectedDates.StopDate.ToQDateString());
			txtStopDate.Attributes.Add("connectStatus", ((int)request.StopDateStatus).ToString());
			txtCRATrainingDate.Attributes.Add("connectedDateValue", request.PpmConnectedDates.CraTrainingDate.ToQDateString());
			txtIMDate.Attributes.Add("connectedDateValue", request.PpmConnectedDates.ImDate.ToQDateString());
			#endregion

			#region Country Region
			lblCountry.InnerHtml = request.CountryName;
			lblCountryRegion.InnerHtml = request.CountryRegionId.HasValue ? request.CountryRegion.Name : string.Empty;
			lblRegion.InnerHtml = request.RegionName;
			lblSsvType.InnerHtml = request.SSVType == null ? string.Empty : request.SSVType.Name;
			ssvTypeId.Value = request.SSVType == null ? "-1" : request.SSVType.Id.ToString();
			hdnProtocol.Value = request.Project.ProtocolNumber50;
			hdnProjectCode.Value = request.Project.ProjectCode;
			hdnCountryName.Value = request.CountryName;
			if ((request.ResourceType.Id == (int)ResourceTypeName.CRS ||
							 request.ResourceType.Id == (int)ResourceTypeName.Regional_CPM) &&
											request.RequestTypeId != (int)RequestType_E.Proposal)
			{
				lblAssignedRegion.InnerHtml = MultipleCountryRegion.getAssignedRegions(request.Id);
				lblAssignedRegion.Attributes.Add("title", lblAssignedRegion.InnerHtml);
				if (string.IsNullOrEmpty(lblAssignedRegion.InnerHtml))
				{
					lblAssignedRegion.InnerHtml = Constants.NotApplicable;
				}

				lblAssignedCountry.InnerHtml = MultipleCountryRegion.getAssignedCountries(request.Id);
				lblAssignedCountry.Attributes.Add("title", lblAssignedCountry.InnerHtml);
				if (string.IsNullOrEmpty(lblAssignedCountry.InnerHtml))
				{
					lblAssignedCountry.InnerHtml = Constants.NotApplicable;
				}
			}

			if (!request.IsHardBooked)
			{
				if (ddlRegion.Items.Count == 0)
				{
					var regionDict = request.ResourceType.GetRegions().ToDictionary(x => x.Id, x => x.Name);
					UIUtility.BindDropDown(ddlRegion, regionDict, true);
				}
				if (!request.ResourceType.IsGlobal && !request.ResourceType.IsRegionBased)
				{
					ddlRegion.SelectedValue = request.Country.Subregion.Region.Id.ToString();
				}
				else if (request.ResourceType.IsRegionBased)
				{
					ddlRegion.SelectedValue = request.RegionId.GetValueOrDefault().ToString();
				}

				if (ddlCountry.Items.Count == 0 && !request.ResourceType.IsGlobal && !request.ResourceType.IsRegionBased)
				{
					if (request.IsProposalRequest)
					{
						UIUtility.BindDropDown(ddlCountry, CacheService.Countries.Where(cntry => cntry.Value.Subregion.Region.Id == request.Country.Subregion.Region.Id).OrderBy(a => a.Value).ToDictionary(x => x.Key, x => x.Value), true);
					}
					else
					{
						var pageManager = PageManagerType.GetPageManagerTypeName(request.ResourceTypeId, request.IsProposalRequest);
						if (pageManager.Id == (int)PageManagerType_E.PhaseCalculatorPageManager_Type2 ||
														pageManager.Id == (int)PageManagerType_E.Co_monitoring_PageManager ||
														pageManager.Id == (int)PageManagerType_E.MonitoringCountrySpecificPageManager_Type1 ||
														(pageManager.Id == (int)PageManagerType_E.FlatFteCalculatorPageManager_Type1 && request.Project.ShowAllCountries))
						{
							var monitoringAttrList = MonitoringAttribute.FindAllByProjectId(request.Project.Id);
							var countryDictionary = monitoringAttrList.ToDictionary(x => x.CountryId, x => x.Country.Name);
							var showSelectItem = countryDictionary.Count > 1;
							if (countryDictionary.Count == 0)
							{
								countryDictionary.Add(request.CountryId.GetValueOrDefault(), request.CountryName);
								showSelectItem = false;
							}
							UIUtility.BindDropDown(ddlCountry, countryDictionary, showSelectItem);
						}
						else if (pageManager.Id == (int)PageManagerType_E.PhaseCalculatorPageManager_Type3)
						{
							var ssvAttrList = SSVAttribute.FindByProjectId(request.Project.Id);
							var countryDictionary = ssvAttrList.ToDictionary(x => x.CountryId, x => x.Country.Name);
							var showSelectItem = countryDictionary.Count > 1;
							if (countryDictionary.Count == 0)
							{
								countryDictionary.Add(request.CountryId.GetValueOrDefault(), request.CountryName);
								showSelectItem = false;
							}
							UIUtility.BindDropDown(ddlCountry, countryDictionary, showSelectItem);
						}
						else
						{
							UIUtility.BindDropDown(ddlCountry, CacheService.Countries.Where(cntry => cntry.Value.Subregion.Region.Id == request.Country.Subregion.Region.Id).OrderBy(a => a.Value).ToDictionary(x => x.Key, x => x.Value), true);
						}
					}
				}
				ddlCountry.SelectedValue = request.CountryId.GetValueOrDefault().ToString();
			}

			#endregion

			if (request.RequestBudgeted.HasValue)
			{
				txtReason.InnerText = request.Reason;
				radioRequestBudgetedYes.Checked = request.RequestBudgeted.GetValueOrDefault() == 1;
				radioRequestBudgetedNo.Checked = !radioRequestBudgetedYes.Checked;
			}
			hdnIsOpenLabel.Value = request.Project.IsOpenLabel.GetValueOrDefault().ToString();
			if (!(Convert.ToBoolean(hdnIsOpenLabel.Value)) && request.RequestBlinded.HasValue)
			{
				radioblindedYes.Checked = request.RequestBlinded.GetValueOrDefault() == 0;
				radioblindedNo.Checked = !radioblindedYes.Checked;
			}

			//lblFieldDuration.InnerHtml = request.Duration == null ? string.Empty : request.Duration.ToString();
			lblVisitType.InnerHtml = request.SiteVisitType == null ? string.Empty : request.SiteVisitType.Name;
			txtFte.Text = request.FTE.HasValue ? request.FTE.Value.To2DecimalString() : string.Empty;

			if (request.ProjectProtocolSite != null)
			{
				lblPIName.InnerHtml = request.ProjectProtocolSite.GetPrincipalInvestigatorName();
				lblSiteStatus.InnerHtml = request.ProjectProtocolSite.SiteStatus.Name;
				lblSiteId.InnerHtml = request.ProjectProtocolSite.GetSiteId();
			}

			lblHeader.Text = String.Format("{0} - {1}{2} - {3} {4}",
							request.Project.ProjectCode,
							request.Project.ProtocolNumber,
							(request.ResourceTypeId == (int)ResourceTypeName.SSVMonitoring_CountrySpecific) ? "" : ProjectProtocolSite.GetPiCitySiteIdString(request.ProjectProtocolSite, (ResourceTypeName)request.ResourceType.Id),
							request.ResourceType.Name,
							_isProposalRequest ? "(Proposal)" : string.Empty);
		}

		private void BindCalculators(models.Request request)
		{
			_showAddAdhocButton = false;
			var requestSchedulerType = request.RequestSchedulerType;
			if ((request.IsProposalRequest && requestSchedulerType == RequestSchedulerType_E.FlatFteValue) || requestSchedulerType == RequestSchedulerType_E.NonProposalFlatFte ||
											requestSchedulerType == RequestSchedulerType_E.MonitoringCountryLevelForecast)
			{
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = false;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
			}
			else if (request.ResourceTypeId == (int)ResourceTypeName.SSVMonitoring_CountrySpecific)
			{
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = false;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
			}
			else if (requestSchedulerType == RequestSchedulerType_E.FrequencyCalculator ||
							requestSchedulerType == RequestSchedulerType_E.SSV ||
							requestSchedulerType == RequestSchedulerType_E.ShortTermSWAT ||
							requestSchedulerType == RequestSchedulerType_E.DteFrequencyCalculator ||
							requestSchedulerType == RequestSchedulerType_E.MonitoringSiteSpecific)
			{
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
				QipClinicalFteCalc.Visible = true;
				QipClinicalFteCalc.IsRequestHardOrSoftBooked = request.IsAssigned;
				_showAddAdhocButton = (request.ResourceType.Id == (int)ResourceTypeName.Standard_Monitoring ||
																												 request.ResourceType.Id == (int)ResourceTypeName.iCRA_Monitoring ||
																												 request.ResourceType.Id == (int)ResourceTypeName.Pharmacy_Monitoring ||
																												 request.ResourceType.Id == (int)ResourceTypeName.DTESite_Monitoring ||
																												 request.ResourceType.Id == (int)ResourceTypeName.DTEPharmacy_Monitoring);

				QipClinicalFteCalc.CalculatorContainerData = CalculatorService.GetCalculatorsByRequestId(request.Id, request.IsAssigned);
			}
			else if (requestSchedulerType == RequestSchedulerType_E.PhaseCalculator ||
																			 requestSchedulerType == RequestSchedulerType_E.RegionalPhaseCalculator ||
																			 requestSchedulerType == RequestSchedulerType_E.GlobalPhaseCalculator ||
																			 requestSchedulerType == RequestSchedulerType_E.QipConnectedProposal)
			{
				QipOtherFteCalc.Visible = true;
				CoMonFteCalc.Visible = false;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
				_showAddAdhocButton = true;
				QipOtherFteCalc.IsRequestHardOrSoftBooked = request.IsAssigned;
			}
			else if (requestSchedulerType == RequestSchedulerType_E.FlatFteValue)
			{
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = true;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
			}
			else if (requestSchedulerType == RequestSchedulerType_E.Generic)
			{
				_showAddAdhocButton = true;
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = false;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = true;
				GenericFTECalculator.IsRequestHardOrSoftBooked = request.IsAssigned;
			}
		}

		private void SetHiddenControlValues(models.Request request, models.Resource assignedResource)
		{
			HdnResourceTypeName.Value = request.ResourceType.Name;
			RequestLastModifiedOn.Value = request.LastModifiedOn.Ticks.ToString();
			RequestId.Value = request.Id.ToString();
			RmPageLinkId.Value = ((int)RmPageLink).ToString();
			RequestTypeId.Value = request.RequestTypeId.ToString();
			ResourceTypeId.Value = request.ResourceType.Id.ToString();
			GenericResourceTypeName.Value = request.ResourceType.Name.ToString();
			IsGenericResourceType.Value = request.ResourceType.IsGeneric.GetIntAsStringFromBool();
			ProjectId.Value = request.Project.Id.ToString();
			CountryId.Value = request.CountryId.GetValueOrDefault().ToString();
			CountryIdForFteCalculation.Value = assignedResource == null ? CountryId.Value : assignedResource.CountryId.GetValueOrDefault().ToString();
			jobRoleIdForFteCalculation.Value = (assignedResource == null ? request.ResourceType.JobRole.Id : assignedResource.PrimaryJobRoleId.GetValueOrDefault()).ToString();
			if (assignedResource != null)
			{
				AssignedResoruceId.Value = assignedResource.Id.ToString();
				AssignedResoruceName.Value = assignedResource.Name;
				AssignedResoruceQid.Value = assignedResource.Qid;
			}
			IsBackfillRequest.Value = _isBackfillRequest.GetIntAsStringFromBool();
			IsPermanentBackfillRequest.Value = _isPermanentBackfillRequest.GetIntAsStringFromBool();
			IsProposalRequest.Value = _isProposalRequest.GetIntAsStringFromBool();
			IsHardBooked.Value = request.IsHardBooked.GetIntAsStringFromBool();
			if (request.Country != null) { CountryWeeklyHours.Value = request.Country.WeeklyHours.ToString(); }
			if (request.RegionId.HasValue) { requestRegionId.Value = request.RegionId.GetValueOrDefault().ToString(); }
			RequestStatusId.Value = request.RequestStatusId.ToString();
			ICountryAttribute attribute = request.GetAttribute();
			AttributeLastModifiedOn.Value = attribute == null ? "0" : attribute.LastModifiedOn.Ticks.ToString();
			ProjectLastModifiedOn.Value = request.Project.LastModifiedOn.Ticks.ToString();
			OrganizationId.Value = request.ResourceType.Organizations.FirstOrDefault().Id.ToString();
			ProjectOrganizationId.Value = request.Project.GetOrganizationIdFromOrganizationalUnit.ToString();
			isDteProject.Value = request.Project.IsDteProject.GetIntAsStringFromBool();
			hdnHasUserDefinedSchema.Value = request.Project.HasUserDefinedSchema.GetIntAsStringFromBool();
			if (request.ProjectProtocolSite == null)
			{
				PiLastModifiedOn.Value = "0";
				SiteLastModifiedOn.Value = "0";
				AddressLastModifiedOn.Value = "0";
				HdnSiteId.Value = "0";
			}
			else
			{
				HdnSiteId.Value = request.ProjectProtocolSite.Id.ToString();
				PiLastModifiedOn.Value = request.ProjectProtocolSite.PrincipalInvestigator == null ? "0" : request.ProjectProtocolSite.PrincipalInvestigator.LastModifiedOn.Ticks.ToString();
				SiteLastModifiedOn.Value = request.ProjectProtocolSite.LastModifiedOn.Ticks.ToString();
				AddressLastModifiedOn.Value = request.ProjectProtocolSite.Address == null ? "0" : request.ProjectProtocolSite.Address.LastModifiedOn.Ticks.ToString();
			}

			TotalHours.Value = request.TotalHours.GetValueOrDefault().To2DecimalString();
			ShowCountryRegion.Value = request.CountryRegionId.HasValue.GetIntAsStringFromBool();
			AllowFteCalculatorEdits.Value = _allowFteCalculatorEdits.GetIntAsStringFromBool();
			AllowRequestEdit.Value = _allowRequestEdit.GetIntAsStringFromBool();

			OldStartDateValue.Value = String.Format("{0:MM/dd/yyyy}", request.StartDate);
			StartDateConnectStatus.Value = ((int)request.StartDateStatus).ToString();
			StopDateConnectStatus.Value = ((int)request.StopDateStatus).ToString();
			ImDateConnectStatus.Value = ((int)request.IMDateStatus).ToString();
			CraTrainingDateConnectStatus.Value = ((int)request.CRATrainingDateStatus).ToString();
			ResourceTransitionTimeinDays.Value = CalculatorUtility.GetResourceTransitionTimeInDays(request.ResourceType.ResourceTransitionTime).ToString();
			GenericResourceTransitionTimeinDays.Value = CalculatorUtility.GetResourceTransitionTimeInDays(request.ResourceType.ResourceTransitionTime).ToString();
			hdnShowSiteList.Value = request.ResourceType.ShowSiteList == true ? "1" : "0";
		}

		private void MakePageReadonly()
		{
			ddlCountry.Enabled = false;
			ddlRegion.Enabled = false;
			txtCRATrainingDate.Enabled = false;
			txtIMDate.Enabled = false;
			txtStartDate.Enabled = false;
			txtStopDate.Enabled = false;
			txtFte.Enabled = false;
			radioRequestBudgetedNo.Disabled = true;
			radioRequestBudgetedYes.Disabled = true;
			txtReason.Disabled = true;
		}

		public override TabDefinition GetTabDefinition()
		{
			var ribbonButtonList = new List<ControlDefinition> {
				GetSiteListButtonDefinition(),
				GetViewProjectMilestonesButtonDefinition(),
				GetViewProjectDetailsButtonDefinition()
			};

			if (RmFunction.HasPermissionToFunction(RmFunction_E.Split_Requests, UserCache.Usr, UserCache.Usr.QId, null))
			{
				ribbonButtonList.Add(GetSplitandAssignDefinition());
			}

			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
				{
					new ButtonDefinition()
					{
						Id="SaveGrid",
						Title="Save",
						CommandEnableJavaScript = !_allowRequestEdit ? "false;" : "editRequest.isSaveButtonEnabled()",
						CommandJavaScript = "editRequest.save()",
						Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
					},
					new ButtonDefinition()
					{
						Id="CancelGrid",
						Title="Cancel",
						CommandJavaScript = "editRequest.cancel()",
						CommandEnableJavaScript = !_allowRequestEdit ? "false;" : "editRequest.isCancelButtonEnabled()",
						Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
					},
					new ButtonDefinition()
					{
						Id="CloseGrid",
						Title="Close",
						CommandJavaScript = "editRequest.close()",
						CommandEnableJavaScript = "editRequest.isCloseButtonEnabled()",
						Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
					}
				}
			});

			if (_showAddAdhocButton)
			{
				PageGroups.Add(new GroupDefinition()
				{
					Id = "SubmitGridAction",
					Title = "Other Action",
					Template = GroupTemplateLibrary.SimpleTemplate,
					Controls = new ControlDefinition[]
					{
							new ButtonDefinition() {
								Id="InterimFrequency",
								Title="Add Ad-hoc Interim Frequency",
								CommandJavaScript = string.Format("requestHelper.handleInterimFrequencyClick({0}, {1});", _resourceTypeId, _isGeneric),
								CommandEnableJavaScript = (_allowRequestEdit &&  _allowAdhocAddEdit ) ? "editRequest.isInterimFrequencyButtonEnabled();":"false;" ,
								Image=MapImageLibrary.GetFormatMapImage(11,3, revision)
							  }
					}
				});
			}

			PageGroups.Add(new GroupDefinition
			{
				Id = "SiteList",
				Title = "Other Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = ribbonButtonList.ToArray()
			});

			return new TabDefinition()
			{
				Id = "RequestRibbon",
				Title = PageTitle,
				Groups = PageGroups.ToArray()
			};
		}
		private ButtonDefinition GetViewProjectMilestonesButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "ViewProjectAndCountryMilestones",
				Title = "View Project and Country Milestones",
				CommandJavaScript = "editRequest.ShowMilestones()",
				CommandEnableJavaScript = "editRequest.isViewProjectMilestonesButtonEnabled();",
				Image = MapImageLibrary.GetFormatMapImage(1, 12, revision),
				ToolTip = new ToolTipDefinition() { Title = "View Project and Project-Country Milestones" }
			};
		}
		private ButtonDefinition GetSiteListButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "SiteList",
				Title = "Site List",
				CommandJavaScript = "editRequest.viewSiteListDetials();",
				CommandEnableJavaScript = "editRequest.isSiteListEnabled();",
				Image = MapImageLibrary.GetFormatMapImage(10, 1, revision),
			};
		}
		private ButtonDefinition GetViewProjectDetailsButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "ViewProjectSummary",
				Title = "View Project Summary",
				CommandJavaScript = "editRequest.viewProjectDetailsClick();",
				CommandEnableJavaScript = "editRequest.isViewProjectDetailsButtonEnabled();",
				Image = MapImageLibrary.GetFormatMapImage(1, 11, revision)
			};
		}
		private ButtonDefinition GetSplitandAssignDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "SplitAndAssign",
				Title = "Split And Assign",
				CommandJavaScript = "editRequest.assignAndSplitRequest();",
				CommandEnableJavaScript = "editRequest.isAssignAndSplitRequestEnabled();",
				Image = MapImageLibrary.GetFormatMapImage(5, 10, revision)
			};

		}
	}
}
