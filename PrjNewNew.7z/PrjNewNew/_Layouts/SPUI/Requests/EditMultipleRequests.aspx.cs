﻿using System;
using System.Collections.Generic;
using System.Linq;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class EditMultipleRequests : AbstractRmRibbonPageLayout
	{
		#region Properties
		protected global::Quintiles.RM.Clinical.UI.UserControls.CalculatorGroupContainer QipClinicalFteCalc;
		protected global::Quintiles.RM.Clinical.UI.UserControls.FTECalculator QipOtherFteCalc;
		protected global::Quintiles.RM.Clinical.UI.UserControls.GenericFTECalculator GenericFTECalculator;
		protected global::Quintiles.RM.Clinical.UI.UserControls.SmallFTECalculator CoMonFteCalc;

		private RmPageLink_E? _rmPageLink = null;
		protected override RmPageLink_E RmPageLink
		{
			get
			{
				if (!_rmPageLink.HasValue)
				{
					_rmPageLink = (RmPageLink_E)Enum.Parse(typeof(RmPageLink_E), Request["rmPageLink"]);
				}
				return _rmPageLink.GetValueOrDefault();
			}
		}
		public string _projectDetailsJsonOnject { get; set; }
		public string _resourceType { get; set; }
		public int _resourceTypeId { get; set; }
		public int _isGeneric { get; set; }
		public bool _allowFteCalculatorEdits { get; set; }
		public bool _allowRequestEdit { get; set; }
		public bool _isProposalRequest { get; set; }
		public bool _isBackfillRequest { get; set; }
		public bool _isPermanentBackfillRequest { get; set; }
		public bool IsSubmitted { get { return RmPageLinkHelper.IsSubmittedPage(RmPageLink); } }
		public bool IsBackfill { get { return RmPageLinkHelper.IsBackfillPage(RmPageLink); } }
		public bool IsQueried { get { return RmPageLinkHelper.IsQueriedPage(RmPageLink); } }
		public bool IsSsv { get { return RmPageLinkHelper.IsSsvPage(RmPageLink); } }
		public bool IsMonitoring { get { return RmPageLinkHelper.IsMonitoringPage(RmPageLink); } }
		public List<string> RequestIds { get; set; }
		public string SessionKey { get; set; }
		public string PageTitle
		{
			get
			{
				string title = string.Empty;

				if (IsSsv)
				{
					title = "Modify SSV Requests - {0}";
				}
				else if (IsMonitoring)
				{
					title = "Modify Monitoring Requests - {0}";
				}
				else if (IsSubmitted)
				{
					title = "Modify Submitted Requests - {0}";
				}
				else if (IsQueried)
				{
					title = "Modify Queried Requests - {0}";
				}
				else if (IsBackfill)
				{
					title = "Modify Backfill Requests - {0}";
				}

				return string.Format(title, _resourceType);
			}
		}
		#endregion

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			System.Text.StringBuilder displayValues = new System.Text.StringBuilder();
			var postedValues = Request.Form;

			List<int> requestIdList = GetRequestIds();

			//This page can handle multipel requests of same resource type and project. Read first request to find out common properties of the requests.
			models.Request request = models.Request.Find(requestIdList[0]);


			SetProperties(request);
			BindCalculators(request);
			SetHiddenControlValues(request);
			SetControlValues(request);
		}

		private List<int> GetRequestIds()
		{
			SessionKey = Request["Key"] == null ? string.Empty : Request["Key"].ToString();
			string requestIds = Session[SessionKey] == null ? string.Empty : Session[SessionKey].ToString();
			RequestIdList.Value = requestIds;
			return ValidateAndGetRequesIds(requestIds);
		}

		private List<int> ValidateAndGetRequesIds(string requestIds)
		{
			if (string.IsNullOrEmpty(requestIds))
			{
				Response.Redirect(string.Format("../Requests/SubmittedRequest.aspx?rmPageLink={0}", (int)RmPageLink));
				//throw new ArgumentNullException("Request IDs cannot be null or empty");
			}

			var requestIdList = new List<int>();

			RequestIds = requestIds.Split(',').ToList<string>();

			foreach (var requestId in RequestIds)
			{
				int intId;
				if (int.TryParse(requestId, out intId))
				{
					requestIdList.Add(intId);
				}
				else
				{
					throw new Exception(string.Format("RequestId must be numeric. Non numeric id found:{0}", requestId));
				}
			}

			string errorMessage;
			if (models.Request.CanEditAsAGroup(requestIdList, out errorMessage))
			{
				return requestIdList;
			}
			else
			{
				throw new Exception(errorMessage);
			}
		}

		private void SetProperties(models.Request request)
		{
			_allowRequestEdit = request.AllowRequestEdit;
			_allowFteCalculatorEdits = request.AllowFteCalculatorEdit;
			_isProposalRequest = request.IsProposalRequest;
			_isBackfillRequest = request.IsBackfillRequest;
			_isPermanentBackfillRequest = request.IsBackfillRequest && request.BackfillTypeId == (int)BackfillTypeName.Permanent;
			_resourceType = request.ResourceType.Name;
			_resourceTypeId = request.ResourceType.Id;
			_isGeneric = request.ResourceType.IsGeneric ? 1 : 0;
		}

		private void SetControlValues(models.Request request)
		{
			#region Dates
			txtStartDate.Attributes.Add("connectStatus", ((int)RequestConnect_E.Disconnected).ToString());
			txtStopDate.Attributes.Add("connectStatus", ((int)RequestConnect_E.Disconnected).ToString());
			txtStartDate.Attributes.Add("connectedDateValue", string.Empty);
			txtStartDate.Attributes.Add("connectStatus", ((int)RequestConnect_E.Disconnected).ToString());
			txtStopDate.Attributes.Add("connectedDateValue", string.Empty);
			txtStopDate.Attributes.Add("connectStatus", ((int)RequestConnect_E.Disconnected).ToString());
			txtCRATrainingDate.Attributes.Add("connectedDateValue", string.Empty);
			txtCRATrainingDate.Attributes.Add("connectStatus", ((int)RequestConnect_E.Disconnected).ToString());
			txtIMDate.Attributes.Add("connectedDateValue", string.Empty);
			txtIMDate.Attributes.Add("connectStatus", ((int)RequestConnect_E.Disconnected).ToString());
			#endregion

			radioRequestBudgetedNoChange.Checked = true;
			radioRequestBudgetedYes.Checked = false;
			radioRequestBudgetedNo.Checked = false;

			hdnIsOpenLabel.Value = request.Project.IsOpenLabel.GetValueOrDefault().ToString();

			radioRequestBlindedNoChange.Checked = true;
			radioblindedYes.Checked = false;
			radioblindedNo.Checked = false;

			lblHeader.Text = String.Format("You are editing {0} {1} requests for Project Code '{2}-{3}'. Only make changes to those fields (or reconnect dates) where required and leave fields blank where no change is needed. Please select 'Save' to save the changes or 'Close' to exit 'Modify Requests'. The changes entered will be applied to all selected requests. Refer to Help for further information.",
		RequestIds.Count(),
		request.RequestTypeId == (int)RequestType_E.Proposal ? RequestType_E.Proposal.ToString() : request.ResourceType.Name,
		request.Project.ProjectCode,
		request.Project.ProtocolNumber);
		}

		private void BindCalculators(models.Request request)
		{
			QipOtherFteCalc.MultiEditMode = true;
			CoMonFteCalc.MultiEditMode = true;
			QipClinicalFteCalc.MultiEditMode = true;
			GenericFTECalculator.MultiEditMode = true;

			var requestSchedulerType = request.RequestSchedulerType;
			if ((request.IsProposalRequest && requestSchedulerType == RequestSchedulerType_E.FlatFteValue) ||
				requestSchedulerType == RequestSchedulerType_E.MonitoringCountryLevelForecast ||
                requestSchedulerType == RequestSchedulerType_E.NonProposalFlatFte )
			{
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = false;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
			}
			else if (requestSchedulerType == RequestSchedulerType_E.FrequencyCalculator ||
				requestSchedulerType == RequestSchedulerType_E.SSV ||
				requestSchedulerType == RequestSchedulerType_E.ShortTermSWAT ||
				requestSchedulerType == RequestSchedulerType_E.DteFrequencyCalculator ||
				requestSchedulerType == RequestSchedulerType_E.MonitoringSiteSpecific)
			{
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
				QipClinicalFteCalc.Visible = true;
				QipClinicalFteCalc.IsRequestHardOrSoftBooked = request.IsAssigned;
				QipClinicalFteCalc.CalculatorContainerData = CalculatorService.GetCalculatorsForEditMultipleRequests((ResourceTypeName)request.ResourceType.Id, (RequestType_E)request.RequestTypeId, request.IsAssigned, request.Project.Id, request.Project.ProjectDteType, request.Project.VisitSchemaLevelId.GetValueOrDefault(), request.CountryId.GetValueOrDefault());
				QipClinicalFteCalc.CalculatorContainerData.IsEditMultipleRequests = true;
			}
			else if (requestSchedulerType == RequestSchedulerType_E.PhaseCalculator ||
							 requestSchedulerType == RequestSchedulerType_E.RegionalPhaseCalculator ||
							 requestSchedulerType == RequestSchedulerType_E.GlobalPhaseCalculator ||
							 requestSchedulerType == RequestSchedulerType_E.QipConnectedProposal)
			{
				QipOtherFteCalc.Visible = true;
				CoMonFteCalc.Visible = false;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
				QipOtherFteCalc.IsRequestHardOrSoftBooked = request.IsAssigned;
			}
			else if (requestSchedulerType == RequestSchedulerType_E.FlatFteValue)
			{
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = true;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = false;
			}
			else if (requestSchedulerType == RequestSchedulerType_E.Generic)
			{
				QipOtherFteCalc.Visible = false;
				CoMonFteCalc.Visible = false;
				QipClinicalFteCalc.Visible = false;
				GenericFTECalculator.Visible = true;
				GenericFTECalculator.IsRequestHardOrSoftBooked = request.IsAssigned;

				GenericStageCount.Value = GenericInitiateCalculator.CountByRequestId(request.Id).ToString();
			}
		}

		private void SetHiddenControlValues(models.Request request)
		{
			HdnResourceTypeName.Value = request.ResourceType.Name;
			RmPageLinkId.Value = ((int)RmPageLink).ToString();
			RequestTypeId.Value = request.RequestTypeId.ToString();
			ResourceTypeId.Value = request.ResourceType.Id.ToString();
			IsGenericResourceType.Value = request.ResourceType.IsGeneric.GetIntAsStringFromBool();
			ProjectId.Value = request.Project.Id.ToString();
			RegionId.Value = request.RegionId.GetValueOrDefault().ToString();
			IsProposalRequest.Value = _isProposalRequest.GetIntAsStringFromBool();
			isDteProject.Value = request.Project.IsDteProject.GetIntAsStringFromBool();
			hdnHasUserDefinedSchema.Value = request.Project.HasUserDefinedSchema.GetIntAsStringFromBool();

			//Just return Japan country code. SD:TODO:Change the logic to use countryId agnostinc logic for such decisions
			if (request.CountryId.GetValueOrDefault() == Constants.JapanCountryId)
			{
				CountryId.Value = request.CountryId.GetValueOrDefault().ToString();
			}

			StartDateConnectStatus.Value = ((int)RequestConnect_E.Disconnected).ToString();
			StopDateConnectStatus.Value = ((int)RequestConnect_E.Disconnected).ToString();
			ImDateConnectStatus.Value = ((int)RequestConnect_E.Disconnected).ToString();
			CraTrainingDateConnectStatus.Value = ((int)RequestConnect_E.Disconnected).ToString();
			ResourceTransitionTimeinDays.Value = CalculatorUtility.GetResourceTransitionTimeInDays(request.ResourceType.ResourceTransitionTime).ToString();
			GenericResourceTransitionTimeinDays.Value = CalculatorUtility.GetResourceTransitionTimeInDays(request.ResourceType.ResourceTransitionTime).ToString();
		}

		private void MakePageReadonly()
		{

			txtCRATrainingDate.Enabled = false;
			txtStartDate.Enabled = false;
			txtStopDate.Enabled = false;
			radioRequestBudgetedNoChange.Disabled = true;
			radioRequestBudgetedNo.Disabled = true;
			radioRequestBudgetedYes.Disabled = true;
			radioRequestBlindedNoChange.Disabled = true;
			radioblindedYes.Disabled = true;
			radioblindedNo.Disabled = true;
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition()
                            {
                                Id="SaveGrid",
                                Title="Save",
                                CommandEnableJavaScript = !_allowRequestEdit ? "false;" : "editRequest.isSaveButtonEnabled()",
                                CommandJavaScript = "editRequest.save()",
                                Image=MapImageLibrary.GetFormatMapImage(8,13, revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="CancelGrid",
                                Title="Cancel",
                                CommandJavaScript = "editRequest.cancel()",
                                CommandEnableJavaScript = !_allowRequestEdit ? "false;" : "editRequest.isCancelButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(6,12, revision)
                            },
                            new ButtonDefinition()
                            {
                                Id="CloseGrid",
                                Title="Close",
                                CommandJavaScript = "editRequest.close()",
                                CommandEnableJavaScript = !_allowRequestEdit ? "false;" : "editRequest.isCloseButtonEnabled()",
                                Image=MapImageLibrary.GetFormatMapImage(9,14, revision)
                            }
                }
			});

			return new TabDefinition()
			{
				Id = "RequestRibbon",
				Title = PageTitle,
				Groups = PageGroups.ToArray()
			};
		}
	}
}
