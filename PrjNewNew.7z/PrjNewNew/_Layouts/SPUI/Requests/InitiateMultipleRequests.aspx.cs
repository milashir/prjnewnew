﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
using Quintiles.RM.Clinical.Domain.Models.Permissions;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class InitiateMultipleRequests : AbstractRmRibbonPageLayout
	{
		protected string RibbonTitle;
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.InitiateMultipleRequests; } }
		protected bool AllowHardbooking { get; set; }
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			InitializePageProperties();
			AllowHardbooking = RmFunction.HasPermissionToFunction(RmFunction_E.Hard_Book_resource_from_Multiple_Init_Assign, RmUser, RmUser.QId, null);
			lblHeading.Text = (RmUser.RolesIdList.Count == 1 && RmUser.IsResourceRequestor) ? "<h3>Multiple Initiate</h3> <label>You may initiate multiple requests on this page, but you do not hold a user role that allows you to assign requests to resources</label>" : "<h3>Multiple Initiate & Assign</h3>";
		}

		public override TabDefinition GetTabDefinition()
		{
			return new TabDefinition()
			{
				Id = "ResourceRequestRibbon",
				Title = RibbonTitle,
				Groups = PageGroups.ToArray()
			};
		}

		private void InitializePageProperties()
		{
			RibbonTitle = "Initiate Multiple Requests";

			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] 
				{
          new ButtonDefinition()
					{
						Id = "Add",
						Title = "Add New Row",
						CommandJavaScript = "initMultiReq.addNewRow(false, null);",
						CommandEnableJavaScript = "initMultiReq.isAddRowEnabled();",
						Image = MapImageLibrary.GetFormatMapImage(0, 7, revision)
					},
					new ButtonDefinition()
					{
						Id = "Clone",
						Title = "Clone to New Row",
						CommandJavaScript = "initMultiReq.cloneSelectedRows();",
						CommandEnableJavaScript = "initMultiReq.isCloneRowEnabled();",
						Image = MapImageLibrary.GetFormatMapImage(0, 7, revision)
					},
          new ButtonDefinition()
					{
						Id = "Cancel",
						Title = "Cancel",
						CommandJavaScript = "initMultiReq.cancel();",
						CommandEnableJavaScript = "initMultiReq.isCancelEnabled();",
						Image = ImageLibrary.GetStandardImage(6, 12, revision)
					},
          new ButtonDefinition()
					{
						Id = "HardBookSubmit",
						Title = "Submit Requests",
						CommandJavaScript = "initMultiReq.hardBookAndSubmit();",
						CommandEnableJavaScript = "initMultiReq.isHardBookAndSubmitEnabled();",
						Image =  MapImageLibrary.GetFormatMapImage(2, 13, revision)
					}
        }
			});
		}
	}
}
