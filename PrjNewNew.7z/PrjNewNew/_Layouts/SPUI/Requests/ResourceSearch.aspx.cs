﻿using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.Requests
{
	public partial class ResourceSearch : AbstractRmRibbonPageLayout
	{
		protected override RmPageLink_E RmPageLink { get { return RmPageLink_E.ResourcingWorklist; } }

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition
			{
				Id = "SearchActions",
				Title = "Search Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
			  {
			    new ButtonDefinition
			    {
			      Id = "Search",
			      Title = "Search",
			      CommandJavaScript = "$.rm.search.Search();",
			      CommandEnableJavaScript = "$.rm.search.SearchEnabled();",
			      Image = MapImageLibrary.GetFormatMapImage(12, 12, revision)
			    },
			    new ButtonDefinition
			    {
			      Id = "ResetFilters",
			      Title = "Reset Filters",
			      CommandJavaScript = "$.rm.search.ResetFilters();",
			      CommandEnableJavaScript = "$.rm.search.ResetFiltersEnabled();",
			      Image = MapImageLibrary.GetFormatMapImage(10, 12, revision)
			    }
			  }
			});


			var bookingButtons = new List<ControlDefinition> 
			{ 
				new ButtonDefinition
			  {
			    Id = "HardBook",
			    Title = "Hard Book",
			    CommandJavaScript = "$.rm.search.HardBook();",
			    CommandEnableJavaScript = "$.rm.search.HardBookEnabled();",
			    Image = MapImageLibrary.GetFormatMapImage(2, 13, revision)
			  },
			  new ButtonDefinition
			  {
			    Id = "SoftBook",
			    Title = "Soft Book",
			    CommandJavaScript = "$.rm.search.SoftBook();",
			    CommandEnableJavaScript = "$.rm.search.SoftBookEnabled();",
			    Image = MapImageLibrary.GetFormatMapImage(1, 13, revision)
			  }
			};

			PageGroups.Add(new GroupDefinition
			{
				Id = "ResourcingActions",
				Title = "Resourcing Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = bookingButtons.ToArray()
			});

			PageGroups.Add(new GroupDefinition
			{
				Id = "ResourcingRequirements",
				Title = "Resourcing Requirements",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
			  {
						GetViewResourcingRequestButtonDefinition(),
						GetViewResourcingRequestNotExistButtonDefinition()
			  }
			});

			PageGroups.Add(new GroupDefinition
			{
				Id = "firewalledStudies",
				Title = "Firewall Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
			  {
					GetViewFirewalledProjectsButtonDefinition(),
					GetViewFirewalledProjectsNotExistButtonDefinition()
			  }
			});

			PageGroups.Add(new GroupDefinition
			{
				Id = "SiteList",
				Title = "Other Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[]
			  {
					GetSiteListButtonDefinition()			
			  }

			});

			return new TabDefinition
			{
				Id = "ResourceSearch",
				Title = "Resourcing Worklist",
				Groups = PageGroups.ToArray()
			};
		}

		private ButtonDefinition GetViewResourcingRequestButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "ViewResourcingRequirements",
				Title = "View",
				CommandJavaScript = "$.rm.search.viewResourcingRequirement();",
				CommandEnableJavaScript = "$.rm.search.viewEnabled();",
				Image = MapImageLibrary.GetFormatMapImage(7, 15, revision)
			};
		}

		private ButtonDefinition GetViewResourcingRequestNotExistButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "ViewResourcingRequirementsNotExist",
				Title = "View",
				CommandJavaScript = "$.rm.search.viewResourcingRequirement();",
				CommandEnableJavaScript = "false",
				Image = MapImageLibrary.GetFormatMapImage(8, 15, revision)
			};
		}

		private ButtonDefinition GetViewFirewalledProjectsButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "FirewalledProjects",
				Title = "View Firewalled Projects",
				CommandJavaScript = "$.rm.search.viewFirewalledProjects();",
				CommandEnableJavaScript = "$.rm.search.firewalledProjectViewEnabled();",
				Image = MapImageLibrary.GetFormatMapImage(10, 15, revision),
				ToolTip = new ToolTipDefinition()
				{
					Title = "Firewalled Projects",
					Description = "Firewalled studies of the projects of the selected requests"
				}
			};
		}

		private ButtonDefinition GetViewFirewalledProjectsNotExistButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "FirewalledProjectsNotExist",
				Title = "View Firewalled Projects",
				CommandJavaScript = "$.rm.search.viewFirewalledProjects();",
				CommandEnableJavaScript = "false",
				Image = MapImageLibrary.GetFormatMapImage(10, 15, revision)
			};
		}

		private ButtonDefinition GetSiteListButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "SiteList",
				Title = "Site List",
				CommandJavaScript = "$.rm.search.viewSiteListDetials();",
				CommandEnableJavaScript = "$.rm.search.isSiteListEnabled();",
				Image = MapImageLibrary.GetFormatMapImage(10, 1, revision),
			};
		}

		private ButtonDefinition GetEditRequestButtonDefinition()
		{
			return new ButtonDefinition()
			{
				Id = "EditRequest",
				Title = "Modify Request",
				CommandJavaScript = "$.rm.search.editSelectedRow();",
				CommandEnableJavaScript = "$.rm.search.editSelectedRowEnabled();",
				Image = MapImageLibrary.GetPSImage(3, 11, revision),
			};
		}

		protected override void Page_Load(object sender, System.EventArgs e)
		{
			base.Page_Load(sender, e);
			//write the flag that decide whether to show 
			ClientScript.RegisterClientScriptBlock(this.GetType(), "codevalue", "<script>var searchCodeValues = {showGraphErrors: " + Quintiles.RM.Clinical.Domain.Models.ConfigValue.ShowGraphErrors.ToString().ToLower() + ", maxRowsToSelect: " + Quintiles.RM.Clinical.Domain.Models.ConfigValue.MaxRowsToSelect.ToString().ToLower() + "};</script>");
		}
	}
}