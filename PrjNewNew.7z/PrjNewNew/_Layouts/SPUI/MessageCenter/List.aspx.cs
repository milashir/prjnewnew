﻿using System;
using System.Web.UI.WebControls;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.SharePoint.QUI;
using Quintiles.RM.Clinical.Ui.Ribbon;
namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI.MessageCenter
{
	public partial class List : AbstractRmRibbonPageLayout
	{
		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);
			ContainerDiv.Visible = (CurrentProject != null);
			PopulateDropdowns();
			ltrMessageList.Text = MessageCenterService.GetMessageHtml(CurrentProject, 7);
		}

		private void PopulateDropdowns()
		{
			var projectList = Project.FindAll();
			if (projectList != null)
			{
				foreach (var project in projectList)
				{
					ddlProject.Items.Add(new ListItem { Text = project.ProjectCode, Value = project.Id.ToString(), Selected = (CurrentProject != null && CurrentProject.Id == project.Id) });
				}
				var regionList = Region.FindAll();
				if (regionList != null)
				{
					foreach (var region in regionList)
					{
						ddlRegion.Items.Add(new ListItem { Text = region.RegionCode, Value = region.Id.ToString() });
					}
				}

			}
		}

		public override TabDefinition GetTabDefinition()
		{
			PageGroups.Add(new GroupDefinition()
			{
				Id = "GridActions",
				Title = "Actions",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="SaveGrid",
                                Title="Save",
                                CommandJavaScript = "monrNs.SaveGrid();",
                                Image=ImageLibrary.GetStandardImage(8,13, revision)
                            },
                             new ButtonDefinition() {
                                Id="SubmitGrid",
                                Title="Submit",
                                CommandJavaScript = "monrNs.SubmitGrid();",
                                Image=ImageLibrary.GetStandardImage(0,10, revision)
                            },
                            new ButtonDefinition() {
                                Id="CancelGrid",
                                Title="Cancel",
                                CommandJavaScript = "monrNs.CancelGrid();",
                                Image=ImageLibrary.GetStandardImage(6,12, revision)
                            }
                        }
			});

			PageGroups.Add(new GroupDefinition()
			{
				Id = "MessageActions",
				Title = "Messages",
				Template = GroupTemplateLibrary.SimpleTemplate,
				Controls = new ControlDefinition[] {
                            new ButtonDefinition() {
                                Id="AddNewMessage",
                                Title="Add New",
                                CommandJavaScript = "AddNewMessage()",
                                Image=MapImageLibrary.GetFormatMapImage(6,5, revision)
                            },
                             new ButtonDefinition() {
                                Id="UpdateMessage()",
                                Title="Update",
                                CommandJavaScript = "UpdateMessage()",
                                Image=MapImageLibrary.GetFormatMapImage(4,6, revision)
                            },
                            new ButtonDefinition() {
                                Id="DeleteMessage",
                                Title="Delete",
                                CommandJavaScript = "DeleteMessage()",
                                Image=MapImageLibrary.GetFormatMapImage(2,6, revision)
                            }
                        }
			});
			return new TabDefinition()
			{
				Id = "PermanentRequestRibbon",
				Title = "Permanent Requests",
				Groups = PageGroups.ToArray()
			};
		}
	}
}
