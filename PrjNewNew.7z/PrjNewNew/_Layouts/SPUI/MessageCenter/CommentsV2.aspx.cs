﻿using System;
using System.Text;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.SharePoint.Layouts.SPUI
{
	public partial class CommentsV2 : System.Web.UI.Page
	{
		protected int commentId;
		protected int entityId;
		protected int searchLevel;
		protected int entityTypeId;
		protected EntityTypes entityTypeEnum;
		protected int countryId;
		protected int regionId;
		protected int projectId;
		protected int resourceTypeId;
		protected int projectJobRoleId;

		protected void Page_Load(object sender, EventArgs e)
		{
			commentId = Request["commentId"].ToInt().GetValueOrDefault();
			entityId = Request["entityId"].ToInt().GetValueOrDefault();
			searchLevel = Request["searchLevel"].ToInt().GetValueOrDefault();
			entityTypeId = Request["entityTypeId"].ToInt().GetValueOrDefault();
			entityTypeEnum = (EntityTypes)Enum.Parse(typeof(EntityTypes), entityTypeId.ToString());
			countryId = Request["countryId"].ToInt().GetValueOrDefault();
			regionId = Request["regionId"].ToInt().GetValueOrDefault();
			projectId = Request["projectId"].ToInt().GetValueOrDefault();
			resourceTypeId = Request["resourceTypeId"].ToInt().GetValueOrDefault();
			projectJobRoleId = Request["projectJobRoleId"].ToInt().GetValueOrDefault();
			if (!string.IsNullOrEmpty(Request.Form["btnSave"]))
			{
				string comment = Request["taComment"];
				if ("add".Equals(Request["action"], StringComparison.InvariantCultureIgnoreCase))
				{
					MessageCenterService.AddComment(entityTypeEnum, comment, entityId, searchLevel,
										 countryId,
										 regionId,
										 projectId,
										 resourceTypeId,
										 projectJobRoleId);
				}
				else if ("edit".Equals(Request["action"], StringComparison.InvariantCultureIgnoreCase))
				{
					MessageCenterService.UpdateComment(commentId, comment);
				}
				else if ("delete".Equals(Request["action"], StringComparison.InvariantCultureIgnoreCase))
				{
					MessageCenterService.DeleteComment(commentId);
				}
				phMessageList.Visible = true;
				modalContentDiv.Visible = false;
			}
			else
			{
				phMessageList.Visible = false;
				modalContentDiv.Visible = true;
			}

		}

		protected string GetCommentsHtml()
		{
			var comments = EntityComment.FindEntityComments(entityId, entityTypeEnum, false);
			StringBuilder sb = new StringBuilder();
			if (comments != null && comments.Count > 0)
			{
				foreach (Quintiles.RM.Clinical.Domain.Models.EntityComment item in comments)
				{
					sb.Append(item.GetNoteHtml(Request.GetTimezoneOffset(), GetEditImage(item.Id), GetDeleteImage(item.Id)));
					//bool isEditable = false;//Disabling edit delete untill siteadmin permission is available (item.CreatedBy == Common.GetCurrentUserQid());
					//sb.AppendFormat(@"<div commentid=""{0}"" class=""entityComment{1}"" editable=""{2}"" isediting=""false"">"
					//, item.Id, (isEditable) ? " editable" : string.Empty, isEditable.ToString().ToLower());
					//sb.AppendFormat(@"<div class=""messageAuthor"">{0} {1} - {2} - {3}{4}{5}</div>", item.CommentHeaderIcon, item.ResourceName, item.CommentHeader, item.LastModifiedOn.ToQDateTimeString(Request.GetTimezoneOffset()), isEditable ? GetDeleteImage(item.Id) : string.Empty, isEditable ? GetEditImage(item.Id) : string.Empty);
					//sb.AppendFormat(@"<span class=""messageContent"">{0}</span>", item.Comment);
					//sb.Append("</div>");
				}
			}
			return sb.ToString();
		}

		private string GetDeleteImage(int commentId)
		{
			return string.Format(@"<img src=""/_Layouts/SPUI/images/iconDelete.png"" class=""deleteImage"" commentid=""{0}"" />", commentId);
		}

		private string GetEditImage(int commentId)
		{
			return string.Format(@"<img src=""/_Layouts/SPUI/images/iconEdit.png"" class=""editImage"" commentid=""{0}"" />", commentId);
		}
	}
}
