﻿using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.BaseClasses;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.DTE;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RPM.Common;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public class RbmNonRbmConversionMappingConfig
	{
		public ProjectDteType_E ProjectDteType { get; set; }
		public ResourceTypeName SourceResourceTypeId { get; set; }
		public ResourceTypeName? TargetResoruceTypeId { get; set; }
		public bool DeleteTierData { get; set; }
		public bool CreateTierData { get; set; }
		public bool SoftDeleteOnMigration { get; set; }

		public static Dictionary<ResourceTypeName, RbmNonRbmConversionMappingConfig> GetMapping(ProjectDteType_E dteType)
		{
			switch (dteType)
			{
				case ProjectDteType_E.Dte:
					return GetMappingForRbm();
				case ProjectDteType_E.NonDte:
					return GetMappingForNonRbm();
				case ProjectDteType_E.Unknown:
				default:
					return null;
			}
		}

		private static Dictionary<ResourceTypeName, RbmNonRbmConversionMappingConfig> GetMappingForRbm()
		{
			return new Dictionary<ResourceTypeName, RbmNonRbmConversionMappingConfig>
			{
				{
					ResourceTypeName.Standard_Monitoring ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.Standard_Monitoring ,
						TargetResoruceTypeId =  ResourceTypeName.DTESite_Monitoring,
						CreateTierData = true,
						DeleteTierData = false,
						ProjectDteType = ProjectDteType_E.Dte,
						SoftDeleteOnMigration = false
					}
				},
				{
					ResourceTypeName.Pharmacy_Monitoring ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.Pharmacy_Monitoring ,
						TargetResoruceTypeId =  ResourceTypeName.DTEPharmacy_Monitoring,
						CreateTierData = true,
						DeleteTierData = false,
						ProjectDteType = ProjectDteType_E.Dte,
						SoftDeleteOnMigration = false
					}
				},
				{
					ResourceTypeName.iCRA_Monitoring ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.iCRA_Monitoring ,
						TargetResoruceTypeId =  null,
						CreateTierData = false,
						DeleteTierData = false,
						ProjectDteType = ProjectDteType_E.Dte,
						SoftDeleteOnMigration = true
					}
				},
				{
					ResourceTypeName.Non_DTE_CRA_Project_Country ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.Non_DTE_CRA_Project_Country ,
						TargetResoruceTypeId =  ResourceTypeName.DTE_CRA_Project_Country,
						CreateTierData = false,
						DeleteTierData = false,
						ProjectDteType = ProjectDteType_E.Dte,
						SoftDeleteOnMigration = false
					}
				},
				{
					ResourceTypeName.Non_DTE_Pharmacy_CRA_Project_Country ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.Non_DTE_Pharmacy_CRA_Project_Country ,
						TargetResoruceTypeId =  ResourceTypeName.DTE_Pharmacy_CRA_Project_Country,
						CreateTierData = false,
						DeleteTierData = false,
						ProjectDteType = ProjectDteType_E.Dte,
						SoftDeleteOnMigration = false
					}
				}
			};
		}
		private static Dictionary<ResourceTypeName, RbmNonRbmConversionMappingConfig> GetMappingForNonRbm()
		{
			return new Dictionary<ResourceTypeName, RbmNonRbmConversionMappingConfig>
			{
				{
					ResourceTypeName.DTESite_Monitoring ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.DTESite_Monitoring,
						TargetResoruceTypeId =  ResourceTypeName.Standard_Monitoring ,
						CreateTierData = false,
						DeleteTierData = true,
						ProjectDteType = ProjectDteType_E.NonDte,
						SoftDeleteOnMigration = false
					}
				},
				{
					ResourceTypeName.DTEPharmacy_Monitoring ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.DTEPharmacy_Monitoring,
						TargetResoruceTypeId =  ResourceTypeName.Pharmacy_Monitoring ,
						CreateTierData = false,
						DeleteTierData = true,
						ProjectDteType = ProjectDteType_E.NonDte,
						SoftDeleteOnMigration = false
					}
				},
				{
					ResourceTypeName.DTE_CRA_Project_Country ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.DTE_CRA_Project_Country ,
						TargetResoruceTypeId =  ResourceTypeName.Non_DTE_CRA_Project_Country,
						CreateTierData = false,
						DeleteTierData = false,
						ProjectDteType = ProjectDteType_E.NonDte,
						SoftDeleteOnMigration = false
					}
				},
				{
					ResourceTypeName.DTE_Pharmacy_CRA_Project_Country ,
					new RbmNonRbmConversionMappingConfig
					{
						SourceResourceTypeId = ResourceTypeName.DTE_Pharmacy_CRA_Project_Country ,
						TargetResoruceTypeId =  ResourceTypeName.Non_DTE_Pharmacy_CRA_Project_Country,
						CreateTierData = false,
						DeleteTierData = false,
						ProjectDteType = ProjectDteType_E.NonDte,
						SoftDeleteOnMigration = false
					}
				}
			};
		}
	}
	public class SiteVisitFrequencyDetails
	{
		public int ProjectId { get; set; }
		public int SiteId { get; set; }
		public CalculatorGroup_E CalculatorGroup { get; set; }
		public CalculatorType_E CalculatorType { get; set; }
		public decimal OnsiteFrequency { get; set; }
		public decimal RemoteFrequency { get; set; }
		public decimal OsRvRatio { get; set; }
		public int OnSiteVisitRatio { get; private set; }
		public int RemoteVisitRatio { get; private set; }
		public int TierCycle
		{
			get
			{
				var tierCycle = Convert.ToInt32(Math.Round(OnSiteVisitRatio * OnsiteFrequency, 0));
				return tierCycle == 0 ? 1 : tierCycle;
			}
		}
		public Tier_E Tier { get; set; }
		public decimal? TargetSitePercentage { get; set; }
		public bool HasSites { get; set; }
		public void ComputeOnsiteAndRemoteVisitRatios()
		{
			if (RemoteFrequency == 0)
			{
				OnSiteVisitRatio = 1;
				RemoteVisitRatio = 0;
			}
			else
			{
				OsRvRatio = OnsiteFrequency / RemoteFrequency;
				if (OsRvRatio >= 1)
				{
					OnSiteVisitRatio = 1;
					RemoteVisitRatio = Convert.ToInt32(Math.Round(OsRvRatio, 0));
				}
				else
				{
					OnSiteVisitRatio = Convert.ToInt32(Math.Round(1 / OsRvRatio, 0));
					RemoteVisitRatio = 1;
				}
			}
		}
	}
	public class RbmConverter
	{
		public Dictionary<CalculatorGroup_E, Dictionary<Tier_E, decimal>> SiteTierProportionDict { get; set; }

		public Dictionary<CalculatorGroup_E, Dictionary<CalculatorType_E, List<SiteVisitFrequencyDetails>>> SchemaInputs { get; private set; }
		public Project Project { get; set; }
		public SiteTierPropotionAlgorithm SiteTierPropotionAlgorithm { get; set; }
		private DteSchemaConfiguration ProjectSiteMonitoringSchema { get; set; }
		private DteSchemaConfiguration PharmacySchema { get; set; }
		private string LoggedInUserQid { get; set; }
		public RbmConverter(Project project, string loggedInUserQid) :
			this(project, loggedInUserQid, SiteTierPropotionAlgorithm.ByTherapeuticArea)
		{ }

		public RbmConverter(Project project, string loggedInUserQid, SiteTierPropotionAlgorithm siteTierPropotionAlgorithm)
		{
			if (project == null) { throw new ArgumentNullException("project"); }

			Project = project;
			LoggedInUserQid = loggedInUserQid;
			SiteTierPropotionAlgorithm = siteTierPropotionAlgorithm;
		}
		public void ConvertToRbm()
		{
			var targetRbmType = ProjectDteType_E.Dte;
			if (Project.ProjectDteType == targetRbmType)
			{
				throw new Exception("This method cannot be used with project which is already configured as RBM project.");
			}
			RetrieveSiteTierProportions();
			RetrieveSiteVisitFrequencyDetails();
			GenerateRbmSchemaFromSiteVisitFrequencyDetails();
			MigrateRequests(targetRbmType);
			SaveSiteTiers();
			//Ideally, UpdateProjectAttributes should be called as a last method in the conversion process. 
			//However, we cannot generate correct calculators unless Project's DteType is not correctly set to target type.
			UpdateProjectAttributes(targetRbmType);
			ReconfigureCountryCalculators(targetRbmType);
			EntityProcessFlags.ClearFlag(Project.Id, Process_E.NonRbmToRbmProjectConversion, EntityTypes.Project);
			MarkRequestsForRecaching();
		}

		private void MarkRequestsForRecaching()
		{
			var sql = string.Format(@"INSERT  INTO dbo.StaleRequestQueue ( RequestId, LastModifiedBy, LastModifiedOn, CreatedBy, CreatedOn )
				SELECT  RequestId, 'system', GETDATE(), 'system', GETDATE()
				FROM    dbo.Request
				WHERE   ProjectId = {0}
						AND RequestStatusId NOT IN ( {1}, {2}, {3} )
						AND ResourceTypeId IN ( {4}, {5}, {6}, {7} )",
				Project.Id,
				(int)RequestStatusName.New,
				(int)RequestStatusName.Closed,
				(int)RequestStatusName.Deleted,
				(int)ResourceTypeName.Standard_Monitoring,
				(int)ResourceTypeName.Pharmacy_Monitoring,
				(int)ResourceTypeName.DTESite_Monitoring,
				(int)ResourceTypeName.DTEPharmacy_Monitoring);

			DbHelp.ExecuteNonQueryText(sql);
		}

		private void UpdateProjectAttributes(ProjectDteType_E targetRbmType)
		{
			Project.ProjectDteType = targetRbmType;
			Project.VisitSchemaLevelId = ProjectDteType_E.Dte == targetRbmType ? (int?)VisitSchemaLevel_E.Custom : null;
			Project.ConvertedToFromRbmNonRbm = true;
			Project.WhoEdited = LoggedInUserQid;
			Project.SaveAndFlush();
		}

		public void ConvertToNonRbm()
		{
			var targetRbmType = ProjectDteType_E.NonDte;
			if (Project.ProjectDteType == targetRbmType)
			{
				throw new Exception("This method cannot be used with project which is already configured as Non-RBM project.");
			}
			MigrateRequests(targetRbmType);
			RemoveRequestAndSiteTiers();
			DeleteRbmSchema();
			//Ideally, UpdateProjectAttributes should be called as a last method in the conversion process. 
			//However, we cannot generate correct calculators unless Project's DteType is not correctly set to target type.
			UpdateProjectAttributes(targetRbmType);
			ReconfigureCountryCalculators(targetRbmType);
			MarkRequestsForRecaching();
		}

		private void DeleteRbmSchema()
		{
			DbHelp.ExecuteNonQueryText(string.Format("DELETE FROM dbo.VisitSchemaLevelTier_Xref WHERE ProjectId = {0};", Project.Id));
		}

		private void RemoveRequestAndSiteTiers()
		{
			var sql = string.Format(
				@"DELETE RTX FROM dbo.RequestTiers_Xref RTX JOIN dbo.Request R ON R.RequestId = RTX.RequestId WHERE R.ProjectId = {0};
				  DELETE STX FROM dbo.SiteTier_XREF STX JOIN dbo.ProjectProtocolSite PPS ON PPS.SiteId = STX.SiteId WHERE PPS.ProjectId = {0};",
				Project.Id);

			DbHelp.ExecuteNonQueryText(sql);
		}

		private void RetrieveSiteTierProportions()
		{
			SiteTierProportionDict = new SiteTierPropotionService(Project, SiteTierPropotionAlgorithm).GetProportions();

			if (!TierProportionDataExists(SiteTierProportionDict, out bool monitoringProportionExists, out bool pharmacyProportionExists) &&
				 SiteTierPropotionAlgorithm != SiteTierPropotionAlgorithm.Global)
			{
				var globalPct = new SiteTierPropotionService(Project, SiteTierPropotionAlgorithm.Global).GetProportions();
				SetTierPercentagesForMissingCalculatorGroup(globalPct, SiteTierProportionDict, monitoringProportionExists, CalculatorGroup_E.DTEMonitoringCalculator);
				SetTierPercentagesForMissingCalculatorGroup(globalPct, SiteTierProportionDict, pharmacyProportionExists, CalculatorGroup_E.DTEPharmacyCalculator);

			}
			if (!TierProportionDataExists(SiteTierProportionDict, out monitoringProportionExists, out pharmacyProportionExists))
			{
				var defaultPercentages = TargetSitePercentageDefault.GetTargetSitePercentageDefaultsDictionary();
				SetTierPercentagesForMissingCalculatorGroup(defaultPercentages, SiteTierProportionDict, monitoringProportionExists, CalculatorGroup_E.DTEMonitoringCalculator);
				SetTierPercentagesForMissingCalculatorGroup(defaultPercentages, SiteTierProportionDict, pharmacyProportionExists, CalculatorGroup_E.DTEPharmacyCalculator);
			}
		}

		private void SetTierPercentagesForMissingCalculatorGroup(Dictionary<CalculatorGroup_E, Dictionary<Tier_E, decimal>> sourceDictionary,
																 Dictionary<CalculatorGroup_E, Dictionary<Tier_E, decimal>> targetDictionary,
																 bool proportionExists, CalculatorGroup_E calculatorGroup)
		{
			if (!proportionExists && sourceDictionary.TryGetValue(calculatorGroup, out Dictionary<Tier_E, decimal> groupProportions))
			{
				if (targetDictionary.ContainsKey(calculatorGroup)) { targetDictionary[calculatorGroup] = groupProportions; }
				else { targetDictionary.Add(calculatorGroup, groupProportions); }
			}
		}

		private bool TierProportionDataExists(Dictionary<CalculatorGroup_E, Dictionary<Tier_E, decimal>> siteTierProportionDict, out bool monitoringProportionExists, out bool pharmacyProportionExists)
		{
			Func<Dictionary<CalculatorGroup_E, Dictionary<Tier_E, decimal>>, CalculatorGroup_E, bool> hasTierProportionData = (proportionDictionary, calculatorGroup) =>
			{
				return proportionDictionary != null &&
					   proportionDictionary.TryGetValue(calculatorGroup, out Dictionary<Tier_E, decimal> groupProportions) &&
					   groupProportions.Sum(mp => mp.Value) > 0;
			};

			monitoringProportionExists = hasTierProportionData(siteTierProportionDict, CalculatorGroup_E.DTEMonitoringCalculator);
			pharmacyProportionExists = hasTierProportionData(siteTierProportionDict, CalculatorGroup_E.DTEPharmacyCalculator);

			return monitoringProportionExists && pharmacyProportionExists;
		}

		private void RetrieveSiteVisitFrequencyDetails()
		{
			SchemaInputs = new Dictionary<CalculatorGroup_E, Dictionary<CalculatorType_E, List<SiteVisitFrequencyDetails>>>();
			using (var dr = DbHelp.ExecuteDataReaderSP("GetSiteVisitFrequencyDetailsByProjectId", new SqlParameter("projectId", Project.Id)))
			{
				try
				{
					while (dr.Read())
					{
						var calculatorGroup = (CalculatorGroup_E)DbSafe.Int(dr["CalculatorTypeId"]);
						var calculatorType = (CalculatorType_E)DbSafe.Int(dr["FTETypeId"]);
						if (!SchemaInputs.TryGetValue(calculatorGroup, out Dictionary<CalculatorType_E, List<SiteVisitFrequencyDetails>> frequencyTierDetails))
						{
							frequencyTierDetails = new Dictionary<CalculatorType_E, List<SiteVisitFrequencyDetails>>();
							SchemaInputs.Add(calculatorGroup, frequencyTierDetails);
						}

						if (!frequencyTierDetails.TryGetValue(calculatorType, out List<SiteVisitFrequencyDetails> siteVisitFrequencyDetailsList))
						{
							siteVisitFrequencyDetailsList = new List<SiteVisitFrequencyDetails>();
							frequencyTierDetails.Add(calculatorType, siteVisitFrequencyDetailsList);
						}

						var siteVisitFrequencyDetails = new SiteVisitFrequencyDetails
						{
							ProjectId = DbSafe.Int(dr["ProjectId"]),
							SiteId = DbSafe.Int(dr["SiteId"]),
							CalculatorGroup = calculatorGroup,
							CalculatorType = calculatorType,
							OnsiteFrequency = DbSafe.Decimal(dr["OnsiteFrequency"]),
							RemoteFrequency = calculatorGroup == CalculatorGroup_E.DTEPharmacyCalculator ? 0 : DbSafe.Decimal(dr["RemoteFrequency"])
						};
						//siteVisitFrequencyDetails.ComputeOnsiteAndRemoteVisitRatios();

						siteVisitFrequencyDetailsList.Add(siteVisitFrequencyDetails);
					}
				}
				finally { dr.Close(); }
			}
		}

		private void GenerateRbmSchemaFromSiteVisitFrequencyDetails()
		{
			ProjectSchemaDetails_WS projectRbmSchema = new ProjectSchemaDetails_WS
			{
				ProjectId = Project.Id,
				SchemaLevel = "Custom",
				SchemaVersion = 1,
				ChangeReason = Constants.AutoGeneratedFromNonRbmCalculators,
				IsPharmacyEnabled = Project.HasPharmacyCalculator
			};
			projectRbmSchema.PharmacySchemaDetails.Budget.OnsiteVisitBuffer = ConfigValue.RbmPharmacyOnsiteVisitBuffer;
			projectRbmSchema.SiteMonitoringSchemaDetails.Budget.OnsiteVisitBuffer = ConfigValue.RbmSiteMonitoringOnsiteVisitBuffer;

			ConfigureRbmSchema(projectRbmSchema, CalculatorGroup_E.DTEMonitoringCalculator);
			ConfigureRbmSchema(projectRbmSchema, CalculatorGroup_E.DTEPharmacyCalculator);
			SaveRbmSchema(projectRbmSchema);
		}

		private void SaveRbmSchema(ProjectSchemaDetails_WS projectRbmSchema)
		{
			_ = VisitSchemaLevelTier.SaveProjectCustomSchemaDetails(projectRbmSchema, LoggedInUserQid, true).Result;
		}

		private void ConfigureRbmSchema(ProjectSchemaDetails_WS projectRbmSchema, CalculatorGroup_E calculatorGroup)
		{
			if (SchemaInputs.TryGetValue(calculatorGroup, out Dictionary<CalculatorType_E, List<SiteVisitFrequencyDetails>> siteDetailsByCalculatorType))
			{
				SetSiteTiers(siteDetailsByCalculatorType, calculatorGroup);
				var tierConfigList = DeriveTierConfiguration(siteDetailsByCalculatorType, calculatorGroup);

				foreach (var tierConfig in tierConfigList)
				{
					var tierToAdd = GetTierConfigurationFromAverageTierConfig(tierConfig, calculatorGroup);
					if (tierToAdd.IsTierEnabled)
					{
						((calculatorGroup == CalculatorGroup_E.DTEMonitoringCalculator) ?
											projectRbmSchema.SiteMonitoringSchemaDetails :
											projectRbmSchema.PharmacySchemaDetails).TierList.Add(tierToAdd);
					}
				}
			}
		}

		private VisitSchemaLevelInfo_WS GetTierConfigurationFromAverageTierConfig(SiteVisitFrequencyDetails tierConfig, CalculatorGroup_E calculatorGroup)
		{
			var isDefaultTier = tierConfig.Tier == VisitSchemaLevelTier.GetDefaultTierForPseudoSchema();
			return new VisitSchemaLevelInfo_WS
			{
				ProjectId = Project.Id,
				CalculatorGroup = calculatorGroup,
				OnSiteVisitRatio = tierConfig.OnSiteVisitRatio,
				RemoteVisitRatio = calculatorGroup == CalculatorGroup_E.DTEPharmacyCalculator ? 0 : tierConfig.RemoteVisitRatio,
				TierCycle = tierConfig.TierCycle,
				IsFsiLsiDefaultTier = isDefaultTier,
				IsLsiLsoDefaultTier = isDefaultTier,
				IsLsoCovDefaultTier = isDefaultTier,
				IsPharmacyDefaultTier = isDefaultTier,
				TierName = (int)tierConfig.Tier,
				TargetSitePercentage = tierConfig.TargetSitePercentage,
				IsTierEnabled = tierConfig.TargetSitePercentage != 0
			};
		}

		private void SetSiteTiers(Dictionary<CalculatorType_E, List<SiteVisitFrequencyDetails>> siteDetailsByCalculatorType, CalculatorGroup_E calculatorGroup)
		{
			if (siteDetailsByCalculatorType != null)
			{
				foreach (var siteDetailsList in siteDetailsByCalculatorType.Values)
				{
					if (siteDetailsList != null)
					{
						var totalSites = siteDetailsList.Count;

						if (SiteTierProportionDict.TryGetValue(calculatorGroup, out Dictionary<Tier_E, decimal> tierProportionsByTierId))
						{
							if (tierProportionsByTierId != null)
							{
								var indexOfLastTieredSite = -1;
								var tierCount = tierProportionsByTierId.Count();
								var tierCounter = 1;

								foreach (var tierProportions in tierProportionsByTierId)
								{
									var numberOfSitesInCurrentTier = Convert.ToInt32(Math.Floor(tierProportions.Value * totalSites / 100));
									var startIndex = indexOfLastTieredSite + 1;
									var stopIndex = Math.Min(startIndex + numberOfSitesInCurrentTier - 1, totalSites - 1);

									//If we are on the last tier, we need to process all remaining sites regardless of the numberOfSitesInCurrentTier
									//Since we use Math.Floor, it is possible that last tier gets few extra sites that determined by the proportion.
									if (tierCounter == tierCount)
									{
										stopIndex = totalSites - 1;
									}

									for (int siteIndex = startIndex; siteIndex <= stopIndex; siteIndex++)
									{
										siteDetailsList[siteIndex].Tier = tierProportions.Key;
										siteDetailsList[siteIndex].TargetSitePercentage = tierProportions.Value;
										indexOfLastTieredSite = siteIndex;
									}
									tierCounter++;
								}
							}
						}
					}
				}
			}

		}
		private List<SiteVisitFrequencyDetails> DeriveTierConfiguration(Dictionary<CalculatorType_E, List<SiteVisitFrequencyDetails>> siteDetailsByCalculatorType, CalculatorGroup_E calculatorGroup)
		{
			var tierConfig = new List<SiteVisitFrequencyDetails>();

			if (siteDetailsByCalculatorType != null)
			{
				var combinedList = new List<SiteVisitFrequencyDetails>();
				siteDetailsByCalculatorType.Values.Each(svfd => combinedList.AddRange(svfd));

				foreach (var tier in CacheService.Tier.Values)
				{
					var currentTier = (Tier_E)tier.Id;
					decimal avgOnsiteFrequency = 0;
					decimal avgRemoteFrequency = 0;
					decimal targetSitePercentage = 0;
					var filteredSiteList = combinedList.Where(csl => csl.Tier == currentTier).ToList();

					if (filteredSiteList.Count > 0)
					{
						avgOnsiteFrequency = filteredSiteList.Average(slbt => slbt.OnsiteFrequency);
						avgRemoteFrequency = filteredSiteList.Average(slbt => slbt.RemoteFrequency);
						targetSitePercentage = filteredSiteList[0].TargetSitePercentage.GetValueOrDefault();
					}
					else
					{
						if (SiteTierProportionDict.TryGetValue(calculatorGroup, out Dictionary<Tier_E, decimal> tierProportions))
						{
							tierProportions.TryGetValue(currentTier, out targetSitePercentage);
						}
					}

					var averageFrequencyDetails = new SiteVisitFrequencyDetails
					{
						OnsiteFrequency = avgOnsiteFrequency,
						RemoteFrequency = avgRemoteFrequency,
						Tier = currentTier,
						TargetSitePercentage = targetSitePercentage,
						HasSites = filteredSiteList.Count > 0
					};
					averageFrequencyDetails.ComputeOnsiteAndRemoteVisitRatios();

					tierConfig.Add(averageFrequencyDetails);
				}

				//Update visit frequency for the tiers with no sites. Use visit frequency from the closest tier.
				var tiersWithNoSites = tierConfig.Where(tc => !tc.HasSites).ToList();
				if (tiersWithNoSites.Count > 0)
				{
					foreach (var tierConfigNoSites in tiersWithNoSites)
					{
						//First try to find a tier which has sites and is numerically less than the tier with missing sites.
						var closestTier = tierConfig.Where(tc => tc.HasSites && (int)tc.Tier < (int)tierConfigNoSites.Tier).OrderByDescending(tc => (int)tc.Tier).FirstOrDefault();
						if (closestTier == null)
						{
							//Othewise find a tier which has sites and is numerically greater than the tier with missing sites.
							closestTier = tierConfig.FirstOrDefault(tc => tc.HasSites && (int)tc.Tier > (int)tierConfigNoSites.Tier);
						}

						if (closestTier != null)
						{
							tierConfigNoSites.OnsiteFrequency = closestTier.OnsiteFrequency;
							tierConfigNoSites.HasSites = true;
						}
					}
				}
			}

			return tierConfig;
		}

		private void SaveSiteTiers()
		{
			if (SchemaInputs != null)
			{
				foreach (var siteListDictByCalculatorType in SchemaInputs)
				{
					if (siteListDictByCalculatorType.Value != null)
					{
						foreach (var siteList in siteListDictByCalculatorType.Value)
						{
							if (siteList.Value != null)
							{
								foreach (var site in siteList.Value)
								{
									var siteTierChangeInfo = new SiteTierChange_WS
									{
										CalculatorTypeId = site.CalculatorType,
										ProjectId = Project.Id,
										SiteId = site.SiteId,
										TierId = site.Tier,
										TierChangeReasonList = new List<int> { (int)SiteTierChangeReason_E.Conversion_From_NonRbm_To_Rbm }
									};
									SiteTier_XREF.CreateOrUpdateSiteTier(siteTierChangeInfo, LoggedInUserQid, out bool isTierChangeDetected);
								}
							}
						}
					}
				}
			}
		}

		private void ReconfigureCountryCalculators(ProjectDteType_E dteType)
		{
			DbHelp.ExecuteScalarSP("dbo.MigrateMonitoringCalculatorByProjectRbmType", ConfigValue.CommandTimeout,
					new SqlParameter("@projectId", Project.Id),
					new SqlParameter("@projectRbmType", (int)dteType));

			//Regenerate calculators
			var monAttrList = MonitoringAttribute.FindAllByProjectId(Project.Id);
			if (monAttrList != null && monAttrList.Count > 0)
			{
				foreach (var ma in monAttrList)
				{
					ma.GenerateFromQIPDataOrDefaultCalculator();
				}
			}
		}
		private void MigrateRequests(ProjectDteType_E dteType)
		{
			/* Mapping config defines
			 *  1. source and target resource types
			 *  2. If the reqeust should be soft deleted
			 *  3. If we need to delete request tiers
			 */
			var mappingConfig = RbmNonRbmConversionMappingConfig.GetMapping(dteType);

			if (mappingConfig != null)
			{
				var dc = DetachedCriteria.For<Request>()
						.Add(Restrictions.Eq("Project.Id", Project.Id))
						.Add(Restrictions.In("ResourceTypeId", mappingConfig.Select(mc => (int)mc.Value.SourceResourceTypeId).ToArray()));

				var requestsToMigrate = Request.FindAll(dc);

				if (requestsToMigrate != null && requestsToMigrate.Length > 0)
				{
					foreach (var request in requestsToMigrate)
					{
						if (mappingConfig.TryGetValue((ResourceTypeName)request.ResourceTypeId, out RbmNonRbmConversionMappingConfig currentMappingConfig))
						{
							if (currentMappingConfig.TargetResoruceTypeId.HasValue)
							{
								request.ResourceTypeId = (int)currentMappingConfig.TargetResoruceTypeId.GetValueOrDefault();
							}
							if (currentMappingConfig.SoftDeleteOnMigration)
							{
								request.RequestStatusId = (int)RequestStatusName.Deleted;
							}
							request.SaveAndFlush();
							//Not required as it is handled when sites tiers are saved
							//if (currentMappingConfig.CreateTierData) {  }
							if (currentMappingConfig.DeleteTierData)
							{
								DbHelp.ExecuteNonQueryText(string.Format("DELETE FROM dbo.RequestTiers_Xref WHERE RequestId={0};", request.Id));
							}
						}
					}
				}
			}
		}
	}
}
