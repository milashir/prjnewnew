﻿using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RPM.Common;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum SiteTierPropotionAlgorithm
	{
		Global = 1,
		ByTherapeuticArea = 2
	}
	public class SiteTierPropotionService
	{
		public Project Project { get; set; }
		public SiteTierPropotionAlgorithm SiteTierPropotionAlgorithmValue { get; set; }

		public SiteTierPropotionService(Project project, SiteTierPropotionAlgorithm siteTierPropotionAlgorithm)
		{
			if (project == null) { throw new ArgumentNullException("project"); }

			Project = project;
			SiteTierPropotionAlgorithmValue = siteTierPropotionAlgorithm;
		}

		public Dictionary<CalculatorGroup_E, Dictionary<Tier_E, decimal>> GetProportions()
		{
			var siteTierProportionDict = new Dictionary<CalculatorGroup_E, Dictionary<Tier_E, decimal>>();
			using (var dr = DbHelp.ExecuteDataReaderSP("GetComputedSiteTierProportionsFromHistoricalSiteTiers", new SqlParameter("projectId", Project.Id), new SqlParameter("siteTierPropotionAlgorithm", (int)SiteTierPropotionAlgorithmValue)))
			{
				try
				{
					while (dr.Read())
					{
						var calculatorType = (CalculatorGroup_E)DbSafe.Int(dr["CalculatorTypeId"]);
						if (!siteTierProportionDict.TryGetValue(calculatorType, out Dictionary<Tier_E, decimal> tierProportions))
						{
							tierProportions = new Dictionary<Tier_E, decimal>();
							siteTierProportionDict.Add(calculatorType, tierProportions);
						}
						tierProportions.Add((Tier_E)DbSafe.Int(dr["TierId"]), DbSafe.Decimal(dr["TierProportion"]));
					}
				}
				finally { dr.Close(); }

				//Make sure that proportion for the last tier is adjusted so that total of all tier adds up to 100%
				foreach (var tierProportionsByCalculatorGroup in siteTierProportionDict.Values)
				{
					var itemCount = tierProportionsByCalculatorGroup.Count();
					decimal totalProportionItems = 0;
					int processedItems = 0;
					var tierProportionKeyList = tierProportionsByCalculatorGroup.Keys.ToList();
					foreach (var tierProportionKey in tierProportionKeyList)
					{
						processedItems++;
						if (processedItems == itemCount)
						{
							tierProportionsByCalculatorGroup[tierProportionKey] = 100M - totalProportionItems;
						}
						else { totalProportionItems += tierProportionsByCalculatorGroup[tierProportionKey]; }
					}
				}
			}
			return siteTierProportionDict;
		}

	}
}
