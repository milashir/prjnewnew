	select distinct RES.Qid,RES.ResourceName AS AssignedResoruceQid,
												RES.ManagerQid,
												R.ResourceTypeId
										FROM    dbo.Project P WITH ( NOLOCK )
												JOIN dbo.Request R WITH ( NOLOCK ) ON P.ProjectId = R.ProjectId
												JOIN dbo.ResourceRequestAssignment_XREF RRX WITH ( NOLOCK ) ON RRX.RequestId = R.RequestId
												JOIN dbo.Resource RES WITH ( NOLOCK ) ON  RES.ResourceId = RRX.ResourceId
												where P.ProjectId=7436
												and R.RequestStatusId in (4,9)
												and R.ResourceTypeId=9111

												

												

												