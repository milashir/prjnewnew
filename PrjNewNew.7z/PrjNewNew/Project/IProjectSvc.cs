using System.Collections.Generic;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Web;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.DTE;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;

namespace Quintiles.RM.Clinical.SharePoint
{
	[ServiceContract]
	public interface IProjectSvc
	{
		[WebInvoke(Method = "POST",
		 UriTemplate = "GetProjectListWhichHasContractualRequirements",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ResourcingRequirementProject_WS> GetProjectListWhichHasContractualRequirements(List<int> projectIdList, int jobRoleId);

		[WebInvoke(Method = "POST",
		 UriTemplate = "UpdateProposalProjectDetails",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EntityExecutionStatus<ProposalProject_WS> UpdateProposalProjectDetails(ProposalProject_WS projectDetails);

		[WebInvoke(Method = "POST",
		 UriTemplate = "UpdateRMProjectDetails",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		RMProject_WS UpdateRMProjectDetails(RMProject_WS projectDetails);

		[WebInvoke(Method = "POST",
		 UriTemplate = "UpdatePPMProjectDetails",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		PPMProject_WS UpdatePPMProjectDetails(PPMProject_WS projectDetails);

		[WebInvoke(Method = "POST",
		 UriTemplate = "UpdateProposalProjectSummary",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ProposalProjectSummary_WS UpdateProposalProjectSummary(ProposalProjectSummary_WS projectSummary);

		[WebInvoke(Method = "POST",
		 UriTemplate = "UpdateProjectMilestones",
BodyStyle = WebMessageBodyStyle.WrappedRequest,
RequestFormat = WebMessageFormat.Json,
ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		AddMilestoneStatus_WS UpdateProjectMilestones(ProposalProject_WS projectDetails);

		[WebInvoke(Method = "POST",
		 UriTemplate = "GetProposalProjectList",
		 BodyStyle = WebMessageBodyStyle.Bare,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<string> GetProposalProjectList();

		[WebInvoke(Method = "POST",
		 UriTemplate = "GetProposalProjectDetails",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<ProposalProject_WS> GetProposalProjectDetails(string opportunityNumber, string protocolNumber);

		[WebInvoke(Method = "POST",
		 UriTemplate = "GetProposalProjectById",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ProposalProject_WS GetProposalProjectById(int projectId);

		[WebInvoke(Method = "POST",
						 UriTemplate = "GetAwardedProjectList?filterBasedonRMUser={filterBasedonRMUser}",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ValueId_WS> GetAwardedProjectList(bool filterBasedonRMUser);

		[WebInvoke(Method = "POST",
				 UriTemplate = "GetAwardedAndProposalProjectList",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ValueId_WS> GetAwardedAndProposalProjectList();


		[WebInvoke(Method = "POST",
				 UriTemplate = "GetSponsorListFromProject",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<string> GetSponsorListFromProject();

		[WebInvoke(Method = "POST",
		UriTemplate = "GetSearchDataForNewOrganization",
		BodyStyle = WebMessageBodyStyle.WrappedRequest,
		RequestFormat = WebMessageFormat.Json,
		ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		Stream GetSearchDataForNewOrganization(string searchField, int resourceRequestTypeId);

		[WebInvoke(Method = "POST",
						UriTemplate = "GetCRMProjects",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<List<CRMProjectList_WS>> GetCRMProjects(string ProjectCode);

		[WebInvoke(Method = "POST",
						UriTemplate = "GetRMProjectDetails",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<RMProject_WS> GetRMProjectDetails(string projectCode, string protocolNumber, string organizationPrefix, bool queryCRM, string autogeneratedProtocolNumber, bool isClinicalRedesignProject, ProjectDteType_E DTEStudyType);

		[WebInvoke(Method = "POST",
				 UriTemplate = "CreateCustomProtocolNumber",
				 BodyStyle = WebMessageBodyStyle.WrappedRequest,
				 RequestFormat = WebMessageFormat.Json,
				 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		string CreateCustomProtocolNumber(string organizationPrefix);

		[WebInvoke(Method = "POST",
		 UriTemplate = "UpdateProjectJobRole",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		int UpdateProjectJobRole(int projectJobRoleId, string education, int edcOther, int informArch, int metaRave, int ocRDC, int inHouse, int onSite, int globalProjectExperience,
				int projectId, int jobRoleId, string contractualRequirements);

		[WebInvoke(Method = "POST",
		 UriTemplate = "SaveResourcingRequirements",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		AddUpdateResourcingRequirementsStatus_WS SaveResourcingRequirements(ProjectJobRoleExperienceCriteria_WS projectJobRoleExpCriteria);

		[WebInvoke(Method = "POST",
		 UriTemplate = "DeleteResourcingRequirements",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		void DeleteResourcingRequirements(int[] projectJobRoleExpCriteriaIds);

		[WebInvoke(Method = "POST",
						 UriTemplate = "GetResourcingRequirements",
						 BodyStyle = WebMessageBodyStyle.WrappedRequest,
						 RequestFormat = WebMessageFormat.Json,
						 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<ProjJobRoleExpCriteriaRowData, GridProjectJobRoleExperienceCriteria_WS, GridRowCommonData> GetResourcingRequirements(int projectId);

		[WebInvoke(Method = "POST",
						 UriTemplate = "GetReadOnlyResourcingRequirements",
						 BodyStyle = WebMessageBodyStyle.WrappedRequest,
						 RequestFormat = WebMessageFormat.Json,
						 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<ProjJobRoleExpCriteriaRowData, GridProjectJobRoleExperienceCriteria_WS, GridRowCommonData> GetReadOnlyResourcingRequirements(int projectId, int jobRoleId);

		[WebInvoke(Method = "POST",
				UriTemplate = "AllowBudgetRefresh",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		BudgetRefreshStatistics_WS AllowBudgetRefresh(int projectId);

		[WebInvoke(Method = "POST",
				UriTemplate = "RefreshBudgetData",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<BudgetRefreshStatistics_WS> RefreshBudgetData(int projectId);

		[WebInvoke(Method = "POST",
				UriTemplate = "IsBudgetRefreshRunning",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		BudgetRefreshRunningStatus_WS IsBudgetRefreshRunning(int projectId);

		[WebInvoke(Method = "POST",
		 UriTemplate = "DeleteCustomMilestone",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		bool DeleteCustomMilestone(string milestoneIds);

		[WebInvoke(Method = "POST",
		 UriTemplate = "GetProjectMilestonesByProjectId",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ProjectMilestones_WS> GetProjectMilestonesByProjectId(int projectId);

		[WebInvoke(Method = "POST",
		 UriTemplate = "GetDTESchemaByProjectId",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<ProjectSchemaDetails_WS> GetDTESchemaByProjectId(int projectId);

		[WebInvoke(Method = "POST",
		 UriTemplate = "GetActiveTierConfigurationByProjectId",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ProjectSchemaDetails_WS GetActiveTierConfigurationByProjectId(int projectId);

		[WebGet(UriTemplate = "GetVisitPatternGraphData?projectId={projectId}",
				BodyStyle = WebMessageBodyStyle.Bare,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		VisitPatternGraphData_WS GetVisitPatternGraphData(int projectId);

		[WebInvoke(Method = "POST",
				 UriTemplate = "GetCustomMilestone",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<CustomMilestoneRowData, CustomMilestones, GridRowCommonData> GetCustomMilestone(GridSearchCustomMilestone_WS gridSearch);


		[WebInvoke(Method = "POST",
				 UriTemplate = "GetCountryMilestone",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<CountryMilestoneRowData, GridSearchCountryMilestone_WS, GridRowCommonData> GetCountryMilestone(GridSearchCountryMilestone_WS gridSearch);

		[WebInvoke(Method = "POST",
						UriTemplate = "UpdateCustomMilestone",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<CustomMilestoneRowData> UpdateCustomMilestone(string oper, int id, string MilestoneName, string MilestoneDate);
		[WebInvoke(Method = "POST",
						UriTemplate = "IsCustomMilestoneValid",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<string> IsCustomMilestoneValid(int milstoneId);

		[WebInvoke(Method = "POST",
				 UriTemplate = "GetAllMilestonesByProjectId",
				 BodyStyle = WebMessageBodyStyle.WrappedRequest,
				 RequestFormat = WebMessageFormat.Json,
				 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<Milestones_WS> GetAllMilestonesByProjectId(int projectId, bool getActiveOnly, int requestId, int countryId, int resourceTypeOrganizationId, int resourceTypeId);

		[WebInvoke(Method = "POST",
				UriTemplate = "SaveProjectCustomSchemaDetails",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		SingleExecutionAndValidationStatus_WS<string> SaveProjectCustomSchemaDetails(ProjectSchemaDetails_WS projectSchemaDetails);

		[WebInvoke(Method = "POST",
		 UriTemplate = "GetProjectsWhichHasFirewalledStudies",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		Dictionary<int, FirewalledProject_WS> GetProjectsWhichHasFirewalledStudies(List<int> projectIds);

		[WebInvoke(Method = "POST",
		 UriTemplate = "SaveFirewalledProjects",
		 BodyStyle = WebMessageBodyStyle.WrappedRequest,
		 RequestFormat = WebMessageFormat.Json,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		void SaveFirewalledProjects(int projectId, List<ProjectInfo_WS> projects);

		[WebGet(UriTemplate = "GetInactiveProjectDetails?projectCodeProtocol={projectCodeProtocol}",
		 BodyStyle = WebMessageBodyStyle.Bare,
		 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ValueId_WS GetInactiveProjectDetails(string projectCodeProtocol);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetAllProjectList",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ValueId_WS> GetAllProjectList();

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<SiteVisitCount_WS> GetDteSiteVisitCount(int projectId, int tierCycle, int onsiteVisitRatio, int remoteVisitRatio, decimal targetSitePercentage, bool isPharmacy);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EntityExecutionStatus<string> PerformInitiatSiteTiering(int projectId);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EntityExecutionStatus<string> UpdateSingleSiteTier(SiteTierChange_WS siteTierChangeInfo);

		[WebInvoke(Method = "POST", BodyStyle = WebMessageBodyStyle.WrappedRequest, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<SiteGridRowData, ProjectProtocolSite, AttributeCommonData> GetSitesByProject(GridSearchSitelist_WS gridSearch);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ProjectTierList_WS GetActiveTierListByProjectId(int projectId);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<TierchangeHistoryGridRowData, SiteTierChangeHistory, GridCommonData> GetSiteTierChangeHistoryBySite(GridTierChangeHistory_WS gridSearch);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EntityExecutionStatus<string> SaveSiteGeneralComments(int siteId, string comments);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EntityExecutionStatus<string> AcceptRecommendedTiers(List<SiteTierChange_WS> siteTierInfoList, string projectCode);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		MonitoringAttributeSummary_WS GetProjectSiteVisitCountSummary(int projectId);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		PeriodicTierReviewInfo_WS MarkPeriodicTierReviewComplete(int projectId);

		[WebInvoke(Method = "POST",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EntityExecutionStatus<string> UpdateRegularTierReviewFlag(int projectId, bool regularReviewRequired, int? noRegularTierReviewReasonId);

		[WebInvoke(Method = "POST",
			 UriTemplate = "GetDteSchemaForSimulation",
			 BodyStyle = WebMessageBodyStyle.WrappedRequest,
			 RequestFormat = WebMessageFormat.Json,
			 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<ProjectSchemaDetails_WS> GetDteSchemaForSimulation();

		[WebInvoke(Method = "POST",
			 UriTemplate = "GenerateVisitPatternTableForSimulation",
			 BodyStyle = WebMessageBodyStyle.WrappedRequest,
			 RequestFormat = WebMessageFormat.Json,
			 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		VisitPatternGraphData_WS GenerateVisitPatternTableForSimulation(List<VisitPatternInputData> visitPatternInputData);

		[WebInvoke(Method = "POST",
			 UriTemplate = "GetDteSiteVisitCountForSimulation",
			 BodyStyle = WebMessageBodyStyle.WrappedRequest,
			 RequestFormat = WebMessageFormat.Json,
			 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<List<SiteVisitCount_WS>> GetDteSiteVisitCountForSimulation(List<VisitSchemaLevelInfo_WS> tierConfigList, int projectedInitiatedSiteCount, string fsiMilestone, string covMilestone, int sivFirstImvWeeks);

		[WebInvoke(Method = "POST",
			 UriTemplate = "GetGloblSiteTierProportions",
			 BodyStyle = WebMessageBodyStyle.WrappedRequest,
			 RequestFormat = WebMessageFormat.Json,
			 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<VisitPatternInputData> GetGloblSiteTierProportions(bool isPharmacy);

		[WebInvoke(Method = "POST",
			 UriTemplate = "GetProjectDetailsByProjectId",
			 BodyStyle = WebMessageBodyStyle.WrappedRequest,
			 RequestFormat = WebMessageFormat.Json,
			 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ProjectDetail_WS GetProjectDetailsByProjectId(int projectId);

		[WebInvoke(Method = "POST",
			UriTemplate = "GetSiteCountBySiteStatus",
			BodyStyle = WebMessageBodyStyle.WrappedRequest,
			RequestFormat = WebMessageFormat.Json,
			ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<KeyValue_WS> GetSiteCountBySiteStatus(int projectId, int countryId);

		[WebInvoke(Method = "POST",
			UriTemplate = "ConvertNonRbmProjectToRbm",
			 BodyStyle = WebMessageBodyStyle.WrappedRequest,
			 RequestFormat = WebMessageFormat.Json,
			 ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionStatus_WS<string> ConvertNonRbmProjectToRbm(int projectId);
	}
}
