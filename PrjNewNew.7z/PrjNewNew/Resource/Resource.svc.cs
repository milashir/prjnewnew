﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Dispatcher;
using System.Text;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.ResourceMatching;
using Quintiles.RM.Clinical.Domain.Properties;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.SharePoint
{
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
	[ServiceBehavior(MaxItemsInObjectGraph = int.MaxValue)]
	public class Resource : IResource, IErrorHandler
	{
		#region Helper Methods
		private static ResReqErrors_WS[] GetRequestErrorsByResource(ResourceCalendar resCalendar)
		{
			ResReqErrors_WS[] errors = null;
			int iresReqErrors = 0;
			if (resCalendar != null && resCalendar.RequestErrors != null && resCalendar.RequestErrors.Count > 0)
			{
				errors = new ResReqErrors_WS[resCalendar.RequestErrors.Count];
				foreach (var item in resCalendar.RequestErrors)
				{
					errors[iresReqErrors] = new ResReqErrors_WS(item.Key, item.Value);
					iresReqErrors++;
				}
			}
			return errors;
		}
		#endregion
		#region GetUsers
		public JqGridData<UserPermissionRowData, RmUserTable, GridRowCommonData> GetUsers(GridSearchRmUser_WS gridSearch)
		{
			return new JqGridData<UserPermissionRowData, RmUserTable, GridRowCommonData>(RmUserTable.FindAllPagedUserPermissions(gridSearch), UserPermissionRowData.Create);
		}

		//SS:QRPM-4881:to get all filtered users for permission
		public List<RmUserTable> GetFilteredUsers(GridSearchRmUser_WS gridSearch)
		{
			return RmUserTable.FindAllPagedUserPermissions(gridSearch).Records.ToList();
		}
		#endregion

		#region GetResourceSchedule
		/// <summary>
		/// Calculate Calendar for a list of Resources
		/// It is independant of any matching Request
		/// </summary>
		/// <param name="resourceIdList"></param>
		/// <param name="minDate"></param>
		/// <param name="maxDate"></param>
		/// /// <param name="isExecPathRequired">Generates tracing information for the graph </param>
		/// <param name="graphContext">Client can control the graph context. WILL BE HONORED ONLY WHEN isExecPathRequired =true.  </param>
		/// <returns></returns>
		public ResListSched_WS GetResourceSchedule(List<int> resourceIdList, int minDate, int maxDate, bool isExecPathRequired, int graphContext)
		{
			// Get Request Sched
			ResourceScheduler resSched = null;
			if (!isExecPathRequired)
			{
				resSched = new ResourceScheduler(new SchedulerService(GraphContext.Resource), new RmCacheService(), null,
								 minDate > 0 ? (DateTime?)DateHelp.MonthNumberToDate(minDate) : null,
								 maxDate > 0 ? (DateTime?)DateHelp.MonthNumberToDate(maxDate) : null);
			}
			else
			{
				resSched = new ResourceScheduler(new SchedulerService((GraphContext)graphContext), new RmCacheService(), null,
								 minDate > 0 ? (DateTime?)DateHelp.MonthNumberToDate(minDate) : null,
								 maxDate > 0 ? (DateTime?)DateHelp.MonthNumberToDate(maxDate) : null);
			}

			#region **********Log Execution Path**********
			resSched.IsExecutionPathRequired = isExecPathRequired;
			StringBuilder sb = new StringBuilder(2000);
			Action<string> execPathDelegate = msg => sb.Append(msg); //define delegate as an inline lambda and we can use closure to capture the output
			if (isExecPathRequired)
			{
				resSched.LogExecutionPathEvent += execPathDelegate;
			}
			#endregion

			resSched.ProcessResources(resourceIdList);
			resSched.LogExecutionPathEvent -= execPathDelegate;
			resSched.TrimZeroValues();
			ResListSched_WS resList = new ResListSched_WS()
			{
				StartMonth = resSched.StartYearMonth,
				EndMonth = resSched.EndYearMonth,
				ResourcesSched = new ResSched_WS[resSched.ResourceCalendars.Count],
				ExecutionPath = sb.ToString()
			};

			// For each Resource
			int iResource = 0;
			foreach (ResourceCalendar resCalendar in resSched.ResourceCalendars.Values)
			{
				int countMonth = resCalendar.MonthlySchedule.Count;
				ResSched_WS resSchedWS = new ResSched_WS(resCalendar, countMonth);
				resList.ResourcesSched[iResource] = resSchedWS;

				int m = -1;
				//check for resource-request assignment errors
				if (resCalendar.RequestErrors != null)
				{
					resSchedWS.ResReqErrors = GetRequestErrorsByResource(resCalendar);
				}

				resList.ResourcesSched[iResource].AreAllRequestsBad = resSchedWS.ResReqErrors == null ? false : resSchedWS.ResReqErrors.Count() == resCalendar.AssignedRequests.Count ? true : false;
				resList.ResourcesSched[iResource].ResourceName = resCalendar.ResourceName;
				foreach (var resourceCalendar in resCalendar.MonthlySchedule)
				{
					m++;
					MonthlyResourceCounter resMonth = resourceCalendar.Value;

					resSchedWS.FullTimeWorkingHours[m] = resMonth.FullTimeWorkingHours;

					resSchedWS.Availability[m] = resMonth.AvailabilityHours;
					resSchedWS.Mismatch[m] = resMonth.MismatchHours;

					resSchedWS.Avt[m] = resMonth.AvtHours;
					resSchedWS.SpecialAssignment[m] = resMonth.SpecialAssignHours;
					//resSchedWS.CurrentWorkingHours[monthCount] = resMonth.CurrentWorkingHours;
					if (resMonth.HardBook != null)
					{
						resSchedWS.HardBook[m] = resMonth.HardBook.Book;
						resSchedWS.HardBookPermanentBackfill[m] = resMonth.HardBook.PermanentBackfill;
						resSchedWS.HardBookProposal[m] = resMonth.HardBook.Proposal;
						resSchedWS.HardBookTemporaryBackfill[m] = resMonth.HardBook.TemporaryBackfill;
					}
					if (resMonth.SoftBook != null)
					{
						resSchedWS.SoftBook[m] = resMonth.SoftBook.Book;
						resSchedWS.SoftBookPermanentBackfill[m] = resMonth.SoftBook.PermanentBackfill;
						resSchedWS.SoftBookProposal[m] = resMonth.SoftBook.Proposal;
						resSchedWS.SoftBookTemporaryBackfill[m] = resMonth.SoftBook.TemporaryBackfill;
					}
				}
				iResource++;
			}
			return resList;
		}

		#endregion

		#region GetMyStaffAssignment
		public JqGridData<ResourceAssignmentRowData, ResourceRequestAssignment, GridRowCommonData> GetMyStaffAssignment(GridSearchMyStaffAssignment_WS gridSearch)
		{
			return new JqGridData<ResourceAssignmentRowData, ResourceRequestAssignment, GridRowCommonData>(ResourceRequestAssignment.GetAssignmentsByResourceIdandPageNumber(gridSearch), ResourceAssignmentRowData.Create);
		}
		#endregion

		#region GetResourcesByCurrentUser
		public models.JqGridData<MyStaffDataRow, models.Resource, ResourceCommonData> GetResourcesByCurrentUser(GridSearchResource_WS gridSearch)
		{
			gridSearch.ManagerQId = ExtensionMethods.GetCurrentUserQid();
			return new JqGridData<MyStaffDataRow, models.Resource, ResourceCommonData>(models.Resource.FindAllPagedReSourcesByManagerQId(gridSearch), MyStaffDataRow.Create);
		}
		#endregion

		#region IErrorHandler Members
		public bool HandleError(Exception error)
		{
			throw new NotImplementedException();
		}

		public void ProvideFault(Exception error, System.ServiceModel.Channels.MessageVersion version, ref System.ServiceModel.Channels.Message fault)
		{
			throw new NotImplementedException();
		}
		#endregion

		public decimal SpecialAssignmentsCalculateFTE(int resourceId, string startDate, string endDate, decimal fte)
		{
			try
			{
				return (decimal)DbHelp.ExecuteScalarText(string.Format("SELECT dbo.ufn_CalculatefteforSpeacialAssignment({0}, {1}, '{2}', '{3}')",
												fte,
												resourceId,
												startDate.ToNotNullDateFromQDateString().ToShortDateString(),
												endDate.ToNotNullDateFromQDateString().ToShortDateString()));
			}
			catch (Exception ex)
			{
				throw new Exception("FTE cannot be calculated because of invalid JobCode or JobRole or Country.");
			}
		}

		public string DeleteSpecialAssignment(string assignmentIds)
		{
			try
			{
				SpecialAssignment.DeleteAssignments(assignmentIds);
				return "Success";
			}
			catch (Exception e)
			{ return "Failed"; }

		}

		public ExecutionAndValidationStatus_WS<string> CreateSpecialAssignment(SpecialAssignment_WS specialAssignmentDetails)
		{
			ExecutionAndValidationStatus_WS<string> result = new ExecutionAndValidationStatus_WS<string> { ValidationErrors = new List<ValidationMessage_WS>() };
			if (specialAssignmentDetails.IsValid(result))
			{
				for (int resIds = 0; resIds < specialAssignmentDetails.lstResouceIds.Count; resIds++)
				{
					SpecialAssignment sa = new SpecialAssignment
					{
						ResourceId = specialAssignmentDetails.lstResouceIds[resIds],
						FTEPerMonth = specialAssignmentDetails.FTEPerMonth.ToDecimal().GetValueOrDefault(),
						StartDate = specialAssignmentDetails.startDate.ToDateFromQDateString(),
						StopDate = specialAssignmentDetails.endDate.ToDateFromQDateString(),
						SpecialAssignmentCategoryId = specialAssignmentDetails.specialAssignmentCategoryId == -1 ? null : specialAssignmentDetails.specialAssignmentCategoryId,
						Description = specialAssignmentDetails.description.Trim(),
						Details = specialAssignmentDetails.details.Trim(),
						ProjectCode = specialAssignmentDetails.ProjectCode,
						ProjectInRm = specialAssignmentDetails.ProjectInRM,
						IsIndefinite = specialAssignmentDetails.IsIndefinite
					};

					sa.SaveAndFlush();
					if (specialAssignmentDetails.details.Trim() != "")
					{
						StringBuilder sb = new StringBuilder("<div>");
						models.Resource resource = models.Resource.Find(specialAssignmentDetails.lstResouceIds[resIds]);
						sb.AppendFormat("<b>Resource Name: </b>{0}", resource.Name);
						sb.AppendFormat("<br /><b>Details: </b>{0}</div>", specialAssignmentDetails.details);

						sa.CreateComment(sb.ToString(), CommentTypeName.None).SaveAndFlush();
					}
				}
			}

			return result;
		}

		public ExecutionAndValidationStatus_WS<string> UpdateSpecialAssignment(SpecialAssignment_WS specialAssignmentDetails)
		{
			ExecutionAndValidationStatus_WS<string> result = new ExecutionAndValidationStatus_WS<string> { ValidationErrors = new List<ValidationMessage_WS>() };
			if (specialAssignmentDetails.IsValid(result))
			{
				SpecialAssignment sa = SpecialAssignment.FindOneById(specialAssignmentDetails.Id);
				sa.ResourceId = specialAssignmentDetails.resourceId;
				sa.FTEPerMonth = specialAssignmentDetails.FTEPerMonth.ToDecimal().GetValueOrDefault();
				sa.StartDate = specialAssignmentDetails.startDate.ToDateFromQDateString();
				sa.StopDate = specialAssignmentDetails.endDate.ToDateFromQDateString();
				sa.SpecialAssignmentCategoryId = specialAssignmentDetails.specialAssignmentCategoryId == -1 ? null : specialAssignmentDetails.specialAssignmentCategoryId;
				sa.Description = specialAssignmentDetails.description.Trim();
				sa.ProjectCode = specialAssignmentDetails.ProjectCode;
				sa.ProjectInRm = specialAssignmentDetails.ProjectInRM;
				sa.IsIndefinite = specialAssignmentDetails.IsIndefinite;


				if (sa.Details != specialAssignmentDetails.details.Trim() && specialAssignmentDetails.details.Trim() != "")
				{
					StringBuilder sb = new StringBuilder("<div>");
					sb.AppendFormat("<b>Resource Name: </b>{0}", specialAssignmentDetails.resourceName);
					sb.AppendFormat("<br /><b>Details: </b>{0}</div>", specialAssignmentDetails.details);

					sa.CreateComment(sb.ToString(), CommentTypeName.None).SaveAndFlush();
				}

				sa.Details = specialAssignmentDetails.details.Trim();
				sa.UpdateAndFlush();
			}

			return result;
		}

		public List<RequestTypeResourceTypeGroup_WS> GetRequestTypeResourceTypeGroupAndResourceTypeList()
		{
			List<RequestTypeResourceTypeGroup_WS> requestTypeResourceTypeGroupList = new List<RequestTypeResourceTypeGroup_WS>();

			List<OpenRequestQueue> orq = new List<OpenRequestQueue>();
			orq = OpenRequestQueue.FindWorkListQueueForGrid(ExtensionMethods.GetCurrentUserQid(), null, null, null, null, null);

			var distinctOrq = orq.Select(x => x.RequestTypeResourceTypeGroupId).Distinct();

			string RequestTypeResourceTypeGroupIds = "";

			foreach (var item in distinctOrq)
			{
				RequestTypeResourceTypeGroupIds += item.ToString() + ",";
			}

			if (RequestTypeResourceTypeGroupIds != "")
			{
				string sqlQuery = string.Format(@"SELECT DISTINCT RTRG.RequestTypeResourceTypeGroupId, RTRG.GroupDescription, RT.ResourceTypeId, CASE WHEN XREF.RequestTypeId = 5 THEN 'Proposal ' + RT.Name ELSE RT.Name END AS Name
																					FROM dbo.RequestTypeResourceTypeGroup RTRG
																					INNER JOIN RequestTypeResourceTypeGroupOpenRequestQueue_XREF XREF ON RTRG.RequestTypeResourceTypeGroupId = XREF.RequestTypeResourceTypeGroupId
																					INNER JOIN dbo.ResourceType RT ON XREF.ResourceTypeId = RT.ResourceTypeId
																					WHERE   RTRG.RequestTypeResourceTypeGroupId IN ({0})
																					ORDER BY RTRG.GroupDescription ,Name", RequestTypeResourceTypeGroupIds.Substring(0, RequestTypeResourceTypeGroupIds.Length - 1));


				using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery, null))
				{
					try
					{
						while (dr.Read())
						{
							int groupId = DbSafe.Int(dr["RequestTypeResourceTypeGroupId"]);
							var group = requestTypeResourceTypeGroupList.Where(o => o.GroupId == groupId).FirstOrDefault();
							if (group == null)
							{
								group = new RequestTypeResourceTypeGroup_WS(groupId, DbSafe.StringValue(dr["GroupDescription"]));
								requestTypeResourceTypeGroupList.Add(group);
							}

							group.ResourceTypeList.Add(new KeyValue_WS(DbSafe.Int(dr["ResourceTypeId"]), DbSafe.StringValue(dr["Name"])));
						}
					}
					finally { dr.Close(); }
				}
			}
			return requestTypeResourceTypeGroupList;
		}

		public List<ResourceSearchCriteria_WS> GetResourceSearchCriteria(int resourceGroupId)
		{
			return models.SearchCriteriaSetup.GetSearchCriteriaSetup(resourceGroupId);
		}

		public List<ResourceSearchCriteria_WS> GetResourceSearchCriteriaById(int[] resourceTypeId)
		{
			return models.SearchCriteriaSetup.GetSearchCriteriaSetup(resourceTypeId);
		}

		public List<LabelValue_WS> GetSmartSearchLookupListForDelegateResource()
		{
			return models.Resource.GetSmartSearchLookupListForDelegateResource();
		}

		public bool DeleteResourceDelegateList(int[] resourceDelegateIds)
		{
			ResourceDelegate.DeleteAll(string.Format("ResourceDelegateId in ({0})", string.Join(",", resourceDelegateIds.Select(v => v.ToString()).ToArray())));
			return true;
		}

		public JqGridData<DelegateResourceRowData, ResourceDelegate, GridRowCommonData> GetDelegatedResourceList()
		{
			return new JqGridData<DelegateResourceRowData, ResourceDelegate, GridRowCommonData>(models.ResourceDelegate.GetDelegatedResourceList(), DelegateResourceRowData.Create);
		}

		public ExecutionAndValidationStatus_WS<string> CreateDelegation(int originalManagerResourceId, int delegateManagerResourceId, string StartDate, string StopDate)
		{
			ExecutionAndValidationStatus_WS<string> result = new ExecutionAndValidationStatus_WS<string>();
			DateTime? startDate = StartDate.ToDateFromQDateString();
			DateTime? stopDate = StopDate.ToDateFromQDateString();

			if (!startDate.HasValue)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", Resources.StartDateIsBlank, MessageType_E.Error));
			}
			else if (stopDate.HasValue && startDate.GetValueOrDefault() > (stopDate.GetValueOrDefault()).AddDays(-1))
			{
				result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", Resources.StartDateGreaterThanStopDate, MessageType_E.Error));
				result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStopDate", Resources.StartDateGreaterThanStopDate, MessageType_E.Error));
			}
			else if (startDate.GetValueOrDefault() <= DateTime.Today)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", Resources.StartDateShouldBeGreaterThanToday, MessageType_E.Error));
			}

			IList<ResourceDelegate> ird;

			if (StopDate == null || StopDate == string.Empty)
			{
				ird = models.ResourceDelegate.GetDelegationStartDateInRange(originalManagerResourceId, startDate.GetValueOrDefault());
				if (ird.Count() > 0)
				{
					ResourceDelegate rd = (ResourceDelegate)ird[0];
					models.Resource r = models.Resource.Find(rd.DelegateManagerResourceId);

					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", string.Format(Resources.StartDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
				}

				ird = models.ResourceDelegate.GetDelegationStartDateInRange(delegateManagerResourceId, startDate.GetValueOrDefault());
				if (ird.Count() > 0)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", Resources.StartDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStopDate", Resources.StopDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
				}
			}
			else
			{
				ird = models.ResourceDelegate.GetDelegationInRange(originalManagerResourceId, startDate.GetValueOrDefault());
				if (ird.Count() > 0)
				{
					ResourceDelegate rd = (ResourceDelegate)ird[0];
					models.Resource r = models.Resource.Find(rd.DelegateManagerResourceId);
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", string.Format(Resources.StartDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
				}
				ird = models.ResourceDelegate.GetDelegationInRange(originalManagerResourceId, stopDate);
				if (ird.Count() > 0)
				{
					ResourceDelegate rd = (ResourceDelegate)ird[0];
					models.Resource r = models.Resource.Find(rd.DelegateManagerResourceId);
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStopDate", string.Format(Resources.StopDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
				}
				ird = models.ResourceDelegate.GetDelegationStartDateStopDateIncludeRange(originalManagerResourceId, startDate.GetValueOrDefault(), stopDate);
				if (ird.Count() > 0)
				{
					ResourceDelegate rd = (ResourceDelegate)ird[0];
					models.Resource r = models.Resource.Find(rd.DelegateManagerResourceId);
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", string.Format(Resources.StartDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStopDate", string.Format(Resources.StartDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
				}


				ird = models.ResourceDelegate.GetDelegationInRange(delegateManagerResourceId, startDate.GetValueOrDefault());
				if (ird.Count() > 0)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", Resources.StartDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
				}

				ird = models.ResourceDelegate.GetDelegationInRange(delegateManagerResourceId, stopDate);
				if (ird.Count() > 0)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStopDate", Resources.StopDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
				}

				ird = models.ResourceDelegate.GetDelegationStartDateStopDateIncludeRange(delegateManagerResourceId, startDate.GetValueOrDefault(), stopDate);
				if (ird.Count() > 0)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStartDate", Resources.StartDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
					result.ValidationErrors.Add(new ValidationMessage_WS("#txtDelegateStopDate", Resources.StopDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
				}
			}


			if (originalManagerResourceId <= 0)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS("[id$=txtCurrentLineManager]", Resources.OriginalManagerIsRequired, MessageType_E.Error));
			}

			if (delegateManagerResourceId <= 0)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS("[id$=txtDelegatedLineManager]", Resources.DelegateManagerIsRequired, MessageType_E.Error));
			}

			if (originalManagerResourceId == delegateManagerResourceId)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS("[id$=txtDelegatedLineManager]", Resources.OriginamManagerIsDelegateManager, MessageType_E.Error));
			}

			string message;

			if (result.ValidationErrors.Count == 0 && !models.ResourceDelegate.CreateDelegation(originalManagerResourceId, delegateManagerResourceId, startDate.GetValueOrDefault(), stopDate, out message))
			{
				result.ValidationErrors.Add(new ValidationMessage_WS("[id$=txtCurrentLineManager]", message, MessageType_E.GridIcon));
			}
			return result;
		}

		public ExecutionAndValidationStatus_WS<SubmittedDelegationRowResponse> UpdateDelegation(int id, string oper, int DelegateManagerResourceId, string DelegateManager, string StartDate, string StopDate)
		{
			//ExecutionAndValidationStatus_WS<string> result = new ExecutionAndValidationStatus_WS<string>();

			ExecutionAndValidationStatus_WS<SubmittedDelegationRowResponse> result = new ExecutionAndValidationStatus_WS
							<SubmittedDelegationRowResponse>
			{
				RequestExecutionStatus =
												new List
												<
												ExecutionStatus_WS
												<SubmittedDelegationRowResponse>>(),
				ValidationErrors =
												new List<ValidationMessage_WS>()
			};

			DateTime? startDate = StartDate.ToDateFromQDateString();
			DateTime? stopDate = StopDate.ToDateFromQDateString();


			if (!startDate.HasValue)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), Resources.StartDateIsBlank, MessageType_E.Error));
			}
			else if (stopDate.HasValue && startDate.GetValueOrDefault() > (stopDate.GetValueOrDefault()).AddDays(-1))
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), Resources.StartDateGreaterThanStopDate, MessageType_E.Error));
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StopDate", id), Resources.StartDateGreaterThanStopDate, MessageType_E.Error));
			}
			else if ((StartDate != ResourceDelegate.Find(id).StartDate.ToQDateString()) && (startDate.GetValueOrDefault() <= DateTime.Today))
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), Resources.StartDateShouldBeGreaterThanToday, MessageType_E.Error));
			}

			var cRd = ResourceDelegate.Find(id);
			if (cRd.OriginalManagerResourceId == DelegateManagerResourceId)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_DelegateManager", id), Resources.OriginamManagerIsDelegateManager, MessageType_E.Error));
			}

			IList<ResourceDelegate> ird;

			if (StopDate == null || StopDate == string.Empty)
			{
				ird = models.ResourceDelegate.GetDelegationStartDateInRangeAndId(id, cRd.OriginalManagerResourceId, startDate.GetValueOrDefault());

				if (ird.Count() > 0)
				{
					ResourceDelegate rd = (ResourceDelegate)ird[0];
					models.Resource r = models.Resource.Find(rd.DelegateManagerResourceId);

					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), string.Format(Resources.StartDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
				}

				ird = models.ResourceDelegate.GetDelegationStartDateInRangeAndId(id, DelegateManagerResourceId, startDate.GetValueOrDefault());
				if (ird.Count() > 0)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), Resources.StartDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StopDate", id), Resources.StopDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
				}
			}
			else
			{
				ird = models.ResourceDelegate.GetDelegationInRangeAndId(id, cRd.OriginalManagerResourceId, startDate.GetValueOrDefault());
				if (ird.Count() > 0)
				{
					ResourceDelegate rd = (ResourceDelegate)ird[0];
					models.Resource r = models.Resource.Find(rd.DelegateManagerResourceId);
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), string.Format(Resources.StartDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
				}
				ird = models.ResourceDelegate.GetDelegationInRangeAndId(id, cRd.OriginalManagerResourceId, stopDate);
				if (ird.Count() > 0)
				{
					ResourceDelegate rd = (ResourceDelegate)ird[0];
					models.Resource r = models.Resource.Find(rd.DelegateManagerResourceId);
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StopDate", id), string.Format(Resources.StopDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
				}
				ird = models.ResourceDelegate.GetDelegationStartDateStopDateIncludeRangeAndId(id, cRd.OriginalManagerResourceId, startDate.GetValueOrDefault(), stopDate);
				if (ird.Count() > 0)
				{
					ResourceDelegate rd = (ResourceDelegate)ird[0];
					models.Resource r = models.Resource.Find(rd.DelegateManagerResourceId);
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), string.Format(Resources.StartDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StopDate", id), string.Format(Resources.StartDateInDurationOfExistedDelegationOfCurrentManager, r.Name), MessageType_E.Error));
				}


				ird = models.ResourceDelegate.GetDelegationInRangeAndId(id, DelegateManagerResourceId, startDate.GetValueOrDefault());
				if (ird.Count() > 0)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), Resources.StartDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
				}

				ird = models.ResourceDelegate.GetDelegationInRangeAndId(id, DelegateManagerResourceId, stopDate);
				if (ird.Count() > 0)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StopDate", id), Resources.StopDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
				}

				ird = models.ResourceDelegate.GetDelegationStartDateStopDateIncludeRangeAndId(id, DelegateManagerResourceId, startDate.GetValueOrDefault(), stopDate);
				if (ird.Count() > 0)
				{
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StartDate", id), Resources.StartDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
					result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_StopDate", id), Resources.StopDateInDurationOfExistedDelegationOfDelegatedManager, MessageType_E.Error));
				}
			}

			if (DelegateManagerResourceId <= 0)
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_DelegateManager", id), Resources.DelegateManagerIsRequired, MessageType_E.Error));
			}
			string message;

			if (result.ValidationErrors.Count == 0 && !models.ResourceDelegate.UpdateDelegation(id, DelegateManagerResourceId, DelegateManager, startDate.GetValueOrDefault(), stopDate, out message))
			{
				result.ValidationErrors.Add(new ValidationMessage_WS(string.Format("#{0}_DelegateManager", id), message, MessageType_E.GridIcon));
			}

			var rds = ResourceDelegate.Find(id);

			//Return an object that contains the updated dateValue, dateValue, and Id
			var response = new SubmittedDelegationRowResponse
			{
				RowId = rds.Id.ToString(),
				StartDateQ = rds.StartDate.ToQDateString(),
				StopDateQ = rds.StopDate.ToQDateString(),
				DelegatedManagerResourceIdQ = rds.DelegateManagerResourceId,
				DelegatedManagerNameQ = rds.DelegateManagerName
			};
			result.RequestExecutionStatus.Add(new ExecutionStatus_WS<SubmittedDelegationRowResponse> { AdditionalData = response });
			return result;
		}

		//bjl 4860
		public string TerminateSpecialAssignment(string assignmentIds)
		{
			try
			{
				SpecialAssignment.TerminateAssignments(assignmentIds);
				return "Success";
			}
			catch (Exception e)
			{ return "Failed"; }

		}

		internal static Dictionary<int, ProjectProgramAssignmentStatus> GetProjectAndProgramAssignmentStatusByRequestAndResourceIds(List<int> requestIdList, List<int> resourceIdList)
		{
			var assignmentData = new Dictionary<int, ProjectProgramAssignmentStatus>();
			using (var dr = DbHelp.ExecuteDataReaderSP("GetProjectAndProgramAssignmentStatusByRequestAndResourceIds", DbHelp.GetIdTableTypeParameter("requestIdList", requestIdList), DbHelp.GetIdTableTypeParameter("resourceIdList", resourceIdList)))
			{
				try
				{
					while (dr.Read())
					{
						int resourceId = DbSafe.Int(dr["ResourceId"]);
						if (!assignmentData.ContainsKey(resourceId))
						{
							assignmentData.Add(resourceId, new ProjectProgramAssignmentStatus(DbSafe.Bool(dr["ProjectMatch"]), DbSafe.Bool(dr["ProgrmMatch"])));
						}
					}

				}
				finally { dr.Close(); }
			}

			return assignmentData;
		}

		internal static Dictionary<int, List<ProjectFireWallStatus>> GetProjectFireWallStatusByProjectAndResourceIds(List<int> projectIdList, List<int> resourceIdList)
		{
			System.Collections.Specialized.NameValueCollection myCollection = new System.Collections.Specialized.NameValueCollection();

			var assignmentData = new Dictionary<int, List<ProjectFireWallStatus>>();

			using (var dr = DbHelp.ExecuteDataReaderSP("GetProjectFireWallStatusByProjectAndResourceIds", DbHelp.GetIdTableTypeParameter("projectIdList", projectIdList), DbHelp.GetIdTableTypeParameter("resourceIdList", resourceIdList)))
			{
				try
				{
					List<ProjectFireWallStatus> projectFireWallStatusList;
					while (dr.Read())
					{
						int resourceId = DbSafe.Int(dr["ResourceId"]);
						if (!assignmentData.TryGetValue(resourceId, out projectFireWallStatusList))
						{
							assignmentData.Add(resourceId, new List<ProjectFireWallStatus>());
						}
						assignmentData[resourceId].Add(new ProjectFireWallStatus()
						{
							ProjectCode = DbSafe.StringValue(dr["ProjectCode"]),
							ProtocolNumber = DbSafe.StringValue(dr["ProtocolNumber"]),
							ResourceTypeName = DbSafe.StringValue(dr["ResourceType"]),
							JobRoleName = DbSafe.StringValue(dr["JobRole"]),
							StartDate = DbSafe.DateTime(dr["StartDate"]).ToString("dd-MMM-yyyy"),
							StopDate = DbSafe.DateTime(dr["StopDate"]).ToString("dd-MMM-yyyy")
						});
					}
				}
				finally { dr.Close(); }
			}
			return assignmentData;
		}



		internal static Dictionary<int, ProgramStudyStatus> GetProgramBlindedUnblindedStatusByRequestAndResourceIds(List<int> requestIdList, List<int> resourceIdList)
		{
			var assignmentData = new Dictionary<int, ProgramStudyStatus>();
			using (var dr = DbHelp.ExecuteDataReaderSP("GetProgramBlindedUnblindedStatusByRequestAndResourceIds", DbHelp.GetIdTableTypeParameter("requestIdList", requestIdList), DbHelp.GetIdTableTypeParameter("resourceIdList", resourceIdList)))
			{
				try
				{
					while (dr.Read())
					{
						int resourceId = DbSafe.Int(dr["ResourceId"]);
						if (!assignmentData.ContainsKey(resourceId))
						{
							assignmentData.Add(resourceId, new ProgramStudyStatus(DbSafe.Int(dr["ProgramUnblinded"])));
						}
					}
				}
				finally { dr.Close(); }
			}

			return assignmentData;
		}

		public ResourceConfiguration_WS GetResourceConfiguration(int resourceId)
		{
			return models.Resource.GetResourceConfiguration(resourceId);
		}

		public EditMultipleResourceStatus_WS UpdateResourceConfiguration(List<int> resourceIdList, int? organizationalUnitId, int? primaryJobRole, List<ResourceableResourceType_WS> resourceableResourceTypeList, bool isResourcedInRm, int? competencyBandId, int? workCountryId, List<ResourceTmfPlatform_WS> tmfPlatformDetails, bool hasResourceableResourceTypes,string preferredSponsor)
		{
			return models.Resource.UpdateResourceConfiguration(resourceIdList, organizationalUnitId, primaryJobRole, resourceableResourceTypeList, isResourcedInRm, competencyBandId, workCountryId, tmfPlatformDetails, hasResourceableResourceTypes,preferredSponsor);
		}

		public List<Resource_WS> GetFulfillableResourcesByResourceTypeId(int resourceTypeId)
		{
			return models.Resource.GetFulfillableResourcesByResourceTypeId(resourceTypeId);
		}

		public List<ValueId_WS> GetAllFulfillableResourcesByResourceTypeIdForAssignment(int resourceTypeId)
		{
			return models.Resource.GetFulfillableResourcesByResourceTypeIdForAssignment(resourceTypeId, false);
		}
		public List<ValueId_WS> GetFulfillableResourcesByResourceTypeIdForAssignment(int resourceTypeId)
		{
			return models.Resource.GetFulfillableResourcesByResourceTypeIdForAssignment(resourceTypeId, true);
		}

		public List<DefaultMiltestones> GetResourceTypeDefaultMilestonesByResourceTypeId(string resourceTypeId)
		{
			List<DefaultMiltestones> lstDefaultMiltestones = new List<DefaultMiltestones>();

			if (!string.IsNullOrEmpty(resourceTypeId))
			{
				string sqlQuery = string.Format(@"Select ResourceTypeDefaultMilestonesId, DefaultFromMilestoneId, DefaultToMilestoneId 
                                                  From ResourceTypeDefaultMilestones Where ResourceTypeid = {0}", resourceTypeId);

				using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery, null))
				{
					try
					{
						while (dr.Read())
						{
							lstDefaultMiltestones.Add(new DefaultMiltestones
							{
								ResourceTypeDefaultMilestonesId = (int)dr["ResourceTypeDefaultMilestonesId"],
								DefaultFromMilestoneId = (int)dr["DefaultFromMilestoneId"],
								DefaultToMilestoneId = (int)dr["DefaultToMilestoneId"]
							});
						}
					}
					finally { dr.Close(); }
				}
			}
			return lstDefaultMiltestones;
		}

		public List<CountryResourceTypeWithSpecialResourcingNeed_WS> GetResourcableResourcesForSpecialResourcingNeed()
		{
			return CountryResourceTypeWithSpecialResourcingNeed.GetResourcableResourcesForSpecialResourcingNeed();
		}
		public ResourceDetails_WS GetResourceDetailsByResourceId(int resourceId)
		{
			return models.Resource.GetResourceDetailsByResourceId(resourceId);
		}
	}
}