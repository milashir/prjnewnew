﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using models = Quintiles.RM.Clinical.Domain.Models;


namespace Quintiles.RM.Clinical.SharePoint
{
	[DataContract]
	public class ResSched_WS
	{
		[DataMember]
		public int ResID;
		[DataMember]
		public decimal TargetUtil; //ReqMonthlyHours_WS[] RequestSched; // Requests

		[DataMember]
		public decimal[] FullTimeWorkingHours;

		[DataMember]
		public decimal[] Availability;
		[DataMember]
		public decimal[] Mismatch;

		[DataMember]
		public decimal[] SpecialAssignment;
		[DataMember]
		public decimal[] Avt;

		[DataMember]
		public decimal[] SoftBookProposal;
		[DataMember]
		public decimal[] SoftBook;
		[DataMember] // resource.ParentRequestId, -- Exists=Child Backfill
		public decimal[] SoftBookPermanentBackfill; // resource.BackFillTypeId, -- 1=Permanent, 2=Temporary
		[DataMember]
		public decimal[] SoftBookTemporaryBackfill; // resource.BackfillPercent, -- Use 100-BackfillPercent in case ParentRequestId exists

		[DataMember]
		public decimal[] HardBookProposal;
		[DataMember]
		public decimal[] HardBook;
		[DataMember] // resource.ParentRequestId, -- Exists=Child Backfill
		public decimal[] HardBookPermanentBackfill; // resource.BackFillTypeId, -- 1=Permanent, 2=Temporary
		[DataMember]
		public decimal[] HardBookTemporaryBackfill; // resource.BackfillPercent, -- Use 100-BackfillPercent in case ParentRequestId exists
		[DataMember]
		public bool AreAllRequestsBad;
		[DataMember]
		public string ResourceName;
		[DataMember]
		public ResReqErrors_WS[] ResReqErrors;

		public ResSched_WS(ResourceCalendar resCalendar, int countMonth)
		{
			ResID = resCalendar.ResourceID;
			TargetUtil = resCalendar.TargetUtilization;

			FullTimeWorkingHours = new decimal[countMonth];

			Availability = new decimal[countMonth];
			Mismatch = new decimal[countMonth];

			Avt = new decimal[countMonth];
			SpecialAssignment = new decimal[countMonth];

			//CurrentWorkingHours = new decimal[countMonth];
			SoftBook = new decimal[countMonth];
			SoftBookPermanentBackfill = new decimal[countMonth];
			SoftBookProposal = new decimal[countMonth];
			SoftBookTemporaryBackfill = new decimal[countMonth];

			HardBook = new decimal[countMonth];
			HardBookPermanentBackfill = new decimal[countMonth];
			HardBookProposal = new decimal[countMonth];
			HardBookTemporaryBackfill = new decimal[countMonth];
		}
	}

	[DataContract]
	public class ResListSched_WS
	{
		[DataMember]
		public int StartMonth; // Year*12 + Month
		[DataMember]
		public int EndMonth; // Year*12 + Month
		[DataMember]
		public ResSched_WS[] ResourcesSched; // Resources
		[DataMember]
		public string ExecutionPath;
	}

	[ServiceContract]
	public interface IResource
	{
		[WebInvoke(Method = "POST",
						UriTemplate = "GetResourcesByCurrentUser",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		models.JqGridData<models.MyStaffDataRow, models.Resource, ResourceCommonData> GetResourcesByCurrentUser(GridSearchResource_WS gridSearch);


		[WebInvoke(Method = "POST",
						UriTemplate = "GetUsers",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<UserPermissionRowData, RmUserTable, GridRowCommonData> GetUsers(GridSearchRmUser_WS gridSearch);

		//SS:QRPM-4881:to get all filtered users for permission
		[WebInvoke(Method = "POST",
						UriTemplate = "GetFilteredUsers",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<RmUserTable> GetFilteredUsers(GridSearchRmUser_WS gridSearch);
		//[WebGet(BodyStyle = WebMessageBodyStyle.Bare,
		//    RequestFormat = WebMessageFormat.Json,
		//    ResponseFormat = WebMessageFormat.Json)]
		//[OperationContract]
		//JqGridData GetUsers(string search, int rows, int page, string sidx, string sord, string qid, string name, // string sord
		//        string jobTitle, string qOffice, string status, string country, string role, string AllowedCountries, string AllowedResTypes);

		[WebInvoke(Method = "POST",
				 UriTemplate = "GetResourceSchedule",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ResListSched_WS GetResourceSchedule(List<int> resourceIdList, int minDate, int maxDate, bool isExecPathRequired, int graphContext);

		[WebInvoke(Method = "POST",
				UriTemplate = "GetMyStaffAssignment",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<ResourceAssignmentRowData, ResourceRequestAssignment, GridRowCommonData> GetMyStaffAssignment(GridSearchMyStaffAssignment_WS gridSearch);

		[WebInvoke(Method = "POST", UriTemplate = "SpecialAssignmentsCalculateFTE",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		decimal SpecialAssignmentsCalculateFTE(int resourceId, string startDate, string endDate, decimal fte);

		[WebInvoke(Method = "POST", UriTemplate = "CreateSpecialAssignment",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<string> CreateSpecialAssignment(SpecialAssignment_WS specialAssignmentDetails);

		[WebInvoke(Method = "POST", UriTemplate = "DeleteSpecialAssignment",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		string DeleteSpecialAssignment(string assignmentIds);

		[WebInvoke(Method = "POST", UriTemplate = "UpdateSpecialAssignment",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<string> UpdateSpecialAssignment(SpecialAssignment_WS specialAssignmentDetails);

		[WebInvoke(Method = "GET",
						UriTemplate = "GetRequestTypeResourceTypeGroupAndResourceTypeList",
						BodyStyle = WebMessageBodyStyle.Bare,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<RequestTypeResourceTypeGroup_WS> GetRequestTypeResourceTypeGroupAndResourceTypeList();

		[WebInvoke(Method = "POST",
										UriTemplate = "GetResourceSearchCriteria",
										BodyStyle = WebMessageBodyStyle.WrappedRequest,
										RequestFormat = WebMessageFormat.Json,
										ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ResourceSearchCriteria_WS> GetResourceSearchCriteria(int resourceGroupId);

		[WebInvoke(Method = "POST",
										UriTemplate = "GetResourceSearchCriteriaById",
										BodyStyle = WebMessageBodyStyle.WrappedRequest,
										RequestFormat = WebMessageFormat.Json,
										ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ResourceSearchCriteria_WS> GetResourceSearchCriteriaById(int[] resourceTypeId);

		[WebInvoke(Method = "GET",
						UriTemplate = "GetSmartSearchLookupListForDelegateResource",
						BodyStyle = WebMessageBodyStyle.Bare,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<LabelValue_WS> GetSmartSearchLookupListForDelegateResource();

		[WebInvoke(Method = "POST", UriTemplate = "CreateDelegation",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<string> CreateDelegation(int originalManagerResourceId, int delegateManagerResourceId, string StartDate, string StopDate);

		[WebInvoke(Method = "POST", UriTemplate = "DeleteResourceDelegateList",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		bool DeleteResourceDelegateList(int[] resourceDelegateIds);

		[WebInvoke(Method = "POST", UriTemplate = "GetDelegatedResourceList",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		JqGridData<DelegateResourceRowData, ResourceDelegate, GridRowCommonData> GetDelegatedResourceList();

		[WebInvoke(Method = "POST",
				UriTemplate = "UpdateDelegation",
				BodyStyle = WebMessageBodyStyle.WrappedRequest,
				RequestFormat = WebMessageFormat.Json,
				ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ExecutionAndValidationStatus_WS<SubmittedDelegationRowResponse> UpdateDelegation(int id, string oper, int DelegateManagerResourceId, string DelegateManager, string StartDate, string StopDate);

		[WebInvoke(Method = "POST", UriTemplate = "TerminateSpecialAssignment",
						BodyStyle = WebMessageBodyStyle.WrappedRequest,
						RequestFormat = WebMessageFormat.Json,
						ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		string TerminateSpecialAssignment(string assignmentIds);

		[WebInvoke(Method = "POST", UriTemplate = "GetResourceConfiguration", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ResourceConfiguration_WS GetResourceConfiguration(int resourceId);

		[WebInvoke(Method = "POST", UriTemplate = "UpdateResourceConfiguration", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		EditMultipleResourceStatus_WS UpdateResourceConfiguration(List<int> resourceIdList, int? organizationalUnitId, int? primaryJobRole, List<ResourceableResourceType_WS> resourceableResourceTypeList, bool isResourcedInRm, int? competencyBandId, int? workCountryId, List<ResourceTmfPlatform_WS> tmfPlatformDetails, bool hasResourceableResourceTypes,string preferredSponsor);

		[WebInvoke(Method = "POST", UriTemplate = "GetFulfillableResourcesByResourceTypeId", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<Resource_WS> GetFulfillableResourcesByResourceTypeId(int resourceTypeId);

		[WebInvoke(Method = "POST", UriTemplate = "GetAllFulfillableResourcesByResourceTypeIdForAssignment", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ValueId_WS> GetAllFulfillableResourcesByResourceTypeIdForAssignment(int resourceTypeId);

		[WebInvoke(Method = "POST", UriTemplate = "GetFulfillableResourcesByResourceTypeIdForAssignment", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<ValueId_WS> GetFulfillableResourcesByResourceTypeIdForAssignment(int resourceTypeId);

		[WebInvoke(Method = "POST", UriTemplate = "GetResourceTypeDefaultMilestonesByResourceTypeId", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<DefaultMiltestones> GetResourceTypeDefaultMilestonesByResourceTypeId(string resourceTypeId);

		[WebInvoke(Method = "POST", UriTemplate = "GetResourcableResourcesForSpecialResourcingNeed", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		List<CountryResourceTypeWithSpecialResourcingNeed_WS> GetResourcableResourcesForSpecialResourcingNeed();

		[WebInvoke(Method = "POST", UriTemplate = "GetResourceDetailsByResourceId", BodyStyle = WebMessageBodyStyle.WrappedRequest, ResponseFormat = WebMessageFormat.Json)]
		[OperationContract]
		ResourceDetails_WS GetResourceDetailsByResourceId(int resourceId);
	}


	[DataContract]
	public class SubmittedDelegationRowResponse
	{
		[DataMember]
		public String RowId { get; set; }

		[DataMember]
		public String StartDateQ { get; set; }

		[DataMember]
		public String StopDateQ { get; set; }

		[DataMember]
		public int DelegatedManagerResourceIdQ { get; set; }

		[DataMember]
		public String DelegatedManagerNameQ { get; set; }

		[DataMember]
		public String ErrorMessage { get; set; }
	}

}