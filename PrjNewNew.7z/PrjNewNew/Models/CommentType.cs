using System;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum CommentTypeName
	{
		None = 0,
		ResubmitComments = 1,
		BackfillComments = 2,
		ReturnDetails = 3,
		ProposalBidDefense = 4,
		RejectedSoftBook = 5
	}
	[ActiveRecord(Table = "CommentType")]
	public class CommentType : AbstractActiveRecordBaseModel<CommentType>, IComparable<CommentType>, ICodeTable
	{
		[PrimaryKey(Column = "CommentTypeId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }

		#region IComparable<CommentType> Members

		public int CompareTo(CommentType other)
		{
			return this.Name.CompareTo(other.Name);
		}

		#endregion

		internal static CommentType CreateFromReader(System.Data.IDataReader r)
		{
			CommentType ct = null;
			var cc = new ColumnChecker(r);

			if (r != null && cc.HasColumn("CommentTypeId") && !(r["CommentTypeId"] is System.DBNull))
			{
				ct = new CommentType { Id = DbSafe.Int(r["CommentTypeId"]) };
			}

			return ct;
		}

		public static CommentType CommentTypeByEnum(CommentTypeName commentType)
		{
			return CommentTypeName.None.Equals(commentType) ? null : new CommentType { Id = (int)commentType };
		}
	}
}
