﻿//using Quintiles.RM.Clinical.Domain.Models.GridDataManager.DataEngine;
//using Quintiles.RM.Clinical.Domain.Services;

//namespace Quintiles.RM.Clinical.Domain.Models.SiteVisitAttributes
//{
//	public class SiteGridRowData
//	{
//		public string TieringCompletionStatus { get; set; }
//		public string CTMSSiteNumber { get; set; }
//		public string SiteName { get; set; }
//		public string PIName { get; set; }
//		public string Country { get; set; }
//		public string FsiLisTier { get; set; }
//		public string LsiCovTier { get; set; }
//		public string PharmacyTier { get; set; }
//		public string GeneralComments { get; set; }
//		public string TierChangeHistory { get; set; }

//		public static PagedResponse<SiteGridRowData, AttributeCommonData> FindAllSiteList(GridSearchSitelist_WS gridSearch)
//		{
//			return new SiteListRequestGridDataEngine(gridSearch).GetDataForGrid();
//		}
//	}
//}
