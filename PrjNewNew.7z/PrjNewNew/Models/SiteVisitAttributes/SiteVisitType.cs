using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	/*
	 * DisplayVisitType = 0 and 1-->has data pertain to RM application.
	   RM = 1 -->    has data pertain to RM application.
	 
	 */

	[ActiveRecord(Table = "SiteVisitType")]
	public class SiteVisitType : AbstractActiveRecordBaseModel<SiteVisitType>
	{

		[PrimaryKey(Column = "SiteVisitTypeId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		public SiteVisitType_E SiteVisitTypeEnum { get { return (SiteVisitType_E)Id; } }

		[Property(Column = "Name")]
		public string Name { set; get; }

		[Property]
		public virtual string AlternateName { set; get; }

		[Property]
		public virtual int IsCTMS { set; get; }

		[Property]
		public virtual int IsInnTrax { set; get; }

		[Property]
		public int IsActive { set; get; }

		[Property]
		public bool IsCoMonitoring { set; get; }

		[Property]
		public bool IsOnsiteVisit { set; get; }
		[Property]
		public bool IsRemoteVisit { set; get; }
		[Property]
		public bool IsSivVisit { set; get; }
		[Property]
		public bool IsCovVisit { set; get; }
		[Property]
		public bool IsSsvVisit { set; get; }
		[Property]
		public bool PreventVisitPatternReset { set; get; }
		[Property]
		public bool IsImvVisit { set; get; }
		[Property]
		public bool IsPharmacyVisit { set; get; }
		[Property]
		public bool IsImvVisitForVisitCount { set; get; }
		[Property]
		public bool IsRmProjectedVisit { set; get; }
		[Property]
		public bool IsOnsiteVisitForSpecialCase { set; get; }
		[Property]	
		public bool PreventVisitPatternResetForSpecialCase { set; get; }
		public bool IsImvDependentVisit { get { return !IsSivVisit && !IsCovVisit && !IsSsvVisit; } }

		/// <summary>
		/// Consider additional check for PreventVisitPatternReset if training booster visits are not needed
		/// </summary>
		public bool IsOnsiteInterimMonitoringVisit { get { return IsOnsiteVisit && !IsSivVisit && !IsCovVisit && !IsSsvVisit && !IsPharmacyVisit; } }
		public bool IsPharmacyMonitoringVisit { get { return IsOnsiteVisit && !IsSivVisit && !IsCovVisit && !IsSsvVisit && IsPharmacyVisit; } }

		public static SiteVisitType FindByEnum(SiteVisitType_E enumValue)
		{
			return SiteVisitType.Find((int)enumValue);
		}

		internal static SiteVisitType CreateFromReader(System.Data.IDataReader r)
		{
			SiteVisitType svt = null;
			var cc = new ColumnChecker(r);

			if (r != null && cc.HasColumn("SiteVisitTypeId") && !(r["SiteVisitTypeId"] is System.DBNull))
			{
				svt = CacheService.SiteVisitTypes[DbSafe.Int(r["SiteVisitTypeId"])];
			}
			return svt;
		}

		public static bool IsImvDependentVisitType(SiteVisitType_E visitType)
		{
			SiteVisitType siteVisitType;
			if (CacheService.SiteVisitTypes.TryGetValue((int)visitType, out siteVisitType)) { return siteVisitType.IsImvDependentVisit; }
			else { return false; }
		}
	}
}
