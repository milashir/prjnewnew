﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Models.DTE;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class MonitoringAttribute : AbstractActiveRecordBaseModel<MonitoringAttribute>, ICountryAttribute
	{
		#region Mapped properties
		[PrimaryKey(Column = "MonitoringAttributeId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int CountryId { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public virtual int? BudgetedSites { get; set; }

		[Property]
		public virtual DateTime? CRATrainingDate { get; set; }

		[Property]
		public virtual DateTime? StartDate { get; set; }

		[Property]
		public virtual DateTime? StartDateActual { get; set; }

		[Property]
		public virtual DateTime? StopDate { get; set; }

		[Property]
		public virtual DateTime? StopDateActual { get; set; }

		[Property]
		public virtual DateTime? IMDate { get; set; }

		[Property]
		public virtual int IsActive { get; set; }

		[Property]
		public virtual DateTime? SIVFirstLastActualFinish { get; set; }

		[Property]
		public virtual DateTime? SIVFirstLastProjectedFinish { get; set; }

		[Property]
		public int? QipBudgetedSitesConnectedValue { get; set; }
		[Property]
		public int? QipBudgetedSites { get; set; }
		[Property]
		public bool? IsQipBudgetedSitesConnected { get; set; }

		[Property]
		public int? QipBudgetedRemoteVisitCount { get; set; }
		[Property]
		public int? QipBudgetedRemoteVisitCountConnectedValue { get; set; }
		[Property]
		public bool? IsQipBudgetedRemoteVisitCountConnected { get; set; }

		[Property]
		public int? QipBudgetedOnsiteImvVisitCount { get; set; }
		[Property]
		public int? QipBudgetedOnsiteImvVisitCountConnectedValue { get; set; }
		[Property]
		public bool? IsQipBudgetedOnsiteImvVisitCountConnected { get; set; }

		[Property]
		public int? QipBudgetedPharmacyVisitCount { get; set; }
		[Property]
		public int? QipBudgetedPharmacyVisitCountConnectedValue { get; set; }
		[Property]
		public bool? IsQipBudgetedPharmacyVisitCountConnected { get; set; }

		[Property]
		public int? QipBudgetedOnsiteVisitCount { get; set; }
		[Property]
		public int? ProjectedOnsiteVisitCount { get; set; }
		[Property]
		public int? ProjectedRemoteVisitCount { get; set; }
		[Property]
		public int? ProjectedPharmacyVisitCount { get; set; }
		[Property]
		public int? BudgetedBoosterVisitCount { get; set; }
		[Property]
		public int? BudgetedBoosterVisitCountConnectedValue { get; set; }
		[Property]
		public bool? IsBudgetedBoosterVisitCountConnected { get; set; }


		[Property]
		public int? QipBudgetedSivVisitCount { get; set; }
		[Property]
		public int? QipBudgetedCovVisitCount { get; set; }

		[Property]
		public int? ProjectedOnsiteImvVisitCount { get; set; }
		[Property]
		public int? ProjectedSivVisitCount { get; set; }
		[Property]
		public int? ProjectedCovVisitCount { get; set; }

		#endregion

		#region Unmapped properties
		private bool? _hasPharmacyCalculator = null;
		public bool HasPharmacyCalculator
		{
			get
			{
				if (!_hasPharmacyCalculator.HasValue)
				{
					var sql = string.Format(@"SELECT COUNT(1) FROM dbo.TFTECalculator
																		WHERE MonitoringAttributeId={0} AND CalculatorTypeId IN ({1}, {2}) AND RequestId IS NULL",
																		Id,
																		(int)CalculatorGroup_E.DTEPharmacyCalculator,
																		(int)CalculatorGroup_E.PharmacyCalculator);
					_hasPharmacyCalculator = DbSafe.Bool(DbHelp.ExecuteScalarText(sql));
				}
				return _hasPharmacyCalculator.GetValueOrDefault();
			}
		}

		public int? QipBudgetedVisits
		{
			get { return QipBudgetedOnsiteVisitCount + QipBudgetedRemoteVisitCount + QipBudgetedPharmacyVisitCount; }
		}

		public bool HasNotes { get; set; }
		private Country _country = null;
		public Country Country
		{
			get
			{
				if (_country == null)
				{
					_country = CacheService.Country(CountryId);
				}
				return _country;
			}
		}

		internal static List<string> FindAllWithNullBudgetedSiteCount(int projectId)
		{
			var attributes = FindAll(DetachedCriteria.For<MonitoringAttribute>()
						.Add(Expression.Eq("ProjectId", projectId))
						.Add(Expression.IsNull("BudgetedSites")));

			return attributes.Select(a => a.Country.CTMSCountryName).ToList();
		}

		private Project _project = null;
		public Project Project
		{
			get
			{
				if (_project == null)
				{
					_project = models.Project.Find(ProjectId);
				}
				return _project;
			}
			set { _project = value; }
		}

		public DateTime? SiteCOVDate
		{
			get
			{
				return StopDateActual.HasValue ? StopDateActual : StopDate;
			}
		}
		public DateTime? MonitoringAttributeStartDate
		{
			get
			{
				return StartDateActual.HasValue ? StartDateActual : StartDate;//Start Date is StartDateProjectedDate
			}
		}
		//MonitoringAttributeStopDate is same as SiteCOVDate
		public DateTime? MonitoringAttributeStopDate
		{
			get
			{
				return StopDateActual.HasValue ? StopDateActual : StopDate;
			}
		}
		public DateTime? SIVFirstLastFinishDate
		{
			get
			{
				return SIVFirstLastActualFinish.HasValue ? SIVFirstLastActualFinish : SIVFirstLastProjectedFinish;
			}
		}

		private List<int> _monitoringCalculatorTypeId = null;
		public List<int> monitoringCalculatorTypeId
		{
			get
			{
				if (_monitoringCalculatorTypeId == null)
				{
					_monitoringCalculatorTypeId = Init(string.Format("SELECT FTETypeId FROM dbo.CalculatorTFTEType_XREF WHERE CalculatorTypeId = {0}", (int)CalculatorGroup_E.MonitoringCalculator));

				}
				return _monitoringCalculatorTypeId;
			}
			set { _monitoringCalculatorTypeId = value; }
		}
		public List<int> dteMonitoringCalculatorTypeId
		{
			get
			{
				if (_monitoringCalculatorTypeId == null)
				{
					_monitoringCalculatorTypeId = Init(string.Format("SELECT FTETypeId FROM dbo.CalculatorTFTEType_XREF WHERE CalculatorTypeId = {0}", (int)CalculatorGroup_E.DTEMonitoringCalculator));

				}
				return _monitoringCalculatorTypeId;
			}
			set { _monitoringCalculatorTypeId = value; }
		}

		private List<int> _pharmacyCalculatorTypeId = null;
		public List<int> pharmacyCalculatorTypeId
		{
			get
			{
				if (_pharmacyCalculatorTypeId == null)
				{
					_pharmacyCalculatorTypeId = Init(string.Format("SELECT FTETypeId FROM dbo.CalculatorTFTEType_XREF WHERE CalculatorTypeId = {0}", (int)CalculatorGroup_E.PharmacyCalculator));

				}
				return _pharmacyCalculatorTypeId;
			}
			set { _pharmacyCalculatorTypeId = value; }
		}

		private List<int> _iCRACalculatorTypeId = null;
		public List<int> iCRACalculatorTypeId
		{
			get
			{
				if (_iCRACalculatorTypeId == null)
				{
					_iCRACalculatorTypeId = Init(string.Format("SELECT FTETypeId FROM dbo.CalculatorTFTEType_XREF WHERE CalculatorTypeId = {0}", (int)CalculatorGroup_E.ICraCalculator));

				}
				return _iCRACalculatorTypeId;
			}
			set { _iCRACalculatorTypeId = value; }
		}

		public bool PresentInQip { get; set; }
		public int? ActualActiveSites { get; set; }
		public int? ActualVisits { get; set; }
		public DateTime? ActualStartOrProjectedStart { get { return StartDateActual.HasValue ? StartDateActual : StartDate; } }
		public DateTime? ActualStopOrProjectedStop { get { return StopDateActual.HasValue ? StopDateActual : StopDate; } }
		#endregion

		#region Static Get/Save methods

		/// <summary>
		/// 
		/// </summary>
		/// <param columnName="projectId"></param>
		/// <param columnName="id"></param>
		/// <returns></returns>
		/// <author>Colin Boatwright</author>
		/// <remarks>Updated by Vincent Guilbaud.
		/// TODO: MonitoringAttribute and SSVAttribute should also have common base class (like RequestAttribute)
		/// because they share behaviors & data and have currently duplicate code and are difficult o manupulate in a generic way</remarks>
		public static MonitoringAttribute FindByProjectIdCountryId(int projectId, int? countryId)
		{
			return MonitoringAttribute.FindByProjectIdCountryId(projectId, countryId, true);
		}

		public static MonitoringAttribute FindByProjectIdCountryId(int projectId, int? countryId, bool activeAttributesOnly)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(MonitoringAttribute));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("CountryId", countryId));
			if (activeAttributesOnly)
			{
				criteria.Add(Expression.Eq("IsActive", 1));
			}

			return MonitoringAttribute.FindFirst(criteria);
		}


		public static MonitoringAttribute FindOneByProjectId(int projectId)
		{
			MonitoringAttribute rv = null;

			DetachedCriteria criteria = DetachedCriteria.For(typeof(MonitoringAttribute));
			criteria.Add(Expression.Eq("ProjectId", projectId));

			IList<MonitoringAttribute> result = MonitoringAttribute.FindAll(criteria);
			if (result.Count >= 1)
			{
				rv = result[0];
			}

			return rv;
		}

		public static List<MonitoringAttributeIR_WS> GetMonitoringAttributesForInitiateRequest(int projectId)
		{
			List<MonitoringAttributeIR_WS> monAttrList = new List<MonitoringAttributeIR_WS>();
			IList<MonitoringAttribute> monAttr = FindAllByProjectId(projectId);
			foreach (MonitoringAttribute ma in monAttr)
			{
				monAttrList.Add(new MonitoringAttributeIR_WS(ma));
			}
			return monAttrList;
		}

		#endregion

		#region FindAllPagedMonAttributes
		public static PagedResponse<MonitoringAttribute, AttributeCommonData> FindAllPagedMonAttributes(GridSearchAttribute_WS gsr)
		{
			return new MonitoringAttributeGridDataEngine(gsr).GetDataForGrid();
		}
		#endregion

		#region SaveMonitoringAttribute
		public static void SaveMonitoringAttribute(MonitoringAttribute_WS monAttributeData, VisitCount visitCount)
		{
			DbHelp.ExecuteNonQuerySP("dbo.SaveMonitoringAttr",
				new SqlParameter("@MonitID", monAttributeData.Id),
				new SqlParameter("@CRATraining", string.IsNullOrEmpty(monAttributeData.CRADate) ? (object)DBNull.Value : (object)monAttributeData.CRADate),
				new SqlParameter("@IM", string.IsNullOrEmpty(monAttributeData.IMDate) ? (object)DBNull.Value : (object)monAttributeData.IMDate),
				new SqlParameter("@qID", ExtensionMethods.GetCurrentUserQid()),
				new SqlParameter("@ProjectedOnsiteVisitCount", visitCount == null ? (object)DBNull.Value : (object)visitCount.IntOnsiteImvVisitCount),
				new SqlParameter("@ProjectedRemoteVisitCount", visitCount == null ? (object)DBNull.Value : (object)visitCount.IntRemoteVisitCount),
				new SqlParameter("@ProjectedPharmacyVisitCount", visitCount == null ? (object)DBNull.Value : (object)visitCount.IntPharmacyVisitCount),
				new SqlParameter("@projectedInitiatedSites", monAttributeData.ProjectedInitiatedSites.HasValue ? (object)monAttributeData.ProjectedInitiatedSites : (object)DBNull.Value),
				new SqlParameter("@QipBudgetedSites", monAttributeData.QipBudgetedSites),
				new SqlParameter("@IsQipBudgetedSitesConnected", monAttributeData.IsQipBudgetedSitesConnected),
				new SqlParameter("@QipBudgetedOnsiteImvVisitCount", monAttributeData.QipBudgetedOnsiteImvVisitCount),
				new SqlParameter("@IsQipBudgetedOnsiteImvVisitCountConnected", monAttributeData.IsQipBudgetedOnsiteImvVisitCountConnected),
				new SqlParameter("@QipBudgetedPharmacyVisitCount", monAttributeData.QipBudgetedPharmacyVisitCount),
				new SqlParameter("@IsQipBudgetedPharmacyVisitCountConnected", monAttributeData.IsQipBudgetedPharmacyVisitCountConnected),
				new SqlParameter("@QipBudgetedRemoteVisitCount", monAttributeData.QipBudgetedRemoteVisitCount),
				new SqlParameter("@IsQipBudgetedRemoteVisitCountConnected", monAttributeData.IsQipBudgetedRemoteVisitCountConnected),
				new SqlParameter("@BudgetedBoosterVisitCount", monAttributeData.BudgetedBoosterVisitCount),
				new SqlParameter("@IsBudgetedBoosterVisitCountConnected", monAttributeData.IsBudgetedBoosterVisitCountConnected));
		}
		#endregion

		#region GetNotesColumnValue
		public string GetNotesColumnValue(bool getCommentCountFromDb)
		{
			bool hasNotes = getCommentCountFromDb ? (EntityComment.FindEntityComments(Id, EntityTypes.MonitoringAttribute, false).Count > 0) : HasNotes;

			return string.Format(Constants.MessageDiv,
							hasNotes ? string.Empty : "no_",
							Id,
							(int)SearchLevel.Country,
							EntityTypes.MonitoringAttribute.ToString(), (int)EntityTypes.MonitoringAttribute,
							Country.Name, Country.Id, Country.CountryCode,
							Country.Subregion.Region.Name, Country.Subregion.Region.Id, Country.Subregion.Region.RegionCode,
							ProjectId, Project.ProjectCode,
							Constants.UnspecifiedId, string.Empty,
							Constants.UnspecifiedId, string.Empty,
							string.Empty);
		}
		#endregion

		/// <summary>
		///Sriram:Get Active Countries from Monitoring Attributes .
		///This is used in Assigned country drop down in CRS,Regional CPM
		/// </summary>
		/// <param name="projectId"></param>
		/// <returns></returns>
		public static List<CountryAndRegion_WS> GetActiveCountries(int projectId, string regionIds)
		{
			List<CountryAndRegion_WS> keyValueList = new List<CountryAndRegion_WS>();
			List<MonitoringAttribute> monCountry = new List<MonitoringAttribute>();
			IList<MonitoringAttribute> monAttributeCountries = MonitoringAttribute.FindAllByProjectId(projectId);
			string[] regionId = regionIds.Split(',');

			foreach (var region in regionId)
			{
				foreach (MonitoringAttribute ssv in monAttributeCountries)
				{
					if (ssv.Country.Subregion.Region.Id == Convert.ToInt64(region))
					{
						monCountry.Add(ssv);
					}
				}
			}
			foreach (MonitoringAttribute ssv in monCountry)
			{
				keyValueList.Add(new CountryAndRegion_WS(ssv.Country.Id, ssv.Country.Name, ssv.Country.Subregion.Region.Id, false, false));
			}
			keyValueList.Sort();
			return keyValueList;
		}

		public static IList<MonitoringAttribute> FindAllByProjectId(int projectId)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(MonitoringAttribute));
			List<int> countryIds = Country.GetCountryOrRegionByUserId(false);
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("IsActive", 1));
			return MonitoringAttribute.FindAll(criteria).OrderBy(attr => attr.Country.Name).Where(c => countryIds.Contains(c.CountryId)).ToList();
		}

		public static IList<MonitoringAttribute> FindAllByProjectIdNoPermissionCheck(int projectId)
		{
			var criteria = DetachedCriteria.For<MonitoringAttribute>().Add(Expression.Eq("ProjectId", projectId));
			return MonitoringAttribute.FindAll(criteria);
		}

		public static IList<MonitoringAttribute> FindAllActiveByProjectId(int projectId)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(MonitoringAttribute));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("IsActive", 1));
			return MonitoringAttribute.FindAll(criteria);
		}
		/// <summary>
		/// Sriram:to find the country is Active for the selected project.
		/// </summary>
		/// <param name="projectId"></param>
		/// <param name="countryId"></param>
		/// <returns></returns>

		public static bool IsCountryActive(int projectId, int countryId)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(MonitoringAttribute));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("CountryId", countryId));
			criteria.Add(Expression.Eq("IsActive", 1));
			MonitoringAttribute monAttr = MonitoringAttribute.FindOne(criteria);
			return monAttr != null ? true : false;
		}

		public void GenerateFromQIPDataOrDefaultCalculator()
		{
			bool generateCountCalculators = ((ProjectDteType_E.Dte.Equals(Project.ProjectDteType) && Project.VisitSchemaLevelId != (int)VisitSchemaLevel_E.Unknown) || ProjectDteType_E.NonDte.Equals(Project.ProjectDteType));
			if (generateCountCalculators)
			{
				GenerateFromQipData();
				GenerateMonitoringCalculatorsForMissingCountry();
				GenerateDefaultCalculatorsIfMissing();
			}
		}

		internal List<FTECalculator> GenerateFromQipData(CalculatorGroup_E calculatorGroup)
		{
			var calcList = new List<FTECalculator>();

			DbHelp.ExecuteScalarSP("dbo.GenerateMonitoringCalculatorsFromQipClinicalFinalByCalculatorType", ConfigValue.CommandTimeout,
											new SqlParameter("@monitoringAttributeId", Id),
											new SqlParameter("@projectId", ProjectId),
											new SqlParameter("@countryId", CountryId),
											new SqlParameter("@calculatorTypeId", (int)calculatorGroup)
											);

			var criteria = DetachedCriteria.For(typeof(FTECalculator));
			criteria.Add(Expression.Eq("ProjectId", ProjectId));
			criteria.Add(Expression.Eq("CountryId", CountryId));
			criteria.Add(Expression.Eq("CalculatorTypeId", (int)calculatorGroup));
			criteria.Add(Expression.IsNull("RequestId"));

			return FTECalculator.FindAll(criteria).ToList();
		}

		internal void GenerateFromQipData()
		{
			DbHelp.ExecuteScalarSP("dbo.GenerateMonitoringCalculatorsFromQipClinicalFinal", ConfigValue.CommandTimeout,
											new SqlParameter("@monitoringAttributeId", Id),
											new SqlParameter("@projectId", ProjectId),
											new SqlParameter("@countryId", CountryId)
											);
		}
		internal void GenerateMonitoringCalculatorsForMissingCountry()
		{
			GenerateCalculatorsForMissingCountry(null);
		}

		internal void GenerateCalculatorsForMissingCountry(CalculatorGroup_E? calculatorGroupId)
		{
			DbHelp.ExecuteScalarSP("dbo.GenerateMonitoringCalculatorsForMissingCountryinQipClinicalFinal", ConfigValue.CommandTimeout,
											new SqlParameter("@projectId", ProjectId),
											new SqlParameter("@countryId", CountryId),
											new SqlParameter("@calculatorTypeId", calculatorGroupId)
											);
		}

		public void GenerateDefaultCalculatorsIfMissing()
		{
			IList<FTECalculator> calculators = FTECalculator.GetMonitoringCalculatorsByAttributeId(Id, false);
			Project project = Models.Project.FindOneById(ProjectId);

			if (ProjectDteType_E.Dte.Equals(project.ProjectDteType))
			{
				// Generate default DTE Site and DTE Pharamacy Monitoring calculator for DTE projects
				GenerateDefaultMonitoringCalculatorsIfMissing(calculators, CountryId, true, (OrganizationalUnit_E)project.OrganizationalUnit.Id);
				GenerateDefaultPharmacyCalculatorsIfMissing(calculators, true, false, (OrganizationalUnit_E)project.OrganizationalUnit.Id);
			}
			else
			{
				// Generate default Standard, iCRA and Pharamacy Monitoring calculator for non DTE projects
				GenerateDefaultMonitoringCalculatorsIfMissing(calculators, CountryId, false, (OrganizationalUnit_E)project.OrganizationalUnit.Id);
				GenerateDefaultPharmacyCalculatorsIfMissing(calculators, false, false, (OrganizationalUnit_E)project.OrganizationalUnit.Id);
				GenerateDefaultIcraCalculatorsIfMissing(calculators, (OrganizationalUnit_E)project.OrganizationalUnit.Id);
			}
		}


		private void GenerateDefaultIcraCalculatorsIfMissing(IList<FTECalculator> calculators, OrganizationalUnit_E organizationalUnit)
		{
			List<FTECalculator> icraCalculators = calculators.Where(c => c.CalculatorTypeId == (int)CalculatorGroup_E.ICraCalculator).ToList();
			if (icraCalculators.Count != 0)
			{
				foreach (var calculatorTypeId in iCRACalculatorTypeId)
				{
					if (icraCalculators.Where(c => c.TypeId == calculatorTypeId).Count() == 0)
					{
						var defaultCalulatorValues = MonitoringCalculatorDefaultValueByOrganizationalUnit.GetDefaultCalculatorValues(organizationalUnit, CalculatorGroup_E.ICraCalculator, (CalculatorType_E)calculatorTypeId);

						new FTECalculator
						{
							ProjectId = ProjectId,
							CountryId = CountryId,
							CalculatorTypeId = (int)defaultCalulatorValues.CalculatorTypeId,
							TypeId = (int)defaultCalulatorValues.TypeId,
							MonitoringAttributeId = Id,
							SIVPerSite = defaultCalulatorValues.SIVPerSite,
							VisitFrequency = defaultCalulatorValues.VisitFrequency,
							ClusterTravelTime = defaultCalulatorValues.ClusterTravelTime,
							OnSiteTime = defaultCalulatorValues.OnSiteTime,
							PrepFollowUpTime = defaultCalulatorValues.PrepFollowUpTime,
							PhoneSIVPerSite = defaultCalulatorValues.PhoneSIVPerSite,
							PhoneVisitFrequency = defaultCalulatorValues.PhoneVisitFrequency,
							PhoneVisitTime = defaultCalulatorValues.PhoneVisitTime,
							PhonePrepFollowUpTime = defaultCalulatorValues.PhonePrepFollowUpTime,
							AdminTime = defaultCalulatorValues.AdminTime,
							SSVPerSite = defaultCalulatorValues.SSVPerSite,
							PhoneSSVPerSite = defaultCalulatorValues.PhoneSSVPerSite,
							Fte = CalculatorUtility.CalculateAverageFte(defaultCalulatorValues.TotalOnsiteHours, CountryId),
							PhoneFte = CalculatorUtility.CalculateAverageFte(defaultCalulatorValues.TotalPhoneHours, CountryId),
							IsConnectedToQip = false
						}.SaveAndFlush();
					}
				}
			}
		}
		internal void GenerateDefaultPharmacyCalculatorsIfMissing(IList<FTECalculator> calculators, bool DTEProject, bool alwaysCreateDefaultCalculators, OrganizationalUnit_E organizationalUnit)
		{
			List<FTECalculator> pharmacyCalculators = calculators.Where(c => c.CalculatorTypeId == (DTEProject ? (int)CalculatorGroup_E.DTEPharmacyCalculator : (int)CalculatorGroup_E.PharmacyCalculator)).ToList();

			if (pharmacyCalculators.Count != 0 || alwaysCreateDefaultCalculators)
			{
				foreach (var calculatorTypeId in pharmacyCalculatorTypeId)
				{
					if (pharmacyCalculators.Where(c => c.TypeId == calculatorTypeId).Count() == 0)
					{
						var calculatorGroup = DTEProject ? CalculatorGroup_E.DTEPharmacyCalculator : CalculatorGroup_E.PharmacyCalculator;
						var defaultCalulatorValues = MonitoringCalculatorDefaultValueByOrganizationalUnit.GetDefaultCalculatorValues(organizationalUnit, calculatorGroup, (CalculatorType_E)calculatorTypeId);

						new FTECalculator
						{
							ProjectId = ProjectId,
							CountryId = CountryId,
							CalculatorTypeId = (int)defaultCalulatorValues.CalculatorTypeId,
							TypeId = (int)defaultCalulatorValues.TypeId,
							MonitoringAttributeId = Id,
							SIVPerSite = defaultCalulatorValues.SIVPerSite,
							VisitFrequency = defaultCalulatorValues.VisitFrequency,
							ClusterTravelTime = defaultCalulatorValues.ClusterTravelTime,
							OnSiteTime = defaultCalulatorValues.OnSiteTime,
							PrepFollowUpTime = defaultCalulatorValues.PrepFollowUpTime,
							PhoneSIVPerSite = defaultCalulatorValues.PhoneSIVPerSite,
							PhoneVisitFrequency = defaultCalulatorValues.PhoneVisitFrequency,
							PhoneVisitTime = defaultCalulatorValues.PhoneVisitTime,
							PhonePrepFollowUpTime = defaultCalulatorValues.PhonePrepFollowUpTime,
							AdminTime = defaultCalulatorValues.AdminTime,
							SSVPerSite = defaultCalulatorValues.PhoneSSVPerSite,
							PhoneSSVPerSite = 0,
							Fte = CalculatorUtility.CalculateAverageFte(defaultCalulatorValues.TotalOnsiteHours, CountryId),
							PhoneFte = CalculatorUtility.CalculateAverageFte(defaultCalulatorValues.TotalPhoneHours, CountryId),
							IsConnectedToQip = false
						}.SaveAndFlush();
					}
				}
			}
		}
		private void GenerateDefaultMonitoringCalculatorsIfMissing(IList<FTECalculator> calculators, int countryId, bool DTEProject, OrganizationalUnit_E organizationalUnit)
		{
			List<FTECalculator> monitoringCalculators = calculators.Where(c => c.CalculatorTypeId == (DTEProject ? (int)CalculatorGroup_E.DTEMonitoringCalculator : (int)CalculatorGroup_E.MonitoringCalculator)).ToList();

			List<int> monitoringFrequenciesTypeId;
			if (DTEProject)
			{
				monitoringFrequenciesTypeId = dteMonitoringCalculatorTypeId;
			}
			else
			{
				monitoringFrequenciesTypeId = monitoringCalculatorTypeId;
			}

			foreach (var calculatorTypeId in monitoringFrequenciesTypeId)
			{
				if (monitoringCalculators.Where(c => c.TypeId == calculatorTypeId).Count() == 0)
				{
					var calculatorGroup = DTEProject ? CalculatorGroup_E.DTEMonitoringCalculator : CalculatorGroup_E.MonitoringCalculator;
					var defaultCalulatorValues = MonitoringCalculatorDefaultValueByOrganizationalUnit.GetDefaultCalculatorValues(organizationalUnit, calculatorGroup, (CalculatorType_E)calculatorTypeId);
					bool isCovForJapan = (countryId == Constants.JapanCountryId && calculatorTypeId == (int)CalculatorType_E.COV);

					new FTECalculator
					{
						ProjectId = ProjectId,
						CountryId = CountryId,
						CalculatorTypeId = (int)defaultCalulatorValues.CalculatorTypeId,
						TypeId = (int)defaultCalulatorValues.TypeId,
						MonitoringAttributeId = Id,
						SIVPerSite = isCovForJapan ? 2 : defaultCalulatorValues.SIVPerSite,
						VisitFrequency = isCovForJapan ? ConfigValue.DefaultJapanCovVisitFrequency : defaultCalulatorValues.VisitFrequency,
						ClusterTravelTime = defaultCalulatorValues.ClusterTravelTime,
						OnSiteTime = defaultCalulatorValues.OnSiteTime,
						PrepFollowUpTime = defaultCalulatorValues.PrepFollowUpTime,
						PhoneSIVPerSite = defaultCalulatorValues.PhoneSIVPerSite,
						PhoneVisitFrequency = defaultCalulatorValues.PhoneVisitFrequency,
						PhoneVisitTime = defaultCalulatorValues.PhoneVisitTime,
						PhonePrepFollowUpTime = defaultCalulatorValues.PhonePrepFollowUpTime,
						AdminTime = defaultCalulatorValues.AdminTime,
						SSVPerSite = defaultCalulatorValues.SSVPerSite,
						PhoneSSVPerSite = defaultCalulatorValues.PhoneSSVPerSite,
						Fte = CalculatorUtility.CalculateAverageFte(defaultCalulatorValues.TotalOnsiteHours, CountryId),
						PhoneFte = CalculatorUtility.CalculateAverageFte(defaultCalulatorValues.TotalPhoneHours, CountryId),
						IsConnectedToQip = false
					}.SaveAndFlush();
				}
			}
		}

		protected List<int> Init(string sql)
		{
			var ftetype = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						ftetype.Add((int)dr[0]);
					}
				}
				finally { dr.Close(); }
			}
			return ftetype;
		}

		public static IEnumerable<ICountryAttribute> FindByAttributeIdList(List<int> attributeIdList)
		{
			var dc = DetachedCriteria.For(typeof(MonitoringAttribute));
			dc.Add(Expression.In("Id", attributeIdList.ToArray()));
			return MonitoringAttribute.FindAll(dc).Cast<ICountryAttribute>();
		}

		public static MonitoringAttributeSummary_WS GetSiteCountAndVisitCountSummary(int projectId)
		{
			var result = new MonitoringAttributeSummary_WS();
			using (var dr = DbHelp.ExecuteDataReaderSP("GetMonitoringAttributeSummary", new SqlParameter("ProjectId", projectId)))
			{
				try
				{
					if (dr.Read())
					{
						result.TotalBudgetedSites = DbSafe.Int(dr["TotalQipBudgetedSites"]);
						result.TotalProjectedInitiatedSites = DbSafe.Int(dr["TotalProjectedInitiatedSites"]);
						result.TotalActualActiveSites = DbSafe.Int(dr["TotalActualActiveSites"]);

						result.TotalQipBudgetedSivVisitCount = DbSafe.Int(dr["TotalQipBudgetedSivVisitCount"]);
						result.TotalQipBudgetedCovVisitCount = DbSafe.Int(dr["TotalQipBudgetedCovVisitCount"]);
						result.TotalQipBudgetedOnsiteImvVisitCount = DbSafe.Int(dr["TotalQipBudgetedOnsiteImvVisitCount"]);
						result.TotalQipBudgetedPharmacyVisitCount = DbSafe.Int(dr["TotalQipBudgetedPharmacyVisitCount"]);
						result.TotalQipBudgetedRemoteVisitCount = DbSafe.Int(dr["TotalQipBudgetedRemoteVisitCount"]);
						result.TotalBudgetedBoosterVisitCount = DbSafe.Int(dr["TotalBudgetedBoosterVisitCount"]);

						result.TotalProjectedSivVisitCount = DbSafe.Int(dr["TotalProjectedSivVisitCount"]);
						result.TotalProjectedCovVisitCount = DbSafe.Int(dr["TotalProjectedCovVisitCount"]);
						result.TotalProjectedOnsiteImvVisitCount = DbSafe.Int(dr["TotalProjectedOnsiteImvVisitCount"]);
						result.TotalProjectedPharmacyVisitCount = DbSafe.Int(dr["TotalProjectedPharmacyVisitCount"]);
						result.TotalProjectedRemoteVisitCount = DbSafe.Int(dr["TotalProjectedRemoteVisitCount"]);
					}
				}
				finally { dr.Close(); }
			}
			return result;
		}

		/// <summary>
		/// Throws RMException if datevalidation fails
		/// Use this function only when updating single country
		/// </summary>
		public void UpdateProjectedVisitCount() { UpdateProjectedVisitCount(null); }

		/// <summary>
		/// Throws RMException if datevalidation fails
		/// </summary>
		public void UpdateProjectedVisitCount(ProjectSchemaDetails_WS projectDteSchema)
		{
			var projectVisitCount = GetProjectedVisits(projectDteSchema);
			ProjectedSivVisitCount = projectVisitCount.IntSivVisitCount;
			ProjectedCovVisitCount = projectVisitCount.IntCovVisitCount;
			ProjectedOnsiteImvVisitCount = projectVisitCount.IntOnsiteImvVisitCount;
			ProjectedRemoteVisitCount = projectVisitCount.IntRemoteVisitCount;
			ProjectedPharmacyVisitCount = projectVisitCount.IntPharmacyVisitCount;
			SaveAndFlush();
		}
		public static void UpdateMonitoringAttributeProjectedVisitCount(int projectId)
		{
			var maList = MonitoringAttribute.FindAllByProjectIdNoPermissionCheck(projectId);
			var projectDteSchema = Project.GetProjectActiveTierInformation(projectId);
			foreach (var ma in maList)
			{
				try
				{
					ma.UpdateProjectedVisitCount(projectDteSchema);
				}
				catch (RMException rex) { Logger.Instance.Error(rex); }
			}
		}
		public static VisitCount GetProjectedVisitCountForAllActiveMonitoringCountries(int projectId, ProjectSchemaDetails_WS projectDteSchema)
		{
			var maList = MonitoringAttribute.FindAllActiveByProjectId(projectId);
			var totalVisitCount = new VisitCount();
			foreach (var ma in maList)
			{
				try
				{
					var sa = SSVAttribute.FindByProjectIdCountryId(projectId, ma.CountryId);
					totalVisitCount.Sum(new CountryLevelVisitProjector(ma, sa, ma.BudgetedSites.GetValueOrDefault(), projectDteSchema).ProjectedVisitCount);
				}
				catch (RMException rex) { Logger.Instance.Error(rex); }
			}
			return totalVisitCount;
		}
		/// <summary>
		/// Throws RMException if date validation fails
		/// </summary>
		public VisitCount GetProjectedVisits(int projectedInitiatesSiteCount, ProjectSchemaDetails_WS projectDteSchema)
		{
			var sa = SSVAttribute.FindByProjectIdCountryId(ProjectId, CountryId);
			return new CountryLevelVisitProjector(this, sa, projectedInitiatesSiteCount, projectDteSchema).ProjectedVisitCount;
		}

		/// <summary>
		/// Throws RMException if datevalidation fails
		/// </summary>
		public VisitCount GetProjectedVisits(ProjectSchemaDetails_WS projectDteSchema)
		{
			return GetProjectedVisits(BudgetedSites.GetValueOrDefault(), projectDteSchema);
		}

		internal static VisitCount GetBudgetedVisitCount(int projectId)
		{
			var visitcount = new VisitCount();
			var sql = string.Format(@"SELECT  SUM(MA.QipBudgetedSivVisitCount) AS TotalQipBudgetedSivVisitCount ,
																				SUM(MA.QipBudgetedCovVisitCount) AS TotalQipBudgetedCovVisitCount ,
																				SUM(MA.QipBudgetedOnsiteImvVisitCount) AS TotalQipBudgetedOnsiteImvVisitCount ,
																				SUM(MA.QipBudgetedPharmacyVisitCount) AS TotalQipBudgetedPharmacyVisitCount ,
																				SUM(MA.QipBudgetedRemoteVisitCount) AS TotalQipBudgetedRemoteVisitCount 
																FROM    dbo.MonitoringAttribute MA WITH ( NOLOCK )
																WHERE   MA.ProjectId = {0}
																				AND MA.IsActive = 1", projectId);
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					if (dr.Read())
					{
						visitcount.SivVisitCount = DbSafe.Int(dr["TotalQipBudgetedSivVisitCount"]);
						visitcount.CovVisitCount = DbSafe.Int(dr["TotalQipBudgetedCovVisitCount"]);
						visitcount.OnsiteImvVisitCount = DbSafe.Int(dr["TotalQipBudgetedOnsiteImvVisitCount"]);
						visitcount.RemoteVisitCount = DbSafe.Int(dr["TotalQipBudgetedRemoteVisitCount"]);
						visitcount.PharmacyVisitCount = DbSafe.Int(dr["TotalQipBudgetedPharmacyVisitCount"]);
					}
				}
				finally { dr.Close(); }
			}
			return visitcount;
		}

		public static int ConnectSingleMonitoringValueToQip(int monitoringAttributeId, string columnName, int connectedValue)
		{
			var ma = Find(monitoringAttributeId);
			if (!string.IsNullOrEmpty(columnName))
			{
				switch (columnName.ToUpper())
				{
					case "QIPBUDGETEDSITES":
						ma.IsQipBudgetedSitesConnected = true;
						ma.QipBudgetedSites = ma.QipBudgetedSitesConnectedValue;

						ma.QipBudgetedSivVisitCount = ma.QipBudgetedSitesConnectedValue;
						//Japan uses 2 COV visits 93% of the time.
						ma.QipBudgetedCovVisitCount = GetBudgetedCovVisisCountFromBudgetedSites(ma, ma.QipBudgetedSitesConnectedValue.GetValueOrDefault());
						break;
					case "QIPBUDGETEDONSITEIMVVISITCOUNT":
						ma.IsQipBudgetedOnsiteImvVisitCountConnected = true;
						ma.QipBudgetedOnsiteImvVisitCount = ma.QipBudgetedOnsiteImvVisitCountConnectedValue;
						break;
					case "QIPBUDGETEDPHARMACYVISITCOUNT":
						ma.IsQipBudgetedPharmacyVisitCountConnected = true;
						ma.QipBudgetedPharmacyVisitCount = ma.QipBudgetedPharmacyVisitCountConnectedValue;
						break;
					case "QIPBUDGETEDREMOTEVISITCOUNT":
						ma.IsQipBudgetedRemoteVisitCountConnected = true;
						ma.QipBudgetedRemoteVisitCount = ma.QipBudgetedRemoteVisitCountConnectedValue;
						break;
					case "BUDGETEDBOOSTERVISITCOUNT":
						ma.IsBudgetedBoosterVisitCountConnected = true;
						ma.BudgetedBoosterVisitCount = ma.BudgetedBoosterVisitCountConnectedValue;
						break;
					default:
						break;
				}
				ma.SaveAndFlush();
			}
			return (ma.QipBudgetedSivVisitCount + ma.QipBudgetedCovVisitCount).GetValueOrDefault();
		}

		public static int GetNumberOfCovVisistsPerSiteByCOuntryId(int countryId)
		{
			return (countryId == Constants.JapanCountryId ? 2 : 1);
		}
		public static int GetBudgetedCovVisisCountFromBudgetedSites(MonitoringAttribute ma, int qipBudgetedSites)
		{
			return GetNumberOfCovVisistsPerSiteByCOuntryId(ma.CountryId) * qipBudgetedSites;
		}
		public static decimal GetBudgetedCovVisisCountFromBudgetedSites(MonitoringAttribute ma, decimal qipBudgetedSites)
		{
			return GetNumberOfCovVisistsPerSiteByCOuntryId(ma.CountryId) * qipBudgetedSites;
		}

		public static void CopyBudgetedSitesToProjectedInitiatedSites(int projectId)
		{
			DbHelp.ExecuteNonQuerySP("CopyQipBudgetedSitesValueToProjectedInitiatedSites", new SqlParameter("projectId", projectId), new SqlParameter("lastModifiedBy", ExtensionMethods.GetCurrentUserQid()));
		}

		public static void UpdateBudgetedSites(int projectId, int countryId, int? budgetedSites)
		{
			if (budgetedSites.HasValue)
			{
				var attribute = FindByProjectIdCountryId(projectId, countryId, false);
				if (attribute != null && attribute.BudgetedSites != budgetedSites)
				{
					attribute.BudgetedSites = budgetedSites;
					attribute.SaveAndFlush();
				}
			}
		}
	}
}