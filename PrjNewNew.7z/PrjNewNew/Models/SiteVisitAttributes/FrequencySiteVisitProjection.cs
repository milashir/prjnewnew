﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public class FrequencySiteVisitProjection
	{
		public string Frequency { get; set; }
		public CalculatorType_E CalculatorType { get; set; }
		public DateTime StartDate { get; set; }
		public DateTime StopDate { get; set; }

		public int OnsiteVisitFrequency { get; set; }
		public int QipBudgetedOnsiteVisitCount { get; set; }
		public int ProjectedSivVisitCount { get; set; }
		public int ProjectedCovVisitCount { get; set; }
		public int ProjectedOnsiteImvVisitCount { get; set; }
		public int ActualOnsiteVisitCount { get; set; }
		public int RemoteVisitFrequency { get; set; }
		public int QipBudgetedRemoteVisitCount { get; set; }
		public int ProjectedRemoteVisitCount { get; set; }
		public int ActualRemoteVisitCount { get; set; }
		public bool OutOfRangeVisitCount { get; set; }
	}
}
