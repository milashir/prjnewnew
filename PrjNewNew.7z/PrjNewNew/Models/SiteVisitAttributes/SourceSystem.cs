﻿using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "cd_SourceSystem")]
	public class SourceSystem : AbstractActiveRecordBaseModel<SourceSystem>
	{
		[PrimaryKey(Column = "SourceSystemId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property(Column = "SourceSystemName")]
		public string Name { set; get; }

	}
}


