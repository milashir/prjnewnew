﻿//using Castle.ActiveRecord;
//using NHibernate.Criterion;

//namespace Quintiles.RM.Clinical.Domain.Models
//{
//	[ActiveRecord(Table = "CountryVisitTypeInclude")]
//	public class CountryVisitTypeInclude : AbstractActiveRecordBaseModel<CountryVisitTypeInclude>
//	{
//		[PrimaryKey(Column = "CountryVisitTypeIncludeId", UnsavedValue = "-1")]
//		public override int Id { set { this._id = value; } get { return this._id; } }

//		[Property]
//		public int CountryId { get; set; }

//		[Property]
//		public int SiteVisitTypeId { get; set; }
//	}
//}
