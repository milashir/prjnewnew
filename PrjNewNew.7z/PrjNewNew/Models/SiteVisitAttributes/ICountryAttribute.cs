﻿using System;
namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// Public interface of Country Attribute class
	/// </summary>
	public interface ICountryAttribute
	{
#pragma warning disable 1591
		int Id { get; set; }

		int CountryId { get; set; }
		Project Project { get; set; }

		DateTime? CRATrainingDate { get; set; }
		DateTime? StartDate { get; set; }
		DateTime? StopDate { get; set; }
		DateTime? IMDate { get; set; }

		int? BudgetedSites { get; set; }
		DateTime LastModifiedOn { get; set; }
		string GetNotesColumnValue(bool makeDbCall);
		int IsActive { get; set; }
#pragma warning restore 1591
	}
}
