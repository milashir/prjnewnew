using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.Serialization;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[DataContract]
	public class Visit_WS
	{
		[DataMember(IsRequired = false)]
		public DateTime? ActualVisitStartDate;

		[DataMember(IsRequired = false)]
		public string AuthorFirstName;

		[DataMember(IsRequired = false)]
		public string AuthorLastName;
		[DataMember(IsRequired = false)]
		public DateTime? ContractedVisitDate;

		[DataMember(IsRequired = false)] // Required
		public DateTime? PlannedVisitStartDate;

		[DataMember(IsRequired = false)]
		public string QId;
		[DataMember(IsRequired = false)]
		public String SiteVisitReportStatus;
		[DataMember(IsRequired = false)]
		public String SiteVisitSection;

		[DataMember(IsRequired = false)]
		public String SiteVisitStatus;
		[DataMember(IsRequired = false)]
		public String UnblindedFlag;
		[DataMember(IsRequired = false)]
		public string VisitID;

		[DataMember(IsRequired = false)]
		public int VisitType; // enum: SSV-SIV

		[DataMember(IsRequired = false)]
		public string VisitTypeText; // same as VisitType

		[DataMember(IsRequired = false)]
		public DateTime? ActualVisitEndDate;

		[DataMember(IsRequired = false)]
		public DateTime? PlannedVisitEndDate;

		public DateTime? ActualOrPlanned()
		{
			return ActualVisitStartDate.HasValue ? ActualVisitStartDate : PlannedVisitStartDate;
		}
	}

	public class ctmsLoader_SiteVisit
	{
		public ctmsLoader_SiteVisit()
		{
		}

		public ctmsLoader_SiteVisit(Visit_WS v, int siteID)
		{
			ctmsLoader_SiteID = siteID;
			VisitID = v.VisitID;
			ActualVisitStartDate = v.ActualVisitStartDate;
			ContractedVisitDate = v.ContractedVisitDate;
			PlannedVisitStartDate = v.PlannedVisitStartDate;
			ActualVisitEndDate = v.ActualVisitEndDate;
			PlannedVisitEndDate = v.PlannedVisitEndDate;
			SiteVisitSection = v.SiteVisitSection;
			VisitType = v.VisitType;
			VisitTypeText = v.VisitTypeText;
			SiteVisitStatus = v.SiteVisitStatus;
			SiteVisitReportStatus = v.SiteVisitReportStatus;
			AuthorFirstName = v.AuthorFirstName;
			AuthorLastName = v.AuthorLastName;
			QId = v.QId;
			UnblindedFlag = v.UnblindedFlag;
		}

		public int Id { get; set; }
		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public int ctmsLoader_SiteID { get; set; }
		public DateTime? ActualVisitStartDate { get; set; }
		public DateTime? ContractedVisitDate { get; set; }
		public DateTime? PlannedVisitStartDate { get; set; }
		public String SiteVisitSection { get; set; }
		public int? VisitType { get; set; }
		public String VisitTypeText { get; set; }
		public string VisitID { get; set; }
		public String SiteVisitStatus { get; set; }
		public string SiteVisitReportStatus { get; set; }
		public String AuthorFirstName { get; set; }
		public String AuthorLastName { get; set; }
		public String QId { get; set; }
		public string UnblindedFlag { get; set; }
		public DateTime? ActualVisitEndDate { get; set; }
		public DateTime? PlannedVisitEndDate { get; set; }

		public DateTime? ConfirmedOrPlanned()
		{
			return ContractedVisitDate.HasValue ? ContractedVisitDate : PlannedVisitStartDate;
		}

		public DateTime? GetVisitDate()
		{
			var visitDate = ActualVisitStartDate.HasValue
							? ActualVisitStartDate.Value
							: ContractedVisitDate.HasValue
									? ContractedVisitDate.Value
									: PlannedVisitStartDate.GetValueOrDefault();
			//KM:Could not throw an  exception because of business rule.
			/*	if (visitDate==DateTime.MinValue)
				{
					throw new ApplicationException("Visit date does not have a value in SiteVisit. There should be atleast one date value in actual,confirmed or planned date.");
				}*/
			return visitDate;
		}

		public bool IsQIDSameAsRMAssignedResourceId(int requestId)
		{
			if (string.IsNullOrEmpty(QId)) return false;
			var sql =
				string.Format(
					"SELECT count(1) FROM resource JOIN ResourceRequestAssignment_XREF rra ON	dbo.Resource.ResourceId = rra.ResourceId WHERE qid='{0}' AND requestid={1}",
					QId, requestId);
			return (0 != (int)DbHelp.ExecuteScalarText(sql));
		}
	}

	public class ctmsLoader_SiteMilestone
	{
		public ctmsLoader_SiteMilestone()
		{
		}

		public ctmsLoader_SiteMilestone(MileStone_WS m, int siteID)
		{
			ctmsLoader_SiteID = siteID;
			MilestoneID = m.MileStoneID;
			ActualDate = m.ActualDate;
			ContractedDate = m.ContractedDate;
			MilestoneType = m.MilestoneType;
			MilestoneTypeText = m.MilestoneTypeText;
			PlannedDate = m.PlannedDate;
		}

		public int Id { get; set; }
		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public int ctmsLoader_SiteID { get; set; }
		public DateTime? ActualDate { get; set; }
		public DateTime? ContractedDate { get; set; }
		public int MilestoneType { get; set; }
		public DateTime? PlannedDate { get; set; }
		public string MilestoneTypeText { get; set; }
		public string MilestoneID { get; set; }
	}

	public class ctmsLoader_DTESiteTier
	{
		public ctmsLoader_DTESiteTier()
		{
		}

		public ctmsLoader_DTESiteTier(DTESiteTier_WS siteTier, int siteID)
		{
			ctmsLoader_SiteID = siteID;
			ResourceTypeId = siteTier.ResourceTypeId;
			TierId = DbSafe.Int(siteTier.DTESiteTier);
			EffectiveDate = siteTier.DTEEffectiveDate;
			ReasonForChange = siteTier.ReasonForChange;
			ReasonForChangeOther = siteTier.ReasonForChangeOther;
			DTESiteTierModifiedBy = siteTier.DTEModifiedBy;
			DTESiteTierModifiedOn = siteTier.DTEModifiedDate;
		}

		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public int ctmsLoader_SiteID { get; set; }
		public int ResourceTypeId { get; set; }
		public int TierId { get; set; }
		public DateTime EffectiveDate { get; set; }
		public string ReasonForChange { get; set; }
		public string ReasonForChangeOther { get; set; }
		public string DTESiteTierModifiedBy { get; set; }
		public DateTime DTESiteTierModifiedOn { get; set; }

	}

	public class ctmsLoader_SiteIRBType
	{
		public int Id { get; set; }
		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public int IRBTypeId { get; set; }
		public int ctmsLoader_SiteID { get; set; }
	}

	public class ctmsLoader_SiteAddress
	{
		public ctmsLoader_SiteAddress()
		{
		}

		public ctmsLoader_SiteAddress(SiteAddress_WS a, int siteID)
		{
			ctmsLoader_SiteID = siteID;
			AddressID = a.AddressID;
			ClusterCode = a.ClusterCode;
			ClusterName = a.ClusterName;
			StreetAddress1 = a.StreetAddress1;
			StreetAddress2 = a.StreetAddress2;
			StreetAddress3 = a.StreetAddress3;
			City = a.City;
			PostalCode = a.PostalCode;
			State = a.State;
			Country = a.Country;
			AddressType = a.AddressType;
		}

		public int Id { get; set; }
		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public int ctmsLoader_SiteID { get; set; }
		public string ClusterCode { get; set; }
		public string ClusterName { get; set; }
		public string SiteAddress { get; set; }
		public string StreetAddress1 { get; set; }
		public string StreetAddress2 { get; set; }
		public string StreetAddress3 { get; set; }
		public string City { get; set; }
		public string PostalCode { get; set; }
		public string State { get; set; }
		public string Country { get; set; }
		public string AddressID { get; set; }
		public string AddressType { get; set; }
	}

	public class ctmsLoader_ProtocolTeam
	{
		public ctmsLoader_ProtocolTeam() { }

		public ctmsLoader_ProtocolTeam(ProtocolSiteType_WS ps)
		{
			FirstName = ps.ProtocolTeamFirstName;
			LastName = ps.ProtocolTeamLastName;
			UnblindedFlag = ps.ProtocolTeamUnblindedFlag;
			QId = ps.ProtocolTeamQId;
		}

		public int Id { get; set; }
		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string UnblindedFlag { get; set; }
		public string QId { get; set; }
	}

	public class ctmsLoader_Site
	{
		public int Id { get; set; }
		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public string ProgramID { get; set; }
		public string ProjectCode { get; set; }
		public string ProtocolIdentifier { get; set; }
		public string SiteID { get; set; }
		public int? SiteSelectVisitRequired { get; set; }
		public int? SiteSelectVisitType { get; set; }
		public string SiteStatus { get; set; }
		public string SourceSystem { get; set; }
		public string SourceSystemID { get; set; }
		public string SponsorSiteID { get; set; }
		public string StudyID { get; set; }
		public string StudyStatus { get; set; }
		public string ProgramName { get; set; }
		public string PrincipalInvestigatorId { get; set; }
		public string SiteSelectVisitRequiredText { get; set; }
		public string SiteSelectVisitTypeText { get; set; }
		public string SiteStatusText { get; set; }
		public string ClusterNameResource { get; set; }
		public string ClusterNameSite { get; set; }
		public string SponsorId { get; set; }
		public string SponsorName { get; set; }
		public string IsDeleted { get; set; }
		public string PrimaryAddressID { get; set; }
		public string IrbType { get; set; }
		public DateTime? EarliestSIFSentDate { get; set; }
		public string SiteQaStatus { get; set; }
		public int? SubjectsScreened { get; set; }
		public int? SubjectsRandomized { get; set; }
	}

	[Serializable]
	public class BulkLoadKey
	{
		[KeyProperty]
		public string ProjectCode { get; set; }

		[KeyProperty]
		public string ProtocolIdentifier { get; set; }

		[KeyProperty]
		public string SiteId { get; set; }

		public override int GetHashCode()
		{
			return ProjectCode.GetHashCode() ^ ProtocolIdentifier.GetHashCode() ^ SiteId.GetHashCode();
		}

		public override bool Equals(object obj)
		{
			if (this == obj)
				return true;

			BulkLoadKey key = obj as BulkLoadKey;
			if (key == null)
				return false;

			if (key.ProjectCode != ProjectCode || key.ProtocolIdentifier != ProtocolIdentifier || key.SiteId != SiteId)
				return false;

			return true;
		}
	}

	public class z_site_ProjectProtocol
	{
		public BulkLoadKey Key { get; set; }
		public bool IsHandled { get; set; }
		public string ProgramId { get; set; }
		public string SourceSystem { get; set; }
		public string SourceSystemId { get; set; }
		public string SponsorSiteId { get; set; }
		public string StudyId { get; set; }
		public string StudyStatus { get; set; }
		public string ProgramName { get; set; }
		public string PrincipalInvestigatorId { get; set; }
		public string SiteSelectVisitRequiredText { get; set; }
		public int? SiteSelectVisitRequired { get; set; }
		public string SiteSelectVisitTypeText { get; set; }
		public int? SiteSelectVisitType { get; set; }
		public string SiteStatusText { get; set; }
		public string SiteStatus { get; set; }
		public string ClusternameResource { get; set; }
		public string ClusternameSite { get; set; }
		public string SponsorId { get; set; }
		public string SponsorName { get; set; }
		public string IsDeleted { get; set; }
		public string PrimaryAddressId { get; set; }
	}

	public class ctmsLoader_EmployeeCluster
	{
		public int Id { get; set; }
		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public string AddressId { get; set; }
		public DateTime? AddressUpdatedDate { get; set; }
		public string ClusterName { get; set; }
		public string EmployeeLogin { get; set; }
		public string ProfessionalId { get; set; }
	}

	public class ctmsLoader_Message
	{
		/// <summary>
		///   Default constructor
		/// </summary>
		public ctmsLoader_Message()
		{
			SiteVisits = new List<ctmsLoader_SiteVisit>();
			Milestones = new List<ctmsLoader_SiteMilestone>();
			Addresses = new List<ctmsLoader_SiteAddress>();
		}

		public int Id { get; set; }
		public int IsHandled { get; set; }
		public bool IsDeleted { get; set; }
		public string RawMessage { get; set; }
		public ctmsLoader_PrincipInvest PrincipInvest { get; set; }
		public ctmsLoader_ProtocolTeam ProtocolTeam { get; set; }
		public ctmsLoader_Site ProtocolSite { get; set; }
		public IList<ctmsLoader_SiteVisit> SiteVisits { get; set; }
		public IList<ctmsLoader_SiteMilestone> Milestones { get; set; }
		public IList<ctmsLoader_SiteAddress> Addresses { get; set; }
		public string PrimaryAddressID { get; set; }

		public override string ToString()
		{
			if (ProtocolSite != null)
			{
				return string.Format("Message id={0}, Project Code={1} Protocol Identifier={2}, site id={3}, site status={4}.   ", Id,
														 ProtocolSite.ProjectCode, ProtocolSite.StudyID, ProtocolSite.SiteID,
														 ProtocolSite.SiteStatusText);
			}
			return Id.ToString(CultureInfo.InvariantCulture);
		}
	}

	public class ctmsLoader_SiteAccount
	{
		public ctmsLoader_SiteAccount()
		{
		}

		public ctmsLoader_SiteAccount(SiteAccount_WS siteAccount, int siteID)
		{
			ctmsLoader_SiteID = siteID;
			SiteAccountRowId = siteAccount.SiteAccountRowId;
			AccountName1 = siteAccount.AccountName1;
			AccountName2 = siteAccount.AccountName2;
			ParentAccountName = siteAccount.ParentAccountName;
			RelationshipManagerQid = siteAccount.RelationshipManagerQid;
			RelationshipManagerFirstName = siteAccount.RelationshipManagerFirstName;
			RelationshipManagerLastName = siteAccount.RelationshipManagerLastName;
		}

		public int ctmsLoader_MessageId { get; set; }
		public int IsHandled { get; set; }
		public int ctmsLoader_SiteID { get; set; }
		public string SiteAccountRowId { get; set; }
		public string AccountName1 { get; set; }
		public string AccountName2 { get; set; }
		public string ParentAccountName { get; set; }
		public string RelationshipManagerQid { get; set; }
		public string RelationshipManagerFirstName { get; set; }
		public string RelationshipManagerLastName { get; set; }

	}
}