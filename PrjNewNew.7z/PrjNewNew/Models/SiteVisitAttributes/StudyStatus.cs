﻿using Castle.ActiveRecord;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum StudyStatus_E
	{
		ClosedFollowUpInAnalysis = 1,
		ClosedToEnrollment = 2,
		Completed = 3,
		Discontinued = 4,
		Enrolling = 5,
		InDevelopment = 6,
		OnHold = 7,
		OpenToEnrollment = 8,
		Planning = 9,
		Proposed = 10,
		Test = 11,
		ClosedWon = 12,
		ProposalLost = 13,
		NotApplicable = 14,
		Open = 15
	}

	[ActiveRecord(Table = "CD_StudyStatus")]
	public class StudyStatus : AbstractActiveRecordBaseModel<StudyStatus>
	{
		[PrimaryKey(Column = "StudyStatusId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property(Column = "StudyStatusName")]
		public string Name { set; get; }

		[Property]
		public bool SendSgrNotification { get; set; }
	}
}