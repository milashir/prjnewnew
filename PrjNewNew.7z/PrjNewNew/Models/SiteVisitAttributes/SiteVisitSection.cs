﻿using Castle.ActiveRecord;

namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// Represents table CD_SiteVisitSection in DB
	/// </summary>
	[ActiveRecord(Table = "CD_SiteVisitSection")]
	public class SiteVisitSection : AbstractActiveRecordBaseModel<SiteVisitSection>
	{
		[PrimaryKey(Column = "SiteVisitSectionId", UnsavedValue = "-1")]
		public override int Id { get; set; }


		[Property(Column = "SiteVisitSectionName")]
		public string Name { set; get; }

	}
}
