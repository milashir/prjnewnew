﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models.SiteVisitAttributes
{
	/// <summary>
	/// Any project code in this table means ignore all CTMS/Inntrax messages related to it
	/// </summary>
	[ActiveRecord]
	//public class SiteMessageProjectsToExclude : AbstractBaseReadWriteModel<SiteMessageProjectsToExclude>
	public class SiteMessageProjectsToExclude : AbstractModels.IntegrateDatabase<SiteMessageProjectsToExclude>
	{
		[PrimaryKey(Column = "Id", UnsavedValue = "-1")]
		public override int Id { get; set; }
		[Property]
		public string ProjectCode { get; set; }
		[Property]
		public string ProtocolNumber { get; set; }

		/// <summary>
		/// Does this projectcode exist in our project exclusions table?
		/// </summary>
		/// <param name="projectCode"></param>
		/// <param name="protocolNumber"></param>
		/// <returns></returns>
		public static bool Exists(string projectCode, string protocolNumber)
		{
			DetachedCriteria filters = DetachedCriteria.For(typeof(SiteMessageProjectsToExclude));
			filters.Add(Restrictions.Eq("ProjectCode", projectCode.Trim()));
			//filters.Add(Restrictions.Eq("ProtocolNumber", protocolNumber));   //MR: ProtocolNumber not in the list of exclusions
			SiteMessageProjectsToExclude[] projects = FindAll(filters);
			return projects.Length > 0;
		}
	}

	/// <summary>
	/// AR class for SiteVisit message from CTMS/Inntrax. (Writes to RM_Integrate db).
	/// </summary>
	[ActiveRecord]
	//public class SiteMessage : AbstractBaseReadWriteModel<SiteMessage>
	public class SiteMessage : AbstractModels.IntegrateDatabase<SiteMessage>
	{
		public SiteMessage()
		{
			SiteVisits = new List<ctmsLoader_SiteVisit>();
			Milestones = new List<ctmsLoader_SiteMilestone>();
			Addresses = new List<ctmsLoader_SiteAddress>();
			DTESiteTiers = new List<ctmsLoader_DTESiteTier>();
			IsProjectExist = false;
			IsProcessed = false;
		}

		[PrimaryKey(Column = "SiteMessageId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public bool? IsApprovedForSSV { get; set; }

		[Property]
		public bool? IsRejectedForSSV { get; set; }

		[Property]
		public bool? IsSelected { get; set; }


		[Property]
		public int IsHandled { get; set; }

		[Property]
		public bool IsStaged { get; set; }

		[Property]
		public bool IsAddressHandled { get; set; }

		[Property]
		public bool IsPIHandled { get; set; }

		[Property]
		public bool IsProtocolTeamHandled { get; set; }

		[Property]
		public bool IsProjectExist { get; set; }

		[Property]
		public bool IsSiteHandled { get; set; }

		[Property]
		public bool IsSiteVisitHandled { get; set; }

		[Property]
		public bool IsMileStoneHandled { get; set; }

		[Property]
		public bool IsDTESiteTierHandled { get; set; }

		[Property]
		public bool IsSiteAccountHandled { get; set; }

		[Property]
		public string Error { get; set; }

		[Property]
		public string ProjectCode { get; set; }

		[Property]
		public string ProtocolIdentifier { get; set; }

		[Property]
		public string StudyId { get; set; }

		[Property]
		public string SourceSystem { get; set; }

		[Property]
		public string SiteStatus { get; set; }

		[Property]
		public bool IsProcessed { get; set; }




		[Property]
		public bool IsDeleted { get; set; }

		public string RawMessage { get; set; }

		[Property]
		public string SiteId { get; set; }

		public ctmsLoader_PrincipInvest PrincipInvest { get; set; }
		public ctmsLoader_ProtocolTeam ProtocolTeam { get; set; }
		public ctmsLoader_Site ProtocolSite { get; set; }
		public IList<ctmsLoader_SiteVisit> SiteVisits { get; set; }
		public IList<ctmsLoader_SiteMilestone> Milestones { get; set; }
		public IList<ctmsLoader_SiteAddress> Addresses { get; set; }
		public IList<ctmsLoader_DTESiteTier> DTESiteTiers { get; set; }
		public ctmsLoader_SiteAccount SiteAccount { get; set; }
		public string PrimaryAddressID { get; set; }


		public void UpdateRawMessage()
		{
			SaveAndFlush();
			string escapedRawMessage = DbSafe.EscapeAndSurroundQuote(RawMessage);
			string sqlQuery =
				string.Format(@"UPDATE [SiteMessage] SET [RawMessage] ={0} WHERE SiteMessageId={1}",
											escapedRawMessage, Id);

			RMDbContext context = new RMDbContext(typeof(SiteMessage));
			RMDb db = new RMDb(context);
			db.ExecuteScalarText(sqlQuery);

			//DbHelp.ExecuteScalarText(sqlQuery);
		}

		/// <summary>
		/// Populates the RawMessage Property by the raw xml message that was originally sent by CTMS.
		/// </summary>
		public void LoadRawMessage()
		{
			string sql = string.Format(@"select rawmessage from SiteMessage WHERE SiteMessageId={0}", Id);
			RMDbContext context = new RMDbContext(typeof(SiteMessage));
			RMDb db = new RMDb(context);

			using (var dr = db.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						RawMessage = DbSafe.StringValue(dr.GetString(0));
						break;
					}
				}
				finally { dr.Close(); }
			}
		}

		public static SiteMessage[] GetUnHandledMessagesFromStaging()
		{
			DetachedCriteria filters = DetachedCriteria.For(typeof(SiteMessage));
			filters.Add(Restrictions.Eq("IsStaged", true));
			filters.Add(Restrictions.Eq("IsHandled", 0));
			filters.Add(Restrictions.Eq("IsProjectExist", true));
			SiteMessage[] messages = FindAll(filters);
			return messages;
		}


		public static SiteMessage[] GetUnHandledMessages(string projectCode, string studyid, string alternateId)
		{
			DetachedCriteria filters = DetachedCriteria.For(typeof(SiteMessage));
			filters.Add(Restrictions.Eq("ProjectCode", projectCode));
			filters.Add(Restrictions.Or(Restrictions.Eq("StudyId", studyid), Restrictions.Eq("StudyId", alternateId)));
			filters.Add(Restrictions.Eq("IsProcessed", false));
			filters.Add(Restrictions.Eq("IsHandled", 0));
			SiteMessage[] messages = FindAll(filters);
			return messages;
		}


		/// <summary>
		/// Gets the list of raw xml messages that was originally sent by CTMS for the given message ids.
		/// </summary>
		/// <param name="messageIds"></param>
		/// <returns></returns>
		public static SiteMessage[] GetMessagesFromStaging(List<int> messageIds)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(SiteMessage));
			criteria.Add(Restrictions.In("Id", messageIds.ToArray()));
			SiteMessage[] messages = FindAll(criteria);
			return messages;
		}


		public static List<SiteMessage> GetUnHandledMessages(int count)
		{
			DetachedCriteria filters = DetachedCriteria.For(typeof(SiteMessage));
			filters.Add(Restrictions.Eq("IsHandled", 0));
			filters.Add(Restrictions.Eq("IsProcessed", false));
			filters.AddOrder(new Order("Id", true));
			filters.SetMaxResults(count);
			SiteMessage[] messages = FindAll(filters);
			return messages.ToList();
		}

		public override string ToString()
		{
			if (ProtocolSite != null)
			{
				return string.Format("Message id={0}, Project Code={1} Protocol Identifier={2}, site id={3}, site status={4}.   ",
														 Id,
														 ProtocolSite.ProjectCode, ProtocolSite.StudyID, ProtocolSite.SiteID,
														 ProtocolSite.SiteStatusText);
			}
			return Id.ToString(CultureInfo.InvariantCulture);
		}

		public static int GetTotalUnhandledMessageCount()
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(SiteMessage));
			criteria.Add(Expression.Eq("IsHandled", 0));
			criteria.Add(Expression.Eq("IsProcessed", false));
			try
			{
				return Count(criteria);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}