﻿using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[DataContract]
	public class SiteVisitType_WS
	{
		[DataMember]
		public int SiteVisitTypeId { get; set; }

		[DataMember]
		public string SiteVisitTypeName { get; set; }

		[DataMember]
		public int? CountryId { get; set; }
	}

	[ActiveRecord(Table = "CD_ResourceTypeSiteVisitType_XREF")]
	public class ResourceTypeSiteVisitType : AbstractActiveRecordBaseModel<ResourceTypeSiteVisitType>
	{
		[PrimaryKey(Column = "ResourceTypeSiteVisitTypeId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public int ResourceTypeId { get; set; }
		[Property]
		public int? CountryId { set; get; }
		[Property]
		public int SiteVisitTypeId { get; set; }

		[Property]
		public int? OrderBy { set; get; }

		private SiteVisitType _siteVisitType = null;
		public SiteVisitType SiteVisitType
		{
			get
			{
				if (_siteVisitType == null)
				{
					_siteVisitType = CacheService.SiteVisitTypes[SiteVisitTypeId];
				}
				return _siteVisitType;
			}
		}

		public static List<SiteVisitType_WS> GetSiteVisitTypeByResourceType(ResourceTypeName resourceTypeName)
		{//
			return CacheService.ResourceTypeSiteVisitTypes.Values.Where(
				t => t.ResourceTypeId == (int)resourceTypeName && t.SiteVisitType.IsActive == 1).OrderBy(o => o.OrderBy).Select(t => new SiteVisitType_WS
				{
					SiteVisitTypeId = t.SiteVisitType.Id,
					SiteVisitTypeName = t.SiteVisitType.Name,
					CountryId = t.CountryId
				}).ToList();
		}
	}
}