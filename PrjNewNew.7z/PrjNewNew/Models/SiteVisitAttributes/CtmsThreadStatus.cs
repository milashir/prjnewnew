﻿using Castle.ActiveRecord;

namespace Quintiles.RM.Clinical.Domain.Models.SiteVisitAttributes
{
	[ActiveRecord]
	public class CtmsThreadStatus : AbstractActiveRecordBaseModel<CtmsThreadStatus>
	{
		[PrimaryKey]
		public override int Id { get; set; }
		[Property]
		public long MessageId { get; set; }
		[Property]
		public int ThreadId { get; set; }
		[Property]
		public string Status { get; set; }
		[Property]
		public string ProjectCode { get; set; }
		[Property]
		public string ProtocolNumber { get; set; }

	}
}
