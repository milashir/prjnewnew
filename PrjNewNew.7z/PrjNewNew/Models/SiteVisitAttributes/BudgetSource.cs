//using Castle.ActiveRecord;
//using NHibernate.Criterion;
//using Quintiles.RM.Clinical.Domain.Database;

//namespace Quintiles.RM.Clinical.Domain.Models
//{
//	public enum BudgetSourceName
//	{
//		Program_Budget = 1,
//		Project_Budget = 2,
//		Country_Budget = 3,
//		Internal_Cost = 4
//	}


//	[ActiveRecord(Table = "BudgetSource")]
//	public class BudgetSource : AbstractActiveRecordBaseModel<BudgetSource>
//	{
//		[PrimaryKey(Column = "BudgetSourceId", UnsavedValue = "-1")]
//		public override int Id { set { this._id = value; } get { return this._id; } }

//		[Property(Column = "Name")]
//		public string Name { set; get; }

//		internal static BudgetSource CreateFromReader(System.Data.IDataReader r)
//		{
//			BudgetSource bs = null;
//			var cc = new ColumnChecker(r);

//			if (r != null && cc.HasColumn("BudgetSourceId") && !(r["BudgetSourceId"] is System.DBNull))
//			{
//				bs = new BudgetSource { Id = DbSafe.Int(r["BudgetSourceId"]) };
//				if (cc.HasColumn("BudgetSourceName")) { bs.Name = r["BudgetSourceName"].ToString(); }
//			}
//			return bs;
//		}
//	}
//}