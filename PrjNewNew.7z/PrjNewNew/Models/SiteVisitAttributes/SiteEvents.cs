﻿//using Castle.ActiveRecord;
//using NHibernate.Criterion;

//namespace Quintiles.RM.Clinical.Domain.Models
//{
//	[ActiveRecord(Table = "SiteEvents")]
//	public class SiteEvents : AbstractActiveRecordBaseModel<SiteEvents>
//	{
//		public SiteEvents()
//			: base()
//		{
//			Site = new ProjectProtocolSite();
//			SSVRequired = new SSVRequired();
//			SSVType = new SSVType();
//			SiteVisitType = new SiteVisitType();
//			MileStoneType = new MileStoneType();
//		}

//		[PrimaryKey(Column = "SiteEventsId", UnsavedValue = "-1")]
//		public override int Id { set { this._id = value; } get { return this._id; } }

//		[Property]
//		public virtual string StudyStatus { set; get; }

//		[Property]
//		public virtual string ProgramIdentifier { set; get; }

//		[Property]
//		public virtual string ProgramName { set; get; }

//		[Property]
//		public virtual string ProtocolIdentifier { set; get; }

//		[Property]
//		public virtual string ProtocolNumber { set; get; }

//		[Property]
//		public virtual string ProjectCode { set; get; }


//		[BelongsTo("SiteId")]
//		public virtual ProjectProtocolSite Site { get; set; }

//		[Property]
//		public virtual string SponserSiteId { set; get; }

//		[Property]
//		public virtual string PrincipalInvestigatorFirstName { set; get; }

//		[Property]
//		public virtual string PrincipalInvestigatorLastName { set; get; }

//		[Property]
//		public virtual string City { set; get; }

//		[Property]
//		public virtual string State { set; get; }

//		[Property]
//		public virtual int? ZipCode { set; get; }

//		[Property]
//		public virtual string Country { set; get; }

//		[Property]
//		public virtual string SiteClusterName { set; get; }

//		[Property]
//		public virtual string SiteStatus { set; get; }

//		[BelongsTo("SSVRequiredId")]
//		public virtual SSVRequired SSVRequired { get; set; }

//		[BelongsTo("SSVTypeId")]
//		public virtual SSVType SSVType { get; set; }

//		[BelongsTo("SiteVisitTypeId")]
//		public virtual SiteVisitType SiteVisitType { get; set; }

//		[Property]
//		public virtual string VisitDate { set; get; }

//		[BelongsTo("MileStoneTypeId")]
//		public virtual MileStoneType MileStoneType { get; set; }

//		[Property]
//		public virtual string MilestoneDate { set; get; }
//	}
//}



