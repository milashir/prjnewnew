﻿using System.Data.SqlClient;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "SiteQaStatus")]
	public class SiteQaStatus : AbstractActiveRecordBaseModel<SiteQaStatus>
	{
		[PrimaryKey(Column = "SiteQaStatusId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }
		[Property]
		public string Name { get; set; }
	}
}
