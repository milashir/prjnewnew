﻿using Castle.ActiveRecord;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "cd_IRBType")]
	public class IrbType : AbstractActiveRecordBaseModel<IrbType>, ICodeTable
	{
		[PrimaryKey(Column = "IRBTypeId", UnsavedValue = "-1")]
		public override int Id
		{
			set { _id = value; }
			get { return _id; }
		}

		[Property(Column = "IRBTypeName")]
		public string Name { get; set; }
	}
}