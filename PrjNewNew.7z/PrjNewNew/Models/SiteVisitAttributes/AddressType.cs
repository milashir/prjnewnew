﻿using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "AddressType")]
	public class AddressType : AbstractActiveRecordBaseModel<AddressType>
	{
		[PrimaryKey(Column = "AddressTypeId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property(Column = "Name")]
		public string Name { set; get; }
	}
}