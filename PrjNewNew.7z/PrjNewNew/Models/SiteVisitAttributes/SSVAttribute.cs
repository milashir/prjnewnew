﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "SSVAttribute")]
	public class SSVAttribute : AbstractActiveRecordBaseModel<SSVAttribute>, ICountryAttribute
	{
		public SSVAttribute()
			: base()
		{
		}

		#region Mapped properties
		[PrimaryKey(Column = "SSVAttributeId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public int CountryId { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public virtual DateTime? CRATrainingDate { get; set; }

		[Property]
		public virtual DateTime? StartDate { get; set; }

		[Property]
		public virtual DateTime? StartDateActual { get; set; }

		[Property]
		public virtual DateTime? StopDate { get; set; }

		[Property]
		public virtual DateTime? StopDateActual { get; set; }

		public virtual DateTime? IMDate { get; set; }  //MR: Not used for SSV's, beginning of massive refactoring exercise...

		[Property]
		public virtual int? BudgetedSites { get; set; }

		[Property]
		public virtual int IsActive { get; set; }

		[Property]
		public virtual DateTime? EarliestSIFSentDate { get; set; }

		[Property]
		public int? QipBudgetedSites { get; set; }
		[Property]
		public int? QipBudgetedSitesConnectedValue { get; set; }
		[Property]
		public bool? IsQipBudgetedSitesConnected { get; set; }

		#endregion

		#region Unmapped properties
		private Country _country = null;
		public Country Country
		{
			get
			{
				if (_country == null)
				{
					_country = CacheService.Country(CountryId);
				}
				return _country;
			}
		}

		private Project _project = null;
		public Project Project
		{
			get
			{
				if (_project == null)
				{
					_project = models.Project.Find(ProjectId);
				}
				return _project;
			}
			set { _project = value; }
		}

		public virtual int? ProjectedTotalSites { get; set; }
		public virtual bool QipStatus { get; set; }

		private List<int> _ssvCalculatorTypeId = null;
		public List<int> RequiredCalculatorTypeIds
		{
			get
			{
				if (_ssvCalculatorTypeId == null)
				{
					_ssvCalculatorTypeId = new List<int>();
					string sql = string.Format("SELECT FTETypeId FROM dbo.CalculatorTFTEType_XREF WHERE CalculatorTypeId = {0}", (int)CalculatorGroup_E.SsvCalculator);

					using (var dr = DbHelp.ExecuteDataReaderText(sql))
					{
						try
						{
							while (dr.Read())
							{
								_ssvCalculatorTypeId.Add((int)dr[0]);
							}
						}
						finally { dr.Close(); }
					}
				}

				return _ssvCalculatorTypeId;
			}

			set { _ssvCalculatorTypeId = value; }



		}

		public DateTime? SSVAttributeStartDate { get { return StartDateActual.HasValue ? StartDateActual : StartDate; } }

		public DateTime? SSVAttributeStopDate { get { return StopDateActual.HasValue ? StopDateActual : StopDate; } }

		public bool HasNotes { get; set; }
		#endregion

		#region Static Get/Save methods
		/// <summary>
		/// 
		/// </summary>
		/// <param columnName="projectId"></param>
		/// <param columnName="id"></param>
		/// <returns></returns>
		/// <author>Colin Boatwright</author>
		public static SSVAttribute FindByProjectIdCountryId(int projectId, int? countryId)
		{
			return SSVAttribute.FindByProjectIdCountryId(projectId, countryId, true);
		}

		public static SSVAttribute FindByProjectIdCountryId(int projectId, int? countryId, bool activeAttributesOnly)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(SSVAttribute));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("CountryId", countryId));
			if (activeAttributesOnly)
			{
				criteria.Add(Expression.Eq("IsActive", 1));
			}

			return SSVAttribute.FindFirst(criteria);
		}
		/// <summary>
		/// This method will return all the active countries for a given project.
		/// </summary>
		/// <param name="projectId"></param>
		/// <returns></returns>
		public static IList<SSVAttribute> FindByProjectId(int projectId)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(SSVAttribute));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("IsActive", 1));
			List<int> countryIds = Country.GetCountryOrRegionByUserId(false);
			return SSVAttribute.FindAll(criteria).OrderBy(attr => attr.Country.Name).Where(c => countryIds.Contains(c.CountryId)).ToList();
		}

		internal static List<string> FindAllWithNullBudgetedSiteCount(int projectId)
		{
			var attributes = FindAll(DetachedCriteria.For<SSVAttribute>()
						.Add(Expression.Eq("ProjectId", projectId))
						.Add(Expression.IsNull("BudgetedSites")));

			return attributes.Select(a => a.Country.CTMSCountryName).ToList();
		}

		#region FindAllPagedSsvAttributed
		/// <summary>
		/// </summary>
		/// <returns></returns>
		public static PagedResponse<SSVAttribute, AttributeCommonData> FindAllPagedSsvAttributes(GridSearchAttribute_WS gsr)
		{
			return new SsvAttributeGridDataEngine(gsr).GetDataForGrid();
		}
		#endregion
		#endregion

		#region GetNotesColumnValue
		public string GetNotesColumnValue(bool getCommentCountFromDb)
		{
			bool hasNotes = getCommentCountFromDb ? (EntityComment.FindEntityComments(Id, EntityTypes.SsvAttribute, false).Count > 0) : HasNotes;

			return string.Format(Constants.MessageDiv,
							hasNotes ? string.Empty : "no_",
							Id,
							(int)SearchLevel.Country,
							EntityTypes.SsvAttribute.ToString(), (int)EntityTypes.SsvAttribute,
							Country.Name, Country.Id, Country.CountryCode,
							Country.Subregion.Region.Name, Country.Subregion.Region.Id, Country.Subregion.Region.RegionCode,
							ProjectId, Project.ProjectCode,
							Constants.UnspecifiedId, string.Empty,
							Constants.UnspecifiedId, string.Empty,
							string.Empty);
		}
		#endregion

		/// <summary>
		/// Sriram.Get all the info from SSVATributes for SSV Monitoring Initiate Request.
		/// </summary>
		/// <param name="projectId"></param>
		/// <returns></returns>
		public static List<SSVAttributeIR_WS> GetSSVAttributesForInitiateRequest(int projectId)
		{
			List<SSVAttributeIR_WS> ssvAttrList = new List<SSVAttributeIR_WS>();
			IList<SSVAttribute> ssvattr = SSVAttribute.FindByProjectId(projectId);
			foreach (SSVAttribute ssv in ssvattr)
			{
				ssvAttrList.Add(new SSVAttributeIR_WS(ssv));
			}
			return ssvAttrList;
		}

		public void GenerateFromQIPDataOrDefaultCalculator()
		{
			DbHelp.ExecuteScalarSP("dbo.GenerateSsvCalculatorsFromQipClinicalFinal",
									new SqlParameter("@ssvAttributeId", Id),
									new SqlParameter("@projectId", ProjectId),
									new SqlParameter("@countryId", CountryId)
									);

			GenerateDefaultSSVCalculatorsIfMissing();
		}

		public void GenerateDefaultSSVCalculatorsIfMissing()
		{
			IList<FTECalculator> calculators = FTECalculator.GetSsvCalculatorsByAttributeId(Id, false);

			foreach (var calculatorTypeId in RequiredCalculatorTypeIds)
			{
				if (calculators.Where(c => c.TypeId == calculatorTypeId).Count() == 0)
				{
					var defaultCalulatorValues = MonitoringCalculatorDefaultValue.GetDefaultCalculatorValues(CalculatorGroup_E.SsvCalculator, (CalculatorType_E)calculatorTypeId);
					new FTECalculator
					{
						ProjectId = ProjectId,
						CountryId = CountryId,
						CalculatorTypeId = (int)defaultCalulatorValues.CalculatorTypeId,
						TypeId = (int)defaultCalulatorValues.TypeId,
						SsvAttributeId = Id,
						SIVPerSite = defaultCalulatorValues.SIVPerSite,
						VisitFrequency = defaultCalulatorValues.VisitFrequency,
						ClusterTravelTime = defaultCalulatorValues.ClusterTravelTime,
						OnSiteTime = defaultCalulatorValues.OnSiteTime,
						PrepFollowUpTime = defaultCalulatorValues.PrepFollowUpTime,
						PhoneSIVPerSite = defaultCalulatorValues.PhoneSIVPerSite,
						PhoneVisitFrequency = defaultCalulatorValues.PhoneVisitFrequency,
						PhoneVisitTime = defaultCalulatorValues.PhoneVisitTime,
						PhonePrepFollowUpTime = defaultCalulatorValues.PrepFollowUpTime,
						AdminTime = defaultCalulatorValues.AdminTime,
						SSVPerSite = defaultCalulatorValues.SSVPerSite,
						PhoneSSVPerSite = defaultCalulatorValues.PhoneSSVPerSite,
						Fte = CalculatorUtility.CalculateAverageFte(defaultCalulatorValues.TotalOnsiteHours, CountryId),
						PhoneFte = CalculatorUtility.CalculateAverageFte(defaultCalulatorValues.TotalPhoneHours, CountryId),
						IsConnectedToQip = false,
						OnSiteEstimatedNumberOfSites = 0,
						PhoneEstimatedNumberOfSites = 0
					}.SaveAndFlush();
				}
			}

		}

		public static IEnumerable<ICountryAttribute> FindByAttributeIdList(List<int> attributeIdList)
		{
			var dc = DetachedCriteria.For(typeof(SSVAttribute));
			dc.Add(Expression.In("Id", attributeIdList.ToArray()));
			return SSVAttribute.FindAll(dc).Cast<ICountryAttribute>();
		}

		public static bool IsCountryActive(int projectId, int countryId)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(SSVAttribute));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("CountryId", countryId));
			criteria.Add(Expression.Eq("IsActive", 1));
			SSVAttribute ssvAttr = SSVAttribute.FindOne(criteria);
			return ssvAttr != null ? true : false;
		}

		public static void UpdateSIFSent(int projectId, int countryId)
		{
			DbHelp.ExecuteScalarSP("dbo.SSV_UpdateSIFDetails", ConfigValue.CommandTimeout, new SqlParameter("@ProjectId", projectId), new SqlParameter("@CountryId", countryId), new SqlParameter("@User", ExtensionMethods.GetCurrentUserQid()));
		}

		public static void ConnectSingleSsvValueToQip(int ssvAttributeId, string columnName, int connectedValue)
		{
			var sa = Find(ssvAttributeId);
			if (!string.IsNullOrEmpty(columnName))
			{
				switch (columnName.ToUpper())
				{
					case "QIPBUDGETEDSITES":
						sa.IsQipBudgetedSitesConnected = true;
						sa.QipBudgetedSites = sa.QipBudgetedSitesConnectedValue;
						break;
					default:
						break;
				}
				sa.SaveAndFlush();
			}
		}

		public static void UpdateBudgetedSites(int projectId, int countryId, int? budgetedSites)
		{
			if (budgetedSites.HasValue)
			{
				var attribute = FindByProjectIdCountryId(projectId, countryId, false);
				if (attribute != null && attribute.BudgetedSites != budgetedSites)
				{
					attribute.BudgetedSites = budgetedSites;
					attribute.SaveAndFlush();
				}
			}
		}
	}
}
