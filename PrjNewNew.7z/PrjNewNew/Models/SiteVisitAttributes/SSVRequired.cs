﻿using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
    [ActiveRecord(Table = "SSVRequired")]
	public class SSVRequired : AbstractActiveRecordBaseModel<SSVRequired>
    {
        [PrimaryKey(Column = "SSVRequiredId", UnsavedValue = "-1")]
        public override int Id { set { this._id = value; } get { return this._id; } }

        [Property(Column = "Name")]
        public string Name { set; get; }


        public static SSVRequired FindByEnum(SSVRequired_E requiredName)
        {
            return SSVRequired.Find((int)requiredName);
        }
    }
}


