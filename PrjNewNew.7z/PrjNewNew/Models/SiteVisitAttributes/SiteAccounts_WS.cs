﻿using System;
using System.Runtime.Serialization;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public class SiteAccount_WS
	{
		[DataMember(IsRequired = false)]
		public String SiteAccountRowId;
		[DataMember(IsRequired = false)]
		public String AccountName1;
		[DataMember(IsRequired = false)]
		public String AccountName2;
		[DataMember(IsRequired = false)]
		public String ParentAccountName;
		[DataMember(IsRequired = false)]
		public String RelationshipManagerQid;
		[DataMember(IsRequired = false)]
		public String RelationshipManagerFirstName;
		[DataMember(IsRequired = false)]
		public String RelationshipManagerLastName;

	}

}
