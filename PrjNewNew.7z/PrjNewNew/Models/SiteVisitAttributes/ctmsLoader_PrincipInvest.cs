using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class ctmsLoader_PrincipInvest : AbstractActiveRecordBaseModel<ctmsLoader_PrincipInvest>
	{
		#region Properties
		[PrimaryKey(Column = "PrincipalInvestigatorId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public int ctmsLoader_MessageId { get; set; }
		[Property]
		public int IsHandled { get; set; }

		[Property]
		public string GivenName { get; set; }
		[Property]
		public string Surname { get; set; }
		[Property]
		public string FirstName { get; set; }
		[Property]
		public string LastName { get; set; }
		[Property]
		public string Title { get; set; }
		[Property]
		public string MiddleName { get; set; }
		[Property]
		public string DisplayName { get; set; }
		[Property]
		public string PreceedingTitle { get; set; }
		[Property]
		public string OtherName { get; set; }
		[Property]
		public string Suffix { get; set; }
		[Property]
		public string GenerationQualifier { get; set; }
		[Property]
		public string NameType { get; set; }
		[Property]
		public string ExternalId { get; set; }
		#endregion

		/// <summary>
		/// default constructor required by hibernate
		/// </summary>
		public ctmsLoader_PrincipInvest() { }

		/// <summary>
		/// init with person data contract
		/// </summary>
		/// <param name="person"></param>
		public ctmsLoader_PrincipInvest(PersonNameType_WS person)
		{
			GivenName = person.GivenName;
			Surname = person.Surname;
			FirstName = person.FirstName;
			LastName = person.LastName;
			Title = person.Title;
			MiddleName = person.MiddleName;
			DisplayName = person.DisplayName;
			PreceedingTitle = person.PreceedingTitle;
			OtherName = person.OtherName;
			Suffix = person.Suffix;
			GenerationQualifier = person.GenerationQualifier;
			NameType = person.NameType;
			ExternalId = person.ExternalId;
		}
	}
}
