using System.Collections.Generic;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "SSVType")]
	public class SSVType : AbstractActiveRecordBaseModel<SSVType>
	{
		[PrimaryKey(Column = "SSVTypeId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property(Column = "Name")]
		public string Name { set; get; }
		
		[Property]
		public virtual bool IsVisible { set; get; }

		public static SSVType FindByEnum(SSVType_E enumValue)
		{
			return SSVType.Find((int)enumValue);
		}

		internal static SSVType CreateOneFromReader(System.Data.IDataReader r)
		{
			SSVType ssvt = null;
			var cc = new ColumnChecker(r);

			if (r != null && cc.HasColumn("SSVTypeId") && !(r["SSVTypeId"] is System.DBNull))
			{
				ssvt = CacheService.SSVTypes[DbSafe.Int(r["SSVTypeId"])];
			}

			return ssvt;
		}

		internal static List<KeyValue_WS> GetSSVType()
		{
			List<KeyValue_WS> ssvTypeList = new List<KeyValue_WS>();
			KeyValue_WS ssvType;
			DetachedCriteria filter = DetachedCriteria.For(typeof(SSVType));
			filter.Add(Expression.Eq("IsVisible", 1));
			var ssvTypeValues =  SSVType.FindAll(filter);
			foreach (SSVType ssvt in ssvTypeValues)
			{
				ssvType = new KeyValue_WS();
				ssvType.Key = ssvt.Id;
				ssvType.Value = ssvt.Name;
				ssvTypeList.Add(ssvType);
			}
			return ssvTypeList;
		}
	}
}