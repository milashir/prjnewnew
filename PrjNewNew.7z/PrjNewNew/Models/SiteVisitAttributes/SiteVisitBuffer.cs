﻿using System;
using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RPM.Common;
using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	// CTMS data
	public class ProtocolSiteType
	{
		public String StudyStatus { get; set; } // Project (useless because redondent)
		public String ProgramID { get; set; } // Project (useless because redondent)
		public String ProgramName { get; set; } // Project (useless because redondent)
		public String ProtocolIdentifier { get; set; } // Project
		public String StudyID { get; set; } // Project (useless because redondent)
		public String ProjectCode { get; set; } // Project
		public String SiteID { get; set; } // Site => ExternalSiteID
		public String SponsorSiteID { get; set; } // 
		public String PrincipalInvestigator { get; set; } // Site (overwrite previous value)
		public List<SiteAddressList> SiteAddressList { get; set; }
		public String SiteStatus { get; set; } // Site
		public String SiteSelectVisitRequired { get; set; } // Site
		public String SiteSelectVisitType { get; set; } // Site
		public List<Visit> Visits { get; set; }
		public List<MileStone> MileStones { get; set; }
		public String SourceSystemID { get; set; } // Site
		public String SourceSystem { get; set; } // Site
	}

    public class Visit
    {
        public String VisitType { get; set; } // enum: SSV-SIV
        public DateTime PlannedVisitDate { get; set; }
        public DateTime ContractedVisitDate { get; set; }
        public DateTime ActualVisitDate { get; set; }
        public String SiteVisitSection { get; set; }
        public String UnblindedFlag { get; set; }
    }

	// Site Milestone
    public class MileStone
    {
        public String MilestoneType { get; set; } // enum
        public DateTime PlannedDate { get; set; } // Projected (cannot be null)
        public DateTime ContractedDate { get; set; } // not use
        public DateTime ActualDate { get; set; } // 
    }

    public class SiteAddressList
    {
		public string StreetAddress1  { get; set; }
		public string StreetAddress2  { get; set; }
		public string StreetAddress3  { get; set; }
		public string City { get; set; }
		public string PostalCode { get; set; }
		public string State { get; set; }
		// No CountryRegion for now ?
		public string Country { get; set; }
        public String ClusterCode { get; set; }
        public String ClusterName { get; set; }
    }

    [ActiveRecord(Table = "SiteVisit")]
    public class SiteVisit : AbstractBaseReadWriteModel<SiteVisit>
    {
        public SiteVisit()
            : base()
        {

        }

        [PrimaryKey(Column = "SiteVisitId", UnsavedValue = "-1")]
        public override int Id { set { this._id = value; } get { return this._id; } }

        public override string Name
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        public String StudyStatus { get; set; }
        public String ProgramID { get; set; }
        public String ProgramName { get; set; }
        public String ProtocolIdentifier { get; set; }
        public int StudyID { get; set; }
        public String ProjectCode { get; set; }
        public String SiteID { get; set; }
        public String SponsorSiteID { get; set; }
        public String PrincipalInvestigator { get; set; }
        public Address SiteAddress { get; set; }
        public String SiteStatus { get; set; }
        public String SiteSelectVisitRequired { get; set; }
        public String SiteSelectVisitType { get; set; }
        public List<Visit> Visits { get; set; }
        public List<MileStone> Milestones { get; set; }
        public String SiteVisitSection { get; set; }
        public String UnblindedFlag { get; set; }

    }

    [ActiveRecord(Table = "SiteVisitBuffer")]
    public class SiteVisitBuffer : AbstractBaseReadWriteModel<SiteVisitBuffer>
    {
        public SiteVisitBuffer()
            : base()
        {

        }

        #region Properties

        [PrimaryKey(Column = "SiteVisitBufferId", UnsavedValue = "-1")]
        public override int Id { set { this._id = value; } get { return this._id; } }

        public override string Name { get; set; }

        [Property]
        public virtual int ExternalId { get; set; }

        [Property]
        public virtual string ExternalSource { get; set; }

        [Property]
        public virtual DateTime? ExternalTimestamp { get; set; }

        [Property]
        public virtual String StudyStatus { get; set; }

        [Property]
        public virtual String ProgramID { get; set; }
        [Property]
        public virtual String ProgramName { get; set; }
        [Property]
        public virtual String ProtocolIdentifier { get; set; }
        [Property]
        public virtual String ProtocolNumber { get; set; }
        [Property]
        public virtual String StudyID { get; set; }
        [Property]
        public virtual String ProjectCode { get; set; }
        [Property]
        public virtual String SiteID { get; set; }
        [Property]
        public virtual String SponsorSiteID { get; set; }

        //Principal Investigator
        [Property]
        public virtual String FirstName { get; set; }
        [Property]
        public virtual String LastName { get; set; }

        //SiteAddress
        [Property]
        public virtual String AddressType { set; get; }
        [Property]
        public virtual String Address1 { set; get; }
        [Property]
        public virtual String Address2 { set; get; }
        [Property]
        public virtual String Address3 { set; get; }
        [Property]
        public virtual String City { set; get; }
        [Property]
        public virtual String StateProvince { set; get; }
        [Property]
        public virtual String PostalZipCode { set; get; }
        [Property]
        public virtual String Country { set; get; }

        [Property]
        public virtual String SiteStatus { get; set; }
        [Property]
        public virtual String SiteSelectVisitRequired { get; set; }
        [Property]
        public virtual String SiteSelectVisitType { get; set; }

        //Visit
        [Property]
        public virtual String VisitType { get; set; }
        [Property]
        public virtual DateTime? PlannedVisitDate { get; set; }
        [Property]
        public virtual DateTime? ContractedVisitDate { get; set; }
        [Property]
        public virtual DateTime? ActualVisitDate { get; set; }

        //Milestone
        [Property]
        public virtual String MilestoneType { get; set; }
        [Property]
        public virtual DateTime? PlannedDate { get; set; }
        [Property]
        public virtual DateTime? ContractedDate { get; set; }
        [Property]
        public virtual DateTime? ActualDate { get; set; }


        //Cluster
        [Property]
        public virtual String ClusterNameResource { get; set; }
        [Property]
        public virtual String ClusterNameSite { get; set; }

        [Property]
        public virtual String SiteVisitSection { get; set; }
        [Property]
        public virtual String UnblindedFlag { get; set; }


        #endregion


        /// <summary>
        /// Get Site Data based on SystemID
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="countryId"></param>
        /// <param name="typeName"></param>
        /// <returns></returns>

        public static SiteVisitBuffer FindByExternalId(int ExternalId)
        {
            DetachedCriteria criteria = DetachedCriteria.For(typeof(SiteVisitBuffer));
            criteria.Add(Expression.Eq("ExternalId", ExternalId));
            SiteVisitBuffer returnData = SiteVisitBuffer.FindFirst(criteria);
            return returnData;
        }

    }
}
