﻿using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "MileStoneType")]
	public class MileStoneType : AbstractActiveRecordBaseModel<MileStoneType>
	{
		[PrimaryKey(Column = "MileStoneTypeId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property(Column = "Name")]
		public string Name { set; get; }

		public static MileStoneType FindByEnum(MileStoneType_E enumValue)
		{
			return MileStoneType.Find((int)enumValue);
		}


	}
}