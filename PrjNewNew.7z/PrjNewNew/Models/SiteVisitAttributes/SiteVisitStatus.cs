﻿using Castle.ActiveRecord;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum SiteVisitStatus_E
	{
		Planned = 1,
		Confirmed = 2,
		DocumentsCompleted = 3,
		VisitCompleted = 4
	}
	[ActiveRecord(Table = "cd_SiteVisitStatus")]
	public class SiteVisitStatus : AbstractActiveRecordBaseModel<SiteVisitStatus>
	{
		[PrimaryKey(Column = "SiteVisitStatusId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property(Column = "SiteVisitStatusName")]
		public string Name { set; get; }

		[Property]
		public string Inntraxvalue { set; get; }

		[Property]
		public string Ctmsvalue { set; get; }

		

		public static SiteVisitStatus Find(SiteVisitStatus_E SVStatus)
		{
			return SiteVisitStatus.Find((int)SVStatus);
		}
	}
}
