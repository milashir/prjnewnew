﻿using Castle.ActiveRecord;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum SiteVisitReportStatus_E
	{
		Abandoned = 1,
		Approved = 2,
		Cancelled = 3,
		Closed = 4,
		ExceptionHandling = 5,
		InProgress = 6,
		NotStarted = 7,
		Open = 8,
		Pending = 9,
		Quoted = 10,
		Rejected = 11,
		Returned = 13,
		Revised = 13,
		Signed = 14,
		Submitted = 15
	}



	[ActiveRecord(Table = "cd_SiteVisitReportStatus")]
	public class SiteVisitReportStatus : AbstractActiveRecordBaseModel<SiteVisitReportStatus>
	{
		[PrimaryKey(Column = "SiteVisitReportStatusId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property(Column = "SiteVisitReportStatusName")]
		public string Name { set; get; }
	}
}
