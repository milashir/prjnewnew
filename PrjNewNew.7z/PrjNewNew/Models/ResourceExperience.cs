﻿using System;
using System.Collections.Generic;
using Castle.ActiveRecord;


namespace Quintiles.RM.Clinical.Domain.Models
{
	public interface ICriteriaResult
	{
		//Resource Resource { get; }
		int ResourceId { get; }
		int CriteriaMatch { get; }
	}


	[ActiveRecord(Table = "ResourceEducation")]
	public class ResourceEducation : AbstractActiveRecordBaseModel<ResourceEducation>
	{
		[PrimaryKey(Column = "ResourceEducationId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ResourceId { get; set; }

		[Property]
		public string QId { get; set; }

		[Property]
		public String EducationLevelDegree { get; set; }

		public static String GetList(int resourceId)
		{
			ResourceEducation[] myList = ResourceEducation.FindAllByProperty("ResourceId", resourceId);
			List<String> eduList = new List<string>();
			foreach (ResourceEducation re in myList)
			{
				eduList.Add(re.EducationLevelDegree);
			}

			return String.Join(", ", eduList.ToArray());
		}
	}

	public class ResourceOrganization : ICriteriaResult
	{
		public int ResourceId { get; set; }
		public int OrganizationalUnitId { get; set; }

		public int CriteriaMatch { get { return OrganizationalUnitId; } }
	}

	[ActiveRecord(Table = "ResourceStudyPhase")]
	public class ResourceStudyPhase : AbstractActiveRecordBaseModel<ResourceStudyPhase>, ICriteriaResult
	{
		[PrimaryKey(Column = "ResourceStudyPhaseId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ResourceId { get; set; }

		[Property]
		public string QId { get; set; }

		[Property]
		public bool IsQ { get; set; }

		[Property]
		public int StudyPhaseId { get; set; }

		public int CriteriaMatch { get { return StudyPhaseId; } }
	}

	[ActiveRecord(Table = "ResourceCustomer")]
	public class ResourceCustomer : AbstractActiveRecordBaseModel<ResourceCustomer>, ICriteriaResult
	{
		[PrimaryKey(Column = "ResourceCustomerId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ResourceId { get; set; }

		[Property]
		public string QId { get; set; }

		[Property]
		public int CustomerId { get; set; }

		[Property]
		public int StudyPhaseId { get; set; }

		[Property]
		public String Role { get; set; }

		public int CriteriaMatch { get { return CustomerId; } }
	}

	[ActiveRecord(Table = "ResourceLanguage")]
	public class ResourceLanguage : AbstractActiveRecordBaseModel<ResourceLanguage>, ICriteriaResult
	{
		[PrimaryKey(Column = "ResourceLanguageId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ResourceId { get; set; }

		[Property]
		public string QId { get; set; }

		[Property]
		public int LanguageId { get; set; }

		[Property]
		public string SpeakingProficiency { get; set; }
		[Property]
		public string ReadingProficiency { get; set; }
		[Property]
		public string WritingProficiency { get; set; }

		public int CriteriaMatch { get { return LanguageId; } }
	}


	[ActiveRecord(Table = "ResourceTherapeuticIndication")]
	public class ResourceTherapeuticIndicationBase : AbstractActiveRecordBaseModel<ResourceTherapeuticIndicationBase>
	{
		[PrimaryKey(Column = "ResourceTherapeuticIndicationId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ResourceId { get; set; }

		[Property]
		public string QId { get; set; }
	}

	[ActiveRecord(Table = "ResourceTherapeuticIndication")]
	public class ResourceTherapeuticArea : ResourceTherapeuticIndicationBase, ICriteriaResult
	{
		[Property]
		public int TherapeuticAreaId { get; set; }

		[Property]
		public string TherapeuticAreaYears { get; set; }

		public int CriteriaMatch { get { return TherapeuticAreaId; } }
	}

	[ActiveRecord(Table = "ResourceTherapeuticIndication")]
	public class ResourceIndication : ResourceTherapeuticIndicationBase, ICriteriaResult
	{
		[Property]
		public int IndicationId { get; set; }

		[Property]
		public string IndicationYears { get; set; }

		public int CriteriaMatch { get { return IndicationId; } }
	}

	[ActiveRecord(Table = "ResourceExperienceType")]
	public class ResourceExperienceType : AbstractActiveRecordBaseModel<ResourceExperienceType>, ICriteriaResult
	{
		[PrimaryKey(Column = "ResourceExperienceTypeId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ResourceId { get; set; }

		[Property]
		public string QId { get; set; }
		[Property]
		public string Department { get; set; }
		[Property]
		public int ExperienceTypeId { get; set; }
		[Property]
		public string NumYears { get; set; }

		public int CriteriaMatch { get { return ExperienceTypeId; } }
	}

}
