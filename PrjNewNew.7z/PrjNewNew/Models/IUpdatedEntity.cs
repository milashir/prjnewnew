﻿
namespace Quintiles.RM.Clinical.Domain.Models
{
    public interface IUpdatedEntity : IEntity
    {
    }
}
