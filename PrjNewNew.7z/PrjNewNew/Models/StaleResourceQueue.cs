﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class StaleResourceQueue : AbstractActiveRecordBaseModel<StaleResourceQueue>
	{
		[PrimaryKey(Column = "StaleResourceQueueId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public int ResourceId { get; set; }

		[Property]
		public string LockedBy { get; set; }

		[Property]
		public DateTime? LockedOn { get; set; }

		public static SortedDictionary<int, int> GetResourceIdsFromStaleResourceQueue(int maxRecordCount)
		{
			var resourceList = new SortedDictionary<int, int>();

			using (var dr = DbHelp.ExecuteDataReaderSP("GetStaleResourceFifoQueue", new SqlParameter("serverName", ExtensionMethods.GetCurrentServerName()), new SqlParameter("maxRecordCount", maxRecordCount)))
			{
				try
				{
					while (dr.Read())
					{
						resourceList.Add(DbSafe.Int(dr["StaleResourceQueueId"]), DbSafe.Int(dr["ResourceId"]));
					}
				}
				finally { dr.Close(); }
			}

			return resourceList;
		}

		public static void UpdateThreadGuid(string threadGuid, int[] staleResourceQueueIdList)
		{
			var sql = string.Format(@"UPDATE  dbo.StaleResourceQueue WITH ( ROWLOCK, READPAST ) 
                        SET     ThreadGuid = '{0}'
                        WHERE   StaleResourceQueueId IN ({1})", DbSafe.EscapeQuote(threadGuid), string.Join(",", staleResourceQueueIdList.Select(v => v.ToString()).ToArray()));
			DbHelp.ExecuteNonQueryText(sql);
		}

		public static void DeleteProcessedResources(string threadGuid)
		{
			//StaleResourceQueue.DeleteAll(string.Format("ThreadGuid='{0}'", DbSafe.EscapeQuote(threadGuid)));
			//because of the deadlock we use query instead of active record.
			var sql = string.Format(@"DELETE FROM dbo.StaleResourceQueue  WITH ( ROWLOCK, READPAST ) WHERE ThreadGuid='{0}'", DbSafe.EscapeQuote(threadGuid));
			DbHelp.ExecuteNonQueryText(sql);
		}
	}
}
