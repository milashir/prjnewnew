﻿using System.Collections.Generic;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public class PagedResponse<TRecords, TAdditionalData>
		where TRecords : class
		where TAdditionalData : class
	{
		public int TotalPages { get; set; }
		public int TotalRecords { get; set; }
		public int PageNumber { get; set; }
		public IList<TRecords> Records { get; set; }
		public TAdditionalData AdditionalData { get; set; }
	}
}
