﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// Represents a comment (aka note) for any entity in the system
	/// </summary>
	/// <author>Colin B. Boatwright</author>
	[ActiveRecord(Table = "EntityComment")]
	public class EntityComment : AbstractActiveRecordBaseModel<EntityComment>
	{
		#region Mapped Properties

		[PrimaryKey(Column = "EntityCommentId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public virtual int RefEntityId { get; set; }

		[BelongsTo("EntityTypeId")]
		public virtual EntityType RefEntityType { get; set; }

		[Property]
		public virtual bool IsImportant { get; set; }

		[Property]
		public virtual bool IsPrivate { get; set; }

		[Property]
		public virtual string Comment { get; set; }

		[Property]
		public virtual int SearchLevel { get; set; }

		[BelongsTo("CountryId")]
		public virtual Country Country { get; set; }
		[BelongsTo("RegionId")]
		public virtual Region Region { get; set; }
		[BelongsTo("ProjectId")]
		public virtual Project Project { get; set; }

		[BelongsTo("ResourceTypeId")]
		public virtual ResourceType ResourceType { get; set; }

		[BelongsTo("ProjectJobRoleId")]
		public virtual ProjectJobRole ProjectJobRole { get; set; }

		[BelongsTo("CommentTypeId")]
		public virtual CommentType CommentType { get; set; }

		[Property]
		public bool BackfillCommentFixed { get; set; }

		#endregion

		public string Name
		{
			get
			{
				return "Comment#" + RefEntityType.Id + "#" + RefEntityId;
			}
			set
			{
				throw new NotImplementedException();
			}
		}
		public string ResourceName { get; set; }
		public string SiteName { get; set; }
		public string City { get; set; }
		public string PrincipalInvestigator { get; set; }
		public string CommentHeaderIcon
		{
			get
			{
				string iconHtml = string.Empty;
				if (RefEntityType.Id == 6)
				{
					if (CommentType != null)
					{
						CommentTypeName ct = (CommentTypeName)(Enum.Parse(typeof(CommentTypeName), CommentType.Id.ToString()));
						switch (ct)
						{
							case CommentTypeName.BackfillComments:
								iconHtml = Request.FindOneById(RefEntityId).BackfillIconHtml;
								break;
							case CommentTypeName.ReturnDetails:
								iconHtml = "<img src='/_layouts/SPUI/images/returnRequest.png' title='Return Details' />";
								break;
							case CommentTypeName.ProposalBidDefense:
								iconHtml = "<img src='/_layouts/SPUI/images/proposalIcon.png' title='Bid Defense Details' />";
								break;
							case CommentTypeName.RejectedSoftBook:
								iconHtml = "<img src='/_layouts/SPUI/images/iconRejectSoftBooking.png' title='Reject Soft Booking' />";
								break;
						}
					}
				}
				else if (RefEntityType.Id == 7)
				{
					if (CommentType != null && CommentType.Id == (int)CommentTypeName.ProposalBidDefense)
					{
						iconHtml = "<img src='/_layouts/SPUI/images/bidDefense.png' title='Bid Defense Details' />";
					}
				}
				return iconHtml;
			}
		}

		public string CommentHeader
		{
			get
			{
				string returnValue = string.Empty;
				switch (RefEntityType.Id)
				{
					case 1:
						returnValue = "Project Level";
						break;
					case 2:
						returnValue = "Region Level";
						break;
					case 3:
						returnValue = string.Format("{0} - SSV Attributes Level", Country == null ? string.Empty : Country.CountryCode);
						break;
					case 4:
						returnValue = string.Format("{0} - Monitoring Attributes Level", Country == null ? string.Empty : Country.CountryCode);
						break;
					case 5:
						returnValue = "Contractual Requirements Level";
						break;
					case 6:
						string commentType = string.Empty;
						if (CommentType != null)
						{
							CommentTypeName ct = (CommentTypeName)(Enum.Parse(typeof(CommentTypeName), CommentType.Id.ToString()));
							switch (ct)
							{
								case CommentTypeName.ResubmitComments:
									commentType = "Resubmit comments";
									break;
								case CommentTypeName.BackfillComments:
									commentType = "Backfill comments";
									break;
								case CommentTypeName.ReturnDetails:
									commentType = "Return Details";
									break;
								case CommentTypeName.ProposalBidDefense:
									commentType = "Bid Defense Details";
									break;
								case CommentTypeName.RejectedSoftBook:
									commentType = "Rejection Details";
									break;
							}
							commentType = string.Format(" - {0}", commentType);
						}
						returnValue = string.Format("{0}{1}{2} - Request Level",
								string.IsNullOrEmpty(PrincipalInvestigator) ? string.Empty : string.Format(" {0} - ", PrincipalInvestigator),
								string.IsNullOrEmpty(City) ? string.Empty : string.Format("{0} - ", City),
								string.IsNullOrEmpty(SiteName) ? Constants.NoSite : string.Format("{0} - ", SiteName),
								commentType);
						break;
					case 7:
						returnValue = "Resource Level";
						break;
					case 8:
						returnValue = "Assignment Details";
						break;
				}
				return returnValue;
			}
		}

		public override bool ShouldSerializeLastModifiedBy() { return true; }  //!JSON
		public override bool ShouldSerializeLastModifiedOn() { return true; }  //!JSON

		#region custom CRUD operations

		public virtual void CreateAndFlush(int entityId, EntityTypes entityType, string comment)
		{
			RefEntityId = entityId;
			RefEntityType = new EntityType { Id = (int)entityType };
			Comment = comment;
			base.CreateAndFlush();
		}

		public static void DeleteAndFlush(int entityId, EntityTypes entityType)
		{
			IList<EntityComment> comments = FindEntityComments(entityId, entityType, true);
			comments.Each<EntityComment>(c =>
			{
				c.DeleteAndFlush();
			});
		}

		#endregion

		#region Notes icon for grid
		public static string GetNotesColumnValueForProject()
		{
			return string.Empty;
		}

		public static string GetNotesColumnValueForSpecialAssignment()
		{
			return string.Empty;
		}

		public static string GetNotesColumnValueForStaff()
		{
			return string.Empty;
		}

		public static string GetNotesColumnValueForSsvAttribute()
		{
			return string.Empty;
		}

		public static string GetNotesColumnValueForMonitoringAttribute()
		{
			return string.Empty;
		}
		#endregion

		#region Public static finder methods

		public static IList<EntityComment> FindEntityComments(int projectId, SearchLevel SearchLevel, int displayFromLastXDays)
		{

			DetachedCriteria criteria = DetachedCriteria.For(typeof(EntityComment));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("SearchLevel", (int)SearchLevel));
			if (displayFromLastXDays > 0)
			{
				criteria.Add(Expression.Ge("CreatedOn", DateTime.Today.AddDays(-1 * displayFromLastXDays)));
			}
			criteria.Add(Expression.Or(Expression.Eq("IsPrivate", false), Expression.Eq("CreatedBy", ExtensionMethods.GetCurrentUserQid())));
			criteria.AddOrder(new Order("LastModifiedOn", false));

			return FindAll(criteria);
		}

		public static IList<EntityComment> FindEntityComments(int entityId, EntityTypes entityType, bool getEntityOnlyComments)
		{
			int entityTypeId = (int)entityType;
			List<EntityComment> comments = new List<EntityComment>();
			var sql = string.Format("select * from dbo.ufn_GetComments({0},{1},{2},{3})", entityId, entityTypeId, getEntityOnlyComments ? 1 : 0, 0);

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						EntityComment comment = new EntityComment
						{
							Comment = dr["Comment"].ToString(),
							CreatedBy = dr["CreatedBy"].ToString(),
							ResourceName = dr["ResourceName"].ToString(),
							CreatedOn = DateTime.Parse(dr["CreatedOn"].ToString()),
							Id = int.Parse(dr["EntityCommentId"].ToString()),
							IsImportant = (dr["IsImportant"].ToString() == "1"),
							IsPrivate = (dr["IsPrivate"].ToString() == "1"),
							LastModifiedBy = dr["LastModifiedBy"].ToString(),
							LastModifiedOn = DateTime.Parse(dr["LastModifiedOn"].ToString()),
							RefEntityId = int.Parse(dr["RefEntityId"].ToString()),
							RefEntityType = new EntityType { Id = int.Parse(dr["EntityTypeId"].ToString()), Name = ((EntityTypes)Enum.Parse(typeof(EntityTypes), dr["EntityTypeId"].ToString())).ToString() },
							SiteName = dr["SiteName"] is System.DBNull ? String.Empty : dr["SiteName"].ToString(),
							City = dr["City"] is System.DBNull ? String.Empty : dr["City"].ToString(),
							PrincipalInvestigator = dr["PrincipalInvestigator"] is System.DBNull ? String.Empty : dr["PrincipalInvestigator"].ToString(),
							CommentType = CommentType.CreateFromReader(dr),
							Country = Country.CreateFromReader(dr),
							Project = Project.CreateFromReader(dr),
							ProjectJobRole = ProjectJobRole.CreateFromReader(dr),
							Region = Region.CreateFromReader(dr),
							ResourceType = ResourceType.CreateFromReader(dr),
							BackfillCommentFixed = DbSafe.Bool(dr["BackfillCommentFixed"])
						};

						comments.Add(comment);
					}
				}
				finally { dr.Close(); }
			}

			return comments;
		}

		public static IList<EntityComment> FindReturnDetails(int requestId)
		{
			List<EntityComment> comments = new List<EntityComment>();
			using (var dr = DbHelp.ExecuteDataReaderSP("GetReturnRequestDetails", new System.Data.SqlClient.SqlParameter("entityId", requestId)))
			{
				try
				{
					while (dr.Read())
					{
						EntityComment comment = new EntityComment
						{
							Comment = dr["Comment"].ToString(),
							CreatedBy = dr["CreatedBy"].ToString(),
							ResourceName = dr["ResourceName"].ToString(),
							CreatedOn = DateTime.Parse(dr["CreatedOn"].ToString()),
							Id = int.Parse(dr["EntityCommentId"].ToString()),
							IsImportant = (dr["IsImportant"].ToString() == "1"),
							IsPrivate = (dr["IsPrivate"].ToString() == "1"),
							LastModifiedBy = dr["LastModifiedBy"].ToString(),
							LastModifiedOn = DateTime.Parse(dr["LastModifiedOn"].ToString()),
							RefEntityId = int.Parse(dr["RefEntityId"].ToString()),
							RefEntityType = new EntityType { Id = int.Parse(dr["EntityTypeId"].ToString()), Name = ((EntityTypes)Enum.Parse(typeof(EntityTypes), dr["EntityTypeId"].ToString())).ToString() },
							SiteName = dr["SiteName"] is System.DBNull ? String.Empty : dr["SiteName"].ToString(),
							PrincipalInvestigator = dr["PrincipalInvestigator"] is System.DBNull ? String.Empty : dr["PrincipalInvestigator"].ToString(),
							CommentType = CommentType.CreateFromReader(dr),
							Country = Country.CreateFromReader(dr),
							Project = Project.CreateFromReader(dr),
							ProjectJobRole = ProjectJobRole.CreateFromReader(dr),
							Region = Region.CreateFromReader(dr),
							ResourceType = ResourceType.CreateFromReader(dr),
						};

						comments.Add(comment);
					}
				}
				finally { dr.Close(); }
			}

			return comments;
		}

		public static List<ReadonlyNotesResponse_WS> GetReadonlyNotes(List<ReadonlyNotes_WS> requestIds)
		{
			var retrunNotes = new List<ReadonlyNotesResponse_WS>();
			foreach (ReadonlyNotes_WS item in requestIds)
			{
				var entityType = (EntityTypes)Enum.Parse(typeof(EntityTypes), item.entityType.ToString());
				var comments = EntityComment.FindEntityComments(item.entityId, entityType, false);
				StringBuilder sb = new StringBuilder();
				if (comments != null && comments.Count > 0)
				{
					foreach (Quintiles.RM.Clinical.Domain.Models.EntityComment comment in comments)
					{
						sb.Append(comment.GetNoteHtml(HttpContext.Current.Request.GetTimezoneOffset(), string.Empty, string.Empty));
					}
				}
				retrunNotes.Add(new ReadonlyNotesResponse_WS { tabId = item.entityId, tabData = sb.ToString() });
			}
			return retrunNotes;
		}
		#endregion

		public string GetNoteHtml(int timezoneOffset, string editImage, string deleteImage)
		{
			bool isEditable = false;//Disabling edit delete untill siteadmin permission is available (CreatedBy == Common.GetCurrentUserQid());

			var sb = new StringBuilder();
			sb.AppendFormat(@"<div commentid=""{0}"" class=""entityComment{1}"" editable=""{2}"" isediting=""false"">",
												Id,
												isEditable ? " editable" : string.Empty,
												isEditable.ToString().ToLower());
			sb.AppendFormat(@"<div class=""messageAuthor"">{0} {1} - {2} - {3}{4}{5}{6}</div>",
												CommentHeaderIcon,
												ResourceName,
												CommentHeader,
												LastModifiedOn.ToQDateTimeString(timezoneOffset),
												isEditable ? deleteImage : string.Empty,
												isEditable ? editImage : string.Empty,
												BackfillCommentFixed ? " (NB: System default date)" : string.Empty);

			sb.AppendFormat(@"<span class=""messageContent"">{0}</span>", Comment);
			sb.Append("</div>");

			return sb.ToString();
		}
	}
}
