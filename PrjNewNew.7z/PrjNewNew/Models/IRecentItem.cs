﻿
namespace Quintiles.RM.Clinical.Domain.Models
{
    public interface IRecentItem : IEntity
    {
        string TypeName { get; }

    }
}
