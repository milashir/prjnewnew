﻿using System;
using System.Collections.Generic;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[Serializable]
	public class RMException : Exception
	{
		public string ErrorMessage
		{
			get
			{
				return base.Message.ToString();
			}
		}

		public int ID { get; set; }
		public RMException(string errorMessage)
			: base(errorMessage) { }

		public RMException(int id, string errorMessage)
			: base(errorMessage) { ID = id; }

		public RMException(string errorMessage, Exception innerEx)
			: base(errorMessage, innerEx) { }
	}

	[Serializable]
	public class HardbookedException : RMException
	{
		public HardbookedException(string errorMessage)
			: base(errorMessage) { }

		public HardbookedException(string errorMessage, Exception innerEx)
			: base(errorMessage, innerEx) { }
	}

	[Serializable]
	public class RequestDataChangedException : RMException
	{
		public RequestDataChangedException(string errorMessage)
			: base(errorMessage) { }

		public RequestDataChangedException(string errorMessage, Exception innerEx)
			: base(errorMessage, innerEx) { }
	}

	[Serializable]
	public class CalculatorDataChangedException : RMException
	{
		public CalculatorDataChangedException(string errorMessage)
			: base(errorMessage) { }

		public CalculatorDataChangedException(string errorMessage, Exception innerEx)
			: base(errorMessage, innerEx) { }
	}

	[Serializable]
	public class CustomSchemaDataChangedException : RMException
	{
		public CustomSchemaDataChangedException(string errorMessage)
			: base(errorMessage) { }

		public CustomSchemaDataChangedException(string errorMessage, Exception innerEx)
			: base(errorMessage, innerEx) { }
	}

	[Serializable]
	public class CountryDataChangedException : RMException
	{
		public CountryDataChangedException(string errorMessage)
			: base(errorMessage) { }

		public CountryDataChangedException(string errorMessage, Exception innerEx)
			: base(errorMessage, innerEx) { }
	}

	[Serializable]
	public class RequestException : RMException
	{
		//No RequestExceptions allowed without an ID
		public RequestException(string errorMessage, int requestId) : base(errorMessage) { this.ID = requestId; }
	}
	[Serializable]
	public class SiteException : RMException
	{
		public int? RequestId { get; set; }
		public IEnumerable<Quintiles.RM.Clinical.Domain.Models.Search.MonitoringRow> FrequencyDates { get; set; }
		//No RequestExceptions allowed without an ID
		public SiteException(string errorMessage, int siteId, int? requestId)
			: base(errorMessage)
		{
			this.ID = siteId;
			RequestId = requestId;
		}
	}
	[Serializable]
	public class ValidationException : RMException
	{
		public List<KeyValuePair<int, string>> ErrorMessages { get; set; }

		//No RequestExceptions allowed without an ID
		public ValidationException(string errorMessage, int entityId)
			: base(errorMessage)
		{
			this.ID = entityId;
		}
	}

	[Serializable]
	public class ServiceDownException : RMException
	{
		public ServiceDownException(string errorMessage, Exception innerEx)
			: base(errorMessage, innerEx)
		{ }
	}
	[Serializable]
	public class RmGenericException<T> : RMException where T : class
	{
		public T ExceptionDetails { get; set; }
		public RmGenericException(string errorMessage, T exceptionDetails)
			: base(errorMessage)
		{
			ExceptionDetails = exceptionDetails;
		}
		public RmGenericException(int id, string errorMessage, T exceptionDetails)
			: base(id, errorMessage)
		{
			ExceptionDetails = exceptionDetails;
		}
	}

	[Serializable]
	public class TooManyRecordsException : Exception
	{
		public TooManyRecordsException(string message)
			: base(message)
		{ }
	}
}