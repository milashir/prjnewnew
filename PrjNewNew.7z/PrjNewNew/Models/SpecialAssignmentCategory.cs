﻿using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[DataContract]
	public class SpecialAssignmentCategory_WS
	{
		[DataMember]
		public int Id { get; set; }

		[DataMember]
		public string Description { get; set; }

		[DataMember]
		public string Tooltip { get; set; }

		public SpecialAssignmentCategory_WS(SpecialAssignmentCategory category)
		{
			Id = category.Id;
			Description = category.Description;
			Tooltip = category.Tooltip;
		}
	}

	[ActiveRecord]
	public class SpecialAssignmentCategory : AbstractActiveRecordBaseModel<SpecialAssignmentCategory>
	{
		#region Mapped Properties
		[PrimaryKey(Column = "SpecialAssignmentCategoryId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public string Description { get; set; }

		[Property]
		public string Tooltip { get; set; }
		#endregion

		public static List<SpecialAssignmentCategory> GetAllCategory()
		{
			return CacheService.SpecialAssignmentCategories.Values.ToList();
		}

		public static Dictionary<int, string> GetObjectForJson()
		{
			var dictionary = new Dictionary<int, string>();

			foreach (var specialCategory in GetAllCategory())
			{
				dictionary.Add(specialCategory.Id, specialCategory.Description);
			}

			return dictionary;
		}
	}
}
