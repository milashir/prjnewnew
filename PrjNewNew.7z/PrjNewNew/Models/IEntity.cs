﻿namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// All RM entities shall have an Id
	/// </summary>
	public interface IEntity
	{
		int Id { get; }
	}
}