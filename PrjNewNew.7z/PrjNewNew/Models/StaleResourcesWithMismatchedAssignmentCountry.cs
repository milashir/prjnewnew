﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class StaleResourcesWithMismatchedAssignmentCountry : AbstractActiveRecordBaseModel<StaleResourcesWithMismatchedAssignmentCountry>
	{
		[PrimaryKey(UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public int ResourceId { get; set; }

		[Property]
		public string LockedBy { get; set; }

		[Property]
		public DateTime? LockedOn { get; set; }

		public static SortedDictionary<int, int> GetResourceIds(int maxRecordCount)
		{
			var resourceList = new SortedDictionary<int, int>();

			using (var dr = DbHelp.ExecuteDataReaderSP("StaleResourcesWithMismatchedAssignmentCountryFifoQueue", new SqlParameter("serverName", ExtensionMethods.GetCurrentServerName()), new SqlParameter("maxRecordCount", maxRecordCount)))
			{
				try { while (dr.Read()) { resourceList.Add(DbSafe.Int(dr["Id"]), DbSafe.Int(dr["ResourceId"])); } }
				finally { dr.Close(); }
			}

			return resourceList;
		}

		public static void UpdateThreadGuid(string threadGuid, List<int> resourceIdList)
		{
			var sql = string.Format(@"UPDATE  dbo.StaleResourcesWithMismatchedAssignmentCountry WITH ( ROWLOCK, READPAST ) 
                        SET     ThreadGuid = '{0}'
                        WHERE   Id IN ({1})", DbSafe.EscapeQuote(threadGuid), string.Join(",", resourceIdList.Select(v => v.ToString()).ToArray()));
			DbHelp.ExecuteNonQueryText(sql);
		}

		public static void DeleteProcessedRecords(string threadGuid)
		{
			DbHelp.ExecuteNonQueryText(string.Format(@"DELETE FROM dbo.StaleResourcesWithMismatchedAssignmentCountry  WITH ( ROWLOCK, READPAST ) WHERE ThreadGuid='{0}'", DbSafe.EscapeQuote(threadGuid)));
		}
	}
}
