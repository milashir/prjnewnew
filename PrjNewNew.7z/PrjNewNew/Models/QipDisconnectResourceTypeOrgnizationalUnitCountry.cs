﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Castle.ActiveRecord;
using Castle.ActiveRecord.Framework;
using NHibernate;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "QipDisconnect_ResourceTypeOrgnizationalUnitCountry_Xref")]
	public class QipDisconnectResourceTypeOrgnizationalUnitCountry : AbstractActiveRecordBaseModel<QipDisconnectResourceTypeOrgnizationalUnitCountry>
	{
		[PrimaryKey(Column = "QipDisconnectRRTOrgUnitCountryId")]
		public override int Id { set; get; }

		[Property]
		public int ResourceTypeId { set; get; }

		[Property]
		public int OrganizationalUnitId { set; get; }

		[Property]
		public int CountryId { set; get; }

		[Property]
		public decimal? MinQipVersion { set; get; }

		public string countryNameList { set; get; }

		public string countryIdList { get; set; }


		public static PagedResponse<QipDisconnectResourceTypeOrgnizationalUnitCountry_WS, GridCommonData> GetAllQipDisconnectDataByOrganizationId(int organizationalUnitId)
		{
			var response = new PagedResponse<QipDisconnectResourceTypeOrgnizationalUnitCountry_WS, GridCommonData>();

			var qpdList = new List<QipDisconnectResourceTypeOrgnizationalUnitCountry_WS>();

			using (var dr = DbHelp.ExecuteDataReaderSP("GetQipDisconnectDataByOrganizationalUnitId", ConfigValue.CommandTimeout, new SqlParameter("organizationalUnit", organizationalUnitId)))
			{
				try
				{
					while (dr.Read()) { qpdList.Add(QipDisconnectResourceTypeOrgnizationalUnitCountry.FormReader(dr)); }
					response.Records = qpdList;
					response.PageNumber = response.Records.Count > 0 ? 1 : 0;
				}
				finally { dr.Close(); }
			}

			return response;
		}

		private static QipDisconnectResourceTypeOrgnizationalUnitCountry_WS FormReader(IDataReader dr)
		{
			var qipDisconnectStatus = new QipDisconnectResourceTypeOrgnizationalUnitCountry_WS();
			qipDisconnectStatus.Id = DbSafe.Int(dr["ROWID"]);
			qipDisconnectStatus.ResourceTypeId = DbSafe.Int(dr["ResourceTypeId"]);
			qipDisconnectStatus.ResourceTypeName = DbSafe.StringValue(dr["ResourceTypeName"]);
			qipDisconnectStatus.countryIdList = DbSafe.StringValue(dr["CountryIdList"]);
			qipDisconnectStatus.countryNameList = DbSafe.StringValue(dr["CountryNameList"]);
			qipDisconnectStatus.MinQipVersion = DbSafe.DecimalNull(dr["MaxQipVersion"]);
			return qipDisconnectStatus;
		}

		public static void InsertUpdateQipDisconnectData(List<int> RRTIdList, List<int> CountryIdList, int organizationalUnitId, decimal? minQipVersion, string updatedBy)
		{
			DbHelp.ExecuteNonQuerySP("QipDisconnect_ResourceTypeOrgnizationalUnitCountry_InsertUpdateData",
									DbHelp.GetIdTableTypeParameter("QipDisconnectRRTIds", ((RRTIdList == null) ? new List<int>() : RRTIdList)),
									DbHelp.GetIdTableTypeParameter("QipDisconnectCountryIds", ((CountryIdList == null) ? new List<int>() : CountryIdList)),
									new SqlParameter("OrganizationalUnitId", organizationalUnitId),
									new SqlParameter("@maxQipVersion", minQipVersion),
									new SqlParameter("updatedBy", updatedBy)
				);
		}

		public static void DeleteQipDisconnectData(List<ResourceTypeCountryIdListToDelete_WS> QipDisconnectIdList)
		{
			foreach (var qipDisconnectData in QipDisconnectIdList)
			{
				var resourceTypeId = qipDisconnectData.resourceTypeId;
				var countryIdList = string.Join(",", qipDisconnectData.countryIdList.Select(n => n.ToString()).ToArray());
				string sqlQuery = string.Format(@"Delete from QipDisconnect_ResourceTypeOrgnizationalUnitCountry_Xref where ResourceTypeId = {0} and CountryId IN ({1})", resourceTypeId, countryIdList);
				DbHelp.ExecuteScalarText(sqlQuery);
			}
		}
	}
}
