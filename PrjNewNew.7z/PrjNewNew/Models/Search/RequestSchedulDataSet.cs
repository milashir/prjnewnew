﻿using System.Collections.Generic;
using System.Linq;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class RequestScheduleData : IRequestSchedulerDataList
	{
		public List<IRequestSchedulerData> ScheduleTypeSpecificDataList { get; set; }

		public RequestScheduleData()
		{
			ScheduleTypeSpecificDataList = new List<IRequestSchedulerData>();
		}

		public RequestScheduleData(List<int> requestIdList)
			: this()
		{
			var requestListByScheduletType = GetSchedulerTypeconfigByRequestList(requestIdList);

			foreach (var keyValuePair in requestListByScheduletType)
			{
				switch (keyValuePair.Key)
				{
					case RequestSchedulerType_E.FrequencyCalculator:
						AddMonitoringDataToSchedulerDataToList(keyValuePair);
						break;
					case RequestSchedulerType_E.FlatFteValue:
						AddFlatFteDataToSchedulerDataToList(keyValuePair);
						break;
					case RequestSchedulerType_E.NonProposalFlatFte:
						ScheduleTypeSpecificDataList.Add(new NonProposalFlatFteSchedulerData(keyValuePair.Value.First().Value));
						break;
					case RequestSchedulerType_E.SsvCountryLevelForecast:
						ScheduleTypeSpecificDataList.Add(new SsvCountryLevelForecastSchedulerData(keyValuePair.Value.First().Value));
						break;
					case RequestSchedulerType_E.ShortTermSWAT:
						AddShortTermDataToSchedulerDataToList(keyValuePair);
						break;
					case RequestSchedulerType_E.PhaseCalculator:
						ScheduleTypeSpecificDataList.Add(new CpmSchedulerData(keyValuePair.Value.First().Value));
						break;
					case RequestSchedulerType_E.RegionalPhaseCalculator:
						ScheduleTypeSpecificDataList.Add(new RegionalPhaseSchedulerData(keyValuePair.Value.First().Value));
						break;
					case RequestSchedulerType_E.GlobalPhaseCalculator:
						ScheduleTypeSpecificDataList.Add(new GlobalPhaseSchedulerData(keyValuePair.Value.First().Value));
						break;
					case RequestSchedulerType_E.SSV:
						ScheduleTypeSpecificDataList.Add(new SsvSchedulerData(keyValuePair.Value.First().Value));
						break;
					case RequestSchedulerType_E.Generic:
						ScheduleTypeSpecificDataList.Add(new GenericSchedulerData(keyValuePair.Value.First().Value));
						break;
					case RequestSchedulerType_E.DteFrequencyCalculator:
						AddDteMonitoringDataToSchedulerDataToList(keyValuePair);
						break;
					case RequestSchedulerType_E.MonitoringSiteSpecific:
						AddMonitoringSiteSpecificDataToSchedulerDataToList(keyValuePair);
						break;
					case RequestSchedulerType_E.QipConnectedProposal:
						ScheduleTypeSpecificDataList.Add(new QipConnectedProposalData(keyValuePair.Value.First().Value));
						break;
					//case RequestSchedulerType_E.MonitoringCountryLevelForecast:
					//	ScheduleTypeSpecificDataList.Add(new MonitoringCountrySpecificSchedulerData(keyValuePair.Value.First().Value));
					//	break;
					case RequestSchedulerType_E.MonitoringCountryLevelForecast:
						AddMonitoringCountryLevelForecastDataToSchedulerDataToList(keyValuePair);
						break;
					case RequestSchedulerType_E.DteMonitoringCountryLevelForecast:
						AddDteMonitoringCountryLevelForecastDataToSchedulerDataToList(keyValuePair);
						break;
					default:
						break;
				}
			}
		}

		private void AddMonitoringCountryLevelForecastDataToSchedulerDataToList(KeyValuePair<RequestSchedulerType_E, Dictionary<int, List<int>>> keyValuePair)
		{
			foreach (var resourceTypeRequestIdKvp in keyValuePair.Value)
			{
				switch ((ResourceTypeName)resourceTypeRequestIdKvp.Key)
				{
					case ResourceTypeName.Non_DTE_CRA_Project_Country:
						ScheduleTypeSpecificDataList.Add(new StdMonitoringCountryLevelForecastData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.Non_DTE_Pharmacy_CRA_Project_Country:
						ScheduleTypeSpecificDataList.Add(new PharmacyMonitoringCountryLevelForecastData(resourceTypeRequestIdKvp.Value));
						break;
				}
			}
		}

		private void AddDteMonitoringCountryLevelForecastDataToSchedulerDataToList(KeyValuePair<RequestSchedulerType_E, Dictionary<int, List<int>>> keyValuePair)
		{
			foreach (var resourceTypeRequestIdKvp in keyValuePair.Value)
			{
				switch ((ResourceTypeName)resourceTypeRequestIdKvp.Key)
				{
					case ResourceTypeName.DTE_CRA_Project_Country:
						ScheduleTypeSpecificDataList.Add(new DteSiteMonitoringCountryLevelForecastData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.DTE_Pharmacy_CRA_Project_Country:
						ScheduleTypeSpecificDataList.Add(new DtePharmacyMonitoringCountryLevelForecastData(resourceTypeRequestIdKvp.Value));
						break;
				}
			}
		}

		private void AddDteMonitoringDataToSchedulerDataToList(KeyValuePair<RequestSchedulerType_E, Dictionary<int, List<int>>> keyValuePair)
		{
			foreach (var resourceTypeRequestIdKvp in keyValuePair.Value)
			{
				switch ((ResourceTypeName)resourceTypeRequestIdKvp.Key)
				{
					case ResourceTypeName.DTESite_Monitoring:
						ScheduleTypeSpecificDataList.Add(new DteSiteMonitoringSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.DTEPharmacy_Monitoring:
						ScheduleTypeSpecificDataList.Add(new DtePharmacyMonitoringSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
				}
			}
		}

		public Dictionary<RequestSchedulerType_E, Dictionary<int, List<int>>> GetSchedulerTypeconfigByRequestList(List<int> requestIdList)
		{
			var requestListByResourceType = new Dictionary<RequestSchedulerType_E, Dictionary<int, List<int>>>();

			using (var dr = DbHelp.ExecuteDataReaderText(string.Format(@"SELECT RSTRTX.RequestSchedulerTypeId ,
																																					REQ.RequestId ,
																																					REQ.ResourceTypeId ,
																																					RTYP.IsProposal
																																	FROM    dbo.Request REQ
																																					JOIN dbo.ResourceType RT ON REQ.ResourceTypeId = RT.ResourceTypeId
																																					JOIN dbo.RequestType RTYP ON RTYP.RequestTypeId = REQ.RequestTypeId
																																					JOIN dbo.RequestSchedulerTypeResourceType_XREF RSTRTX ON RSTRTX.ResourceTypeId = RT.ResourceTypeId
																																																													AND RSTRTX.IsProposal = RTYP.IsProposal
																																	WHERE   REQ.RequestId IN ({0})", string.Join(",", requestIdList.Select(r => r.ToString()).ToArray()))))
			{
				try
				{
					while (dr.Read())
					{
						var requestSchcedulerType = (RequestSchedulerType_E)DbSafe.Int(dr["RequestSchedulerTypeId"]);
						var resourceTypeId = GetResourceTypeIdBySchedulerTypeAndProposal(DbSafe.Int(dr["ResourceTypeId"]), DbSafe.Bool(dr["IsProposal"]), requestSchcedulerType);

						List<int> requestList;
						Dictionary<int, List<int>> requestdictionaryByResourceType;
						if (!requestListByResourceType.TryGetValue(requestSchcedulerType, out requestdictionaryByResourceType))
						{
							requestdictionaryByResourceType = new Dictionary<int, List<int>>();
							requestListByResourceType.Add(requestSchcedulerType, requestdictionaryByResourceType);
						}

						if (!requestdictionaryByResourceType.TryGetValue(resourceTypeId, out requestList))
						{
							requestList = new List<int>();
							requestdictionaryByResourceType.Add(resourceTypeId, requestList);
						}

						requestList.Add(DbSafe.Int(dr["RequestId"]));
					}
				}
				finally { dr.Close(); }
			}

			return requestListByResourceType;
		}

		private static int GetResourceTypeIdBySchedulerTypeAndProposal(int resourceTypeId, bool isProposal, RequestSchedulerType_E requestSchedulerType)
		{
			if (requestSchedulerType == RequestSchedulerType_E.PhaseCalculator ||
					requestSchedulerType == RequestSchedulerType_E.RegionalPhaseCalculator ||
					requestSchedulerType == RequestSchedulerType_E.GlobalPhaseCalculator ||
					requestSchedulerType == RequestSchedulerType_E.QipConnectedProposal ||
					requestSchedulerType == RequestSchedulerType_E.Generic ||
					requestSchedulerType == RequestSchedulerType_E.SSV)
			{
				//For these calculators we don't need to distinguish between resource types
				resourceTypeId = 0;
			}
			else if (requestSchedulerType == RequestSchedulerType_E.FlatFteValue)
			{
				//For Flat fte value calculators we need two distinct resource type ids (need not be real IDs). 
				//One for proposal other for non proposal. We want to segregate proposal and non proposal requests. 
				resourceTypeId = isProposal ? 0 : resourceTypeId;
			}
			return resourceTypeId;
		}

		private void AddMonitoringDataToSchedulerDataToList(KeyValuePair<RequestSchedulerType_E, Dictionary<int, List<int>>> keyValuePair)
		{
			foreach (var resourceTypeRequestIdKvp in keyValuePair.Value)
			{
				switch ((ResourceTypeName)resourceTypeRequestIdKvp.Key)
				{
					case ResourceTypeName.Standard_Monitoring:
						ScheduleTypeSpecificDataList.Add(new StandardMonitoringSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.Pharmacy_Monitoring:
						ScheduleTypeSpecificDataList.Add(new PharmacyMonitoringSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.iCRA_Monitoring:
						ScheduleTypeSpecificDataList.Add(new ICraMonitoringSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.DTEPharmacy_Monitoring:
						ScheduleTypeSpecificDataList.Add(new DtePharmacyMonitoringSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.DTESite_Monitoring:
						ScheduleTypeSpecificDataList.Add(new DteSiteMonitoringSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
				}
			}
		}

		private void AddShortTermDataToSchedulerDataToList(KeyValuePair<RequestSchedulerType_E, Dictionary<int, List<int>>> keyValuePair)
		{
			foreach (var resourceTypeRequestIdKvp in keyValuePair.Value)
			{
				switch ((ResourceTypeName)resourceTypeRequestIdKvp.Key)
				{
					case ResourceTypeName.Short_term_SWAT_Monitoring_OnSite_Visit:
						ScheduleTypeSpecificDataList.Add(new ShortTermSwatOnSiteSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.Short_term_SWAT_Monitoring_Phone_Visit:
						ScheduleTypeSpecificDataList.Add(new ShortTermSwatPhoneSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
				}
			}
		}

		private void AddFlatFteDataToSchedulerDataToList(KeyValuePair<RequestSchedulerType_E, Dictionary<int, List<int>>> keyValuePair)
		{
			List<int> proposalRequestIds = new List<int>();
			foreach (var resourceTypeRequestIdKvp in keyValuePair.Value)
			{
				switch ((ResourceTypeName)resourceTypeRequestIdKvp.Key)
				{
					case ResourceTypeName.Co_monitoring_NonSiteSpecific:
						ScheduleTypeSpecificDataList.Add(new CoMonitoringNonSiteSpecificSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.Non_Standard_Monitoring_NonSiteSpecific:
						ScheduleTypeSpecificDataList.Add(new NonStandardMonitoringNonSiteSpecificSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.Co_monitoring:
						ScheduleTypeSpecificDataList.Add(new CoMonitoringSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					default:
						proposalRequestIds.AddRange(resourceTypeRequestIdKvp.Value);
						break;
				}
			}

			if (proposalRequestIds.Count > 0)
			{
				ScheduleTypeSpecificDataList.Add(new ProposalSchedulerData(proposalRequestIds));
			}
		}

		private void AddMonitoringSiteSpecificDataToSchedulerDataToList(KeyValuePair<RequestSchedulerType_E, Dictionary<int, List<int>>> keyValuePair)
		{
			foreach (var resourceTypeRequestIdKvp in keyValuePair.Value)
			{
				switch ((ResourceTypeName)resourceTypeRequestIdKvp.Key)
				{
					case ResourceTypeName.Co_monitoring_SiteSpecific:
						ScheduleTypeSpecificDataList.Add(new CoMonitoringSiteSpecificSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
					case ResourceTypeName.Non_Standard_Monitoring_SiteSpecific:
						ScheduleTypeSpecificDataList.Add(new NonStandardMonitoringSiteSpecificSchedulerData(resourceTypeRequestIdKvp.Value));
						break;
				}
			}
		}
	}
}
