﻿using System;
using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class RequestData
	{
		public Dictionary<int, RequestRow> RequestRows { get; private set; }

		public RequestData(IDataReader r)
			: this()
		{
			ColumnChecker cc = null;
			while (r.Read())
			{
				if (cc == null)
				{
					cc = new ColumnChecker(r);
				}
				var newRow = new RequestRow(r, cc);
				RequestRows.Add(newRow.RequestId, newRow);
			}
		}

		public RequestData()
		{
			RequestRows = new Dictionary<int, RequestRow>();
		}
	}

	public class RequestRow
	{
		#region Properties
		public int SiteId { get; set; }
		public int RequestId { get; set; }
		public decimal Utilization { get; set; }
		public int CountryId { get; set; }
		public int? RegionId { get; set; }
		public RequestStatusName RequestStatus { get; set; }
		public DateTime RequestStartDate { get; set; }
		public DateTime RequestStopDate { get; set; }
		public DateTime? MaxAdhocEndDate { get; set; }
		public ResourceTypeName ResourceType { get; set; }
		public RequestType_E RequestType { get; set; }
		public int? ParentRequestId { get; set; }
		public SSVType_E? SSVType { get; set; }
		public BackfillTypeName? BackFillType { get; set; }
		public int ProjectId { get; set; }
		public int? AssignedResourceId { get; set; }
		public int? NumberOfPhases { get; set; }
		public bool IsGeneric { get; set; }
		public int? ProjectOrganizationId { get; set; }
		public int ProjectedInitiatedSites { get; set; }
		public int ActualInitiatedSites { get; set; }
		public int SivFsiWeeks { get; set; }
		
		public int SivFsiDays { get { return SivFsiWeeks * 7; } }
		public int SitesPendingInitiation { get { return ProjectedInitiatedSites - ActualInitiatedSites; } }
		public bool AllowWeeklyFteCalculation { get; set; }
		#endregion
		public RequestRow() { }

		public RequestRow(IDataReader r, ColumnChecker cc)
		{
			if (cc.HasColumn("SiteId")) { SiteId = DbSafe.Int(r["SiteId"]); }
			if (cc.HasColumn("RequestId")) { RequestId = DbSafe.Int(r["RequestId"]); }
			if (cc.HasColumn("Utilization")) { Utilization = DbSafe.Decimal(r["Utilization"]); }
			if (cc.HasColumn("CountryId")) { CountryId = DbSafe.Int(r["CountryId"]); }
			if (cc.HasColumn("RegionId")) { RegionId = DbSafe.IntNull(r["RegionId"]); }
			if (cc.HasColumn("RequestStatusId")) { RequestStatus = (RequestStatusName)DbSafe.Int(r["RequestStatusId"]); }
			if (cc.HasColumn("StartDate")) { RequestStartDate = DbSafe.DateTime(r["StartDate"]); }
			if (cc.HasColumn("StopDate")) { RequestStopDate = DbSafe.DateTime(r["StopDate"]); }
			if (cc.HasColumn("MaxAdhocEndDate")) { MaxAdhocEndDate = DbSafe.DateTimeNull(r["MaxAdhocEndDate"]); }
			if (cc.HasColumn("ResourceType")) { ResourceType = (ResourceTypeName)DbSafe.Int(r["ResourceType"]); }
			if (cc.HasColumn("RequestType")) { RequestType = (RequestType_E)DbSafe.Int(r["RequestType"]); }
			if (cc.HasColumn("ParentRequestId")) { ParentRequestId = DbSafe.IntNull(r["ParentRequestId"]); }
			if (cc.HasColumn("ProjectId")) { ProjectId = DbSafe.Int(r["ProjectId"]); }
			if (cc.HasColumn("AssignedResourceId")) { AssignedResourceId = DbSafe.IntNull(r["AssignedResourceId"]); }
			if (cc.HasColumn("NumberOfPhases")) { NumberOfPhases = DbSafe.IntNull(r["NumberOfPhases"]); }
			if (cc.HasColumn("IsGeneric")) { IsGeneric = DbSafe.Bool(r["IsGeneric"]); }
			if (cc.HasColumn("ProjectOrganizationId")) { ProjectOrganizationId = DbSafe.IntNull(r["ProjectOrganizationId"]); }

			if (cc.HasColumn("SSVType") && !(r["SSVType"] is DBNull))
			{
				SSVType = (SSVType_E)DbSafe.Int(r["SSVType"]);
			}

			if (cc.HasColumn("BackFillTypeId") && !(r["BackFillTypeId"] is DBNull))
			{
				BackFillType = (BackfillTypeName)DbSafe.Int(r["BackFillTypeId"]);
			}
			if (cc.HasColumn("ProjectedInitiatedSites")) { ProjectedInitiatedSites = DbSafe.Int(r["ProjectedInitiatedSites"]); }
			if (cc.HasColumn("ActualInitiatedSites")) { ActualInitiatedSites = DbSafe.Int(r["ActualInitiatedSites"]); }
			if (cc.HasColumn("SivFsiWeeks")) { SivFsiWeeks = DbSafe.Int(r["SivFsiWeeks"]); }
			if (cc.HasColumn("AllowWeeklyFteCalculation")) { AllowWeeklyFteCalculation = DbSafe.Bool(r["AllowWeeklyFteCalculation"]); }
		}
	}
}