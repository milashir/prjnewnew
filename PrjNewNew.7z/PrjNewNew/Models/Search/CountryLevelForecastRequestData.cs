﻿using System;
using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class CountryLevelForecastRequestData : RequestData
	{
		public CountryLevelForecastRequestData(IDataReader r)
			: this()
		{
			while (r.Read())
			{
				var newRow = new CountryLevelForecastRequestRow(r);
				RequestRows.Add(newRow.RequestId, newRow);
			}
		}

		public CountryLevelForecastRequestData()
			: base()
		{ }
	}

	public class CountryLevelForecastRequestRow : RequestRow
	{
		public CountryLevelForecastRequestRow() { }

		public CountryLevelForecastRequestRow(IDataReader r)
		{
			RequestId = DbSafe.Int(r["RequestId"]);
			Utilization = DbSafe.Decimal(r["Utilization"]);
			CountryId = DbSafe.Int(r["CountryId"]);
			RequestStatus = (RequestStatusName)DbSafe.Int(r["RequestStatusId"]);
			RequestStartDate = DbSafe.DateTime(r["StartDate"]);
			RequestStopDate = DbSafe.DateTime(r["StopDate"]);
			ResourceType = (ResourceTypeName)DbSafe.Int(r["ResourceType"]);
			RequestType = (RequestType_E)DbSafe.Int(r["RequestType"]);
			ProjectId = DbSafe.Int(r["ProjectId"]);
			ProjectedInitiatedSites = DbSafe.Int(r["ProjectedInitiatedSites"]);
			ActualInitiatedSites = DbSafe.Int(r["ActualInitiatedSites"]);
			SivFsiWeeks = DbSafe.Int(r["SivFsiWeeks"]);
		}
	}
}