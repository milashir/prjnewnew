﻿using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class SsvSchedulerData : IRequestSchedulerData
	{
		public RequestData RequestData { get; private set; }
		public SsvData SsvData { get; private set; }

		public SsvSchedulerData(List<int> requestIdList)
		{
			using (var dr = DbHelp.ExecuteDataReaderSP("GetRequestSchedule_SsvRequests", ConfigValue.CommandTimeout, DbHelp.GetIdTableTypeParameter("requestIds", requestIdList)))
			{
				try
				{
					RequestData = new RequestData(dr);
					dr.NextResult();

					SsvData = new SsvData(dr);

				}
				finally { dr.Close(); }
			}
		}

		public SsvSchedulerData()
		{
			RequestData = new RequestData();
			SsvData = new SsvData();
		}
	}

	public class SsvData
	{
		public Dictionary<int, SsvRow> SsvRows { get; private set; }

		public SsvData(IDataReader r)
			: this()
		{
			while (r.Read())
			{
				SsvRows.Add(DbSafe.Int(r["RequestId"]), new SsvRow(r));
			}
		}

		public SsvData()
		{
			SsvRows = new Dictionary<int, SsvRow>();
		}
	}

	public class SsvRow : BaseSearchModel
	{
		#region Properties
		//public DateTime MiddleDate { get; private set; }
		public decimal ClusterFTESite { get; private set; }
		public decimal NonClusterFTESite { get; private set; }
		public decimal PhoneVisitFTESite { get; private set; }
		public decimal SsvPerSite { get; private set; }
		public decimal VisitFrequency { get; private set; }
		public decimal PhoneSSVPerSite { get; private set; }
		public decimal PhoneVisitFrequency { get; private set; }
		public decimal PhoneVisitTime { get; private set; }
		#endregion

		public SsvRow(IDataReader r)
			: base(r)
		{
			//MiddleDate = DbSafe.DateTime(r["MiddleDate"]);
			ClusterFTESite = DbSafe.Decimal(r["ClusterFTESite"]);
			NonClusterFTESite = DbSafe.Decimal(r["NonClusterFTESite"]);
			PhoneVisitFTESite = DbSafe.Decimal(r["PhoneVisitFTESite"]);
			SsvPerSite = DbSafe.Decimal(r["SsvPerSite"]);
			WeeklyHours = DbSafe.Decimal(r["WeeklyHours"]);
			VisitFrequency = DbSafe.Decimal(r["VisitFrequency"]);
			PhoneSSVPerSite = DbSafe.Decimal(r["PhoneSSVPerSite"]);
			PhoneVisitFrequency = DbSafe.Decimal(r["PhoneVisitFrequency"]);
			PhoneVisitTime = DbSafe.Decimal(r["PhoneVisitTime"]);
		}
	}
}
