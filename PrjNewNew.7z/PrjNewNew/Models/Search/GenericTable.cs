﻿using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class GenericSchedulerData : IRequestSchedulerData
	{
		public RequestData RequestData { get; private set; }
		public GenericData GenericData { get; private set; }
		public GenericMilestoneData GenericMilestoneData { get; private set; }

		public GenericSchedulerData(List<int> requestIdList)
			: this()
		{
			using (var dr = DbHelp.ExecuteDataReaderSP("GetRequestSchedule_GenericRequests", DbHelp.GetIdTableTypeParameter("requestIds", requestIdList)))
			{
				try
				{
					RequestData = new RequestData(dr);

					dr.NextResult();
					GenericData = new GenericData(dr);

					dr.NextResult();
					GenericMilestoneData = new GenericMilestoneData(dr);
				}
				finally { dr.Close(); }
			}
		}

		public GenericSchedulerData()
		{
			RequestData = new RequestData();
			GenericData = new GenericData();
		}
	}

	public class GenericMilestoneData
	{
		public Dictionary<int, bool> MileStoneStatus { get; set; }
		public GenericMilestoneData(IDataReader dr)
		{
			MileStoneStatus = new Dictionary<int, bool>();

			while (dr.Read())
			{
				int milestoneId = DbSafe.Int(dr["CustomMilestoneId"]);

				if (!MileStoneStatus.ContainsKey(milestoneId))
				{
					MileStoneStatus.Add(milestoneId, DbSafe.Bool(dr["IsActive"]));
				}
			}
		}

	}

	public class GenericData
	{
		public Dictionary<int, SearchRowData<GenericRow, PhaseAdhocRow>> GenericRowData { get; set; }

		public GenericData(IDataReader r)
			: this()
		{
			MapGenericPhaseRows(r);

			r.NextResult();

			MapGenericAdhocRows(r);
		}

		private void MapGenericPhaseRows(IDataReader r)
		{
			SearchRowData<GenericRow, PhaseAdhocRow> genericRowData;

			while (r.Read())
			{
				int requestId = DbSafe.Int(r["RequestId"]);
				if (!GenericRowData.TryGetValue(requestId, out genericRowData))
				{
					genericRowData = new SearchRowData<GenericRow, PhaseAdhocRow>();
					GenericRowData.Add(requestId, genericRowData);
				}
				genericRowData.Rows.Add(new GenericRow(r));
			}
		}

		private void MapGenericAdhocRows(IDataReader r)
		{
			SearchRowData<GenericRow, PhaseAdhocRow> genericRowData;

			while (r.Read())
			{
				int requestId = DbSafe.Int(r["RequestId"]);

				if (!GenericRowData.TryGetValue(requestId, out genericRowData))
				{
					genericRowData = new SearchRowData<GenericRow, PhaseAdhocRow>();
					GenericRowData.Add(requestId, genericRowData);
				}
				genericRowData.AdhocRows.Add(new PhaseAdhocRow(r));
			}
		}

		public GenericData()
		{
			GenericRowData = new Dictionary<int, SearchRowData<GenericRow, PhaseAdhocRow>>();
		}
	}

	public class GenericRow : PhaseRow
	{
		#region Properties
		public GenericMilestoneType_E FromMilestoneType { get; set; }
		public GenericMilestoneType_E ToMilestoneType { get; set; }
		public int FromMilestoneTypeId { get; set; }
		public int ToMilestoneTypeId { get; set; }
		#endregion

		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="r"></param>
		public GenericRow(IDataReader r)
			: base(r)
		{
			FromMilestoneType = (GenericMilestoneType_E)DbSafe.Char(r["FromMilestoneType"]);
			ToMilestoneType = (GenericMilestoneType_E)DbSafe.Char(r["ToMilestoneType"]);
			FromMilestoneTypeId = DbSafe.Int(r["FromMilestoneId"]);
			ToMilestoneTypeId = DbSafe.Int(r["ToMilestoneId"]);
		}
		#endregion

		public GenericRow() { }
	}
}
