﻿using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{

	public class FlatFteValueSchedulerData : IRequestSchedulerData
	{
		public RequestData RequestData { get; private set; }
		public FlatFteValueData FlatFteValueData { get; private set; }

		public FlatFteValueSchedulerData(string spName, List<int> requestIdList)
		{
			using (var dr = DbHelp.ExecuteDataReaderSP(spName, DbHelp.GetIdTableTypeParameter("requestIds", requestIdList)))
			{
				try
				{
					RequestData = new RequestData(dr);
					dr.NextResult();

					FlatFteValueData = new FlatFteValueData(dr);

				}
				finally { dr.Close(); }
			}
		}

		public FlatFteValueSchedulerData()
		{
			RequestData = new RequestData();
			FlatFteValueData = new FlatFteValueData();
		}
	}

	public sealed class CoMonitoringSchedulerData : FlatFteValueSchedulerData
	{
		public CoMonitoringSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_CoMonitoringRequests", requestIdList) { }
	}

	public sealed class CoMonitoringNonSiteSpecificSchedulerData : FlatFteValueSchedulerData
	{
		public CoMonitoringNonSiteSpecificSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_CoMonitoringNonSiteSpecificRequests", requestIdList) { }
	}

	public sealed class NonStandardMonitoringNonSiteSpecificSchedulerData : FlatFteValueSchedulerData
	{
		public NonStandardMonitoringNonSiteSpecificSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_NonStandardMonitoringNonSiteSpecificRequests", requestIdList) { }
	}

	public sealed class ProposalSchedulerData : FlatFteValueSchedulerData
	{
		public ProposalSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_ProposalRequests", requestIdList) { }
	}

	public sealed class NonProposalFlatFteSchedulerData : FlatFteValueSchedulerData
	{
		public NonProposalFlatFteSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_NonProposalFlatFteRequests", requestIdList) { }
	}

	public sealed class MonitoringCountrySpecificSchedulerData : FlatFteValueSchedulerData
	{
		public MonitoringCountrySpecificSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_MonitoringCountrySpecificSchedulerRequests", requestIdList) { }
	}
	public class FlatFteValueData
	{
		public Dictionary<int, FlatFteValueRow> FlatFteValueRows { get; private set; }

		public FlatFteValueData(IDataReader r)
			: this()
		{
			while (r.Read())
			{
				FlatFteValueRows.Add(DbSafe.Int(r["RequestId"]), new FlatFteValueRow(r));
			}
		}

		public FlatFteValueData()
		{
			FlatFteValueRows = new Dictionary<int, FlatFteValueRow>();
		}
	}

	public class FlatFteValueRow : BaseSearchModel
	{
		public decimal Fte { get; private set; }

		public FlatFteValueRow(IDataReader r)
			: base(r)
		{
			Fte = DbSafe.Decimal(r["FTE"]);
		}
	}
}
