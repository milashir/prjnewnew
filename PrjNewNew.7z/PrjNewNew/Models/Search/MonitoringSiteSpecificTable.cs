﻿using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class MonitoringSiteSpecificSchedulerData : IRequestSchedulerData
	{
		public RequestData RequestData { get; private set; }
		public MonitoringSiteSpecificData MonitoringSiteSpecificData { get; private set; }

		public MonitoringSiteSpecificSchedulerData(string spName, List<int> requestIdList)
		{
			using (var dr = DbHelp.ExecuteDataReaderSP(spName, DbHelp.GetIdTableTypeParameter("requestIds", requestIdList)))
			{
				try
				{
					RequestData = new RequestData(dr);
					dr.NextResult();

					MonitoringSiteSpecificData = new MonitoringSiteSpecificData(dr);
					dr.NextResult();
				}
				finally { dr.Close(); }
			}
		}

		public MonitoringSiteSpecificSchedulerData()
		{
			RequestData = new RequestData();
			MonitoringSiteSpecificData = new MonitoringSiteSpecificData();
		}
	}

	public sealed class CoMonitoringSiteSpecificSchedulerData : MonitoringSiteSpecificSchedulerData
	{
		public CoMonitoringSiteSpecificSchedulerData(List<int> requestIdList) : base("GetRequestSchedule_CoMonitoringSiteSpecificRequests", requestIdList) { }
	}

	public sealed class NonStandardMonitoringSiteSpecificSchedulerData : MonitoringSiteSpecificSchedulerData
	{
		public NonStandardMonitoringSiteSpecificSchedulerData(List<int> requestIdList) : base("GetRequestSchedule_NonStandardMonitoringSiteSpecificRequests", requestIdList) { }
	}
	
	public class MonitoringSiteSpecificData
	{
		public Dictionary<int, MonitoringSiteSpecificRow> MonitoringSiteSpecificRows { get; private set; }

		public MonitoringSiteSpecificData(IDataReader r)
			: this()
		{
			while (r.Read())
			{
				MonitoringSiteSpecificRows.Add(DbSafe.Int(r["RequestId"]), new MonitoringSiteSpecificRow(r));
			}
		}

		public MonitoringSiteSpecificData()
		{
			MonitoringSiteSpecificRows = new Dictionary<int, MonitoringSiteSpecificRow>();
		}
	}

	public class MonitoringSiteSpecificRow : BaseSearchModel
	{
		public CalculatorType_E TypeId { get; private set; }
		public decimal VisitFrequency { get; private set; }
		/*Properties goes here*/
		public MonitoringSiteSpecificRow(IDataReader r)
			: base(r)
		{
			VisitFrequency = DbSafe.Decimal(r["VisitFrequency"]);
			TypeId = (CalculatorType_E)DbSafe.Int(r["TypeId"]);
			HoursNeeded = DbSafe.Decimal(r["HoursNeeded"]);
		}
	}
}
