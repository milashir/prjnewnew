﻿using System;
using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class SiteVisitData
	{
		public Dictionary<int, List<SiteVisitRow>> SiteVisitRows { get; private set; }

		public SiteVisitData(IDataReader r)
			: this()
		{
			List<SiteVisitRow> siteVisitList;

			while (r.Read())
			{
				int siteId = DbSafe.Int(r["SiteId"]);

				if (!SiteVisitRows.TryGetValue(siteId, out siteVisitList))
				{
					siteVisitList = new List<SiteVisitRow>();
					SiteVisitRows.Add(siteId, siteVisitList);
				}
				siteVisitList.Add(new SiteVisitRow(r));
			}
		}

		public SiteVisitData()
		{
			SiteVisitRows = new Dictionary<int, List<SiteVisitRow>>();
		}
	}

	public class SiteVisitRow
	{
		#region Properties
		public int SiteId { get; set; }
		public DateTime VisitDate { get; set; }
		public bool AddonlyOnsiteHours { get; set; }
		public SiteVisitType_E SiteVisitType { get; set; }
		public FrequencyDateSource_E VisitDateSource { get; set; }
		public int? ResourceId { get; set; }
		public double WeekNumber { get { return Math.Ceiling(VisitDate.DayOfYear / 7.0); } }
		public bool IsGeneratedFromPattern { get; set; }
		private SiteVisitType _siteVisitTypeDetails = null;
		public SiteVisitType SiteVisitTypeDetails
		{
			get
			{
				if (_siteVisitTypeDetails == null)
				{
					_siteVisitTypeDetails = Quintiles.RM.Clinical.Domain.Services.CacheService.SiteVisitType((int)SiteVisitType);
				}
				return _siteVisitTypeDetails;
			}
		}
		public bool IsImvVisit { get { return SiteVisitTypeDetails.IsImvVisit; } }
		public bool IsRemoteVisit { get { return SiteVisitTypeDetails.IsRemoteVisit; } }
		public bool IsOnsiteVisit { get { return SiteVisitTypeDetails.IsOnsiteVisit; } }
		public bool PreventVisitPatternReset { get { return SiteVisitTypeDetails.PreventVisitPatternReset; } }
		public bool PreventVisitPatternResetForSpecialCase { get { return SiteVisitTypeDetails.PreventVisitPatternResetForSpecialCase; } }
		public bool IsOnsiteVisitForSpecialCase { get { return SiteVisitTypeDetails.IsOnsiteVisitForSpecialCase; } }
		#endregion

		public SiteVisitRow(IDataReader r)
		{
			var cc = new ColumnChecker(r);
			VisitDate = DbSafe.DateTime(r["VisitDate"]);
			SiteVisitType = (SiteVisitType_E)DbSafe.Int(r["SiteVisitTypeId"]);
			ResourceId = DbSafe.IntNull(r["ResourceId"]);
			AddonlyOnsiteHours = cc.HasColumn("AddOnlyOnsiteHours") ? DbSafe.Bool(r["AddOnlyOnsiteHours"]) : false;
			SiteId = DbSafe.Int(r["SiteId"]);
			VisitDateSource = (FrequencyDateSource_E)DbSafe.Int(r["VisitDateSource"]);
		}

		public SiteVisitRow() { }

		public override string ToString()
		{
			return string.Format("Date: {0}, Type: {1}, Week: {2}", VisitDate.ToShortDateString(), SiteVisitType.ToString(), WeekNumber);
		}
	}
}
