﻿using System;
using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class SearchRowData<T, TA>
		where T : BaseSearchModel
		where TA : BaseSearchModel
	{
		public DateTime MinStartDate { get; set; }
		public DateTime MaxStopDate { get; set; }
		public List<T> Rows { get; private set; }
		public List<TA> AdhocRows { get; private set; }
		public bool AreRequestDatesBeforeMilestone { get; set; }
		public bool AreRequestDatesAfterMilestone { get; set; }
		public bool RulesApplied { get; set; }

		public SearchRowData()
		{
			Rows = new List<T>();
			AdhocRows = new List<TA>();
		}
	}

	public class FrequencySchedulerData : IRequestSchedulerData
	{
		public RequestData RequestData { get; internal set; }
		public SiteVisitData SiteVisitData { get; internal set; }
		public MonitoringData MonitoringData { get; internal set; }

		public FrequencySchedulerData()
		{
			RequestData = new RequestData();
			SiteVisitData = new SiteVisitData();
			MonitoringData = new MonitoringData();
		}

		public FrequencySchedulerData(string spName, List<int> list)
			: this()
		{
			using (var dr = DbHelp.ExecuteDataReaderSP(spName, ConfigValue.CommandTimeout, DbHelp.GetIdTableTypeParameter("requestIds", list)))
			{
				try
				{
					RequestData = new RequestData(dr);
					dr.NextResult();

					SiteVisitData = new SiteVisitData(dr);
					dr.NextResult();

					MonitoringData = new MonitoringData(dr);
				}
				finally { dr.Close(); }
			}
		}
	}

	public sealed class StandardMonitoringSchedulerData : FrequencySchedulerData
	{
		public StandardMonitoringSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_StandardMonitoringRequests", requestIdList) { }

		public StandardMonitoringSchedulerData() { }
	}

	public sealed class PharmacyMonitoringSchedulerData : FrequencySchedulerData
	{
		public PharmacyMonitoringSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_PharmacyMonitoringRequests", requestIdList) { }

		public PharmacyMonitoringSchedulerData() { }
	}

	public sealed class ICraMonitoringSchedulerData : FrequencySchedulerData
	{
		public ICraMonitoringSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_ICraMonitoringRequests", requestIdList) { }

		public ICraMonitoringSchedulerData() { }
	}

	public sealed class DteSiteMonitoringSchedulerData : FrequencySchedulerData
	{
		public DteSiteMonitoringSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_DteSiteMonitoringRequests", requestIdList) { }
	}

	public sealed class DtePharmacyMonitoringSchedulerData : FrequencySchedulerData
	{
		public DtePharmacyMonitoringSchedulerData(List<int> requestIdList)
			: base("GetRequestSchedule_DtePharmacyMonitoringRequests", requestIdList) { }
	}

	public class MonitoringData
	{
		public Dictionary<int, SearchRowData<MonitoringRow, MonitoringRow>> MonitoringRowData { get; private set; }

		public MonitoringData(IDataReader r)
			: this()
		{
			SearchRowData<MonitoringRow, MonitoringRow> monitoringRowData;

			while (r.Read())
			{
				int requestId = DbSafe.Int(r["RequestId"]);
				CalculatorType_E calculatorType = (CalculatorType_E)DbSafe.Int(r["TypeId"]);

				if (!MonitoringRowData.TryGetValue(requestId, out monitoringRowData))
				{
					monitoringRowData = new SearchRowData<MonitoringRow, MonitoringRow>();
					MonitoringRowData.Add(requestId, monitoringRowData);
				}

				if (calculatorType == CalculatorType_E.AdHoc)
				{
					monitoringRowData.AdhocRows.Add(new MonitoringRow(r));
				}
				else
				{
					monitoringRowData.Rows.Add(new MonitoringRow(r));
				}
			}
		}

		public MonitoringData(Dictionary<int, List<MonitoringRow>> monitoringFrequencyDictionary)
		{
			MonitoringRowData = new Dictionary<int, SearchRowData<MonitoringRow, MonitoringRow>>();

			foreach (var item in monitoringFrequencyDictionary)
			{
				if (!MonitoringRowData.ContainsKey(item.Key))
				{
					MonitoringRowData.Add(item.Key, new SearchRowData<MonitoringRow, MonitoringRow>());
				}

				foreach (var frequency in item.Value)
				{
					if (frequency.CalculatorTypeId == CalculatorType_E.AdHoc)
					{
						MonitoringRowData[item.Key].AdhocRows.Add(frequency);
					}
					else
					{
						MonitoringRowData[item.Key].Rows.Add(frequency);
					}
				}
			}
		}

		public MonitoringData()
		{
			MonitoringRowData = new Dictionary<int, SearchRowData<MonitoringRow, MonitoringRow>>();
		}
	}

	/// <summary>
	/// Shared between standard Monitoring, Pharmacy Monitoring and Remote Monitoring Non DTE Only
	/// </summary>
	public class MonitoringRow : SiteScheduleRow
	{
		#region Properties
		public decimal? AdminTime { get; set; }
		public decimal? FsiFirstImvWeeks { get; set; }
		public int? PhoneSIVPerSite { get; set; }
		public decimal? PhoneVisitFrequency { get; set; }
		public decimal? PhoneVisitTime { get; set; }
		public int? OnSiteVisitRatio { get; set; }
		public int? RemoteVisitRatio { get; set; }
		public decimal? OnsiteVisitTime { get; set; }
		#endregion

		internal MonitoringRow(IDataReader r)
			: base(r)
		{
			var cc = new ColumnChecker(r);
			RequestId = DbSafe.Int(r["RequestId"]);
			HoursNeeded = DbSafe.Decimal(r["HoursNeeded"]);
			AdminTime = DbSafe.DecimalNull(r["AdminTime"]);
			FsiFirstImvWeeks = DbSafe.DecimalNull(r["FsiFirstImvWeeks"]);
			PhoneSIVPerSite = DbSafe.Int(r["PhoneSIVPerSite"]);
			PhoneVisitFrequency = DbSafe.DecimalNull(r["PhoneVisitFrequency"]);
			PhoneVisitTime = DbSafe.DecimalNull(r["PhoneVisitTime"]);
			if (cc.HasColumn("OnsiteVisitTime"))
			{
				OnsiteVisitTime = DbSafe.DecimalNull(r["OnsiteVisitTime"]);
				OnsiteVisitTime = OnsiteVisitTime <= 8 ? OnsiteVisitTime : 8;
			}
			PhoneVisitFrequency = PhoneVisitFrequency <= 0 ? 4 : PhoneVisitFrequency;
			if (cc.HasColumn("OnSiteVisitRatio"))
			{
				// Set onsite visit ratio
				OnSiteVisitRatio = DbSafe.Int(r["OnSiteVisitRatio"]);
			}

			if (cc.HasColumn("RemoteVisitRatio"))
			{
				// Set remote visit ratio
				RemoteVisitRatio = DbSafe.Int(r["RemoteVisitRatio"]);
			}
			if (cc.HasColumn("TierCycle"))
			{
				// Set remote visit ratio
				TierCycle = DbSafe.Int(r["TierCycle"]);
			}
		}

		public MonitoringRow() { }

		public override string ToString()
		{
			return string.Format("[Milestone: {0} - {1}] [Project: {2} - {3}] [Country: {4} - {5}]",
				StartDate.ToShortDateString(),
				StopDate.ToShortDateString(),
				StartProjectMilestoneDate.GetValueOrDefault().ToShortDateString(),
				StopProjectMilestoneDate.GetValueOrDefault().ToShortDateString(),
				StartCountryMilestoneDate.GetValueOrDefault().ToShortDateString(),
				StopCountryMilestoneDate.GetValueOrDefault().ToShortDateString()
				);
		}
	}
}
