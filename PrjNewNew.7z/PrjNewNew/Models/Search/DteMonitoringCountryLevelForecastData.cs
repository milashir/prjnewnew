﻿using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public abstract class MonitoringCountryLevelForecastData : IRequestSchedulerData
	{
		public RequestData RequestData { get; internal set; }
		public CountryCalculatorData CountryCalculatorData { get; internal set; }

		public MonitoringCountryLevelForecastData()
		{
			RequestData = new CountryLevelForecastRequestData();
			CountryCalculatorData = new CountryCalculatorData();
		}
	}

	public class DteMonitoringCountryLevelForecastData : MonitoringCountryLevelForecastData
	{
		public ProjectTierData TierInfo { get; internal set; }

		public DteMonitoringCountryLevelForecastData()
			: base()
		{ }

		public DteMonitoringCountryLevelForecastData(string spName, List<int> list)
		{
			using (var dr = DbHelp.ExecuteDataReaderSP(spName, ConfigValue.CommandTimeout, DbHelp.GetIdTableTypeParameter("requestIds", list)))
			{
				try
				{
					RequestData = new CountryLevelForecastRequestData(dr);
					dr.NextResult();

					CountryCalculatorData = new CountryCalculatorData(dr);
					dr.NextResult();

					TierInfo = new ProjectTierData(dr);
				}
				finally { dr.Close(); }
			}
		}
	}

	public sealed class DteSiteMonitoringCountryLevelForecastData : DteMonitoringCountryLevelForecastData
	{
		public DteSiteMonitoringCountryLevelForecastData(List<int> requestIdList) : base("GetRequestSchedule_DteSiteMonitoringCountryLevelForecastRequests", requestIdList) { }
	}

	public sealed class DtePharmacyMonitoringCountryLevelForecastData : DteMonitoringCountryLevelForecastData
	{
		public DtePharmacyMonitoringCountryLevelForecastData(List<int> requestIdList) : base("GetRequestSchedule_DtePharmacyMonitoringCountryLevelForecastRequests", requestIdList) { }
	}
}
