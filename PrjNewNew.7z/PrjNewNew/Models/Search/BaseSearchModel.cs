﻿using System;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class BaseSearchModel
	{
		#region Propetries
		public int RequestId { get; set; }
		public DateTime StartDate { get; set; }
		public DateTime StopDate { get; set; }

		public decimal HoursNeeded { get; set; }
		public decimal WeeklyHours { get; set; }
		#endregion

		public BaseSearchModel() { }

		public BaseSearchModel(IDataReader r)
		{
			RequestId = DbSafe.Int(r["RequestId"]);
			StartDate = DbSafe.DateTime(r["StartDate"]).Date;
			StopDate = DbSafe.DateTime(r["StopDate"]).Date;
		}
	}
}
