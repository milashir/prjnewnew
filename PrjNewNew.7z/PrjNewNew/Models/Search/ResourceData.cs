﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public interface IResourceData
	{
		Dictionary<int, ResourceAssignment> ResourceDetails { get; set; }
		HashSet<int> DistinctAssignedRequestIds { get; set; }
	}

	public class ResourceData : IResourceData
	{
		/// <summary>
		/// Dictionary key is ResourceId
		/// </summary>
		public Dictionary<int, ResourceAssignment> ResourceDetails { get; set; }
		/// <summary>
		/// List of Distinct RequestIds assigned to all resources in current instance
		/// </summary>
		public HashSet<int> DistinctAssignedRequestIds { get; set; }

		public ResourceData(IDataReader r)
			: this()
		{
			MapResourceData(r);

			r.NextResult();
			MapSpecialAssignments(r);

			r.NextResult();
			MapMonthlyAbsence(r);

			r.NextResult();
			MapAssignmedRequests(r);

			r.NextResult();
			MapDailyAbsence(r);

			r.NextResult();
			MapWeeklyAbsence(r);
		}

		private void MapDailyAbsence(IDataReader r)
		{
			while (r.Read())
			{
				if (ResourceDetails.TryGetValue(DbSafe.Int(r["ResourceId"]), out ResourceAssignment resourceAssignment))
				{
					resourceAssignment.DailyAbsenceData.Add(new DailyAbsenceRow(r));
				}
			}
		}

		private void MapWeeklyAbsence(IDataReader r)
		{
			while (r.Read())
			{
				if (ResourceDetails.TryGetValue(DbSafe.Int(r["ResourceId"]), out ResourceAssignment resourceAssignment))
				{
					resourceAssignment.WeeklyAbsenseData.Add(new WeeklyAbsenceRow(r));
				}
			}
		}

		private void MapMonthlyAbsence(IDataReader r)
		{
			while (r.Read())
			{
				if (ResourceDetails.TryGetValue(DbSafe.Int(r["ResourceId"]), out ResourceAssignment resourceAssignment))
				{
					resourceAssignment.MonthlyAbsenceRows.Add(new MonthlyAbsenceRow(r));
				}
			}
		}

		private void MapAssignmedRequests(IDataReader r)
		{
			ResourceAssignment resourceAssignment;
			while (r.Read())
			{
				int resourceId = DbSafe.Int(r["ResourceId"]);
				//Add records only for available resources
				if (ResourceDetails.TryGetValue(resourceId, out resourceAssignment))
				{
					int requestId = DbSafe.Int(r["RequestId"]);
					DistinctAssignedRequestIds.Add(requestId);
					resourceAssignment.AssignedRequests.Add(new AssignmentRow(r));
					resourceAssignment.AssignedRequestIds.Add(requestId);
				}
			}
		}

		private void MapSpecialAssignments(IDataReader r)
		{
			ResourceAssignment resourceAssignment;
			while (r.Read())
			{
				int resourceId = DbSafe.Int(r["ResourceId"]);
				//Add records only for available resources
				if (ResourceDetails.TryGetValue(resourceId, out resourceAssignment))
				{
					resourceAssignment.SpecialAssignments.Add(new SpecialAssignmentRow(r));
				}
			}
		}

		private void MapResourceData(IDataReader r)
		{
			ResourceAssignment resourceAssignment;
			while (r.Read())
			{
				int resourceId = DbSafe.Int(r["ResourceId"]);

				if (!ResourceDetails.TryGetValue(resourceId, out resourceAssignment))
				{
					resourceAssignment = new ResourceAssignment();
					ResourceDetails.Add(resourceId, resourceAssignment);
				}
				resourceAssignment.Resource = new ResourceRow(r);
			}
		}

		public ResourceData()
		{
			ResourceDetails = new Dictionary<int, ResourceAssignment>();
			DistinctAssignedRequestIds = new HashSet<int>();
		}
	}

	public class ResourceAssignment
	{
		public ResourceRow Resource { get; set; }
		public List<SpecialAssignmentRow> SpecialAssignments { get; set; }
		public List<MonthlyAbsenceRow> MonthlyAbsenceRows { get; set; }
		public List<AssignmentRow> AssignedRequests { get; set; }
		public List<DailyAbsenceRow> DailyAbsenceData { get; set; }
		public List<WeeklyAbsenceRow> WeeklyAbsenseData { get; set; }
		public List<int> AssignedRequestIds { get; set; }

		public ResourceAssignment()
		{
			SpecialAssignments = new List<SpecialAssignmentRow>();
			MonthlyAbsenceRows = new List<MonthlyAbsenceRow>();
			AssignedRequests = new List<AssignmentRow>();
			DailyAbsenceData = new List<DailyAbsenceRow>();
			AssignedRequestIds = new List<int>();
			WeeklyAbsenseData = new List<WeeklyAbsenceRow>();
		}

		public string GetDebugString()
		{
			if (Resource != null)
			{
				var sb = new StringBuilder(1000);
				sb.Append(Resource.ToString());
				sb.AppendFormat("{0}", GetSpecialAssignmentsDebugString());
				sb.AppendFormat("{0}", GetAbsenceDebugString());
				sb.AppendFormat("{0}", GetAssignedRequestsDebugString());
				return sb.ToString();
			}
			else
			{
				return string.Empty;
			}
		}

		public string GetAbsenceDebugString()
		{
			if (MonthlyAbsenceRows != null && MonthlyAbsenceRows.Count > 0)
			{
				var sb = new StringBuilder(100);
				sb.AppendFormat("     **** ABSENCE ****{0}", Environment.NewLine);
				foreach (var row in MonthlyAbsenceRows)
				{
					sb.AppendFormat("          {0}", row.ToString());
				}
				return sb.Append(Environment.NewLine).ToString();
			}
			else
			{
				return string.Empty;
			}
		}

		public string GetSpecialAssignmentsDebugString()
		{
			if (SpecialAssignments != null && SpecialAssignments.Count > 0)
			{
				var sb = new StringBuilder(100);
				sb.AppendFormat("     **** SPECIAL ASSIGNMENTS ****{0}", Environment.NewLine);
				foreach (var row in SpecialAssignments)
				{
					sb.AppendFormat("          {0}", row.ToString());
				}
				return sb.Append(Environment.NewLine).ToString();
			}
			else
			{
				return string.Empty;
			}
		}

		public string GetAssignedRequestsDebugString()
		{
			if (AssignedRequests != null && AssignedRequests.Count > 0)
			{
				var sb = new StringBuilder(50);
				sb.AppendFormat("     **** REQUESTS ASSIGNED ****{0}", Environment.NewLine);
				foreach (var row in AssignedRequests)
				{
					sb.AppendFormat("          {0}", row.ToString());
				}
				return sb.Append(Environment.NewLine).ToString();
			}
			else
			{
				return string.Empty;
			}
		}

	}
	public class ResourceRow
	{
		#region Properties
		public int ResourceId { get; set; }
		public decimal ResourceContractHours { get; set; }
		public decimal UtilizationPercent { get; set; }
		public int CountryId { get; set; }
		public string ResourceName { get; set; }
		public decimal CountryWeeklyHours { get; set; }
		public bool AllowWeeklyFteCalculation { get; set; }
		#endregion

		public ResourceRow(IDataReader r)
		{
			ResourceId = DbSafe.Int(r["ResourceId"]);
			ResourceContractHours = DbSafe.Decimal(r["ContractHours"]);
			UtilizationPercent = DbSafe.Decimal(r["Utilization"]) / 100;
			CountryId = DbSafe.Int(r["CountryId"]);
			ResourceName = DbSafe.StringValue(r["Name"]);
			CountryWeeklyHours = DbSafe.Decimal(r["WeeklyHours"]);
			AllowWeeklyFteCalculation = DbSafe.Bool(r["AllowWeeklyFteCalculation"]);
		}

		public override string ToString()
		{
			return string.Format("Resource Id:{0}, Contract Hours: {1}{2}Utilization: {3}{2}Country: {4}{2}",
				ResourceId,
				ResourceContractHours,
				Environment.NewLine,
			 UtilizationPercent.To3DecimalString(),
			 CacheService.Country(CountryId).Name);
		}
	}

	public class SpecialAssignmentRow
	{
		#region Properties
		public int SpecialAssignmentId { get; set; }
		public int ResourceId { get; set; }
		public DateTime StartDate { get; set; }
		public DateTime StopDate { get; set; }
		public decimal FtePerMonth { get; set; }
		#endregion

		public SpecialAssignmentRow(IDataReader r)
		{
			SpecialAssignmentId = DbSafe.Int(r["SpecialAssignmentId"]);
			ResourceId = DbSafe.Int(r["ResourceId"]);
			StartDate = DbSafe.DateTime(r["StartDate"]);
			StopDate = DbSafe.DateTime(r["StopDate"]);
			FtePerMonth = DbSafe.Decimal(r["FTEPerMonth"]);
		}

		public override string ToString()
		{
			return string.Format("Id: {0}, Assignment Start Date: {1}, Assignment Stop Date: {2}, FTE Per Month: {3}{4}",
							SpecialAssignmentId.ToString(),
							StartDate.ToShortDateString(),
							StopDate.ToShortDateString(),
							FtePerMonth.To3DecimalString(),
							Environment.NewLine);
		}
	}

	public abstract class AbsenceRow
	{
		#region Properties
		public int ResourceId { get; set; }
		public decimal HoursAbsence { get; set; }
		public decimal HoursAbsenceWithUtilization { get; set; }
		#endregion

		public AbsenceRow(IDataReader r)
		{
			ResourceId = DbSafe.Int(r["ResourceId"]);
			HoursAbsence = DbSafe.Decimal(r["HoursAbsence"]);
			HoursAbsenceWithUtilization = DbSafe.Decimal(r["HoursAbsenceWithUtilization"]);
		}
	}
	public class MonthlyAbsenceRow : AbsenceRow
	{
		#region Properties
		public int AbsenceMonthYearNumber { get; set; }
		public DateTime AbsenceMonth { get; set; }
		#endregion

		public MonthlyAbsenceRow(IDataReader r) : base(r)
		{
			AbsenceMonthYearNumber = DbSafe.Int(r["MonthAbsence"]);
			AbsenceMonth = DateHelp.MonthNumberToDate(AbsenceMonthYearNumber);
		}
		public override string ToString()
		{
			return string.Format("Absence Month: {0}, Absence Hours: {1}{2}",
							AbsenceMonthYearNumber.ToString(),
							HoursAbsence.To3DecimalString(),
							Environment.NewLine);
		}
	}

	public class DailyAbsenceRow : AbsenceRow
	{
		#region Properties
		public DateTime AbsenceDate { get; set; }
		#endregion
		public DailyAbsenceRow(IDataReader r) : base(r)
		{
			AbsenceDate = DbSafe.DateTime(r["AbsenceDate"]);
		}
	}

	public class WeeklyAbsenceRow : AbsenceRow
	{
		#region Properties
		public DateTime WeeklyStartDate { get; set; }
		#endregion

		public WeeklyAbsenceRow(IDataReader r) : base(r)
		{
			WeeklyStartDate = DbSafe.DateTime(r["WeekStartDate"]);
		}
	}

	public class AssignmentRow
	{
		#region Properties
		public int RequestId { get; set; }
		public int ResourceId { get; set; }
		public decimal Utilization { get; set; }
		public RequestStatusName RequestStatus { get; set; }
		#endregion

		public AssignmentRow(IDataReader r)
		{
			RequestId = DbSafe.Int(r["RequestId"]);
			ResourceId = DbSafe.Int(r["ResourceId"]);
			Utilization = DbSafe.Decimal(r["Utilization"]);
			RequestStatus = (RequestStatusName)DbSafe.Int(r["RequestStatusId"]);
		}

		public override string ToString()
		{
			return string.Format("Request Id: {0}, Utilization: {1}{2}",
							RequestId,
							Utilization.To3DecimalString(),
							Environment.NewLine);
		}
	}
}
