﻿using System;
using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class SiteSchedule
	{
		public Dictionary<int, List<SiteScheduleRow>> SiteScheduleRows { get; set; }

		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="r"></param>
		public SiteSchedule(IDataReader r)
		{
			SiteScheduleRows = new Dictionary<int, List<SiteScheduleRow>>();
			List<SiteScheduleRow> siteScheduleRowList;

			while (r.Read())
			{
				int siteId = DbSafe.Int(r["SiteId"]);
				if (!SiteScheduleRows.TryGetValue(siteId, out siteScheduleRowList))
				{
					siteScheduleRowList = new List<SiteScheduleRow>();
					SiteScheduleRows.Add(siteId, siteScheduleRowList);
				}
				siteScheduleRowList.Add(new SiteScheduleRow(r));
			}
		}
		#endregion
	}

	#region SiteScheduleRow
	/// <summary>
	/// Data structure to store Site Schedule
	/// </summary>
	public class SiteScheduleRow : BaseSearchModel
	{
		#region Properties
		public int SiteId { get; set; }
		public CalculatorType_E CalculatorTypeId { get; set; }
		public DateTime? StartMileStoneDate { get; set; }
		public DateTime? StartProjectMilestoneDate { get; set; }
		public DateTime? StartCountryMilestoneDate { get; set; }
		public DateTime? StopMileStoneDate { get; set; }
		public FrequencyDateSource_E StopMileStoneDateSource { get; set; }
		public DateTime? SSUCompletionDate { get; set; }
		public DateTime? StopProjectMilestoneDate { get; set; }
		public DateTime? StopCountryMilestoneDate { get; set; }
		public DateTime? LSIMilestoneDate { get; set; }
		public FrequencyDateSource_E LSIMilestoneDateSource { get; set; }
		public FrequencyDateSource_E StartDateSource { get; set; }
		public FrequencyDateSource_E StopDateSource { get; set; }
		public FrequencyDateSource_E StartDateActualSource { get; set; }
		public FrequencyDateSource_E StopDateActualSource { get; set; }
		public int SivFsiWeeks { get; set; }
		public int SivPerSite { get; set; }
		public decimal VisitFrequency { get; set; }
		public int TierCycle { get; set; }
		#endregion

		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		public SiteScheduleRow() { }
		#endregion

		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		internal SiteScheduleRow(IDataReader r)
		{
			CalculatorTypeId = (CalculatorType_E)DbSafe.Int(r["TypeId"]);
			StartDate = DbSafe.DateTime(r["StartDate"]);
			StopDate = DbSafe.DateTime(r["StopDate"]);
			StartMileStoneDate = DbSafe.DateTimeNull(r["StartMileStoneDate"]);
			StartProjectMilestoneDate = DbSafe.DateTimeNull(r["StartProjectMilestoneDate"]);
			StartCountryMilestoneDate = DbSafe.DateTimeNull(r["StartCountryMilestoneDate"]);
			StopMileStoneDate = DbSafe.DateTimeNull(r["StopMileStoneDate"]);
			SSUCompletionDate = DbSafe.DateTimeNull(r["SsuCompletionDate"]);
			StopProjectMilestoneDate = DbSafe.DateTimeNull(r["StopProjectMilestoneDate"]);
			StopCountryMilestoneDate = DbSafe.DateTimeNull(r["StopCountryMilestoneDate"]);
			LSIMilestoneDate = DbSafe.DateTimeNull(r["LSIMilestoneDate"]);
			SiteId = DbSafe.Int(r["SiteId"]);
			SivPerSite = DbSafe.Int(r["SivPerSite"]);
			SivFsiWeeks = DbSafe.Int(r["SivFsiWeeks"]);
			VisitFrequency = DbSafe.Decimal(r["VisitFrequency"]);
			StartDateSource = (FrequencyDateSource_E)DbSafe.Int(r["StartDateSource"]);
			StopDateSource = (FrequencyDateSource_E)DbSafe.Int(r["StopDateSource"]);
			LSIMilestoneDateSource = (FrequencyDateSource_E)DbSafe.Int(r["LSIMilestoneDateSource"]);
			StopMileStoneDateSource = (FrequencyDateSource_E)DbSafe.Int(r["StopMileStoneDateSource"]);

			SivFsiWeeks = SivFsiWeeks <= 0 ? 1 : SivFsiWeeks;
			VisitFrequency = VisitFrequency <= 0 ? CalculatorTypeId == CalculatorType_E.LSO_COV ? 0 : 4 : VisitFrequency;
		}
		#endregion
	}
	#endregion
}
