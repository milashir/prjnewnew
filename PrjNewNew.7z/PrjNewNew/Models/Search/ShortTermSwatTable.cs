﻿using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class ShortTermSwatSchedulerData : IRequestSchedulerData
	{
		public RequestData RequestData { get; private set; }
		public ShortTermSwatData ShortTermSwatData { get; private set; }

		public ShortTermSwatSchedulerData(string spName, List<int> requestIdList)
		{
			using (var dr = DbHelp.ExecuteDataReaderSP(spName, DbHelp.GetIdTableTypeParameter("requestIds", requestIdList)))
			{
				try
				{
					RequestData = new RequestData(dr);
					dr.NextResult();

					ShortTermSwatData = new ShortTermSwatData(dr);
					dr.NextResult();
				}
				finally { dr.Close(); }
			}
		}

		public ShortTermSwatSchedulerData()
		{
			RequestData = new RequestData();
			ShortTermSwatData = new ShortTermSwatData();
		}
	}

	public sealed class ShortTermSwatOnSiteSchedulerData : ShortTermSwatSchedulerData
	{
		public ShortTermSwatOnSiteSchedulerData(List<int> requestIdList) : base("GetRequestSchedule_ShortTermSwatOnSiteRequests", requestIdList) { }
	}

	public sealed class ShortTermSwatPhoneSchedulerData : ShortTermSwatSchedulerData
	{
		public ShortTermSwatPhoneSchedulerData(List<int> requestIdList) : base("GetRequestSchedule_ShortTermSwatPhoneRequests", requestIdList) { }
	}

	public class ShortTermSwatData
	{
		public Dictionary<int, ShortTermSwatRow> ShortTermSwatRows { get; private set; }

		public ShortTermSwatData(IDataReader r)
			: this()
		{
			while (r.Read())
			{
				ShortTermSwatRows.Add(DbSafe.Int(r["RequestId"]), new ShortTermSwatRow(r));
			}
		}

		public ShortTermSwatData()
		{
			ShortTermSwatRows = new Dictionary<int, ShortTermSwatRow>();
		}
	}

	public class ShortTermSwatRow : BaseSearchModel
	{
		#region Properties
		public CalculatorType_E TypeId { get; private set; }
		#endregion

		public ShortTermSwatRow(IDataReader r)
			: base(r)
		{
			TypeId = (CalculatorType_E)DbSafe.Int(r["TypeId"]);
			HoursNeeded = DbSafe.Decimal(r["HoursNeeded"]);
		}
	}
}
