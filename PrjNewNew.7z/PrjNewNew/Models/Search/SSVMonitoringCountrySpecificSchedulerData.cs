﻿using System;
using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public sealed class SsvCountryLevelForecastSchedulerData : IRequestSchedulerData
	{
		public RequestData RequestData { get; private set; }
		public SsvCountryLevelForecastData SsvCountryLevelForecastData { get; private set; }

		public SsvCountryLevelForecastSchedulerData(List<int> requestIdList)
		{
			using (var dr = DbHelp.ExecuteDataReaderSP("GetRequestSchedule_SSVMonitoringCountrySpecificRequests", DbHelp.GetIdTableTypeParameter("requestIds", requestIdList)))
			{
				try
				{
					RequestData = new RequestData(dr);

					dr.NextResult();
					SsvCountryLevelForecastData = new SsvCountryLevelForecastData(dr);

					dr.NextResult();
					MapSiteLevelHours(dr);

				}
				finally { dr.Close(); }
			}
		}

		private void MapSiteLevelHours(System.Data.SqlClient.SqlDataReader dr)
		{
			while (dr.Read())
			{
				var countryRequestId = DbSafe.Int(dr["RequestId"]);

				SsvCountryLevelForecastRow countryForecastRow;
				if (SsvCountryLevelForecastData.SsvCountryLevelForecastRows.TryGetValue(countryRequestId, out countryForecastRow))
				{
					countryForecastRow.TotalSiteLevelHours = DbSafe.Decimal(dr["TotalSiteHours"]);
				}
			}
		}

		public SsvCountryLevelForecastSchedulerData()
		{
			RequestData = new RequestData();
			SsvCountryLevelForecastData = new SsvCountryLevelForecastData();
		}
	}

	public class SsvCountryLevelForecastData
	{
		public Dictionary<int, SsvCountryLevelForecastRow> SsvCountryLevelForecastRows { get; private set; }

		public SsvCountryLevelForecastData(IDataReader r)
			: this()
		{
			while (r.Read())
			{
				SsvCountryLevelForecastRows.Add(DbSafe.Int(r["RequestId"]), new SsvCountryLevelForecastRow(r));
			}
		}

		public SsvCountryLevelForecastData()
		{
			SsvCountryLevelForecastRows = new Dictionary<int, SsvCountryLevelForecastRow>();
		}
	}

	public class SsvCountryLevelForecastRow : BaseSearchModel
	{
		public decimal TotalCoutryLevelForecastHours { get; set; }
		public decimal TotalSiteLevelHours { get; set; }
		public decimal OutstandinCountryLevelHours { get { return Math.Max(0, TotalCoutryLevelForecastHours - TotalSiteLevelHours); } } //We do not need -ve hours

		public SsvCountryLevelForecastRow(IDataReader r)
			: base(r)
		{
			TotalCoutryLevelForecastHours = DbSafe.Decimal(r["TotalHours"]);
		}
	}
}
