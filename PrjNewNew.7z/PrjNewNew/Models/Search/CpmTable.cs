﻿using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class PhaseSchedulerData : IRequestSchedulerData
	{
		public RequestData RequestData { get; private set; }
		public PhaseData CpmData { get; private set; }

		public PhaseSchedulerData(string spName, List<int> requestIdList)
		{
			using (var dr = DbHelp.ExecuteDataReaderSP(spName, DbHelp.GetIdTableTypeParameter("requestIds", requestIdList)))
			{
				try
				{
					RequestData = new RequestData(dr);
					dr.NextResult();

					CpmData = new PhaseData(dr);
				}
				finally { dr.Close(); }
			}
		}

		public PhaseSchedulerData()
		{
			RequestData = new RequestData();
			CpmData = new PhaseData();
		}
	}

	public sealed class CpmSchedulerData : PhaseSchedulerData
	{
		public CpmSchedulerData(List<int> requestIdList) : base("GetRequestSchedule_PhaseCalculatorRequests", requestIdList) { }

		public CpmSchedulerData() { }
	}

	public sealed class RegionalPhaseSchedulerData : PhaseSchedulerData
	{
		public RegionalPhaseSchedulerData(List<int> requestIdList) : base("GetRequestSchedule_RegionalPhaseCalculatorRequests", requestIdList) { }

		public RegionalPhaseSchedulerData() { }
	}

	public sealed class GlobalPhaseSchedulerData : PhaseSchedulerData
	{
		public GlobalPhaseSchedulerData(List<int> requestIdList) : base("GetRequestSchedule_GlobalPhaseCalculatorRequests", requestIdList) { }

		public GlobalPhaseSchedulerData() { }
	}

	public sealed class QipConnectedProposalData : PhaseSchedulerData
	{
		public QipConnectedProposalData(List<int> requestIdList) : base("GetRequestSchedule_QipConnectedProposalRequests", requestIdList) { }

		public QipConnectedProposalData() { }
	}

	public class PhaseData
	{
		public Dictionary<int, SearchRowData<PhaseRow, PhaseAdhocRow>> PhaseRowData { get; set; }

		public PhaseData(IDataReader r)
			: this()
		{
			MapPhaseRows(r);

			r.NextResult();

			MapPhaseAdhocRows(r);
		}

		private void MapPhaseAdhocRows(IDataReader r)
		{
			SearchRowData<PhaseRow, PhaseAdhocRow> phaseRowData;
			while (r.Read())
			{
				int requestId = DbSafe.Int(r["RequestId"]);

				if (!PhaseRowData.TryGetValue(requestId, out phaseRowData))
				{
					phaseRowData = new SearchRowData<PhaseRow, PhaseAdhocRow>();
					PhaseRowData.Add(requestId, phaseRowData);
				}
				phaseRowData.AdhocRows.Add(new PhaseAdhocRow(r));
			}
		}

		private void MapPhaseRows(IDataReader r)
		{
			SearchRowData<PhaseRow, PhaseAdhocRow> phaseRowData;
			while (r.Read())
			{
				int requestId = DbSafe.Int(r["RequestId"]);
				if (!PhaseRowData.TryGetValue(requestId, out phaseRowData))
				{
					phaseRowData = new SearchRowData<PhaseRow, PhaseAdhocRow>();
					PhaseRowData.Add(requestId, phaseRowData);
				}
				phaseRowData.Rows.Add(new PhaseRow(r));
			}
		}

		public PhaseData()
		{
			PhaseRowData = new Dictionary<int, SearchRowData<PhaseRow, PhaseAdhocRow>>();
		}
	}

	public class PhaseRow : BaseSearchModel
	{
		#region Properties
		public FTEMilestoneType_E FTEMileStoneType { get; set; }
		public FrequencyDateSource_E StartDateSource { get; set; }
		public FrequencyDateSource_E StopDateSource { get; set; }
		public CalculatorType_E Stage { get; set; }
		#endregion

		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="r"></param>
		public PhaseRow(IDataReader r)
			: base(r)
		{
			var cc = new ColumnChecker(r);
			RequestId = DbSafe.Int(r["RequestId"]);
			FTEMileStoneType = (FTEMilestoneType_E)DbSafe.Int(r["FTEMileStoneTypeId"]);
			WeeklyHours = DbSafe.Decimal(r["WeeklyHours"]);
			StartDateSource = (FrequencyDateSource_E)DbSafe.Int(r["StartDateSource"]);
			StopDateSource = (FrequencyDateSource_E)DbSafe.Int(r["StopDateSource"]);
			if (cc.HasColumn("FTETypeId")) { Stage = (CalculatorType_E)DbSafe.Int(r["FTETypeId"]); }
		}
		#endregion

		public PhaseRow() { }

	}

	public class PhaseAdhocRow : BaseSearchModel
	{
		public PhaseAdhocRow() { }

		public PhaseAdhocRow(IDataReader r)
			: base(r)
		{
			WeeklyHours = DbSafe.Decimal(r["WeeklyHours"]);
		}
	}
}
