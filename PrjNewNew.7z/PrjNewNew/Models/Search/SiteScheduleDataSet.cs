﻿using System;
using System.Data;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class SiteScheduleData
	{
		#region Properties
		public SiteSchedule SiteSchedule { get; private set; }
		#endregion

		#region SiteScheduleData
		/// <summary>
		/// Maps dataset to strongly typed object
		/// </summary>
		/// <param name="r"></param>
		public SiteScheduleData(IDataReader r)
		{
			if (r == null)
			{
				throw new ArgumentNullException("DataReader");
			}

			SiteSchedule = new SiteSchedule(r);
		}
		#endregion
	}
}
