﻿using System;
using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class ProjectTierData
	{
		public Dictionary<int, TierRow> TierByProjectId { get; private set; }

		public ProjectTierData()
		{
			TierByProjectId = new Dictionary<int, TierRow>();
		}

		public ProjectTierData(IDataReader r)
			: this()
		{
			while (r.Read())
			{
				var tierRow = new TierRow(r);

				//As per design, project can have only one tier defined for a calculator group. 
				//Also scheduler is setup to work with one resource type at a time for DTE RRTs
				if (!TierByProjectId.ContainsKey(tierRow.ProjectId))
				{
					TierByProjectId.Add(tierRow.ProjectId, tierRow);
				}
			}
		}
	}

	public class TierRow
	{
		#region Properties

		public int ProjectId { get; set; }
		public Tier_E TierId { get; set; }
		public CalculatorGroup_E CalculatorGroup { get; set; }
		public int TierCycle { get; set; }
		public int OnsiteVisitRatio { get; set; }
		public int RemoteVisitRatio { get; set; }
		public decimal TargetPercentage { get; set; }
		#endregion

		public TierRow(IDataReader r)
		{
			ProjectId = DbSafe.Int(r["ProjectId"]);
			TierId = (Tier_E)DbSafe.Int(r["TierId"]);
			CalculatorGroup = (CalculatorGroup_E)DbSafe.Int(r["CalculatorTypeId"]);
			TierCycle = DbSafe.Int(r["TierCycle"]);
			OnsiteVisitRatio = DbSafe.Int(r["OnsiteVisitRatio"]);
			RemoteVisitRatio = DbSafe.Int(r["RemoteVisitRatio"]);
		}
	}
}