﻿using System.Collections.Generic;
using System.Data;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class CountryCalculatorData
	{
		public Dictionary<int, List<CountryCalculatorRow>> CountryCalculatorRowDataByRequestId { get; private set; }

		public CountryCalculatorData()
		{
			CountryCalculatorRowDataByRequestId = new Dictionary<int, List<CountryCalculatorRow>>();
		}

		public CountryCalculatorData(IDataReader r)
			: this()
		{
			List<CountryCalculatorRow> countryCalculatorRowData;
			ColumnChecker cc = null;

			while (r.Read())
			{
				if (cc == null)
				{
					cc = new ColumnChecker(r);
				}

				int requestId = DbSafe.Int(r["RequestId"]);

				if (!CountryCalculatorRowDataByRequestId.TryGetValue(requestId, out countryCalculatorRowData))
				{
					countryCalculatorRowData = new List<CountryCalculatorRow>();
					CountryCalculatorRowDataByRequestId.Add(requestId, countryCalculatorRowData);
				}

				countryCalculatorRowData.Add(new CountryCalculatorRow(r, cc));
			}
		}
	}

	/// <summary>
	/// Shared between Non-DTE CRA Project-Country, Non-DTE Pharmacy CRA Project-Country, DTE CRA Project-Country, DTE Pharmacy CRA Project-Country
	/// </summary>
	public class CountryCalculatorRow : BaseSearchModel
	{
		#region Properties

		public int MonitoringAttributeId { get; set; }
		public int ProjectId { get; set; }
		public int CountryId { get; set; }
		public CalculatorType_E CalcualtorType { get; set; }
		public CalculatorGroup_E CalculatorGroup { get; set; }

		public decimal AdminTime { get; set; }

		public int SivPerSite { get; set; }
		public decimal VisitFrequency { get; set; }
		public decimal TimePerOnsiteVisit { get; set; }

		public int PhoneSivPerSite { get; set; }
		public decimal PhoneVisitFrequency { get; set; }
		public decimal TimePerRemoteVisit { get; set; }

		#endregion

		public CountryCalculatorRow() { }

		internal CountryCalculatorRow(IDataReader r, ColumnChecker cc)
			: base(r)
		{
			MonitoringAttributeId = DbSafe.Int(r["MonitoringAttributeId"]);
			ProjectId = DbSafe.Int(r["ProjectId"]);
			CountryId = DbSafe.Int(r["CountryId"]);
			CalcualtorType = (CalculatorType_E)DbSafe.Int(r["TypeId"]);
			CalculatorGroup = (CalculatorGroup_E)DbSafe.Int(r["CalculatorTypeId"]);
			AdminTime = DbSafe.Decimal(r["AdminTime"]);

			SivPerSite = DbSafe.Int(r["SIVPerSite"]);
			VisitFrequency = DbSafe.Decimal(r["VisitFrequency"]);
			TimePerOnsiteVisit = DbSafe.Decimal(r["TimePerOnsiteVisit"]);

			PhoneSivPerSite = DbSafe.Int(r["PhoneSIVPerSite"]);
			PhoneVisitFrequency = DbSafe.Decimal(r["PhoneVisitFrequency"]);
			TimePerRemoteVisit = DbSafe.Decimal(r["TimePerRemoteVisit"]);
		}

		public override string ToString()
		{
			return string.Format("[Milestone: {0} - {1}]", StartDate.ToShortDateString(), StopDate.ToShortDateString());
		}
	}
}
