﻿using System.Collections.Generic;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.ResourceMatching.Interfaces;

namespace Quintiles.RM.Clinical.Domain.Models.Search
{
	public class NonDteMonitoringCountryLevelForecastData : MonitoringCountryLevelForecastData
	{
		public NonDteMonitoringCountryLevelForecastData()
			: base()
		{ }

		public NonDteMonitoringCountryLevelForecastData(string spName, List<int> list)
		{
			using (var dr = DbHelp.ExecuteDataReaderSP(spName, ConfigValue.CommandTimeout, DbHelp.GetIdTableTypeParameter("requestIds", list)))
			{
				try
				{
					RequestData = new CountryLevelForecastRequestData(dr);
					dr.NextResult();

					CountryCalculatorData = new CountryCalculatorData(dr);
				}
				finally { dr.Close(); }
			}
		}
	}
	public sealed class StdMonitoringCountryLevelForecastData : NonDteMonitoringCountryLevelForecastData
	{
		public StdMonitoringCountryLevelForecastData(List<int> requestIdList) : base("GetRequestSchedule_StdMonitoringCountryLevelForecastRequests", requestIdList) { }
	}

	public sealed class PharmacyMonitoringCountryLevelForecastData : NonDteMonitoringCountryLevelForecastData
	{
		public PharmacyMonitoringCountryLevelForecastData(List<int> requestIdList) : base("GetRequestSchedule_PharmacyMonitoringCountryLevelForecastRequests", requestIdList) { }
	}
}
