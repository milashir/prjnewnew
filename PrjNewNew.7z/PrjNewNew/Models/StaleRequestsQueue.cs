﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class StaleRequestQueue : AbstractActiveRecordBaseModel<StaleRequestQueue>
	{
		[PrimaryKey(Column = "StaleRequestQueueId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public int RequestId { get; set; }

		[Property]
		public string LockedBy { get; set; }

		[Property]
		public DateTime? LockedOn { get; set; }

		[Property]
		public string ThreadGuid { get; set; }


		public static SortedDictionary<int, int> GetRequestIdsFromStaleRequestsQueue(int maxRecordCount)
		{
			var requestIdDictionary = new SortedDictionary<int, int>();

			using (SqlDataReader dr = DbHelp.ExecuteDataReaderSP("GetStaleRequestsFifoQueue", new SqlParameter("serverName", ExtensionMethods.GetCurrentServerName()), new SqlParameter("maxRecordCount", maxRecordCount)))
			{
				try
				{
					while (dr.Read())
					{
						requestIdDictionary.Add(DbSafe.Int(dr["StaleRequestQueueId"]), DbSafe.Int(dr["RequestId"]));
					}
				}
				finally { dr.Close(); }
			}

			return requestIdDictionary;
		}

		public static void UpdateThreadGuid(string threadGuid, int[] staleRequestQueueIdList)
		{
			var sql = string.Format(@"UPDATE  dbo.StaleRequestQueue  WITH ( ROWLOCK, READPAST )
                        SET     ThreadGuid = '{0}'
                        WHERE   StaleRequestQueueId IN ({1})", DbSafe.EscapeQuote(threadGuid), string.Join(",", staleRequestQueueIdList.Select(v => v.ToString()).ToArray()));
			DbHelp.ExecuteNonQueryText(sql);
		}

		public static void DeleteProcessedRequests(string threadGuid)
		{
			//because of the deadlock we use query instead of active record.
			var sql = string.Format(@"DELETE FROM dbo.StaleRequestQueue  WITH ( ROWLOCK, READPAST ) WHERE ThreadGuid='{0}'", DbSafe.EscapeQuote(threadGuid));
			DbHelp.ExecuteNonQueryText(sql);
		}

		internal static void MarkRequestForRecaching(int requestId, string modifiedBy)
		{
			try
			{
				DbHelp.ExecuteNonQueryText(String.Format(@"INSERT INTO dbo.StaleRequestQueue ( RequestId, LastModifiedBy, LastModifiedOn, CreatedBy, CreatedOn) VALUES  ( {0} , N'{1}' , GETDATE() , N'{1}' , GETDATE());", requestId, DbSafe.EscapeQuote(modifiedBy)));
			}
			catch (Exception) { }
		}
	}

}
