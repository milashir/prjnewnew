﻿using Castle.ActiveRecord;
using NHibernate.Criterion;


namespace Quintiles.RM.Clinical.Domain.Models
{
    [ActiveRecord]
	public class RmConstant : AbstractActiveRecordBaseModel<RmConstant>
    {

        [PrimaryKey(Column ="ConstantId", UnsavedValue = "-1")]
        public override int Id { set { this._id = value; } get { return this._id; } }

        [Property]
        public string Name {get;set;}

        [Property]
        public string Value {get;set;}


    }
}
