﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RPM.Common;
using Quintiles.RM.Clinical.Services;
using Quintiles.RM.Clinical.Domain.Models.Permissions;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class Organization : AbstractActiveRecordBaseModel<Organization>, IEquatable<Organization>, IComparable<Organization>, ICodeTable
	{
		#region Mapped Properties

		[PrimaryKey(Column = "OrganizationId")]
		public override int Id { get; set; }
		[Property]
		public string Name { get; set; }
		[Property]
		public string HeadQid { get; set; }
		[Property]
		public bool IsEnabled { get; set; }
		[Property]
		public string ShortName { get; set; }
		[Property]
		public int SortOrder { get; set; }
		[Property]
		public bool AutoGenerateMonitoringRequests { get; set; }
		[Property]
		public decimal? GlobalWeeklyHours { get; set; }
		[Property]
		public bool IsProjectLeadership { get; set; }

		public bool Equals(Organization other)
		{
			return ((this.Id > 0 && other.Id > 0) && this.Id == other.Id);
		}

		public int CompareTo(Organization other)
		{
			return String.CompareOrdinal(Name, other.Name);
		}

		#endregion


		public static List<OrganizationProjectMilestone> GetOrganizationMilestoneList(int organizationId)
		{
			var projectMilestoneOrgMap = new List<OrganizationProjectMilestone>();
			string sqlQuery = @"Select DISTINCT A.PROJECTMILESTONEID,A.DESCRIPTION AS projectMilestoneName ,A.DisplayOrder,(case when b.PROJECTMILESTONEID is null then 0 else 1 end) AS organizationProjectMilestone from cd_ProjectMilestone A LEFT OUTER JOIN OrganizationProjectMilestone_XREF  B ON A.ProjectMileStoneId=B.ProjectMileStoneId and B.OrganizationId=" + organizationId + " Where A.IsVisibleInUI=1 Order By A.DisplayOrder";
			using (IDataReader dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						projectMilestoneOrgMap.Add(new OrganizationProjectMilestone
						{
							projectMileStoneId = DbSafe.Int(dr["projectMileStoneId"]),
							projectMilestoneName = DbSafe.StringValue(dr["projectMilestoneName"]),
							organizationHasProjectMilestone = DbSafe.Bool(dr["organizationProjectMilestone"])
						});
					}
				}
				finally { dr.Close(); }
			}
			return projectMilestoneOrgMap;
		}

		public static List<Organization_WS> GetAllOrganizationList()
		{
			List<Organization_WS> organizationList = new List<Organization_WS>();
			string sqlQuery =
			@"SELECT	O.Name AS OrganizationName ,
						O.OrganizationId ,
						OU.OrganizationalUnitId ,
						OU.Name AS OrganizationalUnitName,
						OU.ShowPreferredSponsor AS ShowPreferredSponsor
			FROM    dbo.Organization O
					JOIN dbo.OrganizationalUnit OU ON O.OrganizationId = OU.OrganizationId
			WHERE   O.IsEnabled = 1
					AND OU.IsEnabled = 1
			ORDER BY O.Name, OU.Name";

			using (IDataReader dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						organizationList.Add(new Organization_WS
						{
							Id = (int)dr["OrganizationId"],
							Name = dr["OrganizationName"].ToString(),
							OrganizationalUnitName = dr["OrganizationalUnitName"].ToString(),
							OrganizationalUnitId = DbSafe.Int(dr["OrganizationalUnitId"]),
							ShowPreferredSponsor = DbSafe.Bool(dr["ShowPreferredSponsor"])
						});
					}
				}
				finally { dr.Close(); }
			}

			return organizationList;
		}

		#region Get Organization based on ResourceType ID
		/// <summary>
		/// Get list of Organizations filtered by ResourceType
		/// </summary>
		/// <param name="resourceTypeId"></param>
		/// <returns></returns>
		public static IList<Organization> GetByResourceTypeId(int resourceTypeId)
		{
			var orgUnits = new List<Organization>();

			string sqlQuery = string.Format(@"
					SELECT 
								OU.OrganizationId, OU.Name
					FROM	
								ResourceTypeOrganization_XREF xref 
								JOIN Organization OU ON xref.OrganizationId = OU.OrganizationId 
					WHERE 
								OU.IsEnabled=1 
								AND xref.ResourceTypeId = {0}", resourceTypeId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						orgUnits.Add(CacheService.GetOrganization(DbSafe.Int(dr["OrganizationId"])));
					}
				}
				finally { dr.Close(); }
			}

			return orgUnits;
		}
		#endregion

		public static PagedResponse<Organization_WS, GridCommonData> FindAllOrganizations()
		{
			return new ManageOrganizationsGridDataEngine(null).GetDataForGrid();
		}

		public static SingleExecutionAndValidationStatus_WS<OrganizationOrganizationUnit_WS> UpdateOrganizationOrganizationUnit(OrganizationOrganizationUnit_WS orgOrgUnit)
		{
			var response = new SingleExecutionAndValidationStatus_WS<OrganizationOrganizationUnit_WS>();
			response.RequestExecutionStatus.AdditionalData = orgOrgUnit;
			var loggedInUser = ExtensionMethods.GetCurrentUserQid();
			if (RmFunction.HasPermissionToFunction(RmFunction_E.Edit_Organizations, RmUser.FindByQid(loggedInUser), loggedInUser, new CustomPermissionArg(null, null)))
			{
				if (orgOrgUnit.IsValidForEdit(response))
				{
					Organization org;
					OrganizationalUnit orgUnit;
					OrganizationProjectMilestone orgPM = new OrganizationProjectMilestone();


					CacheService.AllOrganizations.TryGetValue(orgOrgUnit.OrganizationId, out org);
					CacheService.AllOrganizationalUnits.TryGetValue(orgOrgUnit.OrganizationalUnitId, out orgUnit);

					if (org == null)
					{
						response.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, string.Format("Organization Id {0} not found in system", orgOrgUnit.OrganizationId), Utilities.MessageType_E.ConsolidateAndShowInDialog));
					}
					else if (orgUnit == null)
					{
						response.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, string.Format("Organizational Unit Id {0} not found in system", orgOrgUnit.OrganizationalUnitId), Utilities.MessageType_E.ConsolidateAndShowInDialog));
					}
					else
					{
						org.UpdateOrganization(orgOrgUnit);
						if (orgOrgUnit.QipDisconnectMinQipVersion.HasValue)
						{
							QipDisconnectResourceTypeOrgnizationalUnitCountry.InsertUpdateQipDisconnectData(orgOrgUnit.QipDisconnectResourceTypesList, orgOrgUnit.QipDisconnectCountriesList, orgOrgUnit.OrganizationalUnitId, orgOrgUnit.QipDisconnectMinQipVersion, ExtensionMethods.GetCurrentUserQid());
						}
						if (orgOrgUnit.DisassociateOrganizationalUnit)
						{
							DeleteOrgUnitAssociationFromResource(orgOrgUnit);
						}
						orgUnit.UpdateOrganizationalUnit(orgOrgUnit);
						OrganizationalUnit_PPM.InsertUpdateMultiple(orgOrgUnit.OrganizationalUnitPpmNameList, orgUnit);
						try
						{
							orgPM.addOrganizationProjectMilestone(orgOrgUnit.OrganizationId, orgOrgUnit.ProjectMilestoneIdsList);
						}
						catch (Exception ex)
						{
							response.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, string.Format("Organizational Project Milestones could not be saved properly." + ex.ToString()), Utilities.MessageType_E.ConsolidateAndShowInDialog));
						}
					}
				}
			}
			else
			{
				response.ValidationErrors.Add(new ValidationMessage_WS("", "You do not have permission to edit Organizations", Utilities.MessageType_E.SharepointNotification));
			}

			return response;
		}

		private static void DeleteOrgUnitAssociationFromResource(OrganizationOrganizationUnit_WS orgOrgUnit)
		{
			var sql = string.Format(@"UPDATE Resource set organizationalunitid = NULL, LastModifiedBy='{0}', LastModifiedOn=GETDATE() where organizationalunitid = {1}", ExtensionMethods.GetCurrentUserQid(), orgOrgUnit.OrganizationalUnitId);
			DbHelp.ExecuteNonQueryText(sql);
		}

		private void UpdateOrganization(OrganizationOrganizationUnit_WS orgOrgUnit)
		{
			if (IsEnabled != orgOrgUnit.OrganizationIsEnabled ||
					Name != orgOrgUnit.OrganizationName ||
					ShortName != orgOrgUnit.OrganizationShortName ||
				GlobalWeeklyHours != orgOrgUnit.GlobalWeeklyHours)
			{
				IsEnabled = orgOrgUnit.OrganizationIsEnabled;
				Name = orgOrgUnit.OrganizationName;
				ShortName = orgOrgUnit.OrganizationShortName;
				GlobalWeeklyHours = orgOrgUnit.GlobalWeeklyHours;
				SaveAndFlush();

				CacheService.ClearCache(CacheKey_E.Organization);
			}
		}

		internal static bool HasActiveOrganizationalUnits(int OrganizationId, out Dictionary<int, string> activeOrganizationalUnitList)
		{
			activeOrganizationalUnitList = CacheService.AllOrganizationalUnits.Values.Where(ou => ou.IsEnabled && ou.OrganizationId == OrganizationId).ToDictionary(ou => ou.Id, ou => ou.Name);
			return activeOrganizationalUnitList != null && activeOrganizationalUnitList.Count > 0;
		}

		public static List<Organization_WS> GetOrganizationOrganizationalUnitList()
		{
			var orgOrgUnitList = new List<Organization_WS>();

			var sql = @"SELECT  o.OrganizationId ,
													o.Name 'Organization' ,
													ou.OrganizationalUnitId ,
													ou.Name 'OrganizationalUnit'
									FROM    Organization o
													JOIN OrganizationalUnit ou ON o.OrganizationId = ou.OrganizationId
									WHERE   ou.IsEnabled = 1
													AND ou.IsProjectOrganizationalUnit = 1
									ORDER BY o.Name ,
													ou.Name;";

			using (IDataReader dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						orgOrgUnitList.Add(new Organization_WS
						{
							Id = DbSafe.Int(dr["OrganizationId"]),
							Name = DbSafe.StringValue(dr["Organization"]),
							OrganizationalUnitId = DbSafe.Int(dr["OrganizationalUnitId"]),
							OrganizationalUnitName = DbSafe.StringValue(dr["OrganizationalUnit"]),
						});
					}
				}
				finally { dr.Close(); }
			}
			return orgOrgUnitList;
		}


		public static SingleExecutionAndValidationStatus_WS<OrganizationOrganizationUnit_WS> AddOrganizationOrganizationUnit(OrganizationOrganizationUnit_WS orgOrgUnit)
		{
			var response = new SingleExecutionAndValidationStatus_WS<OrganizationOrganizationUnit_WS>();
			OrganizationProjectMilestone orgPM = new OrganizationProjectMilestone();
			var loggedInUser = ExtensionMethods.GetCurrentUserQid();
			if (RmFunction.HasPermissionToFunction(RmFunction_E.Edit_Organizations, RmUser.FindByQid(loggedInUser), loggedInUser, new CustomPermissionArg(null, null)))
			{
				if (orgOrgUnit.IsValidForAdd(response))
				{
					Organization org = orgOrgUnit.IsAddingNewOrganization ? Organization.AddNewOrganization(orgOrgUnit) : Organization.TryFind(orgOrgUnit.OrganizationId);

					if (org == null)
					{
						response.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, string.Format("Organization Id {0} not found in system", orgOrgUnit.OrganizationId), Utilities.MessageType_E.ConsolidateAndShowInDialog));
					}
					else
					{
						orgOrgUnit.OrganizationId = org.Id;
						var orgUnit = OrganizationalUnit.AddNewOrganizationalUnit(orgOrgUnit);
						OrganizationalUnit_PPM.InsertUpdateMultiple(orgOrgUnit.OrganizationalUnitPpmNameList, orgUnit);
						orgPM.addOrganizationProjectMilestone(orgOrgUnit.OrganizationId, orgOrgUnit.ProjectMilestoneIdsList);
						SetNewOrganizationUnitRMUserPermission(orgUnit.Id);
						HttpContext.Current.Session[orgOrgUnit.IsAddingNewOrganization ? Constants.SessionKeys.ORGANIZATION_ADDED_SUCCESSFULLY : Constants.SessionKeys.ORGANIZATIONAL_UNIT_ADDED_SUCCESSFULLY] = true;
					}
				}
			}
			else
			{
				response.ValidationErrors.Add(new ValidationMessage_WS("", "You do not have access to add new organizations", Utilities.MessageType_E.SharepointNotification));
			}

			return response;
		}

		private static void SetNewOrganizationUnitRMUserPermission(int orgUnitId)
		{
			DbHelp.ExecuteNonQueryText(string.Format("INSERT INTO [dbo].[RmUser_Organization_XREF]([RmUserId],[OrganizationalUnitId],[LastModifiedBy],[LastModifiedOn],[CreatedBy],[CreatedOn]) SELECT RmUserId, {0},'{1}','{2}','{1}','{2}' FROM dbo.RmUser_GrantAll_XREF WHERE OrganizationUnit = 1 ", orgUnitId, UserCache.Usr.QId, DateTime.Now, UserCache.Usr.QId, DateTime.Now));
		}

		private static Organization AddNewOrganization(OrganizationOrganizationUnit_WS orgOrgUnit)
		{
			var org = new Organization
			{
				IsEnabled = orgOrgUnit.OrganizationIsEnabled,
				Name = orgOrgUnit.OrganizationName,
				ShortName = orgOrgUnit.OrganizationShortName,
				HeadQid = string.Empty
			};

			org.SaveAndFlush();

			DbHelp.ExecuteNonQueryText(string.Format(@"INSERT  INTO dbo.OrganizationCountryMilestone_Xref 
																												( OrganizationId, CountryMilestoneId, LastModifiedBy, LastModifiedOn, CreatedBy, CreatedOn )
																								 SELECT  O.OrganizationId, CM.CountryMileStoneId, '{0}', GETDATE(), '{0}', GETDATE() 
																								 FROM    dbo.Organization O
																								 				 CROSS JOIN dbo.cd_CountryMileStone CM
																								 WHERE   AlwaysVisibleOnUi = 1 AND O.OrganizationId = {1};",
																								ExtensionMethods.GetCurrentUserQid(),
																								org.Id));

			CacheService.ClearCache(CacheKey_E.Organization);

			return org;
		}

		internal static Organization GetOrganizationById(int OrganizationId)
		{
			Organization org;
			CacheService.AllOrganizations.TryGetValue(OrganizationId, out org);
			return org;
		}

		internal static bool IsNameInUseAlready(string organizationName, int organizationId)
		{
			return CacheService.AllOrganizations.Values.FirstOrDefault(o => o.Id != organizationId && string.Equals(o.Name, organizationName, StringComparison.InvariantCultureIgnoreCase)) != null;
		}

		internal static bool IsShortNameInUseAlready(string organizationShortName, int organizationId, out string duplicateEntityName)
		{
			Organization org = CacheService.AllOrganizations.Values.FirstOrDefault(o => o.Id != organizationId && string.Equals(o.ShortName, organizationShortName, StringComparison.InvariantCultureIgnoreCase));
			duplicateEntityName = org == null ? null : org.Name;
			return org != null;
		}

		internal static bool HasActiveResourceTypes(int organizationId, out List<string> activeResourceTypeNameList)
		{
			activeResourceTypeNameList = null;

			using (var dr = DbHelp.ExecuteDataReaderText(string.Format(@"SELECT  Name AS ResourceType
																																	 FROM    dbo.ResourceTypeOrganization_XREF RTOX
																																	 				 JOIN dbo.ResourceType RT ON RTOX.ResourceTypeId = RT.ResourceTypeId
																																	 WHERE   OrganizationId = {0}
																																	 				 AND RT.IsEnabled = 1", organizationId)))
			{
				if (dr.HasRows)
				{
					try
					{
						activeResourceTypeNameList = new List<string>();
						while (dr.Read())
						{
							activeResourceTypeNameList.Add(DbSafe.StringValue(dr["ResourceType"]));
						}
					}
					finally { dr.Close(); }
				}
			}

			return activeResourceTypeNameList != null && activeResourceTypeNameList.Count > 0;
		}
	}
}
