﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Properties;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ResourceDelegate")]
	public class ResourceDelegate : AbstractActiveRecordBaseModel<ResourceDelegate>
	{
		[PrimaryKey(Column = "ResourceDelegateId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public int OriginalManagerResourceId { set; get; }

		[Property]
		public int DelegateManagerResourceId { get; set; }

		[Property]
		public DateTime StartDate { get; set; }

		[Property]
		public DateTime? StopDate { get; set; }

		public string OriginalManagerName { get; set; }
		public string DelegateManagerName { get; set; }


		public static IList<ResourceDelegate> GetDelegationStartDateInRange(int originalManagerResourceId, DateTime? checkDate)
		{
			return ResourceDelegate.FindAll().Where(rd => (rd.OriginalManagerResourceId == originalManagerResourceId && (checkDate <= rd.StopDate || rd.StopDate == null))).ToList();
		}

		public static IList<ResourceDelegate> GetDelegationStartDateStopDateIncludeRange(int originalManagerResourceId, DateTime? startDate, DateTime? stopDate)
		{
			return ResourceDelegate.FindAll().Where(rd => (rd.OriginalManagerResourceId == originalManagerResourceId && startDate <= rd.StopDate && stopDate >= rd.StopDate)).ToList();
		}

		public static IList<ResourceDelegate> GetDelegationInRange(int originalManagerResourceId, DateTime? checkDate)
		{
			return ResourceDelegate.FindAll().Where(rd => (rd.OriginalManagerResourceId == originalManagerResourceId && ((checkDate >= rd.StartDate && checkDate <= rd.StopDate) || (checkDate >= rd.StartDate && rd.StopDate == null)))).ToList();
		}

		public static IList<ResourceDelegate> GetDelegationStartDateInRangeAndId(int id, int originalManagerResourceId, DateTime? checkDate)
		{
			return ResourceDelegate.FindAll().Where(rd => (rd.Id < id && rd.OriginalManagerResourceId == originalManagerResourceId && (checkDate <= rd.StopDate || rd.StopDate == null))).ToList();
		}

		public static IList<ResourceDelegate> GetDelegationStartDateStopDateIncludeRangeAndId(int id, int originalManagerResourceId, DateTime? startDate, DateTime? stopDate)
		{
			return ResourceDelegate.FindAll().Where(rd => (rd.Id < id && rd.OriginalManagerResourceId == originalManagerResourceId && startDate <= rd.StopDate && stopDate >= rd.StopDate)).ToList();
		}

		public static IList<ResourceDelegate> GetDelegationInRangeAndId(int id, int originalManagerResourceId, DateTime? checkDate)
		{
			return ResourceDelegate.FindAll().Where(rd => (rd.Id < id && rd.OriginalManagerResourceId == originalManagerResourceId && ((checkDate >= rd.StartDate && checkDate <= rd.StopDate) || (checkDate >= rd.StartDate && rd.StopDate == null)))).ToList();
		}

		public static PagedResponse<ResourceDelegate, GridRowCommonData> GetDelegatedResourceList()
		{
			return new PagedResponse<ResourceDelegate, GridRowCommonData>
			{
				PageNumber = 1,
				Records = new DelegationGridDataEngine(null).GetDataForGrid().Records
			};

			//			var response = new PagedResponse<ResourceDelegate, GridRowCommonData> { PageNumber = 1 };
			//			response.Records = new List<ResourceDelegate>();

			//			var sql = @"SELECT  RD.ResourceDelegateId ,
			//													RD.OriginalManagerResourceId ,
			//													RD.DelegateManagerResourceId ,
			//													RD.StartDate ,
			//													RD.StopDate ,
			//													DR.ResourceName + ' - (' + DR.Qid + ')' AS DelegateManagerName ,
			//													ORG.ResourceName + ' - (' + ORG.Qid + ')' AS OriginalManagerName
			//									FROM    dbo.ResourceDelegate RD
			//													JOIN dbo.Resource DR ON RD.DelegateManagerResourceId = DR.ResourceId
			//													JOIN dbo.Resource ORG ON RD.OriginalManagerResourceId = ORG.ResourceId";

			//			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			//			{
			//				try
			//				{
			//					while (dr.Read())
			//					{
			//						response.Records.Add(ResourceDelegate.CreateFromReader(dr));
			//					}
			//				}
			//				finally { dr.Close(); }
			//			}

			//			return response;
		}

		public static bool CreateDelegation(int originalManagerResourceId, int delegateManagerResourceId, DateTime startDate, DateTime? stopDate, out string message)
		{
			bool success = false;
			message = string.Empty;
			try
			{
				ResourceDelegate rd = new ResourceDelegate();
				rd.OriginalManagerResourceId = originalManagerResourceId;
				rd.DelegateManagerResourceId = delegateManagerResourceId;
				rd.StartDate = startDate;
				rd.StopDate = stopDate;
				string strQId = ExtensionMethods.GetCurrentUserQid();
				rd.LastModifiedBy = strQId;
				rd.LastModifiedOn = DateTime.Today;
				rd.SaveAndFlush();
				success = true;
			}
			catch (Exception)
			{
				message = string.Format("The delegation was failed!", "");
			}

			return success;
		}

		//private static ResourceDelegate CreateFromReader(IDataReader dr)
		//{
		//	ResourceDelegate rd = null;

		//	if (dr != null)
		//	{
		//		ColumnChecker cc = new ColumnChecker(dr);
		//		rd = new ResourceDelegate();

		//		rd.Id = DbSafe.Int(dr["ResourceDelegateId"]);
		//		rd.OriginalManagerResourceId = DbSafe.Int(dr["OriginalManagerResourceId"]);
		//		rd.DelegateManagerResourceId = DbSafe.Int(dr["DelegateManagerResourceId"]);
		//		rd.StartDate = DbSafe.DateTime(dr["StartDate"]);
		//		rd.StopDate = DbSafe.DateTimeNull(dr["StopDate"]);

		//		if (cc.HasColumn("OriginalManagerName")) { rd.OriginalManagerName = DbSafe.StringValue(dr["OriginalManagerName"]); }
		//		if (cc.HasColumn("DelegateManagerName")) { rd.DelegateManagerName = DbSafe.StringValue(dr["DelegateManagerName"]); }
		//	}

		//	return rd;
		//}

		public static bool UpdateDelegation(int resourceDelegateId, int delegateManagerResourceId, string delegateManagerName, DateTime startDate, DateTime? stopDate, out string message)
		{
			bool success = false;
			message = string.Empty;

			try
			{
				var rd = ResourceDelegate.Find(resourceDelegateId);

				if (delegateManagerResourceId != rd.OriginalManagerResourceId)
				{
					rd.StartDate = startDate;
					rd.StopDate = stopDate;
					rd.DelegateManagerResourceId = delegateManagerResourceId;
					rd.LastModifiedBy = ExtensionMethods.GetCurrentUserQid();
					rd.LastModifiedOn = DateTime.Today;
					rd.SaveAndFlush();
					success = true;
				}
				else
				{
					message = Resources.DelegateManagerCannotBeSameAsOriginalManager;
				}
			}
			catch (NHibernate.ObjectNotFoundException)
			{
				success = false;
				message = string.Format("Resource {0} not found in RM system", delegateManagerName);
			}

			return success;
		}
	}
}
