﻿using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "OrganizationJobRoleTargetUtilization")]
	public class OrganizationJobRoleTargetUtilization : AbstractActiveRecordBaseModel<OrganizationJobRoleTargetUtilization>
	{
		[PrimaryKey(Column = "OrganizationJobRoleTargetUtilizationId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int JobRoleId { get; set; }

		[Property]
		public int OrganizationId { get; set; }

		[Property]
		public virtual decimal Utilization { set; get; }

		internal static decimal GetUtilizationByJobRole(int organizationId, int jobRoleId)
		{
			return CacheService.OrganizationJobRoleTargetUtilizationDict.Values.FirstOrDefault(rjtu => (rjtu.OrganizationId == organizationId && rjtu.JobRoleId == jobRoleId)).Utilization;
		}

		public static ResourceTypeOrganizationTargetUtilization_WS GetResourceTypeOrganizationTargetUtilization(int organizationId)
		{
			var targetUtilization = new ResourceTypeOrganizationTargetUtilization_WS(organizationId);
			var sql = string.Format(@"SELECT  Utilization ,
																				ResourceTypeId
																FROM    dbo.OrganizationJobRoleTargetUtilization OJTU
																				JOIN dbo.JobRole JR ON JR.JobRoleId = oJTU.JobRoleId
																				JOIN dbo.ResourceType RT ON RT.JobRoleId = JR.JobRoleId
																WHERE   OJTU.OrganizationId= {0}",
																organizationId);

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						targetUtilization.ResourceTypeUtilizationList.Add(new KeyValue_WS(DbSafe.Int(dr["ResourceTypeId"]), (DbSafe.Decimal(dr["Utilization"]) / 100).ToString()));
					}
				}
				finally { dr.Close(); }
			}

			return targetUtilization;
		}
	}
}