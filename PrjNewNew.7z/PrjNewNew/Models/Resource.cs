﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using Castle.Components.Validator;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Notification;
using Quintiles.RM.Clinical.Domain.Properties;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.Services;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// Maps to Resource_View
	/// </summary>
	[ActiveRecord(Table = "Resource_View")]
	public class Resource : AbstractActiveRecordBaseModel<Resource>, IExternalEntity
	{
		#region Properties

		[PrimaryKey(Column = "ResourceId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		[ValidateNonEmpty("Qid is a required field")]
		public virtual string Qid { set; get; }

		[Property(Column = "ResourceName")]
		[ValidateNonEmpty("Name is a required field")]
		public string Name { set; get; }

		[Property]
		public virtual int? CountryId { set; get; }

		private Country _country = null;
		public virtual Country Country
		{
			get
			{
				if (_country == null)
				{
					_country = CacheService.Country(CountryId);
				}
				return _country;
			}
		}

		[Property]
		public virtual int? HomeCountryId { set; get; }

		private Country _homeCountry = null;
		public virtual Country HomeCountry
		{
			get
			{
				if (_homeCountry == null)
				{
					_homeCountry = CacheService.Country(HomeCountryId);
				}
				return _homeCountry;
			}
		}

		[Property]
		public virtual int? OrganizationalUnitId { get; set; }

		[Property]
		public virtual string PostalZipCode { set; get; }

		[Property]
		public virtual string QOffice { set; get; }

		[Property]
		public virtual double TargetBillableHours { set; get; }

		[Property]
		public virtual double ContractHours { set; get; }

		[Property]
		public virtual double OriginalContractHours { set; get; }

		[Property]
		public virtual string City { set; get; }

		[Property]
		public int? StateProvinceId { get; set; }

		private StateProvince _stateProvince = null;
		public virtual StateProvince StateProvince
		{
			get
			{
				if (_stateProvince == null)
				{
					_stateProvince = CacheService.StateProvince(StateProvinceId);
				}
				return _stateProvince;
			}
		}


		[Property(NotNull = true)]
		[ValidateNonEmpty("JobGrade is a required field")]
		public virtual string JobGrade { set; get; }

		[Property(NotNull = true)]
		[ValidateNonEmpty("JobTitle is a required field")]
		public virtual string JobTitle { set; get; }

		[Property(NotNull = true)]
		[ValidateNonEmpty("Status is a required field")]
		public virtual string Status { set; get; }

		[Property(NotNull = true)]
		[ValidateNonEmpty("ManagerQid is a required field")]
		public virtual string ManagerQid { set; get; }

		[Property]
		public virtual string ManagerName { set; get; }

		[Property(NotNull = true)]
		[ValidateNonEmpty("DepartmentId is a required field")]
		public virtual int DepartmentId { set; get; }

		[Property]
		public virtual string DepartmentName { set; get; }

		[Property]
		[ValidateNonEmpty("SBU is a required field")]
		public virtual int SBU { set; get; }

		[Property(NotNull = true)]
		[ValidateNonEmpty("JobCode is a required field")]
		public virtual string JobCode { set; get; }

		[Property]
		public string CountryRegion { get; set; }

		[Property]
		public int? ClusterId { get; set; }

		private Cluster _cluster = null;
		public virtual Cluster Cluster
		{
			get
			{
				if (_cluster == null)
				{
					_cluster = CacheService.Cluster(ClusterId);
				}
				return _cluster;
			}
		}

		[Property]
		public virtual bool Active { get; set; }

		[Property]
		public virtual bool HasNotes { get; set; }

		[Property]
		public int? PrimaryJobRoleId { get; set; }

		[Property]
		public string JobRoleName { get; set; }
		#endregion

		public decimal UtilizationPercent { get; set; }
		public decimal ResourceContractHours { get; set; }
		public decimal CountryWeeklyHours { get; set; }
		public Message_WS Message { get; set; }
		public string Organization { get; set; }
		public string OrganizationalUnit { get; set; }
		public string PrimaryJobRole { get; set; }
		public string CompetencyBand { get; set; }
		public string ResourceRequestTypes { get; set; }
		public string HomeCountryName { get; set; }
		public string ResourceTmfPlatform { get; set; }
		public bool AllowWeeklyFteCalculation
		{
			get
			{
				OrganizationalUnit orgUnit = null;
				return CacheService.AllEnabledOrganizationalUnits.TryGetValue(OrganizationalUnitId.GetValueOrDefault(), out orgUnit)
					&& orgUnit.AllowWeeklyFteCalculation;
			}
		}

		public string PreferredSponsor { get; set; }
		public string TherapeuticAreas { get; set; }

		#region IExternalEntity
		[Property]
		public string ExternalId { get; set; }

		[Property]
		public string ExternalSource { get; set; }
		#endregion

		public Resource()
		{
		}

		public static IList<Resource> FindByJobRoleId(int[] idList)
		{
			return DbHelp.RunQuery<Resource>(@"SELECT *, ISNULL(Man.ResourceName, Res.ManagerQid) AS ManagerName ,
							CASE WHEN EXISTS ( SELECT TOP 1 EntityCommentId FROM   dbo.EntityComment WHERE  EntityTypeId = 7 AND RefEntityId = Res.ResourceId ) THEN 1 ELSE 0 END AS HasNotes 
							FROM dbo.Resource AS Res WITH ( NOLOCK ) LEFT OUTER JOIN dbo.Resource AS Man WITH ( NOLOCK ) ON Res.ManagerQid = Man.Qid 
							WHERE Res.JobCode IN (SELECT JobCode FROM dbo.JobCode j WHERE j.JobRoleId IN (:idList)) ",
											"r",
											new ActiveRecordInParameter("j", "JobRoleId", "idList", idList));
		}

		private static string GetAssignedResourceSql(int projectId, List<int> resourceTypeIdList)
		{
			var resourceTypeIds = string.Join(",", resourceTypeIdList.Select(rt => rt.ToString()).ToArray());
			return string.Format(@"SELECT DISTINCT RES.Qid, RES.ManagerQid
														FROM    dbo.Request R
																		JOIN dbo.ResourceRequestAssignment_XREF RRX ON R.RequestId = RRX.RequestId
																		JOIN dbo.Resource RES ON RRX.ResourceId = RES.ResourceId
														WHERE   R.ResourceTypeId IN ( {0} )
																		AND R.RequestStatusId IN ({1}, {2}, {3})
																		AND R.ProjectId = {4};",
														resourceTypeIds,
														(int)RequestStatusName.Assigned,
														(int)RequestStatusName.Backfilled,
														(int)RequestStatusName.Closed,
														projectId);
		}

		public static List<string> GetAssignedResourceEmailIdsByProjectAndResourceTypes(int projectId, List<int> resourceTypeIdList, out List<string> lineManagerEmailIds)
		{
			var assignedResoruceEmailIds = new List<string>();
			lineManagerEmailIds = new List<string>();
			using (var dr = DbHelp.ExecuteDataReaderText(GetAssignedResourceSql(projectId, resourceTypeIdList)))
			{
				try
				{
					while (dr.Read())
					{
						var lineManagerEmail = EmailNotification.GetEmailIdFromQid(dr["ManagerQid"].ToString());
						if (!lineManagerEmailIds.Contains(lineManagerEmail)) { lineManagerEmailIds.Add(lineManagerEmail); }
						assignedResoruceEmailIds.Add(EmailNotification.GetEmailIdFromQid(dr["Qid"].ToString()));
					}
				}
				finally { dr.Close(); }
			}
			return assignedResoruceEmailIds;
		}

		/// <summary>
		/// Get a Resource from the database for a specific QID.
		/// If no QID found, return null.
		/// </summary>
		/// <param name="qid"> </param>
		/// <returns>Resource or NULL</returns>
		public static Resource GeResourceByQId(string qid)
		{
			Resource res = null;
			try
			{
				res = FindOneByProperty("Qid", qid);
			}
			catch (Exception ex)
			{
				//MR: 11-28-2012: Convert to 'Debug' from 'Error'
				Logger.Instance.Debug("Could not find a resource for QID: " + qid);
			}
			return res;
		}

		/// <summary>
		/// Get City, State, Country of the Resource
		/// </summary>
		/// <returns></returns>
		/// <author>Matt Rakestraw</author>
		public String GetLocation()
		{
			StringBuilder location = new StringBuilder();

			if (!String.IsNullOrEmpty(City.Trim()))
			{
				location.Append(City);
			}

			if (StateProvince != null)
			{
				if (location.Length > 0)
				{
					location.Append(", ").Append(StateProvince.Name);
				}
				else
				{
					location.Append(StateProvince.Name);
				}
			}

			if (Country != null)
			{
				if (location.Length > 0)
				{
					location.Append(", ").Append(Country.Name);
				}
				else
				{
					location.Append(Country.Name);
				}
			}

			return location.ToString();

		}

		public String GetHomeLocation()
		{
			var location = new StringBuilder(City);

			if (StateProvince != null)
			{
				location.Append((location.Length > 0) ? ", " : string.Empty).Append(StateProvince.Name);
			}

			if (HomeCountry != null)
			{
				location.Append((location.Length > 0) ? ", " : string.Empty).Append(HomeCountry.Name);
			}

			return location.ToString();
		}

		/// <summary>
		/// Get Peoplesoft description of the Employee's status
		/// </summary>
		/// <returns></returns>
		/// <author>Matt Rakestraw</author>
		public String GetStatusDescription()
		{
			return TranslateStatus(Status);
		}

		/// <summary>
		/// Translate the PeopleSoft employee status code to a hard coded description
		/// </summary>
		/// <param columnName="statusCode"></param>
		/// <returns></returns>
		/// <author>Matt Rakestraw</author>
		public static String TranslateStatus(String statusCode)
		{
			switch (statusCode)
			{
				case "U":
					return "Terminated w/Benefits or Pay";
				case "P":
					return "Leave with Pay";
				case "A":
					return "Active";
				case "L":
					return "Leave of Absence";
				case "S":
					return "Suspended";
				default:
					return "Unknown";
			}
		}


		internal static IList<Resource> CreateOneFromReader(System.Data.IDataReader r)
		{
			List<Resource> rl = new List<Resource>();
			var cc = new ColumnChecker(r);

			if (r != null && cc.HasColumn("ResourceId") && !(r["ResourceId"] is System.DBNull))
			{
				Resource res = new Resource { Id = int.Parse(r["ResourceId"].ToString()) };

				if (cc.HasColumn("ResourceName")) { res.Name = r["ResourceName"].ToString(); }
				if (cc.HasColumn("ResourceQId")) { res.Qid = r["ResourceQId"].ToString(); }
				if (cc.HasColumn("ManagerQid")) { res.ManagerQid = r["ManagerQid"].ToString(); }

				rl.Add(res);
			}
			return rl;
		}

		internal static Resource CreateFromReader(System.Data.IDataReader r)
		{
			Resource res = null;
			var cc = new ColumnChecker(r);

			if (r != null && cc.HasColumn("ResourceId") && !(r["ResourceId"] is System.DBNull))
			{
				res = new Resource { Id = int.Parse(r["ResourceId"].ToString()) };

				if (cc.HasColumn("ResourceName")) { res.Name = r["ResourceName"].ToString(); }
				if (cc.HasColumn("ManagerQid")) { res.ManagerQid = r["ManagerQid"].ToString(); }
				if (cc.HasColumn("ManagerName")) { res.ManagerName = r["ManagerName"].ToString(); }

				if (string.IsNullOrEmpty(res.ManagerName))
				{
					res.ManagerName = res.ManagerQid;
				}
			}

			return res;
		}

		public EntityComment CreateComment(string comment, CommentTypeName commentType)
		{
			return new EntityComment
			{
				Comment = comment,
				RefEntityId = Id,
				RefEntityType = new EntityType { Id = (int)EntityTypes.Staff },
				CommentType = CommentType.CommentTypeByEnum(commentType)
			};
		}

		public static PagedResponse<Resource, ResourceCommonData> FindAllPagedReSourcesByManagerQId(GridSearchResource_WS gsr)
		{
			return new MyStaffGridDataEngine(gsr).GetDataForGrid();
		}

		//FIXME: Convert to full table join so we can use AR to populate resource instead of datareader!
		public static IList<Resource> FindAllLineManagers()
		{
			var res = new List<Resource>();
			const string sqlString = @"SELECT COUNT(res.ResourceId), M.ResourceId, M.Qid, M.ResourceName
								FROM dbo.Resource M INNER JOIN resource res ON M.Qid = res.ManagerQid
								WHERE M.Active = 1 AND res.Active = 1
								GROUP BY 
								M.ResourceId, M.Qid, M.ResourceName
								HAVING COUNT(res.ResourceId) > 0
								ORDER BY M.ResourceName";

			using (var dr = DbHelp.ExecuteDataReaderText(sqlString))
			{
				try
				{
					while (dr.Read())
					{
						res.Add(new Resource
						{
							Id = DbSafe.Int(dr["ResourceId"]),
							Qid = dr["Qid"].ToString(),
							Name = dr["ResourceName"].ToString(),
						});
					}
				}
				finally { dr.Close(); }
			}

			return res;
		}
		public static JqGridData<ResourceDataRow, Resource, ResourceCommonData> GetResourcesForUtility(string managerQId)
		{
			var resourceList = new JqGridData<ResourceDataRow, Resource, ResourceCommonData>();

			DetachedCriteria criteria = DetachedCriteria.For(typeof(Resource));
			criteria.Add(Restrictions.Eq("ManagerQid", string.IsNullOrEmpty(managerQId) ? ExtensionMethods.GetCurrentUserQid() : managerQId));
			IList<Resource> resources = Resource.FindAll(criteria);

			int resourceCount = resources.Count;
			var pagedResponse = new PagedResponse<Resource, ResourceCommonData>();
			pagedResponse.PageNumber = resourceCount > 0 ? 1 : 0;
			pagedResponse.TotalRecords = resourceCount;
			pagedResponse.Records = resources;

			return new JqGridData<ResourceDataRow, Resource, ResourceCommonData>(pagedResponse, ResourceDataRow.Create);
		}

		internal static int[] GetAllActiveResourceIds()
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(Resource));
			criteria.Add(Expression.Eq("Active", 1));
			return FindAll(criteria).Select(r => r.Id).ToArray();
		}

		/// <summary>
		/// Get match criteria information from DB for the Resource
		/// </summary>
		/// <returns></returns>
		/// <author>Taneesha Lenka</author>
		public static HashSet<ResourceCriteriaType_E> GetMatchCriteria(string ResourceTypeId)
		{
			HashSet<ResourceCriteriaType_E> matchCriteria = new HashSet<ResourceCriteriaType_E>();
			string sqlQuery = string.Format(@"SELECT [ResourceCriteriaType_E] FROM [dbo].[SearchCriteria] INNER JOIN [dbo].[SearchCriteriaSetup] 
                        ON [dbo].[SearchCriteria].[SearchCriteriaId] = [dbo].[SearchCriteriaSetup].[SearchCriteriaId] WHERE IsNull(IsMatch, 0) = 1 
                        AND ResourceTypeId = {0} AND ResourceCriteriaType_E IS NOT NULL", ResourceTypeId);
			IDataReader dr = DbHelp.ExecuteDataReaderText(sqlQuery);

			using (dr)
			{
				try
				{
					while (dr.Read())
					{
						matchCriteria.Add((ResourceCriteriaType_E)Enum.Parse(typeof(ResourceCriteriaType_E), dr["ResourceCriteriaType_E"].ToString()));
					}
				}
				finally { dr.Close(); }
			}

			return matchCriteria;
		}

		public static List<Resource_WS> GetFulfillableResourcesByResourceTypeId(int resourceTypeId)
		{
			var resourceList = new List<Resource_WS>();
			var sqlQuery = string.Format(@"SELECT  ResourceName ,
																		 				 Qid ,
																		 				 R.ResourceId
																		 FROM    Resource R
																		 				 JOIN ResourceResourceType_Xref RRTX ON RRTX.ResourceId = R.ResourceId
																		 WHERE   R.Active = 1
																		 				 AND RRTX.ResourceTypeId = {0}
																		 				 AND R.ResourceId > 0
																		 ORDER BY R.ResourceName", resourceTypeId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						resourceList.Add(new Resource_WS(DbSafe.Int(dr["ResourceId"]), DbSafe.StringValue(dr["ResourceName"]), DbSafe.StringValue(dr["Qid"])));
					}
				}
				finally { dr.Close(); }
			}
			return resourceList;
		}

		public static List<ValueId_WS> GetFulfillableResourcesByResourceTypeIdForAssignment(int resourceTypeId, bool performLineManagerCheck)
		{
			var resourceList = new List<ValueId_WS>();

			var retrieveAllResources = UserCache.Usr.IsAdmin || UserCache.Usr.IsSupport || UserCache.Usr.IsResourceManager;
			var retrieveDirectReportsOnly = !retrieveAllResources && performLineManagerCheck && UserCache.Usr.IsLineManager;
			var allowAssignment = retrieveAllResources || retrieveDirectReportsOnly;

			if (allowAssignment)
			{
				var sqlQuery = string.Format(@"SELECT  ResourceName ,
													Qid ,
													R.ResourceId
											FROM    Resource R
													JOIN ResourceResourceType_Xref RRTX ON RRTX.ResourceId = R.ResourceId
											WHERE   R.Active = 1
													AND R.ResourceId > 0
													AND RRTX.ResourceTypeId = {0} {1}
											ORDER BY R.ResourceName;",
													resourceTypeId,
													retrieveDirectReportsOnly ? string.Format("AND R.ManagerQid = '{0}'", UserCache.Usr.QId) : string.Empty);

				using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
				{
					try
					{
						while (dr.Read())
						{
							resourceList.Add(new ValueId_WS(DbSafe.StringValue(dr["ResourceId"]), string.Format("{0} ({1})", DbSafe.StringValue(dr["ResourceName"]), DbSafe.StringValue(dr["Qid"]))));
						}
					}
					finally { dr.Close(); }
				}
			}
			return resourceList;
		}

		#region GetNotesColumnValue
		public string GetNotesColumnValue(bool getCommentCountFromDb)
		{
			string returnValue = string.Empty;

			bool hasNotes = hasNotes = getCommentCountFromDb ? (EntityComment.FindEntityComments(Id, EntityTypes.Staff, false).Count > 0) : HasNotes;

			returnValue = string.Format(Constants.MessageDiv,
													hasNotes ? string.Empty : "no_",
													Id,
													(int)SearchLevel.Staff,
													EntityTypes.Staff.ToString(), (int)EntityTypes.Staff,
													string.Empty, Constants.UnspecifiedId, string.Empty,
													string.Empty, Constants.UnspecifiedId, string.Empty,
													Constants.UnspecifiedId, string.Empty,
													Constants.UnspecifiedId, string.Empty,
													Constants.UnspecifiedId, string.Empty,
													Name);

			return returnValue;
		}
		#endregion

		public static List<LabelValue_WS> GetSmartSearchLookupListForDelegateResource()
		{
			var smartSearchList = new List<LabelValue_WS>();
			var sql = @"SELECT R.ResourceId, R.ResourceName, R.QId
									FROM   dbo.Resource R
												 LEFT JOIN ( SELECT DISTINCT
																						RES.ResourceId
																		FROM    dbo.Resource RES
																						JOIN dbo.CountryResourceTypeWithSpecialResourcingNeed CRTSRN ON RES.CountryId = CRTSRN.CountryId
																						JOIN dbo.ResourceType RT ON CRTSRN.ResourceTypeId = RT.ResourceTypeId
																																				AND RT.JobRoleId = RES.PrimaryJobRoleId
																	) ResourcesToHide ON R.ResourceId = ResourcesToHide.ResourceId
									WHERE  R.Active = 1
												 AND ResourcesToHide.ResourceId IS NULL
									ORDER BY R.ResourceName";
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						smartSearchList.Add(new LabelValue_WS(DbSafe.StringValue(dr["ResourceId"]), string.Format("{0} - ({1})", DbSafe.StringValue(dr["ResourceName"]), DbSafe.StringValue(dr["QId"]))));
					}
				}
				finally { dr.Close(); }
			}

			return smartSearchList;
		}

		internal static int GetResourceIdFromQid(string qid)
		{
			var resource = Resource.FindOneByProperty("Qid", qid);
			if (resource == null)
			{
				throw new Exception(string.Format("No resource found with Qid {0}", qid));
			}
			return resource.Id;
		}

		public static ResourceConfiguration_WS GetResourceConfiguration(int resourceId)
		{
			ResourceConfiguration_WS resourceConfig = null;
			var sql = string.Format(@"SELECT R.PrimaryJobRoleId ,
											 R.OrganizationalUnitId ,
											 OU.OrganizationId ,
											 R.CompetencyBandID ,
											 R.CountryId ,
											 R.HasResourceableResourceTypes,
											 R.IsResourcedInRm,
											 R.PreferredSponsor,
											 OU.ShowPreferredSponsor,
											 HC.Name AS HomeCountry
							FROM    dbo.Resource R
									LEFT JOIN dbo.OrganizationalUnit OU ON R.OrganizationalUnitId = OU.OrganizationalUnitId
									LEFT JOIN dbo.Country HC ON HC.CountryId = R.HomeCountryId
							WHERE   R.ResourceId = {0};

							SELECT  RRTX.ResourceTypeId, RRTX.IntendedFte
							FROM    dbo.ResourceResourceType_Xref RRTX
									JOIN dbo.ResourceType RT on RT.ResourceTypeId = RRTX.ResourceTypeId
							WHERE   RRTX.ResourceId = {0} ORDER BY RT.Name;

							SELECT  TmfPlatformId, IsPrimary, IsSecondary, IsTertiary
							FROM    dbo.ResourceTmfPlatform_Xref
							WHERE   ResourceId = {0};", resourceId);

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					if (dr.Read())
					{
						resourceConfig = new ResourceConfiguration_WS(resourceId, DbSafe.Int(dr["OrganizationalUnitId"], -1), DbSafe.Int(dr["OrganizationId"], -1), DbSafe.Int(dr["PrimaryJobRoleId"]), DbSafe.Int(dr["CompetencyBandID"], -1), DbSafe.Int(dr["countryId"], -1), DbSafe.StringValue(dr["HomeCountry"]), DbSafe.Bool(dr["IsResourcedInRm"]), DbSafe.Bool(dr["HasResourceableResourceTypes"]), DbSafe.StringValue(dr["PreferredSponsor"]), DbSafe.Bool(dr["ShowPreferredSponsor"]));

						//Hide competency band if loggedin user does not have permission to view competency band
						var qid = ExtensionMethods.GetCurrentUserQid();
						if (!RmFunction.HasPermissionToFunction(RmFunction_E.View_Competency_Band, RmUser.FindOneByProperty("QId", qid), qid, new CustomPermissionArg(null, new List<int> { resourceId })))
						{
							resourceConfig.CompetencyBandId = -1;
						}

						dr.NextResult();
						while (dr.Read())
						{
							resourceConfig.ResourceableResourceTypes.Add(new ResourceableResourceType_WS
							{
								ResourceTypeId = DbSafe.Int(dr["ResourceTypeId"]),
								IntendedFte = DbSafe.DecimalNull(dr["IntendedFte"])
							});

						}
						dr.NextResult();
						while (dr.Read())
						{
							resourceConfig.TmfPlatforms.Add(new ResourceTmfPlatform_WS
							{
								TmfPlatformId = DbSafe.Int(dr["TmfPlatformId"]),
								IsPrimary = DbSafe.Bool(dr["IsPrimary"]),
								IsSecondary = DbSafe.Bool(dr["IsSecondary"]),
								IsTertiary = DbSafe.Bool(dr["IsTertiary"])
							});
						}
					}
				}
				finally { dr.Close(); }
			}
			return resourceConfig;
		}

		public static bool IsEditableByCurrentUser(List<int> resourceIds, string managerQid, out string errorMessage, out List<int> resourceIdsWithNoEditPermission)
		{
			errorMessage = string.Empty;
			resourceIdsWithNoEditPermission = null;

			if (RmFunction.HasPermissionToFunction(RmFunction_E.Update_Resource_Attributes_from_My_Staff, UserCache.Usr, managerQid, new CustomPermissionArg(null, resourceIds)))
			{
				return true;
			}
			else
			{
				using (var dr = DbHelp.ExecuteDataReaderText(CustomFunctionPermissionRule_LineManagerOfASelectedResource.GetDetailsQuery(managerQid, resourceIds)))
				{
					try
					{
						while (dr.Read())
						{
							if (resourceIdsWithNoEditPermission == null)
							{
								resourceIdsWithNoEditPermission = new List<int>();
							}
							errorMessage = string.Format(", {0}", DbSafe.StringValue(dr["ResourceName"]));
							resourceIdsWithNoEditPermission.Add(DbSafe.Int(dr["ResourceId"]));
						}
					}
					finally { dr.Close(); }
				}

				if (!string.IsNullOrEmpty(errorMessage))
				{
					errorMessage = string.Format("You are not allowed to modify following resources as they are not your direct reports: {0}", errorMessage.Substring(2));
				}
				return string.IsNullOrEmpty(errorMessage);
			}
		}

		public static EditMultipleResourceStatus_WS UpdateResourceConfiguration(List<int> resourceIdList, int? organizationalUnitId, int? primaryJobRoleId, List<ResourceableResourceType_WS> resourceableResourceTypeList, bool isResourcedInRm, int? competencyBandId, int? workCountryId, List<ResourceTmfPlatform_WS> tmfPlatformDetails, bool hasResourceableResourceTypes, string preferredSponsor)
		{
			var response = new EditMultipleResourceStatus_WS();

			if (resourceIdList != null)
			{
				string clearTmfPlatformQueryTemplate = "DELETE FROM dbo.ResourceTmfPlatform_Xref WHERE ResourceId IN ( {0} );";
				string errorMessage;
				List<int> resourceIdsWithNoEditPermission;
				if (!IsEditableByCurrentUser(resourceIdList, ExtensionMethods.GetCurrentUserQid(), out errorMessage, out resourceIdsWithNoEditPermission))
				{
					response.ValidationErrors.Add(new ValidationMessage_WS(Constants.UnspecifiedId.ToString(), errorMessage, MessageType_E.AlertMessage));
					if (resourceIdsWithNoEditPermission != null)
					{
						foreach (var resourceId in resourceIdsWithNoEditPermission)
						{
							resourceIdList.Remove(resourceId);
						}
					}
				}

				var isMultiEditMode = resourceIdList.Count > 1;
				var commaSeparatedResourceIdList = string.Join(",", resourceIdList.Select(r => r.ToString()).ToArray());
				var noResourceTypeIdSelectedString = "-1";
				var commaSeparatedResourceTypeIdList = (resourceableResourceTypeList == null || resourceableResourceTypeList.Count == 0) ?
														noResourceTypeIdSelectedString :
														string.Join(",", resourceableResourceTypeList.Select(resTypeId => resTypeId.ResourceTypeId.ToString()).ToArray());

				var updateResourceSql =
					string.Format(@"UPDATE  R
									SET     R.OrganizationalUnitId = COALESCE(@OrganizationalUnitId,
											R.OrganizationalUnitId) ,
											R.PrimaryJobRoleId = CASE WHEN COALESCE(@OrganizationalUnitId, R.OrganizationalUnitId) != R.OrganizationalUnitId 
																	THEN @PrimaryJobRoleId
																	ELSE COALESCE(@PrimaryJobRoleId, R.PrimaryJobRoleId) END ,
											R.CompetencyBandID = CASE WHEN COALESCE(@OrganizationalUnitId, R.OrganizationalUnitId) != R.OrganizationalUnitId
																			OR COALESCE(@PrimaryJobRoleId, R.PrimaryJobRoleId) != R.PrimaryJobRoleId
																	THEN @CompetencyBandID
																	ELSE COALESCE(@CompetencyBandID, R.CompetencyBandID) END,
											R.CountryId = COALESCE(@CountryId, R.CountryId) ,
											R.ContractHours = CASE WHEN R.OriginalContractHours >= C.WeeklyHours
																	THEN C.WeeklyHours
																	ELSE R.OriginalContractHours
															  END ,
											R.LastModifiedBy = '{0}' ,
											R.LastModifiedOn = GETDATE(),
											R.HasResourceableResourceTypes='{2}',
											R.IsResourcedInRm='{3}',
											R.PreferredSponsor=COALESCE(@preferredSponsor, R.preferredSponsor)
									FROM    dbo.Resource R
											LEFT JOIN dbo.Country C ON C.CountryId = COALESCE(@CountryId, R.CountryId)
									WHERE   ResourceId IN ( {1} );", ExtensionMethods.GetCurrentUserQid(), commaSeparatedResourceIdList, hasResourceableResourceTypes, isResourcedInRm);

				var resourceTypeSourceQuery = "{0} SELECT {1} AS ResourceId, {2} AS ResourceTypeId , {3} AS IntendedFte";
				var unionAll = string.Empty;
				var sourceTableBuilder = new StringBuilder();
				for (int resIndex = 0; resIndex < resourceIdList.Count; resIndex++)
				{
					for (int intendedFteIndex = 0; intendedFteIndex < resourceableResourceTypeList.Count; intendedFteIndex++)
					{
						sourceTableBuilder.AppendFormat(resourceTypeSourceQuery, unionAll, resourceIdList[resIndex], resourceableResourceTypeList[intendedFteIndex].ResourceTypeId, resourceableResourceTypeList[intendedFteIndex].IntendedFte == null ? "NULL" : (object)resourceableResourceTypeList[intendedFteIndex].IntendedFte);

						if (string.IsNullOrEmpty(unionAll))
						{
							unionAll = String.Format("{0}UNION all{0}", Environment.NewLine);
						}
					}

				}
				var resourceTypeSql = String.Empty;
				if (sourceTableBuilder.Length != 0)
				{
					var resourcetypeMergeQuery = @"MERGE ResourceResourceType_Xref TargetTbl
											   USING ({0}) AS SourceTbl (ResourceId,ResourceTypeId,IntendedFte)
											   ON ( SourceTbl.ResourceId = TargetTbl.ResourceId
											   AND SourceTbl.ResourceTypeId = TargetTbl.ResourceTypeId)
											   WHEN MATCHED THEN
											   UPDATE SET TargetTbl.LastModifiedBy = '{1}' ,
                                               TargetTbl.LastModifiedOn = GETDATE() ,
                                               TargetTbl.IntendedFte = SourceTbl.IntendedFte
											   WHEN NOT MATCHED BY TARGET THEN
											   INSERT ( ResourceId ,
														 ResourceTypeId ,
														 CreatedBy ,
														 CreatedOn ,
														 LastModifiedBy ,
														 LastModifiedOn ,
														 IntendedFte
													   )
												VALUES ( SourceTbl.ResourceId ,
														 SourceTbl.ResourceTypeId ,
														 '{1}' ,
														 GETDATE() ,
														 '{1}' ,
														 GETDATE() ,
														 SourceTbl.IntendedFte
													   )
												WHEN NOT MATCHED BY SOURCE AND TargetTbl.ResourceId IN ( {2} ) THEN
												DELETE;";
					resourceTypeSql = String.Format(resourcetypeMergeQuery, sourceTableBuilder.ToString(), ExtensionMethods.GetCurrentUserQid(), commaSeparatedResourceIdList);
				}
				else
				{
					resourceTypeSql = (isMultiEditMode && commaSeparatedResourceTypeIdList == noResourceTypeIdSelectedString) ?
								   string.Empty :
								   string.Format(@"DELETE  FROM dbo.ResourceResourceType_Xref
												   WHERE ResourceId IN ( {0} )
												   AND ResourceTypeId NOT IN ( {1} )", commaSeparatedResourceIdList, commaSeparatedResourceTypeIdList);
				}

				var noTmfPlatformIdSelectedString = "-1";
				var commaSeparatedTmfPlatformIdList = (tmfPlatformDetails == null || tmfPlatformDetails.Count == 0) ?
														noTmfPlatformIdSelectedString :
														string.Join(",", tmfPlatformDetails.Select(v => v.TmfPlatformId.ToString()).ToArray());

				var tmfPlatformSql = (isMultiEditMode && commaSeparatedTmfPlatformIdList == noTmfPlatformIdSelectedString) ?
									string.Empty :
									string.Format(@"DELETE  FROM dbo.ResourceTmfPlatform_Xref
									WHERE   ResourceId IN ( {0} )
											AND TmfPlatformId NOT IN ( {1} );

									INSERT  INTO dbo.ResourceTmfPlatform_Xref
										( ResourceId ,
											TmfPlatformId ,
											CreatedBy ,
											CreatedOn ,
											LastModifiedBy ,
											LastModifiedOn
										)
										SELECT  ResourceId ,
												TmfPlatformId ,
												@userQid ,
												GETDATE() ,
												@userQid ,
												GETDATE()
										FROM    ( SELECT    ResourceId ,
															TmfPlatformId
													FROM    dbo.Resource
													CROSS JOIN dbo.TmfPlatform
													WHERE   ResourceId IN ( {0} )
															AND TmfPlatformId IN ( {1} )
													EXCEPT
													SELECT  ResourceId ,
															TmfPlatformId
													FROM    dbo.ResourceTmfPlatform_Xref
													WHERE   ResourceId IN ( {0} )
															AND TmfPlatformId IN ( {1} )
												) RRX",
									commaSeparatedResourceIdList,
									commaSeparatedTmfPlatformIdList);
				JobRole selectedJobRole;
				//TMF platform shoudl be cleared only when job role is selected and the selected job role does not show TMF Platforms
				if (primaryJobRoleId.HasValue && CacheService.AllJobRoles.TryGetValue(primaryJobRoleId.GetValueOrDefault(), out selectedJobRole) && !selectedJobRole.ShowTmfPlatform)
				{
					//Clear TMF Platforms associated with resource
					tmfPlatformSql = string.Format(clearTmfPlatformQueryTemplate, commaSeparatedResourceIdList);
				}

				if (!isResourcedInRm)
				{
					updateResourceSql = string.Format(@"UPDATE  dbo.Resource
														SET     OrganizationalUnitId = NULL ,
																PrimaryJobRoleId = NULL,
																CompetencyBandID = NULL,
																LastModifiedBy = '{0}',
																LastModifiedOn = GETDATE(),
																IsResourcedInRm ='{2}',
																HasResourceableResourceTypes ='{3}',
																PreferredSponsor = NULL
														WHERE   ResourceId IN ( {1} );", ExtensionMethods.GetCurrentUserQid(), commaSeparatedResourceIdList, isResourcedInRm, hasResourceableResourceTypes);

					//Delete resource type and resource combinations which are no more configured
					resourceTypeSql = string.Format(@"DELETE FROM dbo.ResourceResourceType_Xref WHERE   ResourceId IN ( {0} );", commaSeparatedResourceIdList);

					//Clear TMF Platforms associated with resource
					tmfPlatformSql = string.Format(clearTmfPlatformQueryTemplate, commaSeparatedResourceIdList);
				}
				if (!hasResourceableResourceTypes)
				{
					resourceTypeSql = string.Format(@"DELETE FROM dbo.ResourceResourceType_Xref WHERE  ResourceId IN ( {0} );", commaSeparatedResourceIdList);
				}
				StringBuilder sbtmfPlatformPreferenceSql = new StringBuilder();
				if (!isMultiEditMode && resourceIdList != null && resourceIdList.Count > 0)
				{
					foreach (var tmfPlatform in tmfPlatformDetails)
					{
						if (tmfPlatform.IsPrimary)
						{
							sbtmfPlatformPreferenceSql.AppendFormat("UPDATE ResourceTmfPlatform_Xref SET IsPrimary = CASE TmfPlatformId WHEN {1} THEN 1 ELSE 0 END,IsSecondary=0,IsTertiary=0  WHERE ResourceId = {0} AND TmfPlatformId ={1};", resourceIdList[0], tmfPlatform.TmfPlatformId);
						}
						else if (tmfPlatform.IsSecondary)
						{
							sbtmfPlatformPreferenceSql.AppendFormat("UPDATE ResourceTmfPlatform_Xref SET IsSecondary = CASE TmfPlatformId WHEN {1} THEN 1 ELSE 0 END,IsPrimary=0,IsTertiary=0 WHERE ResourceId = {0} AND TmfPlatformId ={1};", resourceIdList[0], tmfPlatform.TmfPlatformId);

						}
						else if (tmfPlatform.IsTertiary)
						{
							sbtmfPlatformPreferenceSql.AppendFormat("UPDATE ResourceTmfPlatform_Xref SET IsTertiary = CASE TmfPlatformId WHEN {1} THEN 1 ELSE 0 END,IsPrimary=0,IsSecondary=0 WHERE ResourceId = {0} AND TmfPlatformId ={1};", resourceIdList[0], tmfPlatform.TmfPlatformId);
						}
						else
						{
							sbtmfPlatformPreferenceSql.AppendFormat("UPDATE ResourceTmfPlatform_Xref SET IsPrimary=0,IsSecondary=0,IsTertiary=0 WHERE ResourceId = {0} AND TmfPlatformId = {1};", resourceIdList[0], tmfPlatform.TmfPlatformId);
						}
					}
				}
				try
				{
					string QueryToExecute = sbtmfPlatformPreferenceSql.ToString() != String.Empty ? string.Format("{0};{1};{2};{3};", updateResourceSql, resourceTypeSql, tmfPlatformSql, sbtmfPlatformPreferenceSql) : string.Format("{0};{1};{2};", updateResourceSql, resourceTypeSql, tmfPlatformSql);
					DbHelp.ExecuteNonQueryText(QueryToExecute,
						new SqlParameter("OrganizationalUnitId", organizationalUnitId.HasValue ? (object)organizationalUnitId : DBNull.Value),
						new SqlParameter("PrimaryJobRoleId", primaryJobRoleId.HasValue ? (object)primaryJobRoleId : DBNull.Value),
						new SqlParameter("userQid", ExtensionMethods.GetCurrentUserQid()),
						new SqlParameter("CountryId", workCountryId.HasValue ? (object)workCountryId : DBNull.Value),
						new SqlParameter("CompetencyBandID", competencyBandId.HasValue ? (object)competencyBandId : DBNull.Value),
						new SqlParameter("preferredSponsor", preferredSponsor == null ? DBNull.Value : (object)preferredSponsor));
					MarkResourcesToUpdateAssignedRequestWeeklyHours(resourceIdList);
				}
				catch (Exception ex)
				{
					response.ValidationErrors.Add(new ValidationMessage_WS(Constants.UnspecifiedId.ToString(), ex.Message, MessageType_E.AlertMessage));
				}
			}
			return response;
		}

		public static string GetSelectQueryForResourcesWithMismatchedAssignmentCountry(bool forInsertResourceToStaleQueue, List<int> resourceIdList)
		{
			var columnsToSelect = forInsertResourceToStaleQueue ?
				"DISTINCT RES.ResourceId,'ResourceCountryUpdate', GETDATE(),'ResourceCountryUpdate', GETDATE()" :
				"REQ.RequestId, RES.CountryId as ResourceCountryId, RES.PrimaryJobRoleId";

			return string.Format(@"SELECT  {0}
        FROM    dbo.Resource RES
								JOIN dbo.ResourceRequestAssignment_XREF RRX ON RRX.ResourceId = RES.ResourceId
								JOIN dbo.Country RESC ON RESC.CountryId = RES.CountryId
								JOIN dbo.Request REQ ON REQ.RequestId = RRX.RequestId
								JOIN dbo.Country REQC ON REQC.CountryId = REQ.CountryId
								JOIN dbo.ResourceType RT ON RT.ResourceTypeId = REQ.ResourceTypeId
								LEFT JOIN dbo.StaleResourcesWithMismatchedAssignmentCountry SRWMAC ON SRWMAC.ResourceId = RES.ResourceId AND SRWMAC.LockedBy IS NULL
        WHERE   SRWMAC.ResourceId IS NULL
								AND (RT.IsOthers = 1 OR RT.IsGeneric = 1)
								AND RES.ResourceId IN ( {1} )
								AND REQ.RequestStatusId NOT IN ( 1, 7, 8 )
								AND REQ.CountryId != RES.CountryId
								AND REQC.WeeklyHours != RESC.WeeklyHours;",
				columnsToSelect,
				string.Join(",", resourceIdList.Select(r => r.ToString()).ToArray()));
		}

		private static void MarkResourcesToUpdateAssignedRequestWeeklyHours(List<int> resourceIdList)
		{
			DbHelp.ExecuteNonQueryText(string.Format(@"INSERT INTO dbo.StaleResourcesWithMismatchedAssignmentCountry
        (ResourceId, LastModifiedBy, LastModifiedOn, CreatedBy, CreatedOn)
        {0}",
				GetSelectQueryForResourcesWithMismatchedAssignmentCountry(true, resourceIdList)));
		}

		public static string GetCommaSeparatedResourceNamesByResourceIdList(List<int> requestIdList, out string managerQids)
		{
			managerQids = string.Empty;
			var resourceNames = string.Empty;

			if (requestIdList != null && requestIdList.Count > 0)
			{
				using (var dr = DbHelp.ExecuteDataReaderText(string.Format(@"SELECT  STUFF(( SELECT ', ' + ResourceName FROM dbo.Resource WHERE ResourceId IN ({0}) ORDER BY ResourceName FOR XML PATH('') ), 1, 2, '') AS ResoruceNames, 
																				 STUFF(( SELECT DISTINCT ', ' + ManagerQid FROM dbo.Resource WHERE ResourceId IN ({0}) FOR XML PATH('') ), 1, 2, '') AS ManagerQids",
																	string.Join(",", requestIdList.Select(r => r.ToString()).ToArray()))))
				{
					try
					{
						if (dr.Read())
						{
							managerQids = DbSafe.StringValue(dr["ManagerQids"]);
							resourceNames = DbSafe.StringValue(dr["ResoruceNames"]);
						}
					}
					finally { dr.Close(); }
				}
			}

			return resourceNames;
		}

		/// <summary>
		/// TODO : Refactor further when possible
		/// </summary>
		/// <param name="inactiveResourceIds"></param>
		public static void CreateAutoBackFillRequestForInactiveResource(List<int> inactiveResourceIds)
		{
			//Handle Soft booked requests 
			Request.HandleSoftbookForInactiveResource(inactiveResourceIds);

			//Get list of all the impacted hardbooked requests of those assigned with the Inactive Resources
			List<int> hardbookedRequestIds = Request.GetAssignedRequestIdList(inactiveResourceIds);
			if (hardbookedRequestIds.Count > 0)
			{
				List<int> terminateRequestIds = new List<int>();
				List<int> submitRequestIds = new List<int>();

				//Handle if backfill already exists scenario - Hack the start date
				Request.HandleExistingBackfillRequests(ref hardbookedRequestIds, terminateRequestIds, submitRequestIds);

				// Create backfill request and terminate the parent request assigned to in-active resources
				Request.CreateNewBackFillRequests(hardbookedRequestIds, terminateRequestIds, submitRequestIds);
				Request.SubmitRequests(submitRequestIds, Constants.AutoBackfillCreatedBy, true);
				Request.CloseRequests(terminateRequestIds, Resources.AutoBackfillTerminationComments, Constants.AutoBackfillCreatedBy);
			}
		}

		public static bool AreAllJapanResourcesSelected(List<int> requestIdList)
		{
			return DbSafe.Int(DbHelp.ExecuteScalarText(string.Format(@"SELECT  COUNT(1)
																																 FROM    dbo.Resource
																																 WHERE   ResourceId IN ( {0} )
																																				 AND CountryId = {1}",
																																																											string.Join(",", requestIdList.Select(rid => rid.ToString()).ToArray()),
																																																											Constants.JapanCountryId))) == requestIdList.Count();
		}

		public static int GetOrganizationUnitId(string qId)
		{
			int organizationUnitId = 0;
			using (var dr = DbHelp.ExecuteDataReaderText(string.Format(@"SELECT  org.OrganizationalUnitId
																																		FROM    Resource res
																																						JOIN OrganizationalUnit org ON res.OrganizationalUnitId = org.OrganizationalUnitId
																																		WHERE   res.Qid = '{0}'", qId)))
			{
				try
				{
					if (dr.Read()) { organizationUnitId = DbSafe.Int(dr["OrganizationalUnitId"]); }
				}
				finally { dr.Close(); }
			}

			return organizationUnitId;
		}

		public static ResourceDetails_WS GetResourceDetailsByResourceId(int resourceId)
		{
			var resource = Resource.FindByPrimaryKey(resourceId);

			OrganizationalUnit orgUnit = null;
			CacheService.AllOrganizationalUnits.TryGetValue(resource.OrganizationalUnitId.GetValueOrDefault(), out orgUnit);

			if (resource == null)
			{
				return new ResourceDetails_WS();
			}
			else
			{
				return new ResourceDetails_WS
				{
					Name = resource.Name,
					QId = resource.Qid,
					JobRole = resource.JobRoleName,
					JobTitle = resource.JobTitle,
					Office = resource.QOffice,
					WorkCountry = (resource.Country != null) ? resource.Country.Name : string.Empty,
					Manager = resource.ManagerName,
					Organization = (orgUnit != null && orgUnit.Organization != null) ? orgUnit.Organization.Name : string.Empty,
					TmfPlatforms = resource.GetTmfPlatforms(),
					OrganizationalUnit = (orgUnit != null) ? orgUnit.Name : string.Empty
				};
			}
		}

		private string GetTmfPlatforms()
		{
			var tmfPlatforms = string.Empty;
			var sql = string.Format(@"SELECT STUFF(( SELECT ', '+ CASE
                                                              WHEN RTPX.IsPrimary = 1
                                                              THEN '(Pri.)'
                                                              WHEN RTPX.IsSecondary = 1
                                                              THEN '(Sec.)'
                                                              WHEN RTPX.IsTertiary = 1
                                                              THEN '(Ter.)'
                                                              ELSE ''
                                                              END + TP.Name
                                                        FROM  dbo.ResourceTmfPlatform_Xref RTPX
                                                              JOIN dbo.TmfPlatform TP ON TP.TmfPlatformId = RTPX.TmfPlatformId
                                                        WHERE RTPX.ResourceId = {0}
                                                        ORDER BY ( CASE
                                                              WHEN RTPX.IsPrimary = 1
                                                              THEN 1
                                                              WHEN RTPX.IsSecondary = 1
                                                              THEN 2
                                                              WHEN RTPX.IsTertiary = 1
                                                              THEN 3
                                                              ELSE 4
                                                              END ) ,
                                                              TP.Name
                                                      FOR
                                                        XML PATH('')
                                                      ), 1, 2, '') AS ResourceTmfPlatform;", Id);

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					if (dr.Read())
					{
						tmfPlatforms = DbSafe.StringValue(dr["ResourceTmfPlatform"]);
					}
				}
				finally { dr.Close(); }
			}
			return tmfPlatforms;
		}

		internal static Dictionary<string, List<KeyValuePair<string, string>>> GetResourcesWithIncompleteAttributes()
		{
			var resourcesWithIncompleteAttributes = new Dictionary<string, List<KeyValuePair<string, string>>>();

			using (var dr = DbHelp.ExecuteDataReaderText(
				@"SELECT R.ManagerQid ,
						R.Qid ,
						R.ResourceName
				FROM    dbo.Resource R
						LEFT JOIN dbo.JobRole JR ON JR.JobRoleId = R.PrimaryJobRoleId
						LEFT JOIN (SELECT	DISTINCT
											ResourceId AS ResourceableResourceId
									FROM    dbo.ResourceResourceType_Xref
								  ) RR ON RR.ResourceableResourceId = R.ResourceId
				WHERE	Active = 1
						AND COALESCE(R.ManagerQid, '') != ''
						AND R.IsResourcedInRM = 1
						AND ( OrganizationalUnitId IS NULL
								OR PrimaryJobRoleId IS NULL
								OR ( JR.ShowCompetencyBand = 1 AND R.CompetencyBandID IS NULL )
								OR ( R.HasResourceableResourceTypes = 1 AND ResourceableResourceId IS NULL)
							)
				ORDER BY R.ManagerQid;"))
			{
				try
				{
					while (dr.Read())
					{
						var managerQid = DbSafe.StringValue(dr["ManagerQid"]);
						List<KeyValuePair<string, string>> resourceList;

						if (!resourcesWithIncompleteAttributes.TryGetValue(managerQid, out resourceList))
						{
							resourceList = new List<KeyValuePair<string, string>>();
							resourcesWithIncompleteAttributes.Add(managerQid, resourceList);
						}

						resourceList.Add(new KeyValuePair<string, string>(DbSafe.StringValue(dr["Qid"]), DbSafe.StringValue(dr["ResourceName"])));
					}
				}
				finally { dr.Close(); }
			}

			return resourcesWithIncompleteAttributes;
		}
	}
	public class ResourceMissingAttributes
	{
		public int ResourceId { get; set; }
		public string Qid { get; set; }
		public string ResourceName { get; set; }
		public string ManagerQid { get; set; }
	}
	[ActiveRecord(Table = "SearchCriteriaSetup")]
	public class SearchCriteriaSetup : AbstractActiveRecordBaseModel<SearchCriteriaSetup>
	{
		#region Mapped Properties


		[PrimaryKey(Column = "SearchCriteriaSetupId")]
		public override int Id { get; set; }


		[Property(Column = "DisplayInSearchPage")]
		public bool IsDisplay { get; set; }



		[Property(Column = "ResourceTypeId")]
		public int ResourceTypeId { get; set; }


		[Property]
		public bool CheckedByDefault { get; set; }


		[Property]
		public string CriteriaValuesFromTable { get; set; }


		[Property]
		public string CriteriaValuesFromColumn { get; set; }


		[Property]
		public string PresetFilterFromTable { get; set; }



		[Property]
		public string PresetFilterFromColumn { get; set; }

		[Property]
		public bool SearchFromFilter { get; set; }


		[Property]
		public int SearchCriteriaId { get; set; }

		[Property]
		public bool IsMatch { get; set; }


		#endregion

		#region Get the page manager Name
		/// <summary>
		//RMK: To get the SearchCriteriaSetup
		/// </summary>
		/// <returns></returns>
		public static List<ResourceSearchCriteria_WS> GetSearchCriteriaSetup(int resourceGroupId)
		{
			string sqlQuery = string.Format(@"SELECT DISTINCT CriteriaName,DisplayInSearchPage,CriteriaDivId FROM dbo.SearchCriteriaSetup WHERE ResourceTypeId IN(SELECT DISTINCT ResourceTypeId FROM RequestTypeResourceTypeGroupOpenRequestQueue_XREF WHERE RequestTypeResourceTypeGroupId={0}) ORDER BY DisplayInSearchPage", resourceGroupId);
			List<ResourceSearchCriteria_WS> searchCriteriaList = new System.Collections.Generic.List<ResourceSearchCriteria_WS>();

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						searchCriteriaList.Add(new ResourceSearchCriteria_WS
						{
							CriteriaName = dr["CriteriaName"].ToString(),
							IsDisplay = (bool)dr["DisplayInSearchPage"],
							DivId = dr["CriteriaDivId"].ToString()
						});
					}
				}
				finally { dr.Close(); }
			}
			return searchCriteriaList;

		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="resourceTypeId"></param>
		/// <returns></returns>
		public static List<ResourceSearchCriteria_WS> GetSearchCriteriaSetup(int[] resourceTypeId)
		{
			string sqlQuery = string.Empty;
			string Ids = string.Join(",", Array.ConvertAll(resourceTypeId, x => x.ToString()));
			sqlQuery = string.Format(@"SELECT DISTINCT B.CriteriaName,A.DisplayInSearchPage,B.CriteriaDivId,A.CheckedByDefault FROM dbo.SearchCriteriaSetup A JOIN dbo.SearchCriteria B ON A.SearchCriteriaId=B.SearchCriteriaId  WHERE ResourceTypeId IN({0}) ORDER BY DisplayInSearchPage", Ids);
			List<ResourceSearchCriteria_WS> searchCriteriaList = new System.Collections.Generic.List<ResourceSearchCriteria_WS>();

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						searchCriteriaList.Add(new ResourceSearchCriteria_WS
						{
							CriteriaName = dr["CriteriaName"].ToString(),
							IsDisplay = (bool)dr["DisplayInSearchPage"],
							DivId = dr["CriteriaDivId"].ToString(),
							IsFilter = (bool)dr["CheckedByDefault"]
						});
					}
				}
				finally { dr.Close(); }
			}
			return searchCriteriaList;

		}
		#endregion

	}

	//RMK : Added to map the page manager 
	[ActiveRecord(Table = "FTECalculatorPageManagerType")]
	public class PageManagerType : AbstractActiveRecordBaseModel<PageManagerType>
	{

		#region Mapped Properties
		[PrimaryKey(Column = "PageManagerTypeId")]
		public override int Id { get; set; }

		[Property(Column = "TypeName")]
		public string Name { get; set; }

		#endregion

		#region Get the page manager Name
		/// <summary>
		//RMK: To map the page manager Name
		/// </summary>
		/// <returns></returns>
		public static PageManager_WS GetPageManagerTypeName(int resourceTypeId, bool isProposalRequest)
		{
			var sqlQuery = @"SELECT PMT.TypeName ,
															PMT.PageManagerTypeId ,
															RT.DefaultFromMilestoneId ,
															RT.DefaultToMilestoneId ,
															RT.ResourceTransitionTime ,
															RT.AssigneesAlwaysUnblinded ,
															RT.DisplaysBlindedField ,
															RT.RequestStartDateConnectedMilestoneId ,
															RT.RequestStopDateConnectedMilestoneId
											FROM    dbo.ResourceType RT
															JOIN dbo.ResourceTypePageManager_XREF RTPMX ON RTPMX.ResourceTypeId = RT.ResourceTypeId
															JOIN dbo.FTECalculatorPageManagerType PMT ON PMT.PageManagerTypeId = RTPMX.PageManagerTypeId
											WHERE   RT.ResourceTypeId = @resourceTypeId
															AND RTPMX.IsProposal = @isPRoposal;";
			PageManager_WS pageManagerInfo = new PageManager_WS();
			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery, new SqlParameter("resourceTypeId", resourceTypeId), new SqlParameter("isProposal", isProposalRequest)))
			{
				try
				{
					while (dr.Read())
					{
						pageManagerInfo.Id = DbSafe.Int(dr["PageManagerTypeId"]);
						pageManagerInfo.Name = DbSafe.StringValue(dr["TypeName"]);
						if (isProposalRequest)
						{
							ResourceType resourceType = CacheService.ResourceTypes[resourceTypeId];
							pageManagerInfo.ResourceTransitionTime = CalculatorUtility.GetResourceTransitionTimeInDays(resourceType.ResourceTransitionTime);
						}
						else
						{
							pageManagerInfo.ResourceTransitionTime = CalculatorUtility.GetResourceTransitionTimeInDays(DbSafe.IntNull(dr["ResourceTransitionTime"]));
							if (!isProposalRequest)
							{
								pageManagerInfo.AssigneesAlwaysUnblinded = DbSafe.Bool(dr["AssigneesAlwaysUnblinded"]);
								pageManagerInfo.DisplaysBlindedField = DbSafe.Bool(dr["DisplaysBlindedField"]);
							}
						}

						pageManagerInfo.DefaultFromMilestoneId = DbSafe.Int(dr["DefaultFromMilestoneId"]);
						pageManagerInfo.DefaultToMilestoneId = DbSafe.Int(dr["DefaultToMilestoneId"]);
						pageManagerInfo.RequestStartDateConnectedMilestoneId = DbSafe.IntNull(dr["RequestStartDateConnectedMilestoneId"]);
						pageManagerInfo.RequestStopDateConnectedMilestoneId = DbSafe.IntNull(dr["RequestStopDateConnectedMilestoneId"]);
					}
				}
				finally { dr.Close(); }
			}
			return pageManagerInfo;
		}
		#endregion

	}
}
