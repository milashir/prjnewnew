﻿
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RPM.Common;
namespace Quintiles.RM.Clinical.Domain.Models
{
	[DataContract]
	public class OrganizationProjectMilestone
	{
		[DataMember]
		public int projectMileStoneId { get; set; }
		[DataMember]
		public string projectMilestoneName { get; set; }
		[DataMember]
		public bool organizationHasProjectMilestone { get; set; }
		[DataMember]
		public int organizationId { get; set; }

		public void addOrganizationProjectMilestone(int OrganizationId, List<int> ProjectMilestoneIdsList)
		{
			string projectMileStoneIds = string.Empty;
			projectMileStoneIds = string.Join(",", ProjectMilestoneIdsList.ConvertAll(x => x.ToString()).ToArray());
			//Delete Query
			var delQuery = string.Format("Delete from dbo.OrganizationProjectMilestone_XREF where OrganizationId ={0} and ProjectMileStoneId Not IN ({1}) ", OrganizationId, projectMileStoneIds);
			//Insert Query
			var insquery = string.Format("INSERT  INTO dbo.OrganizationProjectMilestone_XREF (OrganizationId,ProjectMileStoneId ,LastModifiedBy,LastModifiedOn,CreatedBy ,CreatedOn) SELECT '{0}',ProjectMileStoneId,'{2}',GETDATE(),'{2}',GETDATE() FROM dbo.cd_ProjectMilestone where ProjectMileStoneId in ( SELECT  ProjectMileStoneId FROM dbo.cd_ProjectMilestone WHERE ProjectMileStoneId IN ( {1} )  EXCEPT SELECT ProjectMileStoneId FROM  dbo.OrganizationProjectMilestone_XREF WHERE OrganizationId = {0} )", OrganizationId, projectMileStoneIds, ExtensionMethods.GetCurrentUserQid());
			var sql = string.Format("{0};{1}", delQuery, insquery);
			try { DbHelp.ExecuteNonQueryText(sql, ConfigValue.CommandTimeout); }
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}




	[DataContract]
	public class OrganizationProjectMilestone_WS
	{
		[DataMember]
		public List<OrganizationProjectMilestone> OrganizationPMList { get; set; }
		[DataMember]
		public FancyTreeData OrganizationPMData { get; set; }
		public OrganizationProjectMilestone_WS(List<OrganizationProjectMilestone> organizationPMList)
		{
			OrganizationPMList = organizationPMList;
			MapResourceTypeData(OrganizationPMList);
		}

		private void MapResourceTypeData(List<OrganizationProjectMilestone> OrganizationPMList)
		{
			OrganizationPMData = new FancyTreeData();
			if (OrganizationPMList != null)
			{
				FancyTreeNode organizationPMNode;
				organizationPMNode = new FancyTreeNode { title = "Organizational Project Milestones", expanded = true, hideCheckbox = false, unselectable = false };
				foreach (var OrganizationPM in OrganizationPMList)
				{
					//FancyTreeNode organizationalUnitNode;
					if (OrganizationPM.projectMileStoneId == 1)
					{
						//					organizationNode = new FancyTreeNode { title = "OrganizationsProjectMilestones", hideCheckbox = false, unselectable = false };
						OrganizationPMData.treeNodes.Add(organizationPMNode);
					}
					if (OrganizationPM.organizationHasProjectMilestone)
						organizationPMNode.children.Add(new FancyTreeNode { title = OrganizationPM.projectMilestoneName, selected = true, key = OrganizationPM.projectMileStoneId.ToString() });
					else
						organizationPMNode.children.Add(new FancyTreeNode { title = OrganizationPM.projectMilestoneName, selected = false, key = OrganizationPM.projectMileStoneId.ToString() });
				}
			}
		}

	}
}
