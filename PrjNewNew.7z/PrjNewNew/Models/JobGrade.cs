﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public class JobGrade
	{
		public int JobGradeId { get; set; }
		public int Name { get; set; }

		public static List<int> GetJobGradeArray()
		{
			var jobGradeList = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText("SELECT Name FROM dbo.JobGrade ORDER BY Name ASC;"))
			{
				try { while (dr.Read()) { jobGradeList.Add(DbSafe.Int(dr["Name"])); } }
				finally { dr.Close(); }
			}
			return jobGradeList;
		}
	}
}
