﻿using System;
using Castle.ActiveRecord;
using NHibernate.Criterion;


namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "Project_FirewalledStudies")]
	public class Project_FirewalledStudies : AbstractActiveRecordBaseModel<Project_FirewalledStudies>
	{
		#region Properties

		[PrimaryKey(Column = "ProjectFirewalledStudyId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public int FirewalledProjectId { get; set; }

		#endregion

		public static bool FindByProjectIdAndFirewalledProjectId(int projectId, int firewalledProjectId)
		{
			var criteria = DetachedCriteria.For(typeof(Project_FirewalledStudies));
			criteria.Add(Restrictions.Eq("ProjectId", projectId));
			criteria.Add(Restrictions.Eq("FirewalledProjectId", firewalledProjectId));
			return Count(criteria)>0;
		}
	}
}
