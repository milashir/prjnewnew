using System.Collections.Generic;

namespace Quintiles.RM.Clinical.Domain.Models
{
    public class RolesWrapper
    {
        public IList<ResourceType> Roles;
        public string Message;
    }
}
