using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RPM.Common;
using Quintiles.RM.Clinical.Domain.Utilities;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public class ProjectProjectMilestoneDto
	{
		public int ProjectMilestoneId { get; private set; }
		public int ProjectId { get; private set; }
		public DateTime? ActualDate { get; private set; }
		public DateTime? ProjectedDate { get; private set; }
		public DateTime? ContractedDate { get; private set; }

		private ProjectProjectMilestoneDto(int projectId, DateTime? actualDate, DateTime? projectedDate, DateTime? contractedDate)
		{
			ProjectId = projectId;
			ActualDate = actualDate;
			ProjectedDate = projectedDate;
			ContractedDate = contractedDate;
		}

		public ProjectProjectMilestoneDto(int projectId, int projectMilestoneId, DateTime? actualDate, DateTime? projectedDate, DateTime? contractedDate)
			: this(projectId, actualDate, projectedDate, contractedDate)
		{
			if (CacheService.ProjectMilestones.ContainsKey(projectMilestoneId)) { ProjectMilestoneId = projectMilestoneId; }
			else { throw new ArgumentOutOfRangeException(projectMilestoneId.ToString()); }
		}

		public ProjectProjectMilestoneDto(int projectId, string projectMilestoneName, DateTime? actualDate, DateTime? projectedDate, DateTime? contractedDate)
			: this(projectId, actualDate, projectedDate, contractedDate)
		{
			if (string.IsNullOrEmpty(projectMilestoneName)) { throw new ArgumentNullException("projectMilestoneName"); }

			var projectMilestone = CacheService.ProjectMilestones.Values.FirstOrDefault(m => string.Equals(m.Name, projectMilestoneName, StringComparison.InvariantCultureIgnoreCase));
			if (projectMilestone == null)
			{
				throw new Exception(string.Format("Invalid project milestone name sent. '{0}'", projectMilestoneName));
			}
			else
			{
				ProjectMilestoneId = projectMilestone.Id;
			}
		}
	}

	/// <summary>
	/// Project to ProjectMilestone mapping, includes Projected/Actual/Contracted dates
	/// </summary>
	[ActiveRecord(Table = "ProjectProjectMilestone_XREF")]
	public class ProjectProjectMilestone : AbstractActiveRecordBaseModel<ProjectProjectMilestone>, IEquatable<ProjectProjectMilestone>
	{
		[PrimaryKey(Column = "ProjectProjectMilestoneId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public int ProjectMilestoneId { get; set; }

		[Property]
		public DateTime? ProjectedDate { get; set; }
		[Property]
		public DateTime? ActualDate { get; set; }
		[Property]
		public DateTime? ContractedDate { get; set; }
		[Property]
		public string Comment { get; set; }
		[Property]
		public DateTime? ManualEntryDate { get; set; }

		public bool Equals(ProjectProjectMilestone other)
		{
			return ((this.Id > 0 && other.Id > 0) && this.Id == other.Id);
		}

		public static ProjectProjectMilestone FindByProjectIdAndMilestoneId(int projectId, int milestoneId, bool createIfNull)
		{
			var milestone = FindByProjectIdAndMilestoneId(projectId, milestoneId);
			return milestone == null && createIfNull ? new ProjectProjectMilestone { ProjectId = projectId, ProjectMilestoneId = (int)milestoneId } : milestone;
		}

		public static ProjectProjectMilestone FindByProjectIdAndMilestoneId(int projectId, int milestoneId)
		{
			var criteria = DetachedCriteria.For(typeof(ProjectProjectMilestone));
			criteria.Add(Restrictions.Eq("ProjectId", projectId));
			criteria.Add(Restrictions.Eq("ProjectMilestoneId", milestoneId));

			return FindOne(criteria);
		}

		public static void UpdateProjectProjectMilestones(List<ProjectMilestones_WS> updatedProjectMilestonesFromUi, AddMilestoneStatus_WS result)
		{
			if (updatedProjectMilestonesFromUi != null && updatedProjectMilestonesFromUi.Count > 0)
			{
				var projectMilestoneListForComputedMilestones = new List<ProjectProjectMilestoneDto>();

				var updateQuery = string.Empty;
				foreach (var updatedProjectMilestone in updatedProjectMilestonesFromUi)
				{
					ProjectMilestone projectMilestoneConfig;
					//This code is needed until we completely remove date columns from Project table.
					if (CacheService.ProjectMilestones.TryGetValue(updatedProjectMilestone.ProjectMilestoneId, out projectMilestoneConfig) && projectMilestoneConfig.TargetTable == Constants.ProjectTable)
					{
						updateQuery = string.Format("{0} {1}={2}, ",
														string.IsNullOrEmpty(updateQuery) ? "UPDATE dbo.Project SET " : updateQuery,
														projectMilestoneConfig.ActualColumnMapping,
														updatedProjectMilestone.MilestoneDate.ToDateFromQDateString().ToNullableDbDate());
					}

					if (updatedProjectMilestone.MilestoneDate == null)
					{
						ProjectProjectMilestone.DeleteAll(string.Format("ProjectId={0} AND ProjectMilestoneId={1}", updatedProjectMilestone.ProjectId, updatedProjectMilestone.ProjectMilestoneId));
					}
					else
					{
						//Update computed milestones and cascade to requests.
						ComputedProjectMilestoneService.CreateOrUpdateComputedMilestones(new ProjectProjectMilestoneDto(updatedProjectMilestone.ProjectId, updatedProjectMilestone.ProjectMilestoneId, updatedProjectMilestone.MilestoneDate.ToDateFromQDateString(), null, null), true);

						ProjectProjectMilestone existingProjectMilestones = ProjectProjectMilestone.FindByProjectIdAndMilestoneId(updatedProjectMilestone.ProjectId, updatedProjectMilestone.ProjectMilestoneId);

						if (existingProjectMilestones == null)
						{
							new ProjectProjectMilestone
							{
								ProjectId = updatedProjectMilestone.ProjectId,
								ProjectMilestoneId = updatedProjectMilestone.ProjectMilestoneId,
								ActualDate = updatedProjectMilestone.MilestoneDate.ToDateFromQDateString(),
								Comment = updatedProjectMilestone.Comment,
								ManualEntryDate = updatedProjectMilestone.MilestoneDate.ToDateFromQDateString()

							}.SaveAndFlush();
						}
						else if (updatedProjectMilestone.MilestoneDate.ToDateFromQDateString() != existingProjectMilestones.ActualDate)
						{
							existingProjectMilestones.ActualDate = updatedProjectMilestone.MilestoneDate.ToDateFromQDateString();
							existingProjectMilestones.Comment = updatedProjectMilestone.Comment;
							existingProjectMilestones.ManualEntryDate = updatedProjectMilestone.MilestoneDate.ToDateFromQDateString();
							existingProjectMilestones.UpdateAndFlush();

							GenericInitiateCalculator.CascadeMilestonesToRequestAndGenericCalculators(updatedProjectMilestone.ProjectMilestoneId, updatedProjectMilestone.ProjectId, GenericMilestoneType_E.Project, updatedProjectMilestone.MilestoneDate.ToDateFromQDateString());
						}
						
						//Update custom computed milestones and cascade to requests.
						ComputedProjectMilestoneService.CreateOrUpdateAllCustomComputedMilestones(updatedProjectMilestone.ProjectId, true);
					}
				}


				if (!string.IsNullOrEmpty(updateQuery))
				{
					updateQuery = string.Format("{0} LastModifiedBy='{1}', LastModifiedOn=GETDATE() WHERE ProjectId={2}", updateQuery, ExtensionMethods.GetCurrentUserQid(), updatedProjectMilestonesFromUi[0].ProjectId);
					DbHelp.ExecuteNonQueryText(updateQuery);
				}
			}
		}

		#region UpdateInitialAwardedDateInProjectMilestone
		public static void UpdateInitialAwardedDateInProjectMilestone(PPMProject_WS updatedProjectMilestonesFromUi)
		{
			try
			{
				ProjectProjectMilestone projectProjectMilestone = ProjectProjectMilestone.FindByProjectIdAndMilestoneId(updatedProjectMilestonesFromUi.ProjectId, Constants.InitialAwardedDate);
				if (projectProjectMilestone == null)
				{
					ProjectProjectMilestone projectProjectMilestoneAwarded = ProjectProjectMilestone.FindByProjectIdAndMilestoneId(updatedProjectMilestonesFromUi.ProjectId, Constants.AwardedDate);
					if (projectProjectMilestoneAwarded != null)
					{
						new ProjectProjectMilestone()
						{
							ProjectedDate = projectProjectMilestoneAwarded.ProjectedDate,
							ContractedDate = projectProjectMilestoneAwarded.ContractedDate,
							ActualDate = projectProjectMilestoneAwarded.ActualDate,
							ProjectId = projectProjectMilestoneAwarded.ProjectId,
							ProjectMilestoneId = Constants.InitialAwardedDate
						}.SaveAndFlush();
					}
				}
				else
				{
					projectProjectMilestone.ProjectedDate = updatedProjectMilestonesFromUi.InitialAwardedDate.ToDateFromQDateString();
					projectProjectMilestone.ContractedDate = updatedProjectMilestonesFromUi.InitialAwardedDate.ToDateFromQDateString();
					projectProjectMilestone.ActualDate = updatedProjectMilestonesFromUi.InitialAwardedDate.ToDateFromQDateString();
					projectProjectMilestone.SaveAndFlush();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		#endregion
	}
}