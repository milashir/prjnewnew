﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Properties;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ResourceRequirements_ExperienceCriteria_XREF")]
	public class ProjectJobRoleExperienceCriteria : AbstractActiveRecordBaseModel<ProjectJobRoleExperienceCriteria>, IComparable<ProjectJobRoleExperienceCriteria>
	{
		[PrimaryKey(Column = "ProjectJobRoleExperienceCriteriaId", UnsavedValue = "-1")]
		public override int Id { get; set; }


		public ProjectJobRole ProjectJobRole { get; set; }

		/// <summary>
		///Gets or sets the ProjectJobRoleId.
		///</summary> 
		[Property]
		public int ProjectJobRoleId { get; set; }

		/// <summary>
		///Gets or sets the ProjectJobRoleGroupId.
		///</summary> 
		[Property]
		public int? ProjectJobRoleGroupId { get; set; }

		/// <summary>
		///Gets or sets the RequirementTypeId.
		///</summary>  
		[Property]
		public RequirementType_E RequirementTypeId { get; set; }

		/// <summary>
		///Gets or sets the ExperienceCategoryId.
		///</summary>  
		[Property]
		public ExperienceCategory_E ExperienceCategoryId { get; set; }

		/// <summary>
		///Gets or sets the TherapeuticAreaId.
		///</summary>       
		[BelongsTo("TherapeuticAreaId")]
		public TherapeuticArea TherapeuticArea { get; set; }

		/// <summary>
		///Gets or sets the TherapeuticAreaId.
		///</summary>    
		[Property]
		public int TherapeuticAreaId { get; set; }

		/// <summary>
		///Gets or sets the NoOfYearsForArea.
		///</summary>       
		[Property]
		public string NoOfYearsForArea { get; set; }

		/// <summary>
		///Gets or sets the IndicationId.
		///</summary>       
		[BelongsTo("IndicationId")]
		public Indication Indication { get; set; }

		/// <summary>
		///Gets or sets the IndicationId.
		///</summary>  
		[Property]
		public int IndicationId { get; set; }

		/// <summary>
		///Gets or sets the NoOfYearsForIndication.
		///</summary>       
		[Property]
		public string NoOfYearsForIndication { get; set; }

		/// <summary>
		///Gets or sets the InHouseMonitoring.
		///</summary>       
		[Property]
		public int? InHouseMonitoring { get; set; }

		/// <summary>
		///Gets or sets the OnSiteMonitoring.
		///</summary>       
		[Property]
		public int? OnSiteMonitoring { get; set; }

		/// <summary>
		///Gets or sets the GlobalProjectExperience.
		///</summary>       
		[Property]
		public int? GlobalProjectExperience { get; set; }

		/// <summary>
		///Gets or sets the Education.
		///</summary>       
		[Property]
		public string Education { get; set; }

		#region IComparable<ProjectJobRole> Members

		public int CompareTo(ProjectJobRoleExperienceCriteria other)
		{
			return this.ProjectJobRole.Id.CompareTo(other.ProjectJobRoleId);
		}

		#endregion


		public bool HasEducation()
		{
			return !String.IsNullOrEmpty(Education);
		}
		public bool HasMonitoringExperience()
		{
			return (InHouseMonitoring != null || OnSiteMonitoring != null);
		}
		public bool HasGlobalProjectExperience()
		{
			return GlobalProjectExperience != null;
		}

		public static IList<ProjectJobRoleExperienceCriteria> GetAllProjJobRoleExpCrtByProjectId(int projectId)
		{
			List<ProjectJobRoleExperienceCriteria> lstProjJobRoleExpCrt = new List<ProjectJobRoleExperienceCriteria>();
			IList<ProjectJobRole> lstProjectJobRoles = new List<ProjectJobRole>();
			lstProjectJobRoles = ProjectJobRole.FindByProjectId(projectId);

			foreach (var objProjJob in lstProjectJobRoles)
			{
				DetachedCriteria criteria = DetachedCriteria.For(typeof(ProjectJobRoleExperienceCriteria));
				criteria.Add(Expression.Eq("ProjectJobRoleId", objProjJob.Id));
				lstProjJobRoleExpCrt.Add(ProjectJobRoleExperienceCriteria.FindFirst(criteria));
			}

			return lstProjJobRoleExpCrt;
		}

		public static void DeleteResourcingRequirements(int[] projectJobRoleExpCriteriaIds)
		{
			foreach (int projectJobRoleExpCriteriaId in projectJobRoleExpCriteriaIds)
			{
				DbHelp.ExecuteNonQuerySP("ResourceRequirements_Delete", new SqlParameter("projectJobRoleExperienceCriteriaId", projectJobRoleExpCriteriaId));
			}
		}

		public static PagedResponse<GridProjectJobRoleExperienceCriteria_WS, GridRowCommonData> FindAllPagedByProjectId(int projectId)
		{
			var projJobRoleExpCrtList = new List<GridProjectJobRoleExperienceCriteria_WS>();
			var lstProjJobRoles = new List<ProjectJobRoleGroup>(ProjectJobRoleGroup.FindByProjectId(projectId));

			using (var dr = DbHelp.ExecuteDataReaderSP("ResourceRequirements_GetDetails", new SqlParameter("projectId", projectId)))
			{
				ColumnChecker cc = null;
				try
				{
					while (dr.Read())
					{
						if (cc == null) { cc = new ColumnChecker(dr); }
						GridProjectJobRoleExperienceCriteria_WS projJobRoleExpCriteria = new GridProjectJobRoleExperienceCriteria_WS
						{
							JobRole = DbSafe.StringValue(dr["JobRole"]),
							AppliesTo = DbSafe.StringValue(dr["AppliesTo"]),
							ResourceRequirementType = DbSafe.StringValue(dr["ResourceRequirementType"]),
							ExperienceCategory = DbSafe.StringValue(dr["ExperienceCategory"]),
							Experience = DbSafe.StringValue(dr["Experience"]),
							JobRoleId = DbSafe.Int(dr["JobRoleId"]),
							ProjectJobRoleId = DbSafe.Int(dr["ProjectJobRoleId"]),
							ProjectJobRoleExperienceCriteriaId = DbSafe.Int(dr["ProjectJobRoleExperienceCriteriaId"]),
							RequirementTypeId = DbSafe.Int(dr["RequirementTypeId"]),
							ExperienceCategoryId = DbSafe.Int(dr["ExperienceCategoryId"]),
							TherapeuticAreaId = DbSafe.Int(dr["TherapeuticAreaId"]),
							NoOfYearsForArea = DbSafe.StringValue(dr["NoOfYearsForArea"]),
							IndicationId = DbSafe.Int(dr["IndicationId"]),
							NoOfYearsForIndication = DbSafe.StringValue(dr["NoOfYearsForIndication"]),
							InHouseMonitoring = DbSafe.StringValue(dr["InHouseMonitoring"]),
							OnSiteMonitoring = DbSafe.StringValue(dr["OnSiteMonitoring"]),
							GlobalProjectExperience = DbSafe.StringValue(dr["GlobalProjectExperience"]),
							AppliesToIds = DbSafe.StringValue(dr["AppliesToIds"])
						};
						if (lstProjJobRoles != null)
						{
							var objMatchingJobRole = (projJobRoleExpCriteria.JobRole == JobRoleGroupName_E.CRA.ToString()) ? lstProjJobRoles.Find(jr => jr.JobRoleGroupId == (int)JobRoleGroupName_E.CRA) : lstProjJobRoles.Find(jr => jr.JobRoleGroupId == (int)JobRoleGroupName_E.ProjectLeadership);
							if (objMatchingJobRole != null)
							{
								projJobRoleExpCriteria.Notes = objMatchingJobRole.ContractualNotes;
							}
						}
						projJobRoleExpCrtList.Add(projJobRoleExpCriteria);
					}
				}
				finally { dr.Close(); }
			}

			var pr = new PagedResponse<GridProjectJobRoleExperienceCriteria_WS, GridRowCommonData>();
			pr.Records = projJobRoleExpCrtList;
			pr.TotalPages = 1;
			pr.TotalRecords = projJobRoleExpCrtList.Count;
			pr.PageNumber = pr.TotalRecords == 0 ? 0 : 1;
			return pr;
		}

		public static AddUpdateResourcingRequirementsStatus_WS SaveResourcingRequirements(ProjectJobRoleExperienceCriteria_WS projectJobRoleExpCriteria)
		{
			AddUpdateResourcingRequirementsStatus_WS executionStatus = new AddUpdateResourcingRequirementsStatus_WS { ValidationErrors = new List<ValidationMessage_WS>() };

			try
			{
				if (!CheckIfDuplicateRequirementsExists(projectJobRoleExpCriteria))
				{
					DataTable tableResourceRequirementsResourceTypeGroup = GetResourceRequirementsResourceType(projectJobRoleExpCriteria.ResourceRequirementsResouceTypeGroupLst);

					DbHelp.ExecuteScalarSP("dbo.ResourceRequirements_CreateOrUpdate",
											new SqlParameter("@ProjectId", projectJobRoleExpCriteria.ProjectId),
											new SqlParameter("@Qid", ExtensionMethods.GetCurrentUserQid()),
											new SqlParameter("@HasRequirements", projectJobRoleExpCriteria.HasRequirements),
											new SqlParameter("@ProjectJobRoleExpCriteriaId", projectJobRoleExpCriteria.ProjJobRoleExpCriteriaId),
											new SqlParameter("@ProjectJobRoleGroupId", projectJobRoleExpCriteria.ProjectJobRoleGroupId),
											new SqlParameter("@ResourcingRequirementsTypeId", projectJobRoleExpCriteria.HasRequirements ? (int)ResourcingRequirementsType_E.Resourcing : (int)ResourcingRequirementsType_E.NoRequirement),
											new SqlParameter("@JobRoleGroupId", projectJobRoleExpCriteria.JobRoleId),
											new SqlParameter("@ContractualRequirementsText", projectJobRoleExpCriteria.ContractualRequirements),
											new SqlParameter("@RequirementTypeId", projectJobRoleExpCriteria.RequirementTypeId),
											new SqlParameter("@ExperienceCategoryId", projectJobRoleExpCriteria.ExperienceCategoryId),
											new SqlParameter("@TherapeuticAreaId", projectJobRoleExpCriteria.TherapeuticAreaId != 0 ? projectJobRoleExpCriteria.TherapeuticAreaId : -1),
											new SqlParameter("@NoOfYearsForArea", projectJobRoleExpCriteria.NoOfYearsForArea),
											new SqlParameter("@IndicationId", projectJobRoleExpCriteria.IndicationId != 0 ? projectJobRoleExpCriteria.IndicationId : -1),
											new SqlParameter("@NoOfYearsForIndication", projectJobRoleExpCriteria.NoOfYearsForIndication),
											new SqlParameter("@InHouseMonitoring", projectJobRoleExpCriteria.InHouseMonitoring),
											new SqlParameter("@OnSiteMonitoring", projectJobRoleExpCriteria.OnSiteMonitoring),
											new SqlParameter("@GlobalProjectExperience", projectJobRoleExpCriteria.GlobalProjectExperience),
											new SqlParameter("@Education", projectJobRoleExpCriteria.Education),
											new SqlParameter("@ResourceRequirementsResourceTypeGroup", tableResourceRequirementsResourceTypeGroup)
											);
				}
				else
				{
					executionStatus.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, Resources.DuplicateResourcingRequirementsExist, Utilities.MessageType_E.SharepointNotification));
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return executionStatus;
		}

		private static DataTable GetResourceRequirementsResourceType(List<int> resourceTypeGroupList)
		{
			DataTable tableSQLInput = null;
			if (resourceTypeGroupList != null && resourceTypeGroupList.Count > 0)
			{
				tableSQLInput = new DataTable();
				tableSQLInput.Columns.Add("EntityId");

				foreach (var resourceTypeGroupId in resourceTypeGroupList)
				{
					DataRow dr = tableSQLInput.NewRow();
					dr["EntityId"] = resourceTypeGroupId;

					tableSQLInput.Rows.Add(dr);
				}
			}
			return tableSQLInput;
		}

		private static bool CheckIfDuplicateRequirementsExists(ProjectJobRoleExperienceCriteria_WS projectJobRoleExpCriteria)
		{
			bool isDuplicateRecord = false;

			if (projectJobRoleExpCriteria.JobRoleId != 0)
			{
				ProjectJobRoleGroup projectJobRoleGroup = ProjectJobRoleGroup.FindByProjectIdJobRoleGroupId(projectJobRoleExpCriteria.ProjectId, projectJobRoleExpCriteria.JobRoleId);
				if (projectJobRoleGroup != null)
				{
					ProjectJobRoleExperienceCriteria projJobRoleExpCrt;
					DetachedCriteria criteria = DetachedCriteria.For(typeof(ProjectJobRoleExperienceCriteria));
					criteria.Add(Expression.Not(Expression.Eq("Id", projectJobRoleExpCriteria.ProjJobRoleExpCriteriaId)));
					criteria.Add(Expression.Eq("ProjectJobRoleGroupId", projectJobRoleGroup.Id));
					criteria.Add(Expression.Eq("RequirementTypeId", (RequirementType_E)projectJobRoleExpCriteria.RequirementTypeId));
					criteria.Add(Expression.Eq("ExperienceCategoryId", (ExperienceCategory_E)projectJobRoleExpCriteria.ExperienceCategoryId));
					if (projectJobRoleExpCriteria.ExperienceCategoryId == (int)ExperienceCategory_E.TherapeuticAreaIndication)
					{
						criteria.Add(Expression.Eq("TherapeuticAreaId", projectJobRoleExpCriteria.TherapeuticAreaId != 0 ? projectJobRoleExpCriteria.TherapeuticAreaId : -1));
						criteria.Add(Expression.Eq("IndicationId", projectJobRoleExpCriteria.IndicationId != 0 ? projectJobRoleExpCriteria.IndicationId : -1));
					}
					projJobRoleExpCrt = ProjectJobRoleExperienceCriteria.FindFirst(criteria);
					isDuplicateRecord = !(projJobRoleExpCrt == null);
					if (projectJobRoleExpCriteria.JobRoleId == (int)JobRoleGroupName_E.ProjectLeadership && isDuplicateRecord)
					{
						isDuplicateRecord = CheckIfDuplicateJobRoleExists(projJobRoleExpCrt.Id, projectJobRoleExpCriteria.ResourceRequirementsResouceTypeGroupLst);
					}
				}
			}
			return isDuplicateRecord;
		}

		private static bool CheckIfDuplicateJobRoleExists(int projJobRoleExpCriteriaId, List<int> resourceReqRscTypeGrpLst)
		{
			bool isDuplicateRecord = false;

			var sql = @"SELECT ResourceRequirementsResouceTypeGroupId
																FROM    ResourceRequirements_ExperienceCriteriaResouceTypeGroup_XREF
																WHERE   ProjectJobRoleExperienceCriteriaId = @projJobRoleExpCriteriaId";

			using (var dr = DbHelp.ExecuteDataReaderText(sql, new SqlParameter("projJobRoleExpCriteriaId", (int)projJobRoleExpCriteriaId)))
			{
				try
				{
					while (dr.Read())
					{
						int resourceTypeGroupId = DbSafe.Int(dr["ResourceRequirementsResouceTypeGroupId"]);

						if (!isDuplicateRecord)
						{
							isDuplicateRecord = resourceReqRscTypeGrpLst.Contains(resourceTypeGroupId);
						}
						if (isDuplicateRecord)
						{
							break;
						}
					}
				}
				finally { dr.Close(); }
			}
			return isDuplicateRecord;
		}

		public static List<ResourcingRequirementProject_WS> GetProjectListWhichHasContractualRequirements(List<int> projectIds, int jobRoleId)
		{
			var resourcingRequirementProjectList = new List<ResourcingRequirementProject_WS>();

			var sql = string.Format(@"SELECT DISTINCT
																				P.ProjectId , P.ProjectCode + '-' + P.ProtocolNumber AS ProjectCodeProtocolNumber 
																FROM    ResourceRequirements_ProjectJobRoleGroup PJR
																INNER JOIN Project P ON PJR.ProjectId = P.ProjectId
																INNER JOIN dbo.ResourceRequirements_ExperienceCriteria_XREF RXREF 
																ON PJR.ProjectJobRoleGroupId=RXREF.ProjectJobRoleGroupId
																INNER JOIN ResourceRequirements_ExperienceCriteriaResouceTypeGroup_XREF REXREF
																ON RXREF.ProjectJobRoleExperienceCriteriaId = REXREF.ProjectJobRoleExperienceCriteriaId
																INNER JOIN ResourceRequirements_ResourceTypeResourceTypeGroup_XREF RTGXREF
																ON REXREF.ResourceRequirementsResouceTypeGroupId = RTGXREF.ResourceRequirementsResourceTypeGroupId
																INNER JOIN dbo.ResourceType RT ON RTGXREF.ResourceTypeId = RT.ResourceTypeId
																WHERE   P.ProjectId IN ({0})
																AND RT.JobRoleId = {1}", string.Join(",", projectIds.Select(r => r.ToString()).ToArray()), jobRoleId);

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						var resourcingRequirementProject = new ResourcingRequirementProject_WS();
						resourcingRequirementProject.projectId = DbSafe.Int(dr["ProjectId"]);
						resourcingRequirementProject.projectCodeProtocolNumber = DbSafe.StringValue(dr["ProjectCodeProtocolNumber"]);
						resourcingRequirementProjectList.Add(resourcingRequirementProject);
					}
				}
				finally { dr.Close(); }
			}
			return resourcingRequirementProjectList;
		}

		public static IList<ProjectJobRoleExperienceCriteria> FindByProjectRoleIdAndRequirementTypeIdAndExperienceCategoryId(int ProjectRoleGroupId, RequirementType_E requirementType, ExperienceCategory_E experienceCategory, List<int> resourceTypeList)
		{
			List<ProjectJobRoleExperienceCriteria> projectJobRoleExperienceCriteriaList = new List<ProjectJobRoleExperienceCriteria>();
			string selectQuery = string.Format(@"SELECT DISTINCT																					
																					EC.ProjectJobRoleExperienceCriteriaId
																	FROM    ResourceRequirements_ProjectJobRoleGroup PJR
																					INNER JOIN ResourceRequirements_ExperienceCriteria_XREF EC ON PJR.ProjectJobRoleGroupId = EC.ProjectJobRoleGroupId
																					LEFT JOIN ResourceRequirements_ExperienceCriteriaResouceTypeGroup_XREF ECG ON EC.ProjectJobRoleExperienceCriteriaId = ECG.ProjectJobRoleExperienceCriteriaId
																					LEFT JOIN ResourceRequirements_ResourceTypeResourceTypeGroup_XREF RTG ON RTG.ResourceRequirementsResourceTypeGroupId = ECG.ResourceRequirementsResouceTypeGroupId
																	WHERE   PJR.ProjectJobRoleGroupId = {0}
																					AND EC.RequirementTypeId = {1}
																					AND EC.ExperienceCategoryId = {2}
																					AND RTG.ResourceTypeId in({3})", ProjectRoleGroupId, (int)requirementType, (int)experienceCategory, string.Join(",", resourceTypeList.Select(r => r.ToString()).ToArray()));

			using (var dr = DbHelp.ExecuteDataReaderText(selectQuery))
			{
				try
				{
					while (dr.Read())
					{
						ProjectJobRoleExperienceCriteria experienceCriteria = ProjectJobRoleExperienceCriteria.FindByPrimaryKey(DbSafe.Int(dr["ProjectJobRoleExperienceCriteriaId"]));
						projectJobRoleExperienceCriteriaList.Add(experienceCriteria);
					}
				}
				finally { dr.Close(); }
			}
			return projectJobRoleExperienceCriteriaList;
		}
		public static void GetExperienceCriteria(Project project, int jobRoleId, List<int> resourceTypeList, List<ProjectExperienceDetails> projectExperienceDetailsList, StringBuilder outerDiv)
		{
			ExperienceType[] expAll = ExperienceType.FindAllForExperienceCriteriaPage();

			StringBuilder containerDiv = new StringBuilder();
			StringBuilder msaContent = new StringBuilder();
			string education = string.Empty;

			containerDiv.AppendFormat("<div class='hoverTipContainer' id='hoverTip_{0}' projectId='{0}'>", project.Id);
			containerDiv.Append("<div class='hoverProject'>");

			ProjectExperienceDetails projectExperienceDetails = new ProjectExperienceDetails();
			projectExperienceDetails.ProjectCode = project.ProjectCode;
			projectExperienceDetails.ProjectId = project.Id;

			MSAView_WS msaView = new MSAView_WS(expAll) { HasData = false };

			ProjectJobRoleGroup projectJobRoleGroup = ProjectJobRoleGroup.FindByProjectIdJobRoleGroupId(project.Id, CacheService.AllJobRoles[jobRoleId].JobRoleGroupId);

			if (projectJobRoleGroup != null)
			{

				ResourcingContractualRequirements resourcingContractualRequirements = GetContractualRequirements(projectJobRoleGroup.Id, resourceTypeList);
				if (resourcingContractualRequirements.HasRequirements)
				{
					StringBuilder headerDiv = new StringBuilder();
					headerDiv.Append("<div class='hoverTipRow'>");
					headerDiv.Append("<div class='hoverTipElements hoverTipElementsTitle'>");
					headerDiv.Append("<span class='hoverTipElementsMSA'>Contractual Agreements Defined</span><span class='hoverTipElementsRM'>RM Adjusted</span>");
					headerDiv.Append("</div></div>");

					//Add header to MSA content DIV

					msaContent.Append(headerDiv.ToString());

					//Define view model for MSA panel
					msaView.ProjectId = projectJobRoleGroup.ProjectId;
					msaView.ProjectCode = project.ProjectCode;
					msaView.Id = projectJobRoleGroup.Id;

					if (resourcingContractualRequirements.OtherRequirements != null)
					{
						msaView.Education = new AdjustableValue_WS()
						{
							Id = null, //not an experiencetype, thus no code table used for Education
							Enabled = resourcingContractualRequirements.OtherRequirements.HasEducation(),
							Checked = true,
							Value = resourcingContractualRequirements.OtherRequirements.Education,
							ValueAdjusted = String.Empty
						};
					}

					if (resourcingContractualRequirements.MonitoringRequirements != null)
					{
						msaView.InHouse = new AdjustableValue_WS()
						{
							Id = resourcingContractualRequirements.MonitoringRequirements.InHouseMonitoring,
							Enabled = resourcingContractualRequirements.MonitoringRequirements.HasMonitoringExperience(),
							Checked = true,
							Value = resourcingContractualRequirements.MonitoringRequirements.InHouseMonitoring == null ? String.Empty : resourcingContractualRequirements.MonitoringRequirements.InHouseMonitoring.ToString(),
							ValueAdjusted = "-1"
						};

						msaView.OnSite = new AdjustableValue_WS()
						{
							Id = resourcingContractualRequirements.MonitoringRequirements.OnSiteMonitoring,
							Enabled = resourcingContractualRequirements.MonitoringRequirements.HasMonitoringExperience(),
							Checked = true,
							Value = resourcingContractualRequirements.MonitoringRequirements.OnSiteMonitoring == null ? String.Empty : resourcingContractualRequirements.MonitoringRequirements.OnSiteMonitoring.ToString(),
							ValueAdjusted = "-1"
						};
					}

					if (resourcingContractualRequirements.GlobalProjectManagementRequirements != null)
					{
						msaView.GlobalProjectExperience = new AdjustableValue_WS()
						{
							Id = (int)ExperienceType_E.GlobalProjectExperience,
							Enabled = resourcingContractualRequirements.GlobalProjectManagementRequirements.HasGlobalProjectExperience(),
							Checked = true,
							Value = resourcingContractualRequirements.GlobalProjectManagementRequirements.GlobalProjectExperience == null ? String.Empty : resourcingContractualRequirements.GlobalProjectManagementRequirements.GlobalProjectExperience.ToString(),
							ValueAdjusted = "-1"
						};
					}

					List<MSAViewItem_WS> indications = new List<MSAViewItem_WS>();
					List<MSAViewItem_WS> areas = new List<MSAViewItem_WS>();

					if (resourcingContractualRequirements.TherapeuticIndicationRequirements.Count() > 0)
					{
						foreach (ProjectJobRoleExperienceCriteria ec in resourcingContractualRequirements.TherapeuticIndicationRequirements)
						{
							if (ec.TherapeuticArea.Id != -1)
							{
								MSAViewItem_WS newItem = new MSAViewItem_WS() { Name = ec.TherapeuticArea.Name, YearsOfExperience = ec.NoOfYearsForArea, Id = ec.TherapeuticArea.Id, Checked = true };
								if (!areas.Contains(newItem, new MSAViewItemComparer()))
								{
									areas.Add(newItem);
								}
							}
							if (ec.Indication.Id != -1)
							{
								MSAViewItem_WS newItem = new MSAViewItem_WS() { Name = ec.Indication.Name, YearsOfExperience = ec.NoOfYearsForIndication, Id = ec.Indication.Id, Checked = true };
								if (!indications.Contains(newItem, new MSAViewItemComparer()))
								{
									indications.Add(newItem);
								}
							}
						}
					}


					if (areas.Count > 0)
					{
						msaContent.Append("<h3>Therapeutic Areas</h3>");
						foreach (MSAViewItem_WS msaViewItem in areas)
						{
							StringBuilder sbTherapeutic = new StringBuilder();
							msaView.TherapeuticAreas.Add(msaViewItem);
							sbTherapeutic.AppendFormat("<div class='hoverTipRow' id='hoverTipRow_{0}_t{1}' style='padding-top:5px'>", msaView.Id, msaViewItem.Id);
							sbTherapeutic.Append("<div class='hoverTipElements'>");
							sbTherapeutic.AppendFormat("<input type='checkbox' id='chk_t{2}' class='hoverTipElementsCheckBox' elementid={2} area='TherapeuticArea' checked='checked' projectId='{1}'   />", msaView.Id, msaView.ProjectId, msaViewItem.Id);
							sbTherapeutic.AppendFormat("<span class='noteTarea'>{0}</span>", msaViewItem.Name);
							sbTherapeutic.AppendFormat("<span class='noteMsaDefined'>{0}</span>", msaViewItem.YearsOfExperience);
							//sbTherapeutic.AppendFormat("<input class='hoverTipElementsInputText validateRange forvalidate' area='TherapeuticArea' type='text' id='txt_t{2}' projectId='{1}' maxlength='6'  from='0' to='50' formating='2,3' allowBlank='true' size='16' />", msaView.Id, msaView.ProjectId, msaViewItem.Id);

							sbTherapeutic.AppendFormat("<select id='ddl_{0}_TA{1}' class='hoverTipElementsTA'>", msaView.Id, msaViewItem.Id);
							sbTherapeutic.AppendFormat("<option value='{0}'>{1}</option>", -1, "-- adjust --");
							string[] options = "NA|<1|1-3|3-5|5-10|10-15|>15".Split('|');
							for (int i = 0; i < options.Length; i++)
							{
								sbTherapeutic.AppendFormat("<option value='{0}'>{1}</option>", options[i], options[i]);
							}
							sbTherapeutic.AppendFormat("</select>");

							sbTherapeutic.Append("<p></p></div></div>");
							msaContent.Append(sbTherapeutic.ToString());
						}
					}

					if (indications.Count > 0)
					{
						msaContent.Append("<h3>Indications</h3>");
						foreach (MSAViewItem_WS msaViewItem in indications)
						{
							StringBuilder sbIndication = new StringBuilder();
							msaView.IndicationAreas.Add(msaViewItem);
							sbIndication.AppendFormat("<div class='hoverTipRow' id='hoverTipRow_{0}_i{1}'>", msaView.Id, msaViewItem.Id);
							sbIndication.Append("<div class='hoverTipElements'>");
							sbIndication.AppendFormat("<input type='checkbox' id='chk_i{2}' area='IndicationArea' elementid={2} class='hoverTipElementsCheckBox' checked='checked' projectId='{1}'  />", msaView.Id, msaView.ProjectId, msaViewItem.Id);
							sbIndication.AppendFormat("<span class='noteIndication'>{0}</span>", msaViewItem.Name);
							sbIndication.AppendFormat("<span class='noteMsaDefined'>{0}</span>", msaViewItem.YearsOfExperience);
							//sbIndication.AppendFormat("<input class='hoverTipElementsInputText validateRange forvalidate'  area = 'IndicationArea'  type='text' id='txt_i{2}' projectId='{1}' maxlength='6'  from='0' to='50' formating='2,3' allowBlank='true' size='16' />", msaView.Id, msaView.ProjectId, msaViewItem.Id);

							sbIndication.AppendFormat("<select id='ddl_{0}_Ind{1}' class='hoverTipElementsIND'>", msaView.Id, msaViewItem.Id);
							sbIndication.AppendFormat("<option value='{0}'>{1}</option>", -1, "-- adjust --");
							string[] options = "NA|<1|1-3|3-5|5-10|10-15|>15".Split('|');
							for (int i = 0; i < options.Length; i++)
							{
								sbIndication.AppendFormat("<option value='{0}'>{1}</option>", options[i], options[i]);
							}
							sbIndication.AppendFormat("</select>");
							sbIndication.Append("</div></div>");

							msaContent.Append(sbIndication.ToString());
						}
					}

					if (resourcingContractualRequirements.OtherRequirements != null)
					{
						msaContent.Append("<h3>Education</h3>");

						msaContent.AppendFormat("<div class='hoverTipRow' id='hoverTipRow_education{0}_footer' style='padding-top:5px' >", msaView.Id);
						msaContent.Append("<div class='hoverTipElements'>");
						msaContent.AppendFormat("<input type='checkbox'  id='chk_education{0}' area='EducationArea' elementid={1} class='hoverTipElementsCheckBox chk_education' checked='checked' projectId='{0}'  />", msaView.ProjectId, msaView.Id);
						msaContent.AppendFormat("<span class='noteIndication'>{0}</span>", "Education");
						msaContent.AppendFormat("<span class='noteMsaDefined'>{0}</span>", msaView.Education.Value);
						msaContent.Append("</div></div>");
					}

					if (resourcingContractualRequirements.MonitoringRequirements != null)
					{
						msaContent.Append("<h3>Monitoring Experience</h3>");
						StringBuilder div = new StringBuilder();
						IEnumerable<ExperienceType> expInHouseList = expAll.Where(exp => ExperienceType.InHouseExpTypes.Contains(exp.Id));
						foreach (ExperienceType et in expInHouseList)
						{
							if (et.Id == resourcingContractualRequirements.MonitoringRequirements.InHouseMonitoring)
							{
								div.AppendFormat("<div class='hoverTipRow' id='hoverTipRow_{0}_InHouse{1}'>", msaView.Id, et.Id);
								div.Append("<div class='hoverTipElements'>");
								div.AppendFormat("<input type='checkbox' id='chk_{0}_InHouse' value='{1}' class='hoverTipElementsCheckBox' checked='checked'  />", msaView.Id, et.Id);
								div.AppendFormat("<span class='noteIndication'>{0}</span>", et.NameForUi);
								div.AppendFormat("<br/><select id='ddl_{0}_InHouse'>", msaView.Id);
								div.AppendFormat("<option value='{0}'>{1}</option>", -1, "-- adjust --");
								foreach (ExperienceType et2 in expInHouseList)
								{
									div.AppendFormat("<option value='{0}'>{1}</option>", et2.Id, et2.NameForUi);
								}
								div.AppendFormat("</select>");
								div.Append("</div></div>");
							}
						}
						msaContent.Append(div);

						div = new StringBuilder();
						IEnumerable<ExperienceType> expOnSiteList = expAll.Where(exp => ExperienceType.OnSiteExpTypes.Contains(exp.Id));
						foreach (ExperienceType et in expOnSiteList)
						{
							if (et.Id == resourcingContractualRequirements.MonitoringRequirements.OnSiteMonitoring)
							{
								div.AppendFormat("<div class='hoverTipRow' id='hoverTipRow_{0}_OnSite{1}'>", msaView.Id, et.Id);
								div.Append("<div class='hoverTipElements'>");
								div.AppendFormat("<input type='checkbox' id='chk_{0}_OnSite' value='{1}' class='hoverTipElementsCheckBox' checked='checked' />", msaView.Id, et.Id);
								div.AppendFormat("<span class='noteIndication'>{0}</span>", et.NameForUi);
								div.AppendFormat("<br/><select id='ddl_{0}_OnSite'>", msaView.Id);
								div.AppendFormat("<option value='{0}'>{1}</option>", -1, "-- adjust --");
								foreach (ExperienceType et2 in expOnSiteList)
								{
									div.AppendFormat("<option value='{0}'>{1}</option>", et2.Id, et2.NameForUi);
								}
								div.AppendFormat("</select>");
								div.Append("</div></div>");
							}
						}
						msaContent.Append(div);
					}

					if (resourcingContractualRequirements.GlobalProjectManagementRequirements != null)
					{
						msaContent.Append("<h3>Global Project Experience</h3>");
						msaContent.Append(RenderExpType(expAll, msaView, ExperienceType_E.GlobalProjectExperience, resourcingContractualRequirements.GlobalProjectManagementRequirements.GlobalProjectExperience));
					}

					msaView.HasData = true;
				}

			}

			containerDiv.Append(msaContent.ToString());
			containerDiv.Append("</div></div>");

			outerDiv.Append(containerDiv);

			projectExperienceDetails.MSAViewData = msaView;
			projectExperienceDetails.HtmlString = containerDiv.ToString();
			projectExperienceDetailsList.Add(projectExperienceDetails);
		}

		private static String RenderExpType(ExperienceType[] expAll, MSAView_WS msaView, ExperienceType_E expTypeE, int? expTypeValue)
		{
			StringBuilder div = new StringBuilder();
			if (expTypeValue != null)
			{
				ExperienceType expType = expAll.First(et => et.Id == (int)expTypeE);
				string[] options = expType.RangeValues.Split('|');
				string selectedOption = options[(int)expTypeValue];
				div.AppendFormat("<div class='hoverTipRow' id='hoverTipRow_{0}_exp{1}'>", msaView.Id, (int)expTypeE);
				div.Append("<div class='hoverTipElements'>");
				div.AppendFormat("<input type='checkbox' id='chk_{0}_exp{1}' class='hoverTipElementsCheckBox' checked='checked' projectId='{2}'  />", msaView.Id, (int)expTypeE, msaView.ProjectId);
				div.AppendFormat("<span class='noteIndication'>{0}</span>", expType.NameForUi);
				div.AppendFormat("<span class='noteMsaDefined'>{0}</span>", selectedOption);
				div.AppendFormat("<select id='ddl_{0}_exp{1}' class='hoverTipElementsGPE'>", msaView.Id, (int)expTypeE);
				div.AppendFormat("<option value='{0}'>{1}</option>", -1, "-- adjust --");
				for (int i = 0; i < options.Length; i++)
				{
					div.AppendFormat("<option value='{0}'>{1}</option>", i, options[i]);
				}
				div.AppendFormat("</select>");
				div.Append("</div></div>");
			}
			return div.ToString();
		}
		private static ResourcingContractualRequirements GetContractualRequirements(int projectJobRoleId, List<int> resourceTypeList)
		{
			ResourcingContractualRequirements resourcingContractualRequirements = new ResourcingContractualRequirements();
			resourcingContractualRequirements.HasRequirements = false;

			IList<ProjectJobRoleExperienceCriteria> otherExperience = ProjectJobRoleExperienceCriteria.FindByProjectRoleIdAndRequirementTypeIdAndExperienceCategoryId(projectJobRoleId, RequirementType_E.Contractual, ExperienceCategory_E.Other, resourceTypeList);
			IList<ProjectJobRoleExperienceCriteria> monitoringExperience = ProjectJobRoleExperienceCriteria.FindByProjectRoleIdAndRequirementTypeIdAndExperienceCategoryId(projectJobRoleId, RequirementType_E.Contractual, ExperienceCategory_E.MonitoringExperience, resourceTypeList);
			IList<ProjectJobRoleExperienceCriteria> globalProjectManagementExperience = ProjectJobRoleExperienceCriteria.FindByProjectRoleIdAndRequirementTypeIdAndExperienceCategoryId(projectJobRoleId, RequirementType_E.Contractual, ExperienceCategory_E.GlobalProjectExperience, resourceTypeList);

			resourcingContractualRequirements.TherapeuticIndicationRequirements = ProjectJobRoleExperienceCriteria.FindByProjectRoleIdAndRequirementTypeIdAndExperienceCategoryId(projectJobRoleId, RequirementType_E.Contractual, ExperienceCategory_E.TherapeuticAreaIndication, resourceTypeList);
			resourcingContractualRequirements.MonitoringRequirements = monitoringExperience.Count() > 0 ? monitoringExperience[0] : null;
			resourcingContractualRequirements.GlobalProjectManagementRequirements = globalProjectManagementExperience.Count() > 0 ? globalProjectManagementExperience[0] : null;
			resourcingContractualRequirements.OtherRequirements = otherExperience.Count() > 0 ? otherExperience[0] : null;
			if (resourcingContractualRequirements.TherapeuticIndicationRequirements.Count() > 0 || resourcingContractualRequirements.MonitoringRequirements != null || resourcingContractualRequirements.GlobalProjectManagementRequirements != null || resourcingContractualRequirements.OtherRequirements != null)
			{
				resourcingContractualRequirements.HasRequirements = true;
			}
			return resourcingContractualRequirements;
		}

		public static PagedResponse<GridProjectJobRoleExperienceCriteria_WS, GridRowCommonData> GetReadOnlyResourcingRequirements(int projectId, int jobRoleId)
		{
			var projectJobRoleExperienceCriteriaList = new List<GridProjectJobRoleExperienceCriteria_WS>();
			var lstProjJobRoles = new List<ProjectJobRoleGroup>(ProjectJobRoleGroup.FindByProjectId(projectId));


			using (var dr = DbHelp.ExecuteDataReaderSP("ResourceRequirements_GetDetails", new SqlParameter("projectId", projectId)))
			{
				ColumnChecker cc = null;
				try
				{
					while (dr.Read())
					{
						if (cc == null) { cc = new ColumnChecker(dr); }
						var results = dr["jobRoleIds"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
						if (results.Contains(jobRoleId.ToString()))
						{
							GridProjectJobRoleExperienceCriteria_WS projectJobRoleExperienceCriteria = new GridProjectJobRoleExperienceCriteria_WS
							{
								JobRole = DbSafe.StringValue(dr["JobRole"]),
								AppliesTo = DbSafe.StringValue(dr["AppliesTo"]),
								ResourceRequirementType = DbSafe.StringValue(dr["ResourceRequirementType"]),
								ExperienceCategory = DbSafe.StringValue(dr["ExperienceCategory"]),
								Experience = DbSafe.StringValue(dr["Experience"]),
								ProjectJobRoleExperienceCriteriaId = DbSafe.Int(dr["ProjectJobRoleExperienceCriteriaId"]),
								JobRoleId = DbSafe.Int(dr["JobRoleId"])
							};

							if (lstProjJobRoles != null)
							{
								var objMatchingJobRole = (projectJobRoleExperienceCriteria.JobRole == JobRoleGroupName_E.CRA.ToString()) ? lstProjJobRoles.Find(jr => jr.JobRoleGroupId == (int)JobRoleGroupName_E.CRA) : lstProjJobRoles.Find(jr => jr.JobRoleGroupId == (int)JobRoleGroupName_E.ProjectLeadership);
								if (objMatchingJobRole != null)
								{
									projectJobRoleExperienceCriteria.Notes = objMatchingJobRole.ContractualNotes;
								}
							}
							projectJobRoleExperienceCriteriaList.Add(projectJobRoleExperienceCriteria);
						}
					}
				}
				finally { dr.Close(); }
			}

			var pr = new PagedResponse<GridProjectJobRoleExperienceCriteria_WS, GridRowCommonData>();
			pr.Records = projectJobRoleExperienceCriteriaList;
			pr.TotalPages = 1;
			pr.TotalRecords = projectJobRoleExperienceCriteriaList.Count;
			pr.PageNumber = pr.TotalRecords == 0 ? 0 : 1;
			return pr;
		}
	}
	/// <summary>
	/// Retrieve data for Project Resourcing requests Resource type
	/// </summary>
	/// <author>Mithun M</author>
	[Serializable]
	[ActiveRecord(Table = "ResourceRequirements_ExperienceCriteriaResouceTypeGroup_XREF")]
	public class ProjectResourceTypeData : AbstractActiveRecordBaseModel<ProjectResourceTypeData>
	{
		[PrimaryKey(Column = "ResourceRequirementsResouceTypeId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property(Column = "ProjectJobRoleExperienceCriteriaId")]
		public int ProjectJobRoleExperienceCriteriaId { get; set; }

		[Property]
		public int ResourceRequirementsResouceTypeGroupId { get; set; }
	}

	public class ResourcingContractualRequirements
	{
		public IList<ProjectJobRoleExperienceCriteria> TherapeuticIndicationRequirements { get; set; }
		public ProjectJobRoleExperienceCriteria MonitoringRequirements { get; set; }
		public ProjectJobRoleExperienceCriteria GlobalProjectManagementRequirements { get; set; }
		public ProjectJobRoleExperienceCriteria OtherRequirements { get; set; }
		public bool HasRequirements { get; set; }
	}

}
