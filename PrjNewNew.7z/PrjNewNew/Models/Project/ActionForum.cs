﻿using System;
using System.Collections.Generic;
using System.Text;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Notification;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum ActionForum_E
	{
		Fpr_Focused_Project_Review = 1,
		Mpr_Tier_A,
		Mpr_Tier_B,
		Sgr_Stage_Gate_Review_1,
		Sgr_Stage_Gate_Review_2,
		Sgr_Stage_Gate_Review_3,
		Sgr_Stage_Gate_Review_4a,
		Sgr_Stage_Gate_Review_4b,
		Sgr_Stage_Gate_Review_4c,
		Sgr_Stage_Gate_Review_4n,
		Sgr_Stage_Gate_Review_5,
		Sgr_Stage_Gate_Review_Wild_Card_1,
		Sgr_Stage_Gate_Review_Wild_Card_2,
		Sgr_Stage_Gate_Review_Wild_Card_3,
		Sgr_Stage_Gate_Review_Wild_Card_4,
		Sgr_Stage_Gate_Review_Wild_Card_5,
		Other,
		MPR_1,
		MPR_2,
		MPR_3,
		Award_Briefing_Meeting,
		Customer_Expectation_Meeting,
		Customer_Meeting,
		Internal_Planning_Meeting,
		Kick_Off_Meeting,
		Project_Team_Meeting,
		Steering_Committee_Meeting
	}

	[ActiveRecord(Table = "ActionForum")]
	public class ActionForum : AbstractActiveRecordBaseModel<ActionForum>, ICodeTable
	{
		[PrimaryKey(Column = "ActionForumId")]
		public override int Id { get; set; }
		[Property]
		public string Name { get; set; }
		[Property]
		public bool IsOther { get; set; }
	}
}
