﻿using System;
using System.Linq;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum ProjectReviewOutcomeType_E
	{
		FPR_Tier_A_Escalated = 1,
		FPR_Tier_A_Unresolved,
		FPR_In_Escalation,
		FPR_Delivery_Risk,
		FPR_Safety_Risk,
		FPR_Financial_Risk,
		FPR_Regulatory_Risk,
		MPR_Tier_A_Red_LPI,
		MPR_Tier_A_No_Improvement_At_Tier_B,
		MPR_Tier_A_Customer_Score,
		MPR_Tier_A_Unsigned,
		MPR_Tier_A_Financial_Concession,
		MPR_Tier_A_RegQuality_Issue,
		MPR_Tier_A__Customer_Issue,
		MPR_Tier_B_RedAmber_Start_Up,
		MPR_Tier_B_Watch_Project,
		MPR_Tier_B_Amber_LPI,
		MPR_Tier_B_CRR_Red,
		MPR_Tier_B_LT50Pct_CM,
		MPR_Tier_B_Backlog_Miss,
		MPR_Tier_B_Quality,
		SGR_Approved,
		SGR_Approved_With_Conditions,
		SGR_Not_Approved
	}

	[ActiveRecord(Table = "ProjectReviewOutcomeType")]
	public class ProjectReviewOutcomeType : AbstractActiveRecordBaseModel<ProjectReviewOutcomeType>, ICodeTable
	{
		[PrimaryKey(Column = "ProjectReviewOutcomeTypeId")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }

		[Property]
		public bool ActionItemNeeded { get; set; }

		public ProjectReviewOutcomeType_E ProjectReviewOutcomeTypeEnum { get { return (ProjectReviewOutcomeType_E)Id; } }

		public static int GetIdFromName(string name)
		{
			var projecrReviewOutcomeType = CacheService.ProjectReviewOutcomeTypes.Values.Where(prot => string.Equals(prot.Name, name, System.StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
			if (projecrReviewOutcomeType == null)
			{
				throw new Exception(string.Format("Project Review Outcome Type name [{0}] is not configured in RM", name));
			}
			return projecrReviewOutcomeType.Id;
		}
	}
}
