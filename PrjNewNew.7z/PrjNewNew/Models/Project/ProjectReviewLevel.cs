﻿using System;
using System.Linq;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum ProjectReviewLevel_E
	{
		Fpr_Focused_Project_Review = 1,
		Mpr_Tier_A,
		Mpr_Tier_B,
		Sgr_Stage_Gate_Review_1,
		Sgr_Stage_Gate_Review_2,
		Sgr_Stage_Gate_Review_3,
		Sgr_Stage_Gate_Review_4a,
		Sgr_Stage_Gate_Review_4b,
		Sgr_Stage_Gate_Review_4c,
		Sgr_Stage_Gate_Review_4n,
		Sgr_Stage_Gate_Review_5,
		Sgr_Stage_Gate_Review_Wild_Card_1,
		Sgr_Stage_Gate_Review_Wild_Card_2,
		Sgr_Stage_Gate_Review_Wild_Card_3,
		Sgr_Stage_Gate_Review_Wild_Card_4,
		Sgr_Stage_Gate_Review_Wild_Card_5,
		Other
	}
	[ActiveRecord(Table = "ProjectReviewLevel")]
	public class ProjectReviewLevel : AbstractActiveRecordBaseModel<ProjectReviewLevel>, ICodeTable
	{
		[PrimaryKey(Column = "ProjectReviewLevelId")]
		public override int Id { get; set; }
		[Property]
		public string Name { get; set; }
		[Property]
		public bool IsOther { get; set; }

		public ProjectReviewLevel_E ProjectReviewLevelEnum { get { return (ProjectReviewLevel_E)Id; } }

		public static int GetIdFromName(string name)
		{
			var projectReviewLevel = CacheService.ProjectReviewLevels.Values.Where(prl => string.Equals(prl.Name, name, System.StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
			if (projectReviewLevel == null)
			{
				throw new Exception(string.Format("Project Review Level name [{0}] is not mapped in RM", name));
			}
			return projectReviewLevel.Id;
		}
	}
}
