﻿using Castle.ActiveRecord;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;


namespace Quintiles.RM.Clinical.Domain.Models
{
    [ActiveRecord(Table = "ProjectPenaltyOrBonus_XREF")]
    public class ProjectPenaltyOrBonus : AbstractActiveRecordBaseModel<ProjectPenaltyOrBonus>, IEquatable<ProjectPenaltyOrBonus>
    {
        public ProjectPenaltyOrBonus()
            : base()
        {
            PenaltyOrBonus = new PenaltyOrBonus();
            Project = new Project();
        }

        [PrimaryKey(Column = "ProjectPenaltyOrBonusId", UnsavedValue = "-1")]
        public override int Id { get; set; }

        [BelongsTo("PenaltyOrBonusIdId")]
        public PenaltyOrBonus PenaltyOrBonus { get; set; }

        [BelongsTo("ProjectId")]
        public Project Project { get; set; }

        public static string GetCommaSeparatedPenaltyOrBonusByProjectId(int projectId)
        {
            string CommaSeparatedPenaltyOrBonusByProjectIdSql = string.Format(@"SELECT STUFF((SELECT  ', ' + [Name] FROM  (SELECT  PB.Name FROM PenaltyOrBonus PB JOIN ProjectPenaltyOrBonus_XREF PPBX ON PPBX.PenaltyOrBonusId = PB.PenaltyOrBonusId WHERE PPBX.ProjectId={0}) AS T FOR XML PATH('')),1,1,'') AS [Name]", projectId);
            return DbHelp.ExecuteScalarText(CommaSeparatedPenaltyOrBonusByProjectIdSql).ToString();
        }
        public bool Equals(ProjectPenaltyOrBonus other)
        {
            throw new NotImplementedException();
        }
        bool IEquatable<ProjectPenaltyOrBonus>.Equals(ProjectPenaltyOrBonus other)
        {
            throw new NotImplementedException();
        }
    }
}
