﻿using System.Collections.Generic;
using System.Data.SqlClient;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ProjectBackroundDetails")]
	public class ProjectBackroundDetails : AbstractActiveRecordBaseModel<ProjectBackroundDetails>
	{
		[PrimaryKey(Column = "ID", UnsavedValue = "-1")]
		public override int Id { get; set; }
		[Property]
		public string FieldValue { get; set; }
		[Property]
		public int ProjectId { get; set; }
		[Property]
		public string ExternalId { get; set; }
		[Property]
		public int ProjectSummaryConfigurationId { get; set; }

		public string DisplayLabel { get; set; }
		public string OrganizationTypeName { get; set; }
		public OrganizationType_E OrganizationType { get; set; }

		public static Dictionary<string, Dictionary<string, List<ProjectBackroundDetails>>> FindByProjectId(int projectId)
		{
			var projectBackroundDetails = new Dictionary<string, Dictionary<string, List<ProjectBackroundDetails>>>();

			string sqlQuery = string.Format(@"SELECT  PBD.ID ,
        PSC.FieldName ,
        PBD.FieldValue ,
        PSC.DisplayLabel,
        PSC.OrganizationTypeId ,
        PBD.ProjectId ,
        OT.Name AS OrganizationTypeName ,
        PBD.ExternalId
FROM    dbo.ProjectSummaryConfiguration PSC
        JOIN dbo.ProjectBackroundDetails PBD ON PBD.ProjectSummaryConfigurationId = PSC.Id
        JOIN dbo.OrganizationType OT ON PSC.OrganizationTypeId = OT.OrganizationTypeId
WHERE   ProjectId = {0}
ORDER BY PBD.OrganizationTypeId ,
        PBD.ExternalId ,
        ISNULL(PSC.DisplayOrder, 9999);", projectId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						Dictionary<string, List<ProjectBackroundDetails>> projectList;
						List<ProjectBackroundDetails> fieldList;

						var externalId = DbSafe.StringValue(dr["ExternalId"]);
						var organizationTypeName = DbSafe.StringValue(dr["OrganizationTypeName"]);

						if (!projectBackroundDetails.TryGetValue(organizationTypeName, out projectList))
						{
							projectList = new Dictionary<string, List<ProjectBackroundDetails>>();
							projectBackroundDetails.Add(organizationTypeName, projectList);
						}

						if (!projectList.TryGetValue(externalId, out fieldList))
						{
							fieldList = new List<ProjectBackroundDetails>();
							projectList.Add(externalId, fieldList);
						}

						fieldList.Add(new ProjectBackroundDetails
						{
							Id = DbSafe.Int(dr["ID"]),
							FieldValue = DbSafe.StringValue(dr["FieldValue"]),
							DisplayLabel = DbSafe.StringValue(dr["DisplayLabel"]),
							OrganizationType = (OrganizationType_E)DbSafe.Int(dr["OrganizationTypeId"]),
							ProjectId = DbSafe.Int(dr["ProjectId"]),
							OrganizationTypeName = organizationTypeName
						});
					}
				}
				finally { dr.Close(); }
			}

			return projectBackroundDetails;
		}

		public static void DeleteProjectDetailsByExternalId(string externalId)
		{
			DbHelp.ExecuteNonQueryText("DELETE FROM ProjectBackroundDetails WHERE ExternalId = @externalId", new SqlParameter("ExternalId", externalId));
		}
	}
}
