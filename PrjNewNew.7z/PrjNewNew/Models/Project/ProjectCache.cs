﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class ProjectCache : AbstractActiveRecordBaseModel<ProjectCache>
	{
		[PrimaryKey(Column = "ProjectCacheId", Generator = PrimaryKeyType.Assigned)]
		public override int Id { set; get; }

		[Property(Column = "OpportunityNumber")]
		public string Name { set; get; }

		[Property]
		public string ProtocolNumber { set; get; }

		[Property]
		public string OpportunityNumber_ProtocolNumber { set; get; }

		[Property]
		public int? ProjectStageId { get; set; }

		[Property]
		public int? WinProbabilityId { get; set; }


		[Property]
		public bool IsProposal { set; get; }

		[Property]
		public bool IsClosed { set; get; }

		/// <summary>
		/// Get all type ahead project codes from cache
		/// </summary>
		/// <returns></returns>
		public new static IList<ProjectCache> FindAll()
		{
			throw new NotSupportedException("Do not use this method. Use GetProposalProjectList instead.");
		}

		public static List<string> GetTypeAheadString()
		{
			var projectCacheList = ProjectCache.GetProposalProjectList();
			return projectCacheList.Select(pp => pp.OpportunityNumber_ProtocolNumber).ToList();
		}

		internal static List<ProjectCache> GetProposalProjectList()
		{
			return CacheService.ProjectCacheList;
		}

		internal static List<ProjectCache> GetProposalProjectListFromDb()
		{
			var proposalProjectList = new List<ProjectCache>();

			var sql = string.Format(@"SELECT  PC.ProjectCacheId, PC.OpportunityNumber, PC.ProtocolNumber, PC.OpportunityNumber_ProtocolNumber,
																				PC.ProjectStageId, PC.WinProbabilityId, PC.IsProposal, PC.IsClosed
																FROM    dbo.ProjectCache PC
																				JOIN dbo.ProjectStage_OpportunityStatus_xref PSOX ON PC.ProjectStageId = PSOX.ProjectStageId
																				JOIN dbo.ProjectStage PS ON PS.ProjectStageId = PC.ProjectStageId
																WHERE   OpportunityStatusId != {0}
																				AND ( IsProposal = 1 OR PC.ProjectStageId = 1 )
																				AND PS.AllowProposalRequestCreation = 1
																				AND IsClosed = 0", (int)OpportunityStatus_E.Closed_Lost);

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						proposalProjectList.Add(new ProjectCache
						{
							Id = DbSafe.Int(dr["ProjectCacheId"]),
							Name = DbSafe.StringValue(dr["OpportunityNumber"]),
							ProtocolNumber = DbSafe.StringValue(dr["ProtocolNumber"]),
							OpportunityNumber_ProtocolNumber = DbSafe.StringValue(dr["OpportunityNumber_ProtocolNumber"]),
							ProjectStageId = DbSafe.Int(dr["ProjectStageId"]),
							WinProbabilityId = DbSafe.Int(dr["WinProbabilityId"]),
							IsProposal = DbSafe.Bool(dr["IsProposal"]),
							IsClosed = DbSafe.Bool(dr["IsClosed"])
						});
					}
				}
				finally { dr.Close(); }
			}

			return proposalProjectList;
		}
	}
}
