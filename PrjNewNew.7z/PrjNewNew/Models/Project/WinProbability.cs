﻿using System.Collections.Generic;
using System.Linq;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class WinProbability : AbstractActiveRecordBaseModel<WinProbability>, ICodeTable
	{
		[PrimaryKey(Column = "WinProbabilityId", UnsavedValue = "-1")]
		public override int Id { get; set; }
		[Property]
		public string Name { get; set; }
		[Property]
		public decimal CrmName { get; set; }

		/// <summary>
		/// Get StudyPhase from cache (convenience method)
		/// </summary>
		/// <returns></returns>
		public new static IList<WinProbability> FindAll()
		{
			Dictionary<int, WinProbability> dict = CacheService.WinProbabilities;
			return dict.Values.ToList();
		}
	}
}
