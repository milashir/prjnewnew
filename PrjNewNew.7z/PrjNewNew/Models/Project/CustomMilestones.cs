﻿using System;
using System.Collections.Generic;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RPM.Common;
namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "CustomMilestones")]
	public class CustomMilestones : AbstractActiveRecordBaseModel<CustomMilestones>
	{
		[PrimaryKey(Column = "CustomMilestoneId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public string Description { get; set; }

		[Property]
		public DateTime? MilestoneDate { get; set; }

		[Property]
		public int OrganizationalUnitId { get; set; }

		[Property]
		public int IsActive { get; set; }

		public string OrganizationalUnitName { get; set; }

		public static int GetProjectId(int customMilestoneId)
		{
			return (int)DbHelp.ExecuteScalarText(string.Format("Select ProjectId from [dbo].[CustomMilestones] where CustomMilestoneId = {0}", customMilestoneId));
		}

		public static bool DeleteCustommilestone(string milestoneIds)
		{
			DbHelp.ExecuteNonQueryText(string.Format(@"Update dbo.CustomMilestones set IsActive='0' WHERE CustomMilestoneId IN({0})", milestoneIds));
			return true;
		}

		public static CustomMilestones FindByProjectIdAndMilestoneName(int projectId, string milestoneName, int orgId)
		{
			var criteria = DetachedCriteria.For(typeof(CustomMilestones));
			criteria.Add(Restrictions.Eq("ProjectId", projectId));
			criteria.Add(Restrictions.Eq("Name", milestoneName));
			criteria.Add(Restrictions.Eq("OrganizationalUnitId", orgId));
			criteria.Add(Restrictions.Eq("IsActive", 1));
			CustomMilestones milestone = FindOne(criteria);
			return milestone;
		}

		public static PagedResponse<CustomMilestones, GridRowCommonData> FindAllCustomMilestone(GridSearchCustomMilestone_WS gridSearch)
		{
			var pr = new PagedResponse<CustomMilestones, GridRowCommonData> { Records = new List<CustomMilestones>() };
			var orderBy = string.IsNullOrEmpty(gridSearch.OrderBy) ?
													string.Empty :
													string.Format(" ORDER BY {0} {1}",
																					gridSearch.OrderBy.ToLower() == "milestonename" ? "CM.Name" :
																										gridSearch.OrderBy.ToLower() == "milestonedate" ? "CM.MilestoneDate" :
																										gridSearch.OrderBy.ToLower() == "organizationalunitname" ? "OU.Name" : "OU.Name",
																					gridSearch.SortOrder);

			var sql = string.Format(@"SELECT  CM.CustomMilestoneId ,
																				CM.Name ,
																				CM.MilestoneDate ,
																				CM.OrganizationalUnitId ,
																				CM.ProjectId,
																				OU.Name AS OrganizationalUnitName
																FROM    dbo.CustomMilestones CM
																JOIN dbo.OrganizationalUnit OU ON OU.OrganizationalUnitId = CM.OrganizationalUnitId
																WHERE   IsActive = 1
																				AND ProjectId = {0} {1} {2} {3}
																{4}",
																gridSearch.ProjectId,
																string.IsNullOrEmpty(gridSearch.Name) ? string.Empty : string.Format(" AND CM.Name LIKE '{0}%'", DbSafe.EscapeQuote(gridSearch.Name)),
																string.IsNullOrEmpty(gridSearch.MilestoneDate) ? string.Empty : string.Format(" AND dbo.ufn_GetDateAsString(CM.MilestoneDate) LIKE '{0}%'", DbSafe.EscapeQuote(gridSearch.MilestoneDate)),
																string.IsNullOrEmpty(gridSearch.OrganizationalUnitName) ? string.Empty : string.Format(" AND OU.Name LIKE '{0}%'", DbSafe.EscapeQuote(gridSearch.OrganizationalUnitName)),
																orderBy);

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						pr.Records.Add(new CustomMilestones
						{
							Id = DbSafe.Int(dr["CustomMilestoneId"]),
							ProjectId = DbSafe.Int(dr["ProjectId"]),
							OrganizationalUnitId = DbSafe.Int(dr["OrganizationalUnitId"]),
							Name = DbSafe.StringValue(dr["Name"]),
							MilestoneDate = DbSafe.DateTimeNull(dr["MilestoneDate"]),
							OrganizationalUnitName = DbSafe.StringValue(dr["OrganizationalUnitName"])
						});
					}
				}
				finally { dr.Close(); }
			}

			return pr;
		}

		public static void UpdateCustomMilestones(List<CustomMilestones_WS> customMilestones, AddMilestoneStatus_WS result)
		{
			if (customMilestones != null && customMilestones.Count > 0)
			{
				foreach (var customMilestone in customMilestones)
				{
					var existingCustomMilestones = CustomMilestones.FindOneByProperty("Id", customMilestone.CustomMilestoneId);

					if (existingCustomMilestones != null)
					{
						existingCustomMilestones.MilestoneDate = customMilestone.MilestoneDate.ToDateFromQDateString();
						existingCustomMilestones.Name = customMilestone.Name;
						existingCustomMilestones.UpdateAndFlush();

						// Cascade custom milestones
						GenericInitiateCalculator.CascadeMilestonesToRequestAndGenericCalculators(existingCustomMilestones.Id, existingCustomMilestones.ProjectId, GenericMilestoneType_E.Custom, existingCustomMilestones.MilestoneDate);
					}
					else
					{
						CustomMilestones cust = new CustomMilestones
						{
							ProjectId = customMilestone.ProjectId,
							OrganizationalUnitId = customMilestone.OrganizationalUnitId,
							MilestoneDate = customMilestone.MilestoneDate.ToDateFromQDateString(),
							Name = customMilestone.Name,
							Description = customMilestone.Description,
							OrganizationalUnitName = CacheService.OrganizationalUnit(customMilestone.OrganizationalUnitId).Name,
							IsActive = 1
						};
						cust.SaveAndFlush();
						result.RowJson = new CustomMilestoneRowData(cust);
						result.JsonString = cust.Id.ToString();
					}
				}
			}
		}
	}
}
