﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class ProjectCustomField : AbstractActiveRecordBaseModel<ProjectCustomField>
	{
		[PrimaryKey(Column = "ProjectCustomFieldId", UnsavedValue = "-1")]
		public override int Id { get; set; }
		[Property]
		public int ProjectId { get; set; }
		[Property]
		public int CustomFieldId { get; set; }
		[Property]
		public string Value { get; set; }

		private CustomField _customField = null;
		public CustomField CustomField
		{
			get
			{
				if (_customField == null)
				{
					CacheService.CustomFields.TryGetValue(CustomFieldId, out _customField);
				}
				return _customField;
			}
		}

		public static ProjectCustomField FindByProjectIdAndCustomFieldId(int projectId, CustomField_E customFieldId)
		{
			ProjectCustomField projectCustomField = null;

			var sql = string.Format(
			@"SELECT  PSF.CustomFieldId ,
								PSF.ProjectCustomFieldId ,
								PSF.ProjectId AS ProjectId ,
								PSF.Value ,
								PSF.CreatedBy ,
								PSF.CreatedOn ,
								PSF.LastModifiedBy ,
								PSF.LastModifiedOn
				FROM    dbo.ProjectCustomField PSF
				WHERE PSF.ProjectId = {0}
							AND PSF.CustomFieldId = {1}",
				projectId,
				(int)customFieldId);

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					if (dr.Read()) { projectCustomField = ProjectCustomField.CreateFromReader(dr); }
				}
				catch (Exception ex) { Logger.Instance.Error(ex); }
				finally { dr.Close(); }
			}

			return projectCustomField;
		}

		public static List<ProjectCustomField> GetByProjectId(int projectId)
		{
			var projectCustomFields = new List<ProjectCustomField>();
			var sql =
			@"SELECT  CF.CustomFieldId ,
							PSF.ProjectCustomFieldId ,
							@ProjectId AS ProjectId ,
							PSF.Value ,
							PSF.CreatedBy ,
							PSF.CreatedOn ,
							PSF.LastModifiedBy ,
							PSF.LastModifiedOn
			FROM    dbo.CustomField CF
							LEFT JOIN dbo.ProjectCustomField PSF ON CF.CustomFieldId = PSF.CustomfieldId
																											AND PSF.ProjectId = @ProjectId
			WHERE CF.IsProjectCustomField = 1
			ORDER BY CF.ProjectFieldOrderBy";

			using (var dr = DbHelp.ExecuteDataReaderText(sql, new SqlParameter("ProjectId", projectId)))
			{
				try
				{
					while (dr.Read()) { projectCustomFields.Add(ProjectCustomField.CreateFromReader(dr)); }
				}
				catch (Exception ex) { Logger.Instance.Error(ex); }
				finally { dr.Close(); }
			}

			return projectCustomFields;
		}

		public static ProjectCustomField CreateFromReader(IDataReader dr)
		{
			return new ProjectCustomField
			{
				Id = DbSafe.Int(dr["ProjectCustomFieldId"], -1),
				Value = DbSafe.StringValue(dr["value"]),
				ProjectId = DbSafe.Int(dr["ProjectId"]),
				CustomFieldId = DbSafe.Int(dr["CustomFieldId"]),
				CreatedBy = DbSafe.StringValue(dr["CreatedBy"]),
				CreatedOn = DbSafe.DateTime(dr["CreatedOn"], DateTime.Now),
				LastModifiedBy = DbSafe.StringValue(dr["LastModifiedBy"]),
				LastModifiedOn = DbSafe.DateTime(dr["LastModifiedOn"], DateTime.Now)
			};
		}


		internal static void UpdateFields(List<ProjectCustomField_WS> customFieldList)
		{
			foreach (var customField in customFieldList)
			{
				if (customField.Id <= 0)
				{
					var pcf = new ProjectCustomField
					{
						ProjectId = customField.ProjectId,
						Value = customField.Value,
						CustomFieldId = customField.CustomFieldId
					};
					pcf.SaveAndFlush();

					customField.Id = pcf.Id;
				}
				else
				{
					var field = ProjectCustomField.Find(customField.Id);
					field.Value = customField.Value;
					field.SaveAndFlush();
				}
			}
		}
	}
}
