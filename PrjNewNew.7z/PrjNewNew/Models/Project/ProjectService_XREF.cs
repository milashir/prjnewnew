﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
namespace Quintiles.RM.Clinical.Domain.Models
{
    [ActiveRecord(Table = "ProjectService_XREF")]
	public class ProjectService_XREF : AbstractActiveRecordBaseModel<ProjectService_XREF>
    {
        [PrimaryKey(Column = "ProjectServiceId", UnsavedValue = "-1")]
        public override int Id { set { this._id = value; } get { return this._id; } }

        [BelongsTo("ProjectId")]
        public virtual Project Project { set; get; }

        [BelongsTo("ServiceId")]
        public virtual Service Service { set; get; }

        public static IList<ProjectService_XREF> getMultipleServices(int projectId)
        {
            List<ProjectService_XREF> projectService;
            DetachedCriteria filter = DetachedCriteria.For(typeof(ProjectService_XREF));
            filter.Add(Expression.Eq("Project.Id", projectId));
            projectService = ProjectService_XREF.FindAll(filter).OrderBy(t => t.Id).ToList();
            return projectService;
        }
        public static List<MultiSelect_WS> getMultipleServicesByProjectId(int projectId)
        {
            List<MultiSelect_WS> serviceList = new List<MultiSelect_WS>();
            IList<Service> allServices = Service.FindAll();

            DetachedCriteria filter = DetachedCriteria.For(typeof(ProjectService_XREF));
            filter.Add(Expression.Eq("Project.Id", projectId));
            var projectServices = ProjectService_XREF.FindAll(filter);

            foreach (Service service in allServices)
            {
                MultiSelect_WS projectService = new MultiSelect_WS
                                {
                                    key = service.Id,
                                    value = service.Name,
                                    isChecked = (projectServices.FirstOrDefault(ps => ps.Service.Id == service.Id) != null)
                                };

                projectService.wasOriginallyChecked = projectService.isChecked;
                serviceList.Add(projectService);
            }
            serviceList.Sort();
            return serviceList;
        }


        #region DmlOperationsOnProjectService_XREF
        internal static void DmlOperationsOnProjectService_XREF(List<MultiSelect_WS> projectServicesList, int projectId)
        {
            try
            {
                if (projectServicesList != null && projectServicesList.Count > 0)
                {
                    #region Delete OnProjectService_XREF
                    string ProjectService_XREFToDelete = null;
                    projectServicesList.ForEach(i =>
                    {
                        if (i.dmlOperation == DMLOperation_E.Delete)
                        {
                            ProjectService_XREFToDelete += "," + i.key;
                        }
                    });

                    if (!string.IsNullOrEmpty(ProjectService_XREFToDelete))
                    {
                        ProjectService_XREFToDelete = ProjectService_XREFToDelete.Substring(1);
                        ProjectService_XREF.DeleteAll(string.Format("ProjectId ={0} and ServiceId in({1})", projectId, ProjectService_XREFToDelete));
                    }

                    #endregion

                    foreach (var projectService in projectServicesList)
                    {
                        if (projectService.dmlOperation == DMLOperation_E.Insert)
                        {
                            new ProjectService_XREF
                            {
                                Project = new Project { Id = projectId },
                                Service = new Service { Id = projectService.key }
                            }.SaveAndFlush();
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}

