﻿using System;
using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ProjectReviewItem")]
	public class ProjectReviewItem : AbstractActiveRecordBaseModel<ProjectReviewItem>
	{
		[PrimaryKey(Column = "ProjectReviewItemId")]
		public override int Id { get; set; }
		[BelongsTo("ProjectId")]
		public Project Project { get; set; }
		[Property]
		public string ExternalId { get; set; }
		[Property]
		public int ProjectReviewLevelId { get; set; }
		[Property]
		public DateTime DateOfReview { get; set; }
		[Property]
		public string ReviewChair { get; set; }
		[Property]
		public string ReviewChairQid { get; set; }
		[BelongsTo("ProjectReviewOutcomeTypeId")]
		public ProjectReviewOutcomeType ProjectReviewOutcomeType { get; set; }
		[Property]
		public string ProjectReviewOutcomeDetails { get; set; }
		[Property]
		public bool? IncludeInReporting { get; set; }
		[Property]
		public bool? ComprehensiveRiskAssessedInPPM { get; set; }
		[Property]
		public bool? ExecutedFullWorkOrder { get; set; }
		[Property]
		public bool? ProjectScheduleContractBaselinedInPpm { get; set; }
		[Property]
		public bool? RevisedIppmExecSumProjExecPlanAndKeyRef { get; set; }
		[Property]
		public bool? AgreedUponThresholdsAndCadenceForAlertsAndTriggers { get; set; }
	}
}
