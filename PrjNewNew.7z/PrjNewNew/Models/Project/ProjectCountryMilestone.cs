using System;
using System.Collections.Generic;
using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// Project to ProjectMilestone mapping, includes Projected/Actual/Contracted dates
	/// </summary>
	[ActiveRecord(Table = "ProjectCountryMilestone_XREF")]
	public class ProjectCountryMilestone : AbstractActiveRecordBaseModel<ProjectCountryMilestone>, IEquatable<ProjectCountryMilestone>
	{
		[PrimaryKey(Column = "ProjectCountryMilestoneId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ProjectId { get; set; }
		[Property]
		public int CountryId { get; set; }
		[Property]
		public int CountryMilestoneId { get; set; }
		[Property]
		public DateTime? ActualDate { get; set; }
		[Property]
		public string Comment { get; set; }
		[Property]
		public DateTime? ManualEntryDate { get; set; }
		[Property]
		public bool IsPpmMilestone { get; set; }
		[Property]
		public int? OrganizationalUnitId { get; set; }

		public DateTime? DateToCompare { get; set; }
		public bool Equals(ProjectCountryMilestone other)
		{
			return ((this.Id > 0 && other.Id > 0) && this.Id == other.Id);
		}

		public static ProjectCountryMilestone FindByProjectIdCountryIdAndMilestoneId(int projectId, int countryId, int milestoneId)
		{
			var criteria = DetachedCriteria.For(typeof(ProjectCountryMilestone));
			criteria.Add(Restrictions.Eq("ProjectId", projectId));
			criteria.Add(Restrictions.Eq("CountryId", countryId));
			criteria.Add(Restrictions.Eq("CountryMilestoneId", milestoneId));
			ProjectCountryMilestone milestone = FindOne(criteria);
			return milestone;
		}

		//internal static void SaveProjectCountryMilestones(List<ProjectCountryMilestone> updatedCountryMilestonesFromUi)
		//{
		//	if (updatedCountryMilestonesFromUi != null && updatedCountryMilestonesFromUi.Count > 0)
		//	{
		//		foreach (ProjectCountryMilestone updatedCountryMilestone in updatedCountryMilestonesFromUi)
		//		{
		//			ProjectCountryMilestone existingProjectCountryMilestones = ProjectCountryMilestone.FindByProjectIdCountryIdAndMilestoneId(updatedCountryMilestone.ProjectId, updatedCountryMilestone.CountryId, updatedCountryMilestone.CountryMilestoneId);

		//			if (existingProjectCountryMilestones != null)
		//			{
		//				if (updatedCountryMilestone.ActualDate != null && existingProjectCountryMilestones.ActualDate != updatedCountryMilestone.ActualDate)
		//				{
		//					existingProjectCountryMilestones.ActualDate = updatedCountryMilestone.ActualDate;
		//					existingProjectCountryMilestones.Comment = updatedCountryMilestone.Comment;
		//					existingProjectCountryMilestones.ManualEntryDate = updatedCountryMilestone.ActualDate;
		//					existingProjectCountryMilestones.UpdateAndFlush();

		//					var countryMilestone = CacheService.CountryMilestone.Values.FirstOrDefault(cm => cm.Id == updatedCountryMilestone.CountryMilestoneId);
		//					//UpdateRequestMilestoneDates(milestone.ProjectId, milestone.CountryId, milestone.CountryMilestoneId, milestone.ActualDate, countryMilestone.Attributekey);
		//					GenericInitiateCalculator.CascadeCountryMilestonesToRequestAndGenericCalculators(countryMilestone.Id, updatedCountryMilestone.ProjectId, updatedCountryMilestone.CountryId, countryMilestone.Attributekey, updatedCountryMilestone.ActualDate);
		//				}
		//				else if (updatedCountryMilestone.ActualDate == null)
		//				{
		//					existingProjectCountryMilestones.DeleteAndFlush();
		//				}
		//			}
		//			else
		//			{
		//				ProjectCountryMilestone newMilestone = new ProjectCountryMilestone
		//				{
		//					ProjectId = updatedCountryMilestone.ProjectId,
		//					CountryId = updatedCountryMilestone.CountryId,
		//					CountryMilestoneId = updatedCountryMilestone.CountryMilestoneId,
		//					ActualDate = updatedCountryMilestone.ActualDate,
		//					Comment = updatedCountryMilestone.Comment,
		//					ManualEntryDate = updatedCountryMilestone.ActualDate

		//				};
		//				newMilestone.SaveAndFlush();
		//			}
		//		}
		//	}
		//}

		//		public static void LockManualCountryMilestones(int projectId, int countryId, List<int> countryMilestoneIds)
		//		{
		//			var sql = string.Format(@"UPDATE ProjectCountryMilestone_XREF 
		//																SET		 Comment = NULL,
		//																			 LastModifiedOn = GETDATE(),
		//																			 LastModifiedBy = '{0}'
		//																WHERE	 ProjectId = {1} AND
		//																			 CountryId = {2} AND
		//																			 CountryMilestoneId IN ({3})",
		//															ExtensionMethods.GetCurrentUserQid(),
		//															projectId,
		//															countryId,
		//															string.Join(",", countryMilestoneIds.Select(var => var.ToString()).ToArray()));

		//			DbHelp.ExecuteNonQueryText(sql);
		//		}

		public static void CreateOrUpdateCountryMilestones(int projectId, int countryId, IEnumerable<CountryMilestoneData> milestoneList, bool isPpmMilestone)
		{
			if (milestoneList == null || milestoneList.Count() == 0)
			{
				DbHelp.ExecuteNonQueryText(string.Format("DELETE FROM dbo.ProjectCountryMilestone_XREF WHERE ProjectId ={0} AND CountryId = {1}", projectId, countryId));
			}
			else
			{
				var milestonesIdsToDelete = milestoneList.Where(cms => !cms.ActualDate.HasValue && !isPpmMilestone).Select(cms => cms.ProjectCountryMilestoneId).ToList();
				var milestonesToAddOrUpdate = milestoneList.Where(cms => cms.ActualDate.HasValue || isPpmMilestone).ToList();

				if (milestonesIdsToDelete.Count > 0)
				{
					ProjectCountryMilestone.DeleteAll(string.Format("ProjectCountryMilestoneId IN ({0})", string.Join(",", milestonesIdsToDelete.Select(id => id.ToString()).ToArray())));
				}

				if (milestonesToAddOrUpdate.Count > 0)
				{
					string sql;
					//ProjectId, CountryId, LastModifiedBy, LastModifiedOn, CreatedBy, CreatedOn, CountryMilestoneId, ProjectedDate, ContractedDate, ActualDate, Comment, isPpmMilestone
					var unionTemplate = string.Format("SELECT {0}, {1}, '{2}', GETDATE(), '{2}', GETDATE(), {{0}}, {{1}}, {{2}}, {{3}}, {{4}}, {{5}}",
																						projectId,
																						countryId,
																						ExtensionMethods.GetCurrentUserQid());
					var unionString = string.Empty;
					var union = string.Empty;
					foreach (var milestone in milestonesToAddOrUpdate)
					{
						unionString = string.Format("{0} {1} {2}",
							unionString,
							union,
							string.Format(unionTemplate,
							milestone.CountryMilestoneId,
							milestone.ProjectedDate.ToNullableDbDate(),
							milestone.ContractedDate.ToNullableDbDate(),
							milestone.ActualDate.ToNullableDbDate(),
							isPpmMilestone ? "NULL" : DbSafe.EscapeAndSurroundQuote(milestone.Comment),
							isPpmMilestone ? 1 : 0)
							);

						if (string.Empty.Equals(union)) { union = " UNION "; }
					}

					sql = string.Format(@";MERGE dbo.ProjectCountryMilestone_XREF TargetTbl
																 USING ( {0} ) AS SourceTbl ( ProjectId, CountryId, LastModifiedBy, LastModifiedOn, CreatedBy, CreatedOn, 
																															CountryMilestoneId, ProjectedDate, ContractedDate, ActualDate, Comment,
									 																						IsPpmMilestone )
																 ON SourceTbl.ProjectId = TargetTbl.ProjectId
									 									AND SourceTbl.CountryId = TargetTbl.CountryId
									 									AND SourceTbl.CountryMilestoneId = TargetTbl.CountryMilestoneId
																 WHEN MATCHED THEN
									 									UPDATE SET TargetTbl.ProjectedDate = SourceTbl.ProjectedDate ,
									 															TargetTbl.ContractedDate = SourceTbl.ContractedDate ,
									 															TargetTbl.ActualDate = SourceTbl.ActualDate ,
									 															TargetTbl.LastModifiedBy = SourceTbl.LastModifiedBy ,
									 															TargetTbl.LastModifiedOn = SourceTbl.LastModifiedOn ,
									 															TargetTbl.Comment = SourceTbl.Comment ,
									 															TargetTbl.ManualEntryDate = CASE WHEN SourceTbl.IsPpmMilestone = 1
																																											AND TargetTbl.IsPpmMilestone = 0
																																								 THEN COALESCE(TargetTbl.ActualDate,
																																															TargetTbl.ProjectedDate,
																																															TargetTbl.ContractedDate)
																																								 ELSE NULL
																																						END
																 WHEN NOT MATCHED BY TARGET THEN
									 									INSERT ( ProjectId ,
									 														CountryId ,
									 														CountryMilestoneId ,
									 														ProjectedDate ,
									 														ContractedDate ,
									 														ActualDate ,
									 														LastModifiedBy ,
									 														LastModifiedOn ,
									 														CreatedBy ,
									 														CreatedOn ,
									 														Comment ,
																							IsPpmMilestone
									 													)
									 									VALUES ( SourceTbl.ProjectId ,
									 														SourceTbl.CountryId ,
									 														SourceTbl.CountryMilestoneId ,
									 														SourceTbl.ProjectedDate ,
									 														SourceTbl.ContractedDate ,
									 														SourceTbl.ActualDate ,
									 														SourceTbl.LastModifiedBy ,
									 														SourceTbl.LastModifiedOn ,
									 														SourceTbl.CreatedBy ,
									 														SourceTbl.CreatedOn ,
									 														SourceTbl.Comment ,
																							SourceTbl.IsPpmMilestone 
									 													);",
																		 unionString);

					DbHelp.ExecuteNonQueryText(sql);
				}
			}
		}

		public static void CreateOrUpdateCountryMilestones(List<GridSearchCountryMilestone_WS> countryMilestonesFromUi, AddMilestoneStatus_WS result)
		{
			if (countryMilestonesFromUi != null && countryMilestonesFromUi.Count > 0)
			{
				int projectId = 0;
				var projectCountryMilestoneListToUpdate = new Dictionary<int, List<CountryMilestoneData>>();

				var updateSQL = string.Empty;
				foreach (var countryMilestone in countryMilestonesFromUi)
				{
					if (projectId != countryMilestone.ProjectId)
					{
						if (projectId == 0) { projectId = countryMilestone.ProjectId; }
						else { result.ValidationErrors.Add(new ValidationMessage_WS(string.Empty, "Cannot update milestones from more than one project at a time", Utilities.MessageType_E.SharepointNotification)); }
					}

					//UI sends -1 in ID and CountryMilestoneId when new country is getting added. Counteriuntutive approach but too late to change it without changing UI behavior.
					if (countryMilestone.Id == Constants.UnspecifiedId && countryMilestone.CountryMilestoneId == Constants.UnspecifiedId)
					{
						CreateNewCountryMilestone(countryMilestone);
					}
					else
					{
						List<CountryMilestoneData> countryMilestoneList;

						if (!projectCountryMilestoneListToUpdate.TryGetValue(countryMilestone.CountryId, out countryMilestoneList))
						{
							countryMilestoneList = new List<CountryMilestoneData>();
							projectCountryMilestoneListToUpdate.Add(countryMilestone.CountryId, countryMilestoneList);
						}

						var countryMilestoneConfiguration = CacheService.CountryMilestone[countryMilestone.CountryMilestoneId];
						countryMilestoneList.Add(new CountryMilestoneData
						{
							MilestoneTypeText = countryMilestoneConfiguration.RmMilestoneKey,
							ActualDate = countryMilestone.MilestoneDate.ToDateFromQDateString(),
							Comment = countryMilestone.Comment,
							ProjectCountryMilestoneId = countryMilestone.Id
						});

						if (!string.IsNullOrEmpty(countryMilestoneConfiguration.MappingTable))
						{
							updateSQL = string.Format("{0};Update {1} SET {2} = {3} WHERE ProjectId ={4} AND CountryId={5};",
																updateSQL,
																countryMilestoneConfiguration.MappingTable,
																countryMilestoneConfiguration.ActualColumnMapping,
																countryMilestone.MilestoneDate.ToDateFromQDateString().ToNullableDbDate(),
																countryMilestone.ProjectId,
																countryMilestone.CountryId
								);
						}
					}
				}

				if (!string.IsNullOrEmpty(updateSQL))
				{
					DbHelp.ExecuteNonQueryText(updateSQL);
				}

				foreach (var countryMilestoneKeyValuePair in projectCountryMilestoneListToUpdate)
				{
					//Ppm milestones are never updated from this function.
					CreateOrUpdateCountryMilestones(projectId, countryMilestoneKeyValuePair.Key, countryMilestoneKeyValuePair.Value, false);

					foreach (var updatedCountryMilestone in countryMilestoneKeyValuePair.Value)
					{
						var countryMilestone = CacheService.CountryMilestone.Values.FirstOrDefault(cm => cm.Id == updatedCountryMilestone.CountryMilestoneId);
						GenericInitiateCalculator.CascadeCountryMilestonesToRequestAndGenericCalculators(countryMilestone.Id, projectId, countryMilestoneKeyValuePair.Key, countryMilestone.Attributekey, updatedCountryMilestone.ActualDate);
					}
				}
			}
		}

		private static void CreateNewCountryMilestone(GridSearchCountryMilestone_WS countryMilestone)
		{
			//Create SSV attribute if missing
			DetachedCriteria searchCriteria = DetachedCriteria.For(typeof(SSVAttribute));
			searchCriteria.Add(Expression.Eq("ProjectId", countryMilestone.ProjectId));
			searchCriteria.Add(Expression.Eq("CountryId", countryMilestone.CountryId));
			if (SSVAttribute.Count(searchCriteria) == 0)
			{
				new SSVAttribute()
				{
					ProjectId = countryMilestone.ProjectId,
					CountryId = countryMilestone.CountryId,
					IsActive = 0
				}.SaveAndFlush();
			}

			//Create Monitoring attribute if missing
			searchCriteria = DetachedCriteria.For(typeof(MonitoringAttribute));
			searchCriteria.Add(Expression.Eq("ProjectId", countryMilestone.ProjectId));
			searchCriteria.Add(Expression.Eq("CountryId", countryMilestone.CountryId));
			if (MonitoringAttribute.Count(searchCriteria) == 0)
			{
				new MonitoringAttribute()
				{
					ProjectId = countryMilestone.ProjectId,
					CountryId = countryMilestone.CountryId,
					IsActive = 0
				}.SaveAndFlush();
			}

			//Create Country milestones
			foreach (var cm in CacheService.CountryMilestone.Values)
			{
				var dc = DetachedCriteria.For<ProjectCountryMilestone>()
									.Add(Expression.Eq("ProjectId", countryMilestone.ProjectId))
									.Add(Expression.Eq("CountryId", countryMilestone.CountryId))
									.Add(Expression.Eq("CountryMilestoneId", cm.Id));

				if (ProjectCountryMilestone.Count(dc) == 0)
				{
					new ProjectCountryMilestone
					{
						CountryId = countryMilestone.CountryId,
						ProjectId = countryMilestone.ProjectId,
						CountryMilestoneId = cm.Id,
						ActualDate = countryMilestone.MilestoneDate.ToDateFromQDateString(),
						IsPpmMilestone = false
					}.SaveAndFlush();
				}
			}
		}
	}
}