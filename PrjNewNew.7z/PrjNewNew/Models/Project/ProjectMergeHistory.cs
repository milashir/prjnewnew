﻿using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ProjectMergeHistory")]
	public class ProjectMergeHistory : AbstractActiveRecordBaseModel<ProjectMergeHistory>
	{
		[PrimaryKey(Column = "ProjectMergeHistoryId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int RmProjectId { get; set; }

		[Property]
		public string RmExternalId { get; set; }

		[Property]
		public string MergedExternalId { get; set; }

		[Property]
		public string MegedProjectCode { get; set; }

		[Property]
		public string MergedProtocolNumber { get; set; }

		[Property]
		public int? MergedOrganizationId { get; set; }
	}
}
