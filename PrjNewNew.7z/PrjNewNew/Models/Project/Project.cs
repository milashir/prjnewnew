﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Models.Calculator;
using Quintiles.RM.Clinical.Domain.Models.DTE;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Models.Search;
using Quintiles.RM.Clinical.Domain.Notification;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.Services;
using Quintiles.RPM.Common;
using domainAdmin = Quintiles.RM.Clinical.Domain.Admin;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum OrganizationType_E
	{
		TDU = 1,
		RSUandCL = 2,
		DM = 3,
		QLAB = 4,
		RmSingleService = 5,
		Proposal = 6
	}
	/// <summary>
	/// ActiveRecord wrapper for NHibernate Project class
	/// </summary>
	[Serializable]
	[ActiveRecord(Table = "Project")]
	//public class Project : RMDatabase<Project>, IExternalEntity, IRecentItem, IEquatable<Project>, ICodeTable
	public class Project : AbstractActiveRecordBaseModel<Project>, IExternalEntity, IRecentItem, IEquatable<Project>, ICodeTable
	{
		/// <summary>
		/// The default id column value prior to saving the Project to the db
		/// </summary>
		public const string UNSAVED_DEFAULT_ID = "0";

		#region Mapped Properties

		/// <summary>
		/// MR: Do not ever change this from 0 as the default unsaved value
		/// </summary>
		[PrimaryKey(Column = "ProjectId", UnsavedValue = Project.UNSAVED_DEFAULT_ID /* "-1" */)]
		public override int Id { get; set; }

		[Property(Column = "ProjectCode")]
		public string Name { get; set; }

		[Property]
		public string ExternalId { get; set; }

		[Property]
		public string ExternalSource { get; set; }

		[Property]
		public virtual int? MasterProjectId { get; set; }

		[Property]
		public virtual string StudyStatus { get; set; }

		[Property]
		public virtual string Organization { get; set; }

		[Property]
		public virtual int? OrganizationUnitId { get; set; }

		[Property]
		public virtual string Sponsor { get; set; }

		[Property]
		public virtual string ProtocolNumber { get; set; }

		[Property]
		public virtual string ProtocolNumberAlt { get; set; }

		[Property]
		public virtual string ProtocolTitle { get; set; }

		[Property]
		public virtual string PrimaryCPM { get; set; }

		[Property]
		public virtual string PrimaryCPMQId { get; set; }

		[Property]
		public virtual string Program { get; set; }

		[Property]
		public virtual string ProgramProtocols { get; set; }

		[Property]
		public virtual string ProgramName { get; set; }

		[Property]
		public virtual string ProjectType { get; set; }

		[Property]
		public virtual string ServicesContracted { get; set; }

		[Property]
		public virtual string OtherProjectInformation { get; set; }

		[Property]
		public virtual string Scope { get; set; }

		[Property]
		public virtual DateTime? AwardDate { get; set; }

		[Property]
		public virtual DateTime? InitialAwardedDate { get; set; }

		[Property]
		public virtual DateTime? FirstSubjectEnrolledProjectedDate { get; set; }

		[Property]
		public virtual DateTime? LastSubjectEnrolledProjectedDate { get; set; }

		[Property]
		public virtual DateTime? FinalDeliverableContractedDate { get; set; }

		[Property]
		public virtual DateTime? LastSubjectOutPrj { get; set; }

		[Property]
		public virtual DateTime? LastSubjectOutAct { get; set; }

		[Property]
		public virtual DateTime? LastSubjectRandomPrj { get; set; }

		[Property]
		public virtual DateTime? LastSubjectRandomAct { get; set; }

		[Property]
		public virtual DateTime? DatabaseLockPrj { get; set; }

		[Property]
		public virtual DateTime? DatabaseLockAct { get; set; }

		[Property]
		public virtual DateTime? KickOffMeetingProjectedFinish { get; set; }

		[Property]
		public virtual DateTime? KickOffMeetingActualFinish { get; set; }

		[Property(Column = "OrganizationId")]
		public virtual OrganizationType_E? OrganizationType { get; set; }

		internal List<string> GetCountryNamesWithNullBudgetedSites()
		{
			var monitoringCountries = MonitoringAttribute.FindAllWithNullBudgetedSiteCount(Id);
			var ssvCountries = SSVAttribute.FindAllWithNullBudgetedSiteCount(Id);
			monitoringCountries.AddRange(ssvCountries);

			return monitoringCountries;
		}

		[Property]
		public virtual string ProjectStatus { get; set; }

		[Property]
		public virtual string ProjectIdentifier { get; set; }

		[Property]
		public virtual string ClusterModelState { get; set; }

		[Property]
		public virtual string CustomerSpecifiedRejection { get; set; }

		[Property]
		public virtual string RejectionComments { get; set; }

		[Property]
		public virtual string FirewalledStudies { get; set; }

		[Property]
		public virtual int? SivFsiWeeks { get; set; }

		[Property]
		public virtual int? FsiFirstImvWeeks { get; set; }
		[Property]
		public virtual int? ImvWindowWeeks { get; set; }
		[Property]
		public virtual string ProjectUrl { get; set; }

		[Property]
		public virtual string Phase { get; set; }

		[Property]
		public virtual string CustomerName { get; set; }

		[Property]
		public virtual DateTime? FirstSubjectScreenProjectedStart { get; set; }

		[Property]
		public virtual DateTime? FirstSubjectScreenedActualStart { get; set; }

		[Property]
		public virtual DateTime? FirstSubjectEnrolledProjectedStart { get; set; }

		[Property]
		public virtual DateTime? FirstSubjectEnrolledActualStart { get; set; }

		[Property]
		public virtual DateTime? FirstSubjectRandomizedProjectedStart { get; set; }

		[Property]
		public virtual DateTime? FirstSubjectRandomizedActualStart { get; set; }

		[Property]
		public virtual DateTime? SIVProjectedFinished { get; set; }

		[Property]
		public virtual DateTime? SIVActualFinished { get; set; }

		[Property]
		public virtual DateTime? FirstSiteSelectedProjectedStart { get; set; }

		[Property]
		public virtual DateTime? FirstSiteSelectedActualStart { get; set; }

		[Property]
		public virtual DateTime? FirstSiteInitiatedProjectedStart { get; set; }

		[Property]
		public virtual DateTime? FirstSiteInitiatedActualStart { get; set; }

		[Property]
		public virtual DateTime? LastSiteClosedProjectedStart { get; set; }

		[Property]
		public virtual DateTime? LastSiteClosedActualStart { get; set; }

		[Property]
		public virtual DateTime? LastSiteInitiatedProjectedStart { get; set; }

		[Property]
		public virtual DateTime? LastSiteInitiatedActualStart { get; set; }

		[Property]
		public virtual DateTime? LastSubjectScreenedProjected { get; set; }

		[Property]
		public virtual DateTime? LastSubjectScreenedActual { get; set; }

		[Property]
		public virtual DateTime? LastSubjectEnrolledActualDate { get; set; }

		[Property]
		public virtual string FspPricingModel { get; set; }

		//        ****************Sriram : Proposal related fields*******************************
		[Property]
		public virtual DateTime? ExpectedStartDate { get; set; }
		[Property]
		public virtual DateTime? RfpReceivedDate { get; set; }

		[Property]
		public virtual DateTime? StratCallDate { get; set; }

		[Property]
		public virtual DateTime? ProposalDueDate { get; set; }

		[Property]
		public virtual DateTime? BidDefenseDate { get; set; }

		[Property]
		public virtual DateTime? PrepCallMeetingDate { get; set; }

		[Property]
		public virtual string BidDefenseLocation { get; set; }

		[Property]
		public virtual int? StudyPhaseId { get; set; }

		[Property]
		public virtual int? WinProbabilityId { get; set; }

		[Property]
		public virtual string ProgramIdentifier { get; set; }

		[Property]
		public virtual int? ProposalTypeId { get; set; }

		[Property]
		public virtual int? ProjectStageId { get; set; }

		[Property]
		public virtual string ProposalLead { get; set; }

		[Property]
		public virtual decimal? Budget { get; set; }

		[Property]
		public virtual int? NumberOfSites { get; set; }

		[Property]
		public virtual int? NumberOfPatients { get; set; }

		[Property]
		public virtual int? OpportunityStatusId { get; set; }

		[Property]
		public virtual bool WasUpdated { get; set; }

		[Property]
		public string SourceSystemID { get; set; }

		[Property]
		public string QipClinicalVersion { get; set; }

		[Property]
		public string QipOtherVersion { get; set; }

		[Property]
		public string QipClinicalStatus { get; set; }

		[Property]
		public string QipOtherStatus { get; set; }

		[Property]
		public string QipClinicalIteration { get; set; }

		[Property]
		public string QipOtherIteration { get; set; }

		[Property]
		public string ProjectDescription { get; set; }

		[Property]
		public virtual int? NumberOfCountries { get; set; }

		[Property]
		public virtual string OldProtocolNumber { get; set; }

		[Property]
		public virtual DateTime? InitialSiteInitiationTarget { get; set; }

		[Property]
		public virtual DateTime? ProjectAwardDate { get; set; }

		[Property]
		public virtual string RMProtocolNumber { get; set; }

		[Property]
		public virtual ProjectDteType_E ProjectDteType { get; set; }

		[Property]
		public ProjectDteType_E? PpmDteType { get; set; }

		[Property]
		public virtual int? VisitSchemaLevelId { get; set; }

		[Property]
		public virtual int? ResourceRequirementsTypeId { get; set; }

		[Property]
		public bool IsClinicalRedesignProject { get; set; }

		[Property]
		public int? CompetencyBandId { get; set; }

		[Property]
		public string ProjectSize { get; set; }

		[Property(Update = false, Insert = false)]
		public bool IsActive { get; set; }
		[Property]
		public string ProjectComplexity { get; set; }
		[Property]
		public bool? IsOpenLabel { get; set; }

		[Property]
		public string QipRegionalVersion { get; set; }
		[Property]
		public string QipRegionalStatus { get; set; }
		[Property]
		public string QipRegionalIteration { get; set; }
		[Property]
		public string QipGlobalVersion { get; set; }
		[Property]
		public string QipGlobalStatus { get; set; }
		[Property]
		public string QipGlobalIteration { get; set; }
		[Property]
		public string ProjectOwner { get; set; }
		[Property]
		public string ProjectOwnerQId { get; set; }
		[Property]
		public bool HasUserDefinedSchema { get; set; }
		[Property]
		public bool InitialTieringPerformed { get; set; }
		[Property]
		public bool StopMissingPrimaryClAlerts { get; set; }
		[Property]
		public bool AllowInitialSiteTiering { get; set; }

		[Property(Column = "BudgetingSystemId")]
		public BudgetingSystem? BudgetingSystem { get; set; }

		[Property]
		public bool? RegularTierReviewRequired { get; set; }
		[Property]
		public int? NoRegularTierReviewReasonId { get; set; }
		[Property]
		public bool? AllowTierWithNoVisits { get; set; }
		[Property]
		public string VirtualTrialType { get; set; }
		[Property]
		public bool ConvertedToFromRbmNonRbm { get; set; }
		public bool IsRbmProjectManagedAsNonRbmInRm { get { return ProjectDteType == ProjectDteType_E.NonDte && PpmDteType == ProjectDteType_E.Dte; } }
		public string GetPpmRbmTypeString()
		{
			return PpmDteType.HasValue ? GetRbmTypeStringFromEnum(PpmDteType.GetValueOrDefault()) : string.Empty;
		}
		public string GetRmRbmTypeString()
		{
			return GetRbmTypeStringFromEnum(ProjectDteType);
		}
		public string GetRbmTypeStringFromEnum(ProjectDteType_E dteType)
		{
			switch (dteType)
			{
				case ProjectDteType_E.Dte:
					return "RBM";
				case ProjectDteType_E.NonDte:
					return "NonRBM";
				case ProjectDteType_E.Unknown:
					return "Unknown";
				default:
					return string.Empty;
			}
		}

		public string BudgetingSystemName { get { return BudgetingSystem.HasValue ? BudgetingSystem.GetValueOrDefault().ToString() : "NA"; } }

		public string PrimaryCl { get; set; }

		private ProjectUploadedDocumentPath _stafExcelInformation = null;
		public ProjectUploadedDocumentPath StafExcelInformation
		{
			get
			{
				if (_stafExcelInformation == null)
				{
					_stafExcelInformation = ProjectUploadedDocumentPath.FindByProjectId(Id);
				}
				return _stafExcelInformation;
			}
		}

		public bool HasStafExcel { get { return StafExcelInformation != null; } }

		private string _projectReviewListUrl = null;
		public string ProjectReviewListUrl
		{
			get
			{
				if (string.IsNullOrEmpty(_projectReviewListUrl))
				{
					_projectReviewListUrl = GetProjectReviewListUrlFromDb();
				}
				return _projectReviewListUrl;
			}
		}

		private string GetProjectReviewListUrlFromDb()
		{
			return DbSafe.StringValue(DbHelp.ExecuteScalarText(string.Format("SELECT ReviewListUrl FROM  ProjectReviewListUrl WHERE ProjectId = {0}", Id)));
		}

		private CompetencyBand _competencyBand = null;
		public CompetencyBand CompetencyBand
		{
			get
			{
				if (CompetencyBandId.HasValue && _competencyBand == null)
				{
					_competencyBand = CacheService.AllCompetencyBands.Values.FirstOrDefault(cb => cb.Id == CompetencyBandId.GetValueOrDefault());
				}
				return _competencyBand;
			}
		}

		public virtual string ProtocolNumber50
		{
			get
			{
				return (string.IsNullOrEmpty(ProtocolNumber) || ProtocolNumber.Length <= 50) ? ProtocolNumber : ProtocolNumber.Substring(0, 50);
			}
		}
		#endregion

		private string _primaryCpmManagerQid = null;
		public string PrimaryCpmManagerQid
		{
			get
			{
				if (_primaryCpmManagerQid == null)
				{
					var primaryCpm = Resource.FindOneByProperty("Qid", PrimaryCPMQId);
					_primaryCpmManagerQid = (primaryCpm != null && !string.IsNullOrEmpty(primaryCpm.ManagerQid)) ? primaryCpm.ManagerQid : string.Empty;
				}
				return _primaryCpmManagerQid;
			}
		}

		private bool? _hasPharmacyCalculator = null;
		public bool HasPharmacyCalculator
		{
			get
			{
				if (!_hasPharmacyCalculator.HasValue)
				{
					var sql = string.Format(@"SELECT COUNT(1) FROM dbo.TFTECalculator WHERE ProjectId={0} AND CalculatorTypeId IN ({1}, {2}) AND RequestId IS NULL;",
											Id,
											(int)CalculatorGroup_E.DTEPharmacyCalculator,
											(int)CalculatorGroup_E.PharmacyCalculator);
					_hasPharmacyCalculator = DbSafe.Int(DbHelp.ExecuteScalarText(sql)) > 0;
				}
				return _hasPharmacyCalculator.GetValueOrDefault();
			}
		}

		#region IRecentItem

		public string TypeName
		{
			get { return typeof(Project).FullName; }
		}

		#endregion

		#region Unmapped Properties
		IList<ProjectJobRole> _projectJobRoles = null;
		public IList<ProjectJobRole> ProjectJobRoles
		{
			get
			{
				if (_projectJobRoles == null)
				{
					_projectJobRoles = ProjectJobRole.FindByProjectId(Id);
				}
				return _projectJobRoles;
			}
			set { _projectJobRoles = value; }
		}

		public string ProjectReviewDocLink { get { return !string.IsNullOrEmpty(ProjectReviewListUrl) ? ProjectReviewListUrl : string.Format("{0}/{1}", ProjectUrl, ConfigValue.ProjectReviewDocLink); } }
		public string ProjectReviewDocLink2 { get { return string.Format("{0}/{1}", ProjectUrl, ConfigValue.ProjectReviewDocLink2); } }
		public string PpmTeamListUrl { get { return string.Format("{0}/{1}", ProjectUrl, ConfigValue.QrpmPpmTeamListUrl); } }
		public string PpmActionTrackerUrl { get { return string.Format("{0}/{1}", ProjectUrl, ConfigValue.QrpmPpmActionTrackerUrl); } }
		public bool IsDteProject { get { return ProjectDteType == ProjectDteType_E.Dte; } }

		/// <summary>
		/// Same as the <tt>ColumnName</tt> property
		/// </summary>
		public virtual string ProjectCode { get { return Name; } set { this.Name = value; } }
		public string ProjectCodeProtocol { get { return string.Format("{0} - {1}", ProjectCode, ProtocolNumber); } }
		public virtual DateTime? ProjectInitialAwardDate { get; set; }
		public virtual string RegionsInvolved { get; set; }
		public DateTime? ProjectAwardedDate { get { return AwardDate.HasValue ? AwardDate : ProjectAwardDate; } }
		public DateTime? KickOffMeetingDate { get { return KickOffMeetingActualFinish.HasValue ? KickOffMeetingActualFinish : KickOffMeetingProjectedFinish; } }
		public DateTime? FirstSiteSelectedDate { get { return FirstSiteSelectedActualStart.HasValue ? FirstSiteSelectedActualStart : FirstSiteSelectedProjectedStart; } }
		public DateTime? LastSiteInitiatedDate { get { return LastSiteInitiatedActualStart.HasValue ? LastSiteInitiatedActualStart : LastSiteInitiatedProjectedStart; } }
		public DateTime? DatabaseLockDate { get { return DatabaseLockAct.HasValue ? DatabaseLockAct : DatabaseLockPrj; } }
		public DateTime? LastSiteClosedDate { get { return LastSiteClosedActualStart.HasValue ? LastSiteClosedActualStart : LastSiteClosedProjectedStart; } }
		public DateTime? FirstSiteInitiatedDate { get { return FirstSiteInitiatedActualStart.HasValue ? FirstSiteInitiatedActualStart : FirstSiteInitiatedProjectedStart; } }
		public DateTime? FirstSubjectRandomizedDate { get { return FirstSubjectRandomizedActualStart.HasValue ? FirstSubjectRandomizedActualStart : FirstSubjectRandomizedProjectedStart; } }
		public DateTime? FirstSubjectEnrolledDate { get { return FirstSubjectEnrolledActualStart.HasValue ? FirstSubjectEnrolledActualStart : FirstSubjectEnrolledProjectedDate; } }
		public DateTime? FirstSubjectScreenedDate { get { return FirstSubjectScreenedActualStart.HasValue ? FirstSubjectScreenedActualStart : FirstSubjectScreenProjectedStart; } }
		public DateTime? LastSubjectRandomizedDate { get { return LastSubjectRandomAct.HasValue ? LastSubjectRandomAct : LastSubjectRandomPrj; } }
		public DateTime? LastSubjectEnrolledDate { get { return LastSubjectEnrolledActualDate.HasValue ? LastSubjectEnrolledActualDate : LastSubjectEnrolledProjectedDate; } }
		public DateTime? LastSubjectScreenedDate { get { return LastSubjectScreenedActual.HasValue ? LastSubjectScreenedActual : LastSubjectScreenedProjected; } }
		public DateTime? LastSubjectOutDate { get { return LastSubjectOutAct.HasValue ? LastSubjectOutAct : LastSubjectOutPrj; } }
		private bool HasRequiredMilestonesForPseudoSchema { get { return LastSiteClosedDate.HasValue && GetFirstSubjectRandomizedDate().HasValue; } }
		private bool ArePseudoSchemaMilestonesInCorrectChronologicalOrder { get { return LastSiteClosedDate.GetValueOrDefault() > GetFirstSubjectRandomizedDate().GetValueOrDefault(); } }
		public bool AreMilesontesValidForPseudoSchamaCreation { get { return HasRequiredMilestonesForPseudoSchema && ArePseudoSchemaMilestonesInCorrectChronologicalOrder; } }
		public TherapeuticArea UP_TherapeuticArea { get; set; }
		public List<Indication> UP_Indications { get; set; }
		public CountryRegionList UP_ProposedCountryRegions { get; set; }
		public List<Service> UP_Services { get; set; }

		private List<KeyValuePair<int, string>> _projectMilestoneList;
		public List<KeyValuePair<int, string>> ProjectMilestoneList
		{
			get
			{
				if (_projectMilestoneList == null)
				{
					_projectMilestoneList = Project.GetProjectMilestones(Id);
				}
				return _projectMilestoneList;
			}
		}
		private StudyStatus _studyStatus = null;
		public StudyStatus StudyStatusObj
		{
			get
			{
				//Do not check for the _studyStatus == null. From PPM data service the status gets updated. We want latest status on update
				if (!string.IsNullOrEmpty(StudyStatus))
				{
					_studyStatus = CacheService.StudyStatuses.Values.FirstOrDefault(ss => string.Equals(ss.Name, StudyStatus, StringComparison.InvariantCultureIgnoreCase));
				}
				return _studyStatus;
			}
		}

		private ProjectStage _projectStage = null;
		public ProjectStage ProjectStage
		{
			get
			{
				if (_projectStage == null && ProjectStageId.HasValue)
				{
					_projectStage = CacheService.ProjectStage[ProjectStageId.GetValueOrDefault()];
				}
				return _projectStage;
			}
		}
		private OrganizationalUnit _organizationalUnit = null;
		public OrganizationalUnit OrganizationalUnit
		{
			get
			{
				if (_organizationalUnit == null && OrganizationUnitId.HasValue)
				{
					_organizationalUnit = CacheService.AllOrganizationalUnits[OrganizationUnitId.GetValueOrDefault()];
				}
				return _organizationalUnit;
			}
		}
		public bool AllowMonitoringRequestAutogeneration { get { return OrganizationalUnit == null ? true : OrganizationalUnit.Organization.AutoGenerateMonitoringRequests; } }

		public bool AllowRequestCreation(int resourceTypeId)
		{
			var allowRequestCreation = true;
			if (StudyStatusObj != null)
			{
				var extendedResourceTypeConfigurationByStudyStatusObj = CacheService.ExtendedResourceTypeConfigurationByStudyStatus.Values.FirstOrDefault(er => er.StudyStatusId == StudyStatusObj.Id && er.ResourceTypeId == resourceTypeId);
				if (extendedResourceTypeConfigurationByStudyStatusObj != null)
				{
					allowRequestCreation = extendedResourceTypeConfigurationByStudyStatusObj.AllowRequestCreation;
				}
			}
			return allowRequestCreation;
		}

		public bool AllowRequestSubmission(int resourceTypeId)
		{
			var allowRequestSubmission = true;
			if (StudyStatusObj != null)
			{
				var extendedResourceTypeConfigurationByStudyStatusObj = CacheService.ExtendedResourceTypeConfigurationByStudyStatus.Values.FirstOrDefault(er => er.StudyStatusId == StudyStatusObj.Id && er.ResourceTypeId == resourceTypeId);
				if (extendedResourceTypeConfigurationByStudyStatusObj != null)
				{
					allowRequestSubmission = extendedResourceTypeConfigurationByStudyStatusObj.AllowRequestSubmission;
				}
			}
			return allowRequestSubmission;
		}

		public bool AllowRequestEdit(int resourceTypeId)
		{
			var allowRequestEdit = true;
			if (StudyStatusObj != null)
			{
				var extendedResourceTypeConfigurationByStudyStatusObj = CacheService.ExtendedResourceTypeConfigurationByStudyStatus.Values.FirstOrDefault(er => er.StudyStatusId == StudyStatusObj.Id && er.ResourceTypeId == resourceTypeId);
				if (extendedResourceTypeConfigurationByStudyStatusObj != null)
				{
					allowRequestEdit = extendedResourceTypeConfigurationByStudyStatusObj.AllowRequestsEdit;
				}
			}
			return allowRequestEdit;
		}

		public bool ClearRequests(int resourceTypeId)
		{
			var clearRequests = true;
			if (StudyStatusObj != null)
			{
				var extendedResourceTypeConfigurationByStudyStatusObj = CacheService.ExtendedResourceTypeConfigurationByStudyStatus.Values.FirstOrDefault(er => er.StudyStatusId == StudyStatusObj.Id && er.ResourceTypeId == resourceTypeId);
				if (extendedResourceTypeConfigurationByStudyStatusObj != null)
				{
					clearRequests = extendedResourceTypeConfigurationByStudyStatusObj.ClearRequests;
				}
			}
			return clearRequests;
		}

		public bool AllowProposalRequestCreation { get { return ProjectStage == null ? false : ProjectStage.AllowProposalRequestCreation; } }
		public bool AllowProposalRequestSubmission { get { return ProjectStage == null ? false : ProjectStage.AllowProposalRequestSubmission; } }
		public int GetOrganizationIdFromOrganizationalUnit { get { return OrganizationalUnit == null ? Constants.UnspecifiedId : OrganizationalUnit.OrganizationId; } }
		public bool IsProposalProject { get { return OpportunityStatusId == (int)OpportunityStatus_E.Open; } }

		public bool ShowAllCountries { get { return (OrganizationUnitId == (int)OrganizationalUnit_E.Early_Clinical_Development || OrganizationUnitId == (int)OrganizationalUnit_E.Novella) || ExternalSource == ProjectSource_E.RM.ToString(); } }
		//public bool ShowNonRBMToRBMConversionWarning { get { return (ProjectDteType == ProjectDteType_E.NonDte) && PpmDteType == (ProjectDteType_E)PPMDteType_E.Dte; } }
		#endregion

		#region Static Finder Methods

		/// <summary>
		/// Get a project using only the project code.
		/// </summary>
		/// <param columnName="columnName"></param>
		/// <returns></returns>
		/// <author>Colin Boatwright</author>
		public static Project FindByName(string name)
		{
			Project p = FindOneByProperty("Name", name);
			return p;
		}

		public static Project FindById(int projectId)
		{
			return Project.FindByPrimaryKey(projectId, false);
		}

		/// <summary>
		/// Returns Project matching GUID's.
		/// If cannot find by GUID,try finding the project for merging using project code/protocol number.
		/// If none of the project exist in RM create new project
		/// </summary>
		/// <param name="projectCode">the project code</param>
		/// <param name="protocol">the protocol number</param>
		/// <param name="ExternalId">GUID from PPM</param>
		/// <returns>the Project object</returns>
		public static Project FindByExternalIdAndProjectCodeProtocol(string projectCode, string protocol, string externalId, OrganizationType_E organizationType, string sourceSystemId, int ppmProjectOrganizationalUnitId)
		{
			//If there is any project exist for for the GUID reqturn the project
			DetachedCriteria criteria = DetachedCriteria.For(typeof(Project));
			if (string.IsNullOrEmpty(sourceSystemId))
			{
				criteria.Add(Expression.Eq("ExternalId", externalId));
			}
			else
			{
				criteria.Add(Expression.Or(Expression.Eq("ExternalId", externalId), Expression.Eq("SourceSystemID", sourceSystemId)));
			}

			Project project = Project.FindOne(criteria);
			string protocolWithoutOrganization = string.Empty;
			bool isProjectMerged = false;
			if (project != null)
			{
				return project;
			}
			else
			{
				if (!OrganizationType_E.TDU.Equals(organizationType))
				{
					int indexOfSeparator = protocol.LastIndexOf('_');
					protocolWithoutOrganization = protocol.Substring(0, indexOfSeparator != -1 ? indexOfSeparator : protocol.Length);
				}
				else
				{
					protocolWithoutOrganization = protocol;
				}
				//Find existing RM project for merging
				int projectId = Project.GetExistingProjectId(projectCode, protocolWithoutOrganization, organizationType, ppmProjectOrganizationalUnitId, false);

				Project rmProjectForMerging = null;
				//Check whether the project received is already exist in RM
				if (projectId != 0)
				{
					rmProjectForMerging = Project.FindByPrimaryKey(projectId);
				}
				//Create new project when RM receives brand new project or the PPM project can not be merged with existing RM project 
				if (rmProjectForMerging == null)
				{
					project = new Project() { Name = projectCode, ProtocolNumber = protocol, ExternalId = externalId, OrganizationType = organizationType, RMProtocolNumber = protocolWithoutOrganization };
				}
				else
				{
					//OrganizationType_E rmProjectOrganizationType = (OrganizationType_E)Enum.Parse(typeof(OrganizationType_E), Project.GetOrganizationShortName(rmProjectForMerging.OrganizationId));
					string rmProtocolNumber = rmProjectForMerging.RMProtocolNumber;
					//when comparing protocol number, consider protocol number without organization suffix
					if (string.IsNullOrEmpty(rmProtocolNumber))
					{
						rmProtocolNumber = rmProjectForMerging.ProtocolNumber;
					}
					//If temp project is already exist for the same organization reject the project
					if (rmProjectForMerging.OrganizationType == organizationType && protocolWithoutOrganization.ToUpper() == "NOT AVAILABLE" && rmProtocolNumber.ToUpper() == "NOT AVAILABLE")
					{
						//project = null;
						throw new RMException(string.Format("Duplicate Project Code:{0} /Protocol:{1}", projectCode, protocol));
					}
					else
					{
						project = rmProjectForMerging;
						isProjectMerged = true;
					}
				}
				//Create history for the project merge to keep track of which project is merged with which project
				if (isProjectMerged && !string.Equals(project.ExternalSource, ProjectService.PROJECT_SOURCE.SES.ToString(), StringComparison.InvariantCultureIgnoreCase))
				{
					//OrganizationType_E rmProjectOrganizationType =  (OrganizationType_E)Enum.Parse(typeof(OrganizationType_E), Project.GetOrganizationShortName(project.OrganizationType));
					string rmExternalId;
					string mergedExternalId;
					string megedProjectCode;
					string mergedProtocolNumber;
					int? mergedOrganizationId;
					//Find which project is going to be RM project
					if (project.OrganizationType != organizationType && OrganizationType_E.TDU.Equals(organizationType))
					{
						rmExternalId = externalId;
						mergedExternalId = project.ExternalId;
						megedProjectCode = project.ProjectCode;
						mergedProtocolNumber = project.ProtocolNumber;
						mergedOrganizationId = (int?)project.OrganizationType;
					}
					else
					{
						rmExternalId = project.ExternalId;
						mergedExternalId = externalId;
						megedProjectCode = projectCode;
						mergedProtocolNumber = protocol;
						mergedOrganizationId = (int)organizationType;
					}
					ProjectMergeHistory mergeHistory = new ProjectMergeHistory()
					{
						RmProjectId = project.Id,
						RmExternalId = rmExternalId,
						MergedExternalId = mergedExternalId,
						MegedProjectCode = megedProjectCode,
						MergedProtocolNumber = mergedProtocolNumber,
						MergedOrganizationId = mergedOrganizationId
					};
					mergeHistory.SaveAndFlush();
				}
			}

			return project;
		}

		public static Project FindByNameAndProtocol(string name, string protocol, bool createIfNull = false)
		{
			var criteria = DetachedCriteria.For(typeof(Project));
			criteria.Add(Restrictions.Eq("Name", name));
			criteria.Add(Restrictions.Eq("ProtocolNumber", protocol));
			var project = FindOne(criteria);

			if (project == null)
			{
				var criteriaAlt = DetachedCriteria.For(typeof(Project));
				criteriaAlt.Add(Restrictions.Eq("Name", name));
				criteriaAlt.Add(Restrictions.Eq("ProtocolNumberAlt", protocol));
				project = FindOne(criteriaAlt);
			}
			//Fuzzy logic. Now search the alternate column.

			return (project ?? (createIfNull ? new Project { Name = name, ProtocolNumber = protocol } : null));
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param columnName="columnName"></param>
		/// <returns></returns>
		/// <author>Colin Boatwright</author>
		public static Project FindOrCreateFromExternalByName(string name, string protocol)
		{
			var criteria = DetachedCriteria.For(typeof(Project));
			criteria.Add(Expression.Eq("Name", name));

			if (Constants.NotAvailableProtocol.Equals(protocol, StringComparison.InvariantCultureIgnoreCase))
			{
				criteria.Add(Expression.Disjunction().Add(Expression.Eq("ProtocolNumber", "")).Add(Expression.IsNull("ProtocolNumber")).Add(Expression.Eq("ProtocolNumber", Constants.NotAvailableProtocol)));
			}
			else
			{
				criteria.Add(Expression.Eq("ProtocolNumber", protocol));
			}

			Project project = Project.FindOne(criteria);

			//if (project == null)
			//{
			//    project = ProjectService.CreateLocalVersion(name);
			//}

			return project;
		}

		public static ExecutionStatus_WS<string> ConvertNonRbmProjectToRbm(int projectId)
		{
			var response = new ExecutionStatus_WS<string>();
			var project = FindOneByProperty("Id", projectId);
			if (project == null)
			{
				response.Message = string.Format("Project with id {0} not found.", projectId);
			}
			else if (!RmFunction.HasPermissionToFunction(RmFunction_E.Convert_NonRbm_To_Rbm_Project,
														UserCache.Usr,
														ExtensionMethods.GetCurrentUserQid(),
														new CustomPermissionArg(project, null)))
			{
				response.Message = string.Format("You do not have permission to convert project {0} - {1} to RBM project in RM.", project.ProjectCode, project.ProtocolNumber);

			}
			else if (!project.IsRbmProjectManagedAsNonRbmInRm)
			{
				response.Message = string.Format("Project {0} - {1} cannot be converted to RBM as it is already managed as RBM project in RM.", project.ProjectCode, project.ProtocolNumber);
			}
			else if (EntityProcessFlags.IsProcessRunningForEntity(projectId, Process_E.NonRbmToRbmProjectConversion, EntityTypes.Project))
			{
				response.Message = string.Format("You are not able to run the conversion process for project {0} - {1} because it is already runnig.", project.ProjectCode, project.ProtocolNumber);
			}
			else
			{
				EntityProcessFlags.SetFlag(projectId, Process_E.NonRbmToRbmProjectConversion, EntityTypes.Project);
				try
				{
					var loggedInUserQid = ExtensionMethods.GetCurrentUserQid();
					Task.Run(() =>
				 {
					 new RbmConverter(project, loggedInUserQid, ConfigValue.SiteTierPropotionAlgorithmForNonRbmToRbmConversion).ConvertToRbm();
					 response.IsSuccessful = true;
				 });
				}
				catch (Exception ex)
				{
					response.IsSuccessful = false;
					Logger.Instance.Error(ex);
				}
			}

			return response;
		}

		/// <summary>
		/// Since Project is an 'IRecentItem' it must remove itself from the RecentEntity tables for all users.
		/// 
		/// Since many objects user Project but project does NOT keep a collection of them, the ActiveRecord
		/// framework cannot do a cascade dlete (insofar as I know!). So this method will manually delete all
		/// referencing objects (aka those which ProjectId as a foreign key).
		/// 
		/// This method isn't really ever called except from Unit Tests. There is not a way, current, to delete
		/// a project from the front end.
		/// </summary>
		/// <author>Colin Boatwright</author>
		public override void DeleteAndFlush()
		{
			IList<RecentEntity> re = RecentEntity.FindAllUsersEntriesByEntity<Project>(this);
			re.Each(r => { r.DeleteAndFlush(); });

			IList<SSVAttribute> c1 = SSVAttribute.FindAllByProperty("Project.Id", Id);
			IList<FTECalculator> c4 = FTECalculator.FindAllByProperty("Project.Id", Id);
			IList<MonitoringAttribute> c6 = MonitoringAttribute.FindAllByProperty("Project.Id", Id);
			IList<Request> c7 = Request.FindAllByProperty("Project.Id", Id);

			c1.Each(c => { c.DeleteAndFlush(); });
			c4.Each(c => { c.DeleteAndFlush(); });
			c6.Each(c => { c.DeleteAndFlush(); });
			c7.Each(c => { c.DeleteAndFlush(); });

			base.DeleteAndFlush();
		}
		#endregion

		#region CreateFromReader
		public static Project CreateFromReader(System.Data.IDataReader r)
		{
			Project p = null;
			var cc = new ColumnChecker(r);

			if (r != null && cc.HasColumn("ProjectId") && !(r["ProjectId"] is System.DBNull))
			{
				p = new Project { Id = int.Parse(r["ProjectId"].ToString()) };
				if (cc.HasColumn("PrimaryCpm")) { p.PrimaryCPM = DbSafe.StringValue(r["PrimaryCpm"]); }
				if (cc.HasColumn("PrimaryCl")) { p.PrimaryCl = DbSafe.StringValue(r["PrimaryCl"]); }
				if (cc.HasColumn("ProjectCode")) { p.ProjectCode = r["ProjectCode"].ToString(); }
				if (cc.HasColumn("ProtocolNumber")) { p.ProtocolNumber = r["ProtocolNumber"].ToString(); }
				if (cc.HasColumn("Sponsor")) { p.Sponsor = r["Sponsor"].ToString(); }
				if (cc.HasColumn("CustomerName")) { p.CustomerName = r["CustomerName"].ToString(); }
				if (cc.HasColumn("Program")) { p.Program = r["Program"].ToString(); }
				if (cc.HasColumn("ProgramName")) { p.ProgramName = r["ProgramName"].ToString(); }
				if (cc.HasColumn("Phase")) { p.Phase = r["Phase"].ToString(); }
				if (cc.HasColumn("Organization")) { p.Organization = r["Organization"].ToString(); }
				if (cc.HasColumn("ProjectLastModifiedOn")) { p.LastModifiedOn = DbSafe.DateTime(r["ProjectLastModifiedOn"]); }
				if (cc.HasColumn("SpmClassId")) { p.CompetencyBandId = DbSafe.IntNull(r["SpmClassId"]); }

				if (cc.HasColumn("OrganizationUnitId")) { p.OrganizationUnitId = DbSafe.IntNull(r["OrganizationUnitId"]); }
				else if (cc.HasColumn("ProjectOrganizationalUnitId")) { p.OrganizationUnitId = DbSafe.IntNull(r["ProjectOrganizationalUnitId"]); }

				if (cc.HasColumn("IsOpenLabel")) { p.IsOpenLabel = DbSafe.Bool(r["IsOpenLabel"]); }

				if (cc.HasColumn("ProjectDteType"))
				{
					var projectDteType = DbSafe.IntNull(r["ProjectDteType"]);
					p.ProjectDteType = projectDteType.HasValue ? (ProjectDteType_E)projectDteType : ProjectDteType_E.Unknown;
				}
				if (cc.HasColumn("PpmDteType"))
				{
					var ppmDteType = DbSafe.IntNull(r["PpmDteType"]);
					p.PpmDteType = ppmDteType.HasValue ? (ProjectDteType_E)ppmDteType : ProjectDteType_E.Unknown;
				}
			}

			return p;
		}

		#endregion

		#region GetProposalProjectDetailsByOpportunityNumber
		public static ProposalProject_WS GetProposalProjectDetailsByOpportunityNumber(string opportunityNumber, string protocolNumber)
		{
			ProposalProject_WS proposalProject = null;

			#region Get project from CRM
			Project projectFromCrm = ProjectService.GetProjectDetailsFromCrmV2(opportunityNumber, protocolNumber);
			#endregion

			#region Get project from RM
			DetachedCriteria criteria = DetachedCriteria.For(typeof(Project));
			criteria.Add(Expression.Eq("Name", opportunityNumber));
			if (Constants.NullProtocol.Equals(protocolNumber))
			{
				criteria.Add(Expression.Or(Expression.Eq("ProtocolNumber", ""), Expression.IsNull("ProtocolNumber")));
			}
			else
			{
				criteria.Add(Expression.Eq("ProtocolNumber", protocolNumber));
			}

			Project projectFromRm = Project.FindOne(criteria);
			#endregion

			//Update the RM project
			if (projectFromRm != null && projectFromCrm != null)
			{
				projectFromRm.ProjectStageId = projectFromCrm.ProjectStageId;

				#region Update non PPM fields if Project was received from PPM and was never updated with CRM values for non PPM fields
				if (!projectFromRm.WasUpdated)
				{
					if (projectFromCrm.UP_TherapeuticArea != null)
					{
						new ProjectTherapeuticArea { Project = projectFromRm, TherapeuticArea = projectFromCrm.UP_TherapeuticArea }.SaveAndFlush();
					}

					if (projectFromCrm.UP_Indications != null)
					{
						foreach (Indication indication in projectFromCrm.UP_Indications)
						{
							new ProjectIndications { Project = projectFromCrm, Indication = indication }.SaveAndFlush();
						}
					}

					projectFromRm.StudyPhaseId = projectFromCrm.StudyPhaseId;
					projectFromRm.WinProbabilityId = projectFromCrm.WinProbabilityId;
					projectFromRm.ProtocolNumber = projectFromCrm.ProtocolNumber;
					projectFromRm.ProgramIdentifier = projectFromCrm.ProgramIdentifier;
					projectFromRm.CustomerName = projectFromCrm.CustomerName;
					projectFromRm.Sponsor = projectFromCrm.Sponsor;
					projectFromRm.ProjectDteType = projectFromCrm.ProjectDteType;
					projectFromRm.ExternalId = projectFromCrm.ExternalId;
				}
				#endregion

				projectFromRm.UpdateAndFlush();
			}
			//Create new roject in RM
			else if (projectFromRm == null && projectFromCrm != null)
			{
				projectFromRm = ProjectService.CreateProposalProject(projectFromCrm);
			}

			proposalProject = ProjectService.MapProjectToWsResponse(projectFromRm);
			return proposalProject;
		}
		#endregion

		#region GetCRMProjectDetailsByOpportunityNumber
		public static ExecutionStatus_WS<List<CRMProjectList_WS>> GetProjectProtocolsByOpportunityNumber(string opportunityNumber)
		{
			var serviceResponse = new ExecutionStatus_WS<List<CRMProjectList_WS>>();
			var exceptionHandler = new Action<Exception>((ex) =>
			{
				serviceResponse.Message = "The Data Warehouse web service responded with an error (GetProjectsV2 Response Code 4).Please try again later.";
				Logger.Instance.Error(ex);
			});

			try
			{
				serviceResponse.AdditionalData = ProjectService.GetProjectProtocolListV2(opportunityNumber);
				serviceResponse.IsSuccessful = true;
			}
			catch (InvalidOperationException ex1) { exceptionHandler(ex1); }
			catch (EntryPointNotFoundException ex2) { exceptionHandler(ex2); }
			catch (CommunicationException ex3) { exceptionHandler(ex3); }
			catch (Exception ex4) { Logger.Instance.Error(ex4); }

			return serviceResponse;
		}
		public static int? GetVisitSchemaLevelFromDteType(ProjectDteType_E projectDteType)
		{
			return ProjectDteType_E.Dte.Equals(projectDteType) ? (int?)VisitSchemaLevel_E.Custom : (int?)null;
		}
		public static RMProject_WS GetCRMProjectDetailsByOpportunityNumber(string opportunityNumber, string protocolNumber, string organizationPrefix, bool queryCRM, string autogeneratedProtocolNumber, bool isClinicalRedesignProject, ProjectDteType_E DTEStudyType)
		{
			RMProject_WS RMProject = null;

			#region Get project from RM
			DetachedCriteria criteria = DetachedCriteria.For(typeof(Project));
			criteria.Add(Expression.Eq("Name", opportunityNumber));
			if (Constants.NullProtocol.Equals(protocolNumber))
			{
				criteria.Add(Expression.Or(Expression.Eq("ProtocolNumber", ""), Expression.IsNull("ProtocolNumber")));
			}
			else
			{
				criteria.Add(Expression.Eq("ProtocolNumber", protocolNumber));
			}
			criteria.Add(Expression.Eq("ExternalSource", ProjectService.PROJECT_SOURCE.RM.ToString()));

			Project projectFromRm = Project.FindOne(criteria);
			if (projectFromRm != null)
			{
				protocolNumber = !string.IsNullOrEmpty(projectFromRm.OldProtocolNumber) ? projectFromRm.OldProtocolNumber : "Not Available";
			}
			#endregion

			#region Get project from CRM
			Project projectFromCrm = null;
			if (queryCRM)
			{
				try
				{
					projectFromCrm = ProjectService.GetProjectDetailsFromCrmV2(opportunityNumber, protocolNumber);
				}
				catch (Exception) { /*Swallow the exception. If project is not found, we still want to allow users to create new project in RM*/ }

				if (projectFromCrm != null && string.IsNullOrEmpty(projectFromCrm.Name))
				{
					projectFromCrm = null;
				}
			}
			#endregion

			//Update the RM project
			if (projectFromRm != null && projectFromCrm != null)
			{

				#region Update non PPM fields if Project was received from PPM and was never updated with CRM values for non PPM fields
				ProjectTherapeuticArea therapeuticArea = ProjectTherapeuticArea.FindOneByProperty("Project.Id", projectFromRm.Id);
				if (therapeuticArea != null)
				{
					therapeuticArea.DeleteAndFlush();
				}

				if (projectFromCrm.UP_TherapeuticArea != null)
				{
					new ProjectTherapeuticArea { Project = projectFromRm, TherapeuticArea = projectFromCrm.UP_TherapeuticArea }.SaveAndFlush();
				}
				ProjectIndications[] projectIndication = ProjectIndications.FindAllByProperty("Project.Id", projectFromRm.Id);
				foreach (ProjectIndications indication in projectIndication)
				{
					indication.DeleteAndFlush();
				}
				if (projectFromCrm.UP_Indications != null)
				{
					foreach (Indication indication in projectFromCrm.UP_Indications)
					{
						new ProjectIndications { Project = projectFromRm, Indication = indication }.SaveAndFlush();
					}
				}


				projectFromRm.CustomerName = projectFromCrm.CustomerName;
				projectFromRm.Sponsor = projectFromCrm.Sponsor;
				projectFromRm.NumberOfSites = projectFromCrm.NumberOfSites;
				projectFromRm.NumberOfCountries = projectFromCrm.UP_ProposedCountryRegions.CountryList.Count;
				projectFromRm.ProjectDescription = projectFromCrm.ProjectDescription;
				projectFromRm.ProjectDteType = DTEStudyType;
				projectFromRm.VisitSchemaLevelId = GetVisitSchemaLevelFromDteType(DTEStudyType);
				#endregion

				projectFromRm.UpdateAndFlush();
			}
			//Create new roject in RM
			else if (projectFromRm == null && projectFromCrm != null)
			{
				projectFromRm = ProjectService.CreateRMProject(projectFromCrm, organizationPrefix, autogeneratedProtocolNumber, isClinicalRedesignProject, DTEStudyType);
			}
			else if (projectFromRm == null && projectFromCrm == null)
			{
				var newRmProject = new Project { ProjectCode = opportunityNumber, ProtocolNumber = autogeneratedProtocolNumber, ExternalId = opportunityNumber, IsClinicalRedesignProject = isClinicalRedesignProject, ProjectDteType = DTEStudyType };
				projectFromRm = ProjectService.CreateRMProject(newRmProject, organizationPrefix, autogeneratedProtocolNumber, isClinicalRedesignProject, DTEStudyType);
			}

			RMProject = ProjectService.MapRMProjectToWsResponse(projectFromRm, projectFromCrm);


			UserCache.ProjectName = new ProjectNameProtocolNumber { ProjectName = projectFromRm.Name, ProtocolNumber = projectFromRm.ProtocolNumber, ProjectId = projectFromRm.Id };

			RecentEntity recentEntity = RecentEntity.FindByEntity<Project>(projectFromRm);
			if (recentEntity == null || recentEntity.Id == -1)
			{
				recentEntity = new RecentEntity()
				{
					EntityId = projectFromRm.Id,
					EntityName = projectFromRm.Name,
					EntityTypeId = (int)EntityTypes.Project,
					Qid = ExtensionMethods.GetCurrentUserQid()
				};
				recentEntity.SaveAndFlush();
			}
			else
			{
				recentEntity.LastModifiedOn = System.DateTime.Now;
				recentEntity.LastModifiedBy = ExtensionMethods.GetCurrentUserQid();
				recentEntity.UpdateAndFlush();
			}

			return RMProject;
		}
		#endregion

		#region UpdateRMProject
		public static RMProject_WS UpdateRMProject(RMProject_WS RMProject)
		{
			var updateRMProject = Project.FindOneById(RMProject.ProjectId);

			updateRMProject.InitialSiteInitiationTarget = RMProject.InitialSiteInitiationTarget.ToDateFromQDateString();
			updateRMProject.ProjectAwardDate = RMProject.ProjectAwardDate.ToDateFromQDateString();
			updateRMProject.NumberOfSites = string.IsNullOrEmpty(RMProject.NumberOfSites) ? (int?)null : Convert.ToInt32(RMProject.NumberOfSites);
			updateRMProject.NumberOfCountries = string.IsNullOrEmpty(RMProject.NumberOfCountries) ? (int?)null : Convert.ToInt32(RMProject.NumberOfCountries);
			updateRMProject.Sponsor = RMProject.Sponsor;
			updateRMProject.CustomerName = RMProject.CustomerName;
			updateRMProject.ProjectDescription = RMProject.ProjectDescription;
			updateRMProject.CompetencyBandId = RMProject.CompetencyBandID == -1 ? null : RMProject.CompetencyBandID;
			updateRMProject.IsClinicalRedesignProject = RMProject.IsClinicalRedesignProject;
			updateRMProject.ProjectDteType = RMProject.DTEStudyType;
			updateRMProject.VisitSchemaLevelId = Project.GetVisitSchemaLevelFromDteType(RMProject.DTEStudyType);

			if (RMProject.TherapeuticAreaId != -1)
			{
				ProjectTherapeuticArea.SaveProjectTherapeuticArea(RMProject.TherapeuticAreaId, RMProject.ProjectId);
			}
			ProjectIndications.DmlOperationsOnIndication(RMProject.Indications, RMProject.ProjectId);
			updateRMProject.SaveAndFlush();

			return ProjectService.MapRMProjectToWsResponse(Project.FindOneById(RMProject.ProjectId), null);
		}
		#endregion

		#region UpdatePPMProject
		public static PPMProject_WS UpdatePPMProject(PPMProject_WS PPMProject)
		{
			var updatePPMProject = Project.FindOneById(PPMProject.ProjectId);

			updatePPMProject.InitialAwardedDate = PPMProject.InitialAwardedDate.ToDateFromQDateString();
			updatePPMProject.FsiFirstImvWeeks = PPMProject.FsiImvWeeks;
			updatePPMProject.SivFsiWeeks = PPMProject.SivFsiWeeks;
			updatePPMProject.ImvWindowWeeks = PPMProject.ImvWindowWeeks;
			updatePPMProject.StopMissingPrimaryClAlerts = PPMProject.StopMissingPrimaryClAlerts;
			updatePPMProject.AllowInitialSiteTiering = PPMProject.AllowInitialSiteTiering;
			ProjectCustomField.UpdateFields(PPMProject.ProjectCustomFields);
			updatePPMProject.SaveAndFlush();
			return PPMProject;
		}
		#endregion

		#region UpdateProposalProject
		public static EntityExecutionStatus<ProposalProject_WS> UpdateProposalProject(ProposalProject_WS proposalProject)
		{
			var criteria = DetachedCriteria.For<Project>();
			criteria.Add(Expression.Eq("Name", proposalProject.ProjectCode));
			criteria.Add(Expression.Eq("ProtocolNumber", proposalProject.ProtocolNumber));
			criteria.Add(Expression.Not(Expression.Eq("Id", proposalProject.ProjectId)));

			var response = new EntityExecutionStatus<ProposalProject_WS>();
			if (Project.Count(criteria) > 0)
			{
				response.Errors.Add(new ValidationMessage_WS("#txtProtocolNumber", "Protocol is already used by another project.", MessageType_E.Error));
			}
			else
			{
				Project updateProposalProject = Project.FindOneById(proposalProject.ProjectId);

				updateProposalProject.ProjectCode = proposalProject.ProjectCode;
				updateProposalProject.ProtocolNumber = proposalProject.ProtocolNumber;
				updateProposalProject.ProgramIdentifier = proposalProject.ProgramIdentifier;
				updateProposalProject.RfpReceivedDate = proposalProject.RfpReceivedDate.ToDateFromQDateString();
				updateProposalProject.StratCallDate = proposalProject.StratCallDate.ToDateFromQDateString();
				updateProposalProject.ProposalDueDate = proposalProject.ProposalDueDate.ToDateFromQDateString();
				updateProposalProject.BidDefenseDate = proposalProject.BidDefenseDate.ToDateFromQDateString();
				updateProposalProject.PrepCallMeetingDate = proposalProject.PrepCallMeetingDate.ToDateFromQDateString();
				updateProposalProject.BidDefenseLocation = proposalProject.BidDefenseLocation;
				updateProposalProject.StudyPhaseId = proposalProject.StudyPhaseId == -1 ? (int?)null : proposalProject.StudyPhaseId;
				updateProposalProject.WinProbabilityId = proposalProject.WinProbabilityId == -1 ? (int?)null : proposalProject.WinProbabilityId;

				updateProposalProject.ProgramIdentifier = proposalProject.ProgramIdentifier;
				updateProposalProject.ProposalLead = proposalProject.ProposalLead;
				updateProposalProject.Budget = string.IsNullOrEmpty(proposalProject.Budget) ? (decimal?)null : Convert.ToDecimal(proposalProject.Budget);
				updateProposalProject.NumberOfSites = string.IsNullOrEmpty(proposalProject.NumberOfSites) ? (int?)null : Convert.ToInt32(proposalProject.NumberOfSites);
				updateProposalProject.NumberOfPatients = string.IsNullOrEmpty(proposalProject.NumberOfPatients) ? (int?)null : Convert.ToInt32(proposalProject.NumberOfPatients);
				updateProposalProject.Sponsor = proposalProject.Sponsor;
				updateProposalProject.CustomerName = proposalProject.CustomerName;
				updateProposalProject.ExpectedStartDate = proposalProject.ExpectedStartDate.ToDateFromQDateString();
				updateProposalProject.OrganizationUnitId = proposalProject.OrganizationUnitId;
				ProjectTherapeuticArea.SaveProjectTherapeuticArea(proposalProject.TherapeuticAreaId, proposalProject.ProjectId);
				ProjectIndications.DmlOperationsOnIndication(proposalProject.Indications, proposalProject.ProjectId);
				ProjectService_XREF.DmlOperationsOnProjectService_XREF(proposalProject.Services, proposalProject.ProjectId);
				ProjectCountryAndRegion.DmlOperationsOnProjectRegion(proposalProject.ProjectCountryAndRegion.RegionList, proposalProject.ProjectCountryAndRegion.CountryList, proposalProject.ProjectId);

				Request.UpdateNeedByDatesOfProposalRequestsByProjectId(updateProposalProject.Id, updateProposalProject.ProposalDueDate.GetValueOrDefault());

				try
				{
					updateProposalProject.SaveAndFlush();
				}
				catch (Exception)
				{
					throw;
				}

				response.Output = ProjectService.MapProjectToWsResponse(Project.FindOneById(proposalProject.ProjectId));
			}
			return response;
		}
		#endregion

		#region IEquatable<Project> Members

		public bool Equals(Project other)
		{
			return this.Id == other.Id;
		}

		#endregion

		#region GetProposalProjectDetailsById
		public static ProposalProject_WS GetProposalProjectDetailsById(int projectId)
		{
			return ProjectService.MapProjectToWsResponse(Project.FindOneById(projectId));
		}
		#endregion

		#region GetProjectMilestonesByProjectId
		public static List<ProjectMilestones_WS> GetProjectMilestonesByProjectId(int projectId)
		{
			List<ProjectMilestones_WS> projectMilestone = new List<ProjectMilestones_WS>();

			using (var dr = DbHelp.ExecuteDataReaderSP("dbo.GetProjectMilestonesByProjectId", new SqlParameter("@projectId", projectId)))
			{
				try
				{
					while (dr.Read())
					{
						projectMilestone.Add(new ProjectMilestones_WS
						{
							ProjectMilestoneId = DbSafe.Int(dr["ProjectMilestoneId"]),
							Description = DbSafe.StringValue(dr["Description"]),
							MilestoneDate = DbSafe.QDateString(dr["MilestoneDate"]),
							Comment = DbSafe.StringValue(dr["Comment"]),
							ManualEntryDate = DbSafe.QDateString(dr["ManualEntryDate"]),
						});
					}
				}
				finally { dr.Close(); }
			}
			return projectMilestone;
		}
		#endregion

		public static ProjectSchemaDetails_WS GetProjectActiveTierInformation(int projectId)
		{
			var response = new ProjectSchemaDetails_WS();

			using (var dr = DbHelp.ExecuteDataReaderSP("dbo.GetProjectActiveTierInformation", new SqlParameter("@projectId", projectId)))
			{
				try
				{
					while (dr.Read())
					{
						var tierRow = new VisitSchemaLevelInfo_WS
						{
							CalculatorGroup = (CalculatorGroup_E)DbSafe.Int(dr["CalcualtorGroupId"]),
							TierName = DbSafe.Int(dr["TierName"]),
							IsFsiLsiDefaultTier = DbSafe.Bool(dr["IsFsiLsiDefaultTier"]),
							IsLsiLsoDefaultTier = DbSafe.Bool(dr["IsLsiLsoDefaultTier"]),
							IsLsoCovDefaultTier = DbSafe.Bool(dr["IsLsoCovDefaultTier"]),
							TargetSitePercentage = DbSafe.DecimalNull(dr["TargetSitePercentage"]),
							TierCycle = DbSafe.DecimalNull(dr["TierCycle"]),
							OnSiteVisitRatio = DbSafe.IntNull(dr["OnSiteVisitRatio"]),
							RemoteVisitRatio = DbSafe.IntNull(dr["RemoteVisitRatio"]),
							IsPharmacyDefaultTier = DbSafe.Bool(dr["IsPharmacyDefaultTier"]),
							SchemaVersion = DbSafe.IntNull(dr["SchemaVersion"]),
							ChangeReason = DbSafe.StringValue(dr["Comments"]),
							IsTierEnabled = true,
							ProjectId = projectId
						};

						(tierRow.CalculatorGroup == CalculatorGroup_E.DTEMonitoringCalculator ?
										response.SiteMonitoringSchemaDetails.TierList :
										response.PharmacySchemaDetails.TierList).Add(tierRow);
					}
				}
				finally { dr.Close(); }
			}

			return response;
		}

		#region GetDTESchemaByProjectId
		public static ExecutionStatus_WS<ProjectSchemaDetails_WS> GetDTESchemaByProjectId(int projectId)
		{
			var response = new ExecutionStatus_WS<ProjectSchemaDetails_WS> { IsSuccessful = true };
			var projectSchemaDtls = new ProjectSchemaDetails_WS();
			response.AdditionalData = projectSchemaDtls;

			using (var dr = DbHelp.ExecuteDataReaderSP("dbo.GetProjectSchemaLevelInformation", new SqlParameter("@projectId", projectId)))
			{
				try
				{
					while (dr.Read())
					{
						var SchemaLastModifiedOn = DbSafe.DateTimeNull(dr["SchemaLastModifiedOn"]);
						projectSchemaDtls.SchemaLevel = DbSafe.StringValue(dr["VisitSchemaLevel"]);
						projectSchemaDtls.LastModifiedBy = StringHelper.DeriveLastModifiedBySystem(DbSafe.StringValue(dr["SchemaLastModifiedBy"]));
						projectSchemaDtls.LastModifiedOn = SchemaLastModifiedOn.HasValue ? ExtensionMethods.ToQDateTimeString(SchemaLastModifiedOn.GetValueOrDefault(), 0) : "";
						projectSchemaDtls.SchemaVersion = GetMaxTierValue(projectId);
					}

					dr.NextResult();

					while (dr.Read())
					{
						var tierRow = new VisitSchemaLevelInfo_WS
						{
							CalculatorGroup = (CalculatorGroup_E)DbSafe.Int(dr["CalcualtorGroupId"]),
							TierName = DbSafe.Int(dr["TierName"]),
							IsFsiLsiDefaultTier = DbSafe.Bool(dr["IsFsiLsiDefaultTier"]),
							IsLsiLsoDefaultTier = DbSafe.Bool(dr["IsLsiLsoDefaultTier"]),
							IsLsoCovDefaultTier = DbSafe.Bool(dr["IsLsoCovDefaultTier"]),
							TargetSitePercentage = DbSafe.DecimalNull(dr["TargetSitePercentage"]),
							TierCycle = DbSafe.DecimalNull(dr["TierCycle"]),
							OnSiteVisitRatio = DbSafe.IntNull(dr["OnSiteVisitRatio"]),
							RemoteVisitRatio = DbSafe.IntNull(dr["RemoteVisitRatio"]),
							FsiLsiSiteCount = DbSafe.Int(dr["FsiLsiSiteCount"]),
							FsiLsiSitePct = DbSafe.Decimal(dr["FsiLsiSitePct"]),
							LsiLsoSiteCount = DbSafe.Int(dr["LsiLsoSiteCount"]),
							LsiLsoSitePct = DbSafe.Decimal(dr["LsiLsoSitePct"]),
							LsoCovSiteCount = DbSafe.Int(dr["LsoCovSiteCount"]),
							LsoCovSitePct = DbSafe.Decimal(dr["LsoCovSitePct"]),
							PharmacySiteCount = DbSafe.Int(dr["PharmacySiteCount"]),
							PharmacySitePct = DbSafe.Decimal(dr["PharmacySitePct"]),
							IsPharmacyDefaultTier = DbSafe.Bool(dr["IsPharmacyDefaultTier"]),
							IsTierInUse = DbSafe.Bool(dr["IsTierInUse"]),
							IsTierEnabled = DbSafe.Bool(dr["IsTierEnabled"]),
							ProjectId = projectId,
							PastActualOsVisitCount = DbSafe.Int(dr["PastActualOsVisitCount"]),
							PlannedActualOsVisitCount = DbSafe.Int(dr["PlannedActualOsVisitCount"]),
							PastActualRvVisitCount = DbSafe.Int(dr["PastActualRvVisitCount"]),
							PlannedActualRvVisitCount = DbSafe.Int(dr["PlannedActualRvVisitCount"]),
						};

						(tierRow.CalculatorGroup == CalculatorGroup_E.DTEMonitoringCalculator ?
										projectSchemaDtls.SiteMonitoringSchemaDetails.TierList :
										projectSchemaDtls.PharmacySchemaDetails.TierList).Add(tierRow);
					}
				}
				finally { dr.Close(); }
			}
			var budgetedVisitCount = MonitoringAttribute.GetBudgetedVisitCount(projectId);
			SetProjectBudgetValues(projectSchemaDtls.SiteMonitoringSchemaDetails, projectId, CalculatorGroup_E.DTEMonitoringCalculator, budgetedVisitCount.IntSivVisitCount, budgetedVisitCount.IntCovVisitCount, budgetedVisitCount.IntOnsiteImvVisitCount, budgetedVisitCount.IntRemoteVisitCount);
			SetProjectBudgetValues(projectSchemaDtls.PharmacySchemaDetails, projectId, CalculatorGroup_E.DTEPharmacyCalculator, budgetedVisitCount.IntSivVisitCount, budgetedVisitCount.IntCovVisitCount, budgetedVisitCount.IntPharmacyVisitCount, 0);

			try
			{
				var project = FindById(projectId);
				var totalSiteCount = project.GetSiteCountFromMonitoringAttrbute();
				SetProjectedVisitCounts(project, totalSiteCount, projectSchemaDtls.SiteMonitoringSchemaDetails, false);
				SetProjectedVisitCounts(project, totalSiteCount, projectSchemaDtls.PharmacySchemaDetails, true);
			}
			catch (RMException rex)
			{
				response.IsSuccessful = false;
				response.Message = rex.Message;
			}
			return response;
		}

		public static int GetMaxTierValue(int projectId)
		{
			var visitSchema = ProjectSchemaVersionHistory.FindAllByProperty("ProjectId", projectId);
			var schemaVersionMax = 0;
			foreach (var schema in visitSchema)
			{
				if (schema.SchemaVersion > schemaVersionMax)
				{
					schemaVersionMax = schema.SchemaVersion;
				}
			}
			return schemaVersionMax;
		}

		private static void SetProjectedVisitCounts(Project project, int totalSiteCount, DteSchemaConfiguration dteSchemaConfiguration, bool isPharmacy)
		{
			foreach (var tier in dteSchemaConfiguration.TierList)
			{
				if (tier.IsTierEnabled)
				{
					var visitCount = GetDteSiteVisitCount(project, Convert.ToInt32(tier.TierCycle.GetValueOrDefault()), tier.OnSiteVisitRatio.GetValueOrDefault(), tier.RemoteVisitRatio.GetValueOrDefault(), tier.TargetSitePercentage.GetValueOrDefault(), isPharmacy);
					tier.SivVisitCount = visitCount.SivVisitCount;
					tier.CovVisitCount = visitCount.CovVisitCount;
					tier.OnsiteImvVisitCount = visitCount.OnsiteImvVisitCount;
					tier.RemoteVisitCount = visitCount.RemoteVisitCount;
				}
			}
		}

		private static void SetProjectBudgetValues(DteSchemaConfiguration dteSchemaConfiguration, int projectId, CalculatorGroup_E calculatorGroup_E, int budgetedSivVisitCount, int budgetedCovVisitCount, int budgetedOnsiteImvVisitCount, int budgetedRemoteVisitCount)
		{
			dteSchemaConfiguration.Budget.SivVisitCount = budgetedSivVisitCount;
			dteSchemaConfiguration.Budget.CovVisitCount = budgetedCovVisitCount;
			dteSchemaConfiguration.Budget.OnsiteImvVisitCount = budgetedOnsiteImvVisitCount;
			dteSchemaConfiguration.Budget.RemoteVisitCount = budgetedRemoteVisitCount;

			var buffer = ProjectSiteVisitBuffer.FindByProjectIdAndCalculatorGroup(projectId, calculatorGroup_E);
			if (buffer != null)
			{
				dteSchemaConfiguration.Budget.OnsiteVisitBuffer = buffer.OnsiteVisitBuffer;
			}
		}
		#endregion


		public static VisitPatternGraphData_WS GetVisitPatternGraphData(int projectId)
		{
			var visitPatternInputData = new List<VisitPatternInputData>();
			using (var dr = DbHelp.ExecuteDataReaderSP("dbo.GetInputDataForGeneratingVisitPattern", new SqlParameter("@ProjectId", projectId)))
			{
				try
				{
					while (dr.Read())
					{
						visitPatternInputData.Add(new VisitPatternInputData
						{
							CalculatorTypeId = Convert.ToInt32(dr["CalculatorTypeId"]),
							VisitSchemaLevelId = Convert.ToInt32(dr["VisitSchemaLevelId"]),
							TierId = Convert.ToInt32(dr["TierId"]),
							TierCycle = Convert.ToInt32(dr["TierCycle"]),
							OnSiteVisitRatio = Convert.ToInt32(dr["OnSiteVisitRatio"]),
							RemoteVisitRatio = Convert.ToInt32(dr["RemoteVisitRatio"])
						});
					}
				}
				finally { dr.Close(); }
			}
			return GenerateVisitPatternTableHtml(projectId, visitPatternInputData);
			//// Generate Visit Pattern Graph data
			//StringBuilder htmlVisitPattern = new StringBuilder("<table width=\"100%\" class=\"visitPatternTable\">");
			//string errorTitle = string.Empty;

			//if (visitPatternInputData == null || visitPatternInputData.Count == 0)
			//{
			//	errorTitle = "No visit pattern generated!";
			//}
			//else
			//{
			//	htmlVisitPattern.Append(BuildVisitPatternHtmlTable(visitPatternInputData, CalculatorGroup_E.DTEMonitoringCalculator, true));
			//	htmlVisitPattern.Append(BuildVisitPatternHtmlTable(visitPatternInputData, CalculatorGroup_E.DTEPharmacyCalculator, false));
			//}

			//htmlVisitPattern.Append("</table>");

			//return new VisitPatternGraphData_WS(projectId, 0, errorTitle, htmlVisitPattern.ToString(), 1, 1);
		}
		public static VisitPatternGraphData_WS GenerateVisitPatternTableHtml(int projectId, List<VisitPatternInputData> visitPatternInputData)
		{
			// Generate Visit Pattern Graph data
			StringBuilder htmlVisitPattern = new StringBuilder("<table width=\"100%\" class=\"visitPatternTable\">");
			string errorTitle = string.Empty;

			if (visitPatternInputData == null || visitPatternInputData.Count == 0)
			{
				errorTitle = "No visit pattern generated!";
			}
			else
			{
				htmlVisitPattern.Append(BuildVisitPatternHtmlTable(visitPatternInputData, CalculatorGroup_E.DTEMonitoringCalculator, true));
				htmlVisitPattern.Append(BuildVisitPatternHtmlTable(visitPatternInputData, CalculatorGroup_E.DTEPharmacyCalculator, false));
			}

			htmlVisitPattern.Append("</table>");

			return new VisitPatternGraphData_WS(projectId, 0, errorTitle, htmlVisitPattern.ToString(), 1, 1);
		}
		private static string BuildVisitPatternHtmlTable(List<VisitPatternInputData> visitPatternInputData, CalculatorGroup_E calculatorGroup, bool addSpacerAtBottom)
		{
			var numberOfweeks = 53;
			var colSpan = numberOfweeks + 1;
			var visitPatternHtml = new StringBuilder();
			var header = CalculatorGroup_E.DTEMonitoringCalculator.Equals(calculatorGroup) ? "RBM Site Monitoring Visit Pattern" : "RBM Pharmacy Monitoring Visit Pattern";

			visitPatternHtml.AppendFormat("<tr><td colspan='{0}' width='100%' class='VisitPattern'><b>{1}</b></td></tr>", colSpan, header);
			visitPatternHtml.AppendFormat("<tr><td width='2.3%' rowspan='2' class='VisitPattern'><b>Tier</b></td><td colspan='{0}' class='VisitPattern'><b>Week</b></td></tr>", numberOfweeks);
			visitPatternHtml.Append(GetTierVisitPatternHeaderRowHtml(numberOfweeks));

			if (visitPatternInputData != null && visitPatternInputData.Count > 0)
			{

				for (int tierId = 1; tierId <= 6; tierId++)
				{
					var currentTier = visitPatternInputData.FirstOrDefault(t => t.CalculatorTypeId == (int)calculatorGroup && t.TierId == tierId);

					ReadOnlyCollection<SiteVisitRow> visitPattern = null;
					if (currentTier != null)
					{
						var vpg = new VisitPatternGeneratorV2(currentTier.TierCycle, currentTier.OnSiteVisitRatio, currentTier.RemoteVisitRatio, new DateTime(DateTime.Today.Year, 1, 1), new DateTime(DateTime.Today.Year, 12, 31), null, 0, CalculatorGroup_E.DTEPharmacyCalculator.Equals(calculatorGroup));
						visitPattern = vpg.VisitPattern;
					}

					visitPatternHtml.Append(GetTierVisitPatternRowHtml(tierId.ToString(), visitPattern, numberOfweeks));
				}
			}

			if (addSpacerAtBottom)
			{
				visitPatternHtml.AppendFormat("<tr><td colspan='{0}' style='border:none;'><br/><br/></td></tr>", colSpan);
			}

			return visitPatternHtml.ToString();
		}

		private static string GetTierVisitPatternHeaderRowHtml(int numberOfweeks)
		{
			var sb = new StringBuilder("<tr>");

			for (int weekNumber = 1; weekNumber <= numberOfweeks; weekNumber++)
			{
				sb.AppendFormat("<td width='1.8%' class='VisitPattern'><b>{0}</b></td>", weekNumber.ToString());
			}

			sb.Append("</tr>");

			return sb.ToString();
		}

		private static string GetTierVisitPatternRowHtml(string tierName, ReadOnlyCollection<SiteVisitRow> visitPattern, int numberOfweeks)
		{
			var grayedOutVisitCell = "<td class='disabledVisitCell'><b>&nbsp;</b></td>";
			var blankVisitCell = "<td class='noVisitCell'><b>&nbsp;</b></td>";
			var onsiteVisitCell = "<td class='osVisitCell'><b>OS</b></td>";
			var remoteVisitCell = "<td class='remoteVisitCell'><b>RV</b></td>";
			var OnsitePlusRemoteVisitCell = "<td class='osRemoteVisitCell'></td>";

			var sb = new StringBuilder("<tr>");
			sb.AppendFormat("<td width='2.3%' class='VisitPattern'><b>{0}</b></td>", tierName);

			//blank pattern
			if (visitPattern == null)
			{
				for (int i = 0; i < numberOfweeks; i++) { sb.Append(grayedOutVisitCell); }
			}
			else
			{
				//Pattern based on tier configuration
				for (int weekNumber = 1; weekNumber <= numberOfweeks; weekNumber++)
				{
					var visitTypesInCurrentWeek = visitPattern.Where(vp => vp.WeekNumber == weekNumber).Select(vp => vp.SiteVisitType).Distinct();

					if (visitTypesInCurrentWeek.Count() == 0) { sb.Append(blankVisitCell); }
					else if (visitTypesInCurrentWeek.Count() == 2) { sb.Append(OnsitePlusRemoteVisitCell); }
					else if (visitTypesInCurrentWeek.First() == SiteVisitType_E.AnyOnsite) { sb.Append(onsiteVisitCell); }
					else { sb.Append(remoteVisitCell); }
				}
			}

			sb.Append("</tr>");

			return sb.ToString();
		}

		#region GetProjectMilestonesByProjectId
		public static List<Milestones_WS> GetAllMilestonesByProjectId(int projectId, bool getActiveOnly, int requestId, int countryId, int resourceTypeOrganizationId, int resourceTypeId)
		{
			var request = (requestId == 0) ? (Request)null : Request.FindOneByProperty("Id", requestId);
			string qId = UserCache.Usr.QId;
			if (request != null)
			{
				getActiveOnly = !request.IsAssigned;
				qId = request.QId;
			}

			int resourceOrganizationalUnitId = Resource.GetOrganizationUnitId(qId);

			List<Milestones_WS> Milestones = new List<Milestones_WS>();
			using (var dr = DbHelp.ExecuteDataReaderSP("dbo.GetAllProjectMilestonesByProjectId",
																																																																																											new SqlParameter("@projectId", projectId),
																																																																																											new SqlParameter("@ResourceOrganizationalUnitId", resourceOrganizationalUnitId),
																																																																																											new SqlParameter("@GetActiveOnly", getActiveOnly ? 1 : 0),
																																																																																											new SqlParameter("@CountryId", countryId),
																																																																																											new SqlParameter("@ResourceTypeOrganizationId", resourceTypeOrganizationId),
																																																																																											new SqlParameter("@RequestId", requestId),
																																																																																											new SqlParameter("@ResourceTypeId", resourceTypeId)))
			{
				try
				{
					while (dr.Read())
					{
						Milestones.Add(new Milestones_WS
						{
							Id = (int)dr["IdentityId"],
							ProjectMilestoneId = (int)dr["ProjectMilestoneId"],
							MilestoneName = DbSafe.StringValue(dr["MilestoneName"]),
							MilestoneDate = DbSafe.QDateString(dr["MilestoneDate"]),
							ConnectedDate = DbSafe.QDateString(dr["ConnectedDate"]),
							MilestoneType = DbSafe.StringValue(dr["MilestoneType"]),
							IsActive = DbSafe.Bool(dr["IsActive"]),
							IsConnected = DbSafe.Bool(dr["IsConnected"]),
							MilestoneLastModifiedOn = DbSafe.DateTime(dr["LastModifiedOn"]).Ticks,
							Utilization = DbSafe.DecimalNull(dr["Utilization"]),
							WeeklyHours = DbSafe.Decimal(dr["WeeklyHours"])
						});
					}
				}
				finally { dr.Close(); }
			}
			return Milestones;
		}
		#endregion

		#region GetInitiateRequestProjects
		public static ProjectInfo_WS GetProjectDetailsForInitiateRequest(int projectId)
		{
			ProjectInfo_WS projectDetails = null;
			string sqlQuery = string.Format(@"SELECT  P.ProjectId ,
																								P.ProjectCode ,
																								P.ProgramName ,
																								P.ProtocolNumber ,
																								P.ResourceTransitionTime ,
																								P.OrganizationUnitId ,
																								OU.Name AS OrganizationalUnit ,
																								P.VisitSchemaLevelId ,
																								P.LastModifiedOn,
																								CASE P.ProjectDteType
																									WHEN 1 THEN 1
																									ELSE 0
																								END AS IsDteProject ,
																								ISNULL(VSL.IsCustomLevel, 0) AS CPMValuesRequired ,
																								CASE WHEN EXISTS ( SELECT TOP 1
																																						1
																																	 FROM     dbo.VisitSchemaLevelTier_Xref VSLTX
																																	 WHERE    VSLTX.ProjectId = P.ProjectId ) THEN 1
																										 ELSE 0
																								END AS CustomValuesConfigured,
																								CASE WHEN EXISTS ( SELECT TOP 1
																																						1
																																	 FROM     dbo.VisitSchemaLevelTier_Xref VSLTX
																																	 WHERE    VSLTX.ProjectId = P.ProjectId
																																						AND CalculatorTypeId = 7) THEN 1 --7:Pharmacy
																										 ELSE 0
																								END AS PharmacySchemaEnabled,
                                                P.ExternalSource,
																								CASE P.ProjectDteType
																								WHEN 1 THEN 'Yes'
																								WHEN 2 THEN 'No'
																								WHEN 3 THEN 'Unknown'
																								END AS ProjectDteType,
																								IsOpenLabel,
																								P.HasUserDefinedSchema,
																								P.ExpectedStartDate
																				FROM    Project P
																								LEFT JOIN dbo.VisitSchemaLevel VSL ON VSL.VisitSchemaLevelId = P.VisitSchemaLevelId
																								LEFT JOIN dbo.OrganizationalUnit OU ON P.OrganizationUnitId = OU.OrganizationalUnitId
																				WHERE   P.ProjectId = {0};", projectId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					if (dr.Read())
					{
						projectDetails = new ProjectInfo_WS
						{
							Id = DbSafe.Int(dr["ProjectId"]),
							ProjectCode = DbSafe.StringValue(dr["ProjectCode"]),
							ProgramName = DbSafe.StringValue(dr["ProgramName"]),
							ProtocolNumber = DbSafe.StringValue(dr["ProtocolNumber"]),
							ProjectLastModifiedOn = DbSafe.DateTime(dr["LastModifiedOn"]).Ticks,
							VisitSchemaLevelId = DbSafe.IntNull(dr["VisitSchemaLevelId"]),
							DTE = DbSafe.Bool(dr["IsDteProject"]),
							CustomSchemaValuesRequired = DbSafe.Bool(dr["CPMValuesRequired"]),
							CustomSchemaValuesConfigured = DbSafe.Bool(dr["CustomValuesConfigured"]),
							PharmacySchemaEnabled = DbSafe.Bool(dr["PharmacySchemaEnabled"]),
							OrganizationalUnitId = DbSafe.Int(dr["OrganizationUnitId"]),
							OrganizationalUnit = DbSafe.StringValue(dr["OrganizationalUnit"]),
							ExternalSource = (ProjectService.PROJECT_SOURCE)Enum.Parse(typeof(ProjectService.PROJECT_SOURCE), dr["ExternalSource"].ToString()),
							ProjectDteType = DbSafe.StringValue(dr["ProjectDteType"]),
							IsOpenLabel = DbSafe.Bool(dr["IsOpenLabel"]),
							HasUserDefinedSchema = DbSafe.Bool(dr["HasUserDefinedSchema"]),
							ExpectedStartDate = DbSafe.DateTime(dr["ExpectedStartDate"]).ToQDateString()
						};
						OrganizationalUnit org;
						if (CacheService.AllOrganizationalUnits.TryGetValue(projectDetails.OrganizationalUnitId, out org))
						{
							projectDetails.OrganizationId = org.OrganizationId;
						}
					}
				}
				finally { dr.Close(); }

				projectDetails.Milestones = GetProjectMilestones(projectId);
				projectDetails.MonitoringAttributes = MonitoringAttribute.GetMonitoringAttributesForInitiateRequest(projectId);
				projectDetails.SsvAttributes = SSVAttribute.GetSSVAttributesForInitiateRequest(projectId);
				projectDetails.CountryMilestones = GetProjectCountryMilestones(projectId);//dibakar create one more method to get sequence validated
				projectDetails.IsMilestoneSequenceValid = IsMilestoneSequenceValid(projectId);
			}
			return projectDetails;
		}
		#endregion

		#region MilestoneSequenceValidate

		public static bool IsMilestoneSequenceValid(int projectId)
		{
			int tempChronologicalOrderOfMilestone = 0;

			string sqlQuery = string.Format(@"SELECT  PPMX.ProjectMilestoneId, PM.ChronologicalOrderOfMilestone,PM.ValidateChronologicalOrder,
					COALESCE(PPMX.ActualDate, PPMX.ProjectedDate, PPMX.ContractedDate) AS ProjectMilestoneDate
					FROM     dbo.ProjectProjectMilestone_XREF PPMX 
					JOIN dbo.cd_ProjectMileStone PM ON PM.ProjectMileStoneId = PPMX.ProjectMilestoneId WHERE   PPMX.ProjectId = {0} AND PM.ValidateChronologicalOrder=1 and PM.ChronologicalOrderOfMilestone is not null ORDER BY COALESCE(PPMX.ActualDate, PPMX.ProjectedDate, PPMX.ContractedDate);", projectId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						if (tempChronologicalOrderOfMilestone > DbSafe.Int(dr["ChronologicalOrderOfMilestone"]))
						{
							return false;
						}
						else
						{
							tempChronologicalOrderOfMilestone = DbSafe.Int(dr["ChronologicalOrderOfMilestone"]);
						}
					}
					return true;
				}
				finally { dr.Close(); }
			}
		}
		#endregion

		#region GetProjectMilestones
		public static List<KeyValuePair<int, string>> GetProjectMilestones(int projectId)
		{
			var projectMilestones = new List<KeyValuePair<int, string>>();

			string sqlQuery = string.Format(@"SELECT  PPMX.ProjectMilestoneId ,
																								COALESCE(PPMX.ActualDate, PPMX.ProjectedDate, PPMX.ContractedDate) AS ProjectMilestoneDate
																				FROM    dbo.Project P
																								JOIN dbo.ProjectProjectMilestone_XREF PPMX ON PPMX.ProjectId = P.ProjectId
																								JOIN dbo.cd_ProjectMileStone PM ON PM.ProjectMileStoneId = PPMX.ProjectMilestoneId
																				WHERE   P.ProjectId = {0};", projectId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						projectMilestones.Add(new KeyValuePair<int, string>(DbSafe.Int(dr["ProjectMilestoneId"]), DbSafe.QDateString(dr["ProjectMilestoneDate"])));
					}
				}
				finally { dr.Close(); }
			}

			return projectMilestones;
		}
		#endregion

		#region GetProjectCountryMilestones
		public static List<CountryMilestone_WS> GetProjectCountryMilestones(int projectId)
		{
			var projectCountryMilestones = new List<CountryMilestone_WS>();

			string sqlQuery = string.Format(@"SELECT  PCMX.CountryMilestoneId,
																				        PCMX.CountryId ,
																								COALESCE(PCMX.ActualDate, PCMX.ProjectedDate, PCMX.ContractedDate) AS MilestoneDate
																				FROM    dbo.ProjectCountryMilestone_XREF PCMX
																				WHERE   PCMX.ProjectId = {0};", projectId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						projectCountryMilestones.Add(new CountryMilestone_WS
						{
							CountryId = DbSafe.Int(dr["CountryId"]),
							MilestoneId = DbSafe.Int(dr["CountryMilestoneId"]),
							MilestoneDate = DbSafe.QDateString(dr["MilestoneDate"])
						});
					}
				}
				finally { dr.Close(); }
			}

			return projectCountryMilestones;
		}
		#endregion

		#region GetAllProjects
		public static PagedResponse<Project, GridRowCommonData> GetProjectsById()
		{
			var pr = new PagedResponse<Project, GridRowCommonData>();
			var openRequests = new List<Project>();

			string sqlQuery = @"SELECT * FROM Project WHERE projectId=1722 Order by ProjectCode, ProtocolNumber";
			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						Project openRequest = new Project
						{
							Id = (int)dr["ProjectId"],
							ProjectCode = dr["ProjectCode"].ToString(),
							ProgramName = dr["ProgramName"].ToString(),
							ProtocolNumber = dr["ProtocolNumber"].ToString()
						};
						openRequests.Add(openRequest);
					}
					pr.Records = openRequests;
				}
				finally { dr.Close(); }
			}
			return pr;
		}
		#endregion

		public static List<ValueId_WS> GetAllProjectList()
		{
			string sql;
			sql = "Select ProjectId, (ProjectCode + ' - ' + ISNULL(ProtocolNumber,'Not Available')) AS LookupString FROM Project where IsActive=1";
			var returnValue = new List<ValueId_WS>();
			using (var dr = DbHelp.ExecuteDataReaderText(sql, null))
			{
				try
				{
					while (dr.Read())
					{
						returnValue.Add(new ValueId_WS(dr["ProjectId"].ToString(), dr["LookupString"].ToString()));
					}
				}
				finally { dr.Close(); }
			}
			return returnValue;
		}

		public static List<ValueId_WS> GetTypeAheadStringForAwardedProjects(bool filterBasedonRMUser)
		{
			string sql;
			if (filterBasedonRMUser)
			{
				sql = string.Format(@"SELECT DISTINCT
																		 PRJ.ProjectId ,
																		 ( PRJ.ProjectCode + ' - ' + ISNULL(PRJ.ProtocolNumber, 'Not Available') ) AS LookupString
															FROM   dbo.RmUser RMU
																		 JOIN RmUser_Organization_XREF RUO ON RMU.RmUserId = RUO.RmUserId
																		 JOIN Project PRJ ON PRJ.OrganizationUnitId = RUO.OrganizationalUnitId
																		 JOIN dbo.OrganizationalUnit OU ON RUO.OrganizationalUnitId = OU.OrganizationalUnitId
																		 LEFT JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = PRJ.StudyStatus
															WHERE  PRJ.ExternalSource != 'SES'
																		 AND OU.IsEnabled = 1
																		 AND ( SS.StudyStatusId IS NULL
																		 			OR ( SS.StudyStatusId IS NOT NULL
																		 					 AND SS.AllowRequestCreation = 1
																		 				 )
																		 		)
																		 AND RMU.QId = '{0}'", ExtensionMethods.GetCurrentUserQid());
			}
			else
			{
				sql = "Select ProjectId, (ProjectCode + ' - ' + ISNULL(ProtocolNumber,'Not Available')) AS LookupString FROM Project WHERE ExternalSource!='SES' ";
			}

			var returnValue = new List<ValueId_WS>();
			using (var dr = DbHelp.ExecuteDataReaderText(sql, null))
			{
				try
				{
					while (dr.Read())
					{
						returnValue.Add(new ValueId_WS(dr["ProjectId"].ToString(), dr["LookupString"].ToString()));
					}
				}
				finally { dr.Close(); }
			}
			return returnValue;
		}

		public static List<ValueId_WS> GetTypeAheadStringForAwardedAndProposalProjects()
		{
			string sql = string.Format(@"SELECT DISTINCT
																					PRJ.ProjectId ,
																					( PRJ.ProjectCode + ' - '
																						+ CASE WHEN PRJ.ProtocolNumber IS NULL
																												OR PRJ.ProtocolNumber = '' THEN 'Not Available'
																									 ELSE PRJ.ProtocolNumber
																							END ) AS LookupString
																	 FROM   dbo.RmUser RMU
																					JOIN RmUser_Organization_XREF RUO ON RMU.RmUserId = RUO.RmUserId
																					JOIN Project PRJ ON PRJ.OrganizationUnitId = RUO.OrganizationalUnitId
																					JOIN dbo.OrganizationalUnit OU ON RUO.OrganizationalUnitId = OU.OrganizationalUnitId
																					LEFT JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = PRJ.StudyStatus
																					LEFT JOIN dbo.RmUserSharePointRole_XREF RUSX ON RUSX.RmUserId = RMU.RmUserId
																	 WHERE  OU.IsEnabled = 1
																					AND PRJ.IsActive = 1 
																					AND PRJ.OpportunityStatusId != {0}
																					AND ( SS.StudyStatusId IS NULL
																		 					OR ( SS.StudyStatusId IS NOT NULL
																		 								AND SS.AllowRequestCreation = 1
																		 							)
																		 				)
																					AND ( PRJ.OpportunityStatusId != {1}
																												OR ( RUSX.SharePointRoleId IN ( {2}, {3}, {4} )
																														 AND PRJ.OpportunityStatusId = {1}
																													 )
																											)
																					AND RMU.QId = '{5}' ORDER BY LookupString",
																																																											(int)OpportunityStatus_E.Closed_Lost,
																																																											(int)OpportunityStatus_E.Open,
																																																											(int)UserRole_E.DemandPlanner,
																																																											(int)UserRole_E.Support,
																																																											(int)UserRole_E.Admin,
																																																											ExtensionMethods.GetCurrentUserQid());

			var returnValue = new List<ValueId_WS>();
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						returnValue.Add(new ValueId_WS(dr["ProjectId"].ToString(), dr["LookupString"].ToString()));
					}
				}
				finally { dr.Close(); }
			}
			return returnValue;
		}

		public static List<string> GetTypeAheadStringForProjectSponsors()
		{
			string sql = @"SELECT DISTINCT Sponsor AS LookupString FROM
							Project p WHERE Sponsor != '' AND Sponsor IS NOT NULL";
			var returnValue = new List<string>();
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						returnValue.Add(DbSafe.StringValue(dr["LookupString"].ToString()));
					}
				}
				finally { dr.Close(); }
			}
			return returnValue;
		}
		public static string GetSearchDataForNewOrganization(string searchField, int resourceRequestTypeId)
		{
			StringBuilder sb = new StringBuilder();
			string queryString = string.Empty;

			if (searchField == "HrName")
			{
				if (resourceRequestTypeId == 0)
				{
					queryString = @"SELECT Distinct Name FROM dbo.JobRole WHERE HRName IS NOT NULL AND JobRoleId IN (SELECT DISTINCT JobRoleId FROM dbo.ResourceType	WHERE IsViewable = 1 AND IsEnabled = 1)";
				}
				else
				{
					ResourceType resoureceType = ResourceType.FindByPrimaryKey(resourceRequestTypeId);
					int jobRoleId;
					if (resoureceType != null)
					{
						jobRoleId = resoureceType.JobRole.Id;
						queryString = @"SELECT Distinct Name FROM dbo.JobRole WHERE HRName IS NOT NULL AND JobRoleId IN (SELECT DISTINCT JobRoleId FROM dbo.ResourceType	WHERE IsViewable = 1 AND IsEnabled = 1) and jobroleid!=" + jobRoleId;
					}
				}
			}

			using (var dr = DbHelp.ExecuteDataReaderText(queryString, null))
			{
				try
				{
					while (dr.Read())
					{
						if (searchField == "HrName")
						{
							sb.AppendFormat(",{0},", dr["Name"].ToString());
						}
					}
				}
				finally { dr.Close(); }
			}

			return sb.ToString();
		}

		#region FindAllPagedCountryMilestones
		/// <summary>
		/// This method is used to return all the country level milestones for project.
		/// </summary>
		/// <returns></returns>
		public static PagedResponse<GridSearchCountryMilestone_WS, GridRowCommonData> FindAllPagedCountryMilestones(GridSearchCountryMilestone_WS gsr)
		{
			#region Paremeter list
			var parms = new List<SqlParameter>{
				new SqlParameter("pageNumber", gsr.PageNumber),
				new SqlParameter("pageSize", gsr.RecordsPerPage)
			};

			if (gsr.OrderBy != string.Empty) { parms.Add(new SqlParameter("orderBy", gsr.OrderBy)); }
			if (gsr.SortOrder != string.Empty) { parms.Add(new SqlParameter("sortOrder", gsr.SortOrder)); }
			if (!string.IsNullOrEmpty(gsr.ProjectId.ToString())) { parms.Add(new SqlParameter("ProjectId", gsr.ProjectId)); }
			if (!string.IsNullOrEmpty(gsr.RegionName)) { parms.Add(new SqlParameter("RegionName", gsr.RegionName)); }
			if (!string.IsNullOrEmpty(gsr.CountryName)) { parms.Add(new SqlParameter("CountryName", gsr.CountryName)); }
			if (!string.IsNullOrEmpty(gsr.MilestoneName)) { parms.Add(new SqlParameter("MilestoneName", gsr.MilestoneName)); }
			if (!string.IsNullOrEmpty(gsr.MilestoneDate)) { parms.Add(new SqlParameter("MilestoneDate", gsr.MilestoneDate)); }
			if (!string.IsNullOrEmpty(gsr.Comment)) { parms.Add(new SqlParameter("Comment", gsr.Comment)); }

			var totalRecordsParm = new SqlParameter("totalRecords", SqlDbType.Int);
			totalRecordsParm.Direction = ParameterDirection.Output;
			parms.Add(totalRecordsParm);

			var totalPagesParm = new SqlParameter("totalPages", SqlDbType.Int);
			totalPagesParm.Direction = ParameterDirection.Output;
			parms.Add(totalPagesParm);
			#endregion

			var pr = new PagedResponse<GridSearchCountryMilestone_WS, GridRowCommonData>();
			var countryMilestones = new List<GridSearchCountryMilestone_WS>();
			using (var dr = DbHelp.ExecuteDataReaderSP("GetProjectCountryMilestonesByProjectId", parms.ToArray()))
			{
				try
				{
					while (dr.Read())
					{
						countryMilestones.Add(new GridSearchCountryMilestone_WS
						{
							Id = DbSafe.Int(dr["ProjectCountryMilestoneId"]),
							CountryMilestoneId = DbSafe.Int(dr["CountryMilestoneId"]),
							ProjectId = gsr.ProjectId,
							CountryId = DbSafe.Int(dr["CountryId"]),
							RegionName = DbSafe.StringValue(dr["RegionName"]),
							CountryName = DbSafe.StringValue(dr["CountryName"]),
							MilestoneName = DbSafe.StringValue(dr["MilestoneName"]),
							MilestoneDate = DbSafe.QDateString(dr["MilestoneDate"]),
							Comment = DbSafe.StringValue(dr["Comment"]),
							DateToCompare = DbSafe.QDateString(dr["MilestoneDate"]),
							ManualEntryDate = DbSafe.QDateString(dr["ManualEntryDate"]),
							IsPpmMilestone = DbSafe.Bool(dr["IsPpmMilestone"]),
							OrganizationalUnitId = DbSafe.Int(dr["OrganizationalUnitId"]),
						});
					}

					dr.NextResult();
					pr.Records = countryMilestones;
					pr.TotalPages = int.Parse(totalPagesParm.Value.ToString());
					pr.TotalRecords = int.Parse(totalRecordsParm.Value.ToString());
					pr.PageNumber = gsr.PageNumber;
				}
				finally { dr.Close(); }
			}

			return pr;
		}
		#endregion

		public string GetPrimaryCpmName()
		{
			var sql = string.Format(@"SELECT  COALESCE(R.ResourceName, P.PrimaryCpm, P.PrimaryCpmQid)
																FROM    Project P
																				LEFT JOIN Resource R ON P.PrimaryCpmQid = R.Qid
																WHERE   ProjectId = {0}", Id);
			return DbHelp.ExecuteScalarText(sql).ToString();
		}

		public string GetProjectOwnerName()
		{
			var sql = string.Format(@"SELECT  COALESCE(R.ResourceName, P.ProjectOwner, P.ProjectOwnerQid)
																FROM    Project P
																				LEFT JOIN Resource R ON P.ProjectOwnerQid = R.Qid
																WHERE   ProjectId = {0}", Id);
			return DbHelp.ExecuteScalarText(sql).ToString();
		}

		public string GetPrimaryClNameFromDb()
		{
			return (string)DbHelp.ExecuteScalarText(string.Format(@"SELECT PrimaryCl FROM ProjectPrimaryCl_View WHERE ProjectId = {0}", Id));
		}

		public string GetPrimaryClQidFromDb(out string primaryClManagerQid)
		{
			primaryClManagerQid = string.Empty;
			string primaryClQid = string.Empty;
			using (var dr = DbHelp.ExecuteDataReaderText(string.Format(@"SELECT PrimaryClQid, PrimaryClManagerQid FROM ProjectPrimaryCl_View WHERE ProjectId = {0}", Id)))
			{
				try
				{
					if (dr.Read())
					{
						primaryClQid = DbSafe.StringValue(dr["PrimaryClQid"]);
						primaryClManagerQid = DbSafe.StringValue(dr["PrimaryClManagerQid"]);
					}
				}
				finally { dr.Close(); }
			}

			return primaryClQid;
		}

		/// <summary>
		/// Method to findout the exisisting RM project to merge the new project received from PPM.
		/// First we will find the project using project code only,if multiple projects found in RM find project using project code and protocol combination
		/// </summary>
		/// <param name="ppmProjectCode">the project code</param>
		/// <param name="ppmProtocolNumber">protocol number with organization suffix i.e 123_ISS</param>
		/// <param name="ppmOrganizationType">TDU,ISS,DM etc..</param>
		/// <param name="queryProtocol">to consider protocol for finding project?</param>
		/// <returns>the project id</returns>
		//private static int GetExistingProjectId(string projectCode, string protocolNumber, OrganizationType_E organizationType, bool queryProtocol, int organizationId)
		private static int GetExistingProjectId(string ppmProjectCode, string ppmProtocolNumber, OrganizationType_E ppmOrganizationType, int ppmOrganizationalUnitId, bool queryProtocol)
		{
			int projectCount = 0;
			int singleServiceProjectCount = 0;
			int projectId = 0;
			int rmOrganizationalUnitId = 0;
			string rmProtocolNumber = string.Empty;
			OrganizationType_E rmProjectOrganizationType = OrganizationType_E.TDU;

			string query = string.Format(@"SELECT  OrganizationUnitId ,
																						 ProjectId ,
																						 ISNULL(OrganizationId, '1') AS OrganizationId ,
																						 ISNULL(RMProtocolNumber, ProtocolNumber) AS ProtocolNumber,
																						 ProtocolNumber AS UnmodifiedProtocol 
																		 FROM    Project
																		 WHERE   ExternalSource IN ( 'PPM', 'SES' )
																						 AND ProjectCode = '{0}'", ppmProjectCode);
			//Add protocol clause when RM has multiple projects for the project code
			if (queryProtocol)
			{
				//query = query + " AND ISNULL(RMProtocolNumber,ProtocolNumber)='" + ppmProtocolNumber + "' AND OrganizationId in(6, 1," + (int)ppmOrganizationType + ")"; //6: Proposal, 1: TDU
				query = string.Format(@"{0} AND ISNULL(RMProtocolNumber,ProtocolNumber)='{1}'
																		AND ( ( {2} = 1 --1: TDU
																						AND OrganizationId NOT IN ( 1, 5 ) --1: TDU, 5: RmSingleService
																					)
																					OR ( {2} != 1 --1: TDU
																							 AND OrganizationId IN ( 1, 6, {2} ) --1: TDU, 6: Proposal
																						 )
																				);", query, ppmProtocolNumber, (int)ppmOrganizationType);
			}

			using (var dr = DbHelp.ExecuteDataReaderText(query, null))
			{
				try
				{
					while (dr.Read())
					{
						projectCount++;
						projectId = Convert.ToInt32(dr["projectid"].ToString());
						rmProtocolNumber = dr["ProtocolNumber"].ToString();
						rmProjectOrganizationType = (OrganizationType_E)DbSafe.Int(dr["OrganizationId"]);
						rmOrganizationalUnitId = DbSafe.Int(dr["OrganizationUnitId"]);
						if (rmProjectOrganizationType != OrganizationType_E.TDU) { singleServiceProjectCount++; }
					}
				}
				finally { dr.Close(); }
			}
			//If there is no project found in RM, return 0 which mean new project needs to be created
			if (projectCount == 0)
			{
				return 0;
			}
			else if (projectCount > 1)
			{
				if (queryProtocol)
				{
					if (projectCount == singleServiceProjectCount)
					{
						return 0;
					}
					else
					{
						throw new Exception(string.Format("Multipel projects found with project code {0} and protocol number {1}", ppmProjectCode, rmProtocolNumber));
					}
				}
				return GetExistingProjectId(ppmProjectCode, ppmProtocolNumber, ppmOrganizationType, ppmOrganizationalUnitId, true);
			}
			else
			{
				//Project merge only happens when the RM project or new PPM project is part of TDU organization.We can not merge both ISS and DM project when there is no TDU projects exist
				if (rmProjectOrganizationType == ppmOrganizationType ||
																																																																				OrganizationType_E.TDU.Equals(rmProjectOrganizationType) ||
																																																																				OrganizationType_E.TDU.Equals(ppmOrganizationType) ||
																																																																				(rmProjectOrganizationType == OrganizationType_E.RmSingleService &&
																																																																				 ppmOrganizationType != OrganizationType_E.TDU &&
																																																																				 ppmOrganizationalUnitId == rmOrganizationalUnitId)
																																				 )
				{
					//If project exist for the same organization and new protocol number comes in we should create a new project.For example
					//RM has TDU project whith ProjectCode:ABC,protocol Number:123
					//PPM sends TDU project with ProjectCode:ABC,protocl Number:456,we create new project in RM
					if (rmProjectOrganizationType == ppmOrganizationType && rmProtocolNumber.ToUpper().Trim() != ppmProtocolNumber.ToUpper().Trim())
					{
						return 0;
					}
					else
					{
						return projectId;
					}
				}
				else
				{
					return 0;
				}
			}
		}

		public static int GetProjectIdWithoutOrgSuffix(string projectCode, string protocolNumber, OrganizationType_E organizationType)
		{
			int projectCount = 0;
			int projectId = 0;
			OrganizationType_E rmProjectOrganizationType = OrganizationType_E.TDU;
			var query = string.Format(@"SELECT projectid,ISNULL(OrganizationType,'TDU') as OrganizationType FROM project WHERE ExternalSource='PPM' AND ProjectCode='{0}' AND ISNULL(OrganizationProtocol,ProtocolNumber)='{1}' ", projectCode, protocolNumber);
			using (var dr = DbHelp.ExecuteDataReaderText(query))
			{
				try
				{
					while (dr.Read())
					{
						projectCount++;
						projectId = Convert.ToInt32(dr["projectid"].ToString());
						rmProjectOrganizationType = (OrganizationType_E)Enum.Parse(typeof(OrganizationType_E), dr["OrganizationType"].ToString());
					}
				}
				finally { dr.Close(); }
			}
			if (projectCount != 0)
			{
				if (projectCount > 1)
				{
					return 0;
				}
				else
				{
					if (rmProjectOrganizationType == organizationType || OrganizationType_E.TDU.Equals(rmProjectOrganizationType) || OrganizationType_E.TDU.Equals(organizationType))
					{
						return projectId;
					}
					else
					{
						return 0;
					}
				}
			}
			else
			{
				return 0;
			}
		}

		public static void SetPrimaryCPMforProject(Request request, Resource resource)
		{
			if (request.RequestTypeId != (int)RequestType_E.Proposal)//only or awarded project.
			{
				if (request.ResourceType.Id == (int)ResourceTypeName.Global_CPM)
				{
					string sql = string.Format(@"UPDATE Project SET PrimaryCPM='{0}' Where ProjectId = {1} ", resource.Name.Replace("'", "''"), request.Project.Id);
					DbHelp.ExecuteNonQueryText(sql);
				}
				if (request.ResourceType.Id == (int)ResourceTypeName.Regional_CPM)
				{
					string sql = string.Format(@"UPDATE Project SET PrimaryCPM='{0}' Where (ProjectId = {1} AND (primaryCPM IS NULL OR PrimaryCPM=''))", resource.Name.Replace("'", "''"), request.Project.Id);
					DbHelp.ExecuteNonQueryText(sql);
				}
			}
		}

		/// <summary>
		/// Update the ProtocolNumberCTMS column from ProtocolNumber with special characters stripped.
		/// </summary>
		/// <param name="projectId"></param>
		/// <param name="strippedProtocolNumber"></param>
		public void UpdateCTMSProtocolNumber(string strippedProtocolNumber)
		{
			var sql = string.Format(@"UPDATE Project set ProtocolNumberCTMS='{0}' where projectId={1}", strippedProtocolNumber, Id);
			DbHelp.ExecuteNonQueryText(sql);
		}

		#region GetNotesColumnValue
		public string GetNotesColumnValue()
		{
			bool hasNotes = (EntityComment.FindEntityComments(Id, EntityTypes.Project, false).Count > 0);

			return string.Format(Constants.MessageDiv
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , (EntityComment.FindEntityComments(Id, EntityTypes.Project, false).Count > 0) ? string.Empty : "no_"
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , Id
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , (int)SearchLevel.Project
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , EntityTypes.Project.ToString(), (int)EntityTypes.Project
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , string.Empty, Constants.UnspecifiedId, string.Empty
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , string.Empty, Constants.UnspecifiedId, string.Empty
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , Id, ProjectCode
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , Constants.UnspecifiedId, string.Empty
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , Constants.UnspecifiedId, string.Empty
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			 , string.Empty);
		}
		#endregion

		public static void RefreshBudgetData(int projectId, string qId)
		{
			DbHelp.ExecuteNonQuerySP("UpdateQipCalculatorsWithNewQipDataByProjectId", ConfigValue.QipRefreshCommandTimeout, new SqlParameter("ProjectId", projectId), new SqlParameter("qId", qId));
		}

		#region GetDefaultPPMProjectList
		public static List<ProjectMileStoneUIMap_WS> GetDefaultPPMProjectList()
		{
			List<ProjectMileStoneUIMap_WS> projectMileStoneUIMap = new List<ProjectMileStoneUIMap_WS>();
			string sqlQuery = @"SELECT [ProjectMileStoneUIMapId]
                              ,[MileStoneDisplayName]
                              ,[MileStoneMappedColumnName]
                          FROM [dbo].[ProjectMileStoneUIMap]";

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						projectMileStoneUIMap.Add(new ProjectMileStoneUIMap_WS
						{
							Id = (int)dr["ProjectId"],
							MileStoneDisplayName = dr["MileStoneDisplayName"].ToString(),
							MileStoneMappedColumnName = dr["MileStoneMappedColumnName"].ToString()
						});
					}
				}
				finally { dr.Close(); }
			}
			return projectMileStoneUIMap;
		}
		#endregion

		public static string GetOrganizationShortName(int? organizationId)
		{
			var organization = CacheService.AllOrganizations.Values.FirstOrDefault(o => o.Id == (organizationId ?? 2));
			return organization == null ? null : organization.ShortName;
		}

		public void AutoGenerateAwardedReqeustsFromProposalRequests()
		{
			DbHelp.ExecuteNonQuerySP("AutogenerateRequestsFromProposalRequests", new SqlParameter("ProjectId", Id));
		}

		public void AutoSubmitAwardedReqeustsFromProposalRequests()
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(Request));
			criteria.Add(Expression.Eq("Project.Id", Id))
					.Add(Expression.Eq("RequestTypeId", 8))
					.Add(Expression.IsNull("ParentRequestId"))
					.Add(Expression.Eq("RequestStatusId", (int)RequestStatusName.New));
			List<int> requests = Request.FindAll(criteria).Select(r => r.Id).ToList();
			if (requests != null && requests.Count > 0)
			{
				Request.SubmitRequests(requests, null, false);
			}
		}

		public static Project FindByMonitoringAttributeId(int monitoringAttributeId)
		{
			return DbHelp.RunQuery<Project>(string.Format(@"SELECT TOP 1 P.* 
															FROM
																	Project P
																	JOIN MonitoringAttribute MA ON P.ProjectId = MA.ProjectId
															WHERE	MA.MonitoringAttributeId  = {0}", monitoringAttributeId),
																																																																																																																																																																																																																																																																			"P", null)[0];
		}

		public static Project FindBySsvAttributeId(int ssvAttributeId)
		{
			return DbHelp.RunQuery<Project>(string.Format(@"SELECT TOP 1 P.* 
															FROM
																	Project P
																	JOIN SsvAttribute SA ON P.ProjectId = SA.ProjectId
															WHERE	SA.SsvAttributeId  = {0}", ssvAttributeId),
																																																																																																																																																																																																																																																																			"P", null)[0];
		}

		public static bool HasContractualOrResourcingRequirements(int projectId)
		{
			var sql = string.Format(@"IF EXISTS ( SELECT  P.ProjectId
																					FROM    dbo.Project P
																									INNER JOIN dbo.ResourceRequirements_ProjectJobRoleGroup PJR ON P.ProjectId = PJR.ProjectId
																					WHERE   ResourceRequirementsTypeId IN ( 1, 2 )
																									AND P.ProjectId = {0}
																					UNION
																					SELECT  P.ProjectId
																					FROM    dbo.Project P
																					WHERE   ResourceRequirementsTypeId IN ( 3 )
																									AND P.ProjectId = {0} ) 
																	BEGIN
																			SELECT  1
																	END
															ELSE 
																	BEGIN
																			SELECT  0
																	END", projectId);
			return Convert.ToBoolean(DbHelp.ExecuteScalarText(sql));
		}

		public static string GetFirewalledProjects(int projectId)
		{
			var FirewalledProjectList = new List<string>();
			var sql = string.Format(@"SELECT  Proj.ProjectCode + ' - ' + Proj.ProtocolNumber AS FirewalledProjects
									FROM    Project Proj
									JOIN project_firewalledstudies Pf ON Proj.ProjectId = Pf.firewalledprojectid
									WHERE   Pf.ProjectId = {0}", projectId);
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						FirewalledProjectList.Add(DbSafe.StringValue(dr["FirewalledProjects"]));
					}
				}
				finally { dr.Close(); }
			}
			return string.Join(", ", FirewalledProjectList.ToArray());
		}

		public static Dictionary<int, FirewalledProject_WS> GetProjectsWhichHasFirewalledStudies(List<int> projectIds)
		{
			var firewalledProjects = new Dictionary<int, FirewalledProject_WS>();

			string sqlQuery = string.Format(@"SELECT PFS.ProjectId,P.ProjectCode,P.ProtocolNumber,PFS.FirewalledProjectId,FP.ProjectCode as FirewalledProjectCode,FP.ProtocolNumber as FirewalledProtocolNumber from Project_FirewalledStudies PFS
													INNER JOIN Project FP on PFS.FirewalledProjectId=FP.ProjectId
													INNER JOIN Project P On PFS.ProjectId=P.ProjectId
													WHERE PFS.ProjectId IN({0})
											UNION		
											select PFS.FirewalledProjectId as ProjectId,FP.ProjectCode,FP.ProtocolNumber,PFS.ProjectId as FirewalledProjectId,P.ProjectCode as FirewalledProjectCode,P.ProtocolNumber as FirewalledProtocolNumber from Project_FirewalledStudies PFS
													INNER JOIN Project FP on PFS.FirewalledProjectId=FP.ProjectId
													INNER JOIN Project P On PFS.ProjectId=P.ProjectId
													WHERE PFS.FirewalledProjectId IN({0})", String.Join(",", projectIds.Select(p => p.ToString()).ToArray()));
			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				FirewalledProject_WS firewalledProject;
				try
				{
					while (dr.Read())
					{
						int projectId = DbSafe.Int(dr["projectId"]);
						string projectCode = DbSafe.StringValue(dr["ProjectCode"]);
						string protocolNumber = DbSafe.StringValue(dr["ProtocolNumber"]);

						int firwalledProjectId = DbSafe.Int(dr["FirewalledProjectId"]);
						string firewalledProjectCode = DbSafe.StringValue(dr["FirewalledProjectCode"]);
						string firewalledProtocolNumber = DbSafe.StringValue(dr["FirewalledProtocolNumber"]);

						if (!firewalledProjects.TryGetValue(projectId, out firewalledProject))
						{
							firewalledProject = new FirewalledProject_WS() { project = new ProjectInfo_WS() { Id = projectId, ProjectCode = projectCode, ProtocolNumber = protocolNumber }, fireWalledProjects = new List<ProjectInfo_WS>() };
							firewalledProjects.Add(projectId, firewalledProject);
						}
						firewalledProject.fireWalledProjects.Add(new ProjectInfo_WS() { Id = firwalledProjectId, ProjectCode = firewalledProjectCode, ProtocolNumber = firewalledProtocolNumber });
					}
				}
				finally { dr.Close(); }
			}
			return firewalledProjects;
		}

		public static void SaveFirewalledProjects(int projectId, List<ProjectInfo_WS> projects)
		{
			if (projects.Count() == 0)
			{
				DbHelp.ExecuteNonQueryText(string.Format("DELETE FROM Project_firewalledStudies WHERE ProjectId ={0}", projectId));
			}
			else
			{
				string projectIds = string.Empty;
				foreach (ProjectInfo_WS projectInfo in projects)
				{

					Project project = Project.FindByNameAndProtocol(projectInfo.ProjectCode, projectInfo.ProtocolNumber);
					if (project != null)
					{
						bool projectExist = Project_FirewalledStudies.FindByProjectIdAndFirewalledProjectId(projectId, project.Id);
						if (!projectExist)
						{
							new Project_FirewalledStudies()
							{
								ProjectId = projectId,
								FirewalledProjectId = project.Id
							}.SaveAndFlush();
						}
						projectIds += project.Id + ",";
					}
				}
				DbHelp.ExecuteNonQueryText(string.Format("DELETE FROM Project_FirewalledStudies where ProjectId={0} AND FirewalledProjectId NOT IN({1})", projectId, projectIds.Substring(0, projectIds.Length - 1)));
			}
		}

		internal static bool IsPrimaryCpmOfAtLeastOneProject(string loggedInUserQid)
		{
			return ((int)DbHelp.ExecuteScalarText(string.Format("SELECT COUNT(1) FROM (SELECT TOP 1 1 IsCpm FROM	dbo.Project WHERE IsActive=1 AND PrimaryCPMQId='{0}') CQ", loggedInUserQid))) > 0;
		}

		internal static bool IsPrimaryCpmOfProject(string loggedInUserQid, int projectId)
		{
			return ((int)DbHelp.ExecuteScalarText(string.Format("SELECT COUNT(1) FROM (SELECT TOP 1 1 IsCpm FROM	dbo.Project WHERE PrimaryCPMQId='{0}' AND  ProjectId={1}) CQ", loggedInUserQid, projectId))) > 0;
		}

		public static int? GetOrganizationalUnitId(OrganizationType_E organizationType, string fullyQualifiedPpmOrganizationText)
		{
			int? organizationalUnitId = null;
			if (OrganizationType_E.TDU.Equals(organizationType))
			{
				organizationalUnitId = OrganizationalUnit_PPM.GetRMOrgIdByPPMOrgName(fullyQualifiedPpmOrganizationText);
			}
			else
			{
				var organizationUnit = OrganizationalUnit.FindOneBySuffix(domainAdmin.OrganizationType.GetSuffix(organizationType));
				if (organizationUnit != null)
				{
					organizationalUnitId = organizationUnit.Id;
				}
			}

			return organizationalUnitId;
		}

		public static ValueId_WS GetProjectDetailsByProjectCodePrptocolNumber(string projectCodeProtocol)
		{
			ValueId_WS projectDetails = null;
			var sql = string.Format("Select ProjectId, (ProjectCode + ' - ' + ISNULL(ProtocolNumber,'Not Available')) AS LookupString FROM Project WHERE ProjectCode + ' - ' + ISNULL(ProtocolNumber,'Not Available') = {0} ", DbSafe.EscapeAndSurroundQuote(projectCodeProtocol));
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					if (dr.Read()) { projectDetails = new ValueId_WS(DbSafe.Int(dr["ProjectId"]).ToString(), projectCodeProtocol); }
				}
				finally { dr.Close(); }
			}
			return projectDetails;
		}


		public static DateTime? GetExpectedStartDateFromQip(string opportunityNumber, string protocolNumber)
		{
			DateTime? expectedStartDate = null;
			var sql = @"SELECT  COALESCE(( SELECT TOP 1
																							P.ExpectedStartDate
																		 FROM     dbo.Project P
																		 WHERE    P.ProjectCode = @projectCode
																							AND CASE WHEN P.ProtocolNumber IS NULL
																														OR P.ProtocolNumber = ''
																											 THEN 'Not Available'
																											 ELSE P.ProtocolNumber
																									END = @protocolNumber
																	 ),
																	 ( SELECT TOP 1
																							MilestoneDate AS PreProjectActivities
																		 FROM     dbo.QipProjectMilestone QPMPP
																		 WHERE    QPMPP.ProjectCode = @projectCode
																							AND QPMPP.MilestoneId = @milestoneIdPreProjectActivity
																							AND QPMPP.MilestoneTypeId = @milestoneTypeId
																							AND CASE WHEN QPMPP.ProtocolNumber IS NULL
																														OR QPMPP.ProtocolNumber = ''
																											 THEN 'Not Available'
																											 ELSE QPMPP.ProtocolNumber
																									END = @protocolNumber
																	 ),
																	 ( SELECT TOP 1
																							MilestoneDate AS AwardDate
																		 FROM     dbo.QipProjectMilestone QPMPP
																		 WHERE    QPMPP.ProjectCode = @projectCode
																							AND QPMPP.MilestoneId = @milestoneIdProjectAward
																							AND QPMPP.MilestoneTypeId = @milestoneTypeId
																							AND CASE WHEN QPMPP.ProtocolNumber IS NULL
																														OR QPMPP.ProtocolNumber = ''
																											 THEN 'Not Available'
																											 ELSE QPMPP.ProtocolNumber
																									END = @protocolNumber
																	 )) AS MilestoneDate;";

			using (var dr = DbHelp.ExecuteDataReaderText(sql, new SqlParameter("projectCode", opportunityNumber),
																																																																																																							new SqlParameter("protocolNumber", protocolNumber),
																																																																																																							new SqlParameter("milestoneIdPreProjectActivity", 128), //128: Pre-Project Activities
																																																																																																							new SqlParameter("milestoneIdProjectAward", 1), //1: Project Award
																																																																																																							new SqlParameter("milestoneTypeId", (int)RequestMilestoneType_E.Project)))
			{
				try
				{
					if (dr.Read()) { expectedStartDate = DbSafe.DateTimeNull(dr["MilestoneDate"]); }
				}
				finally { dr.Close(); }
			}
			return expectedStartDate;
		}

		public static List<Project> GetActiveAwardedProjectsForNotification(NotificationConfig notificationConfig)
		{
			var lastNotificationExecutinTime = DateTime.Today.AddDays(-1).AddTicks(ConfigValue.TimeToSendNotifications.Ticks).ToISODateWithTime();
			var sql = string.Format(
																							@"SELECT  DISTINCT
        X.ProjectId
FROM    dbo.NotificationConfig NC
        JOIN dbo.NotificationMilestoneConfig NMSC ON NMSC.NotificationConfigId = NC.NotificationConfigId
                                                     AND NMSC.MilestoneTypeId = 4
        JOIN dbo.ProjectProjectMilestone_XREF X ON X.ProjectMilestoneId = NMSC.MilestoneId
        JOIN dbo.Project P ON P.ProjectId = X.ProjectId
		JOIN dbo.OrganizationalUnit OU ON ou.organizationalUnitId = P.OrganizationUnitId
        JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = P.StudyStatus
WHERE   X.ActualDate IS NULL
        AND SS.SendSgrNotification = 1
        AND X.ProjectedDate IS NOT NULL
		AND ou.OrganizationId != {0}
        AND P.OpportunityStatusId = {1}
        AND NC.NotificationConfigId = {2}
        AND X.ProjectedDate >= '{3}'
        AND ( DATEADD(DAY, NMSC.DaysFromMilestoneDate, X.ProjectedDate) = CAST(GETDATE() AS DATE)
              OR ( X.CreatedOn >= '{4}'
                   AND NMSC.AllowDelayedSend = 1
                   AND NMSC.DaysFromMilestoneDate < 0
                   AND DATEADD(DAY, NMSC.DaysFromMilestoneDate,
                               CAST(GETDATE() AS DATE)) < ProjectedDate
                 )
            );",
			(int)Organization_E.Real_World_Evidence,
			(int)OpportunityStatus_E.Closed_Won,
			notificationConfig.Id,
			ConfigValue.NotificationCutoffDate.ToISODate(),
			lastNotificationExecutinTime);

			var projectIdList = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read()) { projectIdList.Add(DbSafe.Int(dr["ProjectId"])); }
				}
				finally { dr.Close(); }
			}
			var dc = DetachedCriteria.For<Project>()
					.Add(Expression.Eq("IsActive", true))
					.Add(Expression.Eq("OpportunityStatusId", (int)OpportunityStatus_E.Closed_Won))
					.Add(Expression.In("Id", projectIdList.ToArray()));
			return Project.FindAll(dc).ToList();
		}

		internal SchedulableMilestone GetMilestoneDate(NotificationMilestoneConfig milestoneConfig)
		{
			var milestone = new SchedulableMilestone();
			var projectMilestone = ProjectProjectMilestone.FindByProjectIdAndMilestoneId(Id, milestoneConfig.MilestoneId);

			if (projectMilestone != null)
			{
				milestone.ProjectedDate = projectMilestone.ProjectedDate;
				milestone.ContractedDate = projectMilestone.ContractedDate;
				milestone.ActualDate = projectMilestone.ActualDate;
				milestone.CreatedOn = projectMilestone.CreatedOn;
			}

			return milestone;
		}

		public Dictionary<string, string> GetPlaceholderValueDistionaryForAlerts(SchedulableMilestone milestone)
		{
			var placeholderDictionary = new Dictionary<string, string>
			{
				{ Constants.ContentPlaceholder.ProjectCode, ProjectCode },
				{ Constants.ContentPlaceholder.Protocol, string.IsNullOrEmpty(ProtocolNumber50)? Constants.NotAvailableProtocol: ProtocolNumber50 },
				{ Constants.ContentPlaceholder.ProtocolFull, string.IsNullOrEmpty(ProtocolNumber)? Constants.NotAvailableProtocol: ProtocolNumber },
				{ Constants.ContentPlaceholder.PrimaryCpm, PrimaryCPM },
				{ Constants.ContentPlaceholder.PrimaryCpmQid, PrimaryCPMQId },
				{ Constants.ContentPlaceholder.ProjectOwner, ProjectOwner },
				{ Constants.ContentPlaceholder.ProjectOwnerQid, ProjectOwnerQId },
				{ Constants.ContentPlaceholder.ProjectStatus, ProjectStatus },
				{ Constants.ContentPlaceholder.ProjectOrganizationalUnit, OrganizationalUnit.Name },
				{ Constants.ContentPlaceholder.ProjectOrganization, OrganizationalUnit.Organization.Name },
				{ Constants.ContentPlaceholder.KickOffMeetingDate, KickOffMeetingDate.ToQDateString() },
				{ Constants.ContentPlaceholder.QrpmPpmTeamListUrl, PpmTeamListUrl },
				{ Constants.ContentPlaceholder.QrpmRmProjectSummaryUrl, RmPageLink.GetFullyqualifiedUrlById(RmPageLink_E.ProjectSummary) },
				{ Constants.ContentPlaceholder.QrpmDemandPlannerEmailAddress, ConfigValue.QrpmDemandPlannerEmailAddress },
				{ Constants.ContentPlaceholder.QrpmSupporTeamEmailAddress, ConfigValue.QrpmSupporTeamEmailAddress },
				{ Constants.ContentPlaceholder.QrpmPpmActionTrackerUrl, PpmActionTrackerUrl },
				{ Constants.ContentPlaceholder.QrpmRmProjectSiteListUrl, string.Format("{0}?&projectCode={1}&protocolNumber={2}",RmPageLink.GetFullyqualifiedUrlById(RmPageLink_E.ProjectSiteList),ProjectCode,ProtocolNumber50) }
			};

			if (milestone != null)
			{
				placeholderDictionary.Add(Constants.ContentPlaceholder.SgrMilestoneDate, milestone.ProjectedDate.ToQDateString());
			}

			return placeholderDictionary;
		}

		public static FirewalledProjectsResponse GetFirewalledProjects()
		{
			var filewalledProjects = new Dictionary<int, ProjectDetail>();

			var sql = @"SELECT  DISTINCT
													P.ProjectId ,
													P.ProjectCode ,
													P.ProtocolNumber ,
													P.ExternalId ,
													FP.ProjectId AS FirewalledProjectId ,
													FP.ProjectCode FirewalledProjectCode ,
													FP.ProtocolNumber FirewalledProtocolNumber ,
													FP.ExternalId FirewalledExternalId
									FROM    dbo.Project_FirewalledStudies FS
													JOIN dbo.Project P ON P.ProjectId = FS.ProjectId
													JOIN dbo.Project FP ON FP.ProjectId = FS.FirewalledProjectId
									UNION
									SELECT DISTINCT
													P.ProjectId ,
													P.ProjectCode ,
													P.ProtocolNumber ,
													P.ExternalId ,
													FP.ProjectId AS FirewalledProjectId ,
													FP.ProjectCode FirewalledProjectCode ,
													FP.ProtocolNumber FirewalledProtocolNumber ,
													FP.ExternalId FirewalledExternalId
									FROM    dbo.Project_FirewalledStudies FS
													JOIN dbo.Project P ON P.ProjectId = FS.FirewalledProjectId
													JOIN dbo.Project FP ON FP.ProjectId = FS.ProjectId;";

			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						var projectId = DbSafe.Int(dr["ProjectId"]);
						ProjectDetail projectDetail;
						if (!filewalledProjects.TryGetValue(projectId, out projectDetail))
						{
							projectDetail = new ProjectDetail
							{
								ProjectId = projectId,
								ProjectCode = DbSafe.StringValue(dr["ProjectCode"]),
								ProtocolNumber = DbSafe.StringValue(dr["ProtocolNumber"]),
								ExternalId = DbSafe.StringValue(dr["ExternalId"])
							};
							filewalledProjects.Add(projectId, projectDetail);
						}

						projectDetail.FirewalledProjectList.Add(new FirewalledProjectDetail
						{
							ProjectId = DbSafe.Int(dr["FirewalledProjectId"]),
							ProjectCode = DbSafe.StringValue(dr["FirewalledProjectCode"]),
							ProtocolNumber = DbSafe.StringValue(dr["FirewalledProtocolNumber"]),
							ExternalId = DbSafe.StringValue(dr["FirewalledExternalId"])
						});
					}
				}
				finally
				{
					dr.Close();
				}
			}

			return (filewalledProjects.Count == 0) ? null : new FirewalledProjectsResponse { ProjectList = filewalledProjects.Values.ToList() };
		}

		internal static List<Project> GetProjectsWithSgr3CriticalStopCriteria(NotificationConfig notificationConfig, Organization_E organization, DateTime cutoffDate)
		{
			var sql = string.Format(
@"SELECT  DISTINCT
        P.ProjectId
FROM    dbo.ProjectReviewItem PRI
        JOIN dbo.Project P ON P.ProjectId = PRI.ProjectId
        JOIN dbo.OrganizationalUnit OU ON P.OrganizationUnitId = OU.OrganizationalUnitId
        JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = P.StudyStatus
        LEFT JOIN dbo.NotificationSentSemaphore NSS ON NSS.EntityId = P.ProjectId
                                                       AND NSS.EntityTypeId = {0}
                                                       AND NSS.NotificationConfigId = {1}
WHERE   OU.OrganizationId = {2}
        AND PRI.ProjectReviewLevelId = {3}
        AND ( PRI.RevisedIppmExecSumProjExecPlanAndKeyRef = 0
              OR PRI.ProjectReviewOutcomeTypeId = {4}
            )
        AND NSS.Id IS NULL
        AND SS.SendSgrNotification = 1
				AND P.IsActive = 1
				AND P.OpportunityStatusId = {5}
				AND PRI.DateOfReview >= '{6}'",
			(int)EntityTypes.Project,
			notificationConfig.Id,
			(int)organization,
			(int)ProjectReviewLevel_E.Sgr_Stage_Gate_Review_3,
			(int)ProjectReviewOutcomeType_E.SGR_Not_Approved,
			(int)OpportunityStatus_E.Closed_Won,
			cutoffDate.ToISODate());

			var projectIdList = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read()) { projectIdList.Add(DbSafe.Int(dr["ProjectId"])); }
				}
				finally { dr.Close(); }
			}

			var dc = DetachedCriteria.For<Project>()
					.Add(Expression.Eq("IsActive", true))
					.Add(Expression.Eq("OpportunityStatusId", (int)OpportunityStatus_E.Closed_Won))
					.Add(Expression.In("Id", projectIdList.ToArray()));

			return Project.FindAll(dc).ToList();
		}

		internal static List<Project> GetTmaAssignedMedicalProjectsWithDblInCurrentMonth(List<int> resourceTypeIdList)
		{
			var sql = string.Format(@"SELECT  P.ProjectId
															FROM    dbo.Project P
																			JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = P.StudyStatus
																			JOIN dbo.ProjectProjectMilestone_XREF PPMX ON PPMX.ProjectId = P.ProjectId
																			JOIN dbo.Request R ON R.ProjectId = P.ProjectId
																			JOIN dbo.ResourceRequestAssignment_XREF RRX ON RRX.RequestId = R.RequestId
															WHERE   PPMX.ProjectMilestoneId = 2
																			AND SS.AlternateSendNotificationFlag = 1
																			AND R.ResourceTypeId IN ( {0} )
																			AND P.Scope LIKE '%medical%'
																			AND R.RequestStatusId IN ({1}, {2}, {3})
																			AND COALESCE(ActualDate, ProjectedDate, ContractedDate) IS NOT NULL
																			AND COALESCE(ActualDate, ProjectedDate, ContractedDate) BETWEEN DATEADD(DAY,
																																														1,
																																														EOMONTH(GETDATE(),
																																														-1))
																																														AND
																																														EOMONTH(GETDATE(),
																																														0)
															GROUP BY P.ProjectId
															HAVING  COUNT(R.RequestId) > 0;",
																																																			string.Join(",", resourceTypeIdList.Select(rt => rt.ToString()).ToArray()),
																																																			(int)RequestStatusName.Assigned,
																																																			(int)RequestStatusName.Backfilled,
																																																			(int)RequestStatusName.Closed);

			var projectIdList = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read()) { projectIdList.Add(DbSafe.Int(dr["ProjectId"])); }
				}
				finally { dr.Close(); }
			}

			var dc = DetachedCriteria.For<Project>().Add(Expression.In("Id", projectIdList.ToArray()));
			return Project.FindAll(dc).ToList();
		}


		public int GetSiteCountFromMonitoringAttrbute()
		{
			return MonitoringAttribute.FindAllActiveByProjectId(Id).Sum(s => s.BudgetedSites.GetValueOrDefault());
		}

		public DateTime? GetAwardDate()
		{
			return ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_Project_Award).Value.ToDateFromQDateString();
		}

		public DateTime? GetFirstSiteInitiatedDate()
		{
			return ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_First_Site_Initiated).Value.ToDateFromQDateString();
		}

		public DateTime? GetFirstSubjectRandomizedDate()
		{
			return ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_First_Subject_Randomized).Value.ToDateFromQDateString();
		}
		public DateTime? GetLastSubjectInDate()
		{
			var lastSubjectIn = ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_Last_Subject_Randomized).Value.ToDateFromQDateString();
			if (!lastSubjectIn.HasValue)
			{
				lastSubjectIn = ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_Last_Subject_Enrolled).Value.ToDateFromQDateString();
			}
			if (!lastSubjectIn.HasValue)
			{
				lastSubjectIn = ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_Last_Subject_Screened).Value.ToDateFromQDateString();
			}
			return lastSubjectIn;
		}
		public DateTime? GetFirstSubjectInDate()
		{
			var firstSubjectIn = ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_First_Subject_Randomized).Value.ToDateFromQDateString();
			if (!firstSubjectIn.HasValue)
			{
				firstSubjectIn = ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_First_Subject_Enrolled).Value.ToDateFromQDateString();
			}
			if (!firstSubjectIn.HasValue)
			{
				firstSubjectIn = ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_First_Subject_Screened).Value.ToDateFromQDateString();
			}
			return firstSubjectIn;
		}
		public DateTime? GetLastSubjectOutDate()
		{
			return ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_Last_Subject_Out_LPLV).Value.ToDateFromQDateString();
		}
		public DateTime? GetCovDate()
		{
			return ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_Last_Site_Closed).Value.ToDateFromQDateString();
		}

		public DateTime? GetDblDate()
		{
			return ProjectMilestoneList.FirstOrDefault(m => m.Key == (int)ProjectMilestone_E.KEY_Database_Lock).Value.ToDateFromQDateString();
		}
		public string GetFsiCovDurationWeeks()
		{
			var durationWeeks = string.Empty;
			var fsiMilestoneDate = GetFirstSubjectRandomizedDate();
			var covMilestoneDate = GetCovDate();
			if (fsiMilestoneDate.HasValue && covMilestoneDate.HasValue)
			{
				durationWeeks = Math.Round((covMilestoneDate.GetValueOrDefault() - fsiMilestoneDate.GetValueOrDefault()).TotalDays / 7, 0).ToString();
			}
			return durationWeeks;
		}

		public static SiteVisitCount_WS GetDteSiteVisitCount(int projectId, int tierCycle, int onsiteVisitRatio, int remoteVisitRatio, decimal targetSitePercentage, bool isPharmacy)
		{
			var project = FindById(projectId);
			if (project == null)
			{
				throw new RMException(string.Format("Project Id {0} not found", projectId));
			}
			return GetDteSiteVisitCount(project, tierCycle, onsiteVisitRatio, remoteVisitRatio, targetSitePercentage, isPharmacy);
		}
		public static SiteVisitCount_WS GetDteSiteVisitCount(Project project, int tierCycle, int onsiteVisitRatio, int remoteVisitRatio, decimal targetSitePercentage, bool isPharmacy)
		{
			var fsiMilestoneDate = project.GetFirstSubjectRandomizedDate();
			var covMilestoneDate = project.GetCovDate();
			if (fsiMilestoneDate.HasValue && covMilestoneDate.HasValue)
			{
				var projectSchemaConfig = new ProjectSchemaDetails_WS();
				(isPharmacy ? projectSchemaConfig.PharmacySchemaDetails : projectSchemaConfig.SiteMonitoringSchemaDetails).TierList.Add(new VisitSchemaLevelInfo_WS { TierCycle = tierCycle, OnSiteVisitRatio = onsiteVisitRatio, RemoteVisitRatio = remoteVisitRatio, TargetSitePercentage = targetSitePercentage });

				var visitCounts = MonitoringAttribute.GetProjectedVisitCountForAllActiveMonitoringCountries(project.Id, projectSchemaConfig);
				return new SiteVisitCount_WS(visitCounts.IntSivVisitCount, visitCounts.IntCovVisitCount, visitCounts.IntOnsiteImvVisitCount + visitCounts.IntPharmacyVisitCount, visitCounts.IntRemoteVisitCount);
			}
			else
			{
				throw new RMException(string.Format("Following milestones are missing in PPM: {0}", (!fsiMilestoneDate.HasValue && !covMilestoneDate.HasValue) ? "First Subject Randomized, Last Site Closed" : !fsiMilestoneDate.HasValue ? "First Subject Randomized" : "Last Site Closed"));
			}
		}

		public string GetBudgetVersion()
		{
			var qipVersion = string.Empty;
			var qipStatus = string.Empty;
			var qipIteration = string.Empty;

			if (!string.IsNullOrEmpty(QipClinicalVersion))
			{
				qipVersion = QipClinicalVersion;
				qipStatus = QipClinicalStatus;
				qipIteration = QipClinicalIteration;
			}
			else if (!string.IsNullOrEmpty(QipOtherVersion))
			{
				qipVersion = QipOtherVersion;
				qipStatus = QipOtherStatus;
				qipIteration = QipOtherIteration;
			}
			else if (!string.IsNullOrEmpty(QipRegionalVersion))
			{
				qipVersion = QipRegionalVersion;
				qipStatus = QipRegionalStatus;
				qipIteration = QipRegionalIteration;
			}
			else if (!string.IsNullOrEmpty(QipGlobalVersion))
			{
				qipVersion = QipGlobalVersion;
				qipStatus = QipGlobalStatus;
				qipIteration = QipGlobalIteration;
			}

			var iteration = string.IsNullOrEmpty(qipIteration) ?
								string.Empty :
												(qipIteration.IndexOf(".") != -1) ?
																qipIteration.Split('.')[0] :
																				qipIteration;

			if (!string.IsNullOrEmpty(qipVersion) || !string.IsNullOrEmpty(qipStatus) || !string.IsNullOrEmpty(iteration))
			{
				return string.Format("{0}, {1}, {2}", qipVersion, qipStatus, iteration);
			}
			else { return "N/A"; }
		}

		internal int GetFsiCovDifferenceInWeeks()
		{
			return Convert.ToInt32((LastSiteClosedDate.GetValueOrDefault() - GetFirstSubjectRandomizedDate().GetValueOrDefault()).Days / 7);
		}

		public DateTime GetStartDateByCalculatorTypeId(CalculatorType_E calculatorType_E, MonitoringAttribute monitoringAttr, SSVAttribute ssvAttr)
		{
			DateTime date = DateTime.MinValue;
			switch (calculatorType_E)
			{
				case CalculatorType_E.SIV:
					if (monitoringAttr == null)
					{
						date = GetFirstSiteInitiatedDate().GetValueOrDefault();
					}
					else
					{
						date = monitoringAttr.MonitoringAttributeStartDate.GetValueOrDefault();
					}
					break;
				case CalculatorType_E.SIV_FPI:
					if (monitoringAttr == null)
					{
						date = GetFirstSiteInitiatedDate().GetValueOrDefault().AddDays(1);
					}
					else
					{
						date = monitoringAttr.MonitoringAttributeStartDate.GetValueOrDefault().AddDays(1);
					}
					break;
				case CalculatorType_E.PharmacyMonitoring:
				case CalculatorType_E.IMV_Freq1_FPI_LPI:
				case CalculatorType_E.FSI_COV:
					if (monitoringAttr == null)
					{
						date = GetFirstSubjectRandomizedDate().GetValueOrDefault().AddDays(1);
					}
					else
					{
						date = monitoringAttr.MonitoringAttributeStartDate.GetValueOrDefault().AddDays(2 + (SivFsiWeeks.GetValueOrDefault() * 7));
					}
					break;
				case CalculatorType_E.IMV_Freq2_LPI_LPO:
					date = GetLastSubjectInDate().GetValueOrDefault().AddDays(1);
					break;
				case CalculatorType_E.IMV_Freq34_LPO_DBL:
				case CalculatorType_E.LSO_COV:
					date = GetLastSubjectOutDate().GetValueOrDefault().AddDays(1);
					break;
				case CalculatorType_E.IMV_Freq4_LPO_DBL:
					date = DatabaseLockDate.GetValueOrDefault().AddDays(1);
					break;
				case CalculatorType_E.COV:
					date = LastSiteClosedDate.GetValueOrDefault();
					break;
				case CalculatorType_E.SS_SIV:
					if (ssvAttr == null)
					{
						date = FirstSiteSelectedDate.GetValueOrDefault();
					}
					else
					{
						date = ssvAttr.SSVAttributeStartDate.GetValueOrDefault();
					}
					break;
				default:
					throw new Exception(string.Format("Unsupported calculator Type sent. id:{0}, Name: {1}", (int)calculatorType_E, calculatorType_E.GetEnumDescription()));
			}
			return date;
		}

		public DateTime GetStopDateByCalculatorTypeId(CalculatorType_E calculatorType_E, MonitoringAttribute monitoringAttr)
		{
			DateTime date = DateTime.MinValue;
			switch (calculatorType_E)
			{
				case CalculatorType_E.SS_SIV:
					if (monitoringAttr == null)
					{
						date = GetFirstSiteInitiatedDate().GetValueOrDefault();
					}
					else
					{
						date = monitoringAttr.MonitoringAttributeStartDate.GetValueOrDefault();
					}

					if (date != DateTime.MinValue)
					{
						date = date.AddDays(-1);
					}
					break;
				case CalculatorType_E.SIV:
					if (monitoringAttr == null)
					{
						date = GetFirstSiteInitiatedDate().GetValueOrDefault();
					}
					else
					{
						date = monitoringAttr.MonitoringAttributeStartDate.GetValueOrDefault();
					}
					break;
				case CalculatorType_E.SIV_FPI:
					if (monitoringAttr == null)
					{
						date = GetFirstSubjectRandomizedDate().GetValueOrDefault();
					}
					else
					{
						date = monitoringAttr.MonitoringAttributeStartDate.GetValueOrDefault().AddDays(1 + (SivFsiWeeks.GetValueOrDefault() * 7));
					}
					break;
				case CalculatorType_E.IMV_Freq1_FPI_LPI:
					date = GetLastSubjectInDate().GetValueOrDefault();
					break;
				case CalculatorType_E.IMV_Freq2_LPI_LPO:
					date = GetLastSubjectOutDate().GetValueOrDefault();
					break;
				case CalculatorType_E.IMV_Freq34_LPO_DBL:
					date = DatabaseLockDate.GetValueOrDefault();
					break;
				case CalculatorType_E.COV:
					date = LastSiteClosedDate.GetValueOrDefault();
					break;
				case CalculatorType_E.FSI_COV:
				case CalculatorType_E.LSO_COV:
				case CalculatorType_E.PharmacyMonitoring:
				case CalculatorType_E.IMV_Freq4_LPO_DBL:
					if (LastSiteClosedDate.HasValue)
					{
						date = LastSiteClosedDate.GetValueOrDefault().AddDays(-1);
					}
					else
					{
						date = DateTime.MinValue;
					}
					break;
				default:
					throw new Exception(string.Format("Unsupported calculator Type sent. id:{0}, Name: {1}", (int)calculatorType_E, calculatorType_E.GetEnumDescription()));
			}
			return date;
		}

		public bool IsRequiredTierEnabledForInitialSiteTiering(out string requiredTierId)
		{
			var requiredTiersEnabled = true;
			requiredTierId = string.Empty;

			var requiredTier = CacheService.Tier.Values.FirstOrDefault(t => t.RequiredForInitialTiering);

			if (requiredTier != null)
			{
				var activeTierList = GetActiveTierListByProjectId(Id);
				if (activeTierList.SiteMonitoringTierList == null || activeTierList.SiteMonitoringTierList.Count(t => t.Key == requiredTier.Id) == 0)
				{
					requiredTiersEnabled = false;
				}
				else if (activeTierList.PharmacyTierList != null && activeTierList.PharmacyTierList.Count != 0 && activeTierList.PharmacyTierList.Count(t => t.Key == requiredTier.Id) == 0)
				{
					requiredTiersEnabled = false;
				}
			}
			return requiredTiersEnabled;
		}

		public bool IsIntialTieringAllowed()
		{
			var isIntialTieringAllowed = false;
			if (HasUserDefinedSchema && !InitialTieringPerformed && IsDteProject)
			{
				string tierName;
				isIntialTieringAllowed = IsRequiredTierEnabledForInitialSiteTiering(out tierName);
			}
			return isIntialTieringAllowed;
		}

		public static EntityExecutionStatus<string> PerformInitiatSiteTiering(int projectId)
		{
			var response = new EntityExecutionStatus<string>();
			var project = Project.Find(projectId);
			try
			{
				new InitialSiteTieringEngine(project).PerformInitiatlSiteTiering();
			}
			catch (RMException ex)
			{
				response.Errors.Add(new ValidationMessage_WS("", ex.Message, MessageType_E.SharepointNotification));
			}
			return response;
		}

		public static ProjectTierList_WS GetActiveTierListByProjectId(int projectId)
		{
			var result = new ProjectTierList_WS();
			var sql = @"SELECT  VSLTX.CalculatorTypeId ,
													T.TierId ,
													T.Name TierName
									FROM    dbo.VisitSchemaLevelTier_Xref VSLTX
													JOIN dbo.Tier T ON T.TierId = VSLTX.TierId
									WHERE   VSLTX.ProjectId = @projectId
									ORDER BY VSLTX.CalculatorTypeId ,
													TierName";
			using (var dr = DbHelp.ExecuteDataReaderText(sql, new SqlParameter("@projectId", projectId)))
			{
				try
				{
					while (dr.Read())
					{
						var tierList = ((CalculatorGroup_E)DbSafe.Int(dr["CalculatorTypeId"]) == CalculatorGroup_E.DTEPharmacyCalculator) ? result.PharmacyTierList : result.SiteMonitoringTierList;
						tierList.Add(new KeyValue_WS(DbSafe.Int(dr["TierId"]), DbSafe.StringValue(dr["TierName"])));
					}
				}
				finally { dr.Close(); }

			}

			return result;
		}

		public bool AreMilestonesValidByCalcualtorGroupAndDteType(out string error)
		{
			var areMilestonesValid = true;
			error = string.Empty;
			var frequencyList = CalculatorTfteType.GetCalculatorTypeIdsByCalculatorGroup(IsDteProject ? CalculatorGroup_E.DTEMonitoringCalculator : CalculatorGroup_E.MonitoringCalculator);
			foreach (var frequency in frequencyList)
			{
				var startDate = GetStartDateByCalculatorTypeId((CalculatorType_E)frequency.FTEType.Id, null, null);
				var stopDate = GetStopDateByCalculatorTypeId((CalculatorType_E)frequency.FTEType.Id, null);
				if (startDate > stopDate)
				{
					error = string.Format("{0}[{1}]: Start Date [{2}] is later than Stop Date [{3}]<br/>", error, frequency.FTEType.AlternateName, startDate.ToQDateString(), stopDate.ToQDateString());
					areMilestonesValid = false;
				}
			}
			return areMilestonesValid;
		}

		internal static Project[] GetProjectsWithKom_Success_Criteria()
		{
			var projectIdList = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText(@"SELECT  DISTINCT PRI.ProjectId
																										 FROM    dbo.ProjectReviewItem PRI
																														 JOIN dbo.Project P ON P.ProjectId = PRI.ProjectId
																														 JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = P.StudyStatus
																														 JOIN dbo.OrganizationalUnit OU ON OU.OrganizationalUnitId = P.OrganizationUnitId
																										 WHERE   SS.SendSgrNotification = 1
																														 AND OU.OrganizationId = 2 --Project Leadersip
																														 AND ProjectReviewLevelId = 5	--SGR (Stage Gate Review) 2
																														 AND CAST(PRI.CreatedOn AS DATE) = CAST(GETDATE() AS DATE);"))
			{
				try
				{
					while (dr.Read()) { projectIdList.Add(DbSafe.Int(dr["ProjectId"])); }
				}
				finally { dr.Close(); }
			}

			return Project.FindAll(DetachedCriteria.For<Project>().Add(Expression.In("Id", projectIdList.ToArray())));
		}

		internal static Project[] GetProjectsWithIncomplete_PPM_Metrics(out Dictionary<int, List<string>> countriesByProject)
		{
			countriesByProject = new Dictionary<int, List<string>>();
			using (var dr = DbHelp.ExecuteDataReaderText(@"SELECT  AP.ProjectId ,
																	C.Name AS Country
													FROM    dbo.MonitoringAttribute MA
																	JOIN dbo.Country C ON C.CountryId = MA.CountryId
																	JOIN ( SELECT   P.ProjectId ,
																									DATEDIFF(DAY,
																													COALESCE(PMX.ActualDate, PMX.ProjectedDate,
																																	PMX.ContractedDate), GETDATE()) DaysSinceAward
																					FROM    dbo.Project P
																									JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = P.StudyStatus
																									JOIN dbo.ProjectProjectMilestone_XREF PMX ON PMX.ProjectId = P.ProjectId
																																												AND PMX.ProjectMilestoneId = 1--Key.Award 
																					WHERE    SS.SendSgrNotification = 1
																									AND P.OpportunityStatusId = 2--Awarded
																				) AP ON AP.ProjectId = MA.ProjectId
																								AND ( AP.DaysSinceAward = 60
																											OR ( AP.DaysSinceAward > 60
																													AND AP.DaysSinceAward % 30 = 0
																												)
																										)
													WHERE   MA.IsActive = 1
																	AND COALESCE(MA.BudgetedSites, 0) = 0;"))
			{
				try
				{
					while (dr.Read())
					{
						var projectId = DbSafe.Int(dr["ProjectId"]);
						List<string> countryList;
						if (!countriesByProject.TryGetValue(projectId, out countryList))
						{
							countryList = new List<string>();
							countriesByProject.Add(projectId, countryList);
						}
						countryList.Add(DbSafe.StringValue(dr["Country"]));
					}
				}
				finally { dr.Close(); }
			}

			return Project.FindAll(DetachedCriteria.For<Project>().Add(Expression.In("Id", countriesByProject.Keys.ToArray())));
		}

		internal static Project[] GetProjectsWithMissingPrimaryCl()
		{
			var projectIdList = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText(@"SELECT P.ProjectId
																											FROM   dbo.Project P
																															JOIN dbo.cd_StudyStatus SS ON P.StudyStatus = SS.StudyStatusName
																															JOIN dbo.ProjectProjectMilestone_XREF PPMSX ON PPMSX.ProjectId = P.ProjectId
																															JOIN dbo.OrganizationalUnit OU ON OU.OrganizationalUnitId = P.OrganizationUnitId
																															JOIN dbo.Organization O ON O.OrganizationId = OU.OrganizationId
																															LEFT JOIN dbo.ProjectPrimaryCl_View PCLV ON PCLV.ProjectId = P.ProjectId
																											WHERE  P.StopMissingPrimaryClAlerts = 0
																															AND O.IsProjectLeadership = 1
																															AND SS.SendSgrNotification = 1
																															AND PPMSX.ProjectMilestoneId = @kickoffMeetingMilestoneId
																															AND COALESCE(PPMSX.ActualDate, PPMSX.ProjectedDate,
																																					PPMSX.ContractedDate) < CAST(GETDATE() AS DATE)
																															AND DATEDIFF(DAY, GETDATE(),
																																					COALESCE(PPMSX.ActualDate, PPMSX.ProjectedDate,
																																										PPMSX.ContractedDate)) % 7 = 0
																															AND PCLV.ProjectId IS NULL
																															AND P.ExternalSource ='PPM';", new SqlParameter("kickoffMeetingMilestoneId", (int)ProjectMilestone_E.KEY_Kick_Off_Meeting)))
			{
				try
				{
					while (dr.Read()) { projectIdList.Add(DbSafe.Int(dr["ProjectId"])); }
				}
				finally { dr.Close(); }
			}

			return Project.FindAll(DetachedCriteria.For<Project>().Add(Expression.In("Id", projectIdList.ToArray())));
		}

		internal static List<Project> GetProjectsWithMissingPeriodicTierReview()
		{
			var projectIdList = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText(
						@"SELECT DISTINCT
							P.ProjectId
			FROM    dbo.Project P
							JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = P.StudyStatus
							LEFT JOIN ( SELECT  PPS.ProjectId ,
																	DATEDIFF(DAY, MAX(STCH.LastModifiedOn), @today) AS DaysSinceInitialTiering
													FROM    SiteTierChangeHistory STCH
																	JOIN SiteTierChangeHistoryReason_XREF STCHX ON STCH.SiteTierChangeHistoryId = STCHX.SiteTierChangeHistoryId
																	JOIN dbo.ProjectProtocolSite PPS ON PPS.SiteId = STCH.SiteId
													WHERE   STCHX.SiteTierChangeReasonId = @siteTierChangeReasonId
													GROUP BY PPS.ProjectId
												) ISTD ON P.ProjectId = ISTD.ProjectId
							LEFT  JOIN ( SELECT PPSTRH.ProjectId ,
																	DATEDIFF(DAY, MAX(LastModifiedOn), @today) AS DaysSinceLastMonthlyTierReview
													 FROM   dbo.PeriodicProjectSiteTierReviewHistory PPSTRH
													 GROUP BY PPSTRH.ProjectId
												 ) PPSTRMD ON P.ProjectId = PPSTRMD.ProjectId
			WHERE   P.IsActive = 1
							AND SS.SendSgrNotification = 1
							AND P.RegularTierReviewRequired = 1
							AND P.PpmDteType = 1
							AND P.ProjectDteType = 1
							AND ( ( PPSTRMD.ProjectId IS NULL
											AND ( ISTD.DaysSinceInitialTiering = @initialEmailAfterDays
														OR ( ISTD.DaysSinceInitialTiering > @initialEmailAfterDays
																 AND ( ( ISTD.DaysSinceInitialTiering
																				 - @initialEmailAfterDays )
																			 % @resentEveryNDays ) = 0
															 )
													)
										)
										OR ( PPSTRMD.DaysSinceLastMonthlyTierReview = @initialEmailAfterDays )
										OR ( PPSTRMD.DaysSinceLastMonthlyTierReview > @initialEmailAfterDays
												 AND ( PPSTRMD.DaysSinceLastMonthlyTierReview
															 - @initialEmailAfterDays ) % @resentEveryNDays = 0
											 )
									);",
									new SqlParameter("@today", DateTime.Today),
									new SqlParameter("@initialEmailAfterDays", 45),
									new SqlParameter("@resentEveryNDays", 7),
									new SqlParameter("@SiteTierChangeReasonId", (int)SiteTierChangeReason_E.Initial_Site_Tiering)))
			{
				try
				{
					while (dr.Read()) { projectIdList.Add(DbSafe.Int(dr["ProjectId"])); }
				}
				finally { dr.Close(); }
			}

			var dc = DetachedCriteria.For<Project>().Add(Expression.In("Id", projectIdList.ToArray()));
			return Project.FindAll(dc).ToList();
		}

		internal static List<Project> GetProjectsWithInitialSiteTieringDue()
		{
			var projectIdList = new List<int>();
			using (var dr = DbHelp.ExecuteDataReaderText(
			@"SELECT DISTINCT
											P.ProjectId
							FROM    dbo.Project P
											JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = P.StudyStatus
							--=================================================================================================
							--Determine if last email date
											LEFT JOIN ( SELECT  NSSI.EntityId ,
																					MAX(NSSI.CreatedOn) AS EmailLastSentOn
																	FROM    dbo.NotificationSentSemaphore NSSI
																	WHERE   NSSI.NotificationConfigId = @notificationConfigId
																					AND NSSI.EntityTypeId = 1 --Project
																	GROUP BY NSSI.EntityId
																) NSS ON NSS.EntityId = P.ProjectId 
							--=================================================================================================
							--Determine Projected site Count
											LEFT JOIN ( SELECT  ProjectId ,
																					SUM(BudgetedSites) AS TotalProjectedInitiatedSites
																	FROM    dbo.MonitoringAttribute
																	WHERE   IsActive = 1
																	GROUP BY ProjectId
																) BSC ON BSC.ProjectId = P.ProjectId
							--=================================================================================================
							--Determine actual site Count
											LEFT JOIN ( SELECT  ProjectId ,
																					SUM(ActualActiveSiteCount) AS TotalActualActiveSiteCount
																	FROM    dbo.ActiveSiteCountByProjectAndCountry_View
																	GROUP BY ProjectId
																) ASCBPC ON ASCBPC.ProjectId = P.ProjectId
							--=================================================================================================
							--Determine laste tier review date
											LEFT  JOIN ( SELECT PPSTRH.ProjectId ,
																					MAX(LastModifiedOn) AS LastMonthlyTierReviewDate
																	 FROM   dbo.PeriodicProjectSiteTierReviewHistory PPSTRH
																	 GROUP BY PPSTRH.ProjectId
																 ) MonthlyReviewPerformed ON P.ProjectId = MonthlyReviewPerformed.ProjectId
							--=================================================================================================
							--Determine First subject date
											LEFT JOIN ( SELECT  PVT.ProjectId ,
																					COALESCE(FirstSubjectRandomized,
																									 FirstSubjectEnrolled,
																									 FirstSubjectScreened) AS FirstSubjectInDate
																	FROM    ( SELECT    ProjectId ,
																											COALESCE(PMSX.ActualDate,
																															 PMSX.ProjectedDate,
																															 PMSX.ContractedDate) AS MilestoneDate ,
																											CASE PMSX.ProjectMilestoneId
																												WHEN 14 THEN 'FirstSubjectEnrolled'
																												WHEN 15
																												THEN 'FirstSubjectRandomized'
																												WHEN 16 THEN 'FirstSubjectScreened'
																											END AS MilestoneName
																						FROM      dbo.ProjectProjectMilestone_XREF PMSX
																						WHERE     PMSX.ProjectMilestoneId IN ( 14, --First Subject Enrolled
																																						15, --First Subject Randomized
																																						16 --First Subject Screened
																			)
																					) MS PIVOT ( MAX(MilestoneDate) FOR MilestoneName IN ( [FirstSubjectEnrolled],
																																						[FirstSubjectRandomized],
																																						[FirstSubjectScreened] ) ) AS PVT
																) PFS ON PFS.ProjectId = P.ProjectId
							--=================================================================================================
							WHERE   P.IsActive = 1
											AND P.ProjectDteType = 1
											AND P.AllowInitialSiteTiering = 1
											AND P.InitialTieringPerformed != 1
											AND MonthlyReviewPerformed.ProjectId IS NULL
											AND ( PFS.FirstSubjectInDate < CAST(GETDATE() AS DATE)
														OR COALESCE(TotalProjectedInitiatedSites, 0) * 0.5 <= COALESCE(ASCBPC.TotalActualActiveSiteCount,
																																						0)
													)
											AND ( NSS.EmailLastSentOn IS NULL
														OR ( DATEDIFF(DAY, EmailLastSentOn, GETDATE()) = 7 ) 
													);", new SqlParameter("notificationConfigId", (int)Notification_E.Reminder_Initial_Site_Tiering_Due)))
			{
				try
				{
					while (dr.Read()) { projectIdList.Add(DbSafe.Int(dr["ProjectId"])); }
				}
				finally { dr.Close(); }
			}

			var dc = DetachedCriteria.For<Project>().Add(Expression.In("Id", projectIdList.ToArray()));
			return Project.FindAll(dc).ToList();
		}

		public static EntityExecutionStatus<string> UpdateRegularTierReviewFlag(int projectId, bool regularReviewRequired, int? noRegularTierReviewReasonId)
		{
			var result = new EntityExecutionStatus<string>();
			if (regularReviewRequired || (!regularReviewRequired && noRegularTierReviewReasonId.HasValue))
			{
				var project = FindById(projectId);
				project.RegularTierReviewRequired = regularReviewRequired;
				project.NoRegularTierReviewReasonId = noRegularTierReviewReasonId;
				project.SaveAndFlush();
			}
			else
			{
				result.Errors.Add(new ValidationMessage_WS("[name=rbNoReviewReason]", "Reason is required when disabling monthly tier review.", MessageType_E.Error));
			}
			return result;
		}

		public static ExecutionStatus_WS<ProjectSchemaDetails_WS> GetDteSchemaForSimulation()
		{
			var response = new ExecutionStatus_WS<ProjectSchemaDetails_WS> { IsSuccessful = true, AdditionalData = new ProjectSchemaDetails_WS() };

			foreach (var tier in CacheService.Tier)
			{
				response.AdditionalData.SiteMonitoringSchemaDetails.TierList.Add(new VisitSchemaLevelInfo_WS
				{
					CalculatorGroup = CalculatorGroup_E.DTEMonitoringCalculator,
					TierName = tier.Value.Id,
				});

				response.AdditionalData.PharmacySchemaDetails.TierList.Add(new VisitSchemaLevelInfo_WS
				{
					CalculatorGroup = CalculatorGroup_E.DTEPharmacyCalculator,
					TierName = tier.Value.Id
				});
			}

			return response;
		}
		public static List<SiteVisitCount_WS> GetDteSiteVisitCountForSimulation(List<VisitSchemaLevelInfo_WS> tierConfigList, int projectedInitiatedSiteCount, DateTime? fsiMilestoneDate, DateTime? covMilestoneDate, int sivFirstImvWeeks)
		{
			if (fsiMilestoneDate.HasValue && covMilestoneDate.HasValue)
			{
				var response = new List<SiteVisitCount_WS>();

				foreach (var tierConfig in tierConfigList)
				{
					var projectSchemaConfig = new ProjectSchemaDetails_WS();
					(tierConfig.IsPharmacy ? projectSchemaConfig.PharmacySchemaDetails : projectSchemaConfig.SiteMonitoringSchemaDetails).TierList.Add(tierConfig);

					var vpg = new VisitPatternGeneratorV2(Convert.ToInt32(tierConfig.TierCycle.GetValueOrDefault()), tierConfig.OnSiteVisitRatio.GetValueOrDefault(), tierConfig.RemoteVisitRatio.GetValueOrDefault(), fsiMilestoneDate.GetValueOrDefault(), covMilestoneDate.GetValueOrDefault(), null, sivFirstImvWeeks, tierConfig.IsPharmacy);
					var projectedSitesInCurrentTier = Convert.ToInt32(projectedInitiatedSiteCount * tierConfig.TargetSitePercentage / 100);

					var visitCounts = new VisitCount(projectedSitesInCurrentTier, projectedSitesInCurrentTier, (projectedSitesInCurrentTier * vpg.VisitPattern.Count(vp => vp.SiteVisitType == SiteVisitType_E.AnyOnsite)),
																																																	projectedSitesInCurrentTier * vpg.VisitPattern.Count(vp => vp.SiteVisitType == SiteVisitType_E.AnyRemote), 0);

					response.Add(new SiteVisitCount_WS(tierConfig.TierName, tierConfig.IsPharmacy, visitCounts.IntSivVisitCount, visitCounts.IntCovVisitCount, visitCounts.IntOnsiteImvVisitCount + visitCounts.IntPharmacyVisitCount, visitCounts.IntRemoteVisitCount));

				}
				return response;
			}
			else
			{
				throw new RMException(string.Format("Following milestones are missing in PPM: {0}", (!fsiMilestoneDate.HasValue && !covMilestoneDate.HasValue) ? "First Subject Randomized, Last Site Closed" : !fsiMilestoneDate.HasValue ? "First Subject Randomized" : "Last Site Closed"));
			}
		}

		public static List<VisitPatternInputData> GetGloblSiteTierProportions(bool isPharmacy)
		{
			var globalProportions = new List<VisitPatternInputData>();
			var sql = string.Format(@"SELECT  TC.TierId , ROUND(TC.TierCount * 100.0 / SUM(TierCount) OVER (), 1) AS GlobalPercentage
FROM    ( SELECT    TierId , SUM(1) TierCount
          FROM      dbo.SiteTier_XREF
          WHERE     CalculatorTypeId {0} 8
          GROUP BY  TierId ) TC;", isPharmacy ? "=" : "!=");
			using (var dr = DbHelp.ExecuteDataReaderText(sql))
			{
				try
				{
					while (dr.Read())
					{
						globalProportions.Add(new VisitPatternInputData
						{
							CalculatorTypeId = (int)(isPharmacy ? CalculatorGroup_E.DTEPharmacyCalculator : CalculatorGroup_E.DTEMonitoringCalculator),
							TierId = DbSafe.Int(dr["TierId"]),
							TargetPercentage = DbSafe.Float(dr["GlobalPercentage"])
						});
					}
				}
				finally { dr.Close(); }
			}
			return globalProportions;
		}

		public static ProjectDetail_WS GetProjectDetailsByProjectId(int projectId)
		{
			var project = Project.FindById(projectId);

			var tList = ProjectTherapeuticArea.FindAllByProperty("Project.Id", projectId);
			var iList = ProjectIndications.FindAllByProperty("Project.Id", projectId);

			return new ProjectDetail_WS
			{
				ProjectCode = project.ProjectCode,
				Protocol = project.ProtocolNumber,
				ProtocolIdentifier = project.ProtocolTitle,
				ProjectDesc = project.ProjectDescription,
				ProgramIdentifier = project.ProgramIdentifier,
				Spm = project.CompetencyBand == null ? string.Empty : project.CompetencyBand.Name,
				Complexity = project.ProjectComplexity,
				Size = project.ProjectSize,
				Customer = project.CustomerName,
				Organization = project.Organization,
				OrganizationalUnit = project.OrganizationalUnit == null ? string.Empty : project.OrganizationalUnit.Name,
				ThrapeuticArea = (tList == null) ? string.Empty : string.Join(",", tList.Select(t => t.TherapeuticArea.Name).ToArray()),
				Indication = (iList == null) ? string.Empty : string.Join(",", iList.Select(t => t.Indication.Name).ToArray()),
				Phase = project.Phase,
				Status = project.StudyStatus,
				CpmPl = project.GetPrimaryCpmName(),
				Owner = project.GetProjectOwnerName()
			};
		}

		public static ProposalProjectSummary_WS UpdateProposalProjectSummary(ProposalProjectSummary_WS projectSummary)
		{
			var proposalProject = Project.FindOneById(projectSummary.ProjectId);

			if (proposalProject.IsProposalProject)
			{
				proposalProject.WinProbabilityId = projectSummary.WinProbabilityId;
				proposalProject.SaveAndFlush();
			}

			return projectSummary;
		}

		public static List<string> GetActiveCountryNameList(string projectCode, string protocolNumber)
		{
			var countryList = new List<string>();

			var sql = @"SELECT  COALESCE(C.CTMSCountryName, C.Name) AS CtmsCountryName
									FROM    dbo.Project P
													JOIN dbo.MonitoringAttribute MA ON MA.ProjectId = P.ProjectId
																														 AND MA.IsActive = 1
													JOIN dbo.Country C ON C.CountryId = MA.CountryId
									WHERE   P.ProjectCode = @projectCode
													AND P.ProtocolNumber = @protocolNumber
									UNION
									SELECT  COALESCE(C.CTMSCountryName, C.Name) AS CtmsCountryName
									FROM    dbo.Project P
													JOIN dbo.SSVAttribute SA ON SA.ProjectId = P.ProjectId
																											AND SA.IsActive = 1
													JOIN dbo.Country C ON C.CountryId = SA.CountryId
									WHERE   P.ProjectCode = @projectCode
													AND P.ProtocolNumber = @protocolNumber";

			using (var dr = DbHelp.ExecuteDataReaderText(sql, new SqlParameter("projectCode", projectCode), new SqlParameter("protocolNumber", protocolNumber)))
			{
				try
				{
					while (dr.Read()) { countryList.Add(DbSafe.StringValue(dr["CtmsCountryName"])); }
				}
				finally { dr.Close(); }
			}

			return countryList;
		}

		public static List<KeyValue_WS> GetSiteCountBySiteStatus(int projectId, int countryId)
		{
			var response = new List<KeyValue_WS>();

			var sql = @"SELECT  SS.SiteStatusName AS SiteStatus,
													SS.ChronologicalOrder,
													COUNT(1) AS SiteCount
									FROM    dbo.ProjectProtocolSite PPS WITH ( NOLOCK )
													JOIN dbo.CD_SiteStatus SS WITH ( NOLOCK ) 
                                                    ON SS.SiteStatusId = PPS.SiteStatusId
													JOIN dbo.Address A WITH ( NOLOCK ) 
                                                    ON A.AddressId = PPS.AddressId
									WHERE   PPS.ProjectId = @projectId
													AND A.CountryId = @countryId
									GROUP BY SS.SiteStatusName ,
													SS.ChronologicalOrder
									ORDER BY COALESCE(SS.ChronologicalOrder, 9999) DESC";

			using (var dr = DbHelp.ExecuteDataReaderText(sql, new SqlParameter("projectId", projectId), new SqlParameter("countryId", countryId)))
			{
				try
				{
					while (dr.Read())
					{
						response.Add(new KeyValue_WS(DbSafe.Int(dr["SiteCount"]), DbSafe.StringValue(dr["SiteStatus"])));
					}
				}
				finally { dr.Close(); }
			}

			return response;
		}
		internal List<string> GetAssignedResourceEmailIdsByResourceTypeList(List<int> assignedResourceTypesForToList, List<int> assignedResourceTypesForCcList,
			 out List<string> assignedResourceManagersForToList, out List<string> assignedResourcesForCcList, out List<string> assignedResourceManagersForCcList)
		{
			var assignedResourcesForToList = new List<string>();
			assignedResourceManagersForToList = new List<string>();
			assignedResourcesForCcList = new List<string>();
			assignedResourceManagersForCcList = new List<string>();

			if ((assignedResourceTypesForToList != null && assignedResourceTypesForToList.Count > 0) ||
				(assignedResourceTypesForCcList != null && assignedResourceTypesForCcList.Count > 0))
			{
				var consolidatedList = new List<int>();
				if (assignedResourceTypesForToList != null) { consolidatedList.AddRange(assignedResourceTypesForToList); }
				if (assignedResourceTypesForCcList != null) { consolidatedList.AddRange(assignedResourceTypesForCcList); }

				var sql = string.Format(@"SELECT  DISTINCT
												RES.Qid AS AssignedResoruceQid,
												RES.ManagerQid,
												R.ResourceTypeId
										FROM    dbo.Project P WITH ( NOLOCK )
												JOIN dbo.Request R WITH ( NOLOCK ) ON P.ProjectId = R.ProjectId
												JOIN dbo.ResourceRequestAssignment_XREF RRX WITH ( NOLOCK ) ON RRX.RequestId = R.RequestId
												JOIN dbo.Resource RES WITH ( NOLOCK ) ON RES.ResourceId = RRX.ResourceId
										WHERE   P.ProjectId = {0}
												AND R.ResourceTypeId IN ( {1} )
												AND R.RequestStatusId IN ( {2}, {3} )",
												Id,
												string.Join(",", consolidatedList),
												(int)RequestStatusName.Assigned,
												(int)RequestStatusName.Backfilled);

				using (var dr = DbHelp.ExecuteDataReaderText(sql))
				{
					try
					{
						while (dr.Read())
						{
							var resourceTypeId = DbSafe.Int(dr["ResourceTypeId"]);
							var assignedResoruceQid = DbSafe.StringValue(dr["AssignedResoruceQid"]);
							var managerQid = DbSafe.StringValue(dr["ManagerQid"]);

							if (assignedResourceTypesForToList != null && assignedResourceTypesForToList.Contains(resourceTypeId))
							{
								assignedResourcesForToList.AddUnique(EmailNotification.GetEmailIdFromQid(assignedResoruceQid));
								assignedResourceManagersForToList.AddUnique(EmailNotification.GetEmailIdFromQid(managerQid));
							}
							else if (assignedResourceTypesForCcList != null && assignedResourceTypesForCcList.Contains(resourceTypeId))
							{
								assignedResourcesForCcList.AddUnique(EmailNotification.GetEmailIdFromQid(assignedResoruceQid));
								assignedResourceManagersForCcList.AddUnique(EmailNotification.GetEmailIdFromQid(managerQid));
							}
						}
					}
					finally { dr.Close(); }
				}
			}
			return assignedResourcesForToList;
		}

	}
	public class VisitPatternInputData
	{
		public int CalculatorTypeId { get; set; }
		public int VisitSchemaLevelId { get; set; }
		public int TierId { get; set; }
		public int TierCycle { get; set; }
		public float TargetPercentage { get; set; }
		public int OnSiteVisitRatio { get; set; }
		public int RemoteVisitRatio { get; set; }
	}

	public class SchedulableMilestone
	{
		public DateTime? ProjectedDate { get; set; }
		public DateTime? ActualDate { get; set; }
		public DateTime? ContractedDate { get; set; }
		public DateTime CreatedOn { get; set; }

		internal bool IsOverdueByNumberOfDaysToday(int daysToAdd)
		{
			return DateHelp.IsOverdueByNumberOfDaysToday(ActualDate, ProjectedDate, daysToAdd);
		}
		internal bool IsOverdueByNumberOfDaysOrMore(int daysToAdd)
		{
			return DateHelp.IsOverdueByNumberOfDaysOrMore(CreatedOn, ActualDate, ProjectedDate, daysToAdd);
		}
	}
}