﻿using System;
using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum ProjectStage_E
	{
		Prospecting = 1,
		Qualification = 2,
		Ballpark = 3,
		Bid_Requested = 4,
		Verbally_Agreed = 5,
		Opportunity_Won_LOI_COO_Agreed = 6,
		Opportunity_Won_Repricing = 7,
		Signed_Contract = 8,
		Opportunity_Closed_Lost = 9,
		Stopped = 10,
		Change_Cancellation_Requested = 11,
		Change_Cancellation_Sent_to_Customer = 12,
		Change_Cancellation_Not_Awarded = 13,
		Change_Cancellation_Awarded = 14,
		Ballpark_Stopped = 15,
		Proposal_Sent = 16,
		Opportunity_Won = 17,
		Preliminary_Agreement_Executed=18,
		InHand=19
	}

	[ActiveRecord(Table = "ProjectStage")]
	public class ProjectStage : AbstractActiveRecordBaseModel<ProjectStage>, ICodeTable
	{
		#region Properties

		[PrimaryKey(Column = "ProjectStageId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public String Name { get; set; }

		[Property]
		public bool AllowProposalRequestCreation { get; set; }
		[Property]
		public bool AllowProposalRequestSubmission { get; set; }
		#endregion
	}
}