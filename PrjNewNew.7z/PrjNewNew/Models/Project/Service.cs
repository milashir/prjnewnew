﻿using System.Collections.Generic;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Utilities;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class Service : AbstractActiveRecordBaseModel<Service>, ICodeTable
	{
		[PrimaryKey(Column = "ServiceId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }

		internal static List<Service> FindAllByName(string[] serviceNames)
		{
			List<Service> services = null;
			if (serviceNames != null && serviceNames.Length > 0)
			{
				services = new List<Service>();
				string inClauseValue = ArrayHelper.GetStringForSqlInClause(serviceNames);
				string sqlQuery = string.Format("select ServiceId, Name from Service where Name in({0})", inClauseValue);

				using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery, null))
				{
					try
					{
						while (dr.Read())
						{
							services.Add(new Service { Id = (int)dr["ServiceId"], Name = dr["Name"].ToString() });
						}
					}
					finally { dr.Close(); }
				}
			}

			return services;
		}

	}
}
