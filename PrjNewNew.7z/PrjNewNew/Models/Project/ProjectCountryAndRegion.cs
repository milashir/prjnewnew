﻿using System;
using System.Collections.Generic;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;

namespace Quintiles.RM.Clinical.Domain.Models
{
    [ActiveRecord(Table = "ProjectCountryAndRegion_XREF")]
	public class ProjectCountryAndRegion : AbstractActiveRecordBaseModel<ProjectCountryAndRegion>
    {
        [PrimaryKey(Column = "ProjectCountryAndRegionId", UnsavedValue = "-1")]
        public override int Id { set { this._id = value; } get { return this._id; } }

        [Property]
        public virtual int ProjectId { set; get; }

        [Property]
        public virtual int? RegionId { set; get; }

        [Property]
        public virtual int? CountryId { set; get; }

        public static IList<ProjectCountryAndRegion> GetMultipleCountries(int projectId)
        {
            DetachedCriteria filter = DetachedCriteria.For(typeof(ProjectCountryAndRegion));
            filter.Add(Expression.Eq("ProjectId", projectId));
            return ProjectCountryAndRegion.FindAll(filter);
        }

        #region DmlOperationsOnProjectRegion

        internal static void DmlOperationsOnProjectRegion(List<CountryAndRegion_WS> regionList, List<CountryAndRegion_WS> countryList, int projectId)
        {
            try
            {
                #region Delete ProjectRegions
                string projectRegionsToDelete = null;
                regionList.ForEach(region =>
                {
                    if (region.dmlOperation == DMLOperation_E.Delete)
                    {
                        projectRegionsToDelete += "," + region.key;
                    }
                });

                if (!string.IsNullOrEmpty(projectRegionsToDelete))
                {
                    projectRegionsToDelete = projectRegionsToDelete.Substring(1);
                    ProjectCountryAndRegion.DeleteAll(string.Format("ProjectId ={0} and RegionId in({1})", projectId, projectRegionsToDelete));
                }

                #endregion

                #region Delete ProjectCountries
                string projectCountriesToDelete = null;
                countryList.ForEach(country =>
                {
                    if (country.dmlOperation == DMLOperation_E.Delete)
                    {
                        projectCountriesToDelete += "," + country.key;
                    }
                });

                if (!string.IsNullOrEmpty(projectCountriesToDelete))
                {
                    projectCountriesToDelete = projectCountriesToDelete.Substring(1);
                    ProjectCountryAndRegion.DeleteAll(string.Format("ProjectId ={0} and CountryId in({1})", projectId, projectCountriesToDelete));
                }

                #endregion

                #region Insert countries and build the list of region to insert which has no countries
                List<int> regionsWithCountries = new List<int>();
                regionList.ForEach(r =>
                {
                    if (r.dmlOperation == DMLOperation_E.Insert)
                    {
                        regionsWithCountries.Add(r.key);
                    }
                });

                string regionsWithNullCountriesToDelete = null;

                foreach (var country in countryList)
                {
                    if (country.dmlOperation == DMLOperation_E.Insert)
                    {
                        new ProjectCountryAndRegion
                        {
                            ProjectId = projectId,
                            RegionId = country.regionId,
                            CountryId = country.key
                        }.SaveAndFlush();
                        regionsWithCountries.Remove(country.regionId);
                        regionsWithNullCountriesToDelete += "," + country.regionId;
                    }
                }
                #endregion

                #region Delete regions with null countries
                if (!string.IsNullOrEmpty(regionsWithNullCountriesToDelete))
                {
                    regionsWithNullCountriesToDelete = regionsWithNullCountriesToDelete.Substring(1);
                    ProjectCountryAndRegion.DeleteAll(string.Format("ProjectId = {0} and RegionId in ({1}) and CountryId IS NULL", projectId, regionsWithNullCountriesToDelete));
                }
                #endregion

                #region Add regions with no countries
                foreach (var regionId in regionsWithCountries)
                {
                    new ProjectCountryAndRegion
                        {
                            ProjectId = projectId,
                            RegionId = regionId,
                            CountryId = null
                        }.SaveAndFlush();
                }
                #endregion
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}

