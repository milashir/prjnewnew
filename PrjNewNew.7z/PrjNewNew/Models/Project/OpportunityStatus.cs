﻿using Castle.ActiveRecord;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class OpportunityStatus : AbstractActiveRecordBaseModel<OpportunityStatus>, ICodeTable
	{
		[PrimaryKey(Column = "OpportunityStatusId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }
	}
}
