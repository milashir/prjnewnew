﻿using System;
using System.Linq;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// Represents the milestones in PPM, Name must match their name (full spelling or just after last . )
	/// </summary>
	[ActiveRecord(Table = "cd_countryMileStone")]
	public class CountryMilestone : AbstractActiveRecordBaseModel<CountryMilestone>, IEquatable<CountryMilestone>, IComparable<CountryMilestone>, ICodeTable
	{
		[PrimaryKey(Column = "CountryMilestoneId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }

		[Property]
		public string MappingTable { get; set; }

		[Property]
		public string ActualColumnMapping { get; set; }

		[Property]
		public string ProjectedColumnMapping { get; set; }

		[Property]
		public bool IsSsvMilestone { get; set; }

		//This key is sent by PPM. 
		[Property]
		public string ExternalMilestoneKey { get; set; }

		//This key is RM defined. We need it for disambiguation between start and stop dates of SSV milestones.
		[Property]
		public string RmMilestoneKey { get; set; }

		public GenericMilestoneType_E Attributekey { get { return IsSsvMilestone ? GenericMilestoneType_E.Ssv : GenericMilestoneType_E.Monitoring; } }

		public bool Equals(CountryMilestone other)
		{
			return ((this.Id > 0 && other.Id > 0) && this.Id == other.Id);
		}

		public int CompareTo(CountryMilestone other)
		{
			return String.CompareOrdinal(Name, other.Name);
		}

		public static CountryMilestone GetCountryMilestoneByName(string milestoneName)
		{
			return CacheService.CountryMilestone.Values.FirstOrDefault(m => string.Equals(m.RmMilestoneKey, milestoneName, StringComparison.InvariantCultureIgnoreCase));
		}
	}
}