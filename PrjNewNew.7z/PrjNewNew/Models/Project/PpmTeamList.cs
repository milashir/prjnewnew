﻿using System;
using System.Runtime.Serialization;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Services;
using System.Linq;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class TeamMemberType : AbstractActiveRecordBaseModel<TeamMemberType>, ICodeTable
	{
		[PrimaryKey(Column = "TeamMemberTypeId")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }
	}

	[ActiveRecord]
	public class TeamMemberRole : AbstractActiveRecordBaseModel<TeamMemberRole>, ICodeTable
	{
		[PrimaryKey(Column = "TeamMemberRoleId")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }

		[Property]
		public bool IsPrimaryCl { get; set; }
	}

	[ActiveRecord]
	public class PpmTeamList : AbstractActiveRecordBaseModel<PpmTeamList>
	{
		#region Properties
		[PrimaryKey(Column = "PpmTeamListId")]
		public override int Id { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public int TeamMemberId { get; set; }

		[Property]
		public string Company { get; set; }

		[Property]
		public string Email { get; set; }

		[Property]
		public string MobileNumber { get; set; }

		[Property]
		public string FullName { get; set; }

		[Property]
		public string Qid { get; set; }

		[Property]
		public string Office { get; set; }

		[Property]
		public string OfficePhone { get; set; }

		[Property]
		public string TeamMemberRole { get; set; }

		[Property]
		public string StartDate { get; set; }

		[Property]
		public string StopDate { get; set; }

		[Property]
		public string Title { get; set; }

		[Property]
		public bool PrimaryContact { get; set; }

		[Property]
		public int TeamMemberTypeId { get; set; }

		[Property]
		public bool IncludeInReporting { get; set; }
		#endregion
	}

	[DataContract]
	public class PpmTeamMember
	{
		[DataMember]
		public int TeamMemberId { get; set; }
		[DataMember]
		public string Company { get; set; }
		[DataMember]
		public string Email { get; set; }
		[DataMember]
		public string MobileNumber { get; set; }
		[DataMember]
		public string FullName { get; set; }
		[DataMember]
		public string Qid { get; set; }
		[DataMember]
		public string Office { get; set; }
		[DataMember]
		public string OfficePhone { get; set; }
		[DataMember]
		public string TeamMemberRole { get; set; }
		[DataMember]
		public DateTime? StartDate { get; set; }
		[DataMember]
		public DateTime? StopDate { get; set; }
		[DataMember]
		public string Title { get; set; }
		[DataMember]
		public bool PrimaryContact { get; set; }
		[DataMember]
		public string TeamMemberType { get; set; }
		[DataMember]
		public bool IncludeInReporting { get; set; }
	}
}
