﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Utilities;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ProjectJobRole_XREF")]
	public class ProjectJobRole : AbstractActiveRecordBaseModel<ProjectJobRole>, IComparable<ProjectJobRole>
	{
		[PrimaryKey(Column = "ProjectJobRoleId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int JobRoleId { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public string Education { get; set; }

		[Property]
		public int? EDCOther { get; set; }
		[Property]
		public int? InformArchitect { get; set; }
		[Property]
		public int? MedidataRave { get; set; }
		[Property]
		public int? OCRDC { get; set; }

		[Property]
		public int? GlobalProjectExperience { get; set; }

		[Property]
		public int? InHouseMonitoring { get; set; }
		[Property]
		public int? OnSiteMonitoring { get; set; }

		[Property]
		public string ContractualRequirementsText { get; set; }

		public JobRole JobRole { get; set; }

		private Project _project = null;
		public Project Project
		{
			get
			{
				if (_project == null)
				{
					_project = Project.Find(ProjectId);
				}
				return _project;
			}
		}

		#region IComparable<ProjectJobRole> Members

		public int CompareTo(ProjectJobRole other)
		{
			return this.JobRole.Name.CompareTo(other.JobRole.Name);
		}

		#endregion

		#region Static Finder Methods

		public static ProjectJobRole FindByProjectIdJobRoleId(int projectId, JobRole jobRole, bool createDbIfNotFound = false)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(ProjectJobRole));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("JobRoleId", jobRole.Id));
			ProjectJobRole projectJobRole = ProjectJobRole.FindFirst(criteria);

			if ((projectJobRole == null) && createDbIfNotFound)
			{
				projectJobRole = new ProjectJobRole() { JobRoleId = jobRole.Id, ProjectId = projectId };
				projectJobRole.SaveAndFlush();
			}
			return projectJobRole;
		}

		#endregion

		internal static ProjectJobRole CreateFromReader(System.Data.IDataReader r)
		{
			ProjectJobRole pj = null;
			if (r != null)
			{
				ColumnChecker cc = new ColumnChecker(r);
				if (cc.HasColumn("ProjectJobRoleId") && !(r["ProjectJobRoleId"] is DBNull))
				{
					pj = new ProjectJobRole { Id = int.Parse(r["ProjectJobRoleId"].ToString()) };
				}
			}
			return pj;
		}

		public bool HasEducation()
		{
			return !String.IsNullOrEmpty(Education);
		}

		public bool HasMonitoringExperience()
		{
			return (InHouseMonitoring != null || OnSiteMonitoring != null);
		}

		public bool HasGlobalProjectExperience()
		{
			return GlobalProjectExperience != null;
		}

		internal string GetNotesColumnValue()
		{
			return string.Format(Constants.MessageDiv,
				 (EntityComment.FindEntityComments(Id, EntityTypes.JobRole, false).Count > 0) ? string.Empty : "no_",
				 Id,
				 (int)SearchLevel.JobRole,
				 EntityTypes.JobRole.ToString(), (int)EntityTypes.JobRole,
				 string.Empty, Constants.UnspecifiedId, Constants.UnspecifiedId,
				 string.Empty, Constants.UnspecifiedId, Constants.UnspecifiedId,
				 Project.Id, Project.ProjectCode,
				 Constants.UnspecifiedId, string.Empty,
				 Id, JobRole.Name,
				 string.Empty);
		}

		public static int GetProjectId(int projectJobRoleId)
		{
			return (int)DbHelp.ExecuteScalarText(string.Format("Select ProjectId from ProjectJobRole_XREF where ProjectJobRoleId={0}", projectJobRoleId));
		}

		public static IList<ProjectJobRole> FindByProjectId(int projectId)
		{
			var projectJobroles = new List<ProjectJobRole>();

			using (var dr = DbHelp.ExecuteDataReaderText(string.Format(@"SELECT PJRX.*, JR.Name, P.ProjectCode AS JobRoleName FROM dbo.ProjectJobRole_XREF PJRX
					INNER JOIN dbo.JobRole JR ON PJRX.JobRoleId = JR.JobRoleId
					INNER JOIN dbo.Project P ON P.ProjectId = PJRX.ProjectId
					WHERE PJRX.ProjectId = {0}", projectId), null))
			{
				try
				{
					while (dr.Read())
					{
						projectJobroles.Add(new ProjectJobRole
						{
							Id = DbSafe.Int(dr["ProjectJobRoleId"]),
							ProjectId = DbSafe.Int(dr["ProjectId"]),
							JobRole = JobRole.CreateFromReader(dr),
							JobRoleId = DbSafe.Int(dr["JobRoleId"]),
							Education = DbSafe.StringValue(dr["Education"]),
							LastModifiedBy = DbSafe.StringValue(dr["LastModifiedBy"]),
							LastModifiedOn = DbSafe.DateTime(dr["LastModifiedOn"]),
							CreatedBy = DbSafe.StringValue(dr["CreatedBy"]),
							CreatedOn = DbSafe.DateTime(dr["CreatedOn"]),
							EDCOther = DbSafe.IntNull(dr["EDCOther"]),
							InformArchitect = DbSafe.IntNull(dr["InformArchitect"]),
							MedidataRave = DbSafe.IntNull(dr["MedidataRave"]),
							OCRDC = DbSafe.IntNull(dr["OCRDC"]),
							InHouseMonitoring = DbSafe.IntNull(dr["InHouseMonitoring"]),
							OnSiteMonitoring = DbSafe.IntNull(dr["OnSiteMonitoring"]),
							GlobalProjectExperience = DbSafe.IntNull(dr["GlobalProjectExperience"]),
							ContractualRequirementsText = DbSafe.StringValue(dr["ContractualRequirementsText"])
						});
					}
				}
				finally { dr.Close(); }
			}

			return projectJobroles;
		}
	}

	[ActiveRecord(Table = "ResourceRequirements_ProjectJobRoleGroup")]
	public class ProjectJobRoleGroup : AbstractActiveRecordBaseModel<ProjectJobRoleGroup>, IComparable<ProjectJobRoleGroup>
	{
		[PrimaryKey(Column = "ProjectJobRoleGroupId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public int JobRoleGroupId { get; set; }

		[Property]
		public string ContractualNotes { get; set; }

		#region IComparable<ProjectJobRoleGroup> Members

		public int CompareTo(ProjectJobRoleGroup other)
		{
			return this.ProjectId.CompareTo(other.ProjectId);
		}

		public bool Equals(ProjectJobRoleGroup other)
		{
			if ((this.Id > 0 && other.Id > 0) && this.Id == other.Id) { return true; }
			return false;
		}

		#endregion

		public static List<ProjectJobRoleGroup> FindByProjectId(int projectId)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(ProjectJobRoleGroup));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			List<ProjectJobRoleGroup> projectJobRole = ProjectJobRoleGroup.FindAll(criteria).ToList();

			return projectJobRole;
		}

		public static ProjectJobRoleGroup FindByProjectIdJobRoleGroupId(int projectId, int? jobRoleGroupId)
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(ProjectJobRoleGroup));
			criteria.Add(Expression.Eq("ProjectId", projectId));
			criteria.Add(Expression.Eq("JobRoleGroupId", jobRoleGroupId));
			ProjectJobRoleGroup projectJobRole = ProjectJobRoleGroup.FindFirst(criteria);

			return projectJobRole;
		}
	}
}
