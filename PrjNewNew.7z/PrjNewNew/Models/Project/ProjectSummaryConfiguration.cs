﻿using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{

	[ActiveRecord(Table = "ProjectSummaryConfiguration")]
	public class ProjectSummaryConfiguration : AbstractActiveRecordBaseModel<ProjectSummaryConfiguration>
	{
		[PrimaryKey(Column = "Id", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public string FieldName { get; set; }

		[Property]
		public string DisplayLabel { get; set; }

		[Property(Column = "OrganizationTypeId")]
		public OrganizationType_E OrganizationType { get; set; }

		[Property]
		public virtual int? DisplayOrder { get; set; }

		public static ProjectSummaryConfiguration[] FindByOrganizationType(OrganizationType_E organizationType)
		{
			return ProjectSummaryConfiguration.FindAllByProperty("OrganizationType", organizationType);
		}
	}
}