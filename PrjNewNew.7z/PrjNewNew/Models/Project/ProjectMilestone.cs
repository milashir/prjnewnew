﻿using System;
using System.Collections.Generic;
using System.Linq;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;

namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// Represents the milestones in PPM, Name must match their name (full spelling or just after last . )
	/// </summary>
	[ActiveRecord(Table = "cd_ProjectMilestone")]
	public class ProjectMilestone : AbstractActiveRecordBaseModel<ProjectMilestone>, IEquatable<ProjectMilestone>, IComparable<ProjectMilestone>, ICodeTable
	{
		[PrimaryKey(Column = "ProjectMilestoneId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public string Name { get; set; }

		[Property]
		public string Description { get; set; }
		[Property]
		public string TargetTable { get; set; }

		[Property(Column = "ColumnMapping")]
		public string ActualColumnMapping { get; set; }

		[Property]
		public string ProjectedColumnMapping { get; set; }
		[Property]
		public bool IsVisibleInUI { get; set; }

		[Property]
		public int DisplayOrder { get; set; }

		[Property]
		public bool IsComputed { get; set; }
		[Property]
		public int? ParentMilestoneId { get; set; }
		[Property]
		public int? DaysToAdd { get; set; }
		[Property]
		public int? ChronologicalOrderOfMilestone { get; set; }
		[Property]
		public int? ValidateChronologicalOrder { get; set; }

		public bool Equals(ProjectMilestone other)
		{
			return ((this.Id > 0 && other.Id > 0) && this.Id == other.Id);
		}

		public int CompareTo(ProjectMilestone other)
		{
			return String.CompareOrdinal(Name, other.Name);
		}

		public static List<DefaultProjectMilestone_WS> GetMilestoneData()
		{
			return CacheService.ProjectMilestones.Values.Where(pm => pm.IsVisibleInUI)
																									.OrderBy(pm => pm.DisplayOrder)
																									.Select(pm => new DefaultProjectMilestone_WS(pm.Id, pm.Description)).ToList();
		}
	}
}