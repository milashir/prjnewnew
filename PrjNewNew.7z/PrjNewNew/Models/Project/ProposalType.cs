﻿using System;
using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ProposalType")]
	public class ProposalType : AbstractActiveRecordBaseModel<ProposalType>, ICodeTable
	{
		#region Properties

		[PrimaryKey(Column = "ProposalTypeId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property]
		public String Name { get; set; }

		#endregion
	}
}