﻿using System;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class ProjectStudyStatusDateChange_Xref : AbstractActiveRecordBaseModel<ProjectStudyStatusDateChange_Xref>
	{
		#region Mapped Properties
		[PrimaryKey(UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public int StudyStatusId { get; set; }

		[Property]
		public DateTime StatusChangeDate { get; set; }
		#endregion


		public static void CreateOrUpdateProjectStudyStatusDateChangeEntry(Project projectInRm, int? oldStudyStatusId)
		{
			//Update Study Status of a project when it changes or the project is getting published for the first time.
			if (projectInRm.StudyStatusObj != null)
			{
				var sql = string.Format(@";MERGE dbo.ProjectStudyStatusChangeDate_Xref AS TargetTbl
																	USING
																			( SELECT    {0} AS ProjectId ,
																									{1} AS NewStudyStatusId ,
																									{2} AS OldStudyStatusId ,
																									GETDATE() AS StatusChangeDate
																			) AS SourceTbl
																	ON SourceTbl.ProjectId = TargetTbl.ProjectId
																			AND SourceTbl.NewStudyStatusId = TargetTbl.StudyStatusId
																	WHEN MATCHED AND ( SourceTbl.OldStudyStatusId IS NULL
																										 OR SourceTbl.OldStudyStatusId != SourceTbl.NewStudyStatusId
																									 ) THEN
																			UPDATE SET TargetTbl.StatusChangeDate = SourceTbl.StatusChangeDate
																	WHEN  NOT MATCHED BY TARGET THEN
																			INSERT ( ProjectId ,
																							 StudyStatusId ,
																							 StatusChangeDate
																						 )
																			VALUES ( SourceTbl.ProjectId ,
																							 SourceTbl.NewStudyStatusId ,
																							 SourceTbl.StatusChangeDate
																						 );",
																	projectInRm.Id,
																	projectInRm.StudyStatusObj.Id,
																	oldStudyStatusId.HasValue ? oldStudyStatusId.GetValueOrDefault().ToString() : "NULL");

				DbHelp.ExecuteNonQueryText(sql);
			}
		}
	}
}
