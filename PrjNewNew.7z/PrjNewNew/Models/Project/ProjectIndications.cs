﻿using System;
using System.Collections.Generic;
using System.Data;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ProjectIndication_XREF")]
	public class ProjectIndications : AbstractActiveRecordBaseModel<ProjectIndications>, IEquatable<ProjectIndications>
	{
		public ProjectIndications()
			: base()
		{
			Indication = new Indication();
			Project = new Project();
		}


		[PrimaryKey(Column = "ProjectIndicationId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[BelongsTo("IndicationId")]
		public Indication Indication { get; set; }

		[BelongsTo("ProjectId")]
		public Project Project { get; set; }
		internal static string FindByProjectId(int projectId)
		{
			string projectIndication = string.Empty;

			string sqlQuery = string.Format(@"SELECT IndicationId FROM ProjectIndication_XREF WHERE ProjectId={0}", projectId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						projectIndication = projectIndication + Convert.ToString(dr["IndicationId"]) + ",";
					}
				}
				finally { dr.Close(); }
			}

			return projectIndication;

		}
		#region DmlOperationsOnIndication
		internal static void DmlOperationsOnIndication(List<MultiSelect_WS> indicationList, int projectId)
		{
			try
			{
				if (indicationList != null && indicationList.Count > 0)
				{
					#region Delete indications
					string indicationsToDelete = null;
					indicationList.ForEach(i =>
					{
						if (i.dmlOperation == DMLOperation_E.Delete)
						{
							indicationsToDelete += "," + i.key;
						}
					});

					if (!string.IsNullOrEmpty(indicationsToDelete))
					{
						indicationsToDelete = indicationsToDelete.Substring(1);
						ProjectIndications.DeleteAll(string.Format("ProjectId ={0} and IndicationId in({1})", projectId, indicationsToDelete));
					}

					#endregion

					foreach (var indication in indicationList)
					{
						if (indication.dmlOperation == DMLOperation_E.Insert)
						{
							new ProjectIndications
							{
								Project = new Project { Id = projectId },
								Indication = new Indication { Id = indication.key }
							}.SaveAndFlush();
						}
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}
		#endregion

		public bool Equals(ProjectIndications other)
		{
			throw new NotImplementedException();
		}

		bool IEquatable<ProjectIndications>.Equals(ProjectIndications other)
		{
			throw new NotImplementedException();
		}
	}
}


namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "ProjectTherapeuticArea_XREF")]
	public class ProjectTherapeuticArea : AbstractActiveRecordBaseModel<ProjectTherapeuticArea>, IEquatable<ProjectTherapeuticArea>
	{

		public ProjectTherapeuticArea()
			: base()
		{
			TherapeuticArea = new TherapeuticArea();
			Project = new Project();
		}

		[PrimaryKey(Column = "ProjectTherapeuticAreaId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[BelongsTo("TherapeuticAreaId")]
		public TherapeuticArea TherapeuticArea { get; set; }

		[BelongsTo("ProjectId")]
		public Project Project { get; set; }

		internal static string FindByProjectId(int projectId)
		{
			string projectTA = string.Empty;
			string sqlQuery = string.Format(@"SELECT TherapeuticAreaId FROM ProjectTherapeuticArea_XREF WHERE ProjectId={0}", projectId);

			using (var dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						projectTA = projectTA + Convert.ToString(dr["TherapeuticAreaId"]) + ",";
					}
				}
				finally { dr.Close(); }
			}
			return projectTA;
		}

		internal static void SaveProjectTherapeuticArea(int therapeuticAreaId, int projectId)
		{
			ProjectTherapeuticArea projectTherapeuticArea = ProjectTherapeuticArea.FindOneByProperty("Project.Id", projectId);
			if (projectTherapeuticArea != null)
			{
				projectTherapeuticArea.TherapeuticArea.Id = therapeuticAreaId;
				projectTherapeuticArea.UpdateAndFlush();
			}
			else
			{
				new ProjectTherapeuticArea
				{
					Project = new Project { Id = projectId },
					TherapeuticArea = new TherapeuticArea { Id = therapeuticAreaId }
				}.SaveAndFlush();
			}
		}

		public bool Equals(ProjectTherapeuticArea other)
		{
			throw new NotImplementedException();
		}

		bool IEquatable<ProjectTherapeuticArea>.Equals(ProjectTherapeuticArea other)
		{
			throw new NotImplementedException();
		}
	}
}