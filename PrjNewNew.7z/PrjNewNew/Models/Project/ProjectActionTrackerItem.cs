﻿using System;
using System.Collections.Generic;
using Castle.ActiveRecord;
using NHibernate.Criterion;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Notification;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public enum ProjectActionTrackerItemStatus_E
	{
		Open = 1,
		In_Progress = 2,
		Closed = 3
	}

	[ActiveRecord(Table = "ProjectActionTrackerItem")]
	public class ProjectActionTrackerItem : AbstractActiveRecordBaseModel<ProjectActionTrackerItem>
	{
		[PrimaryKey(Column = "ProjectActionTrackerItemId")]
		public override int Id { get; set; }
		[BelongsTo("ProjectId")]
		public Project Project { get; set; }
		[Property]
		public string ExternalId { get; set; }
		[Property]
		public int ActionId { get; set; }
		[Property]
		public string Title { get; set; }
		[Property(Column = "ProjectActionTrackerItemStatusId")]
		public ProjectActionTrackerItemStatus_E ProjectActionTrackerItemStatus { get; set; }
		[Property]
		public DateTime DateRaised { get; set; }
		[Property]
		public int ActionForumId { get; set; }
		[Property]
		public string ActionForumOther { get; set; }
		[Property]
		public string ResponsibleParty { get; set; }
		[Property]
		public string ResponsiblePartyOther { get; set; }
		[Property]
		public string ResponsiblePerson { get; set; }
		[Property]
		public string ResponsiblePersonQid { get; set; }
		[Property]
		public string ResponsiblePersonExternal { get; set; }
		[Property]
		public DateTime? DueDate { get; set; }
		[Property]
		public DateTime? CompletionDate { get; set; }
		[Property]
		public string Comments { get; set; }
		[Property]
		public bool ShowCustomer { get; set; }
		[Property]
		public string Description { get; set; }

		private ActionForum _actionForum = null;
		public ActionForum ActionForum
		{
			get
			{
				if (_actionForum == null)
				{
					if (!CacheService.ActionForums.TryGetValue(ActionForumId, out _actionForum))
					{
						throw new Exception(string.Format("Invalid ActionFoumId {0} found for ActionTrackerItemId {1}", ActionForumId, Id));
					}
				}
				return _actionForum;
			}
		}

		internal static IList<ProjectActionTrackerItem> GetOpenActionItemsForActiveAwardedProjects(NotificationActionItemConfig notificationActionItemConfig)
		{
			var minOverdueDate = DateTime.Today.AddDays(-1 * NotificationActionItemConfig.GetMaxOverdueDaysByProjectReviewLevelId(notificationActionItemConfig));


			var sql = string.Format(@"SELECT	PATI.*
												FROM    dbo.ProjectActionTrackerItem PATI
																JOIN dbo.ProjectActionTrackerItemStatus PATIS ON  PATIS.ProjectActionTrackerItemStatusId = PATI.ProjectActionTrackerItemStatusId
																JOIN dbo.Project P ON P.ProjectId = PATI.ProjectId
																JOIN dbo.cd_StudyStatus SS ON SS.StudyStatusName = P.StudyStatus
												WHERE   P.IsActive = 1
																AND P.OpportunityStatusId = {0}
																AND SS.SendSgrNotification = 1
																AND PATIS.IsCloseStatus = 0
																AND PATI.ActionForumId = {1}
																AND PATI.DueDate BETWEEN {2}
																AND CAST(GETDATE() AS DATE);",
																(int)OpportunityStatus_E.Closed_Won,
																notificationActionItemConfig.ActionForumId,
																DateHelp.MaxDate(minOverdueDate, ConfigValue.NotificationCutoffDate).ToNonNullableDbDate());


			return DbHelp.RunQuery<ProjectActionTrackerItem>(sql, "PATI");
		}

		internal bool IsOverdueByNumberOfDaysToday(int daysToAdd)
		{
			return DateHelp.IsOverdueByNumberOfDaysToday(ProjectActionTrackerItemStatus == ProjectActionTrackerItemStatus_E.Closed ? DateTime.Today : (DateTime?)null, DueDate, daysToAdd);
		}

		internal List<string> GetSendToAddressList(NotificationConfig notificationConfiguration)
		{
			var sendToAddresslist = new List<string>();
			if (!string.IsNullOrEmpty(ResponsiblePersonQid))
			{
				sendToAddresslist.Add(EmailNotification.GetEmailIdFromQid(ResponsiblePersonQid));
			}
			else
			{
				sendToAddresslist.Add(EmailNotification.GetEmailIdFromQid(Project.ProjectOwnerQId));
			}
			List<string> ccList;
			sendToAddresslist.AddRange(NotificationService.GetAssignedResoruceEmailIds(notificationConfiguration, Project, out ccList));
			return sendToAddresslist;
		}

		internal Dictionary<string, string> GetPlaceholderValueDistionaryForAlerts()
		{
			var placeholderDictionary = Project.GetPlaceholderValueDistionaryForAlerts(null);
			placeholderDictionary.Add(Constants.ContentPlaceholder.ActionItemDueDate, DueDate.ToQDateString());
			placeholderDictionary.Add(Constants.ContentPlaceholder.ActionDescription, Description);
			placeholderDictionary.Add(Constants.ContentPlaceholder.ActionForum, ActionForum == null ? ActionForumOther : ActionForum.Name);
			placeholderDictionary.Add(Constants.ContentPlaceholder.ActionId, ActionId.ToString());
			placeholderDictionary.Add(Constants.ContentPlaceholder.ActionComments, Comments);
			return placeholderDictionary;
		}

		internal List<string> GetCcAddressList(NotificationConfig notificationConfiguration)
		{
			var ccAddresslist = new List<string>();
			if (notificationConfiguration.SendToProjectCpm)
			{
				ccAddresslist.Add(EmailNotification.GetEmailIdFromQid(Project.PrimaryCPMQId));
			}
			if (notificationConfiguration.SendToProjectCpmLineManager && !string.IsNullOrEmpty(Project.PrimaryCpmManagerQid))
			{
				ccAddresslist.Add(EmailNotification.GetEmailIdFromQid(Project.PrimaryCpmManagerQid));
			}
			if (notificationConfiguration.SendToProjectOwner && !string.IsNullOrEmpty(Project.ProjectOwnerQId))
			{
				ccAddresslist.Add(EmailNotification.GetEmailIdFromQid(Project.ProjectOwnerQId));
			}
			return ccAddresslist;
		}

	}
}
