﻿using Castle.ActiveRecord;
using NHibernate.Criterion;
namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord]
	public class ProjectUploadedDocumentPath : AbstractActiveRecordBaseModel<ProjectUploadedDocumentPath>
	{
		[PrimaryKey(Column = "ProjectUploadedDocumentPathId", UnsavedValue = "-1")]
		public override int Id { get; set; }
		[Property]
		public int ProjectId { get; set; }

		[Property]
		public string RelativeDocumentPath { get; set; }

		private static DetachedCriteria SearchByIdCriteria(int projectId)
		{
			return DetachedCriteria.For<ProjectUploadedDocumentPath>().Add(Expression.Eq("ProjectId", projectId));
		}

		/// <summary>
		/// Currently RM supports only STAF file. Hence it is perfectly fine to assume that the record in database is for STAF excel
		/// </summary>
		public static ProjectUploadedDocumentPath FindByProjectId(int projectId)
		{
			return FindFirst(SearchByIdCriteria(projectId));
		}

		public static void CreateOrUpdateFileRecord(Project project, string relativeFilePath)
		{
			var documentPathEntry = FindByProjectId(project.Id);
			if (documentPathEntry == null)
			{
				documentPathEntry = new ProjectUploadedDocumentPath { ProjectId = project.Id };
			}

			documentPathEntry.RelativeDocumentPath = relativeFilePath;
			documentPathEntry.SaveAndFlush();
		}

		public static bool IsSatfExcleUploadedForProject(int projectId)
		{
			return Count(SearchByIdCriteria(projectId)) != 0;
		}
	}
}
