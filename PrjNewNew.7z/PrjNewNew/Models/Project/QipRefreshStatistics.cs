﻿using System;
using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public interface IRefreshStatistics
	{
		int ProjectId { get; set; }
		DateTime LastRefreshedOn { get; set; }
		string LastRefreshedBy { get; set; }
		bool IsRefreshRunning { get; set; }
		DateTime RefreshStartTime { get; set; }
		DateTime? RefreshEndTime { get; set; }
		DateTime LastModifiedOn { get; set; }
		string LastModifiedBy { get; set; }
	}

	[ActiveRecord]
	public class QipRefreshStatistics : AbstractActiveRecordBaseModel<QipRefreshStatistics>, IRefreshStatistics
	{
		#region Mapped Properties
		[PrimaryKey(Column = "QipRefreshStatisticId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public DateTime LastRefreshedOn { get; set; }

		[Property]
		public string LastRefreshedBy { get; set; }

		[Property]
		public bool IsRefreshRunning { get; set; }

		[Property]
		public DateTime RefreshStartTime { get; set; }

		[Property]
		public DateTime? RefreshEndTime { get; set; }
		#endregion

		public static QipRefreshStatistics GetByProjectId(int projectId)
		{
			DetachedCriteria dc = DetachedCriteria.For(typeof(QipRefreshStatistics));
			dc.Add(Expression.Eq("ProjectId", projectId));
			return FindFirst(dc, new Order("Id", false));
		}
	}

	[ActiveRecord]
	public class PricingRefreshStatistics : AbstractActiveRecordBaseModel<PricingRefreshStatistics>, IRefreshStatistics
	{
		#region Mapped Properties
		[PrimaryKey(Column = "PricingRefreshStatisticsId", UnsavedValue = "-1")]
		public override int Id { get; set; }

		[Property]
		public int ProjectId { get; set; }

		[Property]
		public DateTime LastRefreshedOn { get; set; }

		[Property]
		public string LastRefreshedBy { get; set; }

		[Property]
		public bool IsRefreshRunning { get; set; }

		[Property]
		public DateTime RefreshStartTime { get; set; }

		[Property]
		public DateTime? RefreshEndTime { get; set; }
		#endregion

		public static PricingRefreshStatistics GetByProjectId(int projectId)
		{
			DetachedCriteria dc = DetachedCriteria.For(typeof(PricingRefreshStatistics));
			dc.Add(Expression.Eq("ProjectId", projectId));
			return FindFirst(dc, new Order("Id", false));
		}
	}
}
