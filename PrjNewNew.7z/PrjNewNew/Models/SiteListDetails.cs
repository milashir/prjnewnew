﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using NHibernate;
using Quintiles.RM.Clinical.Domain.Database;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.Domain.Models
{
	public class SiteListDetails
	{
		public int SiteId { get; set; }
		public string SiteName { get; set; }
		public string ExternalSource { get; set; }
		public string ProjectCodeProtocolNumber { get; set; }
		public string SiteStatusName { get; set; }
		public string PrincipalInvestigatorName { get; set; }
		public string ResourceName { get; set; }
		public string CountryRegionName { get; set; }
		public string AddressDetails { get; set; }
		public string RowNumber { get; set; }



		#region FindAllPagedSsvAttributed
		/// <summary>
		/// </summary>
		/// <returns></returns>
		public static PagedResponse<SiteListDetails, AttributeCommonData> GetSiteDetailsByCountryAndProject(GridSerachSiteList_WS gsr)
		{
			var pr = new PagedResponse<SiteListDetails, AttributeCommonData>();
			var attributes = new List<SiteListDetails>();

			using (var dr = DbHelp.ExecuteDataReaderSP("GetSiteListDetailsByCountryAndProject", new System.Data.SqlClient.SqlParameter("projectId", gsr.ProjectId), new System.Data.SqlClient.SqlParameter("countryId", gsr.CountryId)))
			{
				try
				{
					while (dr.Read())
					{
						SiteListDetails attribute = new SiteListDetails
						{
							RowNumber = DbSafe.StringValue(dr["#"]),
							ProjectCodeProtocolNumber = DbSafe.StringValue(dr["ProjectCode-Protocol Number"]),
							SiteId = DbSafe.Int(dr["SiteId"]),
							SiteName = DbSafe.StringValue(dr["CTMS Row Id"]),
							SiteStatusName = DbSafe.StringValue(dr["Site Status"]),
							PrincipalInvestigatorName = DbSafe.StringValue(dr["Principal Investigator"]),
							ResourceName = DbSafe.StringValue(dr["CTMS-Assigned Field Monitor(s)"]),
							CountryRegionName = DbSafe.StringValue(dr["Country Region"]),
							AddressDetails = DbSafe.StringValue(dr["Address"])
						};
						attributes.Add(attribute);
					}

					pr.Records = attributes;
					pr.TotalPages = 1;
					pr.TotalRecords = attributes.Count;
				}
				finally { dr.Close(); }
			}

			return pr;
		}
		#endregion
	}
}
