﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Quintiles.RM.Clinical.Domain.Admin;
using Quintiles.RM.Clinical.Domain.Models.DTE;
using Quintiles.RM.Clinical.Domain.Models.Permissions;
using Quintiles.RM.Clinical.Domain.Models.ServerProcessMap;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// Model for row of data in a jqGrid
	/// </summary>
	/// <typeparam name="TGridRow"></typeparam>
	/// <typeparam name="TData"></typeparam>
	/// <typeparam name="TAdditionalData"></typeparam>
	public class JqGridData<TGridRow, TData, TAdditionalData, TDataForClient>
		where TGridRow : JqGridDataRow
		where TData : class
		where TAdditionalData : class
		where TDataForClient : class
	{
		[DataMember]
		public int TotalPages;

		[DataMember]
		public int CurrentPageNumber;

		[DataMember]
		public int RecordCount;

		[DataMember]
		public List<TGridRow> Records;

		[DataMember]
		public TDataForClient JsClientData { get; set; }
		public JqGridData()
		{
			Records = new List<TGridRow>();
		}

		public JqGridData(PagedResponse<TData, TAdditionalData> pagedResponse, TDataForClient jsClientData, Func<TData, TAdditionalData, TGridRow> createJqGridDataRowDelegate)
		{
			if (pagedResponse != null && pagedResponse.Records != null)
			{
				Records = new List<TGridRow>();

				foreach (TData resource in pagedResponse.Records)
				{
					Records.Add(createJqGridDataRowDelegate(resource, pagedResponse.AdditionalData));
				}

				TotalPages = pagedResponse.TotalPages;
				CurrentPageNumber = pagedResponse.PageNumber;
				RecordCount = pagedResponse.TotalRecords;
				JsClientData = jsClientData;
			}
		}
	}

	public class JqGridData<TGridRow, TData, TAdditionalData>
		where TGridRow : JqGridDataRow
		where TData : class
		where TAdditionalData : class
	{
		[DataMember]
		public int TotalPages;

		[DataMember]
		public int CurrentPageNumber;

		[DataMember]
		public int RecordCount;

		[DataMember]
		public List<TGridRow> Records;

		public JqGridData()
		{
			Records = new List<TGridRow>();
		}

		public JqGridData(PagedResponse<TData, TAdditionalData> pagedResponse, Func<TData, TAdditionalData, TGridRow> createJqGridDataRowDelegate)
		{
			if (pagedResponse != null && pagedResponse.Records != null)
			{
				Records = new List<TGridRow>();

				foreach (TData resource in pagedResponse.Records)
				{
					Records.Add(createJqGridDataRowDelegate(resource, pagedResponse.AdditionalData));
				}

				TotalPages = pagedResponse.TotalPages;
				CurrentPageNumber = pagedResponse.PageNumber;
				RecordCount = pagedResponse.TotalRecords;
			}
		}
	}

	[DataContract]
	public class JqGridDataRow
	{
		[DataMember]
		public int id;
	}

	#region Request rows
	[DataContract]
	public class JqGridRequestRow : JqGridDataRow
	{
		public JqGridRequestRow() { }
		public JqGridRequestRow(Request r, bool getCommentsFromDb)
		{
			id = r.Id;

			#region Request Properties
			ParentRequestId = r.ParentRequestId.HasValue ? r.ParentRequestId.GetValueOrDefault() : -1;
			RequestStatusId = r.RequestStatusId;
			RequestTypeId = r.RequestTypeId;
			ResourceTypeId = r.ResourceType.Id;
			IsGenericResourceType = r.ResourceType.IsGeneric;
			ResourceType = r.ResourceType.Name;
			//RMK: Added to assign the generic flag
			IsGeneric = r.ResourceType.IsGeneric;
			RequestIdForFilter = r.Id;
			FTE = r.FTE.GetValueOrDefault().To3DecimalString();
			StartDateStatus = new DateStatus { connected = (int)r.StartDateStatus, changeIcon = true };
			StartDate = r.StartDate.ToQDateString();
			StopDateStatus = new DateStatus { connected = (int)r.StopDateStatus, changeIcon = true };
			StopDate = r.StopDate.ToQDateString();
			NeedByDate = r.NeedByDate.ToQDateString();
			Notes = r.GetNotesColumnValue(getCommentsFromDb);
			RequestLastModifiedOn = r.LastModifiedOn.Ticks;
			AttributeLastModifiedOn = r.AttributeLastModifiedOn.HasValue ? r.AttributeLastModifiedOn.Value.Ticks : 0;
			DateSubmitted = r.DateSubmitted.ToQDateString();
			CreatedBy = r.CreatedBy;
			ShowSiteList = r.ResourceType.ShowSiteList;
			#endregion

			#region Country Properties
			if (r.CountryId.HasValue)
			{
				CountryId = r.CountryId.Value;
				Country = r.Country.Name;
				CountryCode = r.Country.CountryCode;
			}
			else
			{
				CountryId = -1;
				Country = r.CountryName;
			}
			#endregion

			#region Project Properties
			ProjectId = r.Project.Id;
			Program = r.Project.Program;
			ProjectCode = r.Project.ProjectCode;
			Protocol = r.Project.ProtocolNumber;
			ProjectDteType = r.Project.ProjectDteType.GetEnumDescription();
			ProjectLastModifiedOn = r.Project.LastModifiedOn.Ticks;
			#endregion

			#region Region properties
			if (r.Region != null)
			{
				RegionId = r.Region.Id;
				Region = r.RegionName;
			}
			else
			{
				RegionId = -1;
				Region = r.RegionName;
			}
			//if (r.RegionId.HasValue)
			//{
			//	RegionId = r.RegionId.Value;
			//	Region = r.Region.Name;
			//}
			//else if (r.CountryId.HasValue)
			//{
			//	RegionId = r.Country.Subregion.Region.Id;
			//	Region = r.Country.Subregion.Region.Name;
			//}
			//else
			//{
			//	RegionId = -1;
			//	Region = Constants.RegionGlobal;
			//}
			#endregion

			#region Site Properties
			if (r.ProjectProtocolSite == null)
			{
				SiteId = -1;
				SiteLastModifiedOn = 0;
				AddressLastModifiedOn = 0;
				PiLastModifiedOn = 0;
			}
			else
			{
				SiteId = r.ProjectProtocolSite.Id;
				SiteLastModifiedOn = r.ProjectProtocolSite.LastModifiedOn.Ticks;
				AddressLastModifiedOn = r.ProjectProtocolSite.Address == null ? 0 : r.ProjectProtocolSite.Address.LastModifiedOn.Ticks;
				PiLastModifiedOn = r.ProjectProtocolSite.PrincipalInvestigator == null ? 0 : r.ProjectProtocolSite.PrincipalInvestigator.LastModifiedOn.Ticks;
			}
			#endregion
		}

		#region Properties
		[DataMember]
		public int RmPageLinkId;
		[DataMember]
		public int ParentRequestId;
		[DataMember]
		public int RequestTypeId;
		[DataMember]
		public int ResourceTypeId;
		[DataMember]
		public bool IsGenericResourceType;
		[DataMember]
		public int RequestStatusId;
		[DataMember]
		public int CountryId;
		[DataMember]
		public int RegionId;
		[DataMember]
		public int ProjectId;
		[DataMember]
		public int SiteId;
		[DataMember]
		public long RequestLastModifiedOn;
		[DataMember]
		public long AttributeLastModifiedOn;
		[DataMember]
		public long ProjectLastModifiedOn;
		[DataMember]
		public long SiteLastModifiedOn;
		[DataMember]
		public long AddressLastModifiedOn;
		[DataMember]
		public long PiLastModifiedOn;
		[DataMember]
		public int RequestIdForFilter;
		[DataMember]
		public string Notes;
		[DataMember]
		public string FTE;
		[DataMember]
		public DateStatus StartDateStatus;
		[DataMember]
		public string StartDate;
		[DataMember]
		public DateStatus StopDateStatus;
		[DataMember]
		public string StopDate;
		[DataMember]
		public string NeedByDate;
		[DataMember]
		public string Region;
		[DataMember]
		public string Country;
		[DataMember]
		public string Program;
		[DataMember]
		public string ProjectCode;
		[DataMember]
		public string Protocol;
		[DataMember]
		public string ResourceType;
		[DataMember]
		public string CountryCode;
		//RMK: Added to check whether the resource type is generic or not.
		[DataMember]
		public bool IsGeneric;
		[DataMember]
		public string DateSubmitted;
		[DataMember]
		public string CreatedBy;
		[DataMember]
		public string ProjectDteType;
		[DataMember]
		public bool ShowSiteList;
		#endregion
	}

	[DataContract]
	public class NonProposalRequestRowData : JqGridRequestRow
	{
		public NonProposalRequestRowData() { }
		public NonProposalRequestRowData(Request r)
			: base(r, false)
		{
			CalculatorIndicator = (int)r.FteConnectStatus;
			#region Site Properties
			if (r.ProjectProtocolSite == null)
			{
				SponsorSiteName = string.Empty;
				SiteStatus = string.Empty;
			}
			else
			{
				SponsorSiteName = r.ProjectProtocolSite.SponsorSite;
				SiteStatus = r.ProjectProtocolSite.SiteStatus == null ? string.Empty : r.ProjectProtocolSite.SiteStatus.Name;
			}
			PrincipalInvestigator = ProjectProtocolSite.GetPrincipalInvestigatorName(r.ProjectProtocolSite);
			#endregion

			#region Request Properties
			CreatedOn = r.CreatedOn.ToQDateString();
			PrimaryCl = r.Project.PrimaryCl;
			PrimaryCpm = r.Project.PrimaryCPM;
			Location = r.Location;
			SSVType = (r.SSVType != null) ? r.SSVType.Name : string.Empty;
			IMDateStatus = new DateStatus { connected = (int)r.IMDateStatus, changeIcon = false };
			IMDate = r.IMDate.HasValue ? r.IMDate.ToQDateString() : string.Empty;
			CRADateStatus = new DateStatus { connected = (int)r.CRATrainingDateStatus, changeIcon = true };
			CRADate = r.CRATrainingDate.HasValue ? r.CRATrainingDate.ToQDateString() : string.Empty;
			IconColumn = r.GetAllIconHtml(false);
			ProposalResource = r.ProposalResource;
			Customer = r.Project.CustomerName;
			SpmClass = (r.Project.CompetencyBand != null) ? r.Project.CompetencyBand.Name : string.Empty;
			HasRmPpmDteMismatch = r.HasRmPpmDteMismatch;
			TotalSites = r.TotalSites;

			if (r.RequestStatusId == (int)RequestStatusName.Pending)
			{
				Resource = "SOFT BOOKED";
			}
			if (r.RequestStatusId == (int)RequestStatusName.Returned || r.RequestStatusId == (int)RequestStatusName.Submitted)
			{
				Resource = "UNASSIGNED";
			}
			else if (r.RequestStatusId == (int)RequestStatusName.Assigned || r.RequestStatusId == (int)RequestStatusName.Backfilled)
			{

				if ((r.Resource != null && r.Resource.Count > 0))
				{
					Resource = r.Resource[0].Name;

					AssignedResource = new ResourceInfo_WS
					{
						QId = r.Resource[0].Qid,
						Id = r.Resource[0].Id,
						Name = r.Resource[0].Name
					};
				}
				else
				{
					Resource = "BookingError";
				}
			}
			#endregion
		}

		#region Properties
		[DataMember]
		public int CalculatorIndicator;
		[DataMember]
		public string SiteStatus;
		[DataMember]
		public string SponsorSiteName;
		[DataMember]
		public string PrincipalInvestigator;
		[DataMember]
		public string Location;
		[DataMember]
		public string SSVType;
		[DataMember]
		public DateStatus IMDateStatus;
		[DataMember]
		public string IMDate;
		[DataMember]
		public DateStatus CRADateStatus;
		[DataMember]
		public string CRADate;
		[DataMember]
		public string Resource;
		[DataMember]
		public string IconColumn;
		[DataMember]
		public string ProposalResource;
		[DataMember]
		public string CreatedOn { get; set; }
		[DataMember]
		public string PrimaryCpm { get; set; }
		[DataMember]
		public string PrimaryCl { get; set; }
		[DataMember]
		public string Customer { get; set; }
		[DataMember]
		public string SpmClass { get; set; }
		[DataMember]
		public bool HasRmPpmDteMismatch { get; set; }
		[DataMember]
		public int? TotalSites;
		[DataMember]
		public ResourceInfo_WS AssignedResource { get; set; }
		#endregion
	}

	[DataContract]
	public class ProposalRequestRowData : JqGridRequestRow
	{
		public ProposalRequestRowData(Request r, RequestCommonData commonData)
			: base(r, true)
		{
			RmPageLinkId = commonData.RmPageLinkId;
		}

		public static ProposalRequestRowData Create(Request r, RequestCommonData commonData)
		{
			return new ProposalRequestRowData(r, commonData);
		}
	}

	[DataContract]
	public class InitiateRequestRowData : NonProposalRequestRowData
	{
		public InitiateRequestRowData(RequestCommonData commonData)
		{
			RmPageLinkId = commonData.RmPageLinkId;

		}
		public InitiateRequestRowData(Request r, RequestCommonData commonData)
			: base(r)
		{
			RmPageLinkId = commonData.RmPageLinkId;
			VisitTypeName = r.SiteVisitType == null ? string.Empty : r.SiteVisitType.Name;
			SiteVisitTypeId = r.SiteVisitTypeId == null ? -1 : r.SiteVisitTypeId.GetValueOrDefault();
			RequestBudgeted = r.RequestBudgeted.GetValueOrDefault() == 1 ? "Yes" : "No";
			RequestBlinded = r.RequestBlindedString;
			CountryRegion = r.CountryRegion == null ? String.Empty : r.CountryRegion.Name; ;
			CountryRegionId = r.CountryRegionId.HasValue ? r.CountryRegionId.GetValueOrDefault() : -1;
			Reason = r.Reason;
			SSVTypeId = r.SSVType == null ? -1 : r.SSVType.Id;
			RequestOrganizationalUnitId = r.OrganizationalUnitId;
			OrganizationId = r.OrganizationId;

			OrganizationalUnit orgUnit;
			if (CacheService.AllEnabledOrganizationalUnits.TryGetValue(r.ProjectOrganizationalUnitId, out orgUnit))
			{
				ProjectOrganizationalUnit = orgUnit.Name;
			}

			TotalHours = r.TotalHours.GetValueOrDefault().To2DecimalString();
			//if (r.TotalHours != null && r.TotalSites != null)
			//{
			//	TotalSites = r.TotalSites.GetValueOrDefault().ToString();
			//	TotalHoursPerSite = r.TotalHoursPerSite.GetValueOrDefault().To2DecimalString();
			//	FTE_WS fte = Request.CalculateFTE(r.ResourceTypeId, r.CountryId.GetValueOrDefault(), r.StartDate.GetValueOrDefault(), r.StopDate.GetValueOrDefault(), r.TotalHours.GetValueOrDefault(), r.TotalHoursPerSite.GetValueOrDefault());
			//	TotalFTE = fte.TotalFTE;
			//	MonthlyFTEPerSite = fte.MonthlyFTEPerSite;
			//}
		}

		public static InitiateRequestRowData Create(Request r, RequestCommonData commonData)
		{
			return new InitiateRequestRowData(r, commonData);
		}

		#region Properties
		[DataMember]
		public int UiRowId { get; set; }
		[DataMember]
		public string VisitTypeName;
		[DataMember]
		public int SiteVisitTypeId;
		[DataMember]
		public string RequestBudgeted;
		[DataMember]
		public string RequestBlinded;
		[DataMember]
		public string CountryRegion;
		[DataMember]
		public int CountryRegionId;
		[DataMember]
		public string Reason;
		[DataMember]
		public int SSVTypeId;
		[DataMember]
		public int DurationTotalHours;
		[DataMember]
		public string TotalHours;
		[DataMember]
		public int? RequestOrganizationalUnitId;
		[DataMember]
		public int? OrganizationId;
		[DataMember]
		public string ProjectOrganizationalUnit;
		//[DataMember]
		//public string TotalHoursPerSite;
		//[DataMember]
		//public string TotalSites;
		[DataMember]
		public string TotalFTE;
		//[DataMember]
		//public string MonthlyFTEPerSite;
		#endregion
	}

	[DataContract]
	public class AwardedProposalRequestRowData : InitiateRequestRowData
	{
		public AwardedProposalRequestRowData(Request r, RequestCommonData commonData)
			: base(r, commonData)
		{
		}

		new public static AwardedProposalRequestRowData Create(Request r, RequestCommonData commonData)
		{
			return new AwardedProposalRequestRowData(r, commonData);
		}
	}
	[DataContract]
	public class SubmittedRequestRowData : NonProposalRequestRowData
	{
		public SubmittedRequestRowData(Request r, RequestCommonData commonData)
			: base(r)
		{
			RmPageLinkId = commonData.RmPageLinkId;
			VisitTypeName = r.SiteVisitType == null ? string.Empty : r.SiteVisitType.Name;
			RequestBudgeted = r.RequestBudgeted.GetValueOrDefault() == 1 ? "Yes" : "No";
			RequestBlinded = r.RequestBlindedString;
			CountryRegion = r.CountryRegion == null ? String.Empty : r.CountryRegion.Name; ;
			CurrentMonthFTE = r.CurrentMonthFTE != null ? Math.Round(r.CurrentMonthFTE.Value, 3).ToString() : string.Empty;
			SecondMonthFTE = r.SecondMonthFTE != null ? Math.Round(r.SecondMonthFTE.Value, 3).ToString() : string.Empty;
			ThirdMonthFTE = r.ThirdMonthFTE != null ? Math.Round(r.ThirdMonthFTE.Value, 3).ToString() : string.Empty;
			FourthMonthFTE = r.FourthMonthFTE != null ? Math.Round(r.FourthMonthFTE.Value, 3).ToString() : string.Empty;
			FifthMonthFTE = r.FifthMonthFTE != null ? Math.Round(r.FifthMonthFTE.Value, 3).ToString() : string.Empty;
			SixthMonthFTE = r.SixthMonthFTE != null ? Math.Round(r.SixthMonthFTE.Value, 3).ToString() : string.Empty;
			hasFTEError = r.hasFTEError;
			allowModify = r.AllowModify;
			QueriedRequestRoleId = r.QueriedRequestRoleId;

			OrganizationalUnit orgUnit;
			if (r.Project.OrganizationUnitId.HasValue && CacheService.AllOrganizationalUnits.TryGetValue(r.Project.OrganizationUnitId.GetValueOrDefault(), out orgUnit))
			{
				ProjectOrganizationalUnit = orgUnit.Name;
			}
		}

		public static SubmittedRequestRowData Create(Request r, RequestCommonData commonData)
		{
			return new SubmittedRequestRowData(r, commonData);
		}

		#region Properties
		[DataMember]
		public string VisitTypeName;
		[DataMember]
		public string RequestBudgeted;
		[DataMember]
		public string RequestBlinded;
		[DataMember]
		public string CountryRegion;
		[DataMember]
		public string CurrentMonthFTE;
		[DataMember]
		public string SecondMonthFTE;
		[DataMember]
		public string ThirdMonthFTE;
		[DataMember]
		public string FourthMonthFTE;
		[DataMember]
		public string FifthMonthFTE;
		[DataMember]
		public string SixthMonthFTE;
		[DataMember]
		public bool hasFTEError;
		[DataMember]
		public bool allowModify;
		[DataMember]
		public string MonthlyFTESSVAttrCountryLevel;
		[DataMember]
		public string ProjectOrganizationalUnit { get; set; }
		[DataMember]
		public int? QueriedRequestRoleId { get; set; }
		#endregion
	}

	[DataContract]
	public class SsvRequestRowData : NonProposalRequestRowData
	{
		public SsvRequestRowData(Request r, RequestCommonData commonData)
			: base(r)
		{
			RmPageLinkId = commonData.RmPageLinkId;
		}

		public static SsvRequestRowData Create(Request r, RequestCommonData commonData)
		{
			return new SsvRequestRowData(r, commonData);
		}
	}

	[DataContract]
	public class MonitoringRequestRowData : NonProposalRequestRowData
	{
		public MonitoringRequestRowData(Request r, RequestCommonData commonData)
			: base(r)
		{
			RmPageLinkId = commonData.RmPageLinkId;
		}

		public static MonitoringRequestRowData Create(Request r, RequestCommonData commonData)
		{
			return new MonitoringRequestRowData(r, commonData);
		}
	}

	[DataContract]
	public class SoftBookedRequestRowData : InitiateRequestRowData
	{
		public SoftBookedRequestRowData(ResourceRequestAssignment rra, RequestCommonData commonData)
			: base(rra.Request, commonData)
		{
			id = rra.Id;
			IconColumn = rra.Request.GetAllIconHtml(rra.WasBookingRejected);
			ResourceId = rra.Resource.Id;
			Resource = rra.Resource.Name;
			Cluster = (rra.Request.ProjectProtocolSite != null && rra.Request.ProjectProtocolSite.Cluster != null)
						? rra.Request.ProjectProtocolSite.Cluster.Name
						: string.Empty;
			LineManager = rra.Resource.ManagerName;

			var requestSchedulerType = rra.Request.RequestSchedulerType;
			FTE = (requestSchedulerType == RequestSchedulerType_E.FlatFteValue || requestSchedulerType == RequestSchedulerType_E.MonitoringCountryLevelForecast)
						? rra.Request.FTE.GetValueOrDefault().To3DecimalString()
						: string.Format(
								@"<img src=""/_layouts/SPUI/images/{1}"" class=""calcImage"" requestId=""{0}"" dataFetched=""false"" divId=""div_{0}"" />",
								rra.Request.Id,
								rra.Request.FteConnectStatus == RequestConnect_E.Connected
										? "calculatorIcon.png"
										: "brokenCalculatorIcon.png");
			SponsorName = rra.Request.Project.Sponsor;
		}

		public static SoftBookedRequestRowData Create(ResourceRequestAssignment rra, RequestCommonData commonData)
		{
			return new SoftBookedRequestRowData(rra, commonData);
		}

		#region Properties
		[DataMember]
		public int ResourceId;
		[DataMember]
		public string Cluster;
		[DataMember]
		public string LineManager;
		[DataMember]
		public string SponsorName;
		#endregion
	}
	#endregion

	[DataContract]
	public class MyStaffDataRow : JqGridDataRow
	{
		public MyStaffDataRow(Resource resource)
		{
			id = resource.Id;
			Qid = resource.Qid;
			Name = resource.Name;
			JobTitle = resource.JobTitle;
			Office = resource.QOffice;
			Status = resource.Active ? Constants.Active : Constants.InActive;
			ContractHours = resource.ContractHours.ToString();
			City = resource.City;
			StateProvince = resource.StateProvince == null ? string.Empty : resource.StateProvince.Name;
			Notes = resource.GetNotesColumnValue(false);
			Message = resource.Message.GetSerializedJsonData();
			Organization = resource.Organization;
			OrganizationalUnit = resource.OrganizationalUnit;
			JobRole = resource.PrimaryJobRole;
			CompetencyBand = resource.CompetencyBand;
			ResourceRequestTypes = resource.ResourceRequestTypes;
			ManagerName = resource.ManagerName;
			OriginalContractHours = resource.OriginalContractHours.ToString();
			Country = resource.Country == null ? string.Empty : resource.Country.Name;
			HomeCountry = resource.HomeCountryName;
			ResourceTmfPlatform = resource.ResourceTmfPlatform;
			PreferredSponsor = resource.PreferredSponsor;
			TherapeuticAreas = resource.TherapeuticAreas;
		}

		public static MyStaffDataRow Create(Resource resource, ResourceCommonData commonData)
		{
			return new MyStaffDataRow(resource);
		}

		#region Properties
		[DataMember]
		public string Qid;
		[DataMember]
		public string Name;
		[DataMember]
		public string JobTitle;
		[DataMember]
		public string Office;
		[DataMember]
		public string Status;
		[DataMember]
		public string ContractHours;
		[DataMember]
		public string City;
		[DataMember]
		public string StateProvince;
		[DataMember]
		public string Country;
		[DataMember]
		public string HomeCountry;
		[DataMember]
		public string Notes;
		[DataMember]
		public string Message;
		[DataMember]
		public string Organization;
		[DataMember]
		public string OrganizationalUnit;
		[DataMember]
		public string JobRole;
		[DataMember]
		public string CompetencyBand;
		[DataMember]
		public string ResourceRequestTypes;
		[DataMember]
		public string ManagerName;
		[DataMember]
		public string OriginalContractHours;
		[DataMember]
		public string ResourceTmfPlatform;
		[DataMember]
		public string PreferredSponsor;
		[DataMember]
		public string TherapeuticAreas;
		#endregion
	}

	[DataContract]
	public class ResourceDataRow : JqGridDataRow
	{
		public ResourceDataRow(Resource res)
		{
			id = res.Id;
			Cluster = res.Cluster == null ? string.Empty : res.Cluster.Name;
			//EmployeeStatus = res.GetStatusDescription();
			EmployeeStatus = res.Active ? Constants.Active : Constants.InActive;
			Location = res.GetLocation();
			Manager = res.ManagerQid;
			Organization = res.OrganizationalUnitId.HasValue ? CacheService.OrganizationalUnit(res.OrganizationalUnitId).Name : String.Empty;
			QId = res.Qid;
			ResourceName = res.Name;
		}

		public static ResourceDataRow Create(Resource resource, ResourceCommonData commonData)
		{
			return new ResourceDataRow(resource);
		}

		#region Properties
		[DataMember]
		public string QId;
		[DataMember]
		public string ResourceName;
		[DataMember]
		public string Organization;
		[DataMember]
		public string EmployeeStatus;
		[DataMember]
		public string Location;
		[DataMember]
		public string Cluster;
		[DataMember]
		public string Manager;
		#endregion
	}

	[DataContract]
	public class AttributeRowData : JqGridDataRow
	{
		public AttributeRowData(ICountryAttribute attr, AttributeCommonData commonData)
		{
			Country attrCountry = CacheService.Countries[attr.CountryId];
			id = attr.Id;
			Region = attrCountry.Subregion.Region.Name;
			Country = attrCountry.Name;
			Notes = attr.GetNotesColumnValue(false);
			IsActive = attr.IsActive == 0 ? Constants.InActive : Constants.Active;
		}

		#region Properties
		[DataMember]
		public string Region;
		[DataMember]
		public string Country;
		[DataMember]
		public string Notes;
		[DataMember]
		public string IsActive;
		[DataMember]
		public string StartDate;
		[DataMember]
		public string StopDate;
		[DataMember]
		public string PresentInQip;
		#endregion
	}

	[DataContract]
	public class ConnectableGridColumn
	{
		[DataMember]
		public string Value { get; set; }
		[DataMember]
		public string ConnectedValue { get; set; }
		[DataMember]
		public bool IsConnected { get; set; }

		public ConnectableGridColumn(string value, string connectedValue, bool isConnected)
		{
			Value = value;
			ConnectedValue = connectedValue;
			IsConnected = isConnected;
		}
	}

	[DataContract]
	public class MonitoringAttributeRowData : AttributeRowData
	{
		#region Properties
		[DataMember]
		public string IMDate;
		[DataMember]
		public DateStatus IMDateStatus;
		[DataMember]
		public string CRADate;
		[DataMember]
		public DateStatus CRADateStatus;
		[DataMember]
		public string ProjectedInitiatedSites;
		[DataMember]
		public ConnectableGridColumn QipBudgetedSites;
		[DataMember]
		public string QipBudgetedSivCovVisitCount;
		[DataMember]
		public ConnectableGridColumn QipBudgetedOnsiteImvVisitCount;
		[DataMember]
		public ConnectableGridColumn QipBudgetedRemoteVisitCount;
		[DataMember]
		public ConnectableGridColumn QipBudgetedPharmacyVisitCount;
		[DataMember]
		public string ProjectedSivCovVisitCount;
		[DataMember]
		public string ProjectedOnsiteImvVisitCount;
		[DataMember]
		public string ProjectedRemoteVisitCount;
		[DataMember]
		public string ProjectedPharmacyVisitCount;
		[DataMember]
		public string ActualActiveSites;
		[DataMember]
		public string ActualVisits;
		[DataMember]
		public ConnectableGridColumn BudgetedBoosterVisitCount;
		#endregion

		public MonitoringAttributeRowData(MonitoringAttribute ma, AttributeCommonData commonData)
			: base(ma, commonData)
		{
			IMDate = ma.IMDate.ToQDateString();
			IMDateStatus = new DateStatus { connected = 0, changeIcon = false };
			CRADate = ma.CRATrainingDate.ToQDateString();
			CRADateStatus = new DateStatus { connected = 0, changeIcon = false };
			StartDate = ma.MonitoringAttributeStartDate.ToQDateString();
			StopDate = ma.MonitoringAttributeStopDate.ToQDateString();
			ProjectedInitiatedSites = ma.BudgetedSites.GetValueOrDefault().ToString();
			QipBudgetedSites = new ConnectableGridColumn(ma.QipBudgetedSites.GetValueOrDefault().ToString(), StringHelper.GetStringValueOrEmptyString(ma.QipBudgetedSitesConnectedValue), ma.IsQipBudgetedSitesConnected.GetValueOrDefault());

			ProjectedSivCovVisitCount = (ma.ProjectedSivVisitCount + ma.ProjectedCovVisitCount).GetValueOrDefault().ToString();
			ProjectedOnsiteImvVisitCount = ma.ProjectedOnsiteImvVisitCount.GetValueOrDefault().ToString();
			ProjectedRemoteVisitCount = ma.ProjectedRemoteVisitCount.GetValueOrDefault().ToString();
			ProjectedPharmacyVisitCount = ma.ProjectedPharmacyVisitCount.GetValueOrDefault().ToString();

			QipBudgetedSivCovVisitCount = (ma.QipBudgetedSivVisitCount + ma.QipBudgetedCovVisitCount).GetValueOrDefault().ToString();
			QipBudgetedOnsiteImvVisitCount = new ConnectableGridColumn(ma.QipBudgetedOnsiteImvVisitCount.GetValueOrDefault().ToString(), StringHelper.GetStringValueOrEmptyString(ma.QipBudgetedOnsiteImvVisitCountConnectedValue), ma.IsQipBudgetedOnsiteImvVisitCountConnected.GetValueOrDefault());
			QipBudgetedRemoteVisitCount = new ConnectableGridColumn(ma.QipBudgetedRemoteVisitCount.GetValueOrDefault().ToString(), StringHelper.GetStringValueOrEmptyString(ma.QipBudgetedRemoteVisitCountConnectedValue), ma.IsQipBudgetedRemoteVisitCountConnected.GetValueOrDefault());
			QipBudgetedPharmacyVisitCount = new ConnectableGridColumn(ma.QipBudgetedPharmacyVisitCount.GetValueOrDefault().ToString(), StringHelper.GetStringValueOrEmptyString(ma.QipBudgetedPharmacyVisitCountConnectedValue), ma.IsQipBudgetedPharmacyVisitCountConnected.GetValueOrDefault());
			BudgetedBoosterVisitCount = new ConnectableGridColumn(ma.BudgetedBoosterVisitCount.GetValueOrDefault().ToString(), StringHelper.GetStringValueOrEmptyString(ma.BudgetedBoosterVisitCountConnectedValue), ma.IsBudgetedBoosterVisitCountConnected.GetValueOrDefault());

			ActualActiveSites = ma.ActualActiveSites.GetValueOrDefault().ToString();
			ActualVisits = ma.ActualVisits.GetValueOrDefault().ToString();
			PresentInQip = ma.PresentInQip ? "Yes" : "No";
		}

		public static MonitoringAttributeRowData Create(MonitoringAttribute resource, AttributeCommonData commonData)
		{
			return new MonitoringAttributeRowData(resource, commonData);
		}
	}

	[DataContract]
	public class SsvAttributeRowData : AttributeRowData
	{
		#region Properties
		[DataMember]
		public string ProjectedStartStopDate;
		[DataMember]
		public string SIFSentDate;
		[DataMember]
		public ConnectableGridColumn QipBudgetedSites;
		[DataMember]
		public string ProjectedTotalSites;
		#endregion

		public SsvAttributeRowData(SSVAttribute sa, AttributeCommonData commonData)
			: base(sa, commonData)
		{
			IsActive = sa.IsActive == 1 ? Constants.Active : Constants.InActive;
			StartDate = sa.SSVAttributeStartDate.ToQDateString();
			StopDate = sa.SSVAttributeStopDate.ToQDateString();
			SIFSentDate = sa.EarliestSIFSentDate.ToQDateString();
			QipBudgetedSites = new ConnectableGridColumn(StringHelper.GetStringValueOrEmptyString(sa.QipBudgetedSites), StringHelper.GetStringValueOrEmptyString(sa.QipBudgetedSitesConnectedValue), sa.IsQipBudgetedSitesConnected.GetValueOrDefault());
			ProjectedTotalSites = sa.ProjectedTotalSites.HasValue ? sa.ProjectedTotalSites.GetValueOrDefault().ToString() : string.Empty;
			PresentInQip = sa.QipStatus ? "Yes" : "No";
		}

		public static SsvAttributeRowData Create(SSVAttribute sa, AttributeCommonData commonData)
		{
			return new SsvAttributeRowData(sa, commonData);
		}
	}

	[DataContract]
	public class ProjJobRoleExpCriteriaRowData : JqGridDataRow
	{
		public ProjJobRoleExpCriteriaRowData(GridProjectJobRoleExperienceCriteria_WS ec, GridRowCommonData commonData)
		{
			id = ec.ProjectJobRoleExperienceCriteriaId;
			JobRole = ec.JobRole;
			AppliesTo = ec.AppliesTo;
			ResourceRequirementType = ec.ResourceRequirementType;
			ExperienceCategory = ec.ExperienceCategory;
			Experience = ec.Experience;
			Notes = ec.Notes;
			JobRoleId = ec.JobRoleId;
			ProjectJobRoleId = ec.ProjectJobRoleId;
			ProjectJobRoleExperienceCriteriaId = ec.ProjectJobRoleExperienceCriteriaId;
			RequirementTypeId = ec.RequirementTypeId;
			ExperienceCategoryId = ec.ExperienceCategoryId;
			TherapeuticAreaId = ec.TherapeuticAreaId;
			NoOfYearsForArea = ec.NoOfYearsForArea;
			IndicationId = ec.IndicationId;
			NoOfYearsForIndication = ec.NoOfYearsForIndication;
			InHouseMonitoring = ec.InHouseMonitoring;
			OnSiteMonitoring = ec.OnSiteMonitoring;
			GlobalProjectExperience = ec.GlobalProjectExperience;
			AppliesToIds = ec.AppliesToIds;
		}

		public static ProjJobRoleExpCriteriaRowData Create(GridProjectJobRoleExperienceCriteria_WS ec, GridRowCommonData commonData)
		{
			return new ProjJobRoleExpCriteriaRowData(ec, commonData);
		}

		#region Properties
		[DataMember]
		public string JobRole;
		[DataMember]
		public string AppliesTo;
		[DataMember]
		public string ResourceRequirementType;
		[DataMember]
		public string ExperienceCategory;
		[DataMember]
		public string Experience;
		[DataMember]
		public string Notes;
		[DataMember]
		public int JobRoleId;
		[DataMember]
		public int ProjectJobRoleId { get; set; }
		[DataMember]
		public int ProjectJobRoleExperienceCriteriaId { get; set; }
		[DataMember]
		public int RequirementTypeId { get; set; }
		[DataMember]
		public int ExperienceCategoryId { get; set; }
		[DataMember]
		public int TherapeuticAreaId { get; set; }
		[DataMember]
		public string NoOfYearsForArea { get; set; }
		[DataMember]
		public int IndicationId { get; set; }
		[DataMember]
		public string NoOfYearsForIndication { get; set; }
		[DataMember]
		public string InHouseMonitoring { get; set; }
		[DataMember]
		public string OnSiteMonitoring { get; set; }
		[DataMember]
		public string GlobalProjectExperience { get; set; }
		[DataMember]
		public string AppliesToIds { get; set; }
		#endregion
	}

	[DataContract]
	public class OpenResourceRequestRowData : JqGridDataRow
	{
		public OpenResourceRequestRowData(OpenRequestQueue orq, GridRowCommonData commonData)
		{
			id = orq.Id;

			Region = orq.RegionName;
			Country = orq.CountryName;
			Message = string.Empty;
			CountryRegion = orq.CountryRegion;
			Sponsor = orq.Project.Sponsor;
			Program = orq.Project.Program;
			ProjectCode = orq.Project.ProjectCode;
			Protocol = orq.ProtocolNumber;
			ProjectDteType = orq.Project.ProjectDteType.GetEnumDescription();
			Organization = orq.Organization;
			TherapeuticAreaName = orq.TherapeuticAreaName;
			SitesBudgeted = String.Format("{0}/{1}/{2}", orq.Budgeted, orq.Identified, orq.Resourced);
			StaffRole = orq.GroupDescription;
			NeedDate = orq.NeedByDate.ToQDateString();
			NeedDateSort = orq.NeedByDate.ToISODate();
			IconColumn = ((orq.NeedByDate.HasValue
											? Convert.ToDateTime(orq.NeedByDate)
											: (DateTime?)null) < DateTime.Today.AddDays(2) ? string.Format("{0}", "<div class='iconOverdue iconStatus' />") : string.Empty);
			IconColumn = string.Format("{0}{1}", IconColumn, orq.HasRmPpmDteFlagDiscrepancy ? "<div class='iconRmPpmDteMismatchOrq iconStatus' />" : string.Empty);
			SubmittedDateRange = orq.SubmittedDateRange;
			SubmittedDateRangeSort = orq.MinSubmittedDate.ToISODate();
			HiddenJson = JsonConvert.SerializeObject(new OpenRequestGridData
			{
				countryId = orq.Country == null ? Constants.UnspecifiedId : orq.Country.Id,
				projectId = orq.Project.Id,
				regionId = orq.Region == null ? Constants.UnspecifiedId : orq.Region.Id,
				protocolNumber = orq.ProtocolNumber,
				requestTypeResourceTypeGroupId = orq.RequestTypeResourceTypeGroupId,
				countryRegionId = orq.CountryRegionId,
				rowId = orq.Id
			});
		}

		public static OpenResourceRequestRowData Create(OpenRequestQueue orq, GridRowCommonData commonData)
		{
			return new OpenResourceRequestRowData(orq, commonData);
		}

		[DataMember]
		public string Region;
		[DataMember]
		public string Country;
		[DataMember]
		public string Message;
		[DataMember]
		public string CountryRegion;
		[DataMember]
		public string Sponsor;
		[DataMember]
		public string Program;
		[DataMember]
		public string ProjectCode;
		[DataMember]
		public string Protocol;
		[DataMember]
		public string ProjectDteType;
		[DataMember]
		public string Organization;
		[DataMember]
		public string TherapeuticAreaName;
		[DataMember]
		public string SitesBudgeted;
		[DataMember]
		public string StaffRole;
		[DataMember]
		public string NeedDate;
		[DataMember]
		public string NeedDateSort;
		[DataMember]
		public string HiddenJson;
		[DataMember]
		public string IconColumn;
		[DataMember]
		public string SubmittedDateRange;
		[DataMember]
		public string SubmittedDateRangeSort;
	}

	[DataContract]
	public class OpenRequestGridData
	{
		[DataMember]
		public int rowId { get; set; }

		[DataMember]
		public String listOfIds { get; set; }

		[DataMember]
		public int countryId { get; set; }

		[DataMember]
		public int regionId { get; set; }

		[DataMember]
		public int projectId { get; set; }

		[DataMember]
		public string protocolNumber { get; set; }

		[DataMember]
		public int? countryRegionId { get; set; }

		[DataMember]
		public int requestTypeResourceTypeGroupId { get; set; }

	}

	[DataContract]
	public class ResourcingWorklistRequestRowData : NonProposalRequestRowData
	{
		[DataMember]
		public string SearchResourceType { get; set; }

		[DataMember]
		public string RequestBlinded { get; set; }

		[DataMember]
		public string ShowUnBlindedColumn { get; set; }

		[DataMember]
		public DateTime? DateSubmittedAsDateTime { get; set; }
		[DataMember]
		public int? TmfPlatformId { get; set; }
		public ResourcingWorklistRequestRowData(Request r, RequestCommonData commonData)
			: base(r)
		{
			DateSubmittedAsDateTime = r.DateSubmitted;

			#region geographyIds
			string geographyIds = string.Empty;
			string projectTAIds = string.Empty;
			string projectIndicationIds = string.Empty;
			if (r.CountryId == null && r.Region != null)
			{
				geographyIds = string.Format("{0}||", r.Region.Id);
			}
			else if (r.CountryId != null)
			{
				Country c = CacheService.Countries[r.CountryId.Value];
				geographyIds = string.Format("{0}|{1}|{2}", c.Subregion.Region.Id, c.Subregion.Id, r.CountryId);
			}

			if (r.CountryRegionId.HasValue)
			{
				geographyIds = string.Format("{0}|{1}", geographyIds, r.CountryRegionId);
			}

			#endregion

			#region OrganizationalUnit
			//IList<OrganizationalUnit> orgs = r.ResourceType.OrganizationalUnits;
			//List<string> orgIdList = new List<string>();
			//if (r.IsProposalRequest)
			//{
			//	orgIdList.Add(r.Project.OrganizationUnitId.ToString());
			//}
			//else
			//{
			//	if (orgs.Count > 0)
			//	{
			//		//If we have a ResourceType to Org mapping, then ignore the PPM Org
			//		orgs.Each(org => orgIdList.Add(org.Id.ToString()));
			//	}
			//	else
			//	{
			//		//If we don't have a resourcetype to org mapping, use the PPM org (which could be nothing)
			//		int orgId = OrganizationalUnit_PPM.GetRMOrgIdByPPMOrgName(r.Project.Organization);
			//		orgIdList.Add(orgId.ToString());
			//	}
			//}

			IList<OrganizationalUnit> orgs = r.ResourceType.OrganizationalUnits;
			List<string> orgIdList = new List<string>();
			if (!r.IsProposalRequest && orgs.Count == 1)
			{
				orgIdList.Add(orgs[0].Id.ToString());
			}
			else
			{
				orgIdList.Add(r.Project.OrganizationUnitId.ToString());
			}
			#endregion

			#region TA
			//RMK Added
			projectTAIds = ProjectTherapeuticArea.FindByProjectId(r.Project.Id);
			#endregion

			#region Languages
			List<string> LangIds = new List<string>();
			if (r.Country != null && r.Country.LanguageList.Count > 0)
			{
				r.Country.LanguageList.Each(lan => LangIds.Add(lan.Id.ToString()));
			}
			#endregion

			#region Indication
			projectIndicationIds = ProjectIndications.FindByProjectId(r.Project.Id);
			#endregion


			#region ExperienceTypes
			ExperienceProjectRole_WS er = new ExperienceProjectRole_WS();
			er.ProjectCode = r.Project.ProjectCode;
			er.ProjectId = r.Project.Id;
			er.JobRoleId = r.ResourceType.JobRole.Id;
			er.ResourceTypeId = r.ResourceType.Id;
			#endregion
			RequestBlinded = r.RequestBlindedString;
			ShowUnBlindedColumn = r.Project.IsOpenLabel.GetValueOrDefault() ? "No" : (r.ResourceType.DisplaysBlindedField == true || r.ResourceType.AssigneesAlwaysUnblinded == true || r.ResourceType.ShowUnBlindedColumn == true) ? "Yes" : "No";
			SearchResourceType = r.RequestTypeId == 5 ? "Proposal " + r.ResourceType.Name : r.ResourceType.Name;
			ExperienceTypes = Common.SerializeObjectToJsonNoLoops(er);
			RequestId = r.Id;
			GeographyIds = geographyIds;
			StudyPhaseId = StudyPhase.GetIdByName(r.Project.Phase).ToString();
			FTE = r.GetReadonlyFteImage();
			NeedDate = r.NeedByDate.ToQDateString();
			NeedDateSort = r.NeedByDate.ToISODate();
			CRATrainingDate = r.CRATrainingDate.ToQDateString();
			CRATrainingDateSort = r.CRATrainingDate.ToISODate();
			StartDateSort = r.StartDate.ToISODate();
			StopDateSort = r.StopDate.ToISODate();
			OrganizationalUnitIds = String.Join("|", orgIdList.ToArray());
			VisitType = r.SiteVisitType == null ? string.Empty : r.SiteVisitType.Name;
			CountryRegion = r.CountryRegionId.HasValue ? r.CountryRegion.Name : string.Empty;
			AssignedRegions = r.AssignedRegions;
			AssignedCountries = r.AssignedCountries;
			SiteName = r.SponsorSite;
			SiteId = r.SiteId.GetValueOrDefault(-1);
			SiteStatus = r.SiteStatus;
			Sponsor = r.Project.CustomerName;
			SponsorId = r.GetCustomerId();
			SponsorSiteId = r.SponsorSiteId;
			ProjectTA = projectTAIds;
			ProjectIndication = projectIndicationIds;
			LanguageIds = String.Join("|", LangIds.ToArray());
			CompetencyBandId = r.CompetencyBandId;
			TmfPlatformId = r.ProjectTmfPlatformId;
			if (r.CompetencyBand != null) { CompetencyBandName = r.CompetencyBand.Name; }
			if (r.ProjectProtocolSite != null)
			{
				Cluster = (r.ProjectProtocolSite.Cluster != null) ? r.ProjectProtocolSite.Cluster.Name : "";
				Location = r.GetAddress();
			}
		}

		public static ResourcingWorklistRequestRowData Create(Request r, RequestCommonData commonData)
		{
			return new ResourcingWorklistRequestRowData(r, commonData);
		}

		#region Properties
		[DataMember]
		public string ExperienceTypes;
		[DataMember]
		public string Message;
		[DataMember]
		public string MonthlySched;
		[DataMember]
		public string GeographyIds;
		[DataMember]
		public string StudyPhaseId;
		[DataMember]
		public string OrganizationalUnitIds;
		[DataMember]
		public string CRATrainingDate;
		[DataMember]
		public string CRATrainingDateSort;
		[DataMember]
		public string StartDateSort;
		[DataMember]
		public string StopDateSort;
		[DataMember]
		public string CountryRegion;
		[DataMember]
		public string Cluster;
		[DataMember]
		public string AssignedRegions;
		[DataMember]
		public string AssignedCountries;
		[DataMember]
		public string Sponsor;
		[DataMember]
		public string SponsorId;
		[DataMember]
		public string SponsorSiteId;
		[DataMember]
		public string NeedDate;
		[DataMember]
		public string NeedDateSort;
		[DataMember]
		public int RequestId;
		[DataMember]
		public string SiteName;
		[DataMember]
		public string ProjectTA;
		[DataMember]
		public string ProjectIndication;
		[DataMember]
		public string LanguageIds;
		[DataMember]
		public int? CompetencyBandId;
		[DataMember]
		public string CompetencyBandName;
		[DataMember]
		public string VisitType;
		#endregion
	}

	[DataContract]
	public class ResourceAssignmentRowData : JqGridDataRow
	{
		public bool IsIndefinite { get; set; }
		public ResourceAssignmentRowData(ResourceRequestAssignment assignment, GridRowCommonData commonData)
		{
			#region FTE column
			var requestSchedulerType = assignment.Request.RequestSchedulerType;
			if (assignment.Request.AssignmentType == "AVT")
			{
				FTE = assignment.Request.FTE.GetValueOrDefault().To2DecimalString();
			}
			else if (assignment.Request.AssignmentType == "Special Assignment")
			{
				SpecialAssignmentAllocation = (assignment.Request.FTE.GetValueOrDefault() * 100).To2DecimalString();
			}
			else if (requestSchedulerType == RequestSchedulerType_E.FlatFteValue)
			{
				FTE = assignment.Request.FTE.GetValueOrDefault().To3DecimalString();
			}
			else
			{
				FTE = string.Format(@"<img src=""/_layouts/SPUI/images/{1}"" class=""calcImage"" requestId=""{0}"" dataFetched=""false"" divId=""div_{0}"" assignmentId= ""{2}"" allowModify= ""{3}""/>",
						assignment.Request.Id, assignment.Request.FteConnectStatus == RequestConnect_E.Connected ? "calculatorIcon.png" : "brokenCalculatorIcon.png", assignment.Id, assignment.Request.AllowModify);
			}
			#endregion

			#region icon for notes column
			if (assignment.Request.AssignmentType == "AVT")
			{
				Notes = string.Empty;
			}
			else if (assignment.Request.AssignmentType == "Special Assignment")
			{
				Notes = SpecialAssignment.GetNotesColumnValue(assignment.UP_SpecialAssignmentId.GetValueOrDefault());
			}
			else
			{
				Notes = assignment.Request.GetNotesColumnValue(true);
			}
			#endregion

			id = assignment.Id;
			HiddenJSON = JsonConvert.SerializeObject(new MyStaffAssignmentsJson(assignment));
			AssignmentIndicator = assignment.Request.GetAllIconHtml(assignment.WasBookingRejected);
			AssignmentType = assignment.Request.AssignmentType;
			if (assignment.Request.Project != null)
			{
				ProgramName = assignment.Request.Project.ProgramName;
				ProjectCode = assignment.Request.Project.ProjectCode;
				Sponsor = assignment.Request.Project.Sponsor;
			}

			if ("Special Assignment".Equals(assignment.Request.AssignmentType, StringComparison.InvariantCultureIgnoreCase))
			{
				SpecialAssignmentCategoryId = assignment.UP_SpecialAssignmentCategory == null ? "Undefined" : assignment.UP_SpecialAssignmentCategory.Description;
			}

			if (!"AVT".Equals(assignment.Request.AssignmentType, StringComparison.InvariantCultureIgnoreCase) &&
				!"Special Assignment".Equals(assignment.Request.AssignmentType, StringComparison.InvariantCultureIgnoreCase))
			{
				ResourceType = assignment.Request.ResourceType.Name;
				CountryName = assignment.Request.CountryName;
			}
			RequestStatusId = assignment.Request.RequestStatusId;
			AssignmentDescription = assignment.UP_SpecialAssignmentDescription;
			AssignmentId = assignment.UP_SpecialAssignmentId.ToString();
			SiteId = assignment.Request.ProjectProtocolSite != null ? assignment.Request.ProjectProtocolSite.PiLastName_City_SponsorSite : string.Empty;
			StartDate = assignment.Request.StartDate.ToQDateString();
			StopDate = assignment.Request.StopDate.ToQDateString();
			RequestId = (assignment.Request.Id > 0) ? assignment.Request.Id.ToString() : string.Empty;
			SpecialAssignmentProjectCode = assignment.SpecialAssignmentProjectCode;
			SpecialAssignmentProjectCodeInRm = assignment.SpecialAssignmentProjectCodeInRm;
			allowModify = assignment.Request.AllowModify;
			AccountName = assignment.UP_AccountName;
			RequestTypeId = assignment.Request.RequestTypeId;
			ResourceTypeId = assignment.Request.ResourceTypeId;
			hasFTEError = assignment.Request.hasFTEError;
			ProjectId = (assignment.Request.Project != null) ? assignment.Request.Project.Id : -1;
			IsIndefinite = assignment.IsIndefinite;
		}

		public static ResourceAssignmentRowData Create(ResourceRequestAssignment assignment, GridRowCommonData commonData)
		{
			return new ResourceAssignmentRowData(assignment, commonData);
		}

		#region Properties
		[DataMember]
		public string HiddenJSON;
		[DataMember]
		public string Message;
		[DataMember]
		public string AssignmentIndicator;
		[DataMember]
		public string AssignmentType;
		[DataMember]
		public string CountryName;
		[DataMember]
		public string ProgramName;
		[DataMember]
		public string SpecialAssignmentCategoryId;
		[DataMember]
		public string AssignmentDescription;
		[DataMember]
		public string ProjectCode;
		[DataMember]
		public string AssignmentId;
		[DataMember]
		public string Sponsor;
		[DataMember]
		public string SiteId;
		[DataMember]
		public string ResourceType;
		[DataMember]
		public string StartDate;
		[DataMember]
		public string StopDate;
		[DataMember]
		public string FTE;
		[DataMember]
		public string Notes;
		[DataMember]
		public string RequestId;
		[DataMember]
		public Boolean allowModify;
		[DataMember]
		public string SpecialAssignmentProjectCode;
		[DataMember]
		public bool SpecialAssignmentProjectCodeInRm;
		[DataMember]
		public string SpecialAssignmentAllocation;
		[DataMember]
		public string AccountName;
		[DataMember]
		public int RequestStatusId;
		[DataMember]
		public int RequestTypeId;
		[DataMember]
		public bool hasFTEError;
		[DataMember]
		public int ProjectId;
		[DataMember]
		public int ResourceTypeId;

		#endregion
	}

	[DataContract]
	public class UserPermissionRowData : JqGridDataRow
	{
		public UserPermissionRowData(RmUserTable rmUser, GridRowCommonData commonData)
		{
			id = rmUser.Id;
			Id = rmUser.Id;
			Qid = rmUser.QId;
			Name = rmUser.Name;
			Organization = rmUser.Organization;
			JobTitle = rmUser.JobTitle;
			QOffice = rmUser.QOffice;
			Status = rmUser.Status;
			Country = rmUser.CountryCode;
			Role = rmUser.Role;
			AllowedCountries = rmUser.Count_AllowedCountries;
			AllowedResTypes = rmUser.Count_AllowedResTypes;
			JobRole = rmUser.JobRole;
		}

		public static UserPermissionRowData Create(RmUserTable rmUser, GridRowCommonData commonData)
		{
			return new UserPermissionRowData(rmUser, commonData);
		}

		#region Properties

		[DataMember]
		public int Id;
		[DataMember]
		public string Qid;
		[DataMember]
		public string Name;
		[DataMember]
		public string JobTitle;
		[DataMember]
		public string QOffice;
		[DataMember]
		public string Organization;
		[DataMember]
		public string Status;
		[DataMember]
		public string Country;
		[DataMember]
		public string Role;
		[DataMember]
		public string AllowedCountries;
		[DataMember]
		public string AllowedResTypes;
		[DataMember]
		public string JobRole;
		#endregion
	}

	[DataContract]
	public class CustomMilestoneRowData : JqGridDataRow
	{
		public CustomMilestoneRowData(CustomMilestones c)
		{
			id = c.Id;
			MilestoneName = c.Name;
			ProjectId = c.ProjectId;
			MilestoneDate = c.MilestoneDate.ToQDateString();
			OrganizationalUnitName = c.OrganizationalUnitName;
			OrganizationalUnitId = c.OrganizationalUnitId;
		}
		public CustomMilestoneRowData() { }
		public static CustomMilestoneRowData Create(CustomMilestones c, GridRowCommonData commonData)
		{
			return new CustomMilestoneRowData(c);
		}

		#region Properties
		[DataMember]
		public string MilestoneName { get; set; }
		[DataMember]
		public int ProjectId { get; set; }
		[DataMember]
		public string OrganizationalUnitName { get; set; }
		[DataMember]
		public string MilestoneDate { get; set; }
		[DataMember]
		public int OrganizationalUnitId { get; set; }
		#endregion
	}

	[DataContract]
	public class SkillsetCategoryRowData : JqGridDataRow
	{
		public SkillsetCategoryRowData(SkillsetCriteria s)
		{
			id = s.Id;
			CategoryName = s.CategoryName;
			SelectedText = s.SelectedText;
			SelectedValue = s.SelectedValue;

		}

		public static SkillsetCategoryRowData Create(SkillsetCriteria s, GridRowCommonData commonData)
		{
			return new SkillsetCategoryRowData(s);
		}

		#region Properties

		[DataMember]
		public int CategoryId { get; set; }

		[DataMember]
		public string CategoryName { get; set; }

		[DataMember]
		public string SelectedText { get; set; }

		[DataMember]
		public string SelectedValue { get; set; }

		#endregion
	}

	[DataContract]
	public class CountryMilestoneRowData : JqGridDataRow
	{
		public CountryMilestoneRowData(GridSearchCountryMilestone_WS c)
		{
			id = c.Id;
			CountryMilestoneId = c.CountryMilestoneId;
			CountryId = c.CountryId;
			ProjectId = c.ProjectId;
			RegionName = c.RegionName;
			CountryName = c.CountryName;
			MilestoneName = c.MilestoneName;
			MilestoneDate = c.MilestoneDate;
			Comment = c.Comment;
			MappingTable = c.MappingTable;
			MappingColumn = c.MappingColumn;
			DateToCompare = c.DateToCompare;
			ManualEntryDate = c.ManualEntryDate;
			IsPpmMilestone = c.IsPpmMilestone;
			OrganizationalUnitId = c.OrganizationalUnitId;
		}

		public static CountryMilestoneRowData Create(GridSearchCountryMilestone_WS c, GridRowCommonData commonData)
		{
			return new CountryMilestoneRowData(c);

		}

		#region Properties

		[DataMember]
		public int CountryMilestoneId { get; set; }

		[DataMember]
		public int CountryId { get; set; }

		[DataMember]
		public int ProjectId { get; set; }

		[DataMember]
		public string RegionName { get; set; }

		[DataMember]
		public string CountryName { get; set; }

		[DataMember]
		public string MilestoneName { get; set; }

		[DataMember]
		public string MilestoneDate { get; set; }

		[DataMember]
		public string Comment { get; set; }

		[DataMember]
		public string MappingTable { get; set; }

		[DataMember]
		public string MappingColumn { get; set; }

		[DataMember]
		public string DateToCompare { get; set; }

		[DataMember]
		public string ManualEntryDate { get; set; }
		[DataMember]
		public bool IsPpmMilestone { get; set; }
		[DataMember]
		public int? OrganizationalUnitId { get; set; }
		#endregion
	}
	[DataContract]
	public class DelegateResourceRowData : JqGridDataRow
	{
		[DataMember]
		public int OriginalManagerResourceId { get; set; }

		[DataMember]
		public string OriginalManager { get; set; }

		[DataMember]
		public int DelegateManagerResourceId { get; set; }

		[DataMember]
		public string DelegateManager { get; set; }

		[DataMember]
		public string StartDate { get; set; }

		[DataMember]
		public string StopDate { get; set; }

		public DelegateResourceRowData(ResourceDelegate resourceDelegate)
		{
			id = resourceDelegate.Id;
			OriginalManagerResourceId = resourceDelegate.OriginalManagerResourceId;
			OriginalManager = resourceDelegate.OriginalManagerName;
			DelegateManagerResourceId = resourceDelegate.DelegateManagerResourceId;
			DelegateManager = resourceDelegate.DelegateManagerName;
			StartDate = resourceDelegate.StartDate.ToQDateString();
			StopDate = resourceDelegate.StopDate.ToQDateString();
		}

		public static DelegateResourceRowData Create(ResourceDelegate resourceDelegate, GridRowCommonData gcd)
		{
			return new DelegateResourceRowData(resourceDelegate);
		}
	}
	[DataContract]
	public class ResourceTypeRowData : JqGridDataRow
	{
		public ResourceTypeRowData(GridSearchResourceTypes_WS c)
		{
			id = c.ResourceTypeId;
			ResourceTypeId = c.ResourceTypeId;
			OrganizationName = c.OrganizationName;
			ResourceTypeName = c.ResourceTypeName;
			OrganizationId = c.OrganizationId;
			CanInitiateNewRequests = c.CanInitiateNewRequests;
			IsEnabled = c.IsEnabled;


		}

		public static ResourceTypeRowData Create(GridSearchResourceTypes_WS c, GridRowCommonData commonData)
		{
			return new ResourceTypeRowData(c);
		}

		#region Properties
		[DataMember]
		public int ResourceTypeId { get; set; }
		[DataMember]
		public string OrganizationName { get; set; }
		[DataMember]
		public string ResourceTypeName { get; set; }
		[DataMember]
		public int OrganizationId { get; set; }
		[DataMember]
		public string IsEnabled { get; set; }
		[DataMember]
		public string CanInitiateNewRequests { get; set; }
		#endregion
	}

	[DataContract]
	public class ResourceSearchRowData : JqGridDataRow
	{
		public ResourceSearchRowData(ResourceResult resourceResult, ResourceSearchCommonData commonData)
		{
			//Have to set the resource before you can render this to the UI
			//  won't be set until after the filters and availability algorithm's run
			if (resourceResult.Resource == null)
			{
				throw new Exception("Resource has not been hydrated yet.  Cannot render as a result");
			}
			id = resourceResult.Resource.Id;
			ResourceId = resourceResult.Resource.Id;
			Message = string.Empty;
			ProjectMatch = resourceResult.ProjectMatch;
			ProgramMatch = resourceResult.ProgramMatch;
			ResourceFireWalled = resourceResult.ResourceFireWalled;
			ResourceFireWalledDetailsHtml = resourceResult.ResourceFireWalledDetailsHtml;
			ProgramUnblinded = (BlindedUnblindedStatus_E)resourceResult.ProgramUnblinded;
			TmfPlatform = resourceResult.Resource.ResourceTmfPlatform;
			if (resourceResult.ResourceCalendar == null)
			{
				MonthlyHours = string.Empty;
				Availability = string.Empty;
			}
			else
			{
				ResourceCalendar.RemoveFirstElementsBeforeKey(resourceResult.ResourceCalendar.MonthlySchedule, commonData.StartMonthYear);
				ResourceCalendar.RemoveFirstElementsAfterKey(resourceResult.ResourceCalendar.MonthlySchedule, commonData.EndMonthYear);
				MonthlyHours = (resourceResult.ResourceCalendar.MonthlySchedule == null
												? ""
												: JsonConvert.SerializeObject(resourceResult.ResourceCalendar.MonthlySchedule.Values)); // MonthlyHours (for charts)
				Availability = resourceResult.ResourceCalendar.RequestCoveragePercent.ToString("N1"); // % Cover
			}

			MatchPercent = "NA";
			if (commonData.TotalPossibleHits != 0)
			{
				double avg = Math.Round(100.0 * ((double)resourceResult.TotalMatches / commonData.TotalPossibleHits), 2);
				MatchPercent = avg.ToString(CultureInfo.InvariantCulture);
			}

			if (resourceResult.ResourceCalendar == null)
			{
				MaxOverbook = string.Empty;
				AvailPercent = string.Empty;
			}
			else
			{
				MaxOverbook = resourceResult.ResourceCalendar.WorstOverbookMonth.ToString("N1"); // Max Over
				AvailPercent = resourceResult.ResourceCalendar.AvailabilityToRequiredPercent.ToString("N1"); // % Avail
			}

			QId = resourceResult.Resource.Qid;
			ResourceName = resourceResult.Resource.Name;
			ResourceJobRoleName = resourceResult.Resource.JobRoleName;
			CompetencyBandName = resourceResult.Resource.CompetencyBand;
			Organization = (resourceResult.Resource.OrganizationalUnitId == null) ? String.Empty : CacheService.OrganizationalUnit(resourceResult.Resource.OrganizationalUnitId).Name;
			EmpStatus = resourceResult.Resource.Active ? Constants.Active : Constants.InActive;
			CountryRegionName = resourceResult.Resource.CountryRegion;
			Location = resourceResult.Resource.GetHomeLocation();
			WorkCountry = resourceResult.Resource.Country != null ? resourceResult.Resource.Country.Name : string.Empty;
			Cluster = resourceResult.Resource.Cluster == null ? string.Empty : resourceResult.Resource.Cluster.Name;
			LineManager = resourceResult.Resource.ManagerName;
			Notes = resourceResult.Resource.GetNotesColumnValue(false);
			JobTitle = resourceResult.Resource.JobTitle;
			JobGrade = resourceResult.Resource.JobGrade;
			StudyPhaseListNotQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.ProjectStudyPhaseNonQuintiles)) ?
															String.Join("|", resourceResult.StudyPhaseListNotQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			StudyPhaseListQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.ProjectStudyPhase)) ?
															String.Join("|", resourceResult.StudyPhaseListQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			LanguageList = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.Language)) ?
															String.Join("|", resourceResult.LanguageList.ToList().ConvertAll(i => i.ToString(CultureInfo.InvariantCulture)).ToArray()) :
															"Exclude";
			SkillList = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.Skill)) ?
															String.Join("|", resourceResult.SkillHash.ToList().ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			IndicationList = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.ProjectIndication)) ?
															String.Join("|", resourceResult.IndicationList.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			AreaList = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.ProjectTherapeuticArea)) ?
															String.Join("|", resourceResult.AreaList.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			Education = ResourceEducation.GetList(resourceResult.Resource.Id);
			SponsorList = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.CustomerKnowledge)) ?
															String.Join("|", resourceResult.SponsorList.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			SpecialPopulatationQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.SpecialPopulatationQuintiles)) ?
															String.Join("|", resourceResult.SpecialPopulatationQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			SpecialPopulatationNotQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.SpecialPopulatationNonQuintiles)) ?
															String.Join("|", resourceResult.SpecialPopulatationNotQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			DrugClassQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.DrugClassQuintiles)) ?
															String.Join("|", resourceResult.DrugClassQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			DrugClassNotQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.DrugClassNonQuintiles)) ?
															String.Join("|", resourceResult.DrugClassNotQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			RoleQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.RoleQuintiles)) ?
															String.Join("|", resourceResult.RoleQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			RoleNotQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.RoleNonQuintiles)) ?
															String.Join("|", resourceResult.RoleNotQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			IndustryTypeNotQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.IndustryTypeNonQuintiles)) ?
															String.Join("|", resourceResult.IndustryTypeNotQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			RegionNotQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.RegionNonQuintiles)) ?
															String.Join("|", resourceResult.RegionNotQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			IndicationQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.IndicationQuintiles)) ?
															String.Join("|", resourceResult.IndicationQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			IndicationNotQ = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.IndicationNonQuintiles)) ?
															String.Join("|", resourceResult.IndicationNotQ.ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";
			SkillValues = (commonData.CriteriaMap.CriteriaTypes.Contains(ResourceCriteriaType_E.Skill)) ?
															String.Join("|", resourceResult.SkillValues.ToList().ToList().ConvertAll(i => i.ToString()).ToArray()) :
															"Exclude";

			ResReqErrors = GetRequestErrorsByResource(resourceResult.ResourceCalendar);
			AreAllRequestsBad = ResReqErrors != null && resourceResult.ResourceCalendar.AssignedRequests != null && resourceResult.ResourceCalendar.AssignedRequests.Count == ResReqErrors.Count;
		}

		private List<ResReqErrors_WS> GetRequestErrorsByResource(ResourceCalendar resCalendar)
		{
			var errors = new List<ResReqErrors_WS>();
			if (resCalendar != null && resCalendar.RequestErrors != null && resCalendar.RequestErrors.Count > 0)
			{
				foreach (var item in resCalendar.RequestErrors)
				{
					errors.Add(new ResReqErrors_WS(item.Key, item.Value));
				}
			}
			return errors;
		}
		public static ResourceSearchRowData Create(ResourceResult resourceResult, ResourceSearchCommonData commonData)
		{
			return new ResourceSearchRowData(resourceResult, commonData);
		}

		#region Properties
		[DataMember]
		public string TmfPlatform { get; set; }
		[DataMember]
		public int ResourceId { get; set; }
		[DataMember]
		public string Message { get; set; }
		[DataMember]
		public bool ProjectMatch { get; set; }
		[DataMember]
		public bool ProgramMatch { get; set; }
		[DataMember]
		public bool ResourceFireWalled { get; set; }
		[DataMember]
		public string ResourceFireWalledDetailsHtml { get; set; }
		[DataMember]
		public BlindedUnblindedStatus_E ProgramUnblinded { get; set; }
		[DataMember]
		public string MonthlyHours { get; set; }
		[DataMember]
		public string Availability { get; set; }
		[DataMember]
		public string MatchPercent { get; set; }
		[DataMember]
		public string MaxOverbook { get; set; }
		[DataMember]
		public string AvailPercent { get; set; }
		[DataMember]
		public string QId { get; set; }
		[DataMember]
		public string ResourceName { get; set; }
		[DataMember]
		public string Organization { get; set; }
		[DataMember]
		public string EmpStatus { get; set; }
		[DataMember]
		public string CountryRegionName { get; set; }
		[DataMember]
		public string Location { get; set; }
		[DataMember]
		public string WorkCountry { get; set; }
		[DataMember]
		public string Cluster { get; set; }
		[DataMember]
		public string LineManager { get; set; }
		[DataMember]
		public string Notes { get; set; }
		[DataMember]
		public string JobTitle { get; set; }
		[DataMember]
		public string JobGrade { get; set; }
		[DataMember]
		public string StudyPhaseListNotQ { get; set; }
		[DataMember]
		public string StudyPhaseListQ { get; set; }
		[DataMember]
		public string LanguageList { get; set; }
		[DataMember]
		public string SkillList { get; set; }
		[DataMember]
		public string IndicationList { get; set; }
		[DataMember]
		public string AreaList { get; set; }
		[DataMember]
		public string Education { get; set; }
		[DataMember]
		public string SponsorList { get; set; }
		[DataMember]
		public string SpecialPopulatationQ { get; set; }
		[DataMember]
		public string SpecialPopulatationNotQ { get; set; }
		[DataMember]
		public string DrugClassQ { get; set; }
		[DataMember]
		public string DrugClassNotQ { get; set; }
		[DataMember]
		public string RoleQ { get; set; }
		[DataMember]
		public string RoleNotQ { get; set; }
		[DataMember]
		public string IndustryTypeNotQ { get; set; }
		[DataMember]
		public string RegionNotQ { get; set; }
		[DataMember]
		public string IndicationQ { get; set; }
		[DataMember]
		public string IndicationNotQ { get; set; }
		[DataMember]
		public string SkillValues { get; set; }
		[DataMember]
		public List<ResReqErrors_WS> ResReqErrors { get; set; }
		[DataMember]
		public bool AreAllRequestsBad { get; set; }
		[DataMember]
		public string ResourceJobRoleName { get; set; }
		[DataMember]
		public string CompetencyBandName { get; set; }

		#endregion
	}

	[DataContract]
	public sealed class ResourceSearchCommonData
	{
		[DataMember]
		public int TotalPossibleHits { get; set; }
		[DataMember]
		public ResourceTypeMatchCriteriaMapping CriteriaMap { get; set; }
		[DataMember]
		public int StartMonthYear { get; set; }
		[DataMember]
		public int EndMonthYear { get; set; }

		public ResourceSearchCommonData(int totalPossibleHits, ResourceTypeMatchCriteriaMapping criteriaMap, int startMonthYear, int endMonthYear)
		{
			TotalPossibleHits = totalPossibleHits;
			CriteriaMap = criteriaMap;
			StartMonthYear = startMonthYear;
			EndMonthYear = endMonthYear;
		}
	}

	[DataContract]
	public sealed class ResourceSearchGridCommonData
	{
		[DataMember]
		public int StartMonthYear;
		[DataMember]
		public int EndMonthYear;
		[DataMember]
		public string AvailabilityError;
		[DataMember]
		public string HardBookError;
		[DataMember]
		public decimal[] TotalMonthlyHours;
		[DataMember]
		public decimal[] TotalMonthlyFTE;
		[DataMember]
		public SearchPlan_WS SearchPlan { get; set; }

		public ResourceSearchGridCommonData(string availabilityError, string hardBookError, int startMonthYear, int endMonthYear, decimal[] totalMonthlyHours, decimal[] totalMonthlyFTE, SearchPlan_WS searchPlan)
		{
			AvailabilityError = availabilityError;
			HardBookError = hardBookError;
			StartMonthYear = startMonthYear;
			EndMonthYear = endMonthYear;
			TotalMonthlyHours = totalMonthlyHours;
			TotalMonthlyFTE = totalMonthlyFTE;
			SearchPlan = searchPlan;
		}
	}

	[DataContract]
	public sealed class AnnouncementRowData : JqGridDataRow
	{
		[DataMember]
		public string Title { get; set; }
		[DataMember]
		public string EffectiveDate { get; set; }
		[DataMember]
		public string ExpiryDate { get; set; }
		[DataMember]
		public string AnnouncementType { get; set; }

		public AnnouncementRowData(Announcement announcement, AnnouncementCommonData commonData)
		{
			id = announcement.Id;
			Title = announcement.Title;
			EffectiveDate = announcement.EffectiveDate.ToQDateString();
			ExpiryDate = announcement.ExpiryDate.ToQDateString();
			AnnouncementType = announcement.AnnouncementType.GetEnumDescription();
		}

		public static AnnouncementRowData Create(Announcement announcement, AnnouncementCommonData commonData)
		{
			return new AnnouncementRowData(announcement, commonData);
		}
	}

	[DataContract]
	public sealed class AnnouncementChangeHistoryRowData : JqGridDataRow
	{
		[DataMember]
		public string SavedDate { get; set; }
		[DataMember]
		public string Title { get; set; }
		[DataMember]
		public string SavedBy { get; set; }
		[DataMember]
		public string AnnouncementType { get; set; }

		public AnnouncementChangeHistoryRowData(Announcement announcement, AnnouncementCommonData commonData)
		{
			id = announcement.Id;
			Title = announcement.Title;
			SavedDate = announcement.LastModifiedOn.ToQDateString();
			SavedBy = announcement.LastModifiedBy;
		}

		public static AnnouncementChangeHistoryRowData Create(Announcement announcement, AnnouncementCommonData commonData)
		{
			return new AnnouncementChangeHistoryRowData(announcement, commonData);
		}
	}

	public class AnnouncementCommonData
	{ }

	public class GridCommonData
	{ }

	[DataContract]
	public sealed class OrganizationRowData : JqGridDataRow
	{
		[DataMember]
		public string OrganizationName { get; set; }
		[DataMember]
		public int OrganizationId { get; set; }
		[DataMember]
		public string OrganizationalUnitName { get; set; }

		public OrganizationRowData(Organization_WS organization)
		{
			id = organization.OrganizationalUnitId;
			OrganizationalUnitName = organization.OrganizationalUnitName;
			OrganizationId = organization.Id;
			OrganizationName = organization.Name;
		}

		public static OrganizationRowData Create(Organization_WS organization, GridCommonData commonData)
		{
			return new OrganizationRowData(organization);
		}
	}

	[DataContract]
	public sealed class QipDisconnectResourceTypeOrgnizationalUnitCountryData : JqGridDataRow
	{
		[DataMember]
		public int ResourceTypeId { set; get; }
		[DataMember]
		public string ResourceTypeName { set; get; }
		[DataMember]
		public int OrgazinationalUnitId { set; get; }
		[DataMember]
		public string OrganizationalUnitName { set; get; }
		[DataMember]
		public string countryIdList { set; get; }
		[DataMember]
		public string countryNameList { set; get; }
		[DataMember]
		public decimal? MinQipVersion { set; get; }

		public QipDisconnectResourceTypeOrgnizationalUnitCountryData(QipDisconnectResourceTypeOrgnizationalUnitCountry_WS qipDis, GridCommonData commonData)
		{
			id = qipDis.Id;
			ResourceTypeId = qipDis.ResourceTypeId;
			ResourceTypeName = qipDis.ResourceTypeName;
			countryIdList = qipDis.countryIdList;
			countryNameList = qipDis.countryNameList;
			MinQipVersion = qipDis.MinQipVersion;
		}

		public static QipDisconnectResourceTypeOrgnizationalUnitCountryData Create(QipDisconnectResourceTypeOrgnizationalUnitCountry_WS qipDis, GridCommonData commonData)
		{
			return new QipDisconnectResourceTypeOrgnizationalUnitCountryData(qipDis, commonData);
		}
	}


	[DataContract]
	public sealed class JobRoleRowData : JqGridDataRow
	{
		[DataMember]
		public string Name { get; set; }
		[DataMember]
		public string IsEnabled { get; set; }
		[DataMember]
		public string HrName { get; set; }

		public JobRoleRowData(JobRole jobRole)
		{
			id = jobRole.Id;
			Name = jobRole.Name;
			IsEnabled = jobRole.IsEnabled ? "Yes" : "No";
			HrName = jobRole.HRName;
		}

		public static JobRoleRowData Create(JobRole jobRole, GridCommonData commonData)
		{
			return new JobRoleRowData(jobRole);
		}
	}
	//SSVCountrySpecificGridRowData
	[DataContract]
	public class SSVCountrySpecificGridRowData : JqGridDataRow
	{
		private static string getRequestStatusName(int requestStatusId)
		{
			string requestStatusName = string.Empty;
			switch (requestStatusId)
			{
				case 4: requestStatusName = "HardBooked"; break;
				case 3: requestStatusName = "SoftBooked"; break;
				case 6: requestStatusName = "Queried"; break;
				default: requestStatusName = Enum.GetName(typeof(RequestStatusName), requestStatusId); break;
			}
			return requestStatusName;
		}
		public SSVCountrySpecificGridRowData(Request r, RequestCommonData commonData)
		{
			id = r.Id;
			spacer = "";
			requestCurrentlyEdited = "";
			RequestId = r.Id;
			CountryRegionId = r.CountryRegionId ?? 0;
			CountryRegions = "";
			Sites = r.TotalSites ?? 0;
			TotalHours = r.TotalHours ?? 0;
			TotalHoursPerSite = r.TotalHoursPerSite ?? 0;
			MonthlyFTE = r.MonthlyFTE;
			ResourceName = r.ResourceNames;
			status = getRequestStatusName(r.RequestStatusId);
			RequestStatusId = r.RequestStatusId;
			ParentRequestId = r.ParentRequestId;
			allowDelete = r.AllowDelete;
			allowSplit = r.AllowSplit;
			disableRow = r.DisableRow;
			addToTotal = r.AddToTotal;
			CountryId = r.CountryId ?? 0;
			StartDate = r.StartDate.ToString() ?? string.Empty;
			StopDate = r.StopDate.ToString() ?? string.Empty;
			rowActionStatus = (int)DMLOperation_E.NoAction;
			AllowEditParent = r.AllowEditParent;
		}

		public static SSVCountrySpecificGridRowData Create(Request r, RequestCommonData commonData)
		{
			return new SSVCountrySpecificGridRowData(r, commonData);
		}

		#region Properties
		[DataMember]
		public string spacer;
		[DataMember]
		public string requestCurrentlyEdited;
		[DataMember]
		public int RequestId;
		[DataMember]
		public int? BackfillRequestId;
		[DataMember]
		public int CountryRegionId;
		[DataMember]
		public string CountryRegions;
		[DataMember]
		public int Sites;
		[DataMember]
		public decimal TotalHours;
		[DataMember]
		public decimal TotalHoursPerSite;
		[DataMember]
		public decimal MonthlyFTE;
		[DataMember]
		public string ResourceName;
		[DataMember]
		public string status;
		[DataMember]
		public bool allowDelete;
		[DataMember]
		public bool allowSplit;
		[DataMember]
		public bool disableRow;
		[DataMember]
		public bool addToTotal;
		[DataMember]
		public int CountryId;
		[DataMember]
		public string StartDate;
		[DataMember]
		public string StopDate;
		[DataMember]
		public int rowActionStatus;
		[DataMember]
		public int RequestStatusId;
		[DataMember]
		public int? ParentRequestId;
		[DataMember]
		public bool AllowEditParent;
		#endregion
	}

	//PastRequestsListData
	[DataContract]
	public class PastRequestsListData : JqGridDataRow
	{
		public PastRequestsListData(Request r, RequestCommonData commonData)
		{
			RequestId = r.Id;
			StartDate = r.StartDate.ToQDateString();
			StopDate = r.StopDate.ToQDateString();
			CountryName = r.CountryName;
			RegionName = r.RegionName;
			Fte = r.FTE;
		}

		public static PastRequestsListData Create(Request r, RequestCommonData commonData)
		{
			return new PastRequestsListData(r, commonData);
		}

		#region Properties
		[DataMember]
		public int RequestId;
		[DataMember]
		public string StartDate;
		[DataMember]
		public string StopDate;
		[DataMember]
		public string CountryName;
		[DataMember]
		public string RegionName;
		[DataMember]
		public decimal? Fte;
		#endregion
	}

	#region SiteListDetails
	[DataContract]
	public class SiteListRowData : JqGridDataRow
	{
		public SiteListRowData(SiteListDetails sitelist, AttributeCommonData commonData)
		{
			RowNumber = sitelist.RowNumber;
			SiteName = sitelist.SiteName;
			SiteId = sitelist.SiteId;
			ProjectCodeProtocol = sitelist.ProjectCodeProtocolNumber;
			SiteStatusName = sitelist.SiteStatusName;
			PrincipalInvestigatorName = sitelist.PrincipalInvestigatorName;
			ResourceName = sitelist.ResourceName;
			CountryRegionName = sitelist.CountryRegionName;
			AddressDetails = sitelist.AddressDetails;
		}

		public static SiteListRowData Create(SiteListDetails sa, AttributeCommonData commonData)
		{
			return new SiteListRowData(sa, commonData);
		}

		#region Properties
		[DataMember]
		public string RowNumber;
		[DataMember]
		public string SiteName;
		[DataMember]
		public int SiteId;
		[DataMember]
		public string ProjectCodeProtocol;
		[DataMember]
		public string SiteStatusName;
		[DataMember]
		public string PrincipalInvestigatorName;
		[DataMember]
		public string ResourceName;
		[DataMember]
		public string CountryRegionName;
		[DataMember]
		public string AddressDetails;
		#endregion
	}
	#endregion

	[DataContract]
	public sealed class PagePermissionRowData : JqGridDataRow
	{
		[DataMember]
		public string PageName { get; set; }
		[DataMember]
		public string UserRole { get; set; }

		public PagePermissionRowData(PagePermission pagePermission)
		{
			id = pagePermission.Id;
			PageName = pagePermission.PageName;
			UserRole = pagePermission.UserRole;
		}

		public static PagePermissionRowData Create(PagePermission pagePermission, GridCommonData commonData)
		{
			return new PagePermissionRowData(pagePermission);
		}
	}

	[DataContract]
	public sealed class RmFunctionPermissionRowData : JqGridDataRow
	{
		[DataMember]
		public string FunctionName { get; set; }
		[DataMember]
		public string UserRole { get; set; }

		public RmFunctionPermissionRowData(RmFunctionPermission functionPermission)
		{
			id = functionPermission.Id;
			FunctionName = functionPermission.FunctionName;
			UserRole = functionPermission.UserRole;
		}

		public static RmFunctionPermissionRowData Create(RmFunctionPermission functionPermission, GridCommonData commonData)
		{
			return new RmFunctionPermissionRowData(functionPermission);
		}
	}
	[DataContract]
	public sealed class SiteGridRowData : JqGridDataRow
	{
		[DataMember]
		public string TieringCompletionStatus { get; set; }
		[DataMember]
		public string ExternalId { get; set; }
		[DataMember]
		public string SiteName { get; set; }
		[DataMember]
		public string PiName { get; set; }
		[DataMember]
		public string Country { get; set; }
		[DataMember]
		public string Region { get; set; }
		[DataMember]
		public string FsiLsiTier { get; set; }
		[DataMember]
		public string LsiLsoTier { get; set; }
		[DataMember]
		public string LsoCovTier { get; set; }
		[DataMember]
		public string PharmacyTier { get; set; }
		[DataMember]
		public string GeneralComments { get; set; }
		[DataMember]
		public bool AskReasonForChange { get; set; }
		[DataMember]
		public string SiteStatus { get; set; }
		[DataMember]
		public string City { get; set; }
		[DataMember]
		public string SponsorSite { get; set; }
		[DataMember]
		public string IsSiteActive { get; set; }
		[DataMember]
		public string QaStatus { get; set; }
		[DataMember]
		public string EnrollmentScore { get; set; }
		[DataMember]
		public bool HasIntelligenceData { get; set; }
		[DataMember]
		public string RecommendedPharmacyTier { get; set; }
		[DataMember]
		public string RecommendedSiteTier { get; set; }
		[DataMember]
		public int DeltaPharmacyVisits { get; set; }
		[DataMember]
		public int DeltaRemoteVisits { get; set; }
		[DataMember]
		public int DeltaSiteMonitoringVisits { get; set; }
		[DataMember]
		public bool HasPharmacyCountryCalculator { get; set; }
		[DataMember]
		public decimal? CurrentEnrollmentScore { get; set; }
		[DataMember]
		public int? OverDueActionItems { get; set; }
		[DataMember]
		public int? ProtocolDeviations { get; set; }
		[DataMember]
		public int? AdverseEvents { get; set; }
		[DataMember]
		public int? SeriousAdverseEvents { get; set; }
		[DataMember]
		public decimal? QueryRate { get; set; }
		[DataMember]
		public decimal? ScreenFailureRate { get; set; }
		[DataMember]
		public decimal? DropoutRate { get; set; }
		[DataMember]
		public int? ActionItemCount { get; set; }
		[DataMember]
		public string SdvBacklogEventTitle { get; set; }
		[DataMember]
		public string SdvBacklogEventSeverity { get; set; }
		[DataMember]
		public string SdvBacklogEventReceiveDate { get; set; }
		[DataMember]
		public bool IsSiteCovInPast { get; set; }
		[DataMember]
		public DateTime? SiteFsiDate { get; set; }
		[DataMember]
		public DateTime? SiteLsiDate { get; set; }
		[DataMember]
		public DateTime? SiteLsoDate { get; set; }
		[DataMember]
		public DateTime? SiteCovDate { get; set; }
		[DataMember]
		public string IsPpmCountryActive { get; set; }
		[DataMember]
		public string ActiveMonFreq { get; set; }


		public SiteGridRowData(ProjectProtocolSite site)
		{
			id = site.Id;
			AskReasonForChange = site.AskReasonForChange;
			TieringCompletionStatus = site.TieringCompletionStatus;
			FsiLsiTier = ((int)site.FsiLsiTier).ToString();
			LsiLsoTier = ((int)site.LsiLsoTier).ToString();
			LsoCovTier = ((int)site.LsoCovTier).ToString();
			PharmacyTier = ((int)site.PharmacyTier).ToString();
			RecommendedSiteTier = ((int)site.RecommendedSiteTier).ToString();
			RecommendedPharmacyTier = ((int)site.RecommendedPharmacyTier).ToString();
			GeneralComments = site.GeneralComments;
			PiName = site.PrincipalInvestigator.GetFirstLastName();
			Country = site.Address.Country.Name;
			IsPpmCountryActive = site.IsPpmCountryActive ? "Yes" : "No";
			ActiveMonFreq = site.ActiveMonFreq;
			Region = site.Address.Country.Subregion.Region.Name;
			SiteName = site.PiLastNameCitySponsorSite;
			SiteStatus = site.SiteStatus.Name;
			IsSiteActive = site.SiteStatus.ConsiderSiteInactive ? "No" : "Yes";
			City = site.Address.City;
			SponsorSite = site.SponsorSite;
			HasPharmacyCountryCalculator = site.HasPharmacyCountryCalculator;
			if (site.SiteIntelligenceData != null)
			{
				QaStatus = site.SiteIntelligenceData.QaStatus;
				EnrollmentScore = site.SiteIntelligenceData.EnrollmentScore.ToString();
				HasIntelligenceData = site.SiteIntelligenceData.HasIntelligenceData;
			}

			DeltaPharmacyVisits = site.DeltaPharmacyVisits.GetValueOrDefault();
			DeltaRemoteVisits = site.DeltaRemoteVisits.GetValueOrDefault();
			DeltaSiteMonitoringVisits = site.DeltaSiteMonitoringVisits.GetValueOrDefault();



			CurrentEnrollmentScore = site.CurrentEnrollmentScore;
			OverDueActionItems = site.OverDueActionItems;
			ProtocolDeviations = site.ProtocolDeviations;
			AdverseEvents = site.AdverseEvents;
			SeriousAdverseEvents = site.SeriousAdverseEvents;
			QueryRate = site.QueryRate;
			ScreenFailureRate = site.ScreenFailureRate;
			DropoutRate = site.DropoutRate;
			ActionItemCount = site.ActionItemCount;
			SdvBacklogEventTitle = site.SdvBacklogEventTitle;
			SdvBacklogEventSeverity = site.SdvBacklogEventSeverity;
			SdvBacklogEventReceiveDate = site.SdvBacklogEventReceiveDate.ToQDateString();
			IsSiteCovInPast = site.SiteCovDate.HasValue && site.SiteCovDate.GetValueOrDefault() < DateTime.Today;
			SiteFsiDate = site.SiteFsiDate;
			SiteLsiDate = site.SiteLsiDate;
			SiteLsoDate = site.SiteLsoDate;
			SiteCovDate = site.SiteCovDate;
		}

		public static SiteGridRowData Create(ProjectProtocolSite siteList, AttributeCommonData commonData)
		{
			return new SiteGridRowData(siteList);
		}
	}

	[DataContract]
	public sealed class TierchangeHistoryGridRowData : JqGridDataRow
	{
		[DataMember]
		public string Frequency { get; set; }
		[DataMember]
		public string OldTierValue { get; set; }
		[DataMember]
		public string NewTierValue { get; set; }
		[DataMember]
		public string ReasonForChange { get; set; }
		[DataMember]
		public string OtherComments { get; set; }
		[DataMember]
		public string ModifiedBy { get; set; }
		[DataMember]
		public string ModifiedByQid { get; set; }
		[DataMember]
		public string ModifiedOn { get; set; }

		public TierchangeHistoryGridRowData(SiteTierChangeHistory changHistory, GridCommonData commondata)
		{
			id = changHistory.Id;
			Frequency = changHistory.CalculatorTypeId.GetEnumDescription();
			OldTierValue = changHistory.PreviousTierId.HasValue ? ((int)changHistory.PreviousTierId.GetValueOrDefault()).ToString() : string.Empty;
			NewTierValue = ((int)changHistory.UpdatedTierId).ToString();
			ReasonForChange = changHistory.ReasonForChange;
			OtherComments = changHistory.OtherReasonComment;
			ModifiedBy = changHistory.LastModifiedByName;
			ModifiedByQid = changHistory.LastModifiedBy;
			ModifiedOn = changHistory.LastModifiedOn.ToQDateTimeStringNoTimezone();
		}
		public static TierchangeHistoryGridRowData Create(SiteTierChangeHistory changHistory, GridCommonData commondata)
		{
			return new TierchangeHistoryGridRowData(changHistory, commondata);
		}
	}

	[DataContract]
	public sealed class WindowsServiceProcessRowData : JqGridDataRow
	{
		[DataMember]
		public string ServerName { get; set; }
		[DataMember]
		public string ServerDescription { get; set; }
		[DataMember]
		public string IsProductionServer { get; set; }
		[DataMember]
		public string IsServerActive { get; set; }
		[DataMember]
		public string WindowsServiceProcess { get; set; }
		[DataMember]
		public string IsProcessActive { get; set; }
		[DataMember]
		public string AllowExecutionOnServer { get; set; }

		public WindowsServiceProcessRowData(WindowsServiceProcessRmServer serviceProcess)
		{
			id = serviceProcess.Id;
			ServerName = serviceProcess.RmServer.Name;
			ServerDescription = serviceProcess.RmServer.Description;
			IsProductionServer = serviceProcess.RmServer.IsProductionServer ? "Yes" : "No";
			IsServerActive = serviceProcess.RmServer.IsServerActive ? "Yes" : "No";
			WindowsServiceProcess = serviceProcess.WindowsServiceProcess.Name;
			IsProcessActive = serviceProcess.WindowsServiceProcess.IsProcessActive ? "Yes" : "No";
			AllowExecutionOnServer = serviceProcess.AllowExecutionOnServer ? "Yes" : "No";
		}

		public static WindowsServiceProcessRowData Create(WindowsServiceProcessRmServer serviceProcess, GridCommonData commonData)
		{
			return new WindowsServiceProcessRowData(serviceProcess);
		}
	}
}