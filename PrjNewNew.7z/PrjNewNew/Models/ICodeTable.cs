namespace Quintiles.RM.Clinical.Domain.Models
{
	/// <summary>
	/// All RM code tables shall have an Id and Name
	/// </summary>
	public interface ICodeTable : IEntity
	{
		string Name { get; set; }
	}
}