﻿using System;
using System.Collections.Generic;
using System.Data;
using Castle.ActiveRecord;
using Quintiles.RM.Clinical.Domain.Database;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "CompetencyBand")]
	public class CompetencyBand : AbstractActiveRecordBaseModel<CompetencyBand>, IEquatable<CompetencyBand>, IComparable<CompetencyBand>, ICodeTable
	{

		#region Mapped Properties

		[PrimaryKey(Column = "CompetencyBandID")]
		public override int Id { get; set; }
		[Property]
		public string Name { get; set; }

		public bool Equals(CompetencyBand other)
		{
			return ((this.Id > 0 && other.Id > 0) && this.Id == other.Id);
		}

		public int CompareTo(CompetencyBand other)
		{
			return String.CompareOrdinal(Name, other.Name);
		}

		#endregion

		public static List<OptionItem_WS> GetAllCompetencyBandList()
		{
			List<OptionItem_WS> competencyBandList = new List<OptionItem_WS>();
			string sqlQuery = @"SELECT  CompetencyBandID, Name FROM    CompetencyBand ORDER BY SortOrder";

			using (IDataReader dr = DbHelp.ExecuteDataReaderText(sqlQuery))
			{
				try
				{
					while (dr.Read())
					{
						competencyBandList.Add(new OptionItem_WS(DbSafe.Int(dr["CompetencyBandID"]), DbSafe.StringValue(dr["Name"])));
					}
				}
				finally { dr.Close(); }
			}

			return competencyBandList;
		}
	}
}