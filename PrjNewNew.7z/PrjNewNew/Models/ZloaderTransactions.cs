﻿using Castle.ActiveRecord;
using NHibernate.Criterion;

namespace Quintiles.RM.Clinical.Domain.Models
{
	[ActiveRecord(Table = "zloader_transactions")]
	public class ZloaderTransactions : AbstractActiveRecordBaseModel<ZloaderTransactions>
	{
		[PrimaryKey(Column = "TransactionId", UnsavedValue = "-1")]
		public override int Id { set { this._id = value; } get { return this._id; } }

		[Property(Column = "TransactionName")]
		public string Name { set; get; }

		[Property]
		public int TransactionStatus { get; set; }

		public static bool IsPopulateZLoaderRunning()
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(ZloaderTransactions));
			criteria.Add(Expression.Eq("TransactionStatus", 1));

			return (ZloaderTransactions.Count(criteria) != 0);
		}

		public static bool IsPopulateZLoaderForResourceRunning()
		{
			DetachedCriteria criteria = DetachedCriteria.For(typeof(ZloaderTransactions));
			criteria.Add(Expression.Eq("Id", Constants.PopulateResourceTransactionId));
			criteria.Add(Expression.Eq("TransactionStatus", Constants.JobRunning));

			return (ZloaderTransactions.Count(criteria) != 0);
		}

	}
}
