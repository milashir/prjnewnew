﻿
namespace Quintiles.RM.Clinical.Domain.Models
{
    public interface IExternalEntity : IEntity
    {
        string ExternalId { get; set;  }
        string ExternalSource { get; set; }
    }
}
