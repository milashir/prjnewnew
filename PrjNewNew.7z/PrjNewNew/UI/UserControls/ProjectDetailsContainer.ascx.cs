﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using Quintiles.RM.Clinical.Domain;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RPM.Common;
using Quintiles.RM.Clinical.SharePoint.QUI;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class ProjectDetailsContainer : UserControl
	{
		protected Project CurrentProject = null;
		public int ProjectId { get; set; }
		public string FirstTabName { get { return CurrentProject != null && CurrentProject.IsProposalProject ? "Proposal Project" : "Project Leadership"; } }
		protected void Page_Load(object sender, EventArgs e)
		{
			dvNonPpmProject.Style.Add("display", "none");
			dvPpmProject.Style.Add("display", "none");

			if (ProjectId != 0)
			{
				CurrentProject = Project.FindOneById(ProjectId);
				if (CurrentProject != null)
				{
					trAllowInitialSitTiering.Visible = CurrentProject.IsDteProject;
					hdnInitialTieringPerformed.Value = CurrentProject.InitialTieringPerformed.GetIntAsStringFromBool();
					ddlInitialSiteTiering.SelectedValue = CurrentProject.AllowInitialSiteTiering.GetIntAsStringFromBool();
					if (CurrentProject.ExternalSource == ProjectService.PROJECT_SOURCE.RM.ToString())
					{
						dvPpmProject.Style.Add("display", "none");
						dvNonPpmProject.Style.Add("display", "block");
						DisplayNonPpmProjectDetails();
					}
					else
					{
						DisplayPpmProjectDetails();
						dvPpmProject.Style.Add("display", "block");
						dvNonPpmProject.Style.Add("display", "none");
					}
				}
			}
		}

		private void DisplayPpmProjectDetails()
		{
			if (CurrentProject.IsProposalProject)
			{
				UIUtility.BindDropDown(ddlWinProbability, CacheService.WinProbabilities.Values.OrderBy(wp => wp.CrmName), !CurrentProject.WinProbabilityId.HasValue);
				ddlWinProbability.SelectedValue = CurrentProject.WinProbabilityId.GetValueOrDefault().ToString();
				imgProposalProject.Visible = true;
				txtInitialAwardDate.Visible = false;
				ddlStopMissingPclAlerts.Visible = false;
			}
			else
			{
				trWinProbability.Visible = false;
			}
			hdnIsProposalProject.Value = CurrentProject.IsProposalProject.GetIntAsStringFromBool();
			lblProjectSource.Text = CurrentProject.ExternalSource;

			lblProjectExternalId.Text = CurrentProject.ExternalId;
			lblMasterProjectId.Text = CurrentProject.MasterProjectId.HasValue ? CurrentProject.MasterProjectId.GetValueOrDefault().ToString() : string.Empty;

			lblStudyStatus.Text = CurrentProject.StudyStatus;
			lblSponsor.Text = CurrentProject.Sponsor;
			lblProtocolNumber.Text = CurrentProject.ProtocolNumber;
			lblProjectCode.Text = CurrentProject.ProjectCode;
			lblProjectDescription.Text = CurrentProject.ProjectDescription;
			lblFspPrincingModel.Text = CurrentProject.FspPricingModel;
			lblIsClinicalRedesignProject.Text = CurrentProject.IsClinicalRedesignProject ? Constants.Yes : Constants.No;
			lblOpenLabel.Text = CurrentProject.IsOpenLabel.HasValue ? (CurrentProject.IsOpenLabel.GetValueOrDefault() ? Constants.Yes : Constants.No) : string.Empty;
			StringBuilder tA = new StringBuilder();
			StringBuilder ind = new StringBuilder();
			IList<ProjectTherapeuticArea> tlist = ProjectTherapeuticArea.FindAllByProperty("Project.Id", CurrentProject.Id);
			IList<ProjectIndications> ilist = ProjectIndications.FindAllByProperty("Project.Id", CurrentProject.Id);

			lblTotalSites.Text = CurrentProject.GetSiteCountFromMonitoringAttrbute().ToString();
			lblTherapeuticArea.Text = tA.Length == 0 ? String.Empty : (tA.ToString().Substring(0, (tA.ToString().Length - 2)));
			lblIndication.Text = ind.Length == 0 ? String.Empty : (ind.ToString().Substring(0, (ind.ToString().Length - 2)));
			lblPrimaryCPM.Text = CurrentProject.GetPrimaryCpmName();
			lblProjectOwner.Text = CurrentProject.GetProjectOwnerName();
			lblPrimaryCl.Text = CurrentProject.GetPrimaryClNameFromDb();
			ddlStopMissingPclAlerts.SelectedValue = CurrentProject.StopMissingPrimaryClAlerts.GetIntAsStringFromBool();

			trPclAlert.Visible = CurrentProject.OrganizationalUnit.Organization.IsProjectLeadership;
			foreach (ProjectTherapeuticArea it in tlist)
			{ tA.AppendFormat("{0}, ", it.TherapeuticArea.Name.Trim()); }

			foreach (ProjectIndications i in ilist)
			{ ind.AppendFormat("{0}, ", i.Indication.Name.Trim()); }

			lblTherapeuticArea.Text = tA.Length == 0 ? String.Empty : (tA.ToString().Substring(0, (tA.ToString().Length - 2)));
			lblIndication.Text = ind.Length == 0 ? String.Empty : (ind.ToString().Substring(0, (ind.ToString().Length - 2)));

			lblProjectedFSI.Text = CurrentProject.FirstSubjectEnrolledProjectedDate.ToQDateString();
			lblProjectedLSI.Text = CurrentProject.LastSubjectEnrolledProjectedDate.ToQDateString();

			IList<ProjectCountryAndRegion> countryRegionList = ProjectCountryAndRegion.GetMultipleCountries(CurrentProject.Id);
			if (countryRegionList != null && countryRegionList.Count > 0)
			{
				StringBuilder sb = new StringBuilder();
				foreach (var countryRegion in countryRegionList)
				{
					if (countryRegion.CountryId.HasValue)
					{
						sb.AppendFormat(", {0}", CacheService.Country(countryRegion.CountryId).Name);
					}
				}
				if (sb.Length > 2)
				{
					lblCountries.Text = sb.ToString().Substring(2);
				}
				lblTotalCountries.Text = countryRegionList.Count.ToString();
			}
			else
			{
				lblCountries.Text = string.Empty;
				lblTotalCountries.Text = "0";
			}

			lblProgramProtocols.Text = CurrentProject.ProgramProtocols;
			lblScope.Text = CurrentProject.Scope;
			lblStudyStatus.Text = CurrentProject.ProjectStatus;
			lblProjectIdentifier.Text = CurrentProject.ProjectIdentifier;
			lblProgramIdentifier.Text = CurrentProject.Program;
			lblFirewalledStudies.Text = Project.GetFirewalledProjects(CurrentProject.Id);
			lblCompetencyBand.Text = (CurrentProject.CompetencyBand == null) ? string.Empty : CurrentProject.CompetencyBand.Name;
			lblProjectSize.Text = CurrentProject.ProjectSize;
			lblPenaltyOrBonus.Text = ProjectPenaltyOrBonus.GetCommaSeparatedPenaltyOrBonusByProjectId(CurrentProject.Id);
			lblProjectComplexity.Text = CurrentProject.ProjectComplexity;
			lblVirtualTrialType.Text = CurrentProject.VirtualTrialType;

			lblBudgetingSystem.Text = CurrentProject.BudgetingSystemName;
			lblBudgetVersion.Text = CurrentProject.GetBudgetVersion();
			lblProtocolTitle.Text = CurrentProject.ProtocolTitle;
			txtInitialAwardDate.Text = CurrentProject.InitialAwardedDate == null ? string.Empty : CurrentProject.InitialAwardedDate.ToQDateString();
			if (ProjectService.PROJECT_SOURCE.SES.ToString().Equals(CurrentProject.ExternalSource, StringComparison.InvariantCultureIgnoreCase))
			{
				ddlSivFsiWeeks.Visible = false;
				ddlFsiImvWeeks.Visible = false;
				ddlImvWindowWeeks.Visible = false;
			}
			else
			{
				if (CurrentProject.SivFsiWeeks != null) { ddlSivFsiWeeks.SelectedValue = CurrentProject.SivFsiWeeks.ToString(); }
				if (CurrentProject.FsiFirstImvWeeks != null) { ddlFsiImvWeeks.SelectedValue = CurrentProject.FsiFirstImvWeeks.ToString(); }
				if (CurrentProject.ImvWindowWeeks != null)
				{
					ddlImvWindowWeeks.Items.RemoveAt(0);
					ddlImvWindowWeeks.SelectedValue = CurrentProject.ImvWindowWeeks.ToString();
				}
			}

			lblCustomer.Text = CurrentProject.CustomerName == null ? string.Empty : CurrentProject.CustomerName.ToString();
			lblFinalDeliverable.Text = CurrentProject.FinalDeliverableContractedDate == null ? String.Empty : CurrentProject.FinalDeliverableContractedDate.ToQDateString();
			lblStudyPhase.Text = CurrentProject.Phase;
			lblOrganization.Text = CurrentProject.Organization;
			ltrIcon.Text = CurrentProject.GetNotesColumnValue();
			OrganizationType.Value = ((int)(CurrentProject.OrganizationType == null ? OrganizationType_E.TDU : CurrentProject.OrganizationType)).ToString();

			ShowCustomFields();

			// Set tool tip for static labels, if content length > 45
			foreach (Control control in staticTab.Controls)
			{
				if (control is Label)
				{
					if ((control as Label).Text.Length > 45)
					{
						(control as Label).ToolTip = (control as Label).Text;
					}
				}
			}

			// Invoke method to get dynamic project data
			var backgroundDetails = ProjectBackroundDetails.FindByProjectId(CurrentProject.Id);
			if (backgroundDetails != null && backgroundDetails.Count > 0)
			{
				int divId = 1;
				foreach (var backgroundDetail in backgroundDetails)
				{
					foreach (var project in backgroundDetail.Value)
					{
						// Add list of tabs to place holder
						tabsPdcList.Controls.Add(new Literal { Text = string.Format("<li><a href=\"#tabsPdc-{0}\">{1}</a></li>", divId.ToString(), backgroundDetail.Key) });

						// Add start div to placeholder
						staticData.Controls.Add(new Literal { Text = string.Format("<div id=\"tabsPdc-{0}\">", divId.ToString()) });

						//Add tableStart to placeholder
						staticData.Controls.Add(new Literal
						{
							Text = @"<table style=""width: 100%"">
													<tr>
														<td style=""width: 100%"" colspan=""2"">"
						});

						//Add paMessagesTable to placeholder
						staticData.Controls.Add(new Literal
						{
							Text = string.Format(@"<table class=""paMessages"">
																			<tr>
																				<td>Notes</td>
																				<td class=""paMessagesIcon""><div id=""ltrIcon"">{0}</div></td>
																			</tr>
																		</table>", CurrentProject.GetNotesColumnValue())
						});

						var rowCounter = 1;
						var rowNumberToSplitTable = 13;
						foreach (var fieldList in project.Value)
						{
							if (rowCounter == 1)
							{
								staticData.Controls.Add(new Literal { Text = "<table class=\"projectAttributesTableLeft\">" });
							}
							else if (rowCounter == rowNumberToSplitTable)
							{
								staticData.Controls.Add(new Literal { Text = "</table><table class=\"projectAttributesTableRight\">" });

							}
							staticData.Controls.Add(GenerateDynamicFields(fieldList));
							rowCounter++;
						}

						if (CurrentProject.OrganizationType != null && CurrentProject.OrganizationType != OrganizationType_E.TDU)
						{
							//Add Firwalled studies label for all single service projects
							staticData.Controls.Add(new Literal
							{
								Text = string.Format(@"<tr>
																				 <td class=""projectAttributesText"" nowrap>Firewalled Projects</td>
																				 <td>
																						<div class=""projectAttributesBackgroundDynamic paBackDouble"" title=""{0}"">
																							<span id=""lblFirewalledStudiesForSingleServiceProject"">{0}<span>
																						</div>
																				 </td>
																			</tr>", Project.GetFirewalledProjects(CurrentProject.Id))
							});
						}

						// Add projectAttributesCloseDiv to placeholder
						staticData.Controls.Add(new Literal
						{
							Text = @"				</table>
														</td>
													</tr>
												</table>
											</div>"
						});

						// Increment div, move to create next tab and div
						divId++;
					}
				}
			}

			StringBuilder totalPlaceHolderText = new StringBuilder();
			foreach (Control literalControl in staticData.Controls)
			{
				if (literalControl is Literal)
				{
					totalPlaceHolderText.Append((literalControl as Literal).Text);
				}
			}
		}

		private void ShowCustomFields()
		{
			var projectFields = ProjectCustomField.GetByProjectId(CurrentProject.Id);
			if (projectFields != null && projectFields.Count > 0)
			{
				var rowTemplate = @"<tr class=""projectCustomFieldContainer""><td class=""projectAttributesText"">{0}{1}</td><td><div class=""{2}"">{3}</div></td></tr>";
				var sb = new StringBuilder();

				foreach (var projectField in projectFields)
				{
					sb.AppendFormat(rowTemplate,
							projectField.CustomField.FieldLabel,
							projectField.CustomField.GetInfoIconHelpTextHtml(),
							projectField.CustomField.ControlTypeId == Domain.Utilities.DynamicControlTypes_E.Checkbox ? "projectAttributesBackgroundDynamicNoHeight" : "projectAttributesBackgroundDynamic",
							projectField.CustomField.GetControlHtml(projectField.Value, projectField.Id));
				}
				ltrCustomFields.Text = sb.ToString();
			}
		}

		private void DisplayNonPpmProjectDetails()
		{
			OrganizationType.Value = ((CurrentProject.OrganizationType == null ? -1 : (int)CurrentProject.OrganizationType.GetValueOrDefault())).ToString();

			lblProject.Text = CurrentProject.ProjectCode;
			lblSponsorName.Text = CurrentProject.Sponsor;
			lblProtocolNumberNonPpm.Text = CurrentProject.ProtocolNumber;
			lblProjectSource.Text = CurrentProject.ExternalSource;

			StringBuilder tA = new StringBuilder();
			StringBuilder ind = new StringBuilder();
			IList<ProjectTherapeuticArea> tlist = ProjectTherapeuticArea.FindAllByProperty("Project.Id", CurrentProject.Id);
			IList<ProjectIndications> ilist = ProjectIndications.FindAllByProperty("Project.Id", CurrentProject.Id);


			lblTotalSitesNonPpm.Text = CurrentProject.NumberOfSites.ToString();
			// --->

			foreach (ProjectTherapeuticArea it in tlist)
			{ tA.AppendFormat("{0}, ", it.TherapeuticArea.Name.Trim()); }

			foreach (ProjectIndications i in ilist)
			{ ind.AppendFormat("{0}, ", i.Indication.Name.Trim()); }

			lblTherapeuticAreaNonPpm.Text = tA.Length == 0 ? String.Empty : (tA.ToString().Substring(0, (tA.ToString().Length - 2)));
			lblIndicationNonPpm.Text = ind.Length == 0 ? String.Empty : (ind.ToString().Substring(0, (ind.ToString().Length - 2)));
			lblTotalCountriesNonPpm.Text = CurrentProject.NumberOfCountries.ToString();

			lblProjectDesc.Text = CurrentProject.ProjectDescription;

			lblAwardDateNonPpm.Text = CurrentProject.ProjectAwardDate == null ? string.Empty : CurrentProject.ProjectAwardDate.ToQDateString();
			lblCustomerNonPpm.Text = CurrentProject.CustomerName == null ? string.Empty : CurrentProject.CustomerName.ToString();

			lblInitialsiteInitiation.Text = CurrentProject.InitialSiteInitiationTarget.ToQDateString();
			ltrIconNonPpm.Text = CurrentProject.GetNotesColumnValue();
			lblFirewalledStudiesForSingleServiceProject.Text = Project.GetFirewalledProjects(CurrentProject.Id);
			lblCompetencyBandNonPpm.Text = (CurrentProject.CompetencyBand == null) ? string.Empty : CurrentProject.CompetencyBand.Name;
			lblIsClinicalRedesignProjectNonPpm.Text = CurrentProject.IsClinicalRedesignProject ? Constants.Yes : Constants.No;
			if (CurrentProject.ProjectDteType.ToString() == "Dte")
			{
				lblDTEStudyType.Text = "RBM";
			}
			else if (CurrentProject.ProjectDteType.ToString() == "NonDte")
			{
				lblDTEStudyType.Text = "NonRBM";
			}
			else
			{
				lblDTEStudyType.Text = "Unknown";
			}
		}

		private Literal GenerateDynamicFields(ProjectBackroundDetails backgroundDetail)
		{
			Literal dynamictr = new Literal();
			string titleText = string.Empty;
			if (!string.IsNullOrEmpty(backgroundDetail.FieldValue) && backgroundDetail.FieldValue.Length > 45)
			{
				titleText = backgroundDetail.FieldValue;
			}
			// Text area for Sponsor and Project description
			if (backgroundDetail.DisplayLabel.Contains("Sponsor") ||
							backgroundDetail.DisplayLabel.Contains("Description"))
			{
				dynamictr.Text = string.Format(@"<tr>
														<td class=""projectAttributesText"" nowrap>{0}</td>
														<td><div class=""projectAttributesBackgroundDynamic paBackDouble"" title=""{1}"">{2}</div></td>
													</tr>",
																						backgroundDetail.DisplayLabel,
																						titleText,
																						backgroundDetail.FieldValue);
			}
			else if (backgroundDetail.DisplayLabel.Contains("Clinical Redesign") &&
											 CurrentProject.OrganizationType != null &&
											 CurrentProject.OrganizationType != OrganizationType_E.TDU)
			{
				dynamictr.Text = string.Format(@"<tr>
															<td class=""projectAttributesText"" nowrap>{0}</td>
															<td><div class=""projectAttributesBackgroundDynamic"" title=""{1}"">{2}</div></td>
														</tr>",
																						backgroundDetail.DisplayLabel,
																						titleText,
																						backgroundDetail.FieldValue.ToLower() == "true" ? "Yes" : "No");
			}
			else
			{
				dynamictr.Text = string.Format(@"<tr>
														<td class=""projectAttributesText"" nowrap>{0}</td>
														<td><div class=""projectAttributesBackgroundDynamic"" title=""{1}"">{2}</div></td>
													</tr>",
																						backgroundDetail.DisplayLabel,
																						titleText,
																						backgroundDetail.FieldValue);
			}
			return dynamictr;
		}
	}
}
