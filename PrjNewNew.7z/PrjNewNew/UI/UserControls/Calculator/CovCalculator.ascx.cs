﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{

	public partial class CovCalculator : CalculatorBase
	{
		public CovCalculatorData Data { get { return (CovCalculatorData)CalculatorData.Data; } }
		public CovCalculatorData ConnectedValues { get { return (CovCalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlIds(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(Controls);
			HandleControlVisibilityInMultiEditMode();
			SetControlValues();
			SetConnectedValues();
			HideShowControls();
		}

		private void SetControlValues()
		{
			SetControlValue(sivPerSite, Data.SivPerSite, false);
			SetControlValue(visitFrequency, Data.VisitFrequency, false);
			SetControlValue(travelTimeCluster, Data.ClusterTravelTime, false);
			SetControlValue(onSiteTime, Data.OnSiteTime, false);
			SetControlValue(prepFollowUpTime, Data.PrepFollowUpTime, false);
			SetControlValue(phoneVisitTime, Data.PhoneVisitTime, false);
			SetControlValue(fte, Data.Fte, false);
			SetControlValue(phoneFte, Data.PhoneFte, false);
			SetFrequencyHeaderValue(frequencyHeader, Data.FrequencyHeader, Data.FrequencyHeaderToolTip);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(sivPerSite, ConnectedValues.SivPerSite);
			SetConnectedValue(visitFrequency, ConnectedValues.VisitFrequency);
			SetConnectedValue(travelTimeCluster, ConnectedValues.ClusterTravelTime);
			SetConnectedValue(onSiteTime, ConnectedValues.OnSiteTime);
			SetConnectedValue(prepFollowUpTime, ConnectedValues.PrepFollowUpTime);
			SetConnectedValue(phoneVisitTime, ConnectedValues.PhoneVisitTime);
			SetConnectedValue(fte, ConnectedValues.Fte);
			SetConnectedValue(phoneFte, ConnectedValues.PhoneFte);
		}

		private void HideShowControls()
		{
			if (!Data.IsRequestCalculator)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false; 
			}
			phOnSiteVisit.Visible = !CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup);
			if (!(CalculatorGroup_E.MonitoringCalculator.Equals(Data.CalculatorGroup) || (CalculatorGroup_E.DTEMonitoringCalculator.Equals(Data.CalculatorGroup))))
			{
				sivPerSite.Visible = false;
				visitFrequency.Visible = false;
				old_sivPerSite.Visible = false;
				old_visitFrequency.Visible = false;
			}

			// Hide Phone visit section for DTE Pharmacy Monitoring
			if (CalculatorGroup_E.DTEPharmacyCalculator.Equals(Data.CalculatorGroup))
			{
				// Set the invisible fields to 0
				this.phoneVisitTime.Value = "0";
				this.phoneFte.Value = "0";

				// Hide Phone visit section for DTE Pharmacy Monitoring
				this.phoneVisitTime.Visible = false;
				this.phoneFte.Visible = false;

				// Show old values text inputs
				this.old_phoneVisitTime.Visible = false;
				this.old_phoneFte.Visible = false;
			}

			this.ucConnectDisconnect.Visible = (!CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup)) || Data.IsRequestCalculator;
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false;
				ucConnectDisconnect.MultiEditMode = true;
			}
		}
	}
}



