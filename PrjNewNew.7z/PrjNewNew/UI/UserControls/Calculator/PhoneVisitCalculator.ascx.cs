﻿using System;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class PhoneVisitCalculator : CalculatorBase
	{
		public PhoneVisitCalculatorData Data { get { return (PhoneVisitCalculatorData)CalculatorData.Data; } }
		public PhoneVisitCalculatorData ConnectedValues { get { return (PhoneVisitCalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlValues();
			AllowBlanksInMultiEditMode(Controls);
			HandleControlVisibilityInMultiEditMode();
			SetConnectedValues();
		}

		private void SetControlValues()
		{
			SetControlValue(phoneVisitTime, Data.PhoneVisitTime, false);
			SetControlValue(phonePrepFollowUpTime, Data.PhonePrepFollowUpTime, false);
			SetControlValue(phoneFte, Data.PhoneFte, false);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(phoneVisitTime, ConnectedValues.PhoneVisitTime);
			SetConnectedValue(phonePrepFollowUpTime, ConnectedValues.PhonePrepFollowUpTime);
			SetConnectedValue(phoneFte, ConnectedValues.PhoneFte);
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				trPhoneFte.Visible = false;
			}
		}
	}
}
