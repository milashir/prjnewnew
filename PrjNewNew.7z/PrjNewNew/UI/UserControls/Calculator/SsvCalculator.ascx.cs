﻿using System;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class SsvCalculator : CalculatorBase
	{
		public SsvCalculatorData Data { get { return (SsvCalculatorData)CalculatorData.Data; } }
		public SsvCalculatorData ConnectedValues { get { return (SsvCalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlValues();
			AllowBlanksInMultiEditMode(Controls);
			AllowBlanksInMultiEditMode(onsiteNumberOfSites);
			AllowBlanksInMultiEditMode(phoneNumberOfSites);
			HandleControlVisibility();
			SetConnectedValues();
			ChangeControlIds();
		}

		private void SetControlValues()
		{
			SetControlValue(onsiteNumberOfSites, Data.OnSiteNumberOfSites, false);
			SetControlValue(ssvPerSite, Data.SsvPerSite, false);
			SetControlValue(visitFrequency, Data.VisitFrequency, false);
			SetControlValue(travelTimeCluster, Data.ClusterTravelTime, false);
			SetControlValue(onSiteTime, Data.OnSiteTime, false);
			SetControlValue(prepFollowUpTime, Data.PrepFollowUpTime, false);
			SetControlValue(phoneNumberOfSites, Data.PhoneNumberOfSites, false);
			SetControlValue(phoneVisitFrequency, Data.PhoneVisitFrequency, false);
			SetControlValue(phoneVisitTime, Data.PhoneVisitTime, false);
			SetControlValue(phoneSsvPerSite, Data.PhoneSsvPerSite, false);
			SetControlValue(fte, Data.Fte, false);
			SetControlValue(phoneFte, Data.PhoneFte, false);
			SetFrequencyHeaderValue(frequencyHeader, Data.FrequencyHeader, Data.FrequencyHeaderToolTip);
			SetControlValue(totalNumberOfSites, Data.OnSiteNumberOfSites + Data.PhoneNumberOfSites, false);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(ssvPerSite, ConnectedValues.SsvPerSite);
			SetConnectedValue(visitFrequency, ConnectedValues.VisitFrequency);
			SetConnectedValue(travelTimeCluster, ConnectedValues.ClusterTravelTime);
			SetConnectedValue(onSiteTime, ConnectedValues.OnSiteTime);
			SetConnectedValue(prepFollowUpTime, ConnectedValues.PrepFollowUpTime);
			SetConnectedValue(phoneVisitFrequency, ConnectedValues.PhoneVisitFrequency);
			SetConnectedValue(phoneVisitTime, ConnectedValues.PhoneVisitTime);
			SetConnectedValue(phoneSsvPerSite, ConnectedValues.PhoneSsvPerSite);
			SetConnectedValue(fte, ConnectedValues.Fte);
			SetConnectedValue(phoneFte, ConnectedValues.PhoneFte);
			SetConnectedValue(onsiteNumberOfSites, ConnectedValues.OnSiteNumberOfSites);
			SetConnectedValue(phoneNumberOfSites, ConnectedValues.PhoneNumberOfSites);
			SetConnectedValue(totalNumberOfSites, ConnectedValues.OnSiteNumberOfSites + ConnectedValues.PhoneNumberOfSites);
		}

		public void ChangeControlIds()
		{
			SetFullyQualifiedControlId(divTotalHours);
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				trTotalHours.Visible = false;
				trFte.Visible = false;
				trPhoneFte.Visible = false;
				ucConnectDisconnect.MultiEditMode = true;
				trTotalNumberOfSites.Visible = false;
			}
		}

		private void HandleControlVisibility()
		{
			if (Data.IsRequestCalculator)
			{
				trOnsiteNumberOfSites.Visible = false;
				trPhoneNumberOfSites.Visible = false;
				trTotalNumberOfSites.Visible = false;
			}
			HandleControlVisibilityInMultiEditMode();
		}
	}
}
