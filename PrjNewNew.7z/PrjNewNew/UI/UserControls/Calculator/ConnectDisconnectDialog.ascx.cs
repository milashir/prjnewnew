﻿using System;
using Quintiles.RM.Clinical.Domain.BaseClasses.UserControls;
using Quintiles.RM.Clinical.Domain.Properties;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
    public partial class ConnectDisconnectDialog : RmBaseUserControl
    {
        public string InstructionalText { get; set; }
        public bool IsCountryCalculator { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            InstructionalText = IsCountryCalculator ? Resources.ValuesMatchQipLevelInstructionalText : Resources.ValuesMatchCountryLevelInstructionalText;
        }
    }
}
