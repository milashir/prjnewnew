﻿using System;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class CoMonitoringSiteSpecificCalculator : CalculatorBase
	{
		public MonitoringSiteSpecificVisitCalculatorData Data { get { return (MonitoringSiteSpecificVisitCalculatorData)CalculatorData.Data; } }
		public MonitoringSiteSpecificVisitCalculatorData ConnectedValues { get { return (MonitoringSiteSpecificVisitCalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlValues();
			AllowBlanksInMultiEditMode(Controls);
			HandleControlVisibilityInMultiEditMode();
			SetConnectedValues();
		}

		private void SetControlValues()
		{
			SetControlValue(visitFrequency, Data.VisitFrequency, false);
			SetControlValue(travelTimeCluster, Data.ClusterTravelTime, false);
			SetControlValue(onSiteTime, Data.OnSiteTime, false);
			SetControlValue(prepFollowUpTime, Data.PrepFollowUpTime, false);
			SetControlValue(fte, Data.Fte, false);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(visitFrequency, ConnectedValues.VisitFrequency);
			SetConnectedValue(travelTimeCluster, ConnectedValues.ClusterTravelTime);
			SetConnectedValue(onSiteTime, ConnectedValues.OnSiteTime);
			SetConnectedValue(prepFollowUpTime, ConnectedValues.PrepFollowUpTime);
			SetConnectedValue(fte, ConnectedValues.Fte);
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				trFte.Visible = false;
			}
		}

	}
}
