﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class AdHocCalculator : CalculatorBase
	{
		public AdhocCalculatorData Data { get { return (AdhocCalculatorData)CalculatorData.Data; } }
		public AdhocCalculatorData ConnectedValues { get { return (AdhocCalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlIds(phOnSiteVisit.Controls);
			SetControlValues();
			HideShowControls();
		}

		private void SetControlValues()
		{
			SetControlValue(adminTime, Data.AdminTime, false);
			SetControlValue(visitFrequency, Data.VisitFrequency, false);
			SetControlValue(travelTimeCluster, Data.ClusterTravelTime, false);
			SetControlValue(onSiteTime, Data.OnSiteTime, false);
			SetControlValue(prepFollowUpTime, Data.PrepFollowUpTime, false);
			SetControlValue(phoneVisitFrequency, Data.PhoneVisitFrequency, false);
			SetControlValue(phoneVisitTime, Data.PhoneVisitTime, false);
			SetControlValue(fte, Data.Fte, false);
			SetControlValue(phoneFte, Data.PhoneFte, false);

			originalStartDate.Value = Data.StartDate;
			startDate.Value = Data.StartDate;
			stopDate.Value = Data.StopDate;
			comment.Value = Data.Comment;

			if (Data.AllowDelete)
			{
				imgDelete.Attributes.Add("onclick", string.Format("calculatorGroup.removeCalculator('{0}', '{1}');return false;", GroupId, ControlPrefix));
			}
			else
			{
				imgDelete.Visible = false;
			}

			hlAdhocDates.InnerHtml = string.Format("{0}<br/>{1}", startDate.Value, stopDate.Value);
			//TODO:Uncomment when ready and delete below line if (Data.IsRequestHardOrSoftBooked && Data.StopDate.ToDateFromQDateString() < DateTime.Today)
			if (Data.StopDate.ToDateFromQDateString() < DateTime.Today)
			{
				DisableControls(Controls);
				DisableControls(phOnSiteVisit.Controls);
				hlAdhocDates.Attributes.Add("onclick", "calculatorGroup.editCalculatorDisabled();return false;");
			}
			else
			{
				hlAdhocDates.Attributes.Add("onclick", string.Format("calculatorGroup.editAdhocDates('{0}', '{1}');return false;", GroupId, ControlPrefix));
			}

			imgDelete.Disabled = false;
			hlAdhocDates.Disabled = false;
		}

		private void HideShowControls()
		{
			if (!Data.IsRequestCalculator)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false;
			}
			phOnSiteVisit.Visible = !CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup);

			if (CalculatorGroup_E.DTEPharmacyCalculator.Equals(Data.CalculatorGroup))
			{
				// Hide Phone visit section for DTE Pharmacy Monitoring
				this.phoneVisitFrequency.Visible = false;
				this.phoneVisitTime.Visible = false;
				this.phoneFte.Visible = false;

				// hide old values text inputs
				this.old_phoneVisitFrequency.Visible = false;
				this.old_phoneVisitTime.Visible = false;
				this.old_phoneFte.Visible = false;
			}
		}
	}
}
