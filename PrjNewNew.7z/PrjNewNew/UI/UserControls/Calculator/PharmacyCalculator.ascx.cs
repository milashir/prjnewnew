﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class PharmacyCalculator : CalculatorBase
	{
		public PharmacyCalculatorData Data { get { return (PharmacyCalculatorData)CalculatorData.Data; } }
		public PharmacyCalculatorData ConnectedValues { get { return (PharmacyCalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlValues();
			AllowBlanksInMultiEditMode(Controls);
			HandleControlVisibilityInMultiEditMode();
			SetConnectedValues();
			HideShowControls();
			SetFullyQualifiedControlId(ddlTierLevel);
		}

		private void SetControlValues()
		{
			SetControlValue(adminTime, Data.AdminTime, false);
			SetControlValue(visitFrequency, Data.VisitFrequency, false);
			SetControlValue(travelTimeCluster, Data.ClusterTravelTime, false);
			SetControlValue(onSiteTime, Data.OnSiteTime, false);
			SetControlValue(prepFollowUpTime, Data.PrepFollowUpTime, false);
			SetControlValue(phoneVisitFrequency, Data.PhoneVisitFrequency, false);
			SetControlValue(phoneVisitTime, Data.PhoneVisitTime, false);
			SetControlValue(fte, Data.Fte, false);
			SetControlValue(phoneFte, Data.PhoneFte, false);
			SetFrequencyHeaderValue(frequencyHeader, Data.FrequencyHeader, Data.FrequencyHeaderToolTip);
			SetFrequencyTierValue(ddlTierLevel, Data.FrequencyTiers, Data.DefaultTier, visitFrequency);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(adminTime, ConnectedValues.AdminTime);
			SetConnectedValue(visitFrequency, ConnectedValues.VisitFrequency);
			SetConnectedValue(travelTimeCluster, ConnectedValues.ClusterTravelTime);
			SetConnectedValue(onSiteTime, ConnectedValues.OnSiteTime);
			SetConnectedValue(prepFollowUpTime, ConnectedValues.PrepFollowUpTime);
			SetConnectedValue(phoneVisitFrequency, ConnectedValues.PhoneVisitFrequency);
			SetConnectedValue(phoneVisitTime, ConnectedValues.PhoneVisitTime);
			SetConnectedValue(fte, ConnectedValues.Fte);
			SetConnectedValue(phoneFte, ConnectedValues.PhoneFte);
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false;
				ucConnectDisconnect.MultiEditMode = true;
			}
		}

		private void HideShowControls()
		{
			if (!Data.IsRequestCalculator)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false; 
			}
			// Hide the tier dropdown for DTE Pharmacy country calculator
			tierLevel.Visible = CalculatorGroup_E.DTEPharmacyCalculator.Equals(Data.CalculatorGroup) && Data.IsRequestCalculator;

			if (CalculatorGroup_E.DTEPharmacyCalculator.Equals(Data.CalculatorGroup))
			{
				// Hide Phone visit section for DTE Pharmacy Monitoring
				this.phoneVisitFrequency.Visible = false;
				this.phoneVisitTime.Visible = false;
				this.phoneFte.Visible = false;

				// Show old values text inputs
				this.old_phoneVisitFrequency.Visible = false;
				this.old_phoneVisitTime.Visible = false;
				this.old_phoneFte.Visible = false;

				// Hide request level frequency in DTE Pharmacy Country calcultor and make the field read-only for request level.
				if (Data.IsRequestCalculator)
				{
					// Make the request level visit frequency as readonly
					this.visitFrequency.Disabled = true;
				}
				else
				{
					// Monitoring attributes hide "On site Visit Frequency"
					this.visitFrequency.Visible = false;
					this.old_visitFrequency.Visible = false;
				}
			}
		}
		public string GetTierJson()
		{
			return SerializationHelper.SerializeToJson(Data.VisitFrequencyByTier);
		}
	}
}
