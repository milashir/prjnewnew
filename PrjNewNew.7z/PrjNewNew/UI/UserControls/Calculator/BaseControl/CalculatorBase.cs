﻿using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using Quintiles.RM.Clinical.Domain.BaseClasses.UserControls;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl
{
	public class CalculatorBase : CalculatorUserControl
	{
		protected global::Quintiles.RM.Clinical.UI.UserControls.Calculator.ConnectDisconnect ucConnectDisconnect;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden connectedByImageClick;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden calculatorId;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden isChanged;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden isConnected;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden calculatorTypeId;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden calculatorGroupId;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden dmlOperation;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden countryLastModifiedOn;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden countryCalculatorId;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden requestCalculatorLastModifiedOn;
		protected global::System.Web.UI.HtmlControls.HtmlInputHidden requestCalculatorId;

		protected virtual void Page_Load(object sender, EventArgs e)
		{
			SetCommonControlValues();
			SetControlIds();
		}

		protected void SetControlIds(ControlCollection controls)
		{
			foreach (var childControl in controls)
			{
				if (childControl is HtmlInputHidden || childControl is HtmlInputText || childControl is HtmlAnchor || childControl is HtmlContainerControl)
				{
					SetFullyQualifiedControlId(childControl as HtmlControl);
				}
				if (childControl is HtmlContainerControl)
				{
					SetControlIds(((HtmlContainerControl)childControl).Controls);
				}
			}
		}

		public void DisableControls(ControlCollection controls)
		{
			foreach (var control in controls)
			{
				HtmlControl c = control as HtmlControl;
				if (c != null)
				{
					c.Disabled = true;
				}
			}
		}

		public void SetCommonControlValues()
		{
			if (ucConnectDisconnect != null)
			{
				ucConnectDisconnect.ControlPrefix = CalculatorData.Data.ControlPrefix;
				ucConnectDisconnect.IsConnected = CalculatorData.Data.IsConnected;
				ucConnectDisconnect.Visible = CalculatorData.Data.ShowConnectDisconnect;
				ucConnectDisconnect.IsCountryCalculator = !CalculatorData.Data.IsRequestCalculator && !CalculatorData.Data.IsNewRequest;

			}
			calculatorId.Value = CalculatorData.Data.CalculatorId.ToString();
			isConnected.Value = GetIntAsStringFromBool(CalculatorData.Data.IsConnected);
			calculatorTypeId.Value = ((int)CalculatorData.Data.CalculatorType).ToString();
			calculatorGroupId.Value = ((int)CalculatorData.Data.CalculatorGroup).ToString();
			dmlOperation.Value = ((int)CalculatorData.Data.DmlOperation).ToString();
			countryLastModifiedOn.Value = (CalculatorData.Data.CountryLastModifiedOn.HasValue ? CalculatorData.Data.CountryLastModifiedOn.GetValueOrDefault().Ticks : 0).ToString();
			countryCalculatorId.Value = CalculatorData.Data.CountryCalculatorId.GetValueOrDefault().ToString();
			requestCalculatorLastModifiedOn.Value = (CalculatorData.Data.RequestCalculatorLastModifiedOn.HasValue ? CalculatorData.Data.RequestCalculatorLastModifiedOn.GetValueOrDefault().Ticks : 0).ToString();
			requestCalculatorId.Value = CalculatorData.Data.RequestCalculatorId.GetValueOrDefault().ToString();
			connectedByImageClick.Value = "1";
			isChanged.Value = "-1";
		}

		private void SetControlIds()
		{
			SetControlIds(Controls);
		}

		private void SetAttributeOnControl(HtmlControl control, string attributeName, string attributeValue)
		{
			control.Attributes.Add(attributeName, attributeValue);
		}

		public void AllowBlanksInMultiEditMode(HtmlControl control)
		{
			if (MultiEditMode)
			{
				SetAttributeOnControl(control, "allowBlank", "true");
			}
		}

		public void AllowBlanksInMultiEditMode(ControlCollection controls)
		{
			if (MultiEditMode)
			{
				for (int index = 0; index < controls.Count; index++)
				{
					var childControl = controls[index];
					if (childControl != null && (childControl is HtmlInputHidden || childControl is HtmlInputText || childControl is HtmlAnchor || childControl is HtmlContainerControl))
					{
						SetAttributeOnControl(childControl as HtmlControl, "allowBlank", "true");
					}
				}
				//foreach (var childControl in controls)
				//{
				//	if (childControl is HtmlInputHidden || childControl is HtmlInputText || childControl is HtmlAnchor || childControl is HtmlContainerControl)
				//	{
				//		SetAttributeOnControl(childControl as HtmlControl, "allowBlank", "true");
				//	}
				//}
			}
		}
	}
}
