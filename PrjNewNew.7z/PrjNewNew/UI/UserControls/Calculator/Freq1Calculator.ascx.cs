﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class Freq1Calculator : CalculatorBase
	{
		public Freq1CalculatorData Data { get { return (Freq1CalculatorData)CalculatorData.Data; } }
		public Freq1CalculatorData ConnectedValues { get { return (Freq1CalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlIds(phOnSiteVisit.Controls);
			SetFullyQualifiedControlId(ddlTierLevel);
			AllowBlanksInMultiEditMode(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(Controls);
			HandleControlVisibilityInMultiEditMode();
			SetControlValues();
			SetConnectedValues();
			HideShowControls();
		}

		private void SetControlValues()
		{
			SetControlValue(adminTime, Data.AdminTime, false);
			SetControlValue(visitFrequency, Data.VisitFrequency, false);
			SetControlValue(travelTimeCluster, Data.ClusterTravelTime, false);
			SetControlValue(onSiteTime, Data.OnSiteTime, false);
			SetControlValue(prepFollowUpTime, Data.PrepFollowUpTime, false);
			SetControlValue(phoneVisitFrequency, Data.PhoneVisitFrequency, false);
			SetControlValue(phoneVisitTime, Data.PhoneVisitTime, false);
			SetControlValue(fte, Data.Fte, false);
			SetControlValue(phoneFte, Data.PhoneFte, false);
			SetFrequencyHeaderValue(frequencyHeader, Data.FrequencyHeader, Data.FrequencyHeaderToolTip);
			SetFrequencyTierValue(ddlTierLevel, Data.FrequencyTiers, Data.DefaultTier, visitFrequency, phoneVisitFrequency);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(adminTime, ConnectedValues.AdminTime);
			SetConnectedValue(visitFrequency, ConnectedValues.VisitFrequency);
			SetConnectedValue(travelTimeCluster, ConnectedValues.ClusterTravelTime);
			SetConnectedValue(onSiteTime, ConnectedValues.OnSiteTime);
			SetConnectedValue(prepFollowUpTime, ConnectedValues.PrepFollowUpTime);
			SetConnectedValue(phoneVisitFrequency, ConnectedValues.PhoneVisitFrequency);
			SetConnectedValue(phoneVisitTime, ConnectedValues.PhoneVisitTime);
			SetConnectedValue(fte, ConnectedValues.Fte);
			SetConnectedValue(phoneFte, ConnectedValues.PhoneFte);
		}

		private void HideShowControls()
		{
			if (!Data.IsRequestCalculator)
			{
				trFte1.Visible = false;
				trPhoneFte.Visible = false; 
			}
			phOnSiteVisit.Visible = !CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup);
			tierLevel.Visible = (CalculatorGroup_E.DTEMonitoringCalculator.Equals(Data.CalculatorGroup) && Data.IsRequestCalculator);

			if (CalculatorGroup_E.DTEMonitoringCalculator.Equals(Data.CalculatorGroup))
			{
				this.visitFrequency.Visible = false;
				this.old_visitFrequency.Visible = false;
				this.phoneVisitFrequency.Visible = false;
				this.old_phoneVisitFrequency.Visible = false;
			}

			this.ucConnectDisconnect.Visible = (!CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup)) || Data.IsRequestCalculator;
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				trFte1.Visible = false;
				trPhoneFte.Visible = false;
				ucConnectDisconnect.MultiEditMode = true;
			}
		}
	}
}









