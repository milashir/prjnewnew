﻿using System;
using System.Web.UI.HtmlControls;
using Quintiles.RM.Clinical.Domain.BaseClasses.UserControls;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class ConnectDisconnect : RmBaseUserControl
	{
		public string ControlPrefix { get; set; }
		public bool IsConnected { get; set; }
		public bool MultiEditMode { get; set; }
		public bool IsCountryCalculator { get; set; }

		protected void Page_Load(object sender, EventArgs e)
		{
			if (MultiEditMode)
			{
				IsConnected = false;
				imgConnect.Disabled = true;
				imgConnect.Attributes.Add("class", "disabledImage");
			}
			if (IsConnected)
			{
				imgReConnect.Attributes.Add("style", "display:none;");
			}
			else
			{
				imgConnect.Attributes.Add("style", "display:none;");
				//if (IsCountryCalculator)
				//{
				//	imgReConnect.Visible = false;
				//	imgConnect.Visible = false;
				//}
				//else
				//{
				//	imgConnect.Attributes.Add("style", "display:none;");
				//}
			}

			imgReConnect.Attributes.Add("controlPrefix", ControlPrefix);
			imgConnect.Attributes.Add("title", IsCountryCalculator ? "The values for this Type/Frequency are connected to the budget values" : "The values for this type/frequency are connected to the country level values.");

			SetFullyQualifiedControlId(imgConnect, ControlPrefix);
			SetFullyQualifiedControlId(imgReConnect, ControlPrefix);
			SetImageConnectDisconnectPath(IsCountryCalculator, imgConnect, imgReConnect);
		}

		private void SetImageConnectDisconnectPath(bool IsCountryCalculator, HtmlImage imgConnect, HtmlImage imgReConnect)
		{
			imgConnect.Src = IsCountryCalculator ? "/_layouts/SPUI/images/ConnectedBudget.png" : "/_layouts/SPUI/images/conncted.png";
			imgReConnect.Src = IsCountryCalculator ? "/_layouts/SPUI/images/DisconnectedBudget.png" : "/_layouts/SPUI/images/reconnect.png";
		}
	}
}
