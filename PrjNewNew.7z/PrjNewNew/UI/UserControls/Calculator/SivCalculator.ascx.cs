﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class SivCalculator : CalculatorBase
	{
		public SivCalculatorData Data { get { return (SivCalculatorData)CalculatorData.Data; } }
		public SivCalculatorData ConnectedValues { get { return (SivCalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlIds(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(Controls);
			HandleControlVisibilityInMultiEditMode();
			SetControlValues();
			SetConnectedValues();
			HideShowControls();
		}

		private void SetControlValues()
		{
			SetControlValue(sivPerSite, Data.SivPerSite, false);
			SetControlValue(visitFrequency, Data.VisitFrequency, false);
			SetControlValue(travelTimeCluster, Data.ClusterTravelTime, false);
			SetControlValue(onSiteTime, Data.OnSiteTime, false);
			SetControlValue(prepFollowUpTime, Data.PrepFollowUpTime, false);
			SetControlValue(phoneSivPerSite, Data.PhoneSivPerSite, false);
			SetControlValue(phoneVisitFrequency, Data.PhoneVisitFrequency, false);
			SetControlValue(phoneVisitTime, Data.PhoneVisitTime, false);
			SetControlValue(fte, Data.Fte, false);
			SetControlValue(phoneFte, Data.PhoneFte, false);
			SetFrequencyHeaderValue(frequencyHeader, Data.FrequencyHeader, Data.FrequencyHeaderToolTip);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(sivPerSite, ConnectedValues.SivPerSite);
			SetConnectedValue(visitFrequency, ConnectedValues.VisitFrequency);
			SetConnectedValue(travelTimeCluster, ConnectedValues.ClusterTravelTime);
			SetConnectedValue(onSiteTime, ConnectedValues.OnSiteTime);
			SetConnectedValue(prepFollowUpTime, ConnectedValues.PrepFollowUpTime);
			SetConnectedValue(phoneSivPerSite, ConnectedValues.PhoneSivPerSite);
			SetConnectedValue(phoneVisitFrequency, ConnectedValues.PhoneVisitFrequency);
			SetConnectedValue(phoneVisitTime, ConnectedValues.PhoneVisitTime);
			SetConnectedValue(fte, ConnectedValues.Fte);
			SetConnectedValue(phoneFte, ConnectedValues.PhoneFte);
		}

		private void HideShowControls()
		{
			if (!Data.IsRequestCalculator)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false;
			}
			phOnSiteVisit.Visible = !CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup);

			// Hide Phone visit section for DTE Pharmacy Monitoring
			if (CalculatorGroup_E.DTEPharmacyCalculator.Equals(Data.CalculatorGroup))
			{

				// Set the invisible fields to 0
				this.phoneSivPerSite.Value = "0";
				this.phoneVisitFrequency.Value = "0";
				this.phoneVisitTime.Value = "0";
				this.phoneFte.Value = "0";

				// Hide Phone visit section for DTE Pharmacy Monitoring
				this.phoneSivPerSite.Visible = false;
				this.phoneVisitFrequency.Visible = false;
				this.phoneVisitTime.Visible = false;
				this.phoneFte.Visible = false;

				// Show old values text inputs
				this.old_phoneSivPerSite.Visible = false;
				this.old_phoneVisitFrequency.Visible = false;
				this.old_phoneVisitTime.Visible = false;
				this.old_phoneFte.Visible = false;
			}

			this.ucConnectDisconnect.Visible = (!CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup)) || Data.IsRequestCalculator;
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false;
				ucConnectDisconnect.MultiEditMode = true;
			}
		}
	}
}





