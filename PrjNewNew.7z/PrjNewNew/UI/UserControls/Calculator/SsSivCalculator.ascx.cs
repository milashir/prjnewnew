﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class SsSivCalculator : CalculatorBase
	{
		public SsSivCalculatorData Data { get { return (SsSivCalculatorData)CalculatorData.Data; } }
		public SsSivCalculatorData ConnectedValues { get { return (SsSivCalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlIds(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(Controls);
			HandleControlVisibilityInMultiEditMode();
			SetControlValues();
			SetConnectedValues();
			HideShowControls();
		}

		private void SetControlValues()
		{
			SetControlValue(adminTime, Data.AdminTime, false);
			SetFrequencyHeaderValue(frequencyHeader, Data.FrequencyHeader, Data.FrequencyHeaderToolTip);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(adminTime, ConnectedValues.AdminTime);
		}

		private void HideShowControls()
		{
			phOnSiteVisit.Visible = !CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup);
			this.ucConnectDisconnect.Visible = Data.IsRequestCalculator;
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				ucConnectDisconnect.MultiEditMode = true;
			}
		}
	}
}
