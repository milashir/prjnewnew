﻿using System;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.UI.UserControls.Calculator.BaseControl;

namespace Quintiles.RM.Clinical.UI.UserControls.Calculator
{
	public partial class Freq3Calculator : CalculatorBase
	{
		public Freq3CalculatorData Data { get { return (Freq3CalculatorData)CalculatorData.Data; } }
		public Freq3CalculatorData ConnectedValues { get { return (Freq3CalculatorData)CalculatorData.Data.ConnectedValues; } }

		protected override void Page_Load(object sender, EventArgs e)
		{
			base.Page_Load(sender, e);

			SetControlIds(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(phOnSiteVisit.Controls);
			AllowBlanksInMultiEditMode(Controls);
			HandleControlVisibilityInMultiEditMode();
			SetControlValues();
			SetConnectedValues();
			HideShowControls();
		}

		private void SetControlValues()
		{
			SetControlValue(adminTime, Data.AdminTime, false);
			SetControlValue(visitFrequency, Data.VisitFrequency, false);
			SetControlValue(travelTimeCluster, Data.ClusterTravelTime, false);
			SetControlValue(onSiteTime, Data.OnSiteTime, false);
			SetControlValue(prepFollowUpTime, Data.PrepFollowUpTime, false);
			SetControlValue(phoneVisitFrequency, Data.PhoneVisitFrequency, false);
			SetControlValue(phoneVisitTime, Data.PhoneVisitTime, false);
			SetControlValue(fte, Data.Fte, false);
			SetControlValue(phoneFte, Data.PhoneFte, false);
			SetFrequencyHeaderValue(frequencyHeader, Data.FrequencyHeader, Data.FrequencyHeaderToolTip);
		}

		private void SetConnectedValues()
		{
			SetConnectedValue(adminTime, ConnectedValues.AdminTime);
			SetConnectedValue(visitFrequency, ConnectedValues.VisitFrequency);
			SetConnectedValue(travelTimeCluster, ConnectedValues.ClusterTravelTime);
			SetConnectedValue(onSiteTime, ConnectedValues.OnSiteTime);
			SetConnectedValue(prepFollowUpTime, ConnectedValues.PrepFollowUpTime);
			SetConnectedValue(phoneVisitFrequency, ConnectedValues.PhoneVisitFrequency);
			SetConnectedValue(phoneVisitTime, ConnectedValues.PhoneVisitTime);
			SetConnectedValue(fte, ConnectedValues.Fte);
			SetConnectedValue(phoneFte, ConnectedValues.PhoneFte);
		}

		private void HideShowControls()
		{
			if (!Data.IsRequestCalculator)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false; 
			}
			phOnSiteVisit.Visible = !CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup);
			this.ucConnectDisconnect.Visible = (!CalculatorGroup_E.ICraCalculator.Equals(Data.CalculatorGroup)) || Data.IsRequestCalculator;
		}

		private void HandleControlVisibilityInMultiEditMode()
		{
			if (MultiEditMode)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false;
				ucConnectDisconnect.MultiEditMode = true;
			}
		}
	}
}








