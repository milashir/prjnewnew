﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Quintiles.RM.Clinical.Domain.Services;
namespace Quintiles.RM.Clinical.UI.UserControls
{

    public partial class Dialog_ProjectMilestones : System.Web.UI.UserControl
    {
        public string revision { get { return CacheService.GetRevisionQueryString; } }
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}