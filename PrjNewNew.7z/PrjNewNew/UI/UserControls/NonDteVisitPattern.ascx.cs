﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Domain.Models.DTE;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class NonDteVisitPattern : UserControl
	{
		public bool IsCountryCalculator { get; set; }
		public CalculatorGroup_E CalculatorGroup { get; set; }
		public int MonitoringAttributeId { get; set; }
		public bool MultiEditMode { get; set; }
		private MonitoringAttribute MonAttribute { get; set; }

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!MultiEditMode && IsCountryCalculator)
			{
				MonAttribute = MonitoringAttribute.Find(MonitoringAttributeId);
				var ssvAttribute = SSVAttribute.FindByProjectIdCountryId(MonAttribute.ProjectId, MonAttribute.CountryId);
				List<FrequencySiteVisitProjection> frequencyVisitProjectionDetails;
				try
				{
					VisitCount outOfRangeVisitCount;
					new CountryLevelVisitProjector(MonAttribute, ssvAttribute, MonAttribute.BudgetedSites.GetValueOrDefault()).GetVisitCountFromCalculatorFrequencies(CalculatorGroup, out frequencyVisitProjectionDetails, out outOfRangeVisitCount);

					if (outOfRangeVisitCount != null)
					{
						frequencyVisitProjectionDetails.Add(new FrequencySiteVisitProjection
						{
							OutOfRangeVisitCount = true,
							ActualOnsiteVisitCount = outOfRangeVisitCount.IntOnsiteImvVisitCount,
							ActualRemoteVisitCount = outOfRangeVisitCount.IntRemoteVisitCount
						});
					}
					rptVisitFrequency.DataSource = frequencyVisitProjectionDetails;
					rptVisitFrequency.DataBind();

				}
				catch (RMException ex)
				{
					ltrDateValidationError.Visible = true;
					hdnDateValidatioError.Value = string.Format("Visit projection is not possible because {0}", ex.Message);
				}
			}
		}

		protected string BuildProjectedVisitRow(FrequencySiteVisitProjection projection)
		{
			if (projection.OutOfRangeVisitCount)
			{
				return string.Format(@"<tr>
					<td colspan='6'>Actual Visits (other than SIV and COV) outside of SIV-COV date range</td>
					<td>{0}</td>
					<td colspan='3'>-</td>
					<td>{1}</td>
				</tr>",
								projection.ActualOnsiteVisitCount,
								projection.ActualRemoteVisitCount
					);
			}
			else
			{
				return string.Format(@"<tr>
					<td>{0}</td>
					<td>{1}</td>
					<td>{2}</td>
					<td>{3}</td>
					{4}
					<td>{5}</td>
					<td>{6}</td>
					<td>{7}</td>
					{8}
					<td>{9}</td>
					<td>{10}</td>
				</tr>",
								projection.Frequency,
								projection.StartDate.ToQDateString(),
								projection.StopDate.ToQDateString(),
								ShowVisitFrequency(projection) ? projection.OnsiteVisitFrequency.ToString() : string.Empty,
								ShowQipBudgetedValue(projection, true),
								projection.CalculatorType == CalculatorType_E.SIV ? projection.ProjectedSivVisitCount
																																	: (projection.CalculatorType == CalculatorType_E.COV ? projection.ProjectedCovVisitCount
																																																											 : projection.ProjectedOnsiteImvVisitCount),
								projection.ActualOnsiteVisitCount,
								ShowVisitFrequency(projection) ? projection.RemoteVisitFrequency.ToString() : string.Empty,
								ShowQipBudgetedValue(projection, false),
								projection.ProjectedRemoteVisitCount,
								projection.ActualRemoteVisitCount
					);
			}
		}

		private object ShowQipBudgetedValue(FrequencySiteVisitProjection projection, bool showOnsiteCount)
		{
			if (projection.CalculatorType == CalculatorType_E.IMV_Freq1_FPI_LPI)
			{
				return string.Format("<td rowSpan=\"4\">{0}</td>", showOnsiteCount ? MonAttribute.QipBudgetedOnsiteImvVisitCount : MonAttribute.QipBudgetedRemoteVisitCount);
			}
			else if (projection.CalculatorType == CalculatorType_E.SIV)
			{
				return string.Format("<td>{0}</td>", showOnsiteCount ? MonAttribute.QipBudgetedSites.GetValueOrDefault() : projection.QipBudgetedRemoteVisitCount);
			}
			else if (projection.CalculatorType == CalculatorType_E.COV)
			{
				return string.Format("<td>{0}</td>", showOnsiteCount ? MonitoringAttribute.GetBudgetedCovVisisCountFromBudgetedSites(MonAttribute, MonAttribute.QipBudgetedSites.GetValueOrDefault()) : projection.QipBudgetedRemoteVisitCount);
			}
			else if (projection.CalculatorType == CalculatorType_E.PharmacyMonitoring)
			{
				return string.Format("<td>{0}</td>", showOnsiteCount ? MonAttribute.QipBudgetedPharmacyVisitCount : 0);
			}
			else if (projection.CalculatorType == CalculatorType_E.SIV_FPI || projection.CalculatorType == CalculatorType_E.SS_SIV)
			{
				return string.Format("<td>{0}</td>", showOnsiteCount ? projection.QipBudgetedOnsiteVisitCount : projection.QipBudgetedRemoteVisitCount);
			}
			else
			{
				return "";
			}
		}

		private bool ShowVisitFrequency(FrequencySiteVisitProjection projection)
		{
			return projection.CalculatorType != CalculatorType_E.SIV && projection.CalculatorType != CalculatorType_E.COV && projection.CalculatorType != CalculatorType_E.SIV_FPI;
		}

		protected void rptVisitFrequency_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == System.Web.UI.WebControls.ListItemType.Footer)
			{
				var frequencyVisitProjectionDetails = rptVisitFrequency.DataSource as List<FrequencySiteVisitProjection>;

				int totalBudgetedOsVisistCount = (CalculatorGroup == CalculatorGroup_E.PharmacyCalculator ? MonAttribute.QipBudgetedPharmacyVisitCount : MonAttribute.QipBudgetedOnsiteImvVisitCount).GetValueOrDefault();
				int totalProjectedOsVisistCount = 0;
				int totalActualOsVisistCount = 0;
				int totalBudgetedRvVisistCount = CalculatorGroup == CalculatorGroup_E.PharmacyCalculator ? 0 : MonAttribute.QipBudgetedRemoteVisitCount.GetValueOrDefault();
				int totalProjectedRvVisistCount = 0;
				int totalActualRvVisistCount = 0;

				frequencyVisitProjectionDetails.ForEach(fvpd =>
				{
					totalBudgetedOsVisistCount += (fvpd.CalculatorType == CalculatorType_E.SIV || fvpd.CalculatorType == CalculatorType_E.COV) ? fvpd.QipBudgetedOnsiteVisitCount : 0;
					totalProjectedOsVisistCount += fvpd.CalculatorType == CalculatorType_E.SIV ? fvpd.ProjectedSivVisitCount
																																										 : (fvpd.CalculatorType == CalculatorType_E.COV ? fvpd.ProjectedCovVisitCount
																																																																		: fvpd.ProjectedOnsiteImvVisitCount);
					totalActualOsVisistCount += fvpd.ActualOnsiteVisitCount;
					totalProjectedRvVisistCount += fvpd.ProjectedRemoteVisitCount;
					totalActualRvVisistCount += fvpd.ActualRemoteVisitCount;
				});

				GetLabelControlById(e, "lblTotalBudgetedOsVisists").Text = totalBudgetedOsVisistCount.ToString();
				GetLabelControlById(e, "lblTotalProjectedOsVisists").Text = totalProjectedOsVisistCount.ToString();
				GetLabelControlById(e, "lblTotalActualOsVisists").Text = totalActualOsVisistCount.ToString();
				GetLabelControlById(e, "lblTotalBudgetedRvVisists").Text = totalBudgetedRvVisistCount.ToString();
				GetLabelControlById(e, "lblTotalProjectedRvVisists").Text = totalProjectedRvVisistCount.ToString();
				GetLabelControlById(e, "lblTotalActualRvVisists").Text = totalActualRvVisistCount.ToString();
			}
		}

		private Label GetLabelControlById(RepeaterItemEventArgs e, string controlId)
		{
			return e.Item.FindControl(controlId) as Label;
		}
	}
}
