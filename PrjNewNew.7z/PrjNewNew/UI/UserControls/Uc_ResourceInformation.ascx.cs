﻿using System;
using System.Web.UI;
namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class Uc_ResourceInformation : UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}