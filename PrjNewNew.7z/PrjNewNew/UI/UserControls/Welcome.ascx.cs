﻿using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RM.Clinical.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Quintiles.RM.Clinical.UI.UserControls
{
    public partial class Welcome : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ltrUserName.Text = UserCache.Usr.Name;
        }
    }
}