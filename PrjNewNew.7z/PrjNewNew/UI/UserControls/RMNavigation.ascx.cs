﻿using System;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Quintiles.RM.Clinical.Domain.Models;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class RMNavigation : UserControl
	{
		public Project ProjectInContext { get; set; }

		//Moving code to pre render to allow base page to set ProjectInContext
		protected void Page_PreRender(object sender, EventArgs e)
		{
			var rmLinkManager = new RmLinkManager(RmUser.FindOneByProperty("QId", ExtensionMethods.GetCurrentUserQid()), ProjectInContext);
			var navigation = rmLinkManager.GetNavigation();

			BuildFlyoutMenu(navigation);

			lblBuildInfo.InnerHtml = string.Format("Build Version: {0}<br/>Build Date: {1}<br/>Web Server: {2}<br/>Database Server: {3}<br/>Database: {4}",
																							ConfigValue.BuildVersion,
																							ConfigValue.BuildDate,
																							ExtensionMethods.GetCurrentServerName().Substring(ExtensionMethods.GetCurrentServerName().Length - 3),
																							Common.GetDbInstanceName(),
																							Common.GetDatabaseName()
																						);
		}

		private void BuildFlyoutMenu(RmNavigation navigation)
		{
			var menuItemTemplate = "<li class='topMostParent'><div>{0}</div>{1}</li>";

			if (navigation != null && navigation.NavigationSections != null && navigation.NavigationSections.Count > 0)
			{
				var menuBuilder = new StringBuilder();
				foreach (var navSection in navigation.NavigationSections)
				{
					menuBuilder.AppendFormat(menuItemTemplate, navSection.SectionHeadText, GetSectionLinkHtml(navSection.Links));
				}
				ltrTopMenu.Text = menuBuilder.ToString();
			}
		}

		private string GetSectionLinkHtml(System.Collections.Generic.List<RmPageLink> pageLinks)
		{
			string linkTemplate = "<li><a id='{0}' href='{1}' tooltiptext='{2}'>{3}{4}</a></li>";
			if (pageLinks != null && pageLinks.Count > 0)
			{
				var itemBuilder = new StringBuilder("<ul>");
				foreach (var pageLink in pageLinks)
				{
					string countHtml = pageLink.ShowCount ? string.Format(" (<span id='{0}'></span>)", pageLink.CountPlaceHoldSelector) : string.Empty;
					string tooltip = !string.IsNullOrEmpty(pageLink.ToolTip) ? HttpUtility.HtmlAttributeEncode(pageLink.ToolTip).EscapeHtmlAttributeString() : string.Empty;
					itemBuilder.AppendFormat(linkTemplate, pageLink.LinkSelector, pageLink.LinkUrl, tooltip, pageLink.LinkText, countHtml);
				}
				return itemBuilder.Append("</ul>").ToString();
			}
			else
			{
				return string.Empty;
			}
		}
	}
}
