﻿
namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	//Following classes are required only till all pages are moved to new ribbon lobrary.
	public class GroupTemplateDefinition : RibbonDefinition	{ }

	public class GroupTemplateLibrary
	{
		/// <summary>
		/// This simple group template allows you create plain ribbon group with unbounded number of large (32x32 icons) controls inside.
		/// This group template contains only one control section.
		/// </summary>
		public static GroupTemplateDefinition SimpleTemplate = new GroupTemplateDefinition();
	}
}
