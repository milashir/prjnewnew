﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	public enum ControlSize : short
	{
		Size32x32 = 0,
		Size16x16 = 1
	}

	public class ToolTipDefinition
	{
		public string Title = string.Empty;
		public string Description = string.Empty;
	}

	public class RmRibbon
	{
		private bool IsInitialized { get; set; }
		private string JS_FINAL_OUTPUT_TEMPLATE =
@"<script language=""javascript"" type=""text/javascript"">
	{0}{1}{2}{3}{4}
	$(document).ready(function () {{ rm.ui.ribbon.onLoad(); }});
</script>";

		private string JS_GLOBAL_COMMANDLIST_TEMPLATE = "function getRmRibbonGlobalCommands(){{ return {0}; }}";
		private string JS_FUNCTION_COMMAND_ENABLED_TEMPLATE = "function rmRibbonCommandEnabled(commandId){{ {0}; }}";
		private string JS_FUNCTION_HANDLE_COMMAND_TEMPLATE = "function rmRibbonHandleCommand(commandId, properties, sequence){{ {0}; }}";

		private string JS_IS_ENABLED_CONDITION_TEMPLATE = "if (commandId == '{0}') {{ return {1}; }}{2}";
		private string JS_CLICK_HANDLER_SNIPPET_TEMPLATE = "if (commandId == '{0}') {{ {1}; return true; }}{2}";

		private string HTML_TEMPLATE =
@"<div id=""RmRibbonrow"" class=""rm-ribbonrow"">
		<div id=""rm-ribboncont"">
			<div id=""RibbonContainer"">
				<div class=""rm-ribbon"" id=""RmRibbon"" unselectable=""on"" oncontextmenu=""return false"">
					<div class=""rm-ribbonTopBars"" unselectable=""on"">
						<div class=""rm-topBar1"" unselectable=""on"" style=""display:none""><div class=""rm-qat-container"" unselectable=""on""></div></div>
						<div class=""rm-topBar2"" unselectable=""on"">
							<div class=""rm-TabRowLeftSpacer"" id=""RibbonContainer-TabRowLeft"" unselectable=""on""></div>
							<ul class=""rm-tts "" unselectable=""on"" role=""tablist"">{0}</ul>
						</div>
					</div>
					{1}
				</div>
			</div>
		</div>
	</div>";

		public List<TabDefinition> Tabs { get; set; }

		private void Initialize()
		{
			if (!IsInitialized)
			{
				if (Tabs != null && Tabs.Count > 0)
				{
					foreach (var tab in Tabs) { tab.Initialize(); }
					IsInitialized = true;
				}
			}
		}

		internal string GetJavaScript()
		{
			Initialize();

			var commandIdList = new List<string>();
			var sbCmdEnabled = new StringBuilder();
			var sbHandleCmd = new StringBuilder();

			if (Tabs != null && Tabs.Count > 0)
			{
				foreach (var tab in Tabs)
				{

					foreach (var group in tab.Groups)
					{
						foreach (var control in group.Controls)
						{
							if (control is CheckboxDefinition)
							{
								var buttonControl = (ButtonBaseDefinition)control;
								commandIdList.Add(buttonControl.FullyQualifiedCheckboxId);
								sbCmdEnabled.AppendFormat(JS_IS_ENABLED_CONDITION_TEMPLATE, buttonControl.FullyQualifiedCheckboxId, buttonControl.CommandEnableJavaScript, Environment.NewLine);
								sbHandleCmd.AppendFormat(JS_CLICK_HANDLER_SNIPPET_TEMPLATE, buttonControl.FullyQualifiedCheckboxId, buttonControl.CommandJavaScript, Environment.NewLine);
							}
							else if (control is ButtonBaseDefinition)
							{
								var buttonControl = (ButtonBaseDefinition)control;
								commandIdList.Add(buttonControl.FullyQualifiedId);
								sbCmdEnabled.AppendFormat(JS_IS_ENABLED_CONDITION_TEMPLATE, buttonControl.FullyQualifiedId, buttonControl.CommandEnableJavaScript, Environment.NewLine);
								sbHandleCmd.AppendFormat(JS_CLICK_HANDLER_SNIPPET_TEMPLATE, buttonControl.FullyQualifiedId, buttonControl.CommandJavaScript, Environment.NewLine);
							}
							else if (control is FlyoutAnchorDefinition)
							{
								var flyoutMenu = (FlyoutAnchorDefinition)control;

								commandIdList.Add(flyoutMenu.FullyQualifiedId);
								sbCmdEnabled.AppendFormat(JS_IS_ENABLED_CONDITION_TEMPLATE, flyoutMenu.FullyQualifiedId, flyoutMenu.CommandEnableJavaScript, Environment.NewLine);
								sbHandleCmd.AppendFormat(JS_CLICK_HANDLER_SNIPPET_TEMPLATE, flyoutMenu.FullyQualifiedId, flyoutMenu.CommandJavaScript, Environment.NewLine);


								foreach (var menuItem in flyoutMenu.Controls)
								{
									commandIdList.Add(menuItem.FullyQualifiedId);
									sbCmdEnabled.AppendFormat(JS_IS_ENABLED_CONDITION_TEMPLATE, menuItem.FullyQualifiedId, menuItem.CommandEnableJavaScript, Environment.NewLine);
									sbHandleCmd.AppendFormat(JS_CLICK_HANDLER_SNIPPET_TEMPLATE, menuItem.FullyQualifiedId, menuItem.CommandJavaScript, Environment.NewLine);
								}
							}
						}
					}
				}
			}
			sbCmdEnabled.Append("return false;");
			sbHandleCmd.Append("return false;");

			return string.Format(JS_FINAL_OUTPUT_TEMPLATE,
				string.Format(JS_GLOBAL_COMMANDLIST_TEMPLATE, JsonConvert.SerializeObject(commandIdList)),
				Environment.NewLine,
				string.Format(JS_FUNCTION_COMMAND_ENABLED_TEMPLATE, sbCmdEnabled.ToString()),
				Environment.NewLine,
				string.Format(JS_FUNCTION_HANDLE_COMMAND_TEMPLATE, sbHandleCmd.ToString()));
		}

		internal string GetHtml(out string flyoutMenuHtml)
		{
			flyoutMenuHtml = string.Empty;

			Initialize();
			if (Tabs != null && Tabs.Count > 0)
			{
				var headerBuilder = new StringBuilder();
				var bodyBuilder = new StringBuilder();
				var menuBuilder = new StringBuilder();
				for (int tabIndex = 0; tabIndex < Tabs.Count; tabIndex++)
				{
					string menuHtml;
					headerBuilder.Append(Tabs[tabIndex].GetHeaderHtml(tabIndex == 0));
					bodyBuilder.Append(Tabs[tabIndex].GetBodyHtml(tabIndex == 0, out menuHtml));
					menuBuilder.Append(menuHtml);
				}
				flyoutMenuHtml = menuBuilder.ToString();
				return string.Format(HTML_TEMPLATE, headerBuilder.ToString(), bodyBuilder.ToString());
			}
			return string.Empty;
		}
	}
}
