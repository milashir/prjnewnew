﻿
namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	public abstract class ButtonBaseDefinition : VisualControlBaseDefinition
	{
		/// <summary>
		/// Javascript will be run when button is pressed.
		/// Required for all types of buttons.
		/// By default, button does nothing.
		/// </summary>
		public string CommandJavaScript = string.Empty;

		/// <summary>
		/// Javascript to determine, if control is enabled or disabled.
		/// By default it is "true" (button is always enabled).
		/// </summary>
		public string CommandEnableJavaScript = "true";
	}

	/// <summary>Simple button. Does not have inner controls.</summary>
	public class ButtonDefinition : ButtonBaseDefinition
	{
		private string HtmlTemplate = @"
<a class=""rm-ribbon-ctl-large rm-ribbon-disabled"" id=""{0}"" href=""javascript:;"" onclick=""return false;"" title=""{1}"" unselectable=""on"" controlType=""{2}"">
	<span class=""rm-ribbon-ctl-largeIconContainer"" unselectable=""on"">
		<span class=""rm-ribbon-img-32by32 rm-ribbon-img-cont-float rm-ribbon-imageDisabled"" unselectable=""on"">
			<img style=""{3}"" unselectable=""on"" src=""{4}"" alt=""{1}"">
		</span>
	</span>
	<span class=""rm-ribbon-ctl-largelabel"" unselectable=""on"">{5}</span>
</a>";
		internal override string Tag { get { return "Button"; } }

		internal override string GetHtml(out string menuHtml)
		{
			menuHtml = string.Empty;
			return string.Format(HtmlTemplate, FullyQualifiedId, Title, Tag, Image.Style, Image.Url32, TitleForUi);
		}
	}

	/// <summary>Checkbox button. Does not have inner controls.</summary>
	public class CheckboxDefinition : ButtonBaseDefinition
	{
		private string HtmlTemplate = @"
<span class=""rm-ribbon-ctl-large"" id=""{0}"" title=""{1}"" controlType=""{2}"">
	<span class=""rm-ribbon-ctl-largelabel"">
    <div style=""align:left;position: absolute;"">
			<input type=""checkbox"" id=""{3}"" {4}>
		</div>
		<div style=""text-align: left; margin-left: 20px;"">{5}</div></span>
</span>";
		internal override string Tag { get { return "Checkbox"; } }
		public bool Checked { get; set; }
		private string CheckedAttribute { get { return Checked ? "checked=\"checked\"" : string.Empty; } }

		internal override string GetHtml(out string menuHtml)
		{
			menuHtml = string.Empty;
			return string.Format(HtmlTemplate, FullyQualifiedId, Title, Tag, FullyQualifiedCheckboxId, CheckedAttribute, TitleForUi);
		}
	}
}
