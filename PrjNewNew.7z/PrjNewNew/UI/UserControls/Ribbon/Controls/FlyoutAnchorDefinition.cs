﻿using System.Collections.Generic;
using System.Text;

namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	/// <summary>
	/// Interface for all controls with inner elements
	/// </summary>
	public interface IContainer
	{
		/// <summary>Child controls of a container</summary>
		IEnumerable<ButtonDefinition> Controls { get; set; }

		/// <summary>Controls size. By default, 32x32</summary>
		ControlSize ControlsSize { get; set; }
	}

	/// <summary>
	/// Anchor for dropdown menu.
	/// Does not have any action on click.
	/// </summary>
	public class FlyoutAnchorDefinition : VisualControlBaseDefinition, IContainer
	{
		private string HTML_TEMPLATE = @"
<a class=""rm-ribbon-ctl-large "" id=""{0}"" onclick=""return false;"" href=""javascript:;"" mscui:controltype=""FlyoutAnchor"" aria-haspopup=""true"" title=""{1}"" role=""button"" unselectable=""on"">
	<span class=""rm-ribbon-ctl-largeIconContainer"" unselectable=""on"">
		<span class="" rm-ribbon-img-32by32 rm-ribbon-img-cont-float rm-ribbon-imageDisabled"" unselectable=""on"">
			<img class="""" style=""{2}"" unselectable=""on"" src=""{3}"" alt=""{1}"">
		</span>
	</span>
	<span class=""rm-ribbon-ctl-largelabel"" unselectable=""on"">{4}
		<span class=""rm-ribbon-img-5by3 rm-ribbon-img-cont-float rm-ribbon-imageDisabled"" unselectable=""on"">
			<img class="""" style=""top: -24px;left: -48px;"" unselectable=""on"" src=""/_layouts/SPUI/images/formatmap16x16.png"" alt=""{1}"">
		</span>
	</span>
</a>";

		private string FLYOUT_MENU_HTML_TEMPLATE = @"
<div unselectable=""on"" class=""rm-ribbon-menu"" id=""{0}_Menu"" role=""menu"" style=""direction: ltr; display: none; position: absolute; z-index: 1001; min-width: 54px;"">
	<div unselectable=""on"" class=""rm-ribbon-smenu-inner"">
		<div unselectable=""on"" class="""" id=""{0}_Menu_MainSection"">
			<div unselectable=""on"" class=""rm-ribbon-menusection"">
				<ul unselectable=""on"" class=""rm-ribbon-menusection-items rm-ribbon-menusection-items16"">{1}</ul>
			</div>
		</div>
	</div>
</div>";

		private string FLYOUT_MENU_ITEM_HTML_TEMPLATE = @"
<li unselectable=""on"" class=""rm-ribbon-menusection-items"" id=""{0}"">
	<a unselectable=""on"" href=""javascript:;"" onclick=""return false;"" class=""rm-ribbon-ctl-menu "" mscui:controltype=""Button"" role=""button"" title=""{1}"" id=""{0}_a"">
		<span unselectable=""on"" class=""rm-ribbon-ctl-iconContainer"">
			<span unselectable=""on"" class=""rm-ribbon-img-16by16 rm-ribbon-img-cont-float""></span>
		</span>
		<span unselectable=""on"" class=""rm-ribbon-ctl-mediumlabel"">{2}</span>
	</a></li>";

		//		private string FLYOUT_MENU_ITEM_HTML_TEMPLATE = @"
		//<li unselectable=""on"" class=""rm-ribbon-menusection-items"">
		//	<a unselectable=""on"" href=""javascript:;"" onclick=""return false;"" class=""rm-ribbon-ctl-menu "" mscui:controltype=""Button"" role=""button"" title=""{1}"" id=""{0}_Menu_MainSection_{2}"">
		//		<span unselectable=""on"" class=""rm-ribbon-ctl-iconContainer"">
		//			<span unselectable=""on"" class=""rm-ribbon-img-16by16 rm-ribbon-img-cont-float""></span>
		//		</span>
		//		<span unselectable=""on"" class=""rm-ribbon-ctl-mediumlabel"">{1}</span>
		//		<span unselectable=""on"" class=""rm-ribbon-glass-ff""></span>
		//	</a></li>";

		internal override void Validate()
		{
			//base.Validate();
			//ValidationHelper.Current.CheckArrayHasElements(this, "Controls");
		}

		internal override string Tag { get { return "FlyoutAnchor"; } }
		public IEnumerable<ButtonDefinition> Controls { get; set; }
		public ControlSize ControlsSize { get; set; }
		public string CommandEnableJavaScript { get { return "true"; } }
		public string CommandJavaScript { get { return "rm.ui.ribbon.handleMenuClick(commandId)"; } }


		internal override void Initialize(RibbonDefinition parent)
		{
			base.Initialize(parent);
			if (Controls != null)
			{
				foreach (var control in Controls)
				{
					control.Initialize(this);
				}
			}
		}


		internal override string GetHtml(out string menuHtml)
		{
			menuHtml = GetFlyoutMenuHtml();
			return string.Format(HTML_TEMPLATE, FullyQualifiedId, Title, Image.Style, Image.Url32, TitleForUi);
		}

		internal string GetFlyoutMenuHtml()
		{
			if (Controls != null)
			{
				var menuBuilder = new StringBuilder();
				foreach (var menuItem in Controls)
				{
					menuBuilder.AppendFormat(FLYOUT_MENU_ITEM_HTML_TEMPLATE, menuItem.FullyQualifiedId, menuItem.Id, menuItem.Title);
				}
				return string.Format(FLYOUT_MENU_HTML_TEMPLATE, FullyQualifiedId, menuBuilder);

			}
			return string.Empty;
		}
	}
}
