﻿using System.Text;

namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	public class TabDefinition : RibbonDefinition
	{
		private string SELECTED_TAB_BODY_STYLE = @"style=""display:none;""";
		private string SELECTED_TAB_CLASS = "rm-tt-s";
		private string HTML_BODY_TEMPLATE =
@"<div class=""rm-tabContainer"" unselectable=""on"" {0} id=""{1}"" role=""rmTabPanel""><ul class=""rm-ribbon-tabBody"">{2}</ul></div>";
		private string HTML_HEADER_TEMPLATE =
@"<li class=""rm-tt {0}"" id=""{1}-title"" tabBodyId=""{1}"" unselectable=""on"" role=""rmTab"">
	<a class=""rm-tt-a"" unselectable=""on"" href=""javascript:;"" onclick=""return false;"" onkeypress=""return true;"">
		<span class=""rm-tt-span"" unselectable=""on"">{2}</span></a></li>";

		public override string FullyQualifiedId { get { return string.Format("Ribbon_{0}", Id); } }

		internal override void Validate()
		{
			//base.Validate();
			//ValidationHelper.Current.CheckNotNull(this, "Title");
			//ValidationHelper.Current.CheckArrayHasElements(this, "GroupTemplates");
			//ValidationHelper.Current.CheckArrayHasElements(this, "Groups");
		}

		/// <summary>Title, it will be displayed as the tab caption.</summary>
		public string Title;
		/// <summary>Groups of controls. Required at least one group.</summary>
		public GroupDefinition[] Groups;

		public string GetBodyHtml(bool isVisible, out string menuHtml)
		{
			menuHtml = string.Empty;
			var groupHtml = string.Empty;
			if (Groups != null && Groups.Length > 0)
			{
				var sb = new StringBuilder();
				var sbMenu = new StringBuilder();
				foreach (var group in Groups)
				{
					sb.Append(group.GetHtml(out menuHtml));
					sbMenu.AppendFormat(menuHtml);
				}
				menuHtml = sbMenu.ToString();
				groupHtml = sb.ToString();
			}
			return string.Format(HTML_BODY_TEMPLATE, isVisible ? string.Empty : SELECTED_TAB_BODY_STYLE, FullyQualifiedId, groupHtml);
		}

		internal static string GetJavaScript()
		{
			var script = "";
			return script;
		}

		internal string GetHeaderHtml(bool isSelected)
		{
			return string.Format(HTML_HEADER_TEMPLATE, isSelected ? SELECTED_TAB_CLASS : string.Empty, FullyQualifiedId, Title);
		}

		internal void Initialize()
		{
			if (Groups != null && Groups.Length > 0)
			{
				foreach (var group in Groups) { group.Initialize(this); }
			}
		}
	}
}
