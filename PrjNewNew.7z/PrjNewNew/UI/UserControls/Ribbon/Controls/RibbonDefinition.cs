﻿
namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	public abstract class RibbonDefinition
	{
		internal virtual void Validate()
		{
			//ValidationHelper.Current.CheckNotNull(this, "Id");
			//ValidationHelper.Current.CheckRegularExpression(this, "Id", "[A-Za-z_][A-Za-z0-9_]*");
		}

		/// <summary>
		/// <para>Element identifier. It is required for every Ribbon element.</para>
		/// <para>
		/// Please, do not include namespace!
		/// Namespace is calculated automatically from parent elements' ids.
		/// Dots ('.') are not allowed within the Id.
		/// </para>
		/// </summary>
		public string Id;

		public RibbonDefinition Parent { get; protected set; }
		public virtual string FullyQualifiedId { get { return string.Format("{0}_{1}", Parent.FullyQualifiedId, Id); } }
		public virtual string FullyQualifiedCheckboxId { get { return string.Format("Cb_{0}_{1}", Parent.FullyQualifiedId, Id); } }

		internal virtual void Initialize(RibbonDefinition parent)
		{
			Parent = parent;
		}
	}
}
