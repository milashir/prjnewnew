﻿using System;
using System.Text.RegularExpressions;
using Quintiles.RM.Clinical.SharePoint.QUI;

namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	public abstract class VisualControlBaseDefinition : ControlDefinition
	{
		internal override void Validate()
		{
			//base.Validate();
			//ValidationHelper.Current.CheckNotNull(this, "Title");
		}

		/// <summary>Displayable title for control. Required.</summary>
		public string Title;

		/// <summary>
		/// Add <Br/> tag to show title in two lines to preserver horizontal space
		/// </summary>
		public string TitleForUi
		{
			get
			{
				var titleSegments = Title.Split(' ');
				if (titleSegments.Length > 1)
				{
					var lineBreakPosition = Convert.ToInt32(titleSegments.Length / 2.0);
					Match m = Regex.Match(Title, "((" + Regex.Escape(" ") + ").*?){" + lineBreakPosition + "}");

					if (m.Success)
					{
						var insertIndex = m.Groups[2].Captures[lineBreakPosition - 1].Index;
						return Title.Remove(insertIndex, 1).Insert(insertIndex, "<br/>");
					}
				}
				return Title;
			}
		}

		/// <summary>ToolTip</summary>
		public ToolTipDefinition ToolTip;

		/// <summary>Image that is displayed on the control</summary>
		public ImageDefinition Image;
	}
}
