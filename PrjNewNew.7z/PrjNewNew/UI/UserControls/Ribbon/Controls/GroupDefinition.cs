﻿using System.Text;

namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	public class GroupDefinition : RibbonDefinition
	{
		private string HTML_TEMPLATE =
@"
<li class=""rm-ribbon-group"" id=""{0}"" unselectable=""on"">
	<span class=""rm-ribbon-groupContainer"" unselectable=""on"">
		<span class=""rm-ribbon-groupBody"" unselectable=""on"">
			<span class=""rm-ribbon-layout"" id=""Ribbon.RequestRibbon.HomeGridActions-Large"" unselectable=""on"">
				<span class=""rm-ribbon-section""  unselectable=""on"">
					<span class=""rm-ribbon-row-onerow"" unselectable=""on"">{1}</span>
				</span>
			</span>
		</span>
		<span class=""rm-ribbon-groupTitle"" unselectable=""on"" title=""{2}"">{2}</span>
	</span>
	<span class=""rm-ribbon-groupSeparator"" unselectable=""on""></span>
</li>";
		internal override void Validate()
		{
			//base.Validate();
			//ValidationHelper.Current.CheckNotNull(this, "Title");
			//ValidationHelper.Current.CheckNotNull(this, "Template");
			//ValidationHelper.Current.CheckArrayHasElements(this, "Controls");
		}

		/// <summary>Title. Will be displayed below the controls with small gray font. Required.</summary>
		public string Title;

		public GroupTemplateDefinition Template;


		/// <summary>Collection of inner controls</summary>
		public ControlDefinition[] Controls;

		internal string GetHtml(out string menuHtml)
		{
			menuHtml = string.Empty;
			var controlHtml = string.Empty;
			if (Controls != null && Controls.Length > 0)
			{
				var sb = new StringBuilder();
				var sbMenu = new StringBuilder();
				foreach (var control in Controls)
				{
					sb.Append(control.GetHtml(out menuHtml));
					sbMenu.Append(menuHtml);
				}
				menuHtml = sbMenu.ToString();
				controlHtml = sb.ToString();
			}
			return string.Format(HTML_TEMPLATE, FullyQualifiedId, controlHtml, Title);
		}

		internal void Initialize(TabDefinition tabDefinition)
		{
			Parent = tabDefinition;
			if (Controls != null && Controls.Length > 0)
			{
				foreach (var control in Controls) { control.Initialize(this); }
			}
		}
	}
}
