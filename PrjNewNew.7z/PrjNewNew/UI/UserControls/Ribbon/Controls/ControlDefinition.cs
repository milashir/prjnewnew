﻿
namespace Quintiles.RM.Clinical.Ui.Ribbon
{
	public abstract class ControlDefinition : RibbonDefinition
	{
		internal abstract string Tag { get; }
		internal abstract string GetHtml(out string menuHtml);
	}
}
