﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Quintiles.RM.Clinical.UI.UserControls;
using Quintiles.RM.Clinical.SharePoint.QUI;

namespace Quintiles.RM.Clinical.Ui.Ribbon
{






}
