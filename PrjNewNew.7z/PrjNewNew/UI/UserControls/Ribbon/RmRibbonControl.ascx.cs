﻿using System;
using System.Web.UI;
using Quintiles.RM.Clinical.Ui.Ribbon;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class RmRibbonControl : UserControl
	{
		public RmRibbon RibbonControlData { get; set; }
		protected void Page_Load(object sender, EventArgs e)
		{ }

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			if (RibbonControlData != null)
			{
				Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "RmRibbonCommands", RibbonControlData.GetJavaScript());
			}
		}
		protected override void Render(HtmlTextWriter writer)
		{
			base.Render(writer);
			RenderRibbon(writer);
		}

		private void RenderRibbon(HtmlTextWriter writer)
		{
			if (RibbonControlData != null)
			{
				string flyoutMenuHtml;
				writer.Write(RibbonControlData.GetHtml(out flyoutMenuHtml));
				writer.Write(flyoutMenuHtml);
			}
		}
	}
}
