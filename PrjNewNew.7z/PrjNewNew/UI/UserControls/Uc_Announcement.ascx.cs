﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Quintiles.RM.Clinical.Domain.Services;
using Quintiles.RM.Clinical.Domain.Services.DataContracts;
using Quintiles.RPM.Common;

namespace Quintiles.RM.Clinical.UI.UserControls
{
    public partial class Uc_Announcement : UserControl
    {
        public bool ShowInDialog { get; set; }
        protected string revision = CacheService.GetRevisionQueryString;
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnShowInDialog.Value = ShowInDialog.GetIntAsStringFromBool();
        }
    }
}
