﻿using System;
using System.Web.UI;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.SharePoint.ControlTemplates.Quintiles.RM.Clinical.SharePoint
{
	public partial class RequestSplitConfiguration : UserControl
	{
		public string revision { get { return CacheService.GetRevisionQueryString; } }
		public string RequestId { get; set; }
		public string Sites { get; set; }
		public string FTE { get; set; }
		public string TotalHoursPerSite { get; set; }
		protected void Page_Load(object sender, EventArgs e)
		{
			hdnRequestId.Value = RequestId;
			hdnSites.Value = Sites;
			hdnFTE.Value = FTE;
			hdnTotalHoursPerSite.Value = TotalHoursPerSite;

			////To get details off SSV to calculate FTE in javascript
			//List<string> ssv = SSVRequest.GetSSVDetails(Convert.ToInt32(RequestId));
			//if (ssv.Count > 0)
			//{
			//	hdnStartDate.Value = ssv[0];
			//	hdnStopDate.Value = ssv[1];
			//	hdnUtilization.Value = ssv[2];
			//	hdnWeeklyHours.Value = ssv[3];
			//	hdnCountryId.Value = ssv[4];
			//}
		}
	}
}
