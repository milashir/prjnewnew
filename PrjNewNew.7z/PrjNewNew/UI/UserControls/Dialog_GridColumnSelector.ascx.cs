﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class Dialog_GridColumnSelector : UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}
