﻿using System;
using System.Web.UI;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.SharePoint.ControlTemplates.Quintiles.RM.Clinical.SharePoint
{
	public partial class SSVCountryCalculator : UserControl
	{
		public string isPostBackForm { get; set; }
		public string revision { get { return CacheService.GetRevisionQueryString; } }
		
		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}
