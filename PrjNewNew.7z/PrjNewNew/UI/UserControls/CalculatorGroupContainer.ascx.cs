﻿using System;
using Quintiles.RM.Clinical.Domain.BaseClasses;
using Quintiles.RM.Clinical.Domain.BaseClasses.UserControls;
using Quintiles.RM.Clinical.Domain.Models.Calculator.ObjectModel;
using Quintiles.RM.Clinical.Domain.Utilities;
using Quintiles.RM.Clinical.UI.UserControls.Calculator;
using Quintiles.RPM.Common;
using models = Quintiles.RM.Clinical.Domain.Models;
namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class CalculatorGroupContainer : RmBaseUserControl
	{
		public CalculatorGroupContainerData CalculatorContainerData;
		public JS_CalculatorGroupContainerDetails JSCalculatorGroupContainer { get; set; }
		public string IsBackfillRequest { get; private set; }
		public bool IsRequestHardOrSoftBooked { get; set; }
		public bool MultiEditMode { get; set; }

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Visible)
			{
				return;
			}
			this.hdnMultiEditMode.Value = MultiEditMode.GetIntAsStringFromBool();
			this.CalculatorContainerData.IsEditMultipleRequests = MultiEditMode;
			if (!CalculatorContainerData.IsIndependentCalculator)
			{
				if (CalculatorContainerData.IsNewRequest && (!CalculatorContainerData.AttributeType.HasValue && CalculatorContainerData.AttributeId == 0))
				{
					throw new Exception("For new request Attribute Type and Attribute Id is required.");
				}
				else if (!CalculatorContainerData.IsIndependentCalculator && !CalculatorContainerData.AttributeType.HasValue && CalculatorContainerData.RequestId == 0)
				{
					throw new ArgumentNullException("RequestId");
				}
				else if (CalculatorContainerData.AttributeType.HasValue && CalculatorContainerData.AttributeId == 0)
				{
					throw new ArgumentNullException("AttributeId");
				}
			}

			((ConnectDisconnectDialog)ucConnectDisconnectDialog).IsCountryCalculator = !CalculatorContainerData.IsNewRequest && CalculatorContainerData.RequestId <= 0;
			lvTabs.DataSource = CalculatorContainerData.CalculatorGroups;
			lvTabs.DataBind();

			JSCalculatorGroupContainer = new JS_CalculatorGroupContainerDetails(CalculatorContainerData.IsRequestCalculator);
			foreach (AbstractCalculatorGroup calculatorGroup in CalculatorContainerData.CalculatorGroups)
			{
				CalculatorGroupUserControl cguc = calculatorGroup.LoadControl(); //loads the ascx control
				cguc.IsRequestHardOrSoftBooked = IsRequestHardOrSoftBooked;
				calculatorGroup.MultiEditMode = this.MultiEditMode;
				cguc.CalculatorGroup = calculatorGroup;
				cguc.LoadControls(); //Loads the individual calculators within group
				JSCalculatorGroupContainer.CalculatorGroups.Add(cguc.JSCalculatorGroupDetails);

				phCalculator.Controls.Add(cguc);
			}

			hdnAttributeTypeId.Value = CalculatorContainerData.AttributeType.HasValue ?
				((int)CalculatorContainerData.AttributeType.GetValueOrDefault()).ToString() :
				"-1";

			hdnRequestId.Value = CalculatorContainerData.RequestId.ToString();
			hdnAttributeId.Value = CalculatorContainerData.AttributeId.ToString();
			hdnIsNewRequest.Value = GetIntAsStringFromBool(CalculatorContainerData.IsNewRequest);
			hdnIsIndependentCalculator.Value = GetIntAsStringFromBool(CalculatorContainerData.IsIndependentCalculator);
			hdnRequestTypeId.Value = CalculatorContainerData.RequestTypeId.ToString();
			hdnProjectId.Value = CalculatorContainerData.ProjectId.ToString();
			hdnProjectDteTypeId.Value = ((int)CalculatorContainerData.ProjectDteType).ToString();
			hdnVisitSchemaLevelId.Value = CalculatorContainerData.VisitSchemaLevelId.ToString();
			hdnJobGrade.Value = CalculatorContainerData.JobGrade.HasValue ? CalculatorContainerData.JobGrade.GetValueOrDefault().ToString() : string.Empty;
			hdnJobGradeInfoString.Value = CalculatorContainerData.JobGradeInfoStr;

			if (CalculatorContainerData.RequestId > 0)
			{
				IsBackfillRequest = models.Request.Find(CalculatorContainerData.RequestId).IsBackfillRequest.ToString().ToLower();
			}
			else
			{
				IsBackfillRequest = false.ToString().ToLower();
			}
		}

		public string GetJson()
		{
			return SerializationHelper.SerializeToJson(JSCalculatorGroupContainer);
		}
	}
}
