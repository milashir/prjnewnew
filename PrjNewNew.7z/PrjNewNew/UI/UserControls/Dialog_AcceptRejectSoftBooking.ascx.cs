﻿using System;
using System.Web.UI;
namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class Dialog_AcceptRejectSoftBooking : UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}