﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using Quintiles.RM.Clinical.Domain.Models;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class OrganizationalUnitPPMList : UserControl
	{
		public int OrganizationalUnitId { get; set; }
		public bool AddNewMode { get; set; }
		public List<OrganizationalUnit_PPM> OrganizationalUnitPpmList { get; private set; }

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!AddNewMode && OrganizationalUnitId <= 0)
			{
				throw new Exception("OrganizationalUnitId cannot be 0");
			}
			else
			{
				BindControls();
			}
		}

		private void BindControls()
		{
			if (AddNewMode)
			{
				OrganizationalUnitPpmList = new List<OrganizationalUnit_PPM>();
			}
			else
			{
				OrganizationalUnitPpmList = OrganizationalUnit_PPM.FindAllByOrganizationalUnitId(OrganizationalUnitId);
			}
			rptPpmList.DataSource = OrganizationalUnitPpmList;
			rptPpmList.DataBind();
		}
	}
}
