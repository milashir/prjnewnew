﻿using System;
using Quintiles.RM.Clinical.Domain.BaseClasses.UserControls;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class InitiateCaclulatorGroup : CalculatorGroupUserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			tblOnSiteVisit.Visible = CalculatorGroup.HasOnSiteVisitCalculator();
			tblPhoneVisit.Visible = !tblOnSiteVisit.Visible;
            trFte.Visible = false;
            trPhoneFte.Visible = false;
		}
	}
}
