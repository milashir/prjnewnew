﻿using System;
using Quintiles.RM.Clinical.Domain.BaseClasses.UserControls;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class PharmacyCalculatorGroup : CalculatorGroupUserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			InitializeNonDteVisitPatternControl();
			if (MultiEditMode || !IsRequestLevelCalculator)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false;
			}
		}

		private void InitializeNonDteVisitPatternControl()
		{
			var visitPatternControl = nonDteVisitPattern as NonDteVisitPattern;
			visitPatternControl.IsCountryCalculator = !CalculatorGroup.IsRequestLevelCalculator;
			visitPatternControl.CalculatorGroup = CalculatorGroup.CalculatorGroup;
			visitPatternControl.MonitoringAttributeId = CalculatorGroup.AttributeId.GetValueOrDefault();
			visitPatternControl.MultiEditMode = CalculatorGroup.MultiEditMode;
			nonDteVisitPattern.Visible = (!MultiEditMode && !IsRequestLevelCalculator);
		}
	}
}
