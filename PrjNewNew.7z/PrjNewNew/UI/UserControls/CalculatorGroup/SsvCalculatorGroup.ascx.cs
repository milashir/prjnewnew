﻿using System;
using Quintiles.RM.Clinical.Domain.BaseClasses.UserControls;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class SsvCalculatorGroup : CalculatorGroupUserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (MultiEditMode)
			{
				trFte.Visible = false;
				trPhoneFte.Visible = false;
				thTotalHours.Visible = false;
				trTotalNumberOfSites.Visible = false;
			}

			if (IsRequestLevelCalculator)
			{
				trOnSiteNumberOfSites.Visible = false;
				trPhoneNumberOfSites.Visible = false;
				trTotalNumberOfSites.Visible = false;
			}
		}
	}
}
