﻿using System.Web.UI;
using Quintiles.RM.Clinical.Domain.Services;


namespace Quintiles.RM.Clinical.SharePoint.ControlTemplates.Quintiles.RM.Clinical.SharePoint
{
	public partial class SSVCountrySpecificGrid : UserControl
	{
		protected string revision = CacheService.GetRevisionQueryString;
		//protected void Page_Load(object sender, EventArgs e)
		//{
		//	//Get Request Details and set Hidden field values.
		//	int requestId = Int32.Parse(HttpContext.Current.Request["requestId"]);
		//	models.Request request = models.Request.Find(requestId);
		//	SetCountryRegionCustomJSON(request);
		//	SetSSVTargetedAndQipData(request);
		//}

		//private void SetSSVTargetedAndQipData(models.Request request)
		//{
		//	//Data For Last 2 Rows of the jQGrid
		//	SSVAttribute ssvdata = SSVAttribute.FindByProjectIdCountryId(request.Project.Id, request.CountryId);
		//	hdnTargetedTotalHours.Value = ssvdata.TargetedQIPTotalHours.ToString();
		//	hdnTargetedTotalSites.Value = ssvdata.ProjectedTotalSites.ToString();
		//	decimal targetedHoursPerSite = (ssvdata.ProjectedTotalSites == null || ssvdata.ProjectedTotalSites == 0) ? 0 : (ssvdata.TargetedQIPTotalHours ?? 0) / (ssvdata.ProjectedTotalSites ?? 0);
		//	hdnTargetedHoursPerSite.Value = Math.Round(targetedHoursPerSite, 2).ToString();
		//	hdnTargetedMonthlyFTE.Value = models.Request.CalculateFTE(request.ResourceTypeId, ssvdata.CountryId, ssvdata.SSVAttributeStartDate.GetValueOrDefault(), ssvdata.SSVAttributeStopDate.GetValueOrDefault(), ssvdata.TargetedQIPTotalHours.GetValueOrDefault(), targetedHoursPerSite).MonthlyFTE.ToString();
		//	hdnQipTotalHours.Value = ssvdata.QipTotalHours.ToString();
		//	hdnQipTotalSites.Value = ssvdata.QIPTotalSites.ToString();
		//	decimal qipHoursPerSite = (ssvdata.QIPTotalSites == null || ssvdata.QIPTotalSites == 0) ? 0 : (ssvdata.QipTotalHours ?? 0) / (ssvdata.QIPTotalSites ?? 0);
		//	hdnQipdHoursPerSite.Value = Math.Round(qipHoursPerSite, 2).ToString();
		//	hdnQipMonthlyFTE.Value = models.Request.CalculateFTE(0, ssvdata.CountryId, ssvdata.SSVAttributeStartDate.GetValueOrDefault(), ssvdata.SSVAttributeStopDate.GetValueOrDefault(), ssvdata.QipTotalHours.GetValueOrDefault(), qipHoursPerSite).MonthlyFTE.ToString();
		//}

		//private void SetCountryRegionCustomJSON(models.Request request)
		//{
		//	var allCountryRegionInCustomJSONFormat = "{";
		//	allCountryRegionInCustomJSONFormat += @"""0""" + ":" + @"""--Select--""" + ",";
		
		//	//Since the editoptions function of the jQGrid requires data in this format used this instead of using ajax or SerializationHelper Method.
		//	foreach (var crl in request.Country.CountryRegionList)
		//	{
		//		allCountryRegionInCustomJSONFormat += "\"" + crl.Id + "\"" + ":" + "\"" + crl.Name + "\"" + ",";
		//	}
		//	allCountryRegionInCustomJSONFormat = allCountryRegionInCustomJSONFormat.Substring(0, allCountryRegionInCustomJSONFormat.Length - 1);
		//	allCountryRegionInCustomJSONFormat += "}";
		//	hdnCountryRegionList.Value = allCountryRegionInCustomJSONFormat;
		//}
	}
}