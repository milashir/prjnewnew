﻿using System;
using System.Web.UI;
using Quintiles.RM.Clinical.Domain.Services;

namespace Quintiles.RM.Clinical.UI.UserControls
{
	public partial class FTECalculator : UserControl
	{
		public string isPostBackForm { get; set; }
		public string revision { get { return CacheService.GetRevisionQueryString; } }
		public bool IsRequestHardOrSoftBooked { get; set; }
		public bool MultiEditMode { get; set; }

		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}
